/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: deddca6
 * Options:   (none)
 * Seed:      2811314592
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int64_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_6 = 0xC4B4E126L;
static union U0 g_28 = {-3L};
static int32_t g_65 = (-5L);
static uint64_t g_82[5][5][9] = {{{18446744073709551608UL,0x89E6D542D3F7CC82LL,0x26224F168E5B495ALL,3UL,0x559F947EB5F43E01LL,18446744073709551609UL,18446744073709551615UL,0x70B5DC3D349FFB2ELL,0UL},{0UL,0UL,18446744073709551609UL,0UL,1UL,0x65BDF5444FE37806LL,0xAF4455642E063A29LL,0x5D079270D6E0D248LL,8UL},{0x2139E6D594933308LL,0xE2C5435112828081LL,7UL,0xCADD72F777BDFF10LL,0xEBE340CFCE320EC4LL,18446744073709551609UL,1UL,18446744073709551615UL,0xA841158A35CCC4EFLL},{0x2139E6D594933308LL,1UL,18446744073709551606UL,18446744073709551609UL,2UL,0x2835E52A12E21983LL,0xEBE340CFCE320EC4LL,0xA841158A35CCC4EFLL,18446744073709551609UL},{0UL,0x5D079270D6E0D248LL,18446744073709551615UL,18446744073709551606UL,0xB7A8BFC0225587BBLL,0xAF4455642E063A29LL,0x87DF3DEF630FE8BALL,1UL,18446744073709551609UL}},{{18446744073709551608UL,0xB7A8BFC0225587BBLL,0x1CC5CA36B4E13384LL,3UL,0UL,0xCB182417F16C3B14LL,0UL,3UL,0x1CC5CA36B4E13384LL},{0xBFD7802F47D66A43LL,0xBFD7802F47D66A43LL,0x774A768641A018BFLL,0UL,6UL,0xEBE340CFCE320EC4LL,18446744073709551615UL,0xCA37EAD942A26B13LL,2UL},{3UL,0xAF4455642E063A29LL,1UL,0x5C771C75621C9A83LL,18446744073709551610UL,5UL,18446744073709551609UL,1UL,18446744073709551615UL},{5UL,0x2139E6D594933308LL,0x774A768641A018BFLL,0UL,18446744073709551615UL,0xCBABA1048D1DFF66LL,0x5C771C75621C9A83LL,0xD1BD9F019D5C01CFLL,0x3F29F9B9B769E501LL},{0xE3B8AEA20016C6A4LL,9UL,0x1CC5CA36B4E13384LL,18446744073709551615UL,18446744073709551609UL,0x155D2618108949E3LL,0xD1BD9F019D5C01CFLL,0x89E6D542D3F7CC82LL,0xCA37EAD942A26B13LL}},{{7UL,0x9ADBE56F6324B7C8LL,3UL,1UL,18446744073709551609UL,18446744073709551615UL,0UL,0xE99E236B79BA4D29LL,0x89E6D542D3F7CC82LL},{0xCADD72F777BDFF10LL,0x155D2618108949E3LL,0x443A54D8FDC3C1A3LL,0x559F947EB5F43E01LL,0xCB182417F16C3B14LL,1UL,0x155D2618108949E3LL,0x2139E6D594933308LL,1UL},{8UL,18446744073709551609UL,18446744073709551611UL,6UL,0xCB182417F16C3B14LL,5UL,0x65BDF5444FE37806LL,8UL,18446744073709551609UL},{0x70B5DC3D349FFB2ELL,0x2835E52A12E21983LL,0x5C771C75621C9A83LL,0x9BA6CE2C69141744LL,18446744073709551609UL,0UL,0xCA37EAD942A26B13LL,18446744073709551610UL,0UL},{18446744073709551606UL,0x774A768641A018BFLL,3UL,0x2139E6D594933308LL,18446744073709551609UL,18446744073709551608UL,9UL,1UL,9UL}},{{9UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,9UL,1UL,0x35D6DF81F9D3F58FLL,3UL},{0xBFD7802F47D66A43LL,0xA841158A35CCC4EFLL,6UL,0x559F947EB5F43E01LL,18446744073709551610UL,0x5D079270D6E0D248LL,18446744073709551609UL,18446744073709551609UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551612UL,0x70B5DC3D349FFB2ELL,18446744073709551609UL,6UL,0x26224F168E5B495ALL,1UL,0x9BA6CE2C69141744LL,18446744073709551615UL},{0UL,18446744073709551609UL,0x5C771C75621C9A83LL,0x225765C99C2354C0LL,0UL,0UL,9UL,0x774A768641A018BFLL,18446744073709551611UL},{0xCA138DBEC8B24CECLL,8UL,2UL,0UL,0x5D079270D6E0D248LL,0xBFD7802F47D66A43LL,0xCA37EAD942A26B13LL,0x89E6D542D3F7CC82LL,0xD1BD9F019D5C01CFLL}},{{0UL,18446744073709551615UL,0UL,1UL,0x2DC96F097794FBAELL,0x93F16A1EA5693CDBLL,0x65BDF5444FE37806LL,0x1CC5CA36B4E13384LL,1UL},{0xEBE340CFCE320EC4LL,0x87DF3DEF630FE8BALL,0x2835E52A12E21983LL,0UL,0x93F16A1EA5693CDBLL,0UL,0x155D2618108949E3LL,0xCB182417F16C3B14LL,1UL},{18446744073709551615UL,0xB7A8BFC0225587BBLL,1UL,0xCA37EAD942A26B13LL,8UL,1UL,0UL,0x70B5DC3D349FFB2ELL,0xD1BD9F019D5C01CFLL},{0x26224F168E5B495ALL,0x5C771C75621C9A83LL,0x774A768641A018BFLL,0xCBABA1048D1DFF66LL,0UL,0UL,0xD1BD9F019D5C01CFLL,0xCA37EAD942A26B13LL,18446744073709551611UL},{0UL,18446744073709551615UL,0x559F947EB5F43E01LL,0x5C771C75621C9A83LL,18446744073709551606UL,18446744073709551606UL,0x5C771C75621C9A83LL,0x559F947EB5F43E01LL,18446744073709551615UL}}};
static int16_t g_91 = (-1L);
static volatile union U0 g_103 = {1L};/* VOLATILE GLOBAL g_103 */
static volatile union U0 *g_102[8] = {&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103};
static volatile union U0 ** volatile g_101 = &g_102[5];/* VOLATILE GLOBAL g_101 */
static uint32_t g_119 = 4294967292UL;
static int32_t g_122 = (-8L);
static int32_t * volatile g_121[7] = {&g_122,&g_122,&g_122,&g_122,&g_122,&g_122,&g_122};
static int32_t * volatile g_143 = &g_122;/* VOLATILE GLOBAL g_143 */
static volatile int8_t g_176 = 1L;/* VOLATILE GLOBAL g_176 */
static volatile int8_t * const g_175[8] = {&g_176,&g_176,&g_176,&g_176,&g_176,&g_176,&g_176,&g_176};
static uint16_t g_179 = 0UL;
static int64_t g_186[4][9] = {{0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL},{0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL},{0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL},{0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL,0xC767B023839C7493LL}};
static union U0 * const g_195 = (void*)0;
static union U0 * const *g_194 = &g_195;
static int32_t g_197[4] = {(-2L),(-2L),(-2L),(-2L)};
static int64_t g_201[2][4][8] = {{{0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL},{0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL},{0x88D7C33F7625D64DLL,0x88D7C33F7625D64DLL,0x38AAF2569BDC7687LL,0x88D7C33F7625D64DLL,0x88D7C33F7625D64DLL,0x38AAF2569BDC7687LL,0x88D7C33F7625D64DLL,0x88D7C33F7625D64DLL},{0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL}},{{0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL},{0x88D7C33F7625D64DLL,0x88D7C33F7625D64DLL,0x38AAF2569BDC7687LL,0x88D7C33F7625D64DLL,0x88D7C33F7625D64DLL,0x38AAF2569BDC7687LL,0x88D7C33F7625D64DLL,0x88D7C33F7625D64DLL},{0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL},{0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL,0x338217DE881EA7A1LL,0x88D7C33F7625D64DLL,0x338217DE881EA7A1LL}}};
static int8_t g_202 = 0x25L;
static int64_t g_213 = 0x27E87AF14CE292E2LL;
static union U0 *g_218 = &g_28;
static union U0 ** volatile g_217 = &g_218;/* VOLATILE GLOBAL g_217 */
static volatile int32_t *g_235 = (void*)0;
static volatile int32_t **g_234 = &g_235;
static volatile int32_t *** volatile g_233 = &g_234;/* VOLATILE GLOBAL g_233 */
static volatile int32_t g_241[3] = {(-1L),(-1L),(-1L)};
static uint64_t *g_249[7] = {&g_82[3][2][4],&g_82[3][2][4],&g_82[3][2][4],&g_82[3][2][4],&g_82[3][2][4],&g_82[3][2][4],&g_82[3][2][4]};
static uint64_t **g_248 = &g_249[5];
static uint64_t *** volatile g_247[3][4] = {{&g_248,&g_248,&g_248,&g_248},{(void*)0,&g_248,&g_248,&g_248},{&g_248,&g_248,&g_248,&g_248}};
static uint16_t g_267 = 1UL;
static volatile int64_t g_268 = 1L;/* VOLATILE GLOBAL g_268 */
static union U0 **g_291[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint32_t g_296 = 0UL;
static const int16_t g_335[9] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
static volatile uint32_t * volatile *g_362 = (void*)0;
static const int16_t g_425 = 0x681DL;
static const int16_t *g_424 = &g_425;
static int64_t g_436 = 0L;
static volatile uint8_t *g_504 = (void*)0;
static volatile uint8_t **g_503[7][7] = {{&g_504,(void*)0,&g_504,&g_504,&g_504,&g_504,(void*)0},{&g_504,&g_504,(void*)0,(void*)0,&g_504,&g_504,&g_504},{&g_504,&g_504,&g_504,(void*)0,&g_504,&g_504,&g_504},{&g_504,&g_504,&g_504,(void*)0,(void*)0,&g_504,&g_504},{(void*)0,&g_504,&g_504,&g_504,&g_504,(void*)0,&g_504},{&g_504,&g_504,&g_504,&g_504,&g_504,&g_504,&g_504},{&g_504,&g_504,(void*)0,&g_504,&g_504,&g_504,&g_504}};
static uint8_t g_506 = 0x68L;
static int16_t *g_513 = &g_91;
static int16_t *g_514 = (void*)0;
static volatile int64_t g_522[3] = {0x23521C5DCD7DFA84LL,0x23521C5DCD7DFA84LL,0x23521C5DCD7DFA84LL};
static volatile int64_t *g_521 = &g_522[2];
static volatile int32_t g_585 = (-1L);/* VOLATILE GLOBAL g_585 */
static uint16_t g_600 = 0xA7EAL;
static volatile union U0 ** volatile g_622 = &g_102[5];/* VOLATILE GLOBAL g_622 */
static const int32_t *g_632 = &g_122;
static const int32_t ** volatile g_631 = &g_632;/* VOLATILE GLOBAL g_631 */
static int8_t g_635 = 0x55L;
static volatile int32_t g_658 = (-1L);/* VOLATILE GLOBAL g_658 */
static union U0 g_811 = {-7L};
static uint32_t g_887[9][4][1] = {{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}},{{8UL},{8UL},{8UL},{8UL}}};
static volatile union U0 * volatile *g_890 = &g_102[3];
static volatile union U0 * volatile * const  volatile *g_889[6] = {&g_890,&g_890,&g_890,&g_890,&g_890,&g_890};
static volatile union U0 * volatile * const  volatile **g_888 = &g_889[1];
static const int32_t *g_1011 = &g_122;
static const int32_t ** volatile g_1010 = &g_1011;/* VOLATILE GLOBAL g_1010 */
static const uint8_t g_1017 = 0UL;
static const uint8_t *g_1016 = &g_1017;
static const uint8_t **g_1015 = &g_1016;
static const uint8_t ***g_1014[5][5] = {{(void*)0,&g_1015,(void*)0,&g_1015,(void*)0},{&g_1015,&g_1015,&g_1015,&g_1015,&g_1015},{&g_1015,&g_1015,&g_1015,&g_1015,&g_1015},{&g_1015,&g_1015,&g_1015,&g_1015,&g_1015},{(void*)0,&g_1015,(void*)0,&g_1015,(void*)0}};
static const volatile union U0 * const  volatile g_1038 = (void*)0;/* VOLATILE GLOBAL g_1038 */
static const volatile union U0 * volatile g_1041 = &g_103;/* VOLATILE GLOBAL g_1041 */
static volatile uint64_t g_1097 = 0x483A1BB631FAE6F7LL;/* VOLATILE GLOBAL g_1097 */
static volatile uint64_t *g_1096 = &g_1097;
static volatile uint64_t **g_1095[8][4] = {{&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096}};
static int32_t **g_1117 = (void*)0;
static int32_t *g_1158[6][4] = {{(void*)0,&g_197[3],(void*)0,(void*)0},{&g_197[3],&g_197[3],&g_65,&g_197[3]},{&g_197[3],(void*)0,(void*)0,&g_197[3]},{(void*)0,&g_197[3],(void*)0,(void*)0},{&g_197[3],&g_197[3],&g_65,&g_197[3]},{&g_197[3],(void*)0,(void*)0,&g_197[3]}};
static int32_t **g_1157[4] = {&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]};
static volatile int32_t g_1300 = (-1L);/* VOLATILE GLOBAL g_1300 */
static union U0 g_1353 = {0xA603810EF200B97ELL};
static volatile uint16_t g_1459 = 0UL;/* VOLATILE GLOBAL g_1459 */
static union U0 ***g_1484 = (void*)0;
static int32_t *** volatile g_1487[7][1][5] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_1117,&g_1117,&g_1117,&g_1117,&g_1117}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_1117,&g_1117,&g_1117,&g_1117,&g_1117}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_1117,&g_1117,&g_1117,&g_1117,&g_1117}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
static const int64_t *g_1754 = (void*)0;
static const int64_t **g_1753 = &g_1754;
static const int64_t ***g_1752 = &g_1753;
static int16_t g_1808 = 5L;
static int64_t ****g_1845 = (void*)0;
static int64_t *****g_1844 = &g_1845;
static int8_t g_1879[4][5][1] = {{{(-1L)},{0xCAL},{0x76L},{0xCAL},{(-1L)}},{{0xCAL},{0x76L},{0xCAL},{(-1L)},{0xCAL}},{{0x76L},{0xCAL},{(-1L)},{0xCAL},{0x76L}},{{0xCAL},{(-1L)},{0xCAL},{0x76L},{0xCAL}}};
static int8_t *g_1878 = &g_1879[2][4][0];
static uint32_t ***g_1929 = (void*)0;
static int32_t g_1931 = 1L;
static uint64_t g_1971 = 18446744073709551609UL;
static uint8_t *g_2010 = &g_506;
static uint8_t * const *g_2009 = &g_2010;
static uint8_t * const **g_2008 = &g_2009;
static uint8_t * const *** volatile g_2007 = &g_2008;/* VOLATILE GLOBAL g_2007 */
static volatile uint32_t *g_2029 = (void*)0;
static volatile uint32_t **g_2028[7] = {&g_2029,&g_2029,&g_2029,&g_2029,&g_2029,&g_2029,&g_2029};
static volatile uint32_t *** volatile g_2027 = &g_2028[6];/* VOLATILE GLOBAL g_2027 */
static uint64_t g_2032 = 0x4DAC8508D6575DE6LL;
static union U0 **** volatile g_2036[6] = {&g_1484,&g_1484,&g_1484,&g_1484,&g_1484,&g_1484};
static union U0 **** const  volatile g_2037 = &g_1484;/* VOLATILE GLOBAL g_2037 */
static uint8_t * const ***g_2082 = &g_2008;
static uint8_t * const ****g_2081 = &g_2082;
static int32_t ** volatile g_2114[1][3][3] = {{{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[0][1],&g_1158[4][0],&g_1158[0][1]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]}}};
static int32_t ** volatile g_2115[5][10] = {{&g_1158[4][0],&g_1158[2][3],&g_1158[4][0],&g_1158[2][2],&g_1158[4][0],&g_1158[4][0],(void*)0,&g_1158[2][1],&g_1158[0][1],&g_1158[4][0]},{&g_1158[4][0],(void*)0,&g_1158[2][1],&g_1158[0][1],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[0][1],&g_1158[2][1],(void*)0},{&g_1158[4][0],&g_1158[4][0],&g_1158[0][1],&g_1158[2][1],(void*)0,&g_1158[4][0],&g_1158[4][0],&g_1158[2][2],&g_1158[4][0],&g_1158[2][3]},{&g_1158[4][0],&g_1158[4][0],&g_1158[2][2],&g_1158[4][0],&g_1158[2][3],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[4][0],&g_1158[2][3],&g_1158[4][0],&g_1158[2][2],&g_1158[4][0]}};
static uint64_t g_2202 = 0x31C72EFE7653F8D2LL;
static int32_t * volatile g_2229[10] = {&g_122,&g_122,&g_122,&g_122,&g_122,&g_122,&g_122,&g_122,&g_122,&g_122};
static int32_t ** volatile g_2329 = &g_1158[4][0];/* VOLATILE GLOBAL g_2329 */
static volatile uint32_t g_2345 = 0UL;/* VOLATILE GLOBAL g_2345 */
static volatile uint64_t * volatile * volatile * volatile * volatile *g_2368[2] = {(void*)0,(void*)0};
static uint8_t g_2431 = 4UL;
static volatile int32_t * volatile *g_2462 = &g_235;
static volatile int32_t * volatile **g_2461 = &g_2462;
static volatile int32_t * volatile ** volatile *g_2460 = &g_2461;
static int32_t ** volatile g_2492 = &g_1158[0][0];/* VOLATILE GLOBAL g_2492 */
static int32_t ** volatile g_2495 = &g_1158[4][0];/* VOLATILE GLOBAL g_2495 */
static union U0 ** volatile g_2499 = &g_218;/* VOLATILE GLOBAL g_2499 */
static uint8_t g_2541[4] = {255UL,255UL,255UL,255UL};
static int64_t *g_2579 = &g_201[0][1][7];
static int64_t **g_2578 = &g_2579;
static int64_t ** const *g_2577[10][10][2] = {{{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{(void*)0,(void*)0},{(void*)0,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578}},{{&g_2578,&g_2578},{(void*)0,(void*)0},{&g_2578,&g_2578},{&g_2578,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578}},{{&g_2578,&g_2578},{&g_2578,(void*)0},{(void*)0,(void*)0},{&g_2578,&g_2578},{(void*)0,&g_2578},{(void*)0,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,(void*)0},{(void*)0,(void*)0}},{{&g_2578,&g_2578},{(void*)0,(void*)0},{&g_2578,(void*)0},{(void*)0,&g_2578},{&g_2578,(void*)0},{(void*)0,(void*)0},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{(void*)0,&g_2578}},{{(void*)0,&g_2578},{&g_2578,(void*)0},{(void*)0,(void*)0},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,(void*)0},{&g_2578,(void*)0}},{{&g_2578,&g_2578},{&g_2578,(void*)0},{&g_2578,&g_2578},{(void*)0,&g_2578},{(void*)0,(void*)0},{&g_2578,(void*)0},{&g_2578,(void*)0},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,(void*)0}},{{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,(void*)0},{&g_2578,(void*)0},{&g_2578,(void*)0},{(void*)0,&g_2578},{(void*)0,&g_2578},{&g_2578,(void*)0},{&g_2578,&g_2578},{&g_2578,(void*)0}},{{&g_2578,&g_2578},{&g_2578,(void*)0},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,(void*)0},{&g_2578,&g_2578},{(void*)0,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{(void*)0,&g_2578}},{{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,(void*)0},{&g_2578,&g_2578},{(void*)0,&g_2578},{&g_2578,(void*)0},{(void*)0,&g_2578},{&g_2578,&g_2578},{(void*)0,(void*)0},{&g_2578,&g_2578}},{{(void*)0,&g_2578},{&g_2578,(void*)0},{&g_2578,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{(void*)0,&g_2578},{&g_2578,&g_2578},{&g_2578,&g_2578},{(void*)0,&g_2578},{&g_2578,(void*)0}}};
static int64_t ** const **g_2576 = &g_2577[9][8][0];
static int64_t ** const **g_2581 = &g_2577[0][8][1];
static volatile int16_t g_2600 = 0x0B21L;/* VOLATILE GLOBAL g_2600 */
static volatile uint32_t g_2638 = 0UL;/* VOLATILE GLOBAL g_2638 */
static int32_t g_2641 = 0xBE237AD1L;
static int32_t * const  volatile g_2715 = &g_2641;/* VOLATILE GLOBAL g_2715 */
static volatile uint32_t g_2740 = 0UL;/* VOLATILE GLOBAL g_2740 */
static uint16_t g_2844 = 0UL;
static volatile int8_t g_2897 = (-1L);/* VOLATILE GLOBAL g_2897 */
static int64_t ***g_2943[1] = {&g_2578};
static int32_t g_2949 = (-7L);
static int32_t g_3031 = 2L;
static uint32_t * volatile ** volatile * volatile g_3046 = (void*)0;/* VOLATILE GLOBAL g_3046 */
static int32_t ** const ** const *g_3059 = (void*)0;
static uint32_t *g_3066[1][5][4] = {{{&g_887[1][2][0],&g_887[1][2][0],&g_887[1][2][0],&g_887[1][2][0]},{&g_887[3][2][0],&g_887[1][2][0],&g_887[1][2][0],&g_887[1][2][0]},{&g_887[1][2][0],&g_119,&g_887[1][2][0],&g_887[1][2][0]},{&g_887[3][2][0],&g_887[3][2][0],&g_887[1][2][0],&g_887[1][2][0]},{&g_887[1][2][0],&g_119,&g_887[1][2][0],&g_887[1][2][0]}}};
static uint32_t **g_3065 = &g_3066[0][1][3];
static uint64_t g_3275 = 8UL;
static int8_t g_3356 = 0xE8L;
static int32_t g_3388 = (-9L);
static uint16_t g_3390 = 0x8AB3L;
static int32_t g_3421 = 0x88A8227BL;
static uint32_t g_3653 = 0xDB08A8A9L;
static uint32_t g_3708[9][9][1] = {{{18446744073709551606UL},{0xEF65961FL},{0xADEB56AFL},{0UL},{0xADEB56AFL},{0xEF65961FL},{18446744073709551606UL},{7UL},{1UL}},{{7UL},{18446744073709551606UL},{0xEF65961FL},{0xADEB56AFL},{0UL},{0xADEB56AFL},{0xEF65961FL},{18446744073709551606UL},{7UL}},{{1UL},{7UL},{18446744073709551606UL},{0xEF65961FL},{0xADEB56AFL},{0UL},{0xADEB56AFL},{0xEF65961FL},{18446744073709551606UL}},{{7UL},{1UL},{7UL},{18446744073709551606UL},{0xEF65961FL},{0xADEB56AFL},{0UL},{0xADEB56AFL},{0xEF65961FL}},{{18446744073709551606UL},{7UL},{1UL},{7UL},{18446744073709551606UL},{0xEF65961FL},{0xADEB56AFL},{0UL},{0xADEB56AFL}},{{0xEF65961FL},{18446744073709551606UL},{7UL},{1UL},{7UL},{18446744073709551606UL},{0xEF65961FL},{0xADEB56AFL},{0UL}},{{0xADEB56AFL},{0xEF65961FL},{18446744073709551606UL},{7UL},{1UL},{7UL},{18446744073709551606UL},{0xEF65961FL},{0xADEB56AFL}},{{0UL},{0xADEB56AFL},{0xEF65961FL},{18446744073709551606UL},{7UL},{18446744073709551606UL},{0UL},{0x58CCE583L},{0x13F81BC2L}},{{1UL},{0xEF65961FL},{1UL},{0x13F81BC2L},{0x58CCE583L},{0UL},{18446744073709551606UL},{0UL},{0x58CCE583L}}};
static int32_t ***g_3789 = &g_1117;
static int32_t ****g_3788[6] = {&g_3789,&g_3789,&g_3789,&g_3789,&g_3789,&g_3789};
static int32_t ****g_3792[10] = {&g_3789,&g_3789,&g_3789,&g_3789,&g_3789,&g_3789,&g_3789,&g_3789,&g_3789,&g_3789};
static volatile int16_t g_3800 = 0x0F0AL;/* VOLATILE GLOBAL g_3800 */
static uint32_t *g_3838 = &g_3708[2][8][0];
static uint32_t **g_3837[1][6][1] = {{{&g_3838},{(void*)0},{(void*)0},{&g_3838},{(void*)0},{(void*)0}}};
static uint32_t ***g_3836[5] = {&g_3837[0][3][0],&g_3837[0][3][0],&g_3837[0][3][0],&g_3837[0][3][0],&g_3837[0][3][0]};
static uint64_t ***g_3869 = &g_248;
static uint64_t ****g_3868 = &g_3869;
static union U0 ** volatile g_3927[4][3] = {{&g_218,&g_218,&g_218},{&g_218,&g_218,&g_218},{&g_218,&g_218,&g_218},{&g_218,&g_218,&g_218}};
static volatile int32_t * volatile * volatile * volatile g_3989 = &g_2462;/* VOLATILE GLOBAL g_3989 */
static uint16_t g_4079 = 65529UL;
static const volatile uint8_t g_4140 = 248UL;/* VOLATILE GLOBAL g_4140 */
static int32_t * volatile g_4191 = &g_3388;/* VOLATILE GLOBAL g_4191 */
static volatile uint32_t g_4246 = 18446744073709551615UL;/* VOLATILE GLOBAL g_4246 */
static uint64_t *****g_4249 = (void*)0;
static int32_t ** volatile g_4350[4][10][3] = {{{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[5][0],(void*)0,&g_1158[4][1]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{(void*)0,&g_1158[0][1],(void*)0},{&g_1158[4][0],&g_1158[3][3],&g_1158[4][0]},{(void*)0,&g_1158[4][0],&g_1158[4][2]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[4][2],(void*)0,(void*)0},{&g_1158[1][3],&g_1158[5][1],&g_1158[4][0]},{&g_1158[2][3],&g_1158[4][0],&g_1158[4][1]}},{{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][3],&g_1158[5][1],(void*)0},{&g_1158[1][3],&g_1158[4][0],&g_1158[4][0]},{&g_1158[4][2],&g_1158[0][0],&g_1158[2][3]},{&g_1158[4][0],&g_1158[4][0],&g_1158[5][0]},{(void*)0,&g_1158[0][0],&g_1158[4][0]},{&g_1158[4][0],&g_1158[4][0],&g_1158[2][0]},{(void*)0,&g_1158[5][1],&g_1158[5][0]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[5][0],&g_1158[4][0],&g_1158[5][0]}},{{&g_1158[4][0],&g_1158[5][1],&g_1158[2][0]},{&g_1158[2][0],(void*)0,&g_1158[4][0]},{&g_1158[4][0],&g_1158[4][0],&g_1158[5][0]},{&g_1158[4][0],&g_1158[4][0],&g_1158[2][3]},{&g_1158[4][0],&g_1158[3][3],&g_1158[4][0]},{&g_1158[2][0],&g_1158[0][1],(void*)0},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[5][0],(void*)0,&g_1158[4][1]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{(void*)0,&g_1158[0][1],(void*)0}},{{&g_1158[4][0],&g_1158[3][3],&g_1158[4][0]},{(void*)0,&g_1158[4][0],&g_1158[4][2]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[4][2],(void*)0,(void*)0},{&g_1158[1][3],&g_1158[5][1],&g_1158[4][0]},{&g_1158[2][3],&g_1158[4][0],&g_1158[4][1]},{&g_1158[4][0],&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][3],&g_1158[5][1],(void*)0},{&g_1158[1][3],&g_1158[4][0],&g_1158[4][0]},{&g_1158[4][2],&g_1158[0][0],&g_1158[2][3]}}};
static int32_t ** volatile g_4365[1][4][1] = {{{&g_1158[4][0]},{&g_1158[4][0]},{&g_1158[4][0]},{&g_1158[4][0]}}};
static uint32_t g_4450 = 0UL;
static volatile int8_t g_4454[4][2] = {{(-8L),(-1L)},{(-1L),(-8L)},{(-1L),(-1L)},{(-8L),(-1L)}};
static int32_t ** volatile g_4480 = &g_1158[0][3];/* VOLATILE GLOBAL g_4480 */
static int32_t g_4571 = 1L;
static int64_t g_4572 = 0xBFDC8784B8DE718FLL;
static int64_t ***g_4600 = (void*)0;
static int64_t **** const g_4599 = &g_4600;
static int64_t **** const *g_4598[10] = {&g_4599,&g_4599,&g_4599,&g_4599,&g_4599,&g_4599,&g_4599,&g_4599,&g_4599,&g_4599};
static int32_t * volatile g_4618 = &g_6;/* VOLATILE GLOBAL g_4618 */
static int16_t g_4673 = 0xC7A8L;
static const int32_t g_4692[2] = {1L,1L};
static volatile uint64_t g_4782 = 18446744073709551615UL;/* VOLATILE GLOBAL g_4782 */
static int32_t * volatile g_4802 = &g_122;/* VOLATILE GLOBAL g_4802 */
static int32_t ** volatile g_4987 = &g_1158[4][0];/* VOLATILE GLOBAL g_4987 */
static int32_t g_5016 = 2L;
static volatile int32_t g_5046 = (-1L);/* VOLATILE GLOBAL g_5046 */
static volatile int16_t *g_5112 = &g_2600;
static volatile int16_t * const *g_5111[2][10] = {{&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112},{&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112,&g_5112}};
static volatile int16_t * const * volatile *g_5110 = &g_5111[0][8];
static volatile int16_t * const * volatile * volatile *g_5109 = &g_5110;
static volatile int16_t * const * volatile * volatile **g_5108 = &g_5109;
static uint64_t g_5196 = 0xE125607CF9219A18LL;
static volatile int8_t g_5205 = 0x31L;/* VOLATILE GLOBAL g_5205 */
static int8_t g_5257 = 8L;
static const int32_t ** volatile g_5295 = &g_632;/* VOLATILE GLOBAL g_5295 */
static uint32_t g_5360 = 3UL;
static uint32_t ****g_5427 = &g_3836[2];
static uint32_t *****g_5426 = &g_5427;
static int32_t ***g_5438 = &g_1157[0];
static int32_t ****g_5437[1] = {&g_5438};
static int32_t **** const *g_5436 = &g_5437[0];
static int16_t g_5479 = 0x82A4L;
static const volatile int32_t g_5506 = (-8L);/* VOLATILE GLOBAL g_5506 */
static const uint16_t * volatile *g_5510 = (void*)0;
static const int32_t *g_5527 = (void*)0;
static const int32_t **g_5526 = &g_5527;
static const int32_t ** const *g_5525 = &g_5526;
static uint16_t g_5543 = 0x8E37L;
static const int16_t g_5599 = 0x78D8L;
static uint64_t *g_5785 = &g_1971;
static union U0 g_5821[4][9][2] = {{{{0x47DF2C0C4F13D84ALL},{9L}},{{3L},{3L}},{{0x3767BDDE1D1DE639LL},{-1L}},{{0x47DF2C0C4F13D84ALL},{-6L}},{{-1L},{0xAEB1026056D9A686LL}},{{0xF5158CEB7B366AADLL},{-1L}},{{3L},{0x3767BDDE1D1DE639LL}},{{3L},{-1L}},{{0xF5158CEB7B366AADLL},{0xAEB1026056D9A686LL}}},{{{-1L},{-6L}},{{0x47DF2C0C4F13D84ALL},{-1L}},{{0x3767BDDE1D1DE639LL},{3L}},{{3L},{9L}},{{0x47DF2C0C4F13D84ALL},{0xAEB1026056D9A686LL}},{{9L},{0xAEB1026056D9A686LL}},{{0x47DF2C0C4F13D84ALL},{9L}},{{3L},{3L}},{{0x3767BDDE1D1DE639LL},{-1L}}},{{{0x47DF2C0C4F13D84ALL},{-6L}},{{-1L},{0xAEB1026056D9A686LL}},{{0xF5158CEB7B366AADLL},{-1L}},{{3L},{0x3767BDDE1D1DE639LL}},{{3L},{-1L}},{{0xF5158CEB7B366AADLL},{0xAEB1026056D9A686LL}},{{-1L},{-6L}},{{0x47DF2C0C4F13D84ALL},{-1L}},{{0x3767BDDE1D1DE639LL},{3L}}},{{{3L},{9L}},{{0x47DF2C0C4F13D84ALL},{0xAEB1026056D9A686LL}},{{9L},{0xAEB1026056D9A686LL}},{{0x47DF2C0C4F13D84ALL},{9L}},{{3L},{3L}},{{0x3767BDDE1D1DE639LL},{-1L}},{{0x47DF2C0C4F13D84ALL},{-6L}},{{-1L},{0xAEB1026056D9A686LL}},{{0xF5158CEB7B366AADLL},{-1L}}}};
static uint32_t g_5837 = 0x8D2E0575L;
static const int32_t ** volatile g_5853 = (void*)0;/* VOLATILE GLOBAL g_5853 */
static uint64_t g_5862[1] = {0UL};
static const int32_t g_5866 = 0x98530B43L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(uint8_t  p_3, uint64_t  p_4, uint8_t  p_5);
static uint64_t  func_7(uint32_t  p_8, int8_t  p_9, uint8_t  p_10, uint64_t  p_11, uint32_t  p_12);
static uint16_t  func_16(const uint8_t  p_17, uint8_t  p_18, int8_t  p_19);
static int8_t  func_22(uint32_t  p_23, int32_t  p_24, union U0  p_25, int16_t  p_26);
static uint64_t  func_29(int16_t  p_30);
static uint64_t  func_35(union U0 * p_36);
static uint16_t  func_50(int32_t  p_51, uint64_t  p_52);
static int8_t  func_55(union U0  p_56, uint64_t  p_57, union U0 * p_58, int8_t * p_59);
static uint64_t  func_60(union U0 * p_61, union U0 * p_62);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_28 g_65 g_585 g_197 g_122 g_248 g_249 g_82 g_424 g_425 g_213 g_296 g_121 g_267 g_179 g_436 g_101 g_102 g_622 g_143 g_631 g_506 g_233 g_234 g_235 g_513 g_91 g_268 g_335 g_186 g_632 g_521 g_522 g_202 g_600 g_28.f0 g_887 g_888 g_201 g_119 g_1010 g_217 g_218 g_1038 g_811.f0 g_1011 g_635 g_1016 g_1017 g_1095 g_890 g_889 g_1878 g_1879 g_1971 g_2037 g_2007 g_2008 g_2009 g_1096 g_1097 g_2082 g_2010 g_1808 g_241 g_2081 g_2032 g_2202 g_1300 g_2329 g_2345 g_2368 g_2431 g_2460 g_2492 g_2495 g_194 g_195 g_2499 g_1931 g_2576 g_2578 g_2579 g_1015 g_2462 g_2638 g_2715 g_2740 g_2844 g_2461 g_3031 g_3046 g_2581 g_2577 g_2541 g_3275 g_1353.f0 g_3388 g_3390 g_1844 g_3653 g_3708 g_3788 g_3356 g_103.f0 g_3836 g_1157 g_3869 g_2641 g_3989 g_3838 g_4079 g_4140 g_4191 g_1845 g_4246 g_3800 g_3421 g_4450 g_4480 g_4571 g_4572 g_4618 g_503 g_2027 g_2028 g_4782 g_4802 g_2949 g_4987 g_5016 g_3789 g_5108 g_5112 g_2600 g_5426 g_5436 g_5479 g_5506 g_5510 g_5196 g_5525 g_5543 g_5427 g_4673 g_5599 g_5437 g_5837 g_5438 g_5862
 * writes: g_65 g_291 g_296 g_600 g_122 g_121 g_267 g_179 g_248 g_436 g_197 g_102 g_632 g_506 g_91 g_82 g_119 g_213 g_202 g_635 g_887 g_201 g_1011 g_1014 g_1041 g_811.f0 g_1752 g_1808 g_1929 g_1117 g_1971 g_1484 g_1879 g_1158 g_2009 g_2032 g_2202 g_28.f0 g_2345 g_218 g_2431 g_1931 g_2541 g_2576 g_2581 g_235 g_2638 g_2010 g_2844 g_2943 g_28 g_3059 g_3065 g_3275 g_424 g_3390 g_1845 g_3708 g_3788 g_3792 g_3836 g_3868 g_2949 g_2641 g_1157 g_4079 g_3388 g_4249 g_3356 g_3421 g_4450 g_3031 g_3869 g_4598 g_6 g_4782 g_5016 g_4246 g_103.f0 g_4350 g_2008 g_5436 g_5196 g_4673 g_5785 g_5821 g_5862
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_15 = (-4L);
    uint8_t l_27 = 0x90L;
    uint16_t l_31 = 7UL;
    int32_t l_2287 = 0L;
    int32_t l_2288 = (-1L);
    uint32_t *l_3930[1];
    int32_t l_3931[7] = {0L,0L,0L,0L,0L,0L,0L};
    uint64_t l_3932 = 0x542EC87514E27B7ALL;
    int32_t *l_5014 = &g_3421;
    int32_t *l_5015[8][4][6] = {{{&g_4571,&g_5016,&g_4571,&g_4571,&g_5016,&g_5016},{&g_5016,&g_4571,&g_4571,&g_4571,&g_4571,&g_5016},{&g_4571,&g_4571,&g_5016,&g_5016,&g_4571,&g_4571},{(void*)0,&g_4571,&g_4571,(void*)0,&g_5016,(void*)0}},{{&g_4571,&g_5016,&g_4571,(void*)0,&g_5016,(void*)0},{&g_4571,&g_4571,&g_5016,&g_5016,&g_4571,&g_4571},{&g_4571,&g_5016,(void*)0,&g_5016,&g_4571,(void*)0},{&g_4571,(void*)0,&g_5016,(void*)0,&g_5016,&g_4571}},{{&g_4571,&g_4571,&g_4571,(void*)0,&g_4571,&g_4571},{(void*)0,&g_5016,&g_4571,&g_5016,&g_5016,&g_4571},{&g_4571,&g_5016,&g_4571,&g_4571,&g_4571,&g_4571},{&g_5016,&g_4571,&g_4571,&g_4571,&g_4571,&g_4571}},{{&g_4571,&g_4571,&g_5016,&g_4571,(void*)0,(void*)0},{&g_5016,&g_4571,(void*)0,(void*)0,&g_4571,&g_4571},{&g_5016,(void*)0,(void*)0,(void*)0,&g_5016,(void*)0},{&g_4571,&g_4571,(void*)0,&g_4571,&g_4571,&g_4571}},{{&g_4571,&g_5016,&g_5016,(void*)0,(void*)0,&g_5016},{&g_4571,(void*)0,&g_4571,&g_4571,&g_5016,&g_5016},{&g_4571,&g_5016,&g_4571,(void*)0,&g_4571,&g_4571},{&g_4571,&g_4571,&g_5016,&g_4571,&g_4571,&g_4571}},{{&g_4571,(void*)0,&g_5016,(void*)0,&g_4571,&g_4571},{&g_5016,&g_4571,&g_5016,(void*)0,&g_5016,&g_4571},{&g_4571,&g_4571,&g_5016,&g_5016,&g_4571,&g_4571},{&g_5016,&g_4571,&g_5016,&g_4571,&g_4571,&g_4571}},{{&g_5016,&g_5016,&g_4571,&g_5016,&g_4571,&g_5016},{&g_5016,&g_5016,&g_4571,&g_4571,&g_4571,&g_5016},{&g_4571,&g_5016,&g_5016,&g_4571,&g_4571,&g_4571},{(void*)0,&g_4571,(void*)0,&g_4571,&g_4571,(void*)0}},{{&g_4571,&g_4571,(void*)0,(void*)0,&g_5016,&g_5016},{&g_4571,&g_4571,&g_4571,(void*)0,&g_4571,&g_4571},{&g_4571,(void*)0,&g_4571,&g_4571,&g_4571,&g_5016},{(void*)0,&g_4571,&g_4571,&g_4571,&g_4571,&g_4571}}};
    uint32_t l_5017 = 4294967292UL;
    union U0 l_5027 = {0L};
    int64_t l_5029[2];
    uint16_t l_5036 = 0x7F7AL;
    uint8_t l_5037[6] = {0x15L,0x15L,0UL,0x15L,0x15L,0UL};
    int32_t *l_5039 = &g_2949;
    int32_t **l_5038 = &l_5039;
    uint64_t l_5062 = 0xC81D9C0EE19A1363LL;
    union U0 ***l_5101 = (void*)0;
    int32_t l_5119 = 0xC5A09B00L;
    int16_t l_5121 = 0x4B1AL;
    const int32_t l_5199 = (-9L);
    uint16_t l_5201 = 5UL;
    const uint64_t l_5228 = 0x0BAC85DA78A547D6LL;
    const int8_t l_5284 = (-1L);
    uint64_t l_5299 = 4UL;
    uint8_t **l_5306[10][8] = {{&g_2010,&g_2010,&g_2010,(void*)0,(void*)0,&g_2010,&g_2010,&g_2010},{(void*)0,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010},{(void*)0,&g_2010,(void*)0,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,(void*)0,(void*)0,&g_2010,&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010},{(void*)0,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010},{(void*)0,&g_2010,&g_2010,(void*)0,(void*)0,&g_2010,&g_2010,&g_2010},{&g_2010,(void*)0,&g_2010,&g_2010,&g_2010,(void*)0,&g_2010,&g_2010},{&g_2010,(void*)0,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,(void*)0,(void*)0,&g_2010,&g_2010,(void*)0,&g_2010}};
    uint8_t ***l_5305 = &l_5306[8][5];
    uint16_t l_5376 = 1UL;
    union U0 l_5385 = {-1L};
    uint32_t **l_5401 = (void*)0;
    int32_t l_5403 = 0x31640077L;
    int16_t l_5409 = (-1L);
    int32_t l_5410[9][4] = {{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L},{0x86CC1590L,0xDBC97CF9L,0x86CC1590L,0xDBC97CF9L}};
    int32_t l_5411 = 1L;
    uint32_t *****l_5428 = &g_5427;
    uint16_t **l_5433[2];
    int32_t *****l_5442[4];
    uint8_t l_5457 = 252UL;
    uint32_t l_5533 = 0x6AA427EFL;
    uint8_t **l_5593 = &g_2010;
    uint8_t *** const l_5592 = &l_5593;
    uint8_t *** const *l_5591 = &l_5592;
    uint8_t *** const **l_5590 = &l_5591;
    uint64_t l_5595 = 6UL;
    uint32_t l_5603 = 1UL;
    uint32_t l_5682[4][9] = {{4294967286UL,0UL,4294967295UL,0x394C0D78L,6UL,4294967286UL,0x394C0D78L,0UL,0x394C0D78L},{0x394C0D78L,6UL,4294967295UL,4294967295UL,6UL,0x394C0D78L,0x1A46B593L,0UL,4294967295UL},{4294967286UL,6UL,0x394C0D78L,4294967295UL,0UL,4294967286UL,4294967286UL,0UL,4294967295UL},{1UL,6UL,1UL,0x394C0D78L,0UL,1UL,0x1A46B593L,0x81944F97L,0x394C0D78L}};
    uint32_t l_5683[7][6][6] = {{{0xFEA3202BL,0UL,0x70D78A0AL,1UL,0x9B8AE9CFL,18446744073709551609UL},{0xFEA3202BL,0x01378CA1L,1UL,0xF15D1677L,0x70D78A0AL,0x7E7418ACL},{0xF4B6423EL,0x41948100L,0x9E2668ADL,0x5E5A1237L,0x9E2668ADL,0x41948100L},{0UL,0xF4A8B273L,0UL,0xD39F1380L,0UL,0UL},{0x6356316DL,0xF15D1677L,18446744073709551615UL,0x70D78A0AL,0x41948100L,0xDB71ACE9L},{18446744073709551609UL,0xF15D1677L,0x43DFC6A3L,1UL,0UL,0x68A4DB48L}},{{0x7E7418ACL,0xF4A8B273L,1UL,0x9E2668ADL,0x9E2668ADL,1UL},{0x41948100L,0x41948100L,0UL,0UL,0x70D78A0AL,18446744073709551610UL},{0UL,0x01378CA1L,0x855BBCD3L,18446744073709551615UL,0x9B8AE9CFL,0UL},{0xDB71ACE9L,0UL,0x855BBCD3L,0x43DFC6A3L,0x41948100L,18446744073709551610UL},{0x68A4DB48L,0x43DFC6A3L,0UL,1UL,0xFAC86802L,1UL},{1UL,0xFAC86802L,1UL,0UL,0x43DFC6A3L,0x68A4DB48L}},{{18446744073709551610UL,0x41948100L,0x43DFC6A3L,0x855BBCD3L,0UL,0xDB71ACE9L},{0UL,0x9B8AE9CFL,18446744073709551615UL,0x855BBCD3L,0x01378CA1L,0UL},{18446744073709551610UL,0x70D78A0AL,0UL,0UL,0x41948100L,0x41948100L},{1UL,0x9E2668ADL,0x9E2668ADL,1UL,0xF4A8B273L,0x7E7418ACL},{0x68A4DB48L,0UL,1UL,0x43DFC6A3L,0xF15D1677L,18446744073709551609UL},{0xDB71ACE9L,0x41948100L,0x70D78A0AL,18446744073709551615UL,0xF15D1677L,0x6356316DL}},{{0UL,0UL,0xD39F1380L,0UL,0xF4A8B273L,0UL},{0x41948100L,1UL,0xFAC86802L,1UL,0UL,0x43DFC6A3L},{0xD39F1380L,0x68A4DB48L,0xFEA3202BL,18446744073709551615UL,0x6356316DL,0x5E5A1237L},{0UL,0xDB71ACE9L,18446744073709551615UL,0x68A4DB48L,18446744073709551609UL,0x5E5A1237L},{0x70D78A0AL,0UL,0xFEA3202BL,0x9B8AE9CFL,0x7E7418ACL,0x43DFC6A3L},{18446744073709551609UL,0x41948100L,0xFAC86802L,0xFAC86802L,0x41948100L,18446744073709551609UL}},{{0x43DFC6A3L,0x7E7418ACL,0x9B8AE9CFL,0xFEA3202BL,0UL,0x70D78A0AL},{0x5E5A1237L,18446744073709551609UL,0x68A4DB48L,18446744073709551615UL,0xDB71ACE9L,0UL},{0x5E5A1237L,0x6356316DL,18446744073709551615UL,0xFEA3202BL,0x68A4DB48L,0xD39F1380L},{0x43DFC6A3L,0UL,1UL,0xFAC86802L,1UL,0UL},{18446744073709551609UL,0xF4B6423EL,0x01378CA1L,0x9B8AE9CFL,18446744073709551610UL,18446744073709551609UL},{0x70D78A0AL,0xFEA3202BL,0xF4A8B273L,0x68A4DB48L,0UL,0xF15D1677L}},{{0UL,0xFEA3202BL,0x7E7418ACL,18446744073709551615UL,18446744073709551610UL,0x855BBCD3L},{0xD39F1380L,0xF4B6423EL,18446744073709551615UL,1UL,1UL,18446744073709551615UL},{0UL,0UL,18446744073709551609UL,0x01378CA1L,0x68A4DB48L,0x9E2668ADL},{18446744073709551609UL,0x6356316DL,0UL,0xF4A8B273L,0xDB71ACE9L,18446744073709551609UL},{0xF15D1677L,18446744073709551609UL,0UL,0x7E7418ACL,0UL,0x9E2668ADL},{0x855BBCD3L,0x7E7418ACL,18446744073709551609UL,18446744073709551615UL,0x41948100L,18446744073709551615UL}},{{18446744073709551615UL,0x41948100L,18446744073709551615UL,18446744073709551609UL,0x7E7418ACL,0x855BBCD3L},{0x9E2668ADL,0UL,0x7E7418ACL,0UL,18446744073709551609UL,0xF15D1677L},{18446744073709551609UL,0xDB71ACE9L,0xF4A8B273L,0UL,0x6356316DL,18446744073709551609UL},{0x9E2668ADL,0x68A4DB48L,0x01378CA1L,18446744073709551609UL,0UL,0UL},{18446744073709551615UL,1UL,1UL,18446744073709551615UL,0xF4B6423EL,0xD39F1380L},{0x855BBCD3L,18446744073709551610UL,18446744073709551615UL,0x7E7418ACL,0xFEA3202BL,0UL}}};
    int32_t l_5714 = 8L;
    int64_t l_5742 = 0x8C72A882CA807390LL;
    int64_t l_5756[1];
    int64_t l_5759[6] = {0L,0xDE8B3022E21FC85DLL,0L,0L,0xDE8B3022E21FC85DLL,0L};
    int16_t l_5760 = (-10L);
    int32_t l_5761 = (-1L);
    uint8_t l_5786[9][1][4];
    int32_t l_5787[8][2] = {{0L,(-1L)},{(-1L),0L},{(-1L),(-1L)},{0L,(-1L)},{(-1L),0L},{(-1L),(-1L)},{0L,(-1L)},{(-1L),0L}};
    uint8_t l_5788 = 0x9CL;
    int32_t l_5789 = 0x63957133L;
    int32_t l_5790 = 0x587DCA13L;
    int64_t l_5791[7] = {0x68A0233D028E64DELL,0x68A0233D028E64DELL,1L,0x68A0233D028E64DELL,0x68A0233D028E64DELL,1L,0x68A0233D028E64DELL};
    uint32_t l_5801 = 0UL;
    int64_t ****l_5840 = (void*)0;
    int32_t l_5877 = 0x2C5E2F27L;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_3930[i] = &g_887[1][2][0];
    for (i = 0; i < 2; i++)
        l_5029[i] = 2L;
    for (i = 0; i < 2; i++)
        l_5433[i] = (void*)0;
    for (i = 0; i < 4; i++)
        l_5442[i] = &g_5437[0];
    for (i = 0; i < 1; i++)
        l_5756[i] = (-1L);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
                l_5786[i][j][k] = 0xDEL;
        }
    }
    g_5016 &= ((*l_5014) = func_2(g_6, func_7((l_3931[2] = (((safe_mod_func_int8_t_s_s(g_6, l_15)) , ((func_16((safe_sub_func_int8_t_s_s(func_22(l_15, l_27, g_28, (l_2288 = (l_2287 |= ((l_15 , (func_29((l_15 <= ((((l_27 & (-9L)) , l_15) ^ l_31) == l_27))) , (*g_513))) , (-1L))))), 0xA5L)), (*g_1016), l_31) || 0xB777L) ^ l_31)) , 4294967288UL)), l_15, l_31, l_31, l_3932), g_4572));
    if (l_5017)
    { /* block id: 2343 */
        int16_t l_5018 = 0x23BDL;
        int16_t l_5042 = 6L;
        int32_t l_5047 = 0xB9EDA4C7L;
        int32_t l_5048 = (-1L);
        int32_t l_5057 = (-10L);
        uint32_t ***l_5106 = &g_3837[0][3][0];
        uint32_t ****l_5107 = &g_3836[3];
        int64_t l_5113 = 0x1C55D6B586FFF4A7LL;
        uint8_t l_5114 = 0UL;
        if ((l_5018 >= ((safe_sub_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((((safe_sub_func_uint16_t_u_u((((*g_1878) = ((safe_div_func_uint32_t_u_u(((((((l_5027 , (((+l_5029[0]) > ((-1L) && l_5018)) && (*g_1878))) | (safe_rshift_func_int16_t_s_u((*l_5014), (safe_add_func_int16_t_s_s(((safe_sub_func_uint16_t_u_u(g_3390, (*g_513))) , l_5036), (*l_5014)))))) > (*l_5014)) , 1L) && (*g_1878)) , 5UL), 4294967292UL)) | 0x692BL)) || (*g_1016)), (*g_513))) <= (*l_5014)) , l_5037[2]) != l_5018), (*l_5014))), l_5018)) ^ l_5018)))
        { /* block id: 2345 */
            uint8_t l_5049 = 0xB7L;
            uint16_t *l_5052 = &g_267;
            uint16_t *l_5063 = &g_179;
            const int64_t l_5074 = 0xD7C56D3A244A3B95LL;
            int64_t l_5075[9][8] = {{(-10L),(-8L),0xE8508E3810CC44BBLL,0x0303C3958545F89ALL,0x0303C3958545F89ALL,0xE8508E3810CC44BBLL,(-8L),(-10L)},{0xA26D27BC9AC03130LL,0xBEAB4FEB7D9A17D1LL,0x58F020CC8228DBC6LL,0x5B23CE4F931DD338LL,0L,(-9L),0xA823EED9D51CC8A2LL,0xAD56C19AEFB42F12LL},{(-9L),1L,0x9538D9B606BEDE21LL,0x9C523DC72D0178F8LL,0x5B23CE4F931DD338LL,(-9L),1L,0xBEAB4FEB7D9A17D1LL},{7L,0xC236C195AEB1EE19LL,(-10L),0xAD56C19AEFB42F12LL,(-1L),7L,0x0491B04AE25FB4A2LL,0xE8508E3810CC44BBLL},{0xC236C195AEB1EE19LL,1L,(-1L),(-8L),(-5L),0xE8508E3810CC44BBLL,(-5L),(-8L)},{4L,(-5L),4L,0x0491B04AE25FB4A2LL,(-10L),0x58F020CC8228DBC6LL,1L,4L},{0xC2CEF86361B2584ALL,0x99427AD66E1CA041LL,0x5664A8B289D3C71BLL,0xE8508E3810CC44BBLL,0xBEAB4FEB7D9A17D1LL,0x9538D9B606BEDE21LL,(-10L),0x0D972AC35C871FD4LL},{0xC2CEF86361B2584ALL,0x5B23CE4F931DD338LL,0x0491B04AE25FB4A2LL,0x5664A8B289D3C71BLL,(-10L),0x0303C3958545F89ALL,0x5B23CE4F931DD338LL,0x99427AD66E1CA041LL},{4L,0xC236C195AEB1EE19LL,0x99427AD66E1CA041LL,0x9C523DC72D0178F8LL,(-5L),0xAD56C19AEFB42F12LL,7L,7L}};
            int i, j;
            (*g_3789) = l_5038;
            for (g_436 = 0; (g_436 >= 10); g_436 = safe_add_func_uint8_t_u_u(g_436, 9))
            { /* block id: 2349 */
                uint8_t l_5045 = 0x3FL;
                (*g_4802) = ((*l_5014) = (l_5042 <= (*g_4618)));
                for (l_2288 = 0; (l_2288 != 12); l_2288 = safe_add_func_int64_t_s_s(l_2288, 6))
                { /* block id: 2354 */
                    return l_5045;
                }
                for (g_3275 = 0; g_3275 < 4; g_3275 += 1)
                {
                    for (g_4246 = 0; g_4246 < 10; g_4246 += 1)
                    {
                        for (g_103.f0 = 0; g_103.f0 < 3; g_103.f0 += 1)
                        {
                            g_4350[g_3275][g_4246][g_103.f0] = &l_5015[5][1][5];
                        }
                    }
                }
                (*l_5014) = 1L;
            }
            l_5049--;
            (*l_5014) = ((((*l_5052) = 0UL) == (safe_lshift_func_int32_t_s_u((l_5049 ^ 0x7BL), (safe_add_func_int8_t_s_s((l_5048 &= l_5057), (safe_mod_func_int16_t_s_s(((safe_sub_func_uint8_t_u_u((l_5047 , l_5062), ((((*l_5063)++) , (*g_1878)) > (safe_add_func_int8_t_s_s((safe_add_func_uint64_t_u_u((safe_rshift_func_int16_t_s_u((-8L), (safe_mod_func_uint16_t_u_u(0x8FDDL, 1L)))), l_5074)), l_5075[8][4]))))) , (*g_513)), (*g_513)))))))) , (*g_4618));
        }
        else
        { /* block id: 2365 */
            int32_t l_5080[3];
            int32_t *l_5081 = &l_5047;
            int64_t *l_5090 = &g_28.f0;
            int16_t *l_5091 = &g_1808;
            int32_t l_5092 = 1L;
            int i;
            for (i = 0; i < 3; i++)
                l_5080[i] = (-1L);
            l_5092 &= ((safe_mul_func_int64_t_s_s((((((*l_5091) = ((*g_513) = (((safe_sub_func_int32_t_s_s(((-1L) || ((l_5080[0] , l_5081) == &l_2287)), 0x0B56EDBCL)) && (safe_div_func_int16_t_s_s(((*l_5014) == (safe_div_func_int8_t_s_s((safe_sub_func_int64_t_s_s(((safe_add_func_int64_t_s_s(((*g_2579) = (*g_521)), ((*l_5090) ^= ((*l_5081) ^= l_5057)))) , (**g_2578)), l_5080[0])), (*g_1878)))), l_5018))) >= (*l_5014)))) , (**g_2009)) != 1L) , (*l_5081)), (*l_5014))) , l_5048);
        }
        l_5057 ^= (safe_sub_func_int32_t_s_s((((safe_div_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((((safe_sub_func_uint32_t_u_u(((((void*)0 == l_5101) & (l_5113 = ((**g_2578) = (l_5048 < (safe_rshift_func_uint16_t_u_s((safe_add_func_uint64_t_u_u(l_5018, ((((*l_5107) = l_5106) == &g_3837[0][5][0]) || ((l_5018 > (((((void*)0 == g_5108) == l_5047) | l_5018) , l_5048)) == 0x2FL)))), (*g_5112))))))) & 0xAEL), 0x92C99F8AL)) , l_5027) , (*l_5014)), 0xED53L)), 0x56C34CE4L)) & l_5047) < 1L), l_5114));
    }
    else
    { /* block id: 2377 */
        int16_t l_5115 = 0x3D8CL;
        int32_t l_5116 = 0L;
        int32_t l_5117 = 0x9FBFACA0L;
        int32_t l_5118[7][6] = {{(-8L),0x16C38E5EL,2L,0L,0x16C38E5EL,(-5L)},{1L,(-5L),2L,(-8L),0xCDE34CCFL,0xCDE34CCFL},{5L,(-5L),(-5L),5L,0x16C38E5EL,(-10L)},{5L,0x16C38E5EL,(-10L),(-8L),(-5L),(-10L)},{1L,0xCDE34CCFL,(-5L),0L,(-5L),0xCDE34CCFL},{(-8L),0x16C38E5EL,2L,0L,0x16C38E5EL,(-5L)},{1L,(-5L),2L,(-8L),0xCDE34CCFL,0xCDE34CCFL}};
        int64_t l_5120[7][2][7] = {{{0xB6123FB0B764070FLL,0x6D2CF164445C3189LL,0x6D2CF164445C3189LL,0xB6123FB0B764070FLL,0L,0xB6123FB0B764070FLL,0x6D2CF164445C3189LL},{0xD0DD75AE88133A65LL,(-1L),7L,7L,7L,(-1L),0xD0DD75AE88133A65LL}},{{0xCCF96464CB1EBBDCLL,0x6D2CF164445C3189LL,4L,0x6D2CF164445C3189LL,0xCCF96464CB1EBBDCLL,0xCCF96464CB1EBBDCLL,0x6D2CF164445C3189LL},{0x751740A21142CDEFLL,0x3629B815D500481CLL,0x751740A21142CDEFLL,0x8A07764E83FFA652LL,7L,0xD20FCE6D0768C31FLL,1L}},{{0x6D2CF164445C3189LL,0L,4L,4L,0L,0x6D2CF164445C3189LL,0L},{0x751740A21142CDEFLL,0x8A07764E83FFA652LL,7L,0xD20FCE6D0768C31FLL,1L,0xD20FCE6D0768C31FLL,7L}},{{0xCCF96464CB1EBBDCLL,0xCCF96464CB1EBBDCLL,0x6D2CF164445C3189LL,4L,0x6D2CF164445C3189LL,0xCCF96464CB1EBBDCLL,0xCCF96464CB1EBBDCLL},{0xD0DD75AE88133A65LL,0x8A07764E83FFA652LL,0L,0x8A07764E83FFA652LL,0xD0DD75AE88133A65LL,(-1L),7L}},{{0xB6123FB0B764070FLL,0L,0xB6123FB0B764070FLL,0x6D2CF164445C3189LL,0x6D2CF164445C3189LL,0xB6123FB0B764070FLL,0L},{7L,0x3629B815D500481CLL,0L,7L,1L,0x8A07764E83FFA652LL,1L}},{{0xB6123FB0B764070FLL,0x6D2CF164445C3189LL,0x6D2CF164445C3189LL,0xB6123FB0B764070FLL,0L,0xB6123FB0B764070FLL,0x6D2CF164445C3189LL},{0xD0DD75AE88133A65LL,(-1L),7L,7L,7L,(-1L),0xD0DD75AE88133A65LL}},{{0xCCF96464CB1EBBDCLL,0x6D2CF164445C3189LL,4L,0x6D2CF164445C3189LL,0xCCF96464CB1EBBDCLL,0xCCF96464CB1EBBDCLL,0x6D2CF164445C3189LL},{0x751740A21142CDEFLL,0x3629B815D500481CLL,0x751740A21142CDEFLL,0x8A07764E83FFA652LL,7L,0xD20FCE6D0768C31FLL,1L}}};
        uint16_t l_5122 = 0x051FL;
        uint16_t * const l_5125 = &g_267;
        int32_t *** const *l_5135 = (void*)0;
        int32_t *** const * const *l_5134 = &l_5135;
        uint16_t l_5171 = 0x2E06L;
        uint64_t l_5198 = 18446744073709551613UL;
        uint8_t l_5208[8] = {0x6FL,0x6FL,0x6FL,0x6FL,0x6FL,0x6FL,0x6FL,0x6FL};
        union U0 l_5227 = {0x26B9DB40B81AAB66LL};
        int64_t ****l_5235 = &g_2943[0];
        uint64_t ***l_5256 = (void*)0;
        int8_t l_5271[6][9][4] = {{{0xD9L,0x92L,0x92L,0xD9L},{0xD9L,5L,0x80L,(-1L)},{0x91L,(-1L),1L,0x78L},{0xCCL,(-1L),(-1L),0x78L},{0x21L,(-1L),0x56L,(-1L)},{6L,5L,(-1L),0xD9L},{(-1L),0x92L,(-1L),0xCCL},{6L,(-5L),0x56L,0xF3L},{0x21L,0x56L,(-1L),0x91L}},{{0xCCL,0x56L,1L,0xF3L},{0x91L,(-5L),0x80L,0xCCL},{0xD9L,0x92L,0x92L,0xD9L},{0xD9L,5L,0x80L,(-1L)},{0x91L,(-1L),1L,0x78L},{0xCCL,(-1L),(-1L),0x78L},{0x21L,(-1L),0x56L,(-1L)},{6L,5L,(-1L),0xD9L},{(-1L),0x92L,(-1L),0xCCL}},{{6L,(-5L),0x56L,0xF3L},{0x21L,0x56L,(-1L),0x91L},{0xCCL,0x56L,1L,0xF3L},{0x91L,(-5L),0x80L,0xCCL},{0xD9L,0x92L,0x92L,0xD9L},{0xD9L,5L,0x80L,(-1L)},{0x91L,(-1L),1L,0x78L},{0xCCL,(-1L),(-1L),0x78L},{0x21L,(-1L),0x56L,(-1L)}},{{6L,5L,(-1L),0xD9L},{(-1L),0x92L,(-1L),0xCCL},{6L,(-5L),0x56L,0xF3L},{0x21L,0x56L,(-1L),0x91L},{0xCCL,0x56L,1L,0xF3L},{0x91L,(-5L),0x80L,0xCCL},{0xD9L,0x92L,0x92L,0xD9L},{0xD9L,5L,0x80L,(-1L)},{0x91L,(-1L),1L,0x78L}},{{0xCCL,(-1L),(-1L),0x78L},{0x21L,(-1L),0x56L,(-1L)},{6L,5L,(-1L),0xD9L},{(-1L),0x92L,(-1L),0xCCL},{6L,(-5L),0x56L,0xF3L},{0x21L,0x56L,(-1L),0x91L},{0xCCL,0x56L,1L,0xF3L},{0x91L,(-5L),0x80L,0xCCL},{0xD9L,0x92L,0x92L,0xD9L}},{{0xD9L,5L,0x80L,(-1L)},{0x91L,(-1L),0x80L,0x91L},{0xF3L,0x65L,5L,0x91L},{6L,0x92L,(-1L),(-9L)},{0xCCL,(-1L),0x92L,(-1L)},{0x78L,(-1L),0x92L,0xF3L},{0xCCL,1L,(-1L),0xD9L},{6L,(-1L),5L,(-1L)},{0xF3L,(-1L),0x80L,0xD9L}}};
        int32_t *** const *l_5368 = &g_3789;
        int64_t l_5404 = (-1L);
        uint32_t l_5407 = 2UL;
        uint64_t l_5408 = 18446744073709551610UL;
        const uint16_t l_5432 = 0xD49BL;
        int32_t l_5443 = 0x9F7031DBL;
        const uint32_t *l_5448 = &g_887[4][2][0];
        uint32_t l_5453 = 0x20459559L;
        uint32_t l_5454 = 0xA5E9DC27L;
        int32_t l_5570 = (-4L);
        uint16_t l_5632 = 0x20FBL;
        int16_t l_5648 = 0x9D69L;
        union U0 ***l_5658 = &g_291[2];
        uint32_t l_5681[2][6];
        uint16_t l_5684[7][7][1] = {{{0x85DEL},{0x33A4L},{2UL},{1UL},{1UL},{0xE0DCL},{0x85DEL}},{{0xE0DCL},{1UL},{1UL},{2UL},{0x33A4L},{0x85DEL},{0x686BL}},{{65535UL},{1UL},{65535UL},{0x686BL},{0x85DEL},{0x33A4L},{2UL}},{{1UL},{1UL},{0xE0DCL},{0x85DEL},{0xE0DCL},{1UL},{1UL}},{{2UL},{0x33A4L},{0x85DEL},{0x686BL},{65535UL},{1UL},{65535UL}},{{0x686BL},{0x85DEL},{0x33A4L},{2UL},{1UL},{1UL},{0xE0DCL}},{{0x85DEL},{0xE0DCL},{1UL},{1UL},{2UL},{0x33A4L},{0x85DEL}}};
        int32_t l_5715[8][10][3] = {{{(-1L),0xC7BC22B5L,1L},{(-10L),(-7L),(-7L)},{0x3F5F661BL,(-1L),(-7L)},{0x27B0D7A7L,0x918EBFFDL,1L},{0xBABAC71CL,0xA44E197CL,0xBB521CB1L},{0xF8C301C2L,(-10L),(-1L)},{0x918EBFFDL,6L,(-1L)},{(-10L),0xA44E197CL,(-4L)},{0x6647EBEBL,0L,(-1L)},{0xDCBB668FL,0xEDE0A949L,(-1L)}},{{0x371F533EL,(-7L),0xBB521CB1L},{0x6647EBEBL,0L,1L},{6L,(-7L),(-7L)},{0L,0x83B06C1DL,(-7L)},{0xF8C301C2L,0L,1L},{0x09810914L,0x09810914L,0xBB521CB1L},{0L,0xFA0E2890L,(-1L)},{0x3F5F661BL,(-10L),(-1L)},{6L,0x09810914L,(-4L)},{0x8B413C0DL,0x3F5F661BL,(-1L)}},{{0L,(-1L),(-1L)},{0xDCBB668FL,(-7L),0xBB521CB1L},{0x8B413C0DL,(-5L),1L},{0xFA0E2890L,0xEE374711L,(-7L)},{0x918EBFFDL,0xEDE0A949L,(-7L)},{0L,0x3F5F661BL,1L},{0xA44E197CL,0xBABAC71CL,0xBB521CB1L},{0x27B0D7A7L,6L,(-1L)},{0L,0xFA0E2890L,(-1L)},{0xFA0E2890L,0xBABAC71CL,(-4L)}},{{(-1L),0x918EBFFDL,(-1L)},{0x371F533EL,0x83B06C1DL,(-1L)},{0L,0xEE374711L,0xBB521CB1L},{(-1L),0xC7BC22B5L,1L},{(-10L),(-7L),(-7L)},{0x3F5F661BL,(-1L),(-7L)},{0x27B0D7A7L,0x918EBFFDL,1L},{0xBABAC71CL,0xD005538FL,0x09810914L},{0xCB82F5BDL,0L,0xC7BC22B5L},{5L,9L,0xDCBB668FL}},{{0L,0xD005538FL,(-10L)},{0x4F8A2EF9L,(-6L),0xDCBB668FL},{0xE5F8FBA9L,0xBAEE6916L,0xC7BC22B5L},{(-1L),0xCD571413L,0x09810914L},{0x4F8A2EF9L,0xDD052A91L,(-7L)},{9L,7L,(-1L)},{(-6L),0x74B9A195L,(-1L)},{0xCB82F5BDL,(-6L),(-7L)},{1L,1L,0x09810914L},{1L,0xA25CA89EL,0xC7BC22B5L}},{{1L,0L,0xDCBB668FL},{9L,1L,(-10L)},{1L,1L,0xDCBB668FL},{0xF7C083C2L,0x031E9855L,0xC7BC22B5L},{0xE5F8FBA9L,7L,0x09810914L},{1L,(-1L),(-7L)},{0xA25CA89EL,1L,(-1L)},{5L,0xBAEE6916L,(-1L)},{1L,1L,(-7L)},{0xD005538FL,8L,0x09810914L}},{{0xECB887DEL,9L,0xC7BC22B5L},{(-6L),0xA25CA89EL,0xDCBB668FL},{0xA25CA89EL,8L,(-10L)},{6L,5L,0xDCBB668FL},{(-1L),0x74B9A195L,0xC7BC22B5L},{0xF7C083C2L,1L,0x09810914L},{6L,0L,(-7L)},{0L,0xCD571413L,(-1L)},{1L,0x031E9855L,(-1L)},{0xECB887DEL,5L,(-7L)}},{{8L,0xD005538FL,0x09810914L},{0xCB82F5BDL,0L,0xC7BC22B5L},{5L,9L,0xDCBB668FL},{0L,0xD005538FL,(-10L)},{0x4F8A2EF9L,(-6L),0xDCBB668FL},{0xE5F8FBA9L,0xBAEE6916L,0xC7BC22B5L},{(-1L),0xCD571413L,0x09810914L},{0x4F8A2EF9L,0xDD052A91L,(-7L)},{9L,7L,(-1L)},{(-6L),0x74B9A195L,(-1L)}}};
        const uint8_t l_5717[6] = {4UL,4UL,0xE8L,4UL,4UL,0xE8L};
        uint32_t l_5724[8][1][8] = {{{0x4AC25322L,0xCCF888C2L,4294967295UL,0xCCF888C2L,0x4AC25322L,4294967289UL,0x37AA1332L,0x4AC25322L}},{{0x078B7AC7L,0x2C83BEC7L,0xAD91276BL,0x078B7AC7L,4294967288UL,4294967295UL,0x80294F62L,0xCCF888C2L}},{{0x2C83BEC7L,0x80294F62L,0xAD91276BL,0x37AA1332L,4294967295UL,4294967295UL,0x37AA1332L,0xAD91276BL}},{{4294967288UL,4294967288UL,4294967295UL,0x4AC25322L,0x8DA99C7EL,0x636A1D57L,0x6DE0CF62L,4294967288UL}},{{0x80294F62L,0x2C83BEC7L,0xAFE97530L,4294967295UL,0x6DE0CF62L,0xAFE97530L,0xAD91276BL,4294967288UL}},{{0x2C83BEC7L,0x078B7AC7L,0x80294F62L,0x4AC25322L,0x80294F62L,0x078B7AC7L,0x2C83BEC7L,0xAD91276BL}},{{0xCCF888C2L,0x4AC25322L,4294967289UL,0x37AA1332L,0x4AC25322L,4294967291UL,0x6DE0CF62L,0xCCF888C2L}},{{4294967295UL,0xAD91276BL,0x4C847768L,0x15B048A2L,0xAFE97530L,4294967295UL,4294967295UL,0xAFE97530L}}};
        const int8_t l_5741[1][4][9] = {{{0x18L,(-3L),(-3L),0x18L,(-3L),(-3L),0x18L,(-3L),(-3L)},{0x18L,(-3L),(-3L),0x18L,(-3L),(-3L),0x18L,(-3L),(-3L)},{0x18L,(-3L),(-3L),0x18L,(-3L),(-3L),0x18L,(-3L),(-3L)},{0x18L,(-3L),(-3L),0x18L,(-3L),(-3L),0x18L,(-3L),(-3L)}}};
        int8_t l_5743 = 0x2AL;
        uint32_t l_5745 = 0x18972BE9L;
        int i, j, k;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 6; j++)
                l_5681[i][j] = 0xCA7E3B43L;
        }
        l_5122++;
        if ((l_5125 == (((safe_sub_func_int32_t_s_s((*g_143), (((-1L) & (*g_1878)) || (((safe_rshift_func_uint64_t_u_s(((safe_lshift_func_int64_t_s_u(((*l_5014) != ((safe_mul_func_uint64_t_u_u(0xDFCA573304E2E782LL, (((*l_5014) > (l_5122 != (-1L))) > l_5120[1][0][6]))) && 0x32L)), 23)) ^ 0x65772955L), l_5117)) & l_5115) < (*l_5014))))) & l_5118[4][0]) , &g_1459)))
        { /* block id: 2379 */
            int32_t l_5140 = (-1L);
            const uint32_t l_5168 = 0x54358C4BL;
            int64_t l_5197 = 0L;
            int32_t l_5204 = 1L;
            int32_t l_5206 = 0xEB85681AL;
            int32_t l_5207 = 0x844B3A4AL;
            uint8_t **l_5231 = (void*)0;
            uint8_t ***l_5230[9] = {&l_5231,&l_5231,&l_5231,&l_5231,&l_5231,&l_5231,&l_5231,&l_5231,&l_5231};
            uint32_t l_5272 = 4UL;
            int64_t l_5291 = (-1L);
            int16_t l_5304[7][1];
            int32_t l_5363 = 0xDE59DDE0L;
            uint32_t l_5399 = 0x861C7DBAL;
            uint32_t l_5412 = 0xE049DFAAL;
            uint64_t l_5425 = 18446744073709551607UL;
            int8_t l_5429 = 0x8BL;
            int i, j;
            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 1; j++)
                    l_5304[i][j] = (-6L);
            }
            if (((l_5134 = l_5134) == ((safe_div_func_int8_t_s_s((safe_mul_func_int16_t_s_s((l_5140 >= (safe_rshift_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((safe_rshift_func_int32_t_s_s((safe_lshift_func_uint16_t_u_u(((*l_5014) ^ ((l_5140 | l_5140) >= ((safe_div_func_uint32_t_u_u((safe_mod_func_uint8_t_u_u(((*l_5014) | l_5116), l_5140)), (safe_mul_func_uint8_t_u_u(((safe_mul_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(l_5140, 12)), 0xFFL)), 0UL)) || l_5140), (*g_1878))))) ^ (-1L)))), 14)), (*l_5014))), g_3388)), l_5140)), 22))), 1L)), (*g_1878))) , &g_2460)))
            { /* block id: 2381 */
                uint16_t l_5167 = 65530UL;
                int32_t l_5172[6];
                int32_t **l_5182 = &l_5014;
                uint64_t l_5229 = 18446744073709551615UL;
                union U0 l_5234 = {0L};
                int64_t *l_5241 = (void*)0;
                int32_t ***l_5270 = &g_1157[0];
                int32_t ****l_5269 = &l_5270;
                int64_t l_5273 = 0x56F2935E317D4AF9LL;
                uint32_t l_5318 = 4294967291UL;
                int64_t ** const **l_5325 = &g_2577[6][7][0];
                int i;
                for (i = 0; i < 6; i++)
                    l_5172[i] = 0x886D4662L;
            }
            else
            { /* block id: 2487 */
                if ((l_5404 |= (*l_5014)))
                { /* block id: 2489 */
                    (*g_2082) = (*g_2082);
                }
                else
                { /* block id: 2491 */
                    (*l_5014) = 1L;
                    for (g_5016 = 23; (g_5016 > 17); g_5016--)
                    { /* block id: 2495 */
                        (*l_5014) = l_5407;
                        (*l_5014) = (((*g_1878) = l_5408) , l_5272);
                    }
                    l_5409 = 0xF386590CL;
                }
            }
            l_5412++;
            l_5116 ^= ((safe_div_func_int64_t_s_s((*g_521), (((*l_5014) = l_5272) & (((safe_mod_func_uint16_t_u_u((+0xF9L), (+((((safe_lshift_func_int32_t_s_s((((safe_rshift_func_int32_t_s_u(l_5425, ((l_5428 = (l_5227 , g_5426)) != &g_5427))) | l_5429) , (safe_add_func_int16_t_s_s(((l_5429 & l_5432) != 0x9540B07E7A437AA0LL), (*g_513)))), 24)) != 7L) , l_5433[0]) != (void*)0)))) != g_2541[3]) == l_5207)))) >= 0xA7F27A47A0D51CCALL);
        }
        else
        { /* block id: 2507 */
            int32_t ***l_5441 = (void*)0;
            int32_t **** const l_5440 = &l_5441;
            int32_t **** const *l_5439 = &l_5440;
            int32_t l_5455 = 0L;
            uint32_t l_5456 = 8UL;
            uint16_t l_5480 = 0x1919L;
            int8_t l_5505 = 0xEDL;
            uint16_t l_5507 = 0xD9C4L;
            union U0 l_5542 = {1L};
            union U0 ** const l_5631 = (void*)0;
            uint64_t l_5657 = 0xF34DA1667538316BLL;
            uint8_t l_5685 = 0x8CL;
            uint32_t ***l_5690 = &g_3065;
            uint32_t l_5702 = 18446744073709551611UL;
            int32_t l_5744[5][8][6] = {{{(-6L),0x2BE157C2L,0xC5B890F5L,0xE0DBCEFAL,5L,(-1L)},{0xDF62C010L,0xB6CEBC8BL,(-1L),(-2L),5L,0xD7E3C8C7L},{0xD7E3C8C7L,0x2BE157C2L,(-1L),(-1L),(-9L),2L},{(-1L),(-6L),0x86CC93BBL,1L,0x4E918754L,1L},{0x2BE157C2L,0xA00AB387L,0x2BE157C2L,(-1L),(-2L),(-4L)},{0L,(-1L),0x4E918754L,(-6L),(-1L),0x86CC93BBL},{(-4L),2L,0L,(-6L),0xD7E3C8C7L,(-1L)},{0L,0x5FF65765L,0xB6CEBC8BL,(-1L),2L,0x549BE232L}},{{0x2BE157C2L,(-1L),0x9517E38BL,1L,1L,0x9517E38BL},{(-1L),(-1L),4L,(-1L),(-4L),(-1L)},{0xD7E3C8C7L,0x9517E38BL,(-2L),(-2L),0x86CC93BBL,4L},{0xDF62C010L,0xD7E3C8C7L,(-2L),0xE0DBCEFAL,(-1L),(-1L)},{(-6L),0xE0DBCEFAL,4L,(-2L),0x549BE232L,0x9517E38BL},{(-2L),0x549BE232L,0x9517E38BL,(-1L),0x9517E38BL,0x549BE232L},{(-1L),(-2L),0xB6CEBC8BL,0x4E918754L,(-1L),(-1L)},{(-1L),0xDF62C010L,0L,0x5FF65765L,4L,0x86CC93BBL}},{{1L,0xDF62C010L,0x4E918754L,0L,(-1L),(-4L)},{(-1L),(-2L),0x2BE157C2L,(-1L),0x9517E38BL,1L},{2L,0x549BE232L,0x86CC93BBL,0x86CC93BBL,0x549BE232L,2L},{0x6D049135L,0xE0DBCEFAL,(-1L),5L,(-1L),0xD7E3C8C7L},{4L,0xD7E3C8C7L,(-1L),0xC5B890F5L,0x86CC93BBL,(-1L)},{4L,0x9517E38BL,0xC5B890F5L,5L,(-4L),(-2L)},{0x6D049135L,(-1L),(-6L),0x86CC93BBL,1L,0x4E918754L},{2L,(-4L),0xE0DBCEFAL,(-4L),(-1L),(-1L)}},{{0L,0xD7E3C8C7L,(-1L),(-6L),4L,0x4E918754L},{(-1L),(-1L),0x2BE157C2L,0xD7E3C8C7L,0xA00AB387L,0x4E918754L},{(-4L),0xDF62C010L,(-1L),(-2L),0x2BE157C2L,(-1L)},{0xA00AB387L,0x86CC93BBL,0xE0DBCEFAL,0L,(-2L),(-2L)},{0x9517E38BL,1L,1L,0x9517E38BL,(-1L),0x2BE157C2L},{1L,0x5FF65765L,(-2L),0xC5B890F5L,0x4E918754L,0xA00AB387L},{0x549BE232L,(-1L),(-4L),0x2BE157C2L,0x4E918754L,4L},{4L,0x5FF65765L,0L,0xDF62C010L,(-1L),(-1L)}},{{5L,1L,0x6D049135L,(-1L),(-2L),(-1L)},{0x5FF65765L,0x86CC93BBL,0x5FF65765L,5L,0x2BE157C2L,(-1L)},{(-6L),0xDF62C010L,(-2L),1L,0xA00AB387L,0x6D049135L},{(-1L),(-1L),(-9L),1L,4L,5L},{(-6L),0xD7E3C8C7L,(-1L),5L,(-1L),0xE0DBCEFAL},{0x5FF65765L,(-4L),0xB6CEBC8BL,(-1L),(-1L),0xB6CEBC8BL},{5L,5L,2L,0xDF62C010L,(-1L),(-4L)},{4L,0xB6CEBC8BL,0x9517E38BL,0x2BE157C2L,0x6D049135L,2L}}};
            int i, j, k;
            if (((*g_1016) , ((l_5457 = ((*l_5014) = ((safe_mul_func_uint32_t_u_u(((l_5439 = (g_5436 = g_5436)) != l_5442[3]), (l_5443 , (((**g_248) = (safe_lshift_func_int64_t_s_s((safe_div_func_uint64_t_u_u((l_5448 == (void*)0), ((&g_3788[1] != &g_3788[1]) , ((((safe_lshift_func_int8_t_s_u((((((safe_sub_func_int8_t_s_s(((&l_5235 == (void*)0) | l_5453), 0xF2L)) , l_5454) <= 0xD3L) == l_5455) || (*l_5014)), 6)) || (*g_1878)) , l_5455) , l_5456)))), l_5455))) > (*g_2579))))) , 0xA72CB40BL))) | l_5456)))
            { /* block id: 2513 */
                uint8_t l_5466 = 0x83L;
                uint8_t l_5478 = 6UL;
                int32_t l_5481 = 0xF0E8585AL;
                int32_t l_5482[1];
                const uint32_t l_5508 = 4294967289UL;
                int8_t l_5554 = 1L;
                int i;
                for (i = 0; i < 1; i++)
                    l_5482[i] = 0x22B01C54L;
                if ((safe_lshift_func_int8_t_s_s((((safe_add_func_int32_t_s_s((l_5482[0] = (l_5481 = ((l_5480 = (safe_add_func_int32_t_s_s((((safe_rshift_func_int8_t_s_s((0x146DD3B9L && (((l_5466 | (**g_248)) < (+(safe_rshift_func_uint16_t_u_s((1UL ^ (((*g_1878) = (((safe_sub_func_int8_t_s_s((((*g_5112) ^ g_887[1][2][0]) && ((((safe_mul_func_int32_t_s_s(((**g_2009) < (safe_rshift_func_uint64_t_u_u(l_5466, 57))), (((((safe_rshift_func_uint32_t_u_s((((((l_5466 <= 7L) | 0x25L) < (*l_5014)) > (*g_5112)) , l_5478), (*l_5014))) > (*g_1878)) >= (*g_1878)) && l_5466) < (***g_3869)))) , l_5478) , (*g_3838)) , (*l_5014))), (*g_1878))) | l_5466) <= 0xE8A554CE6F57B24FLL)) > (*g_1016))), l_5466)))) && l_5478)), 1)) < l_5466) , g_5479), l_5466))) != 0x7CADD4F0L))), 0x7DE7A954L)) < l_5478) , (*g_1878)), 6)))
                { /* block id: 2518 */
                    return l_5482[0];
                }
                else
                { /* block id: 2520 */
                    int64_t *****l_5485 = &g_1845;
                    int32_t l_5502[6][8][5] = {{{1L,0x2B68481CL,1L,0x3A077BACL,0xEF7320C6L},{0x7DAE2025L,0xC365CE31L,0xB9E199EDL,(-1L),1L},{0x2B68481CL,0xB59960BAL,0xD8599B30L,(-7L),0x2C0648C8L},{(-1L),0x9574B062L,0x099DD946L,(-7L),0xB59960BAL},{0xA73D8B51L,(-2L),(-1L),(-1L),0L},{0x0993621EL,(-2L),0xA770D43FL,0x3A077BACL,0x02A3274EL},{0x79F8C484L,0L,0x2E3070CAL,0L,0x0A0D1802L},{0L,1L,0x6CB9843FL,1L,0L}},{{(-2L),1L,0x79F8C484L,0x9574B062L,0x6CB9843FL},{0x340C2593L,(-1L),0x2C0648C8L,0xF006A241L,0xF9DF7E11L},{(-2L),(-7L),0x0A0D1802L,1L,0x6CB9843FL},{(-1L),0xF006A241L,0x3A077BACL,0x340C2593L,0L},{0x6CB9843FL,(-7L),(-8L),0x0DFA91B3L,0x0A0D1802L},{0x2F0EB559L,1L,0xD7F01920L,(-6L),0x02A3274EL},{0x08786CE8L,(-1L),0xA73D8B51L,1L,0L},{0xD8599B30L,0x4BADE718L,1L,0x08786CE8L,0xB59960BAL}},{{(-1L),0x0993621EL,0xC365CE31L,9L,0x2C0648C8L},{(-1L),(-1L),(-2L),0x8FEA141DL,0x2F0EB559L},{0x0993621EL,0L,0L,0xF9DF7E11L,0x41A5118FL},{0xD8599B30L,0x0A0D1802L,0xA73D8B51L,(-7L),(-1L)},{0x0B8A2C6AL,(-8L),0xD8599B30L,4L,0xD8599B30L},{1L,1L,(-7L),0xD7F01920L,(-1L)},{0xF006A241L,0x4BADE718L,0x02A3274EL,(-1L),0xCE7FF9D8L},{(-1L),0x2F0EB559L,(-8L),0x0993621EL,0x227A9363L}},{{(-1L),0x4BADE718L,0x2B68481CL,1L,0x7DAE2025L},{0x2C0648C8L,1L,0x2E3070CAL,(-1L),(-7L)},{0xF9DF7E11L,(-8L),0xB9E199EDL,0L,1L},{0x7DAE2025L,0x0A0D1802L,(-1L),0L,1L},{0x7DF5D567L,0L,(-1L),(-6L),0L},{4L,(-1L),0x82B0F973L,0x2F0EB559L,0x4BADE718L},{0L,0x7DF5D567L,0x82B0F973L,0x2E3070CAL,0xD7F01920L},{(-2L),0x2B68481CL,(-1L),0xB59960BAL,(-1L)}},{{0x02A3274EL,0xF006A241L,(-1L),0x82B0F973L,0x0B8A2C6AL},{(-1L),1L,0xB9E199EDL,0x7DAE2025L,0xB59960BAL},{0xC9487E5FL,0x2E3070CAL,0x2E3070CAL,0xC9487E5FL,0L},{(-7L),0xA73D8B51L,0x2B68481CL,0xC365CE31L,(-8L)},{0L,0xA770D43FL,(-8L),(-1L),0x0DFA91B3L},{0x9574B062L,0x0DFA91B3L,0x02A3274EL,0xC365CE31L,0L},{0x340C2593L,1L,(-7L),0xC9487E5FL,(-1L)},{0xEF7320C6L,(-1L),0xD8599B30L,0x7DAE2025L,0L}},{{0x2F0EB559L,0xEF7320C6L,0xA73D8B51L,0x82B0F973L,(-1L)},{0x8FEA141DL,0x2C0648C8L,0L,0xB59960BAL,0xC9487E5FL},{0x79F8C484L,(-1L),0x2C0648C8L,0x2E3070CAL,9L},{0x0A0D1802L,0x227A9363L,(-6L),0x2F0EB559L,9L},{0x099DD946L,(-7L),0xB59960BAL,(-6L),0xC9487E5FL},{1L,(-6L),4L,0L,(-1L)},{0L,(-2L),0xCE7FF9D8L,0L,0L},{0xB59960BAL,(-1L),(-1L),(-1L),(-1L)}}};
                    int32_t l_5509 = (-9L);
                    int16_t *l_5511 = (void*)0;
                    int16_t *l_5512 = &l_5409;
                    union U0 l_5537[4] = {{0xB91B1A776996C11DLL},{0xB91B1A776996C11DLL},{0xB91B1A776996C11DLL},{0xB91B1A776996C11DLL}};
                    uint64_t l_5549 = 0x3BD8B4EAF7B87132LL;
                    union U0 *** const *l_5553 = &g_1484;
                    union U0 *** const **l_5552 = &l_5553;
                    uint16_t l_5571 = 0xA206L;
                    int i, j, k;
                    (*l_5014) = ((safe_sub_func_uint8_t_u_u((&g_4599 != (l_5227 , l_5485)), ((((*l_5512) = (+(((safe_sub_func_uint16_t_u_u((safe_add_func_int8_t_s_s(0x85L, (0L & ((safe_mul_func_int8_t_s_s((((safe_div_func_uint8_t_u_u(((safe_add_func_int16_t_s_s((+((l_5482[0] ^ ((*g_513) &= (6L == (l_5507 = (safe_mod_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u((l_5481 ^= ((((((l_5502[2][6][3] , (safe_add_func_int16_t_s_s((l_5482[0] != l_5505), 1L))) > l_5502[2][6][3]) & (**g_248)) >= g_2541[1]) >= l_5502[5][2][4]) , 0x7542L)), 8)) > 0x27L), g_5506)))))) & g_1808)), 0x9305L)) != l_5508), (-1L))) & l_5509) & 0xAAA99F6DL), 255UL)) | 0xB66AL)))), g_4079)) , g_5510) != g_5510))) < l_5478) , 0x94L))) > 1L);
                    for (g_5196 = 0; (g_5196 <= 0); g_5196 += 1)
                    { /* block id: 2528 */
                        const int32_t *l_5530 = &g_4692[0];
                        const int32_t ** const l_5529 = &l_5530;
                        const int32_t ** const *l_5528 = &l_5529;
                        int32_t l_5534 = 0xCD42DE56L;
                        int8_t l_5555 = (-3L);
                        (*l_5014) = (((*g_1878) = (safe_rshift_func_uint64_t_u_s((**g_248), ((safe_mod_func_int64_t_s_s(((safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((*l_5125) &= 0xD1DDL), (safe_sub_func_uint32_t_u_u(((safe_mul_func_uint16_t_u_u((((*l_5368) != (l_5528 = g_5525)) , ((safe_mul_func_int8_t_s_s(l_5533, (l_5534 != ((*g_513) = (((*g_2579) ^= (safe_mul_func_int64_t_s_s(((l_5537[1] , (safe_mod_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u((l_5542 , (l_5537[1].f0 <= (*g_513))), (*g_4191))), 0x88C777F558BD5A34LL))) , 1L), (***g_3869)))) == (**g_248)))))) , g_5196)), g_5543)) , l_5509), 0x9FA4C7E1L)))), 0x8428L)) , 1L), l_5478)) && l_5534)))) <= l_5481);
                        (*l_5014) = (((void*)0 != (**g_5426)) & (((((((safe_add_func_int8_t_s_s((*g_1878), (safe_add_func_uint8_t_u_u((**g_1015), 0xB9L)))) && (((l_5481 < (((((safe_unary_minus_func_int64_t_s(l_5549)) || ((*l_5512) = (-7L))) , ((*l_5512) ^= (safe_add_func_int16_t_s_s(0xACBFL, (*g_513))))) , (void*)0) == l_5552)) , (*g_1878)) ^ (**g_1015))) ^ (*l_5014)) != (*g_2579)) ^ l_5554) ^ l_5478) ^ 0x39L));
                        (**g_2461) = (**g_2461);
                        if (l_5555)
                            continue;
                    }
                    l_5571 |= (g_5479 < ((*g_1878) == ((safe_mod_func_uint64_t_u_u((safe_lshift_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u(((*g_2010) = (((safe_rshift_func_int16_t_s_s(((l_5482[0] , (safe_mod_func_int32_t_s_s((l_5481 = ((safe_add_func_uint32_t_u_u(((-1L) & ((l_5508 <= 1L) || ((*g_4191) >= (l_5502[2][6][3] = (l_5482[0] = ((safe_add_func_uint8_t_u_u(8UL, (*g_1878))) != 0xA0672F61L)))))), l_5481)) || l_5537[1].f0)), 1UL))) <= (*****g_2081)), 2)) && l_5549) >= (*l_5014))), l_5570)) , l_5502[2][6][3]), l_5554)), l_5466)) & 0x15L)));
                }
            }
            else
            { /* block id: 2547 */
                int32_t *l_5572 = &l_5411;
                uint16_t l_5582 = 0UL;
                uint64_t l_5596 = 4UL;
                union U0 **l_5630[3];
                int32_t l_5645 = (-8L);
                int16_t * const *l_5662 = &g_513;
                int16_t * const * const *l_5661 = &l_5662;
                int16_t * const * const **l_5660 = &l_5661;
                int16_t * const * const ***l_5659 = &l_5660;
                int16_t l_5707[1];
                uint64_t l_5716 = 18446744073709551615UL;
                int i;
                for (i = 0; i < 3; i++)
                    l_5630[i] = &g_218;
                for (i = 0; i < 1; i++)
                    l_5707[i] = 7L;
                l_5572 = l_5572;
                for (g_122 = (-9); (g_122 > (-30)); g_122--)
                { /* block id: 2551 */
                    int16_t l_5577 = 1L;
                    uint8_t *** const *l_5589 = &l_5305;
                    uint8_t *** const **l_5588[7][1][8] = {{{(void*)0,&l_5589,&l_5589,(void*)0,&l_5589,&l_5589,&l_5589,&l_5589}},{{&l_5589,&l_5589,&l_5589,&l_5589,(void*)0,&l_5589,&l_5589,(void*)0}},{{&l_5589,&l_5589,&l_5589,&l_5589,&l_5589,&l_5589,&l_5589,&l_5589}},{{(void*)0,&l_5589,&l_5589,(void*)0,&l_5589,&l_5589,&l_5589,&l_5589}},{{&l_5589,&l_5589,&l_5589,&l_5589,&l_5589,&l_5589,&l_5589,&l_5589}},{{(void*)0,&l_5589,&l_5589,(void*)0,(void*)0,&l_5589,&l_5589,(void*)0}},{{&l_5589,&l_5589,&l_5589,&l_5589,(void*)0,&l_5589,&l_5589,(void*)0}}};
                    int16_t *l_5594 = &g_4673;
                    int32_t *l_5601[1][9];
                    int32_t *l_5602 = &l_3931[1];
                    union U0 ** const *l_5652[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
                    union U0 ** const **l_5651 = &l_5652[1];
                    union U0 ** const **l_5653 = (void*)0;
                    union U0 ** const **l_5654 = (void*)0;
                    union U0 ** const *l_5656 = &l_5631;
                    union U0 ** const **l_5655 = &l_5656;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 9; j++)
                            l_5601[i][j] = &g_197[3];
                    }
                    (*l_5014) = ((*g_1878) || ((l_5577 <= ((((*g_513) = (*g_513)) | (*g_5112)) < ((((safe_lshift_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((*g_2010), l_5582)) , ((*l_5594) ^= (safe_unary_minus_func_int16_t_s(((safe_sub_func_uint64_t_u_u(0x9CDA17E0B98AD039LL, (safe_rshift_func_int16_t_s_s((&g_2082 == (l_5590 = l_5588[1][0][7])), l_5577)))) , l_5577))))), l_5577)) , (-1L)) < l_5595) , l_5577))) != l_5596));
                    if ((safe_rshift_func_uint64_t_u_s((l_5577 >= ((((((g_5599 , ((***g_3869) = ((((!l_5577) > 0xD3FC50A0L) || 9UL) != (l_5601[0][5] == (l_5572 = l_5602))))) ^ l_5603) >= (safe_lshift_func_int64_t_s_u(l_5596, (*l_5014)))) || (**g_2009)) < 1L) >= (****g_2082))), l_5596)))
                    { /* block id: 2558 */
                        uint16_t l_5606[4] = {0xF6DEL,0xF6DEL,0xF6DEL,0xF6DEL};
                        int i;
                        (*l_5572) ^= l_5606[3];
                        if (l_5606[3])
                            break;
                    }
                    else
                    { /* block id: 2561 */
                        const union U0 *l_5627[4][10][6] = {{{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353}},{{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353}},{{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353}},{{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353},{&g_1353,&g_28,&g_28,&g_1353,&g_1353,&g_28},{&g_1353,&g_1353,&g_28,&g_28,&g_1353,&g_1353}}};
                        const union U0 **l_5626 = &l_5627[0][5][3];
                        int32_t l_5633 = 8L;
                        int i, j, k;
                        l_5633 = (((safe_mod_func_int64_t_s_s(0x766AA861B38D2F53LL, (safe_sub_func_int32_t_s_s((*l_5602), (safe_add_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((safe_div_func_uint64_t_u_u((safe_add_func_uint16_t_u_u((((safe_mod_func_int32_t_s_s((safe_div_func_int32_t_s_s(((*g_2579) != ((~0x2D36L) < (((void*)0 != l_5626) >= (safe_lshift_func_uint64_t_u_s((l_5630[0] != (((void*)0 != &g_176) , l_5631)), (*l_5572)))))), 0x56EE07C9L)), (*l_5572))) | (*l_5014)) , g_3390), 1UL)), 0xD99A7322FB087D7ALL)), (*g_4191))), (-1L))))))) <= l_5632) , (*g_4618));
                    }
                    if ((safe_mod_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((*l_5572), (*l_5572))), (+(safe_sub_func_int8_t_s_s(((l_5645 = (safe_rshift_func_uint32_t_u_u((*l_5572), 9))) == (&g_2037 != &g_2036[0])), ((((safe_add_func_uint32_t_u_u(l_5648, ((*l_5014) = (safe_lshift_func_int16_t_s_s((((*l_5655) = ((*l_5651) = &l_5631)) == (l_5657 , l_5658)), (*g_5112)))))) == (-1L)) < (*l_5602)) , (*g_2010))))))))
                    { /* block id: 2568 */
                        uint32_t l_5669 = 5UL;
                        if ((*l_5572))
                            break;
                        l_5659 = l_5659;
                        (*l_5602) = (((((((safe_mod_func_uint32_t_u_u(0x22F8191AL, (safe_add_func_uint16_t_u_u(((((**g_248) = (+1UL)) < (255UL | ((~((l_5669 , 0UL) >= ((((((***l_5661) = ((safe_lshift_func_int64_t_s_s((-5L), (4294967289UL & (((l_5669 || ((safe_div_func_int64_t_s_s((safe_rshift_func_int8_t_s_s(((~((safe_mul_func_uint8_t_u_u((((safe_mod_func_uint8_t_u_u(((0x8BL ^ (*g_1878)) , l_5681[0][4]), (****g_2007))) < l_5669) >= 18446744073709551609UL), l_5682[0][7])) < l_5669)) , 0x06L), (*g_1878))), l_5683[6][2][3])) >= l_5684[6][5][0])) <= l_5669) | l_5669)))) <= (-7L))) != (*l_5602)) > (*l_5572)) != (*l_5572)) , l_5685))) == (*g_1878)))) & l_5669), (*l_5572))))) , g_2202) > l_5669) , (*g_1878)) ^ 8UL) && (*g_5112)) | l_5669);
                    }
                    else
                    { /* block id: 2574 */
                        int32_t l_5686[6][9];
                        uint32_t l_5689 = 0x3B40F59EL;
                        int i, j;
                        for (i = 0; i < 6; i++)
                        {
                            for (j = 0; j < 9; j++)
                                l_5686[i][j] = 1L;
                        }
                        if ((*l_5572))
                            break;
                        (*l_5014) |= l_5686[3][3];
                        (*l_5602) = ((safe_add_func_uint8_t_u_u((l_5689 &= (g_2541[1] &= (*g_2010))), (*l_5572))) <= ((0x5FA2L <= ((void*)0 != l_5690)) , ((-1L) || ((safe_add_func_uint64_t_u_u((l_5686[3][3] ^ (0UL > 0L)), 9L)) < 4294967294UL))));
                        (*l_5602) = 0x438004BBL;
                    }
                    (*l_5572) = ((((((*l_5014) = (((((((((((safe_mul_func_uint16_t_u_u((safe_sub_func_int8_t_s_s((l_5715[6][9][2] |= (+((safe_mul_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(((*l_5134) != (*g_5436)), l_5702)), (safe_rshift_func_int32_t_s_s((-3L), (safe_sub_func_int32_t_s_s((((((*g_1878) &= 0x13L) | l_5707[0]) == (safe_unary_minus_func_int32_t_s((!(((safe_rshift_func_int16_t_s_s(((safe_sub_func_uint8_t_u_u(((*****g_2081) = (0x267E1CF7L | (*l_5572))), (((*l_5602) & (*l_5572)) & (**g_1015)))) | (*l_5572)), 0)) , l_5714) < 4294967289UL))))) && 0x4A47A568L), 0x7BD591F8L)))))) == (*l_5572)))), (*l_5572))), (*g_513))) != l_5408) , l_5227) , (***g_888)) == &l_5542) , (*l_5572)) || (*l_5014)) && 0xC2FEBE0C04A84813LL) == (*g_4618)) & 1L) ^ l_5716)) , l_5685) < (*l_5572)) < l_5717[0]) > (*l_5572));
                }
            }
            (*l_5014) = (safe_mod_func_uint32_t_u_u(((l_5717[0] , ((safe_div_func_int64_t_s_s((((safe_mul_func_uint32_t_u_u((l_5724[4][0][4] &= (*l_5014)), ((safe_lshift_func_int8_t_s_u((0x40AA2CE6726B5E32LL == 0x42711ED10C51AEC9LL), 6)) | (safe_mod_func_int32_t_s_s(l_5702, (safe_mul_func_uint16_t_u_u(1UL, (*g_513)))))))) && (((safe_mod_func_int8_t_s_s((safe_div_func_int8_t_s_s((safe_rshift_func_uint32_t_u_s((1L & ((safe_mul_func_uint8_t_u_u((***g_2008), 0xDAL)) == (**g_248))), l_5741[0][3][3])), (*g_1878))), l_5742)) == l_5171) == (*g_5112))) ^ (*l_5014)), l_5743)) , (*l_5014))) || 0xEA89FA2FL), (*l_5014)));
            l_5745--;
        }
    }
    l_5761 &= (safe_sub_func_int64_t_s_s((*l_5014), (safe_mul_func_int16_t_s_s(((((safe_sub_func_int32_t_s_s(1L, ((l_5756[0] ^= (safe_sub_func_uint32_t_u_u((*l_5014), ((*l_5014) > (4294967295UL >= ((void*)0 != &l_5591)))))) < (((safe_mod_func_int64_t_s_s(((*g_2579) = (l_5759[1] , l_5760)), (*g_521))) == 4L) ^ 0x2FL)))) > g_5599) , (-2L)) | 0x90L), g_887[1][2][0]))));
    if ((safe_sub_func_uint16_t_u_u((((((safe_mod_func_int8_t_s_s(((safe_div_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u(((!(((****g_2007) & ((safe_add_func_int32_t_s_s((safe_add_func_int64_t_s_s(((safe_div_func_uint32_t_u_u(((safe_div_func_uint8_t_u_u(((safe_mul_func_uint32_t_u_u((*l_5014), ((((0xB0F4864AC08F9E33LL || (0x1E9FAC84L | (safe_rshift_func_uint8_t_u_u((0x5390L ^ (!(g_179 |= (g_3390 = ((((*g_2579) = (*l_5014)) & ((**g_248) < (~((*g_513) ^= (((g_5785 = (*g_248)) != &l_3932) & 5UL))))) < 0xB1L))))), 1)))) , (void*)0) != (void*)0) < (*l_5014)))) , (**g_2009)), (*g_1878))) <= l_5786[0][0][0]), (*l_5014))) & 248UL), l_5787[3][0])), (*l_5014))) && (-10L))) < l_5788)) & l_5789), (*g_2010))) < (*g_1878)), 0x89C3L)) >= (*g_1878)), (*l_5014))) , 0x031AEE3890E5A551LL) , 0x2E29L) > g_2949) < 0x6D5D8CA19A9F8F99LL), 1L)))
    { /* block id: 2602 */
        uint16_t l_5792 = 0x3B2CL;
        l_5792++;
    }
    else
    { /* block id: 2604 */
        int8_t l_5795 = 0x90L;
        int32_t l_5796 = 0x769DAA53L;
        int32_t l_5797 = 0L;
        uint32_t l_5798 = 1UL;
        int64_t l_5838 = 0xC0A9118AD1CE88E7LL;
        int32_t *l_5843 = &g_5016;
        union U0 l_5847 = {-5L};
        union U0 l_5848 = {0x0C8290857A4935B7LL};
        union U0 **l_5864[7] = {&g_218,&g_218,&g_218,&g_218,&g_218,&g_218,&g_218};
        int i;
        l_5798--;
        l_5801--;
lbl_5882:
        for (l_5411 = 6; (l_5411 >= 0); l_5411 -= 1)
        { /* block id: 2609 */
            uint8_t ****l_5817[10][7] = {{&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305,&l_5305},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
            uint8_t ***** const l_5816 = &l_5817[9][4];
            const int32_t l_5818 = (-7L);
            union U0 l_5822 = {0x67E980F084827151LL};
            const int32_t *l_5865 = &g_5866;
            int i, j;
            for (l_5385.f0 = 0; (l_5385.f0 <= 6); l_5385.f0 += 1)
            { /* block id: 2612 */
                union U0 **l_5810[6] = {&g_218,&g_218,&g_218,&g_218,&g_218,&g_218};
                uint32_t l_5815[5];
                int32_t l_5836[8][2][10] = {{{1L,(-1L),(-4L),0xADAA0E38L,0L,8L,8L,0L,0xADAA0E38L,(-4L)},{0x0BF9E9FFL,0x0BF9E9FFL,(-1L),0L,(-10L),0x96339768L,0x60710274L,0x0BF9E9FFL,0x54369A7EL,0x60710274L}},{{(-1L),1L,8L,0xC2A65269L,1L,0xADAA0E38L,0x60710274L,0xADAA0E38L,1L,0xC2A65269L},{0x96339768L,0x7381E34AL,0x96339768L,(-1L),0xBDF9B671L,0x54369A7EL,(-1L),1L,0xC6904AFDL,0x96339768L}},{{1L,(-1L),(-10L),8L,0x7381E34AL,1L,1L,1L,1L,0x7381E34AL},{(-1L),0x96339768L,0x96339768L,(-1L),0xC6904AFDL,0xB0DA6902L,0x7381E34AL,(-8L),0x96339768L,1L}},{{0xC6904AFDL,1L,(-1L),0x54369A7EL,0xBDF9B671L,(-1L),0x96339768L,0x7381E34AL,0x96339768L,(-1L)},{8L,(-1L),0x0BF9E9FFL,(-1L),8L,0x60710274L,(-4L),8L,1L,0xBDF9B671L}},{{0x7381E34AL,0xC6904AFDL,0x54369A7EL,8L,0x8383E805L,0xB0DA6902L,0xBDF9B671L,0xC6904AFDL,0xC6904AFDL,0xBDF9B671L},{(-8L),8L,(-1L),(-1L),8L,(-8L),0x54369A7EL,(-1L),0xB0DA6902L,(-1L)}},{{1L,0x7381E34AL,0L,(-4L),0xBDF9B671L,0x0BF9E9FFL,(-4L),1L,(-10L),1L},{1L,(-8L),0xC6904AFDL,8L,0xC6904AFDL,(-8L),1L,0x96339768L,(-8L),0x7381E34AL}},{{(-8L),1L,0x96339768L,(-8L),0x7381E34AL,0xB0DA6902L,0xC6904AFDL,(-1L),0x96339768L,0x96339768L},{0x7381E34AL,1L,0x60710274L,0xBDF9B671L,0xBDF9B671L,0x60710274L,1L,0x7381E34AL,0L,(-4L)}},{{8L,(-8L),0x54369A7EL,(-1L),0xB0DA6902L,(-1L),(-4L),0xB0DA6902L,(-8L),0xBDF9B671L},{0xC6904AFDL,0x7381E34AL,0x54369A7EL,0xB0DA6902L,0xADAA0E38L,0xB0DA6902L,0x54369A7EL,0x7381E34AL,0xC6904AFDL,0x54369A7EL}}};
                const int32_t *l_5852 = &l_5411;
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_5815[i] = 0x181C6251L;
                if (((l_3931[l_5411] == ((+(safe_div_func_uint8_t_u_u(1UL, (9L ^ ((safe_unary_minus_func_int32_t_s((((void*)0 != l_5810[4]) | (safe_mul_func_uint32_t_u_u((l_3931[l_5411] , (&g_2007 != ((((safe_mul_func_int32_t_s_s(0xCD54DBEDL, l_5798)) & l_3931[l_5411]) , l_5815[3]) , l_5816))), 0UL))))) != 0L))))) , l_5797)) , l_5818))
                { /* block id: 2613 */
                    union U0 l_5820 = {9L};
                    int32_t l_5839 = 1L;
                    int64_t ****l_5841 = (void*)0;
                    int8_t l_5842 = 0x1CL;
                    const int32_t **l_5854 = &l_5852;
                    int i;
                    if (((((8UL && ((safe_unary_minus_func_uint32_t_u(((l_5822 = (g_5821[2][3][0] = l_5820)) , (safe_div_func_uint32_t_u_u((safe_rshift_func_uint32_t_u_s(((-3L) == l_5815[3]), (l_3931[l_5411] = (((safe_lshift_func_uint16_t_u_u(((safe_sub_func_int8_t_s_s((l_5839 = (0x0FCAL || (l_5796 == ((((safe_mod_func_uint16_t_u_u((safe_mul_func_uint64_t_u_u((((*g_1878) , 1UL) || (+l_5836[7][1][5])), 0xFB99E72858D1B63CLL)), g_5837)) >= l_5838) ^ 0L) && l_5796)))), 0xE7L)) == 1UL), 0)) , l_5840) != l_5841)))), l_5842))))) && 0x9E99L)) || l_5836[7][1][5]) || l_5822.f0) != 0xD62BL))
                    { /* block id: 2618 */
                        uint64_t l_5844 = 18446744073709551615UL;
                        (****g_5436) = l_5843;
                        (*l_5843) |= l_5815[3];
                        l_5844++;
                        if (l_5836[0][1][7])
                            continue;
                    }
                    else
                    { /* block id: 2623 */
                        int16_t l_5849 = 0xA0E4L;
                        l_5849 |= ((((l_5848 = l_5847) , 1L) && (***g_2008)) == (*l_5014));
                    }
                    (*l_5014) ^= (l_5820 , (safe_lshift_func_int32_t_s_u((*l_5843), 4)));
                    (*g_4987) = &l_5839;
                    (*l_5854) = l_5852;
                }
                else
                { /* block id: 2630 */
                    uint16_t l_5855 = 3UL;
                    int32_t l_5856 = 0x54644256L;
                    l_5856 = ((l_5855 && (*g_513)) < g_585);
                    if ((*l_5843))
                        break;
                    for (l_5838 = (-28); (l_5838 <= 13); ++l_5838)
                    { /* block id: 2635 */
                        const int32_t l_5863 = 0x7B1431ADL;
                        g_5862[0] &= ((+((safe_rshift_func_uint8_t_u_s(0UL, ((*g_194) != &l_5847))) || (*g_1016))) , l_5822.f0);
                        if (l_5863)
                            break;
                    }
                    l_3931[l_5411] = (l_5864[0] == (void*)0);
                }
            }
            (*g_631) = (l_5865 = &l_5818);
            return (*l_5843);
        }
        for (l_5027.f0 = 0; (l_5027.f0 <= (-15)); --l_5027.f0)
        { /* block id: 2648 */
            union U0 *l_5869 = &l_5848;
            union U0 l_5881 = {-7L};
            if (((*l_5843) = (-4L)))
            { /* block id: 2650 */
                int32_t *l_5870 = &l_3931[3];
                (*g_217) = l_5869;
                (**g_5438) = l_5870;
            }
            else
            { /* block id: 2653 */
                int32_t l_5880 = 1L;
                (*g_890) = (*g_890);
                (*l_5014) = ((((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_u(0L, (g_3390++))), 1)) <= (l_5877 > (safe_lshift_func_uint16_t_u_s((*l_5843), 6)))) <= l_5880) <= ((l_5881 , &g_5109) == &g_5109));
                for (g_1971 = 0; (g_1971 <= 0); g_1971 += 1)
                { /* block id: 2659 */
                    for (l_5201 = 0; (l_5201 <= 0); l_5201 += 1)
                    { /* block id: 2662 */
                        int i;
                        if (l_5029[(l_5201 + 1)])
                            break;
                        (**g_2461) = (**g_3989);
                        if (g_5196)
                            goto lbl_5882;
                    }
                }
            }
        }
    }
    return (*l_5014);
}


/* ------------------------------------------ */
/* 
 * reads : g_1016 g_1017 g_197 g_4191 g_3388 g_600 g_2081 g_2082 g_2008 g_2009 g_2010 g_28.f0 g_4618 g_6 g_179 g_1878 g_2007 g_506 g_503 g_3390 g_4450 g_2578 g_2579 g_201 g_122 g_1879 g_2027 g_2028 g_513 g_91 g_248 g_249 g_4782 g_4802 g_1015 g_3869 g_521 g_522 g_186 g_267 g_2949 g_3421 g_65 g_1300 g_4079 g_4987 g_1808 g_3031 g_3356 g_2641
 * writes: g_197 g_2641 g_4598 g_600 g_506 g_6 g_1158 g_179 g_267 g_2032 g_1879 g_3390 g_201 g_3388 g_82 g_4782 g_122 g_4450 g_91 g_2949 g_3421 g_119 g_65 g_4079 g_1808 g_3031 g_3356
 */
static int32_t  func_2(uint8_t  p_3, uint64_t  p_4, uint8_t  p_5)
{ /* block id: 2148 */
    int32_t l_4577 = 0x0B14652AL;
    union U0 l_4578 = {7L};
    union U0 **l_4579 = (void*)0;
    int32_t *l_4580 = &g_197[3];
    int32_t l_4657[7] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    const int32_t *l_4691 = &g_4692[0];
    int32_t l_4734 = 1L;
    uint32_t ****l_4736[7][10] = {{(void*)0,&g_3836[0],&g_3836[3],&g_3836[4],&g_3836[3],&g_3836[3],&g_3836[4],&g_3836[3],&g_3836[0],(void*)0},{&g_3836[2],&g_3836[3],&g_3836[3],&g_3836[3],&g_3836[3],&g_3836[3],&g_3836[4],&g_3836[0],&g_3836[0],&g_3836[4]},{&g_3836[4],&g_3836[1],&g_3836[3],&g_3836[3],&g_3836[3],&g_3836[3],&g_3836[3],&g_3836[1],&g_3836[4],(void*)0},{&g_3836[3],&g_3836[4],&g_3836[2],(void*)0,&g_3836[3],&g_3836[4],&g_3836[3],(void*)0,&g_3836[3],&g_3836[3]},{&g_3836[2],&g_3836[3],&g_3836[0],(void*)0,(void*)0,&g_3836[0],&g_3836[3],&g_3836[2],&g_3836[4],&g_3836[4]},{&g_3836[3],(void*)0,&g_3836[1],&g_3836[3],&g_3836[2],&g_3836[3],(void*)0,&g_3836[1],&g_3836[3],&g_3836[1]},{&g_3836[0],&g_3836[1],&g_3836[1],&g_3836[2],&g_3836[1],&g_3836[1],&g_3836[0],&g_3836[3],&g_3836[0],(void*)0}};
    uint32_t ***** const l_4735[7][4] = {{&l_4736[1][1],(void*)0,&l_4736[6][6],(void*)0},{(void*)0,(void*)0,&l_4736[6][6],&l_4736[6][6]},{&l_4736[1][1],&l_4736[1][1],(void*)0,&l_4736[6][6]},{&l_4736[1][1],(void*)0,&l_4736[1][1],(void*)0},{&l_4736[1][1],(void*)0,(void*)0,&l_4736[1][1]},{&l_4736[1][1],(void*)0,&l_4736[6][6],(void*)0},{(void*)0,(void*)0,&l_4736[6][6],&l_4736[6][6]}};
    int64_t *l_4816 = &g_201[1][1][7];
    int8_t l_4845 = 0x52L;
    int32_t l_4850[6][3][4] = {{{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-2L),(-1L),(-1L),(-2L)}}};
    uint16_t l_4851 = 0xC677L;
    uint16_t l_4913 = 0xE668L;
    int64_t l_5011 = 0x89E35F466C72992ALL;
    int i, j, k;
lbl_4979:
    if (((-2L) != (safe_sub_func_int32_t_s_s((safe_add_func_uint32_t_u_u(l_4577, (((l_4578 , l_4579) == l_4579) , ((*l_4580) = 0x5D9E9D7CL)))), ((safe_rshift_func_int32_t_s_u((-9L), 11)) != (~((safe_rshift_func_int64_t_s_u(((((safe_div_func_int8_t_s_s((safe_add_func_uint16_t_u_u((249UL <= (safe_div_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u((*g_1016), p_4)), 0x45L))), 0L)), l_4578.f0)) & (-1L)) & 0x57440FDBA4FFF473LL) , 0L), 28)) != 2L)))))))
    { /* block id: 2150 */
        int32_t *l_4601 = &g_3388;
        const uint8_t ****l_4617 = (void*)0;
        uint32_t l_4640 = 1UL;
        int32_t l_4655 = (-3L);
        int32_t l_4664 = 1L;
        int32_t l_4676 = 0x3FEE7D7FL;
        int32_t l_4678 = 0x67DC65D6L;
        int32_t l_4679 = 0L;
        int32_t l_4680[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
        int32_t * const l_4695 = &g_2641;
        uint8_t **l_4731 = &g_2010;
        int32_t *l_4779 = &l_4657[4];
        int32_t *l_4780[9][8][3] = {{{&g_3388,(void*)0,(void*)0},{&g_197[3],(void*)0,&g_197[3]},{&g_6,&l_4657[6],&g_3388},{&g_197[3],&g_4571,&l_4680[1]},{&g_3388,(void*)0,&l_4680[6]},{&g_4571,&g_122,&g_197[3]},{&g_3388,&l_4657[6],(void*)0},{&g_197[3],&l_4679,&g_4571}},{{&g_6,(void*)0,&l_4679},{&g_197[3],&l_4676,&g_3388},{&g_3388,&g_6,&g_3388},{&g_4571,&g_4571,(void*)0},{&g_3388,&l_4657[6],&l_4655},{&g_197[3],(void*)0,&g_3421},{&g_6,(void*)0,(void*)0},{&g_197[3],(void*)0,&g_65}},{{&g_3388,&g_65,&g_6},{&g_4571,&g_197[0],(void*)0},{&g_3388,(void*)0,(void*)0},{&g_197[3],(void*)0,&g_197[3]},{&g_6,&l_4657[6],&g_3388},{&g_197[3],&g_4571,&l_4680[1]},{&g_3388,&l_4679,&l_4657[6]},{&l_4680[6],(void*)0,&l_4678}},{{&l_4678,(void*)0,&l_4676},{&l_4680[6],&g_4571,&l_4680[6]},{(void*)0,&l_4680[6],(void*)0},{&l_4680[6],&g_197[3],&l_4680[0]},{&l_4678,&g_3388,&l_4678},{&l_4680[6],&l_4657[0],&l_4680[5]},{&l_4678,(void*)0,&g_3031},{&l_4680[6],&l_4655,&g_6}},{{(void*)0,&g_6,&l_4664},{&l_4680[6],(void*)0,&g_4571},{&l_4678,(void*)0,(void*)0},{&l_4680[6],&g_3421,&g_3388},{&l_4678,&l_4655,&l_4664},{&l_4680[6],&l_4678,&l_4680[6]},{(void*)0,&g_3388,(void*)0},{&l_4680[6],&g_3421,&l_4657[6]}},{{&l_4678,&l_4679,&l_4657[6]},{&l_4680[6],(void*)0,&l_4678},{&l_4678,(void*)0,&l_4676},{&l_4680[6],&g_4571,&l_4680[6]},{(void*)0,&l_4680[6],(void*)0},{&l_4680[6],&g_197[3],&l_4680[0]},{&l_4678,&g_3388,&l_4678},{&l_4680[6],&l_4657[0],&l_4680[5]}},{{&l_4678,(void*)0,&g_3031},{&l_4680[6],&l_4655,&g_6},{(void*)0,&g_6,&l_4664},{&l_4680[6],(void*)0,&g_4571},{&l_4678,(void*)0,(void*)0},{&l_4680[6],&g_3421,&g_3388},{&l_4678,&l_4655,&l_4664},{&l_4680[6],&l_4678,&l_4680[6]}},{{(void*)0,&g_3388,(void*)0},{&l_4680[6],&g_3421,&l_4657[6]},{&l_4678,&l_4679,&l_4657[6]},{&l_4680[6],(void*)0,&l_4678},{&l_4678,(void*)0,&l_4676},{&l_4680[6],&g_4571,&l_4680[6]},{(void*)0,&l_4680[6],(void*)0},{&l_4680[6],&g_197[3],&l_4680[0]}},{{&l_4678,&g_3388,&l_4678},{&l_4680[6],&l_4657[0],&l_4680[5]},{&l_4678,(void*)0,&g_3031},{&l_4680[6],&l_4655,&g_6},{(void*)0,&g_6,&l_4664},{&l_4680[6],(void*)0,&g_4571},{&l_4678,(void*)0,(void*)0},{&l_4680[6],&g_3421,&g_3388}}};
        int32_t l_4781 = 0xCD07FCC6L;
        int i, j, k;
        (*l_4580) &= (p_3 == p_5);
lbl_4596:
        (*l_4580) ^= (*g_4191);
        for (g_2641 = (-21); (g_2641 != (-21)); g_2641 = safe_add_func_int64_t_s_s(g_2641, 3))
        { /* block id: 2155 */
            int64_t *****l_4597 = &g_1845;
            int32_t l_4607 = (-1L);
            int16_t **l_4627 = &g_514;
            int16_t ** const *l_4626 = &l_4627;
            int16_t ** const **l_4625[10][4][1] = {{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}},{{&l_4626},{&l_4626},{&l_4626},{&l_4626}}};
            int16_t ** const ***l_4624 = &l_4625[1][0][0];
            uint32_t l_4638 = 0x68736338L;
            uint64_t ****l_4642 = &g_3869;
            int32_t l_4666 = (-10L);
            int32_t l_4667 = 0x9E89A858L;
            int32_t l_4668 = 0x31B998ACL;
            int32_t l_4669 = 1L;
            int32_t l_4671 = 0x532AC928L;
            int32_t l_4672 = 1L;
            int32_t l_4677 = 9L;
            uint8_t l_4684 = 0x2EL;
            const int32_t *l_4694 = &g_4692[0];
            const int32_t **l_4693 = &l_4694;
            uint16_t *l_4723 = &g_600;
            uint32_t **l_4748 = (void*)0;
            uint32_t l_4776 = 4294967292UL;
            int i, j, k;
            if (g_3388)
                goto lbl_4596;
            if ((l_4597 != (g_4598[5] = &g_1845)))
            { /* block id: 2158 */
                int32_t *l_4602 = &g_3031;
                uint16_t *l_4608 = &g_600;
                l_4602 = l_4601;
                (*g_4618) |= (safe_rshift_func_int16_t_s_u(((safe_div_func_uint8_t_u_u(l_4607, ((--(*l_4608)) & 3L))) != ((((((*****g_2081) = (*l_4580)) & (safe_sub_func_uint64_t_u_u(p_3, (-10L)))) >= ((*g_2081) == (((safe_lshift_func_int8_t_s_s(0xD5L, (safe_sub_func_uint32_t_u_u((*l_4601), l_4607)))) || p_3) , l_4617))) , 2L) < 0x64EFL)), g_28.f0));
                return (*l_4602);
            }
            else
            { /* block id: 2164 */
                int32_t **l_4619 = &g_1158[4][0];
                uint64_t l_4620 = 0x06A777E9B69CA01CLL;
                int32_t l_4639 = (-7L);
                uint64_t ****l_4643[7];
                int32_t l_4670 = (-1L);
                int32_t l_4675[2][3][8] = {{{1L,(-1L),1L,0xA4C9589AL,0x06398915L,1L,0x06398915L,0xA4C9589AL},{1L,0xA4C9589AL,1L,0xCB9C286DL,0xA4C9589AL,0xA5188A24L,0xA5188A24L,0xA4C9589AL},{0xA4C9589AL,0xA5188A24L,0xA5188A24L,0xA4C9589AL,0xCB9C286DL,1L,0xA4C9589AL,1L}},{{0xA4C9589AL,0x06398915L,1L,0x06398915L,0xA4C9589AL,1L,(-1L),(-1L)},{1L,0x06398915L,0xCB9C286DL,0xCB9C286DL,0x06398915L,1L,0xA5188A24L,0x06398915L},{(-1L),0xA5188A24L,0xCB9C286DL,(-1L),0xCB9C286DL,0xA5188A24L,(-1L),1L}}};
                uint32_t l_4681 = 0UL;
                int i, j, k;
                for (i = 0; i < 7; i++)
                    l_4643[i] = (void*)0;
                (*l_4619) = &l_4607;
                for (g_179 = 0; (g_179 <= 1); g_179 += 1)
                { /* block id: 2168 */
                    uint16_t *l_4641 = &g_267;
                    int32_t l_4648 = 0x2FD5AA54L;
                    int64_t l_4656 = 0x8E5C6F9AD18978B3LL;
                    int32_t l_4658[4] = {1L,1L,1L,1L};
                    int32_t l_4662[5][10] = {{0x339ED079L,(-8L),0x3FD80EB1L,0L,0xFF70844DL,0x8523AFC1L,0x3250D835L,0xFFFB4E31L,(-1L),1L},{0xDF42E41BL,8L,0x0C29B9BEL,0L,(-1L),9L,9L,(-1L),0L,0x0C29B9BEL},{0xFFFB4E31L,0xFFFB4E31L,0x9546B73BL,0x339ED079L,8L,2L,0xFF70844DL,0x618A3FFFL,5L,0L},{(-8L),0x618A3FFFL,0x3250D835L,0xDF42E41BL,9L,5L,0xFF70844DL,0x339ED079L,0xFF70844DL,5L},{0L,0xFFFB4E31L,0xDF42E41BL,0xFFFB4E31L,0L,0x3250D835L,9L,0x28708806L,8L,0x9546B73BL}};
                    int32_t l_4663 = 0xBA1E7EBEL;
                    int i, j;
                    if (l_4620)
                        break;
                    g_197[(g_179 + 2)] = (safe_div_func_int64_t_s_s((((((+((((((l_4624 = l_4624) == (void*)0) ^ (*l_4601)) , 0x55L) && (p_5 ^ p_5)) > ((*l_4641) = ((safe_lshift_func_uint64_t_u_u((((p_5 , (((!(*l_4580)) ^ (((safe_mul_func_uint32_t_u_u(((+(safe_div_func_uint16_t_u_u(((*l_4601) || 1UL), (*l_4601)))) > 0x6618L), (*l_4580))) < l_4638) == l_4607)) , 6UL)) != p_4) ^ 0x9352L), l_4639)) && l_4640)))) , (*l_4580)) , l_4642) != l_4643[3]) != p_4), p_4));
                    for (g_2032 = (-11); (g_2032 <= 54); g_2032 = safe_add_func_uint16_t_u_u(g_2032, 5))
                    { /* block id: 2175 */
                        int32_t *l_4646 = &g_197[0];
                        int32_t *l_4647 = &g_3421;
                        int32_t *l_4649 = &g_197[3];
                        int32_t *l_4650 = &g_3031;
                        int32_t *l_4651 = &g_3031;
                        int32_t *l_4652 = &g_197[(g_179 + 2)];
                        int32_t *l_4653 = &g_6;
                        int32_t *l_4654[4][7] = {{&g_197[0],&g_3031,&l_4607,&g_3421,&l_4607,&g_3031,&g_197[0]},{&g_122,&g_197[3],&g_197[3],(void*)0,&g_3421,&g_197[3],&g_197[0]},{&g_3421,&g_197[0],&l_4648,&l_4648,&g_197[0],&g_3421,&g_122},{&g_3031,&l_4648,&g_197[3],&g_122,&g_197[3],&g_3421,&g_3421}};
                        uint32_t l_4659 = 1UL;
                        int32_t l_4665[10][4] = {{0x635EB218L,0x77943FBEL,0x68083C85L,0x635EB218L},{0x4DD402A0L,0x9892204BL,0x4DD402A0L,0x68083C85L},{1L,0x9892204BL,0xA7E8A849L,0x635EB218L},{0x9892204BL,0x77943FBEL,0x77943FBEL,0x9892204BL},{0x4DD402A0L,0x635EB218L,0x77943FBEL,0x68083C85L},{0x9892204BL,1L,0xA7E8A849L,1L},{1L,0x77943FBEL,0x4DD402A0L,1L},{0x4DD402A0L,1L,0x68083C85L,0x68083C85L},{0x635EB218L,0x635EB218L,0xA7E8A849L,0x9892204BL},{0x635EB218L,0x77943FBEL,0x68083C85L,0x635EB218L}};
                        int8_t l_4674 = (-5L);
                        int i, j;
                        --l_4659;
                        l_4681--;
                        l_4684++;
                        (*l_4646) = 0x66164D3EL;
                    }
                }
                (*l_4619) = &l_4655;
            }
            if ((safe_rshift_func_uint8_t_u_s((*l_4601), ((*g_1878) = (safe_rshift_func_int16_t_s_u((7L && (((*l_4693) = (l_4691 = &l_4577)) != l_4695)), 13))))))
            { /* block id: 2187 */
                union U0 l_4696 = {0xD4D6958B0C90E81ELL};
                int32_t l_4699 = 0xC965EC95L;
                l_4699 = ((*l_4580) |= ((*l_4601) > (l_4696 , (safe_mod_func_uint16_t_u_u(l_4696.f0, (-1L))))));
            }
            else
            { /* block id: 2190 */
                uint32_t l_4712 = 4294967292UL;
                uint32_t l_4726 = 4294967287UL;
                uint16_t l_4733[9] = {3UL,3UL,3UL,3UL,3UL,3UL,3UL,3UL,3UL};
                uint32_t *****l_4737 = &l_4736[1][1];
                uint32_t l_4754 = 5UL;
                int32_t l_4769 = 0xDD8CD14DL;
                int8_t l_4775[4] = {0L,0L,0L,0L};
                int i;
                if ((p_3 , (safe_rshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_u((*l_4580), (****g_2007))), 5))))
                { /* block id: 2191 */
                    for (l_4638 = 0; (l_4638 <= 0); l_4638 += 1)
                    { /* block id: 2194 */
                        uint16_t *l_4722[9] = {&g_3390,&g_3390,&g_3390,&g_3390,&g_3390,&g_3390,&g_3390,&g_3390,&g_3390};
                        uint16_t **l_4721 = &l_4722[3];
                        uint16_t *l_4724 = &g_3390;
                        int32_t l_4725 = 0L;
                        int i, j;
                        (*l_4601) ^= ((*l_4580) = (((safe_add_func_uint16_t_u_u(((g_503[(l_4638 + 3)][l_4638] != (***g_2081)) > (safe_add_func_uint64_t_u_u(((safe_add_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((**g_2578) ^= (((-6L) < (l_4712 == (safe_sub_func_int16_t_s_s((safe_mul_func_int8_t_s_s((p_4 >= (((safe_mod_func_uint16_t_u_u((safe_add_func_int8_t_s_s((((*l_4724) |= (((((l_4723 = ((*l_4721) = &g_179)) != (l_4712 , &g_2844)) < p_3) , 1L) ^ 0x1B5ECE1DA0A9C2C1LL)) > 0xDEA5L), 0xFDL)), l_4668)) , g_4450) || g_506)), p_5)), l_4725)))) > 1UL)), (-10L))), g_122)) | p_3), l_4712))), l_4726)) , (*g_1878)) > p_3));
                    }
                }
                else
                { /* block id: 2202 */
                    uint16_t l_4744 = 65535UL;
                    int32_t l_4751 = 0x9D9FB168L;
                    if ((safe_add_func_int32_t_s_s((l_4733[0] ^= (l_4726 & (((safe_mod_func_uint16_t_u_u((((****g_2082) ^ 0xD9L) | ((*****g_2081) != (p_5 = ((l_4731 == (void*)0) ^ ((+(0x10288DB0L && (p_4 , ((p_5 == (*l_4601)) >= (*l_4580))))) & 0x8D22C9B9D7CA3E4BLL))))), 0xB91CL)) == p_4) < (**g_2578)))), (-1L))))
                    { /* block id: 2205 */
                        if (l_4734)
                            break;
                    }
                    else
                    { /* block id: 2207 */
                        int8_t l_4745 = (-1L);
                        l_4737 = l_4735[2][0];
                        (*l_4601) |= ((((safe_add_func_int16_t_s_s((1L >= ((safe_mul_func_uint16_t_u_u(((((**l_4731) = (safe_rshift_func_uint64_t_u_s(l_4744, 61))) == l_4745) , (safe_lshift_func_int64_t_s_s(((**g_2578) = 0x26F34AAA58609FF9LL), 56))), 0L)) | (((((*g_2027) != (l_4748 = l_4748)) < (safe_mod_func_int8_t_s_s(p_3, 0x30L))) , l_4745) && 8UL))), (*g_513))) == (*g_1878)) , p_4) == (*l_4580));
                    }
                    l_4751 |= 4L;
                }
                if (((safe_mul_func_uint64_t_u_u(p_5, ((**g_248) = l_4666))) || l_4754))
                { /* block id: 2217 */
                    uint16_t l_4767 = 65535UL;
                    int32_t *l_4768 = &g_1931;
                    l_4769 = ((safe_sub_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u(((*g_513) | (safe_mul_func_int64_t_s_s((p_4 <= (safe_rshift_func_int16_t_s_u(((*l_4580) >= (l_4601 != ((safe_mul_func_uint16_t_u_u((((*l_4601) &= ((((p_3 , 0x99L) <= (~(!(&g_3836[2] != (p_4 , &g_3836[3]))))) && p_5) > p_3)) <= 0x0ED39742L), l_4767)) , l_4768))), 11))), (-1L)))), p_4)) == 1UL), p_5)) & l_4767);
                    if ((*l_4601))
                        break;
                    if (l_4672)
                        break;
                    if (p_3)
                        break;
                }
                else
                { /* block id: 2223 */
                    int32_t *l_4770 = &l_4680[2];
                    int32_t *l_4771 = &g_3031;
                    int32_t *l_4772 = &l_4664;
                    int32_t *l_4773 = &g_4571;
                    int32_t *l_4774[7][3][9];
                    int i, j, k;
                    for (i = 0; i < 7; i++)
                    {
                        for (j = 0; j < 3; j++)
                        {
                            for (k = 0; k < 9; k++)
                                l_4774[i][j][k] = &g_65;
                        }
                    }
                    l_4776--;
                }
            }
        }
        g_4782--;
    }
    else
    { /* block id: 2229 */
        const uint16_t *l_4794 = &g_2844;
        const uint16_t **l_4793 = &l_4794;
        int32_t l_4797 = (-1L);
        int32_t l_4800 = 8L;
        int32_t l_4801 = 0x866F96BFL;
        int64_t l_4807 = 6L;
        int16_t l_4842 = 1L;
        (*g_4802) |= (safe_add_func_int8_t_s_s((*l_4580), ((((safe_mul_func_int16_t_s_s(((((safe_lshift_func_int8_t_s_u((safe_mod_func_int16_t_s_s((*l_4580), 0xE53BL)), 5)) , l_4793) != (void*)0) & p_4), p_5)) > (safe_mod_func_uint16_t_u_u((l_4797 = p_3), (safe_rshift_func_int8_t_s_u(((5UL && p_4) != l_4800), 4))))) ^ l_4801) | p_3)));
        for (l_4800 = 0; (l_4800 <= 0); l_4800 = safe_add_func_int16_t_s_s(l_4800, 5))
        { /* block id: 2234 */
            uint32_t *l_4808 = &g_4450;
            int64_t *l_4817 = (void*)0;
            int16_t **l_4821 = &g_514;
            int16_t ***l_4820 = &l_4821;
            int16_t *** const *l_4819 = &l_4820;
            int8_t l_4822 = 8L;
            l_4657[6] |= (safe_add_func_uint8_t_u_u((((*l_4808) &= l_4807) == (safe_rshift_func_int8_t_s_u(((((***g_3869) = (+(safe_mul_func_int8_t_s_s(0xEAL, (**g_1015))))) ^ (safe_mod_func_uint8_t_u_u(((p_3 , l_4816) == (p_3 , l_4817)), ((p_4 | ((((+((*g_2010) &= (l_4819 == (void*)0))) ^ (*l_4580)) > (*l_4580)) == (*l_4580))) | 65535UL)))) ^ l_4801), l_4822))), p_3));
            l_4801 |= ((((+((((safe_lshift_func_uint16_t_u_u(p_3, 6)) && 18446744073709551614UL) != (safe_div_func_uint32_t_u_u((((!(safe_div_func_int32_t_s_s((safe_add_func_int8_t_s_s((safe_rshift_func_uint32_t_u_u(((((*g_513) &= (~(((1L && l_4822) < (safe_lshift_func_int64_t_s_s((*g_521), (safe_rshift_func_int32_t_s_s(((safe_sub_func_int32_t_s_s(l_4842, (-8L))) && 2L), (safe_mul_func_int16_t_s_s(((l_4845 != (-3L)) == 0L), (*l_4580)))))))) == p_3))) <= 0UL) != g_186[2][6]), 15)), 1UL)), (*l_4580)))) ^ l_4797) >= l_4822), p_3))) > 0x9E6B75C3L)) , (void*)0) != (void*)0) | (-1L));
        }
    }
    for (g_267 = (-21); (g_267 == 58); g_267 = safe_add_func_int64_t_s_s(g_267, 8))
    { /* block id: 2245 */
        int64_t l_4848[2];
        int32_t *l_4849[7][3][2] = {{{(void*)0,(void*)0},{&g_3421,&l_4657[1]},{&l_4657[1],&g_122}},{{(void*)0,&g_65},{&g_122,&g_65},{(void*)0,&g_122}},{{&l_4657[1],&l_4657[1]},{&g_3421,(void*)0},{(void*)0,&g_3421}},{{(void*)0,&g_65},{&g_65,(void*)0},{&l_4657[1],&g_3421}},{{&l_4657[1],(void*)0},{&g_65,&g_65},{(void*)0,&g_3421}},{{(void*)0,(void*)0},{&g_3421,&l_4657[1]},{&l_4657[1],&g_122}},{{(void*)0,&g_65},{&g_122,&g_65},{(void*)0,&g_122}}};
        uint64_t **l_4871[5][8][4] = {{{(void*)0,&g_249[5],(void*)0,&g_249[5]},{(void*)0,&g_249[4],&g_249[5],(void*)0},{(void*)0,(void*)0,(void*)0,&g_249[2]},{(void*)0,&g_249[5],(void*)0,(void*)0},{&g_249[5],&g_249[5],&g_249[2],(void*)0},{&g_249[5],(void*)0,&g_249[5],&g_249[5]},{&g_249[5],&g_249[1],(void*)0,&g_249[5]},{&g_249[5],(void*)0,(void*)0,&g_249[5]}},{{&g_249[5],(void*)0,&g_249[6],&g_249[3]},{(void*)0,(void*)0,&g_249[5],(void*)0},{&g_249[5],&g_249[4],&g_249[5],(void*)0},{&g_249[5],(void*)0,&g_249[5],&g_249[3]},{(void*)0,(void*)0,(void*)0,&g_249[5]},{&g_249[5],(void*)0,&g_249[4],&g_249[5]},{&g_249[5],&g_249[1],(void*)0,&g_249[5]},{(void*)0,(void*)0,&g_249[5],(void*)0}},{{&g_249[2],&g_249[5],&g_249[5],(void*)0},{&g_249[5],&g_249[5],&g_249[5],&g_249[2]},{&g_249[5],(void*)0,&g_249[5],(void*)0},{(void*)0,&g_249[4],&g_249[6],&g_249[5]},{(void*)0,&g_249[5],&g_249[5],(void*)0},{&g_249[2],&g_249[4],&g_249[2],&g_249[5]},{&g_249[5],(void*)0,(void*)0,&g_249[4]},{(void*)0,(void*)0,&g_249[4],(void*)0}},{{(void*)0,(void*)0,&g_249[4],&g_249[2]},{(void*)0,&g_249[3],(void*)0,&g_249[5]},{&g_249[5],&g_249[5],&g_249[2],(void*)0},{&g_249[2],(void*)0,&g_249[5],&g_249[5]},{(void*)0,&g_249[5],&g_249[6],&g_249[5]},{(void*)0,(void*)0,&g_249[5],&g_249[4]},{&g_249[5],&g_249[5],&g_249[5],&g_249[5]},{&g_249[5],(void*)0,&g_249[5],&g_249[5]}},{{&g_249[2],&g_249[5],&g_249[5],&g_249[6]},{(void*)0,(void*)0,(void*)0,&g_249[3]},{&g_249[5],&g_249[4],&g_249[4],&g_249[4]},{&g_249[5],&g_249[5],(void*)0,&g_249[2]},{(void*)0,&g_249[1],&g_249[5],(void*)0},{&g_249[5],(void*)0,&g_249[5],&g_249[5]},{(void*)0,(void*)0,(void*)0,&g_249[5]},{(void*)0,(void*)0,&g_249[4],&g_249[4]}}};
        int32_t l_4934 = 1L;
        union U0 ** const *l_4974 = &g_291[2];
        union U0 ** const **l_4973[10] = {&l_4974,&l_4974,&l_4974,&l_4974,&l_4974,&l_4974,&l_4974,&l_4974,&l_4974,&l_4974};
        int32_t l_4978 = 0x918F656FL;
        uint16_t l_4980 = 65535UL;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_4848[i] = 0xBCCE3A34EDBC2C95LL;
        l_4851++;
        if (p_5)
            break;
        for (g_2949 = 1; (g_2949 >= 0); g_2949 -= 1)
        { /* block id: 2250 */
            int32_t *l_4854 = &g_6;
            int32_t l_4865[2];
            int64_t *l_4931 = &g_186[1][5];
            uint8_t *l_4936[8] = {&g_2541[3],&g_2541[1],&g_2541[3],&g_2541[3],&g_2541[1],&g_2541[3],&g_2541[3],&g_2541[1]};
            uint64_t *l_4945 = &g_1971;
            uint32_t *l_4949[7] = {&g_3708[2][8][0],&g_296,&g_296,&g_3708[2][8][0],&g_296,&g_296,&g_3708[2][8][0]};
            uint8_t ****l_4962 = (void*)0;
            uint8_t *****l_4961 = &l_4962;
            int i;
            for (i = 0; i < 2; i++)
                l_4865[i] = 0x9C8EC2B2L;
            l_4854 = l_4849[1][1][1];
            for (g_3421 = 0; (g_3421 <= 1); g_3421 += 1)
            { /* block id: 2254 */
                uint32_t *l_4859 = (void*)0;
                uint32_t *l_4860 = &g_119;
                uint16_t *l_4861 = (void*)0;
                uint16_t *l_4862 = (void*)0;
                uint16_t *l_4863 = &g_179;
                int32_t l_4867 = (-9L);
                uint64_t **l_4872 = &g_249[6];
                int32_t l_4894 = 0xBBF643D7L;
                uint32_t l_4935 = 9UL;
                int32_t *l_4948 = (void*)0;
                int32_t ** const *l_4960[6];
                int32_t ** const **l_4959 = &l_4960[1];
                int32_t ** const ***l_4958 = &l_4959;
                union U0 l_4965 = {0L};
                int i;
                for (i = 0; i < 6; i++)
                    l_4960[i] = &g_1157[2];
                if (l_4848[g_3421])
                    break;
                if ((((((*l_4863) ^= (p_5 & (((*l_4860) = (safe_add_func_uint16_t_u_u(0x9028L, (safe_mul_func_int8_t_s_s((*g_1878), (**g_1015)))))) || p_3))) > p_4) != p_3) >= ((*l_4580) <= p_3)))
                { /* block id: 2258 */
                    int32_t l_4864 = 0L;
                    int32_t l_4866[7];
                    uint64_t l_4868 = 0x685BBF0F2462A526LL;
                    int i;
                    for (i = 0; i < 7; i++)
                        l_4866[i] = 0x341FC63CL;
                    if (p_4)
                    { /* block id: 2259 */
                        if (l_4848[g_3421])
                            break;
                        if (p_4)
                            break;
                    }
                    else
                    { /* block id: 2262 */
                        (*l_4580) = 0xA665EF3DL;
                        (*l_4580) ^= p_4;
                    }
                    l_4868++;
                }
                else
                { /* block id: 2267 */
                    int64_t l_4893 = 3L;
                    l_4894 ^= (((l_4872 = l_4871[1][7][2]) != ((safe_add_func_uint64_t_u_u(((*l_4580) |= p_3), (safe_div_func_int32_t_s_s((safe_mod_func_int64_t_s_s((-1L), (safe_mul_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u(((*****g_2081) = (safe_mul_func_int32_t_s_s((safe_add_func_int8_t_s_s((safe_rshift_func_uint32_t_u_s(4294967286UL, (((*g_1878) , (((safe_add_func_uint16_t_u_u(0xB230L, (((0xE8L == (safe_rshift_func_uint8_t_u_s(((~(p_4 , ((p_3 <= (-5L)) ^ (-1L)))) <= p_5), p_4))) && p_4) , p_4))) , l_4848[g_3421]) & (-10L))) != l_4867))), (***g_2008))), (-1L)))))), p_3)))), l_4893)))) , l_4871[0][2][0])) ^ 0x1C0B86A8L);
                }
                for (g_65 = 3; (g_65 >= 0); g_65 -= 1)
                { /* block id: 2275 */
                    uint32_t l_4916 = 0x5BE2BBA7L;
                    int32_t *l_4946[2];
                    int32_t ***l_4957[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int32_t ****l_4956[4][8] = {{&l_4957[8],&l_4957[8],(void*)0,(void*)0,&l_4957[8],&l_4957[8],&l_4957[4],&l_4957[8]},{&l_4957[8],&l_4957[4],(void*)0,&l_4957[8],(void*)0,&l_4957[4],&l_4957[8],&l_4957[8]},{&l_4957[8],&l_4957[6],(void*)0,&l_4957[8],&l_4957[8],(void*)0,&l_4957[6],&l_4957[8]},{&l_4957[8],&l_4957[8],&l_4957[4],(void*)0,&l_4957[8],(void*)0,&l_4957[4],&l_4957[8]}};
                    int32_t *****l_4955 = &l_4956[0][1];
                    int32_t ** const **l_4971 = (void*)0;
                    int32_t ** const ***l_4970 = &l_4971;
                    int i, j;
                    for (i = 0; i < 2; i++)
                        l_4946[i] = &g_4571;
                }
                if (g_179)
                    goto lbl_4979;
            }
            l_4980 ^= (((*g_513) & g_1300) , p_4);
        }
        for (g_4079 = 0; (g_4079 == 37); g_4079 = safe_add_func_int8_t_s_s(g_4079, 2))
        { /* block id: 2314 */
            int32_t l_4990 = 0x5B69BEE2L;
            int32_t * const * const *l_5005[7];
            int32_t * const * const **l_5004[3][10] = {{&l_5005[6],&l_5005[5],(void*)0,(void*)0,(void*)0,(void*)0,&l_5005[5],&l_5005[6],&l_5005[5],(void*)0},{(void*)0,&l_5005[5],(void*)0,&l_5005[5],(void*)0,(void*)0,(void*)0,(void*)0,&l_5005[5],(void*)0},{&l_5005[6],&l_5005[6],(void*)0,(void*)0,&l_5005[2],(void*)0,(void*)0,&l_5005[6],&l_5005[6],(void*)0}};
            int32_t * const * const ***l_5003[5][5] = {{&l_5004[1][1],&l_5004[1][1],&l_5004[1][1],&l_5004[1][1],&l_5004[1][1]},{&l_5004[1][5],&l_5004[2][2],&l_5004[1][5],&l_5004[2][2],&l_5004[1][5]},{&l_5004[1][1],&l_5004[1][1],&l_5004[1][1],&l_5004[1][1],&l_5004[1][1]},{&l_5004[1][5],&l_5004[2][2],&l_5004[1][5],&l_5004[2][2],&l_5004[1][5]},{&l_5004[1][1],&l_5004[1][1],&l_5004[1][1],&l_5004[1][1],&l_5004[1][1]}};
            int i, j;
            for (i = 0; i < 7; i++)
                l_5005[i] = (void*)0;
            for (g_3390 = (-20); (g_3390 >= 6); g_3390++)
            { /* block id: 2317 */
                int32_t *l_4985 = &g_197[2];
                int32_t **l_4986 = (void*)0;
                (*g_4987) = l_4985;
                (*l_4580) ^= 1L;
                return (*g_4802);
            }
            if (p_3)
                continue;
            for (g_1808 = 3; (g_1808 >= 0); g_1808 -= 1)
            { /* block id: 2325 */
                int32_t *** const *l_5007 = &g_3789;
                int32_t *** const **l_5006 = &l_5007;
                int32_t * const l_5009 = &g_2641;
                int32_t * const *l_5008 = &l_5009;
                uint32_t *l_5010[8] = {(void*)0,&g_119,(void*)0,(void*)0,&g_119,(void*)0,(void*)0,&g_119};
                int8_t *l_5012[5][2] = {{&g_202,&g_202},{&g_202,&g_202},{&g_202,&g_202},{&g_202,&g_202},{&g_202,&g_202}};
                int32_t l_5013 = 0xE79E0901L;
                int i, j;
                for (g_3031 = 0; (g_3031 <= 1); g_3031 += 1)
                { /* block id: 2328 */
                    int i;
                    if (g_197[g_1808])
                        break;
                }
                (*l_4580) = ((((((((l_4990 | ((*l_4580) == (safe_div_func_uint32_t_u_u(((safe_rshift_func_int64_t_s_u((safe_unary_minus_func_uint64_t_u(((safe_add_func_uint8_t_u_u((safe_rshift_func_int32_t_s_u((l_4990 > ((l_5013 = (((((**g_2578) = ((g_3356 &= ((*g_1878) = ((((((safe_rshift_func_int32_t_s_s(0L, 22)) , (*l_4580)) , p_5) == ((~(l_5003[4][1] != l_5006)) >= (l_5011 = (((*l_4580) , l_5008) == &l_4691)))) | l_4990) <= 0x795B0898L))) != p_3)) && l_5013) | l_5013) | (*****g_2081))) , l_4990)), p_5)), (****g_2082))) , (*l_4580)))), 52)) , 4294967295UL), p_3)))) && 0x29L) >= p_4) || p_3) < l_4990) ^ p_3) <= 1L) | l_4990);
            }
        }
    }
    return (*l_4580);
}


/* ------------------------------------------ */
/* 
 * reads : g_3869 g_248 g_249 g_513 g_91 g_2081 g_2082 g_2008 g_2009 g_2010 g_1878 g_811.f0 g_82 g_2641 g_1879 g_2460 g_2461 g_2462 g_3989 g_65 g_3838 g_1096 g_1097 g_4079 g_2579 g_201 g_506 g_267 g_4140 g_1931 g_2578 g_197 g_1015 g_1016 g_1017 g_521 g_522 g_4191 g_3388 g_1845 g_235 g_4246 g_600 g_2202 g_234 g_3800 g_143 g_122 g_2541 g_3421 g_1844 g_3708 g_4450 g_4480 g_296 g_3031 g_213 g_4571 g_635 g_1808 g_2431 g_1971 g_119
 * writes: g_82 g_91 g_506 g_1879 g_811.f0 g_179 g_2641 g_1157 g_65 g_635 g_3708 g_4079 g_267 g_201 g_1931 g_3388 g_235 g_4249 g_1808 g_1158 g_600 g_2844 g_2431 g_3356 g_3421 g_1971 g_296 g_119 g_4450 g_3390 g_887 g_3031 g_122 g_2541 g_3869 g_2949
 */
static uint64_t  func_7(uint32_t  p_8, int8_t  p_9, uint8_t  p_10, uint64_t  p_11, uint32_t  p_12)
{ /* block id: 1792 */
    uint8_t l_3933 = 0xD7L;
    int32_t l_3949 = 0x390FE5A2L;
    uint8_t l_3950[5] = {8UL,8UL,8UL,8UL,8UL};
    const uint32_t *l_3954 = (void*)0;
    const uint32_t **l_3953[9][9] = {{&l_3954,&l_3954,(void*)0,&l_3954,(void*)0,&l_3954,&l_3954,&l_3954,(void*)0},{(void*)0,&l_3954,&l_3954,(void*)0,&l_3954,&l_3954,&l_3954,(void*)0,(void*)0},{&l_3954,(void*)0,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954},{&l_3954,&l_3954,(void*)0,&l_3954,&l_3954,(void*)0,&l_3954,&l_3954,(void*)0},{&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954},{&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,(void*)0,&l_3954},{&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,(void*)0,&l_3954},{&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,(void*)0,&l_3954},{&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954,&l_3954}};
    const uint32_t ***l_3952 = &l_3953[0][6];
    const uint32_t ****l_3951 = &l_3952;
    uint8_t l_3986 = 0x19L;
    int64_t ***l_3994[9][1] = {{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0}};
    union U0 l_4007 = {-6L};
    int64_t l_4009[6][6][6] = {{{0xB46255BB2D9C5D43LL,(-5L),0L,0xB46255BB2D9C5D43LL,(-3L),4L},{0x9BF51600156E3C28LL,(-5L),(-7L),2L,(-7L),(-5L)},{0xBF5D258541BF54BCLL,(-1L),0xCCB5CA4750C74787LL,0x9BB489B5E996BC39LL,(-7L),(-3L)},{0x2A997D4F9515A028LL,(-5L),(-1L),0x2A997D4F9515A028LL,(-3L),1L},{0x32FCC447E0612133LL,(-5L),(-1L),0x9BF51600156E3C28LL,(-7L),0L},{0x9BB489B5E996BC39LL,(-1L),4L,(-2L),(-7L),(-7L)}},{{0L,(-5L),(-5L),0L,(-3L),0xCCB5CA4750C74787LL},{2L,(-5L),(-3L),0x32FCC447E0612133LL,(-7L),(-1L)},{(-2L),(-1L),1L,0xBF5D258541BF54BCLL,(-7L),(-1L)},{0xB46255BB2D9C5D43LL,(-5L),0L,0xB46255BB2D9C5D43LL,(-3L),4L},{0x9BF51600156E3C28LL,(-5L),(-7L),2L,(-7L),(-5L)},{0xBF5D258541BF54BCLL,(-1L),0xCCB5CA4750C74787LL,0x9BB489B5E996BC39LL,(-7L),(-3L)}},{{0x2A997D4F9515A028LL,(-5L),(-1L),0x2A997D4F9515A028LL,(-3L),1L},{0x32FCC447E0612133LL,(-5L),(-1L),0x9BF51600156E3C28LL,(-7L),0L},{0x9BB489B5E996BC39LL,(-1L),4L,(-2L),(-7L),(-7L)},{0L,(-5L),(-5L),0L,(-3L),0xCCB5CA4750C74787LL},{2L,(-5L),(-3L),0x32FCC447E0612133LL,(-7L),(-1L)},{(-2L),(-1L),1L,0xBF5D258541BF54BCLL,(-7L),(-1L)}},{{0xB46255BB2D9C5D43LL,(-5L),0L,0xB46255BB2D9C5D43LL,(-3L),4L},{0x9BF51600156E3C28LL,(-5L),(-7L),2L,(-7L),(-5L)},{0xBF5D258541BF54BCLL,(-1L),0xCCB5CA4750C74787LL,0x9BB489B5E996BC39LL,(-7L),(-3L)},{0x2A997D4F9515A028LL,(-5L),(-1L),0x2A997D4F9515A028LL,(-3L),1L},{0x32FCC447E0612133LL,(-5L),(-1L),0x9BF51600156E3C28LL,0xD21D8686C09D7AABLL,(-1L)},{(-3L),0x384AF8CE294799D6LL,(-1L),(-1L),0xD21D8686C09D7AABLL,0xD21D8686C09D7AABLL}},{{0L,(-2L),(-2L),0L,1L,0x4344658EE60DDC0DLL},{0xCCB5CA4750C74787LL,(-2L),1L,4L,0xD21D8686C09D7AABLL,0x384AF8CE294799D6LL},{(-1L),0x384AF8CE294799D6LL,0xFD4F507851384ADFLL,(-7L),0xD21D8686C09D7AABLL,0L},{(-5L),(-2L),(-1L),(-5L),1L,(-1L)},{1L,(-2L),0xD21D8686C09D7AABLL,0xCCB5CA4750C74787LL,0xD21D8686C09D7AABLL,(-2L)},{(-7L),0x384AF8CE294799D6LL,0x4344658EE60DDC0DLL,(-3L),0xD21D8686C09D7AABLL,1L}},{{(-1L),(-2L),0x384AF8CE294799D6LL,(-1L),1L,0xFD4F507851384ADFLL},{4L,(-2L),0L,1L,0xD21D8686C09D7AABLL,(-1L)},{(-3L),0x384AF8CE294799D6LL,(-1L),(-1L),0xD21D8686C09D7AABLL,0xD21D8686C09D7AABLL},{0L,(-2L),(-2L),0L,1L,0x4344658EE60DDC0DLL},{0xCCB5CA4750C74787LL,(-2L),1L,4L,0xD21D8686C09D7AABLL,0x384AF8CE294799D6LL},{(-1L),0x384AF8CE294799D6LL,0xFD4F507851384ADFLL,(-7L),0xD21D8686C09D7AABLL,0L}}};
    int64_t l_4011 = 0L;
    int32_t l_4053 = 0L;
    int32_t l_4062 = 0x525D2875L;
    int32_t l_4063 = 0x12D4E7F2L;
    int32_t l_4064 = 0L;
    int32_t l_4067 = 1L;
    int32_t l_4068 = (-6L);
    int32_t l_4069 = 0x74E7EB5CL;
    int32_t l_4070[6][4] = {{0L,1L,(-1L),1L},{(-1L),1L,0L,0x4FCED356L},{1L,0x27E07C87L,6L,(-1L)},{0xCF551E05L,1L,1L,0xCF551E05L},{0xCF551E05L,0x4FCED356L,6L,3L},{1L,0xCF551E05L,0L,9L}};
    int32_t l_4158 = 0x4FDB33FCL;
    uint32_t l_4185 = 0x1AEEC976L;
    uint16_t l_4258 = 0x2EDFL;
    int32_t *l_4351 = &g_122;
    int32_t l_4397 = 0x944D6FE7L;
    int32_t *l_4406 = &g_2949;
    int32_t **l_4405[9][7][4] = {{{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{(void*)0,(void*)0,(void*)0,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{(void*)0,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{(void*)0,(void*)0,(void*)0,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{(void*)0,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{(void*)0,(void*)0,(void*)0,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{(void*)0,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{(void*)0,(void*)0,(void*)0,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{(void*)0,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{(void*)0,(void*)0,(void*)0,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{(void*)0,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}},{{&l_4406,&l_4406,&l_4406,&l_4406},{(void*)0,(void*)0,(void*)0,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{(void*)0,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,&l_4406,&l_4406},{&l_4406,&l_4406,(void*)0,&l_4406},{&l_4406,(void*)0,&l_4406,&l_4406}}};
    int16_t l_4447 = 0x4938L;
    int32_t l_4449 = (-4L);
    uint64_t l_4455 = 9UL;
    uint32_t *l_4531 = &g_3653;
    int64_t l_4549 = 0x621BBABEF612F231LL;
    int i, j, k;
lbl_4198:
    l_3933--;
    if ((safe_div_func_uint64_t_u_u(((***g_3869) = 2UL), (((safe_rshift_func_uint8_t_u_s(0xEBL, p_8)) && (l_3949 &= ((*g_1878) = (((*****g_2081) = (safe_sub_func_uint8_t_u_u((0x5EL > (safe_rshift_func_uint32_t_u_s(((+0L) && (-1L)), 19))), (safe_div_func_int32_t_s_s(((0xB46486DEL <= ((((*g_513) |= l_3933) , (p_12 < 255UL)) < 0xED53B24DL)) , p_11), p_9))))) >= l_3933)))) , l_3950[1]))))
    { /* block id: 1799 */
        uint8_t l_3955 = 0x16L;
        uint32_t ****l_3958[2];
        int32_t l_3983 = 0L;
        int64_t *****l_4015 = (void*)0;
        int32_t l_4029 = 0x95E369AFL;
        int32_t l_4043 = 0xAB433551L;
        int32_t l_4065 = 1L;
        int32_t l_4066[4][5];
        int64_t l_4074 = 0xDF46CDA5C986ACD1LL;
        uint64_t l_4123 = 1UL;
        union U0 l_4173[1][8][8] = {{{{0x56540EC616C39CF3LL},{1L},{0x82D672FAF5C710B0LL},{3L},{0x82D672FAF5C710B0LL},{1L},{0x56540EC616C39CF3LL},{8L}},{{0x0612D7942906C797LL},{0xCA422C1772BC2165LL},{0L},{0x56540EC616C39CF3LL},{5L},{0L},{0xB57DFA0F4C7584E3LL},{0xDD843F4C8ED20401LL}},{{8L},{3L},{4L},{0x82D672FAF5C710B0LL},{5L},{1L},{1L},{3L}},{{0x0612D7942906C797LL},{0L},{-4L},{0L},{-7L},{-7L},{0L},{-4L}},{{0x712D857C4E4A4BCBLL},{0x712D857C4E4A4BCBLL},{3L},{1L},{1L},{5L},{0x82D672FAF5C710B0LL},{4L}},{{-4L},{1L},{4L},{0xE41B8B0164B9299ALL},{4L},{0L},{0x9EAB44AF1E809F82LL},{4L}},{{1L},{0x9EAB44AF1E809F82LL},{-4L},{1L},{0xE41B8B0164B9299ALL},{-4L},{-7L},{-4L}},{{-7L},{0L},{5L},{0L},{-7L},{3L},{-1L},{8L}}}};
        int16_t **l_4231 = (void*)0;
        const int64_t **l_4237 = &g_1754;
        union U0 **l_4337 = &g_218;
        uint64_t l_4339 = 0xBE247A6F84FC0D2FLL;
        int32_t l_4348 = (-3L);
        const int64_t ****l_4401[3][5][4] = {{{&g_1752,(void*)0,&g_1752,&g_1752},{&g_1752,&g_1752,&g_1752,&g_1752},{(void*)0,&g_1752,&g_1752,(void*)0},{&g_1752,(void*)0,&g_1752,&g_1752},{&g_1752,&g_1752,(void*)0,(void*)0}},{{(void*)0,&g_1752,&g_1752,(void*)0},{&g_1752,&g_1752,&g_1752,&g_1752},{&g_1752,(void*)0,&g_1752,(void*)0},{&g_1752,&g_1752,&g_1752,&g_1752},{&g_1752,&g_1752,&g_1752,&g_1752}},{{&g_1752,(void*)0,&g_1752,&g_1752},{&g_1752,&g_1752,&g_1752,(void*)0},{&g_1752,&g_1752,&g_1752,&g_1752},{&g_1752,&g_1752,&g_1752,&g_1752},{&g_1752,&g_1752,&g_1752,(void*)0}}};
        int8_t l_4448 = 0x9AL;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_3958[i] = &g_3836[3];
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 5; j++)
                l_4066[i][j] = 0x8086683BL;
        }
lbl_4426:
        if ((l_3951 == (void*)0))
        { /* block id: 1800 */
            int8_t l_3959 = 0x28L;
            int32_t **l_3963 = &g_1158[4][0];
            int8_t l_4010 = 0xAAL;
            int64_t *****l_4014 = &g_1845;
            int32_t l_4018 = 0xBD09E17FL;
            int32_t l_4049 = 0x8EA3E513L;
            int32_t l_4050 = (-9L);
            int32_t l_4051 = 0x9C77CC67L;
            int32_t l_4052 = 0x808C75F6L;
            int32_t l_4054 = 0x8EAF18C1L;
            uint32_t l_4055[4];
            int32_t l_4072 = (-9L);
            int32_t l_4075 = 0x25C66BD9L;
            uint64_t l_4076[3];
            int32_t l_4124 = 0x7F042724L;
            uint8_t l_4151 = 0UL;
            const uint16_t l_4186 = 1UL;
            union U0 l_4210 = {0x3B8200A14AA58026LL};
            uint64_t l_4217[10] = {0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL,0x250B3776B1AF0680LL};
            int i;
            for (i = 0; i < 4; i++)
                l_4055[i] = 0xD641ED15L;
            for (i = 0; i < 3; i++)
                l_4076[i] = 0xAFD11D962EE6D058LL;
            --l_3955;
            for (g_811.f0 = 0; (g_811.f0 >= 0); g_811.f0 -= 1)
            { /* block id: 1804 */
                int64_t ***l_3996 = &g_2578;
                int32_t l_3997 = 0x29592169L;
                uint16_t *l_4028[7] = {(void*)0,(void*)0,&g_3390,(void*)0,(void*)0,&g_3390,(void*)0};
                int32_t *** const l_4038 = &l_3963;
                int32_t l_4044 = (-8L);
                int32_t l_4047 = 0xDEBE546DL;
                int32_t l_4048 = 8L;
                int32_t l_4071 = 3L;
                int32_t l_4073[9][10] = {{1L,0x1B35CAABL,(-1L),(-1L),0x1B35CAABL,1L,1L,0xB6912283L,0x48DA3581L,0xE10B563CL},{0xB6912283L,0x15D7A0EEL,0xCA851748L,1L,(-1L),(-1L),0x37C9CB10L,0x3B2A69F0L,0x37C9CB10L,(-1L)},{0xB6912283L,9L,(-7L),9L,0xB6912283L,1L,(-1L),0x2F8016F6L,(-1L),(-1L)},{1L,(-1L),0x2F8016F6L,(-1L),(-1L),0xE10B563CL,0x1B35CAABL,0x1B35CAABL,0xE10B563CL,(-1L)},{(-7L),(-1L),(-1L),(-7L),0xB6912283L,0x15D7A0EEL,0xCA851748L,1L,(-1L),(-1L)},{1L,0xB6912283L,0x48DA3581L,0xE10B563CL,(-1L),0xCA851748L,(-1L),0xCA851748L,(-1L),0xE10B563CL},{(-1L),1L,(-1L),(-7L),0x1B35CAABL,0x3B2A69F0L,(-1L),0x37C9CB10L,0xE10B563CL,(-1L)},{(-1L),0x3B2A69F0L,0xB6912283L,(-1L),0x37C9CB10L,0x766D6CF6L,0x766D6CF6L,0x15D7A0EEL,0x48DA3581L,9L},{(-1L),(-1L),0x37C9CB10L,(-1L),0xB6912283L,0x3B2A69F0L,(-1L),1L,0x15D7A0EEL,0xE10B563CL}};
                const int16_t **l_4093[8] = {&g_424,&g_424,&g_424,&g_424,&g_424,&g_424,&g_424,&g_424};
                const int16_t ***l_4092 = &l_4093[4];
                int16_t *l_4098[7][8] = {{&g_91,&g_91,(void*)0,&g_1808,(void*)0,&g_91,&g_91,(void*)0},{&g_1808,(void*)0,(void*)0,&g_1808,(void*)0,&g_1808,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1808,&g_1808,(void*)0,(void*)0,(void*)0,&g_1808},{&g_1808,(void*)0,&g_1808,(void*)0,(void*)0,&g_1808,(void*)0,&g_1808},{&g_91,(void*)0,&g_1808,(void*)0,&g_91,&g_91,(void*)0,&g_1808},{&g_91,&g_91,(void*)0,&g_1808,(void*)0,&g_91,&g_91,(void*)0},{&g_1808,(void*)0,(void*)0,&g_1808,(void*)0,&g_1808,(void*)0,(void*)0}};
                int32_t ****l_4130 = &g_3789;
                int8_t l_4141 = (-9L);
                int i, j;
                for (g_179 = 0; (g_179 <= 5); g_179 += 1)
                { /* block id: 1807 */
                    uint16_t l_3984 = 0x09FDL;
                    int32_t l_3985[1][7];
                    int64_t ***l_3993 = &g_2578;
                    int32_t *l_4013 = &g_65;
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 7; j++)
                            l_3985[i][j] = 0x62F7CA62L;
                    }
                    for (g_2641 = 0; (g_2641 <= 0); g_2641 += 1)
                    { /* block id: 1810 */
                        int32_t ***l_3964 = &g_1157[0];
                        int64_t ****l_3995[3][3][8] = {{{&g_2943[0],(void*)0,&l_3994[2][0],&l_3994[7][0],&l_3994[2][0],(void*)0,&g_2943[0],&l_3993},{(void*)0,&l_3993,&g_2943[0],&g_2943[0],&l_3994[2][0],&l_3994[7][0],&l_3994[7][0],&l_3994[2][0]},{&g_2943[0],&g_2943[0],&g_2943[0],&g_2943[0],&l_3994[2][0],&g_2943[0],&l_3993,&l_3994[7][0]}},{{(void*)0,&l_3994[2][0],&l_3994[7][0],&l_3994[2][0],&l_3994[2][0],&l_3994[2][0],&l_3994[7][0],&l_3994[2][0]},{&g_2943[0],&l_3994[2][0],&l_3994[7][0],&l_3994[7][0],&g_2943[0],&g_2943[0],&g_2943[0],&g_2943[0]},{&l_3994[7][0],&g_2943[0],&l_3993,&l_3993,&g_2943[0],&l_3994[7][0],&g_2943[0],&l_3994[2][0]}},{{&l_3993,&l_3993,&l_3994[7][0],&g_2943[0],&l_3994[7][0],(void*)0,&l_3994[7][0],&g_2943[0]},{&l_3994[7][0],(void*)0,&l_3994[7][0],&g_2943[0],&l_3994[7][0],&l_3993,&l_3993,&l_3994[2][0]},{&g_2943[0],&l_3994[7][0],&g_2943[0],&l_3993,&l_3993,&g_2943[0],&l_3994[7][0],&g_2943[0]}}};
                        int32_t *l_4008 = &g_65;
                        int i, j, k;
                        l_3959 ^= (g_82[(g_811.f0 + 2)][(g_811.f0 + 1)][g_811.f0] > (l_3958[0] != &g_3836[1]));
                        l_3986 &= (g_1879[(g_2641 + 3)][g_811.f0][g_811.f0] || (safe_div_func_uint16_t_u_u(((+p_9) != (((*l_3964) = l_3963) != (**g_2460))), (safe_sub_func_int32_t_s_s((-5L), (((*g_513) = (safe_rshift_func_int64_t_s_u((l_3985[0][5] ^= (((p_9 , ((safe_add_func_uint64_t_u_u(9UL, (((safe_mul_func_int64_t_s_s((safe_mul_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((safe_mul_func_int8_t_s_s((safe_div_func_uint64_t_u_u(p_11, (safe_mod_func_int16_t_s_s(l_3983, l_3984)))), p_9)), (-3L))), p_11)), 0L)) , 1L) , p_11))) && p_9)) || 1UL) <= l_3933)), (***g_3869)))) > 3UL))))));
                        l_3997 &= ((((safe_mul_func_int64_t_s_s(((p_10 < ((l_3964 != g_3989) ^ ((p_11 || ((l_3983 &= p_12) >= (safe_unary_minus_func_int64_t_s((p_8 ^ (safe_mul_func_int64_t_s_s((l_3993 == (l_3996 = l_3994[2][0])), (&g_2082 != (void*)0)))))))) | 0xC883BCD0D06BB876LL))) & 0x077C448DL), 0x80FCCD888B23CB17LL)) >= (-8L)) , p_11) , p_9);
                        l_4010 &= ((safe_mod_func_uint64_t_u_u((l_3986 <= (~(l_3955 < (safe_rshift_func_uint64_t_u_s((((safe_mod_func_uint64_t_u_u((p_10 <= (l_3983 | ((250UL <= ((*g_1878) = p_9)) & ((safe_div_func_int16_t_s_s((((l_3985[0][5] <= ((*l_4008) = (1UL >= (((l_4007 , 0x5584L) ^ (*g_513)) | p_8)))) > 0x67L) | 0xDFL), 0x7F6FL)) > l_3997)))), p_9)) != 0xDE074A09EDFE43EELL) | p_12), l_4009[2][1][0]))))), p_9)) | l_3983);
                    }
                    if (l_4011)
                        continue;
                    (*l_4013) |= (~1L);
                    l_4015 = l_4014;
                    for (g_635 = 0; (g_635 <= 0); g_635 += 1)
                    { /* block id: 1828 */
                        int32_t *l_4016 = &g_3031;
                        int32_t *l_4017[3];
                        uint16_t l_4019 = 0x2717L;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_4017[i] = &l_3949;
                        --l_4019;
                    }
                }
                l_4043 = (safe_lshift_func_int64_t_s_u(l_3955, ((safe_sub_func_int8_t_s_s(0x29L, ((0xA44DL | ((safe_div_func_uint16_t_u_u((l_4029 = (l_3983 = p_8)), ((*g_513) || 0x1F98L))) , ((safe_rshift_func_uint64_t_u_u((((safe_lshift_func_uint8_t_u_u(((***g_2008) = (safe_rshift_func_uint32_t_u_u((((((safe_div_func_int16_t_s_s((((*g_3838) = (l_4038 == (void*)0)) , (safe_add_func_uint64_t_u_u((safe_add_func_uint32_t_u_u(p_12, p_11)), l_4007.f0))), p_10)) | 0x20658B26639487FDLL) , 5L) < p_12) == 0x8E463CDFCC81DCFFLL), 18))), 5)) ^ p_11) , (*g_1096)), (**g_248))) <= 4294967286UL))) | 3L))) ^ (*g_1878))));
                for (l_3997 = 5; (l_3997 >= 0); l_3997 -= 1)
                { /* block id: 1839 */
                    int32_t *l_4045[2];
                    int16_t l_4046 = 0L;
                    int i;
                    for (i = 0; i < 2; i++)
                        l_4045[i] = &l_4043;
                    l_4055[2]++;
                    for (l_4051 = 0; (l_4051 <= 0); l_4051 += 1)
                    { /* block id: 1843 */
                        int64_t l_4058 = 5L;
                        int32_t l_4059 = 0xE1237E52L;
                        int32_t l_4060 = 0x845B144BL;
                        int32_t l_4061[2][8][7] = {{{4L,1L,0xE9626578L,0x813A0DA7L,1L,0x813A0DA7L,0xE9626578L},{1L,1L,8L,(-6L),0x821FE9D3L,8L,0x821FE9D3L},{(-6L),0xE9626578L,0xE9626578L,(-6L),0x813A0DA7L,4L,(-6L)},{4L,0x821FE9D3L,0x813A0DA7L,0x813A0DA7L,0x821FE9D3L,4L,0xE9626578L},{0x821FE9D3L,(-6L),8L,1L,1L,8L,(-6L)},{0x821FE9D3L,0xE9626578L,4L,0x821FE9D3L,9L,9L,0x813A0DA7L},{0x8557ACEEL,0xE9626578L,0x8557ACEEL,9L,0xE9626578L,8L,8L},{0xE9626578L,0x813A0DA7L,1L,0x813A0DA7L,0xE9626578L,1L,4L}},{{4L,8L,9L,4L,9L,8L,4L},{0x8557ACEEL,4L,8L,9L,4L,9L,8L},{4L,4L,1L,0xE9626578L,0x813A0DA7L,1L,0x813A0DA7L},{0xE9626578L,8L,8L,0xE9626578L,9L,0x8557ACEEL,0xE9626578L},{0x8557ACEEL,0x813A0DA7L,9L,9L,0x813A0DA7L,0x8557ACEEL,8L},{0x813A0DA7L,0xE9626578L,1L,4L,4L,1L,0xE9626578L},{0x813A0DA7L,8L,0x8557ACEEL,0x813A0DA7L,9L,9L,0x813A0DA7L},{0x8557ACEEL,0xE9626578L,0x8557ACEEL,9L,0xE9626578L,8L,8L}}};
                        int i, j, k;
                        --l_4076[1];
                        if (p_9)
                            continue;
                        ++g_4079;
                    }
                }
                l_4029 = (safe_sub_func_int16_t_s_s(((((safe_lshift_func_int16_t_s_u((safe_add_func_int16_t_s_s((*g_513), (safe_mod_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((((*l_4092) = (void*)0) != (void*)0), (safe_lshift_func_uint64_t_u_u(((**g_248) = l_4074), 10)))), ((l_4029 , (p_8++)) , (l_4063 ^= l_3986)))))), (safe_sub_func_int64_t_s_s((safe_mul_func_uint8_t_u_u((safe_add_func_int8_t_s_s(((*g_1878) = ((p_9 > 18446744073709551612UL) ^ ((l_4070[5][2] |= (safe_rshift_func_uint64_t_u_s((0x6062L < p_11), 59))) | p_10))), p_11)), l_3949)), (*g_2579))))) == (***g_2008)) , 9L) < p_12), l_3933));
                for (l_4072 = 0; (l_4072 <= 5); l_4072 += 1)
                { /* block id: 1858 */
                    uint8_t l_4118[3];
                    int32_t l_4125 = (-4L);
                    int32_t *l_4154 = (void*)0;
                    int32_t *l_4155[5];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_4118[i] = 0xFCL;
                    for (i = 0; i < 5; i++)
                        l_4155[i] = (void*)0;
                    for (g_506 = 0; (g_506 <= 0); g_506 += 1)
                    { /* block id: 1861 */
                        uint64_t l_4111 = 0xB1A73B020B2DE47ELL;
                        int32_t *l_4112 = &g_65;
                        int32_t *l_4113 = &l_4070[4][3];
                        int32_t *l_4114 = &l_4047;
                        int32_t *l_4115 = &l_4052;
                        int32_t *l_4116 = &l_4071;
                        int32_t *l_4117[2];
                        uint8_t *l_4142 = &l_4118[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_4117[i] = &g_3031;
                        l_4070[1][2] = (safe_lshift_func_uint64_t_u_s((safe_mul_func_int32_t_s_s(l_4111, 9L)), 27));
                        l_4118[2]--;
                        l_4125 = (((*l_4142) ^= (safe_mul_func_uint16_t_u_u(((l_4124 |= l_4123) , 0x2D95L), ((--g_267) , ((((*g_2579) = (safe_add_func_int64_t_s_s(p_8, ((l_4130 != ((((*l_4112) &= (safe_mod_func_uint8_t_u_u(1UL, (safe_div_func_uint64_t_u_u((((~(0x8A503ECEF36AA128LL <= ((***g_3869) ^= (((0x6A5F6804L == (((safe_div_func_uint64_t_u_u((((g_267 &= ((*l_4115) ^= (safe_lshift_func_uint16_t_u_s(0x68CAL, p_12)))) > 0xEE85L) != p_8), (*l_4116))) , 0xEE796224A103C289LL) && p_8)) ^ p_9) >= 0x505CL)))) ^ (*g_513)) != 1L), g_4140))))) < p_12) , (void*)0)) <= g_1931)))) >= l_4141) , p_8))))) >= (-1L));
                    }
                    l_4158 |= (p_9 | (0xD46BL >= (l_4071 = (((*g_1878) = p_12) ^ ((safe_rshift_func_int32_t_s_s((safe_mod_func_int64_t_s_s((safe_div_func_int32_t_s_s((l_4070[5][2] >= (safe_lshift_func_uint16_t_u_u((l_4043 = l_4151), (safe_add_func_uint32_t_u_u(p_10, ((l_4067 = 1L) != (((safe_sub_func_int16_t_s_s((p_12 > l_4070[0][1]), l_4064)) == p_9) > p_9))))))), p_12)), l_4123)), p_8)) <= p_11)))));
                    l_4052 ^= p_9;
                    for (l_4029 = 0; (l_4029 >= 0); l_4029 -= 1)
                    { /* block id: 1882 */
                        if (p_11)
                            break;
                        return p_9;
                    }
                }
            }
            l_4070[2][1] = (((safe_mul_func_uint32_t_u_u((p_10 , ((l_4064 = (safe_div_func_int16_t_s_s((l_4065 != ((((safe_add_func_int64_t_s_s((((safe_rshift_func_int64_t_s_u(p_11, (safe_mod_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(((safe_add_func_int8_t_s_s((l_4173[0][6][0] , (((safe_rshift_func_int8_t_s_u(((safe_div_func_int64_t_s_s(((-1L) || (safe_div_func_uint16_t_u_u((+(((-1L) && (safe_mul_func_uint16_t_u_u(l_4011, (((p_8 , (safe_rshift_func_int64_t_s_u(((l_4069 = ((**g_2578) = l_4069)) <= (***g_3869)), p_12))) & 1UL) | 0x68L)))) > l_4185)), g_197[3]))), 0x18D9D7C2203A28B5LL)) < p_8), 7)) > 5UL) && 0x7C06L)), 0x26L)) | l_4066[3][1]), 0x7C72CAAA7E9AD554LL)), (*g_1878))))) , (**g_1015)) >= 0x70L), (*g_521))) , 1L) , (void*)0) != &g_2082)), 2L))) <= l_4066[3][1])), l_4186)) & 0x41L) , 0x2160F6B9L);
            for (p_8 = 0; (p_8 >= 48); p_8 = safe_add_func_uint64_t_u_u(p_8, 5))
            { /* block id: 1894 */
                uint64_t l_4204 = 0x1156827892DAB10FLL;
                uint8_t **l_4214 = &g_2010;
                uint8_t ***l_4213 = &l_4214;
                uint8_t *** const *l_4212 = &l_4213;
                uint8_t *** const **l_4211 = &l_4212;
                int32_t l_4215[2];
                int16_t * const *l_4224[6];
                int16_t * const **l_4223[1][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                int16_t * const ***l_4222 = &l_4223[0][1];
                const int64_t **l_4236 = &g_1754;
                int i, j;
                for (i = 0; i < 2; i++)
                    l_4215[i] = (-2L);
                for (i = 0; i < 6; i++)
                    l_4224[i] = &g_514;
                if (p_12)
                { /* block id: 1895 */
                    uint16_t l_4194 = 0xBEE1L;
                    for (g_1931 = 0; (g_1931 < (-13)); g_1931--)
                    { /* block id: 1898 */
                        int16_t l_4192[8][3] = {{0x4E38L,0x4E38L,0x4E38L},{(-3L),(-3L),(-3L)},{0x4E38L,0x4E38L,0x4E38L},{(-3L),(-3L),(-3L)},{0x4E38L,0x4E38L,0x4E38L},{(-3L),(-3L),(-3L)},{0x4E38L,0x4E38L,0x4E38L},{(-3L),(-3L),(-3L)}};
                        int32_t *l_4193[5][9];
                        int i, j;
                        for (i = 0; i < 5; i++)
                        {
                            for (j = 0; j < 9; j++)
                                l_4193[i][j] = (void*)0;
                        }
                        (*g_4191) |= l_4185;
                        --l_4194;
                    }
                    for (l_4075 = 0; (l_4075 <= 3); l_4075 += 1)
                    { /* block id: 1904 */
                        int8_t l_4197 = (-1L);
                        int i, j;
                        l_4066[l_4075][l_4075] = l_4197;
                        return p_8;
                    }
                }
                else
                { /* block id: 1908 */
                    int32_t *l_4199 = &l_4052;
                    int32_t *l_4200 = &l_4054;
                    int32_t *l_4201 = &l_4158;
                    int32_t *l_4202 = &g_122;
                    int32_t *l_4203[6][4] = {{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_3421,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_3421,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}};
                    int i, j;
                    if (p_10)
                        goto lbl_4198;
                    l_4204--;
                }
                l_4215[1] |= ((~(l_4067 , (((0L < (0x9FL <= (p_8 , (((safe_rshift_func_int32_t_s_s((((l_4062 , (l_4070[1][1] = (l_4210 , (((l_4211 == &g_2082) > (((*l_4014) != (void*)0) , p_8)) , 0xC1F001D5L)))) , l_4173[0][6][0]) , l_4066[3][1]), 5)) ^ 0x5318L) == 0x13L)))) , 2UL) != (-1L)))) || 0x0B7823F5755E1947LL);
                if ((l_4066[2][3] = 0L))
                { /* block id: 1915 */
                    int32_t *l_4216[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_4216[i] = &g_3388;
                    if ((l_4051 = p_10))
                    { /* block id: 1917 */
                        if (l_4064)
                            goto lbl_4198;
                        (**g_2461) = (**g_3989);
                    }
                    else
                    { /* block id: 1920 */
                        if (l_4217[7])
                            break;
                    }
                }
                else
                { /* block id: 1923 */
                    int32_t *l_4218 = (void*)0;
                    int32_t l_4254 = 0L;
                    int32_t l_4255 = 0L;
                    int32_t l_4256 = 0xD6F3FE04L;
                    int32_t l_4257[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_4257[i] = (-5L);
                    l_4218 = &l_4215[1];
                    if ((safe_lshift_func_uint16_t_u_u(l_4068, 14)))
                    { /* block id: 1925 */
                        int16_t *****l_4221[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_4221[i] = (void*)0;
                        l_4222 = (void*)0;
                    }
                    else
                    { /* block id: 1927 */
                        int64_t **l_4238 = &g_2579;
                        const int32_t l_4239 = 0x900FF0B0L;
                        int32_t l_4247[8][2][1];
                        int32_t l_4248 = 0x5B907267L;
                        int32_t *l_4250 = &l_4062;
                        int32_t *l_4251 = &l_4070[5][2];
                        int32_t *l_4252 = &l_4050;
                        int32_t *l_4253[7] = {&l_4043,&l_4066[1][3],&l_4043,&l_4043,&l_4066[1][3],&l_4043,&l_4043};
                        int i, j, k;
                        for (i = 0; i < 8; i++)
                        {
                            for (j = 0; j < 2; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_4247[i][j][k] = (-4L);
                            }
                        }
                        l_4248 |= (safe_lshift_func_int8_t_s_s((safe_add_func_int8_t_s_s(p_12, (((((safe_mod_func_uint16_t_u_u((l_4231 == ((safe_lshift_func_uint64_t_u_s(((safe_rshift_func_uint8_t_u_u(p_9, l_4173[0][6][0].f0)) , ((l_4237 = l_4236) != l_4238)), (l_4247[7][1][0] = (l_4239 != (p_8 == (safe_div_func_int32_t_s_s((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint64_t_u_s((*l_4218), (*g_2579))), p_11)), g_4246))))))) , &g_424)), p_8)) > l_4204) == g_201[0][3][4]) != (-1L)) ^ l_4215[0]))), (*g_1878)));
                        g_4249 = &g_3868;
                        ++l_4258;
                    }
                    for (l_3983 = 0; (l_3983 != (-7)); --l_3983)
                    { /* block id: 1936 */
                        (*l_4218) ^= p_10;
                        if (p_10)
                            continue;
                    }
                }
                (**g_2461) = (**g_3989);
            }
        }
        else
        { /* block id: 1943 */
            int32_t *l_4270[4][3][8] = {{{&l_4043,&l_3949,&l_4065,&l_4043,&l_3949,&l_4066[3][1],&g_65,&l_4043},{&l_4065,&l_4043,(void*)0,&l_4064,&l_3949,(void*)0,(void*)0,&l_3949},{&l_4043,&g_65,&g_65,&l_4043,(void*)0,&l_4065,(void*)0,&l_4064}},{{&g_65,(void*)0,&l_4068,&l_4043,&g_65,(void*)0,&l_4043,&g_65},{(void*)0,(void*)0,(void*)0,&l_4065,&g_197[3],&l_4065,(void*)0,(void*)0},{(void*)0,&g_65,(void*)0,&g_65,(void*)0,(void*)0,&g_65,(void*)0}},{{&g_65,&l_4043,&l_4066[3][1],&l_3949,(void*)0,&l_4066[3][1],&g_65,&g_65},{&l_4064,&l_3949,(void*)0,(void*)0,(void*)0,&l_4068,&l_4066[3][1],&g_65},{(void*)0,&l_4068,&l_4066[3][1],&g_65,&l_4065,(void*)0,(void*)0,&l_4065}},{{&g_65,&l_4065,&l_3949,&g_65,&l_4070[0][3],&l_4043,&l_4070[0][3],&g_65},{&l_4029,&l_4070[0][3],&l_4029,(void*)0,(void*)0,&l_4066[3][1],(void*)0,&l_4065},{&l_4070[0][3],&l_4064,&l_4066[3][1],(void*)0,&l_4066[3][1],&l_4065,(void*)0,&l_4064}}};
            int32_t *l_4273 = (void*)0;
            int32_t l_4278 = 0x0DB2345CL;
            uint16_t *l_4300[6] = {&g_600,&g_600,&g_600,&g_600,&g_600,&g_600};
            int32_t l_4314 = 0x1E70E9D8L;
            uint64_t l_4316 = 0xE3A13B9C7F448DE3LL;
            int i, j, k;
lbl_4289:
            for (g_1808 = 0; (g_1808 < (-12)); g_1808 = safe_sub_func_uint32_t_u_u(g_1808, 1))
            { /* block id: 1946 */
                int32_t **l_4271 = (void*)0;
                int32_t **l_4272[3][2] = {{&l_4270[0][2][5],&l_4270[0][2][5]},{&l_4270[0][2][5],&l_4270[0][2][5]},{&l_4270[0][2][5],&l_4270[0][2][5]}};
                const uint32_t l_4288 = 0x3E12ED5EL;
                int i, j;
                for (l_4069 = 0; (l_4069 <= 3); l_4069 += 1)
                { /* block id: 1949 */
                    int32_t *l_4265[5] = {&g_197[2],&g_197[2],&g_197[2],&g_197[2],&g_197[2]};
                    int i, j;
                    g_1158[(l_4069 + 2)][l_4069] = l_4265[1];
                    if (g_91)
                        goto lbl_4289;
                }
                if (g_65)
                    goto lbl_4198;
                (*g_4191) &= (safe_sub_func_int16_t_s_s(((((safe_add_func_int64_t_s_s((((l_4273 = (l_4270[3][0][2] = l_4270[0][2][5])) == (((safe_unary_minus_func_int32_t_s((((p_8 , (!(safe_rshift_func_int8_t_s_s(l_4278, ((safe_unary_minus_func_uint32_t_u((safe_add_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u((p_10 > l_4062), p_11)), (l_4278 == l_4070[5][2]))))) != (safe_mod_func_uint8_t_u_u((safe_div_func_int64_t_s_s(((*****g_2081) > l_4278), p_9)), p_12))))))) || p_8) & l_4066[3][1]))) < p_10) , (void*)0)) >= l_4288), (-1L))) , p_9) , (void*)0) == &g_424), p_9));
            }
            if ((l_4173[0][2][0] , ((safe_sub_func_uint8_t_u_u(p_8, ((safe_lshift_func_uint16_t_u_s((safe_rshift_func_int16_t_s_s((safe_div_func_uint16_t_u_u((safe_add_func_int64_t_s_s(((g_2844 = (p_9 , (l_3983 && ((((++g_600) , (((((l_4063 < (l_3949 > (l_4029 = (-4L)))) < (g_3388 == (((1UL >= p_8) >= p_9) | g_2202))) < l_4009[5][4][1]) > p_10) , (void*)0)) == (void*)0) >= p_10)))) == 0x5C99L), 0x00122506C6AAB39FLL)), 65526UL)), 6)), 4)) ^ 0xCCL))) & 0xCACFD497B5192C8CLL)))
            { /* block id: 1961 */
                for (g_2431 = 0; (g_2431 < 39); g_2431++)
                { /* block id: 1964 */
                    uint32_t l_4306 = 0x5B82C6DDL;
                    uint8_t l_4308 = 0xD9L;
                    l_4043 = p_8;
                    if ((~1L))
                    { /* block id: 1966 */
                        l_4306 = p_11;
                        return p_9;
                    }
                    else
                    { /* block id: 1969 */
                        int8_t l_4307 = (-1L);
                        l_4308++;
                        if (l_3983)
                            continue;
                    }
                }
                return l_4043;
            }
            else
            { /* block id: 1975 */
                uint32_t l_4313 = 6UL;
                int32_t l_4315 = (-4L);
                const union U0 *l_4336 = (void*)0;
                const union U0 **l_4335 = &l_4336;
                int32_t l_4341 = 0L;
                int32_t l_4342 = 0xA44097DEL;
                l_4313 = (safe_lshift_func_int32_t_s_s(l_4066[1][4], 18));
                --l_4316;
                (*g_234) = (void*)0;
                for (p_9 = 0; (p_9 <= 0); p_9 += 1)
                { /* block id: 1981 */
                    int64_t *****l_4325 = &g_1845;
                    int32_t l_4338 = 0xE1C5529EL;
                    int32_t l_4340 = 0xF58000DDL;
                    int32_t l_4343 = 0L;
                    int32_t l_4344[2][9][6] = {{{0x6A603590L,0xAAAB0096L,0x8AAE45A4L,0x96290C4CL,(-1L),(-9L)},{3L,0x96290C4CL,4L,4L,0x96290C4CL,3L},{4L,0x96290C4CL,3L,(-1L),(-1L),0x8AAE45A4L},{0x8AAE45A4L,0xAAAB0096L,0x6A603590L,0xAAAB0096L,0x8AAE45A4L,0x96290C4CL},{0x8AAE45A4L,4L,0xAAAB0096L,(-1L),0x1F09E4ECL,0x1F09E4ECL},{4L,(-1L),(-1L),4L,0x6A603590L,0x1F09E4ECL},{3L,0x1F09E4ECL,0xAAAB0096L,0x96290C4CL,(-1L),0x96290C4CL},{0x6A603590L,0x8DB187E1L,0x6A603590L,(-9L),(-1L),0x8AAE45A4L},{0xAAAB0096L,0x1F09E4ECL,3L,0x6A603590L,0x6A603590L,3L}},{{(-1L),(-1L),4L,0x6A603590L,0x1F09E4ECL,(-9L)},{0xAAAB0096L,4L,0x8AAE45A4L,(-9L),0x8AAE45A4L,4L},{0x6A603590L,0xAAAB0096L,0x8AAE45A4L,0x96290C4CL,(-1L),(-9L)},{3L,0x96290C4CL,4L,4L,0x96290C4CL,3L},{4L,0x96290C4CL,3L,(-1L),(-1L),0x8AAE45A4L},{0x8AAE45A4L,0xAAAB0096L,0x6A603590L,0xAAAB0096L,0x8AAE45A4L,0x96290C4CL},{0x8AAE45A4L,4L,0xAAAB0096L,(-1L),0x1F09E4ECL,0x1F09E4ECL},{4L,(-1L),(-1L),4L,0x6A603590L,0x1F09E4ECL},{3L,0x1F09E4ECL,0xAAAB0096L,0x96290C4CL,(-1L),0x96290C4CL}}};
                    int i, j, k;
                    for (l_4314 = 0; (l_4314 >= 0); l_4314 -= 1)
                    { /* block id: 1984 */
                        l_4315 = ((0xA13A2662L | 0UL) <= ((((safe_mul_func_int64_t_s_s(((((((safe_mul_func_int64_t_s_s((safe_mul_func_int32_t_s_s((((void*)0 != l_4325) <= (l_4066[3][1] == (((safe_div_func_int8_t_s_s(1L, l_4070[5][2])) , (safe_sub_func_int16_t_s_s((((((~((-8L) == (safe_mul_func_uint8_t_u_u((((safe_mod_func_int8_t_s_s(((l_4335 != l_4337) , 0xE4L), l_4338)) != (*g_1878)) && p_12), l_4070[5][2])))) > l_4315) , 0xB274697E7A68C119LL) && (**g_2578)) | p_8), 1UL))) || 65535UL))), 0xD712F5D2L)), (***g_3869))) != (*g_513)) , &l_4066[3][1]) == (void*)0) & l_4339) < 0xCE3211752853B988LL), (**g_2578))) && g_3800) != p_8) ^ (*g_513)));
                    }
                    if (p_11)
                        continue;
                    for (g_3356 = 0; (g_3356 <= 0); g_3356 += 1)
                    { /* block id: 1990 */
                        uint32_t l_4345 = 18446744073709551606UL;
                        int32_t *l_4349 = (void*)0;
                        l_4345--;
                        if (l_4070[3][0])
                            break;
                        l_4348 ^= p_10;
                        l_4351 = l_4349;
                    }
                }
            }
            for (l_4029 = 0; (l_4029 <= (-9)); l_4029--)
            { /* block id: 2000 */
                int32_t l_4360 = 0L;
                l_4348 = (*g_143);
                l_4053 |= ((((safe_rshift_func_int64_t_s_u(((safe_mod_func_int16_t_s_s(p_11, (l_4062 = ((g_179 = g_91) || (*g_513))))) == (0xB89EL >= g_2541[1])), 51)) && (safe_mul_func_int8_t_s_s((l_4043 = (l_4360 , (&l_4339 == (void*)0))), (safe_unary_minus_func_int64_t_s((l_4066[3][1] = p_11)))))) , l_4070[5][2]) , 0x24865266L);
            }
        }
        for (l_4158 = 0; (l_4158 > (-6)); l_4158--)
        { /* block id: 2011 */
            int32_t *l_4364 = &g_3421;
            int32_t **l_4366 = &l_4351;
            const uint32_t *l_4430 = &g_887[4][1][0];
            const uint32_t **l_4429[9];
            const uint32_t ***l_4428[9][5] = {{&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7]},{&l_4429[0],&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7]},{&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7]},{&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[0]},{&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7]},{&l_4429[0],&l_4429[7],&l_4429[2],&l_4429[7],&l_4429[7]},{&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7]},{&l_4429[7],&l_4429[8],&l_4429[2],&l_4429[7],&l_4429[2]},{&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7],&l_4429[7]}};
            int32_t l_4433 = 0xFFF13A0BL;
            int32_t l_4446[8][6][5] = {{{0x69FD0670L,0x6A2FACD4L,0xDA0AD6B3L,0x2FF2273EL,0xC29167D5L},{(-3L),4L,0L,0L,4L},{0xB46A4B17L,0x6955882EL,0xDCEE5934L,0x7411F6EFL,0x6B3C6EF0L},{(-3L),0L,4L,1L,(-10L)},{0L,(-4L),0L,3L,0xEC4223FDL},{(-3L),0x9AC8733DL,(-3L),8L,0L}},{{0xB46A4B17L,0x2F658D92L,0x6F2A60F1L,0x6955882EL,0x155211B6L},{(-3L),1L,0x755A466EL,4L,1L},{0x69FD0670L,(-9L),0x6F2A60F1L,(-9L),0x69FD0670L},{4L,3L,(-3L),0L,4L},{0x6D909BDCL,0x9B2416BEL,0L,0x62FABED1L,0xDA0AD6B3L},{(-1L),(-3L),4L,3L,4L}},{{(-1L),0x62FABED1L,0xDCEE5934L,(-6L),0x69FD0670L},{4L,(-10L),0L,0x755A466EL,1L},{0x6F2A60F1L,0x942094BCL,0xDA0AD6B3L,(-4L),0x155211B6L},{0L,(-10L),(-10L),0L,0L},{0x6B3C6EF0L,0x62FABED1L,0xC29167D5L,1L,0xEC4223FDL},{0L,(-3L),0xA0616E4BL,(-1L),(-10L)}},{{0xB7200C27L,0x9B2416BEL,0x69FD0670L,1L,0x6B3C6EF0L},{1L,3L,0x9AC8733DL,0L,4L},{0x4F2E69DDL,(-9L),(-1L),(-4L),0xC29167D5L},{3L,1L,8L,0x755A466EL,0x755A466EL},{0x4F2E69DDL,0x2F658D92L,0x4F2E69DDL,(-6L),0L},{1L,0x9AC8733DL,(-1L),3L,0L}},{{0xB7200C27L,(-4L),0xEC4223FDL,0x62FABED1L,0xB46A4B17L},{0L,0L,(-1L),0L,0L},{0x6B3C6EF0L,0x6955882EL,0x4F2E69DDL,(-9L),(-1L)},{0L,4L,8L,4L,0xA0616E4BL},{0x6F2A60F1L,0x6A2FACD4L,(-1L),0x6955882EL,(-1L)},{4L,4L,0x9AC8733DL,8L,0L}},{{(-1L),0L,0x69FD0670L,3L,0xB46A4B17L},{(-1L),(-3L),0xA0616E4BL,1L,0L},{0x6D909BDCL,0L,0xC29167D5L,0x7411F6EFL,0L},{4L,4L,(-10L),0L,0x755A466EL},{0x69FD0670L,0x6A2FACD4L,0xDA0AD6B3L,0x6955882EL,0xDA0AD6B3L},{0L,(-10L),(-3L),(-3L),(-10L)}},{{0L,0x7411F6EFL,0x86D2FA0DL,1L,0xC29167D5L},{0L,4L,(-1L),(-3L),0xA0616E4BL},{0x6D909BDCL,0x942094BCL,0x6B3C6EF0L,1L,0x69FD0670L},{0L,1L,0L,4L,0x9AC8733DL},{0L,(-4L),0L,0x7411F6EFL,(-1L)},{0L,(-3L),0L,(-1L),8L}},{{0x4F2E69DDL,0x62FABED1L,0L,0x62FABED1L,0x4F2E69DDL},{(-10L),0L,0L,4L,(-1L)},{0xB46A4B17L,0L,0x6B3C6EF0L,0x2FF2273EL,0xEC4223FDL},{3L,0L,(-1L),0L,(-1L)},{0x6F2A60F1L,0x2FF2273EL,0x86D2FA0DL,0x9B2416BEL,0x4F2E69DDL},{(-1L),0xA0616E4BL,(-3L),0L,8L}}};
            int i, j, k;
            for (i = 0; i < 9; i++)
                l_4429[i] = &l_4430;
            (*l_4366) = l_4364;
            if ((l_4029 = (l_4066[3][1] = (l_4065 && ((*l_4364) &= (safe_add_func_int8_t_s_s(p_9, 0UL)))))))
            { /* block id: 2016 */
                int16_t l_4382 = 4L;
                uint32_t l_4413[7];
                int32_t l_4425 = 0x566A6466L;
                int i;
                for (i = 0; i < 7; i++)
                    l_4413[i] = 0UL;
                for (g_1971 = (-4); (g_1971 != 59); g_1971 = safe_add_func_uint64_t_u_u(g_1971, 1))
                { /* block id: 2019 */
                    uint32_t l_4396 = 0UL;
                    for (l_4011 = 19; (l_4011 < (-17)); l_4011--)
                    { /* block id: 2022 */
                        uint64_t l_4373 = 0x79202AC2AD42A9F0LL;
                        --l_4373;
                    }
                    for (l_4185 = (-26); (l_4185 < 2); l_4185++)
                    { /* block id: 2027 */
                        return p_10;
                    }
                    if ((p_11 || (safe_sub_func_uint64_t_u_u((p_9 , ((safe_div_func_int8_t_s_s(1L, (l_4382 & ((safe_lshift_func_int16_t_s_s(0x789BL, 8)) == (((***g_3869) &= (safe_div_func_uint8_t_u_u(p_11, (safe_mul_func_uint16_t_u_u(((((((safe_mod_func_uint32_t_u_u((p_8 &= p_12), (((safe_rshift_func_int8_t_s_s((safe_mod_func_int32_t_s_s((-1L), ((!(((*g_1878) = l_4382) && 7L)) , l_4396))), p_11)) >= l_3983) ^ p_12))) , p_11) | 1L) > l_4382) && p_8) , g_4140), l_4397))))) >= 0xCC10232F8369067ELL))))) == p_11)), (-1L)))))
                    { /* block id: 2033 */
                        return l_4396;
                    }
                    else
                    { /* block id: 2035 */
                        int16_t l_4398[4][8][5] = {{{(-7L),0xE70AL,(-1L),1L,0x2562L},{1L,0x7E3DL,0x1EF7L,0x1EF7L,0x7E3DL},{(-7L),0x2562L,1L,(-1L),0xE70AL},{1L,(-4L),0xB64EL,0x5F02L,0L},{(-7L),0x0117L,0x967AL,0x130DL,0x0977L},{1L,0x22ADL,6L,(-1L),(-1L)},{(-7L),0xB680L,(-1L),(-1L),0xB680L},{1L,(-1L),(-1L),6L,0x22ADL}},{{(-7L),0x0977L,0x130DL,0x967AL,0x0117L},{1L,0L,0x5F02L,0xB64EL,(-4L)},{(-7L),0xE70AL,(-1L),1L,0x2562L},{1L,0x7E3DL,0x1EF7L,0x1EF7L,0x7E3DL},{(-7L),0x2562L,1L,(-1L),0xE70AL},{1L,(-4L),0xB64EL,0x5F02L,0L},{(-7L),0x0117L,0x967AL,0x130DL,0x0977L},{1L,0x22ADL,6L,(-1L),(-1L)}},{{(-7L),0xB680L,(-1L),(-1L),0xB680L},{1L,(-1L),(-1L),6L,0x22ADL},{(-7L),0x0977L,0x130DL,0x967AL,0x0117L},{1L,0L,0x5F02L,0xB64EL,(-4L)},{(-7L),0xE70AL,(-1L),1L,0x2562L},{1L,0x7E3DL,0x1EF7L,0x1EF7L,0x7E3DL},{(-7L),0x2562L,1L,(-1L),0xE70AL},{1L,(-4L),0xB64EL,0x5F02L,0L}},{{(-7L),0x0117L,0x967AL,0x130DL,0x00C0L},{0x9B96L,0x4FB6L,0L,(-4L),(-1L)},{3L,7L,0xB680L,0xB680L,7L},{0x9B96L,(-1L),(-4L),0L,0x4FB6L},{3L,0x00C0L,0xE70AL,0x2562L,0x4C7EL},{0x9B96L,0L,(-1L),0x22ADL,1L},{3L,0x3099L,0x0117L,0x0977L,1L},{0x9B96L,0x7C1AL,0x7E3DL,0x7E3DL,0x7C1AL}}};
                        int i, j, k;
                        if (l_3949)
                            goto lbl_4198;
                        return l_4398[0][1][2];
                    }
                }
                for (g_296 = 1; (g_296 <= 4); g_296 += 1)
                { /* block id: 2042 */
                    int32_t **l_4407 = (void*)0;
                    int32_t *l_4412 = &l_4070[1][0];
                    union U0 l_4422 = {0x9AF6828FB1EA3303LL};
                    for (g_119 = 0; (g_119 <= 4); g_119 += 1)
                    { /* block id: 2045 */
                        int32_t *l_4403 = &g_2641;
                        int32_t **l_4402 = &l_4403;
                        int32_t ***l_4404 = &g_1117;
                        int32_t l_4411 = 0xBBFA1F38L;
                        int i, j;
                        (*l_4366) = ((p_12 = ((*g_3838) &= (0x35A1L > ((((safe_mod_func_uint16_t_u_u(((((l_4401[0][0][1] = &g_1752) != (*g_1844)) >= (-1L)) & ((l_4405[4][4][0] = l_4402) == l_4407)), (~p_12))) >= (((safe_add_func_uint8_t_u_u((l_4411 == p_8), p_9)) ^ (*l_4351)) != p_11)) && p_9) && (*g_2579))))) , l_4412);
                        (*l_4366) = l_4412;
                        (*g_2462) = (***g_2460);
                    }
                    if (l_4413[3])
                        break;
                    l_4425 &= ((*l_4351) = ((safe_lshift_func_uint8_t_u_s((0x17L >= (*g_1878)), 0)) | (0xCFC31110L >= ((safe_sub_func_uint32_t_u_u(((((**l_4366) ^ 0UL) , l_3955) == ((safe_add_func_uint64_t_u_u(((safe_rshift_func_uint64_t_u_s(((**g_248) = ((((l_4422 , (safe_mul_func_uint16_t_u_u(((void*)0 != &g_2037), 0x5FF0L))) , 0x4C7BAD7CD3711B4DLL) ^ 0x88BF53C400E5A477LL) & p_11)), (**l_4366))) && p_9), (*l_4351))) | l_4043)), 0L)) >= p_11))));
                    for (l_4348 = 2; (l_4348 >= 0); l_4348 -= 1)
                    { /* block id: 2060 */
                        int64_t l_4427 = 0x98826489CF6B4F65LL;
                        int i, j, k;
                        if (g_65)
                            goto lbl_4426;
                        if ((*l_4351))
                            break;
                        return l_4427;
                    }
                }
            }
            else
            { /* block id: 2066 */
                int8_t l_4431 = 0x61L;
                int32_t *l_4432 = &l_4348;
                int32_t *l_4434 = (void*)0;
                int32_t *l_4435 = &l_3949;
                int32_t *l_4436 = &g_197[3];
                int32_t *l_4437 = (void*)0;
                int32_t *l_4438 = &g_3031;
                int32_t *l_4439 = &g_3031;
                int32_t *l_4440 = &l_4397;
                int32_t *l_4441 = &l_4070[5][2];
                int32_t *l_4442 = &g_3388;
                int32_t *l_4443 = &g_122;
                int32_t *l_4444 = &l_4064;
                int32_t *l_4445[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_4445[i] = &l_4068;
                (**l_4366) = ((void*)0 != l_4428[2][1]);
                (*l_4351) ^= p_12;
                if (l_4123)
                    continue;
                --g_4450;
            }
        }
    }
    else
    { /* block id: 2073 */
        int32_t *l_4453[8];
        uint32_t l_4476 = 1UL;
        union U0 l_4524 = {0L};
        const int64_t **l_4546[8] = {&g_1754,&g_1754,&g_1754,&g_1754,&g_1754,&g_1754,&g_1754,&g_1754};
        int i;
        for (i = 0; i < 8; i++)
            l_4453[i] = &l_3949;
        ++l_4455;
        for (g_3390 = (-26); (g_3390 < 38); g_3390 = safe_add_func_int32_t_s_s(g_3390, 8))
        { /* block id: 2077 */
            int32_t l_4464 = (-1L);
            uint32_t *l_4469 = &g_887[1][2][0];
            int64_t * const *l_4472 = &g_2579;
            int32_t l_4473[7][9] = {{0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL},{(-1L),(-7L),(-1L),(-1L),(-7L),(-1L),(-1L),(-7L),(-1L)},{0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL},{(-1L),(-7L),(-1L),(-1L),(-7L),(-1L),(-1L),(-7L),(-1L)},{0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL},{(-1L),(-7L),(-1L),(-1L),(-7L),(-1L),(-1L),(-7L),(-1L)},{0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL,0xB7E8AE7EL,0x08367156L,0xB7E8AE7EL}};
            int i, j;
            l_4473[4][5] = (safe_mul_func_int32_t_s_s((safe_add_func_int16_t_s_s(l_4464, (safe_sub_func_int32_t_s_s(p_12, (p_11 != (l_4007 , (~((*l_4469) = (((!(***g_3869)) >= 0x3D2BL) < 0x94D0L))))))))), (safe_lshift_func_int32_t_s_s(((void*)0 != l_4472), 15))));
            if ((*l_4351))
                break;
            for (g_119 = (-7); (g_119 == 15); g_119++)
            { /* block id: 2083 */
                --l_4476;
            }
        }
        for (g_296 = 0; (g_296 <= 2); g_296 += 1)
        { /* block id: 2089 */
            int32_t *l_4479 = (void*)0;
            union U0 l_4494[10][5] = {{{0L},{-6L},{-6L},{0L},{0L}},{{0L},{0xC0DC7176433181C9LL},{1L},{1L},{0xC0DC7176433181C9LL}},{{0L},{-6L},{1L},{0x7633D12CA6288E21LL},{0x7633D12CA6288E21LL}},{{-6L},{0L},{-6L},{1L},{0x7633D12CA6288E21LL}},{{0xC0DC7176433181C9LL},{0L},{0x7633D12CA6288E21LL},{0L},{0xC0DC7176433181C9LL}},{{-6L},{0L},{0L},{0xC0DC7176433181C9LL},{0L}},{{0L},{0L},{0x7633D12CA6288E21LL},{0xC0DC7176433181C9LL},{1L}},{{0L},{-6L},{-6L},{0L},{0L}},{{0L},{0xC0DC7176433181C9LL},{1L},{1L},{0xC0DC7176433181C9LL}},{{0L},{-6L},{1L},{0x7633D12CA6288E21LL},{0x7633D12CA6288E21LL}}};
            int32_t l_4499 = 0x22286C82L;
            const uint64_t ***l_4537 = (void*)0;
            int64_t *l_4557[5] = {&g_28.f0,&g_28.f0,&g_28.f0,&g_28.f0,&g_28.f0};
            int i, j;
            (*g_4480) = l_4479;
            if (g_522[g_296])
                continue;
            for (g_3031 = 2; (g_3031 >= 0); g_3031 -= 1)
            { /* block id: 2094 */
                int32_t *l_4481 = &l_3949;
                int32_t l_4500 = 0x97958653L;
                int32_t l_4501 = 0L;
                int32_t l_4503 = 0x163384EFL;
                uint8_t *****l_4521 = (void*)0;
                int i;
                if (g_522[g_3031])
                { /* block id: 2095 */
                    int32_t l_4497 = 1L;
                    int32_t l_4502[10][10] = {{0x633D4131L,0xDAF8CF03L,0x399C392CL,0x8DDDE8FDL,1L,(-5L),1L,0x8DDDE8FDL,0x399C392CL,0xDAF8CF03L},{0x3ABBA59CL,(-10L),0x399C392CL,1L,(-2L),0x8DDDE8FDL,4L,4L,0x8DDDE8FDL,(-2L)},{0xC43CD10EL,0x3ABBA59CL,0x3ABBA59CL,0xC43CD10EL,(-1L),0x8DDDE8FDL,0x633D4131L,0x399C392CL,0xFA72C8D6L,(-1L)},{0xC43CD10EL,4L,0x633D4131L,(-1L),0x633D4131L,4L,0xC43CD10EL,1L,0xFA72C8D6L,(-2L)},{1L,(-10L),(-5L),0x399C392CL,0xC43CD10EL,0xC43CD10EL,0x399C392CL,(-5L),(-10L),1L},{0x8DDDE8FDL,(-10L),0xFA72C8D6L,0xDAF8CF03L,(-1L),(-2L),0xC43CD10EL,(-2L),(-1L),0xDAF8CF03L},{0xDAF8CF03L,4L,0xDAF8CF03L,(-10L),(-1L),0x3ABBA59CL,1L,0x633D4131L,0x633D4131L,1L},{(-1L),0xC43CD10EL,0x3ABBA59CL,0x3ABBA59CL,0xC43CD10EL,(-1L),0x8DDDE8FDL,0x633D4131L,0x399C392CL,(-2L)},{4L,(-2L),0xDAF8CF03L,(-5L),0x633D4131L,(-5L),0xDAF8CF03L,(-2L),4L,(-1L)},{4L,0x3ABBA59CL,0xFA72C8D6L,0x8DDDE8FDL,(-5L),(-1L),(-1L),(-5L),0x8DDDE8FDL,0xFA72C8D6L}};
                    int i, j;
                    for (g_4450 = 0; (g_4450 <= 2); g_4450 += 1)
                    { /* block id: 2098 */
                        int32_t **l_4482 = &g_1158[3][2];
                        int i;
                        (*l_4482) = l_4481;
                        (*l_4351) ^= g_522[g_3031];
                    }
                    for (g_267 = 0; (g_267 <= 2); g_267 += 1)
                    { /* block id: 2104 */
                        int64_t l_4498 = 0x1C61AAD270FFD1B0LL;
                        uint32_t l_4504 = 0x66336764L;
                        int i;
                        (*l_4351) = (safe_lshift_func_int64_t_s_s(((safe_unary_minus_func_uint64_t_u((safe_rshift_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(((*g_513) = 1L), (safe_sub_func_int64_t_s_s(((((**g_2009) = (safe_lshift_func_uint32_t_u_u(((g_522[g_267] , (l_4494[2][4] , 0UL)) ^ (((safe_rshift_func_uint32_t_u_s((p_10 > p_11), (0xF6L || ((*l_4351) && p_11)))) != 4UL) != 0x6D591657L)), 0))) != p_11) < 8UL), 0x483CCCBC92716D89LL)))), (*l_4481))))) == p_8), 6));
                        l_4504++;
                    }
                    for (g_1971 = 0; (g_1971 <= 49); g_1971 = safe_add_func_int64_t_s_s(g_1971, 6))
                    { /* block id: 2112 */
                        return p_8;
                    }
                }
                else
                { /* block id: 2115 */
                    uint64_t ****l_4536 = &g_3869;
                    uint16_t *l_4547 = &g_179;
                    int32_t l_4548 = 0xB56AECD7L;
                    int32_t l_4550 = 1L;
                    uint8_t l_4568 = 0UL;
                    const int64_t l_4569 = 0x93F85633E876B565LL;
                    for (g_122 = 0; (g_122 <= (-6)); g_122--)
                    { /* block id: 2118 */
                        uint8_t *l_4525[1][2][9] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_3933,&l_3933},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_3933,&l_3933}}};
                        int i, j, k;
                        l_4503 = (safe_add_func_uint8_t_u_u((((**g_248) &= p_12) , (****g_2082)), (g_2541[1] |= ((safe_sub_func_uint16_t_u_u((safe_mul_func_uint32_t_u_u(p_10, ((*l_4481) = (safe_sub_func_uint16_t_u_u((!(~(l_4521 == l_4521))), (safe_lshift_func_int64_t_s_u((*g_2579), 21))))))), (l_4524 , ((*g_513) = (*g_513))))) == 0x60L))));
                    }
                    l_4064 |= (*l_4351);
                    l_4550 ^= (safe_rshift_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((!((((p_11 == (*l_4481)) , (l_4531 != (((((+(safe_div_func_uint8_t_u_u(255UL, ((!(((*l_4536) = &g_248) != l_4537)) , ((safe_add_func_int64_t_s_s(((*l_4351) <= (safe_add_func_int8_t_s_s((((((*l_4406) = p_8) , ((*g_2579) = ((safe_sub_func_uint16_t_u_u(((*l_4547) = (safe_div_func_int8_t_s_s(((*g_1878) = ((g_213 , l_4546[3]) == l_4546[3])), 0x5DL))), p_11)) == l_4548))) | (*l_4481)) , (*g_1878)), (*****g_2081)))), l_4549)) ^ 0x011FL))))) < 0x84617000L) != p_11) >= 0L) , &p_12))) == (*l_4351)) , (*l_4351))), l_4548)), 6));
                    for (g_3356 = 0; (g_3356 <= 6); g_3356 += 1)
                    { /* block id: 2134 */
                        int32_t l_4570[3][3] = {{(-1L),2L,(-1L)},{(-10L),(-10L),(-10L)},{(-1L),2L,(-1L)}};
                        int i, j;
                        if ((*l_4351))
                            break;
                        if (p_10)
                            continue;
                        l_4499 &= ((p_8 <= (0x7D32L < ((((safe_add_func_int32_t_s_s(((safe_lshift_func_uint64_t_u_u((l_4550 | ((l_4557[2] = (void*)0) == ((*g_143) , &g_522[g_3031]))), 36)) | (((safe_mul_func_uint32_t_u_u(((*l_4481) == ((safe_rshift_func_int16_t_s_s((safe_add_func_int32_t_s_s(((safe_mul_func_int32_t_s_s((safe_mod_func_int16_t_s_s(((l_4568 &= p_9) <= (((((0xD85AL ^ (*g_513)) || p_12) | p_8) ^ p_12) != p_8)), l_4569)), p_10)) != l_4570[2][1]), p_12)), 13)) , 0x8DFEL)), 0x4F8D1C98L)) & l_4550) , p_10)), p_9)) >= p_11) , 6UL) >= p_12))) == p_10);
                    }
                }
                if (p_12)
                    continue;
                (*l_4351) = ((void*)0 != &g_513);
            }
        }
    }
    return g_4571;
}


/* ------------------------------------------ */
/* 
 * reads : g_2541 g_2081 g_2082 g_2008 g_2009 g_2010 g_197 g_585 g_635 g_513 g_143 g_122 g_3275 g_1878 g_424 g_425 g_1879 g_91 g_1353.f0 g_248 g_249 g_82 g_2007 g_506 g_1015 g_1016 g_1017 g_2202 g_1096 g_1097 g_2579 g_201 g_600 g_3388 g_3390 g_2578 g_2431 g_234 g_235 g_2461 g_2462 g_436 g_1300 g_631 g_1844 g_267 g_101 g_102 g_3653 g_1931 g_1808 g_6 g_186 g_2844 g_3708 g_522 g_887 g_233 g_3788 g_3356 g_103.f0 g_3836 g_1157 g_2460 g_194 g_195 g_2638 g_65
 * writes: g_506 g_197 g_2202 g_91 g_122 g_3275 g_1879 g_436 g_82 g_424 g_887 g_201 g_235 g_2431 g_3390 g_2032 g_1808 g_632 g_1845 g_267 g_635 g_3708 g_65 g_2844 g_600 g_3788 g_3792 g_3836 g_1158 g_3868 g_2949 g_179
 */
static uint16_t  func_16(const uint8_t  p_17, uint8_t  p_18, int8_t  p_19)
{ /* block id: 1496 */
    int8_t l_3197[5][8][2] = {{{0x6AL,0x87L},{9L,0x4CL},{0xBFL,1L},{0x87L,0xBFL},{0L,0xE1L},{0L,0xBFL},{0x87L,1L},{0xBFL,0x4CL}},{{9L,0x87L},{0x6AL,(-1L)},{(-1L),0x38L},{9L,3L},{0x22L,9L},{(-6L),(-1L)},{0x4CL,(-1L)},{(-6L),9L}},{{0x22L,3L},{9L,0x38L},{(-1L),(-1L)},{0x6AL,0x87L},{9L,0x4CL},{0xBFL,1L},{0x87L,0xBFL},{0L,0xE1L}},{{0L,0xBFL},{0x87L,1L},{0xBFL,0x4CL},{9L,0x87L},{0x6AL,(-1L)},{(-1L),0x38L},{9L,3L},{0x22L,9L}},{{(-6L),(-1L)},{0x4CL,(-1L)},{(-6L),9L},{0x22L,3L},{9L,0x38L},{(-1L),(-1L)},{0x6AL,0x87L},{9L,0x4CL}}};
    int32_t * const l_3198 = &g_197[0];
    int32_t l_3257 = 0xAF211E31L;
    int32_t l_3258 = (-8L);
    uint64_t l_3259 = 18446744073709551610UL;
    int32_t l_3265 = 6L;
    const union U0 *l_3274[2];
    const union U0 **l_3273[9][8] = {{&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0]},{&l_3274[0],&l_3274[0],&l_3274[1],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0]},{&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0]},{&l_3274[1],&l_3274[0],&l_3274[0],&l_3274[1],&l_3274[0],&l_3274[1],&l_3274[0],&l_3274[0]},{&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0]},{&l_3274[1],&l_3274[0],&l_3274[1],&l_3274[0],&l_3274[0],&l_3274[1],&l_3274[0],&l_3274[1]},{&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0]},{&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0],&l_3274[0]},{&l_3274[1],&l_3274[0],&l_3274[0],&l_3274[1],&l_3274[0],&l_3274[1],&l_3274[0],&l_3274[0]}};
    const union U0 ***l_3272 = &l_3273[0][4];
    int32_t *l_3335 = (void*)0;
    int32_t **l_3334 = &l_3335;
    int32_t l_3353 = 0x6F2F09B5L;
    int32_t l_3354[1][9][7] = {{{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)},{0x667CA538L,4L,(-5L),(-5L),4L,0x667CA538L,(-1L)}}};
    uint16_t l_3395[8] = {6UL,0UL,6UL,0UL,6UL,0UL,6UL,0UL};
    uint8_t ****l_3438 = (void*)0;
    int32_t l_3614 = 0x6F97EC63L;
    int32_t ***l_3695 = &g_1157[0];
    int64_t l_3704 = (-8L);
    int16_t **l_3711 = (void*)0;
    const uint8_t ***l_3736 = (void*)0;
    uint64_t ***l_3744 = (void*)0;
    uint64_t ****l_3743 = &l_3744;
    uint64_t *****l_3742 = &l_3743;
    uint64_t l_3796[8] = {0UL,0x9B3A445774BC6D1CLL,0UL,0x9B3A445774BC6D1CLL,0UL,0x9B3A445774BC6D1CLL,0UL,0x9B3A445774BC6D1CLL};
    uint64_t l_3801 = 0x724F44F670B29869LL;
    int32_t l_3841 = 0x5F512AC8L;
    int64_t l_3859[7][8][4] = {{{0x3FABCA811AB2009FLL,(-7L),0x8201EEE445B79CC2LL,0x39DE7920948A3D1ALL},{0xA0EEC61D6F16E067LL,8L,1L,1L},{0xD753E5899026163BLL,0x735143E27273787ELL,0x8A97404D3E37BE63LL,0x5267E512882076C4LL},{8L,0L,(-5L),0xD753E5899026163BLL},{0x80CA281A4C83E3E2LL,0x43A36A0954DEFBAFLL,0x80CA281A4C83E3E2LL,(-1L)},{8L,0xCD6485196650D6A9LL,0xF3D17E1025D2E4E3LL,8L},{1L,0x33E9A93F1C7E3A9DLL,(-6L),0xCD6485196650D6A9LL},{0xD93880079D79617FLL,0xAC52B68FBCD956C0LL,(-6L),(-5L)}},{{1L,0x39DE7920948A3D1ALL,0xF3D17E1025D2E4E3LL,3L},{8L,(-7L),0x80CA281A4C83E3E2LL,0x281FDDDB480651B5LL},{0x80CA281A4C83E3E2LL,0x281FDDDB480651B5LL,(-5L),(-3L)},{8L,0L,0x8A97404D3E37BE63LL,2L},{0xD753E5899026163BLL,0x91F84803B27B2EA0LL,1L,0x50F23E6A7D489CC7LL},{0x8C6F4F77371B0095LL,0x33E9A93F1C7E3A9DLL,0xA3046751E5795EA2LL,5L},{0L,0L,0x758C3F59323D217DLL,0xA0EEC61D6F16E067LL},{0L,2L,6L,0x33E9A93F1C7E3A9DLL}},{{(-1L),0x9A56D80D0535E24BLL,0x00877F747CFE301CLL,0x046561364312B1D4LL},{0xF49031CF38922BCFLL,0xC06939A8431216F7LL,0x735143E27273787ELL,0L},{1L,0xE7390E9CCF1936EELL,9L,1L},{0x2349EEB908F8A017LL,1L,0x97C09E962078E077LL,0xF6FAA0A75E393EA8LL},{0x80CA281A4C83E3E2LL,0L,0xD753E5899026163BLL,(-6L)},{0xA0EEC61D6F16E067LL,0x00877F747CFE301CLL,0x2810EB0D87C768C3LL,4L},{0x2349EEB908F8A017LL,(-6L),(-1L),5L},{(-5L),0xD2BE90AF3ABBB321LL,0x735143E27273787ELL,0L}},{{(-1L),(-1L),(-1L),(-1L)},{(-1L),0xE912F89016FA79EALL,0x8A97404D3E37BE63LL,0x1A0C2F2B478F5BD2LL},{0x91F84803B27B2EA0LL,(-1L),0x758C3F59323D217DLL,1L},{0xC06939A8431216F7LL,0xE7390E9CCF1936EELL,5L,1L},{0x8C6F4F77371B0095LL,(-1L),5L,0x1A0C2F2B478F5BD2LL},{0xD93880079D79617FLL,0xE912F89016FA79EALL,0xD753E5899026163BLL,(-1L)},{0x8201EEE445B79CC2LL,(-1L),0x046561364312B1D4LL,0L},{(-1L),0xD2BE90AF3ABBB321LL,0x8C6F4F77371B0095LL,5L}},{{(-1L),(-6L),0x50F23E6A7D489CC7LL,4L},{0x2453E5F97FEFF3F3LL,0x00877F747CFE301CLL,0xE7390E9CCF1936EELL,(-6L)},{(-1L),0L,0x0F2A748BFB183FC4LL,0xF6FAA0A75E393EA8LL},{(-7L),1L,0x50F23E6A7D489CC7LL,1L},{1L,0xE7390E9CCF1936EELL,0x2349EEB908F8A017LL,0L},{(-1L),0xC06939A8431216F7LL,0x1A0C2F2B478F5BD2LL,0x046561364312B1D4LL},{4L,0x9A56D80D0535E24BLL,0xD753E5899026163BLL,0x33E9A93F1C7E3A9DLL},{0L,2L,(-1L),0xA0EEC61D6F16E067LL}},{{0x8C6F4F77371B0095LL,0L,0xF448B4CFAAFE56A7LL,5L},{2L,0x33E9A93F1C7E3A9DLL,0x758C3F59323D217DLL,0x80CA281A4C83E3E2LL},{0x33E9A93F1C7E3A9DLL,2L,(-1L),0x91F84803B27B2EA0LL},{(-1L),4L,2L,0x046561364312B1D4LL},{0xD2BE90AF3ABBB321LL,2L,0x735143E27273787ELL,2L},{(-3L),0xE7390E9CCF1936EELL,0x8737749430CAAE63LL,(-1L)},{0x2349EEB908F8A017LL,(-5L),0L,0xF6FAA0A75E393EA8LL},{0xE912F89016FA79EALL,0L,0xD753E5899026163BLL,(-7L)}},{{0xE912F89016FA79EALL,0x00877F747CFE301CLL,0L,0x9A56D80D0535E24BLL},{0x2349EEB908F8A017LL,(-7L),0x8737749430CAAE63LL,5L},{(-3L),0xF49031CF38922BCFLL,0x735143E27273787ELL,0L},{0xD2BE90AF3ABBB321LL,(-1L),2L,0xD2BE90AF3ABBB321LL},{(-1L),0xA0EEC61D6F16E067LL,(-1L),0x1A0C2F2B478F5BD2LL},{0x33E9A93F1C7E3A9DLL,(-1L),0x758C3F59323D217DLL,(-5L)},{2L,0xE7390E9CCF1936EELL,0xF448B4CFAAFE56A7LL,(-3L)},{0x8C6F4F77371B0095LL,1L,(-1L),0x1A0C2F2B478F5BD2LL}}};
    uint32_t l_3918 = 0xD4282446L;
    uint16_t l_3922 = 1UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_3274[i] = (void*)0;
lbl_3453:
    if (l_3197[1][7][1])
    { /* block id: 1497 */
        int32_t *l_3199 = &g_122;
        l_3199 = l_3198;
        return g_2541[1];
    }
    else
    { /* block id: 1500 */
        uint16_t l_3219 = 0UL;
        uint64_t ** const *l_3232 = &g_248;
        uint64_t ** const **l_3231 = &l_3232;
        uint64_t ** const ***l_3230[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t l_3233[1];
        uint8_t **l_3236 = &g_2010;
        int32_t *l_3249 = &g_2949;
        int32_t **l_3248 = &l_3249;
        int16_t l_3250[4] = {3L,3L,3L,3L};
        int32_t l_3251 = 0x401A9AB8L;
        union U0 * const **l_3270 = (void*)0;
        int i;
        for (i = 0; i < 1; i++)
            l_3233[i] = 3L;
        (*l_3198) = (+(safe_add_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((safe_mul_func_uint64_t_u_u(((p_17 | 1UL) , ((p_19 < p_17) | ((safe_rshift_func_int32_t_s_u((safe_rshift_func_uint16_t_u_s((safe_add_func_int32_t_s_s(((((safe_lshift_func_uint16_t_u_u(((safe_mod_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((*****g_2081) = (l_3219 & p_19)), ((safe_mod_func_int16_t_s_s((safe_add_func_uint16_t_u_u((l_3233[0] = (((safe_mod_func_int64_t_s_s(l_3219, (((safe_lshift_func_int8_t_s_u((safe_sub_func_int32_t_s_s(((l_3230[3] = l_3230[2]) != (void*)0), p_19)), l_3219)) != 0x445A9A52L) && (*l_3198)))) != (*l_3198)) , 0x3815L)), g_585)), 0xEC16L)) , 1UL))), 2UL)) > l_3219), 2)) | p_19) > p_18) | p_19), p_18)), p_19)), 23)) | l_3219))), l_3219)), 246UL)), g_635)));
        for (g_2202 = 0; (g_2202 <= 5); g_2202 += 1)
        { /* block id: 1507 */
            int32_t *l_3246[7][1][2] = {{{&g_2641,&g_2641}},{{&g_2641,&g_2641}},{{&g_2641,&g_2641}},{{&g_2641,&g_2641}},{{&g_2641,&g_2641}},{{&g_2641,&g_2641}},{{&g_2641,&g_2641}}};
            int32_t **l_3245[8] = {&l_3246[3][0][1],&l_3246[3][0][1],&l_3246[3][0][1],&l_3246[3][0][1],&l_3246[3][0][1],&l_3246[3][0][1],&l_3246[3][0][1],&l_3246[3][0][1]};
            int32_t ***l_3247 = &l_3245[4];
            const int32_t l_3252[5][10][5] = {{{0L,0x87C674F3L,0xE47D27FAL,0x72D6B9D0L,0x9499FC58L},{0xE18D1812L,0xF216F5F8L,(-1L),0xEECA9A03L,(-1L)},{0L,0x72D6B9D0L,0L,(-1L),0xA276C8EFL},{(-1L),0x943F5E81L,0xEECA9A03L,0L,0xE18D1812L},{6L,8L,0xE47D27FAL,(-1L),0xE47D27FAL},{(-1L),(-1L),(-1L),0x050791E1L,0xB214E9F4L},{0L,(-1L),(-1L),1L,0L},{0xE18D1812L,0xEECA9A03L,0xB73AFB11L,0L,1L},{0L,(-1L),0L,8L,0x9499FC58L},{0xB214E9F4L,(-1L),0x943F5E81L,0xEECA9A03L,0L}},{{0xA276C8EFL,8L,0L,0x8A9671CEL,0L},{1L,0x943F5E81L,0x943F5E81L,1L,(-1L)},{6L,0x72D6B9D0L,0L,0x87C674F3L,0xE47D27FAL},{0L,0xF216F5F8L,0xB73AFB11L,0x050791E1L,(-9L)},{0xA276C8EFL,0x87C674F3L,(-1L),0x87C674F3L,0xA276C8EFL},{(-1L),0xEECA9A03L,(-1L),1L,0xF216F5F8L},{0L,0x9E64F0A6L,0xE47D27FAL,0x8A9671CEL,0x9499FC58L},{(-9L),0xF216F5F8L,0xEECA9A03L,0xEECA9A03L,0xF216F5F8L},{0L,0x8A9671CEL,0L,8L,0xA276C8EFL},{0xF216F5F8L,0x943F5E81L,(-1L),0L,(-9L)}},{{6L,(-1L),0xE47D27FAL,1L,0xE47D27FAL},{0xF216F5F8L,(-1L),(-7L),0x050791E1L,(-1L)},{0L,1L,(-1L),(-1L),0L},{(-9L),0xEECA9A03L,0x1A545A6BL,0L,0L},{0L,1L,0L,(-1L),0x9499FC58L},{(-1L),(-1L),0x050791E1L,0xEECA9A03L,1L},{0xA276C8EFL,(-1L),0L,0x72D6B9D0L,0L},{0L,0x943F5E81L,0x050791E1L,1L,0xB214E9F4L},{6L,0x8A9671CEL,0L,0x9E64F0A6L,0xE47D27FAL},{1L,0xF216F5F8L,0x1A545A6BL,0x050791E1L,0xE18D1812L}},{{0xA276C8EFL,0x9E64F0A6L,(-1L),0x9E64F0A6L,0xA276C8EFL},{0xB214E9F4L,0xEECA9A03L,(-7L),1L,(-1L)},{0L,0x87C674F3L,0xE47D27FAL,0x72D6B9D0L,0x9499FC58L},{0xE18D1812L,0xF216F5F8L,(-1L),0xEECA9A03L,(-1L)},{0L,0x72D6B9D0L,0L,(-1L),0xA276C8EFL},{(-1L),0x943F5E81L,0xEECA9A03L,0L,0xE18D1812L},{6L,8L,0xE47D27FAL,(-1L),0xE47D27FAL},{(-1L),(-1L),(-1L),0x050791E1L,0xB214E9F4L},{0L,(-1L),(-1L),1L,0L},{0xE18D1812L,0xEECA9A03L,0xB73AFB11L,0L,1L}},{{0L,(-1L),0L,8L,0x9499FC58L},{0xB214E9F4L,(-1L),0x943F5E81L,0xEECA9A03L,0L},{0xA276C8EFL,8L,0L,0x8A9671CEL,0L},{1L,0x943F5E81L,0x943F5E81L,1L,(-1L)},{6L,0x72D6B9D0L,0L,0x87C674F3L,0xE47D27FAL},{0L,0xF216F5F8L,0xB73AFB11L,0x050791E1L,(-9L)},{0xA276C8EFL,0x87C674F3L,(-1L),0x87C674F3L,0xA276C8EFL},{(-1L),0xEECA9A03L,(-1L),1L,0xF216F5F8L},{0L,0x9E64F0A6L,0xE47D27FAL,0x8A9671CEL,0x9499FC58L},{(-9L),0xF216F5F8L,0xEECA9A03L,0xEECA9A03L,0xF216F5F8L}}};
            int32_t *l_3253 = &g_122;
            uint64_t l_3254 = 0x75FB6E6831202DBDLL;
            int64_t l_3255 = (-1L);
            int32_t *l_3256[6] = {&l_3233[0],&l_3233[0],&l_3233[0],&l_3233[0],&l_3233[0],&l_3233[0]};
            union U0 * const ***l_3271 = &l_3270;
            int i, j, k;
            l_3255 = ((safe_rshift_func_int32_t_s_s(((((*l_3253) = ((l_3233[0] < ((l_3236 == (void*)0) ^ (safe_div_func_uint8_t_u_u(((safe_sub_func_uint64_t_u_u((l_3251 = ((((safe_mod_func_int32_t_s_s(l_3219, ((*l_3198) |= 1L))) , 0x8396L) | (((p_17 > ((*g_513) = (0UL == (((*l_3247) = ((safe_sub_func_int32_t_s_s(l_3233[0], 1L)) , l_3245[4])) == l_3248)))) >= p_18) > l_3250[1])) , 0x6E15135D8FF09EB2LL)), p_17)) ^ l_3252[0][0][3]), l_3219)))) && l_3233[0])) && l_3254) <= 0xDCF4C02EL), p_17)) <= p_19);
            l_3259++;
            (*l_3198) = (~((*g_143) >= ((safe_rshift_func_uint32_t_u_u((p_17 && (l_3233[0] || (0xD57A3CAAL & (p_18 && l_3265)))), 13)) , (((safe_mul_func_int16_t_s_s((safe_mul_func_uint32_t_u_u(((l_3250[3] , 4UL) , (((*l_3271) = l_3270) != l_3272)), 2L)), (-4L))) , p_17) | (*l_3253)))));
        }
        ++g_3275;
    }
    if (p_18)
    { /* block id: 1520 */
        int16_t l_3278 = (-1L);
        int32_t l_3279 = 0x78EA4D8EL;
        int32_t *l_3280 = &g_122;
        int32_t *l_3281[6][1];
        uint8_t l_3282[6] = {0UL,4UL,4UL,0UL,4UL,4UL};
        union U0 l_3295 = {1L};
        int i, j;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 1; j++)
                l_3281[i][j] = &l_3279;
        }
        l_3282[3]--;
        if ((safe_mod_func_uint64_t_u_u(((((*g_1878) = (*l_3198)) || (safe_mul_func_uint16_t_u_u(((0x53F9L & (*g_424)) == (1L < (safe_lshift_func_int8_t_s_s((*g_1878), 6)))), (safe_sub_func_int32_t_s_s(((((safe_lshift_func_int16_t_s_s(((*g_513) ^= (&l_3198 == (l_3295 , &l_3281[3][0]))), (((-1L) >= 0xBD71138FL) || g_1353.f0))) == (-10L)) & (*l_3198)) & (*l_3198)), 0xDA658DADL))))) ^ 9UL), p_19)))
        { /* block id: 1524 */
            uint16_t l_3314 = 0x6719L;
            int32_t l_3320[4] = {3L,3L,3L,3L};
            int i;
            for (g_436 = (-15); (g_436 < 27); g_436 = safe_add_func_int64_t_s_s(g_436, 9))
            { /* block id: 1527 */
                uint64_t *l_3317 = &g_3275;
                uint64_t *l_3318 = &g_2202;
                if ((safe_sub_func_uint64_t_u_u(((**g_248) ^= 0x8CE8CF57A53CECCDLL), (safe_mod_func_uint64_t_u_u(((*l_3318) |= ((((((*g_513) = (*l_3280)) & ((*l_3198) = (((((safe_mul_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(((*l_3317) = (safe_add_func_int32_t_s_s((*l_3198), (p_17 >= (p_18 ^ (safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u(l_3314, l_3314)) < (safe_div_func_int64_t_s_s(p_17, p_19))) >= 255UL), (****g_2007))), (**g_1015)))))))), p_17)), (*g_424))) , (*l_3280)) , p_17) && (-1L)) <= p_19))) < 1UL) , 65534UL) , p_17)), 0xECD28333A5EACB38LL)))))
                { /* block id: 1533 */
                    return (*l_3198);
                }
                else
                { /* block id: 1535 */
                    const int16_t **l_3319 = &g_424;
                    l_3320[1] &= (((*l_3319) = (void*)0) == (void*)0);
                    return (*l_3280);
                }
            }
        }
        else
        { /* block id: 1541 */
            for (g_91 = (-12); (g_91 > (-19)); --g_91)
            { /* block id: 1544 */
                int32_t l_3323 = (-5L);
                return l_3323;
            }
        }
    }
    else
    { /* block id: 1548 */
        uint16_t l_3328 = 0xF1AEL;
        int32_t ***l_3336[9] = {&g_1117,&g_1117,&g_1117,&g_1117,&g_1117,&g_1117,&g_1117,&g_1117,&g_1117};
        int32_t l_3337[5][9] = {{0xBB215852L,0xBB215852L,0x656C304AL,2L,0L,1L,0xE1CEFFB7L,1L,0L},{0x656C304AL,0xBB215852L,0xBB215852L,0x656C304AL,2L,0L,1L,0xE1CEFFB7L,1L},{0xE1CEFFB7L,0x239A60D3L,0x656C304AL,0x656C304AL,0x239A60D3L,0xE1CEFFB7L,9L,0xBB215852L,9L},{0xD10A4A4CL,0L,0xE1CEFFB7L,2L,2L,0xE1CEFFB7L,0L,0xD10A4A4CL,0x239A60D3L},{9L,0x656C304AL,0xD10A4A4CL,9L,0L,0L,9L,0xD10A4A4CL,0x656C304AL}};
        int16_t l_3357 = 0x81ECL;
        uint8_t l_3391 = 0x8FL;
        union U0 * const ****l_3457 = (void*)0;
        int32_t *l_3464[5][2][8] = {{{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353},{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353}},{{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353},{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353}},{{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353},{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353}},{{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353},{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353}},{{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353},{&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353,&g_65,&l_3353}}};
        uint8_t **l_3477[8][3][3] = {{{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010},{&g_2010,(void*)0,&g_2010}},{{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010}},{{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,(void*)0},{&g_2010,(void*)0,&g_2010}},{{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,(void*)0}},{{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010}},{{&g_2010,(void*)0,&g_2010},{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010}},{{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,(void*)0}},{{&g_2010,(void*)0,&g_2010},{&g_2010,&g_2010,&g_2010},{&g_2010,&g_2010,&g_2010}}};
        int64_t **l_3481 = &g_2579;
        uint64_t l_3498[1];
        uint64_t **l_3521 = &g_249[6];
        int8_t l_3522 = 1L;
        uint16_t l_3582 = 0UL;
        uint8_t ***l_3612[3];
        uint8_t **** const l_3611 = &l_3612[2];
        uint8_t **** const *l_3610 = &l_3611;
        const int32_t *l_3636[8] = {&g_2949,&g_2949,&g_2949,&g_2949,&g_2949,&g_2949,&g_2949,&g_2949};
        const int32_t **l_3635 = &l_3636[5];
        const int32_t ***l_3634[7] = {&l_3635,&l_3635,&l_3635,&l_3635,&l_3635,&l_3635,&l_3635};
        union U0 ****l_3648 = &g_1484;
        union U0 *l_3655 = &g_1353;
        int8_t l_3667 = 1L;
        int32_t ***l_3684 = &g_1157[2];
        int32_t *** const *l_3683[9][3][1] = {{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}},{{&l_3684},{&l_3684},{&l_3684}}};
        const uint8_t ***l_3737 = &g_1015;
        uint32_t l_3852 = 0xADE002C6L;
        uint16_t l_3874 = 0xE25EL;
        uint32_t l_3877 = 0xFBE92A54L;
        uint16_t l_3923[4];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_3498[i] = 0UL;
        for (i = 0; i < 3; i++)
            l_3612[i] = &l_3477[2][2][0];
        for (i = 0; i < 4; i++)
            l_3923[i] = 65535UL;
        if ((safe_mul_func_uint64_t_u_u((*g_1096), (safe_add_func_uint8_t_u_u(((0xADL > p_18) | (l_3328 ^ (((safe_div_func_int16_t_s_s((*g_513), p_18)) && (~(safe_mul_func_uint8_t_u_u(((l_3334 = l_3334) != &l_3335), ((*g_2579) == p_19))))) || p_19))), p_17)))))
        { /* block id: 1550 */
            int64_t l_3338 = 1L;
            int32_t *l_3339 = (void*)0;
            int32_t *l_3340 = (void*)0;
            int32_t *l_3341 = &g_197[1];
            int32_t *l_3342 = &g_122;
            int32_t *l_3343 = &g_197[3];
            int32_t *l_3344 = &l_3337[1][8];
            int32_t *l_3345 = &g_122;
            int32_t *l_3346 = &g_65;
            int32_t *l_3347 = (void*)0;
            int32_t l_3348 = 0xF967BA2BL;
            int32_t *l_3349 = &l_3257;
            int32_t *l_3350 = &l_3258;
            int32_t *l_3351 = &g_3031;
            int32_t *l_3352[5][8] = {{&g_6,&l_3337[1][8],&l_3337[1][8],&g_6,&l_3337[1][8],&l_3337[1][8],&g_6,&l_3337[1][8]},{&g_6,&g_6,&g_197[3],&g_6,&g_6,&g_197[3],&g_6,&g_6},{&l_3337[1][8],&g_6,&l_3337[1][8],&l_3337[1][8],&g_6,&l_3337[1][8],&l_3337[1][8],&g_6},{&g_6,&l_3337[1][8],&l_3337[1][8],&g_6,&l_3337[1][8],&l_3337[1][8],&g_6,&l_3337[1][8]},{&g_6,&g_6,&g_197[3],&g_6,&g_6,&g_197[3],&g_6,&g_6}};
            int8_t l_3355 = (-1L);
            uint32_t l_3358 = 9UL;
            int i, j;
            ++l_3358;
        }
        else
        { /* block id: 1552 */
            uint32_t l_3387 = 0x27D07A28L;
            uint32_t *l_3389 = &g_887[4][2][0];
            int32_t l_3420[2][7] = {{0L,0x437008B2L,0L,0x437008B2L,0L,0x437008B2L,0L},{0x1611EAFDL,0x1611EAFDL,0x1611EAFDL,0x1611EAFDL,0x1611EAFDL,0x1611EAFDL,0x1611EAFDL}};
            int8_t l_3425 = 0L;
            int32_t * const ****l_3452 = (void*)0;
            union U0 * const **l_3456[10] = {&g_194,&g_194,&g_194,&g_194,&g_194,&g_194,&g_194,&g_194,&g_194,&g_194};
            union U0 * const ***l_3455[3][9][5] = {{{&l_3456[4],&l_3456[4],&l_3456[3],&l_3456[4],&l_3456[3]},{&l_3456[7],&l_3456[7],&l_3456[4],&l_3456[4],&l_3456[7]},{&l_3456[4],(void*)0,&l_3456[9],&l_3456[4],(void*)0},{&l_3456[4],&l_3456[6],&l_3456[4],(void*)0,&l_3456[4]},{&l_3456[9],(void*)0,&l_3456[4],(void*)0,&l_3456[8]},{&l_3456[4],&l_3456[7],&l_3456[7],&l_3456[4],&l_3456[4]},{&l_3456[3],&l_3456[4],&l_3456[4],&l_3456[7],&l_3456[6]},{&l_3456[4],(void*)0,&l_3456[4],(void*)0,&l_3456[4]},{&l_3456[4],(void*)0,&l_3456[9],&l_3456[7],&l_3456[4]}},{{&l_3456[4],&l_3456[4],&l_3456[4],&l_3456[4],&l_3456[4]},{(void*)0,&l_3456[8],&l_3456[3],(void*)0,&l_3456[4]},{(void*)0,&l_3456[4],&l_3456[4],(void*)0,&l_3456[4]},{&l_3456[4],&l_3456[4],&l_3456[4],&l_3456[4],&l_3456[6]},{(void*)0,&l_3456[7],&l_3456[4],&l_3456[4],&l_3456[4]},{(void*)0,&l_3456[8],(void*)0,&l_3456[4],&l_3456[8]},{&l_3456[4],&l_3456[7],(void*)0,&l_3456[4],&l_3456[4]},{&l_3456[4],&l_3456[4],&l_3456[4],&l_3456[4],(void*)0},{&l_3456[4],&l_3456[4],(void*)0,&l_3456[4],&l_3456[7]}},{{&l_3456[3],&l_3456[8],(void*)0,&l_3456[8],&l_3456[3]},{&l_3456[4],&l_3456[4],&l_3456[4],&l_3456[4],&l_3456[7]},{&l_3456[9],(void*)0,&l_3456[4],&l_3456[4],&l_3456[4]},{&l_3456[4],(void*)0,&l_3456[4],&l_3456[4],&l_3456[7]},{&l_3456[4],&l_3456[4],&l_3456[3],&l_3456[4],&l_3456[3]},{&l_3456[7],&l_3456[7],&l_3456[4],&l_3456[4],&l_3456[7]},{&l_3456[4],(void*)0,&l_3456[9],&l_3456[4],(void*)0},{&l_3456[4],&l_3456[6],&l_3456[4],(void*)0,&l_3456[4]},{&l_3456[9],(void*)0,&l_3456[4],(void*)0,&l_3456[8]}}};
            union U0 * const ****l_3454 = &l_3455[0][8][1];
            uint32_t l_3485[6] = {0x58074B64L,0UL,0x58074B64L,0x58074B64L,0UL,0x58074B64L};
            int8_t l_3489 = (-1L);
            int64_t ****l_3501[1];
            uint64_t l_3545 = 0UL;
            int32_t ****l_3546 = &l_3336[4];
            union U0 *l_3597 = &g_28;
            int64_t ****l_3754 = &g_2943[0];
            uint32_t ***l_3840 = &g_3837[0][1][0];
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_3501[i] = (void*)0;
            if ((safe_sub_func_int32_t_s_s((safe_lshift_func_int64_t_s_s(2L, 22)), (safe_sub_func_uint16_t_u_u((safe_mod_func_int64_t_s_s(((**g_2578) = (p_19 >= (safe_div_func_int64_t_s_s((safe_add_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_s(((safe_mod_func_int8_t_s_s(((p_17 , ((safe_lshift_func_int64_t_s_u((p_18 > (safe_rshift_func_int8_t_s_s((l_3328 | (9UL <= (safe_div_func_uint64_t_u_u((((((**g_248) = (p_17 || ((*l_3198) || ((*l_3389) = ((((((safe_mod_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u(p_19, g_600)), 7UL)) == p_17) || p_17) || l_3387) , l_3337[1][8]) < g_3388))))) >= p_17) >= g_3390) & 0x9A4D9CD46AC13EB5LL), (*l_3198))))), 7))), 38)) & p_17)) != p_17), (****g_2082))) & 1L), l_3391)) || p_19), 0UL)), (*l_3198))))), (*l_3198))), 1UL)))))
            { /* block id: 1556 */
                int32_t *l_3394 = &l_3353;
                for (g_436 = (-20); (g_436 <= 26); ++g_436)
                { /* block id: 1559 */
                    return g_2431;
                }
                l_3395[2]--;
                (**g_2461) = (*g_234);
            }
            else
            { /* block id: 1564 */
                int32_t l_3412 = (-1L);
                int32_t l_3422 = 0xA35F6D91L;
                int32_t l_3423 = 0L;
                int32_t l_3424[4][2];
                uint32_t l_3451 = 0xD792FF6EL;
                union U0 ****l_3459 = &g_1484;
                union U0 *****l_3458 = &l_3459;
                int32_t ***l_3534[4] = {&g_1157[0],&g_1157[0],&g_1157[0],&g_1157[0]};
                int32_t ****l_3533 = &l_3534[2];
                uint32_t l_3583 = 4294967294UL;
                const int8_t *l_3585[2];
                uint8_t l_3591 = 5UL;
                int16_t l_3613 = 0x4ACBL;
                int i, j;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_3424[i][j] = 0xBE14FC53L;
                }
                for (i = 0; i < 2; i++)
                    l_3585[i] = &l_3197[1][7][1];
lbl_3502:
                (*g_143) = p_17;
                for (g_2431 = 0; (g_2431 <= 5); g_2431 += 1)
                { /* block id: 1568 */
                    uint16_t *l_3402 = &g_3390;
                    int32_t l_3415 = 0xF4745D2AL;
                    int32_t l_3426 = 0xBC5442ECL;
                    int32_t l_3427 = (-7L);
                    int32_t l_3428 = 1L;
                    uint8_t l_3429[4][8] = {{0x7AL,0x7AL,255UL,0x7AL,0x7AL,255UL,0x7AL,0x7AL},{247UL,0x7AL,247UL,247UL,0x7AL,247UL,247UL,0x7AL},{0x7AL,247UL,247UL,0x7AL,247UL,247UL,247UL,255UL},{247UL,247UL,0x7AL,247UL,247UL,0x7AL,247UL,247UL}};
                    uint64_t ** const *l_3450 = &g_248;
                    uint64_t ** const **l_3449 = &l_3450;
                    uint64_t ** const ***l_3448[2];
                    int i, j;
                    for (i = 0; i < 2; i++)
                        l_3448[i] = &l_3449;
                    if (((*l_3198) = ((*l_3198) , (safe_mod_func_int8_t_s_s((((p_19 < (safe_div_func_uint16_t_u_u(((*l_3402)--), (((g_436 == (~p_19)) & ((safe_mul_func_int16_t_s_s(l_3357, l_3387)) <= 0xCCF306AA64757807LL)) || (((*g_1878) = ((safe_mul_func_int8_t_s_s(((((l_3412 > (((l_3337[1][8] = (safe_div_func_int32_t_s_s(l_3412, 1UL))) || p_18) || l_3412)) == l_3387) , 1UL) || 255UL), 250UL)) != l_3415)) && p_18))))) && 0xBA07L) != p_18), (****g_2007))))))
                    { /* block id: 1573 */
                        int32_t *l_3416 = &g_197[0];
                        int32_t *l_3417 = &g_3388;
                        int32_t *l_3418 = &g_197[3];
                        int32_t *l_3419[1][9] = {{(void*)0,&l_3258,(void*)0,(void*)0,&l_3258,(void*)0,(void*)0,&l_3258,(void*)0}};
                        uint8_t *****l_3439 = &l_3438;
                        int i, j;
                        l_3429[0][1]++;
                        l_3424[1][1] = (safe_mod_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(((safe_rshift_func_uint32_t_u_s(((void*)0 == (*l_3272)), (((*l_3389) = l_3420[1][6]) == ((p_18 , ((*l_3439) = l_3438)) == (void*)0)))) != (safe_rshift_func_uint16_t_u_s((safe_mul_func_uint32_t_u_u(((safe_add_func_int64_t_s_s(((((((*l_3416) &= 0L) > 7L) > (safe_lshift_func_uint16_t_u_u((((((void*)0 != l_3448[1]) || p_17) , 0UL) > l_3451), 13))) , &g_2460) == l_3452), (**g_2578))) || p_18), p_19)), 12))), 1)), 4L));
                        return g_1300;
                    }
                    else
                    { /* block id: 1580 */
                        int32_t **l_3460 = &g_1158[4][0];
                        int32_t **l_3461 = &g_1158[4][0];
                        int32_t **l_3462 = (void*)0;
                        int32_t *l_3463[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_3463[i] = &g_3388;
                        if (l_3387)
                            goto lbl_3453;
                        (*g_143) = (((g_82[1][4][6] || ((l_3457 = l_3454) == l_3458)) || ((l_3463[0] = &l_3257) == &l_3337[4][5])) , p_18);
                    }
                    for (g_2032 = 0; (g_2032 <= 5); g_2032 += 1)
                    { /* block id: 1588 */
                        l_3464[4][1][2] = (void*)0;
                    }
                }
                for (g_1808 = 22; (g_1808 < (-6)); --g_1808)
                { /* block id: 1594 */
                    int32_t *l_3472 = &l_3265;
                    int64_t **l_3483 = &g_2579;
                    int32_t l_3484[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_3484[i] = 0x368CF978L;
                    if (((!(safe_rshift_func_int32_t_s_s(((((safe_lshift_func_int64_t_s_s((1UL ^ ((((((*l_3334) = l_3472) == &l_3412) < ((safe_rshift_func_uint8_t_u_s((--(**g_2009)), (*g_1878))) != (p_17 , (-1L)))) , (((*l_3458) == (*l_3458)) , (***g_2081))) != l_3477[5][2][2])), 11)) , (*g_1878)) == p_17) | p_18), (*l_3198)))) , (*l_3198)))
                    { /* block id: 1597 */
                        int32_t **l_3478[10] = {&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2],&l_3464[4][1][2]};
                        int64_t **l_3479 = &g_2579;
                        int64_t ***l_3480 = &l_3479;
                        int64_t ***l_3482[5][9][1] = {{{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578}},{{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481}},{{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578}},{{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481}},{{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578},{&l_3481},{&g_2578}}};
                        int i, j, k;
                        (*g_631) = &l_3423;
                        if (l_3412)
                            goto lbl_3453;
                        l_3485[4] = (l_3484[2] = (((*l_3480) = l_3479) == (l_3483 = (l_3481 = l_3481))));
                    }
                    else
                    { /* block id: 1605 */
                        int32_t **l_3486 = &l_3464[2][0][4];
                        int32_t l_3487[7];
                        int32_t l_3488 = 0x371CB285L;
                        int32_t l_3490 = (-10L);
                        int32_t l_3491 = 0x8BEA7FBEL;
                        int32_t l_3492 = 7L;
                        int32_t l_3493 = 0x3F60EB45L;
                        int32_t l_3494 = (-7L);
                        int32_t l_3495 = 0xB20B8F48L;
                        int32_t l_3496 = 0x9929254AL;
                        int32_t l_3497[7][7][5] = {{{0L,0x32641115L,0L,0xF1917491L,(-5L)},{0x6CAF6EC8L,0x0515ACC0L,2L,1L,1L},{9L,(-7L),0x5D2C5C2FL,0L,0x6F64A3D1L},{(-1L),0xCD64DEF4L,0xBDB03E88L,0x9786FDBCL,(-1L)},{0xB9E27211L,0xF1917491L,0x7E2CCE2DL,0xEAD1F438L,(-1L)},{(-6L),1L,0x9786FDBCL,2L,2L},{2L,0x7363730CL,2L,9L,1L}},{{0x54717020L,1L,3L,(-2L),0xBDB03E88L},{0x5D2C5C2FL,0x362D931BL,(-1L),0x1AB3A555L,0x762E1402L},{0x70834FDDL,0xD3FEF650L,3L,0xBDB03E88L,(-1L)},{0L,1L,2L,0xAD74C9DDL,1L},{1L,0xCE7A2558L,0x9786FDBCL,7L,0x70834FDDL},{(-7L),0x762E1402L,0x7E2CCE2DL,0x61A38855L,(-9L)},{0L,0L,0xBDB03E88L,(-2L),1L}},{{(-10L),(-9L),0x5D2C5C2FL,8L,0xF1917491L},{0x7E58F8AEL,0x54717020L,2L,0x54717020L,0x7E58F8AEL},{0x6F64A3D1L,0xA04455CDL,0L,3L,0x13A70667L},{0xAAD558ECL,2L,0x0515ACC0L,(-7L),0x54717020L},{0x7363730CL,0L,0x762E1402L,0xA04455CDL,0x13A70667L},{0x502552A5L,(-7L),(-1L),0x70834FDDL,0x7E58F8AEL},{0x13A70667L,(-6L),0L,0x2F3A6F4EL,0xF1917491L}},{{0L,1L,0xCD64DEF4L,(-6L),1L},{0x3F500D3DL,0L,9L,0x6F64A3D1L,(-9L)},{0xB81B355FL,1L,0x9786FDBCL,3L,(-1L)},{0x649B0C1CL,(-9L),0x32641115L,1L,0x32641115L},{0L,0L,0x502552A5L,0x775A0B62L,0x70834FDDL},{0xE6C59134L,0x5D2C5C2FL,0x3F500D3DL,(-5L),3L},{0x6CAF6EC8L,1L,1L,(-1L),0xAAD558ECL}},{{0x7E2CCE2DL,0x5D2C5C2FL,0xA04455CDL,0x431DF0B3L,(-6L)},{0xCD64DEF4L,0L,0xCE7A2558L,2L,0x39287A07L},{0x71D1DF5CL,(-9L),0x1AB3A555L,0x6F64A3D1L,0xAD74C9DDL},{0xD3FEF650L,1L,0L,3L,0L},{0L,0x61A38855L,0xAE2A0BCCL,0x5D2C5C2FL,0xF1917491L},{2L,0L,(-7L),0xE190B5F0L,0xF403F3F7L},{0L,0x431DF0B3L,0x431DF0B3L,0L,0xE6C59134L}},{{3L,1L,(-2L),0xA25F1355L,(-7L)},{0xB9E27211L,0x2F3A6F4EL,2L,0x13A70667L,1L},{0x70834FDDL,0x39287A07L,0xB81B355FL,0xA25F1355L,7L},{0xEAD1F438L,8L,(-5L),0L,0x6F64A3D1L},{0x7E58F8AEL,(-6L),1L,0xE190B5F0L,1L},{(-1L),0x7E2CCE2DL,0x6F64A3D1L,0x5D2C5C2FL,0L},{0L,(-2L),(-1L),3L,(-1L)}},{{0x431DF0B3L,3L,(-1L),0x6F64A3D1L,(-1L)},{1L,0x9786FDBCL,2L,2L,0x9786FDBCL},{3L,0x71D1DF5CL,1L,0x431DF0B3L,8L},{2L,1L,0xBDB03E88L,(-1L),0x7E58F8AEL},{1L,0x13A70667L,0x762E1402L,(-5L),0x1AB3A555L},{2L,0xF403F3F7L,(-1L),0x775A0B62L,3L},{3L,0x762E1402L,1L,1L,(-3L)}}};
                        int i, j, k;
                        for (i = 0; i < 7; i++)
                            l_3487[i] = 0x3C22FD5BL;
                        (*l_3486) = &l_3423;
                        l_3498[0]--;
                        (*l_3486) = &l_3354[0][0][2];
                    }
                    (*g_1844) = l_3501[0];
                    if (l_3328)
                        goto lbl_3502;
                }
                if ((safe_sub_func_uint32_t_u_u(((*l_3389) = (((safe_mod_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s(p_18, (**g_1015))), ((4294967286UL | ((((****g_2082) > 0L) , (safe_lshift_func_int32_t_s_s((((((**l_3481) = ((safe_mul_func_uint16_t_u_u((safe_mul_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((safe_add_func_uint32_t_u_u(p_19, ((l_3422 , l_3521) != l_3521))), 0x0A33EA2C75D72016LL)), p_17)), l_3451)) ^ p_17)) | p_19) < 0x1448L) , p_18), 13))) >= 0x5AL)) && 255UL))), p_19)) < l_3422) , 0xFD62C46BL)), l_3522)))
                { /* block id: 1615 */
                    uint64_t l_3529 = 0x143801EDCA3B25ADLL;
                    union U0 l_3540 = {5L};
                    int32_t ****l_3541[5][10] = {{&l_3534[2],&l_3534[2],&l_3534[0],&l_3534[2],&l_3534[2],&l_3534[2],&l_3534[0],&l_3534[2],&l_3534[2],&l_3534[2]},{&l_3534[1],&l_3534[0],&l_3534[2],&l_3534[2],&l_3534[2],&l_3534[2],&l_3534[0],&l_3534[1],&l_3534[2],&l_3534[1]},{&l_3534[2],&l_3534[0],&l_3534[2],&l_3534[2],&l_3534[2],&l_3534[0],&l_3534[2],&l_3534[2],&l_3534[2],&l_3534[2]},{&l_3534[2],&l_3534[1],&l_3534[2],&l_3534[2],&l_3534[1],&l_3534[2],&l_3534[0],&l_3534[1],&l_3534[0],&l_3534[2]},{&l_3534[0],&l_3534[1],&l_3534[2],&l_3534[1],&l_3534[0],&l_3534[2],&l_3534[2],&l_3534[2],&l_3534[2],&l_3534[0]}};
                    uint16_t *l_3542 = &l_3395[5];
                    int i, j;
                    for (l_3328 = 0; (l_3328 <= 0); l_3328 += 1)
                    { /* block id: 1618 */
                        l_3420[0][6] &= (safe_lshift_func_int8_t_s_u((*l_3198), 3));
                    }
                    l_3353 ^= (p_19 , (safe_mul_func_int16_t_s_s((safe_sub_func_int16_t_s_s((*g_513), 0UL)), ((*l_3542) = (l_3529 != (p_17 != (!((***g_2008) < ((l_3257 &= (safe_lshift_func_uint64_t_u_u((l_3533 != (((**g_2578) &= (safe_lshift_func_uint8_t_u_s((!(*l_3198)), 4))) , (((safe_sub_func_int32_t_s_s((l_3540 , 0x0B695300L), 0x27E65E3AL)) < p_17) , l_3541[2][4]))), 0))) , 0x37L)))))))));
                    for (l_3258 = 0; (l_3258 <= 21); l_3258 = safe_add_func_int16_t_s_s(l_3258, 1))
                    { /* block id: 1627 */
                        (*l_3198) |= p_17;
                        (*l_3198) |= p_18;
                        if (l_3545)
                            break;
                        l_3546 = &l_3336[5];
                    }
                }
                else
                { /* block id: 1633 */
                    int32_t l_3581 = 0xC86D3DD2L;
                    int32_t l_3586 = 0x4B515739L;
                    int32_t l_3587 = 1L;
                    int32_t l_3590 = 4L;
                    int32_t l_3616 = (-1L);
                    int32_t l_3617[7] = {7L,7L,7L,7L,7L,7L,7L};
                    int i;
                    for (g_267 = (-1); (g_267 != 19); g_267 = safe_add_func_uint64_t_u_u(g_267, 5))
                    { /* block id: 1636 */
                        uint16_t l_3555 = 65535UL;
                        int32_t l_3578 = 0L;
                        int32_t l_3584 = (-10L);
                        int32_t l_3588 = 0xBF33114FL;
                        int32_t l_3589 = 0xC20A03A2L;
                        l_3583 = (safe_add_func_int32_t_s_s((((***g_2008) = p_19) , (safe_div_func_uint32_t_u_u(((((**g_248) = ((safe_add_func_uint64_t_u_u(l_3555, (safe_unary_minus_func_int8_t_s((!((**g_2578) = (safe_lshift_func_uint8_t_u_u(((****g_2082) = ((safe_mul_func_int8_t_s_s(((l_3420[0][6] = (*l_3198)) , (safe_mod_func_uint32_t_u_u(((g_267 <= ((safe_add_func_int64_t_s_s((safe_rshift_func_uint64_t_u_s(p_18, 33)), (safe_mod_func_int64_t_s_s((((safe_mul_func_int64_t_s_s((safe_add_func_uint16_t_u_u(((((void*)0 != &l_3477[6][0][1]) , (l_3582 |= (safe_sub_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(l_3578, 14)), ((safe_mod_func_int32_t_s_s((4294967295UL > (*l_3198)), l_3581)) < (-10L)))))) <= p_18), p_19)), p_17)) < (**g_1015)) > (**g_248)), 0x3E3CB4B5420E9483LL)))) , (*g_424))) , p_18), (*l_3198)))), (**g_1015))) & p_17)), (**g_1015))))))))) >= l_3581)) <= p_17) && p_17), (*l_3198)))), l_3581));
                        (*l_3198) = (l_3584 = 0x18E0CF84L);
                        l_3586 = ((void*)0 == l_3585[1]);
                        l_3591--;
                    }
                    for (g_635 = 0; (g_635 <= 3); g_635 += 1)
                    { /* block id: 1651 */
                        union U0 **l_3598 = &l_3597;
                        uint64_t ****l_3606 = (void*)0;
                        uint64_t ***l_3608 = &l_3521;
                        uint64_t ****l_3607 = &l_3608;
                        uint8_t **** const *l_3609 = &l_3438;
                        int32_t l_3615[4];
                        uint16_t l_3618 = 65528UL;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_3615[i] = 0x82482FE6L;
                        l_3353 &= ((safe_unary_minus_func_uint8_t_u((((*g_101) != ((*l_3598) = l_3597)) < (safe_add_func_int16_t_s_s(0x96A6L, (((*l_3198) = (safe_sub_func_uint8_t_u_u((((((+(safe_mul_func_uint32_t_u_u(p_19, 6L))) && ((((*l_3607) = &l_3521) != &g_1095[0][2]) , (((l_3610 = l_3609) != (void*)0) , p_17))) , p_17) , &g_3356) == (void*)0), 0UL))) && l_3613)))))) > 0L);
                        l_3618++;
                        (*l_3198) = (safe_mod_func_uint64_t_u_u(((((((((safe_sub_func_uint16_t_u_u(0x00B6L, ((safe_sub_func_int8_t_s_s(p_18, (safe_lshift_func_uint32_t_u_s(4UL, p_19)))) >= (l_3590 , p_19)))) ^ (***g_2008)) || ((safe_add_func_uint64_t_u_u(l_3618, p_18)) & p_19)) | p_18) >= (*l_3198)) & (*g_513)) > (*g_513)) , l_3590), p_17));
                    }
                    l_3617[2] = (+((void*)0 != (**g_2461)));
                }
            }
            if ((*l_3198))
            { /* block id: 1663 */
                const int32_t l_3647 = 0x880F0DAEL;
                int32_t *** const * const l_3668 = &l_3336[4];
                if ((((((l_3634[2] == (*l_3546)) <= (((safe_mul_func_uint16_t_u_u(((((safe_mod_func_int32_t_s_s((*l_3198), ((safe_lshift_func_int16_t_s_s(((safe_mod_func_int64_t_s_s((safe_div_func_uint16_t_u_u((l_3647 | ((void*)0 == l_3648)), p_19)), (safe_mod_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u(l_3647, p_18)) > 0xBF78L), (**g_2009))))) != p_18), 6)) , p_18))) ^ l_3647) <= 0x9AL) <= g_3653), (*l_3198))) <= g_1931) == p_19)) == p_17) >= p_17) >= g_1808))
                { /* block id: 1664 */
                    union U0 *l_3654[5][4] = {{&g_811,&g_811,&g_811,&g_28},{&g_28,&g_1353,&g_811,&g_1353},{&g_811,&g_28,&g_811,&g_811},{&g_1353,&g_28,&g_28,&g_1353},{&g_28,&g_1353,&g_811,&g_811}};
                    int i, j;
                    l_3655 = l_3654[0][0];
                }
                else
                { /* block id: 1666 */
                    uint32_t l_3656 = 0xC2BFF7FEL;
                    for (l_3387 = 0; (l_3387 <= 1); l_3387 += 1)
                    { /* block id: 1669 */
                        l_3656++;
                        return g_6;
                    }
                    if ((safe_lshift_func_uint64_t_u_u((safe_rshift_func_int16_t_s_u(((*l_3198) = ((safe_unary_minus_func_int32_t_s(l_3656)) == (p_18 == (~((*l_3198) ^ ((((p_19 < l_3667) || (((void*)0 == &l_3438) & g_186[0][8])) != ((*g_424) < g_2844)) ^ 0xFBL)))))), 10)), 5)))
                    { /* block id: 1674 */
                        return l_3647;
                    }
                    else
                    { /* block id: 1676 */
                        (*l_3198) |= (-1L);
                        return g_436;
                    }
                }
                (*l_3198) = (l_3668 == (l_3546 = (void*)0));
            }
            else
            { /* block id: 1683 */
                uint16_t l_3687 = 65528UL;
                int16_t l_3688 = 0xA015L;
                int32_t l_3689 = 0xFE4C6B52L;
                const int32_t **l_3699 = &g_632;
                const int32_t ***l_3698[9] = {&l_3699,&l_3699,&l_3699,&l_3699,&l_3699,&l_3699,&l_3699,&l_3699,&l_3699};
                uint64_t *****l_3702 = (void*)0;
                int32_t l_3703[6][2][10] = {{{0x9C7965EDL,0x72142F96L,0L,1L,2L,0x970358EDL,0x0146C700L,1L,(-2L),(-2L)},{1L,1L,0x9C7965EDL,1L,1L,0x9C7965EDL,1L,1L,0xA0BB9FEAL,0xACB23B6BL}},{{0xACB23B6BL,0x970358EDL,(-3L),0x9C7965EDL,1L,1L,0L,0xC74769F1L,0L,1L},{0x9D6120DAL,1L,(-3L),1L,0x72142F96L,0xC74769F1L,0x72142F96L,1L,(-3L),1L}},{{(-5L),(-2L),0x9C7965EDL,0xACB23B6BL,0x444CA9D7L,1L,0x970358EDL,1L,0L,0x9D6120DAL},{(-3L),0x0146C700L,0L,0x9D6120DAL,0x036AA54BL,1L,(-5L),(-5L),1L,0x036AA54BL}},{{(-5L),2L,2L,(-5L),0x9C7965EDL,0xC74769F1L,0L,0L,0L,1L},{0x9D6120DAL,0L,0x0146C700L,(-3L),0xC74769F1L,1L,2L,0L,0L,0L}},{{0xACB23B6BL,0x9C7965EDL,(-2L),(-5L),(-2L),0x9C7965EDL,0xACB23B6BL,0x444CA9D7L,1L,0x970358EDL},{1L,(-3L),1L,0x9D6120DAL,(-5L),0x970358EDL,0L,0xA0BB9FEAL,0L,0x444CA9D7L}},{{0x9C7965EDL,(-3L),0x970358EDL,0xACB23B6BL,0x0146C700L,0x0146C700L,0xACB23B6BL,0x970358EDL,(-3L),0x9C7965EDL},{1L,0x9C7965EDL,1L,1L,0xA0BB9FEAL,0xACB23B6BL,2L,0x9D6120DAL,0L,(-5L)}}};
                union U0 l_3729 = {0x9CA3F2B1921B8CC8LL};
                int64_t l_3799 = 0xF1E205B649D1AE6CLL;
                int i, j, k;
                if ((safe_add_func_uint32_t_u_u(((safe_rshift_func_int16_t_s_u(0x72C6L, (safe_lshift_func_uint32_t_u_s((((*l_3198) || ((p_18 , (safe_mod_func_int16_t_s_s((safe_lshift_func_int32_t_s_u((safe_mod_func_int32_t_s_s(((safe_mul_func_int64_t_s_s(((l_3683[2][1][0] == (void*)0) <= ((**g_2009) <= (l_3689 = ((safe_rshift_func_uint32_t_u_u(((((*l_3198) = p_19) ^ l_3687) | (*g_1878)), l_3688)) , 0UL)))), l_3688)) <= p_17), 0xB611FCEAL)), 14)), 0xF9F9L))) & p_19)) != l_3688), p_17)))) | p_17), p_19)))
                { /* block id: 1686 */
                    int64_t l_3690 = 2L;
                    int32_t l_3705 = 8L;
                    int32_t l_3706 = (-1L);
                    if (l_3690)
                    { /* block id: 1687 */
                        int32_t l_3707[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
                        int i;
                        l_3703[4][1][8] = ((safe_lshift_func_int8_t_s_u(((safe_rshift_func_int64_t_s_u((l_3695 != ((safe_add_func_uint32_t_u_u((*l_3198), (l_3689 = (l_3690 || p_18)))) , l_3698[2])), 52)) && ((*g_1878) |= ((safe_sub_func_uint32_t_u_u(p_18, (((((((void*)0 == l_3702) > l_3420[1][6]) , &g_1879[2][4][0]) != (void*)0) == p_19) && 1L))) <= l_3690))), (**g_1015))) >= (*g_424));
                        g_3708[2][8][0]--;
                    }
                    else
                    { /* block id: 1692 */
                        uint32_t l_3712[7][8] = {{0x8CEE5110L,0x0200824FL,0UL,0x8940C988L,0UL,7UL,0UL,8UL},{0x1077DE22L,0x0200824FL,0xA531D48BL,0UL,0xA531D48BL,0x0200824FL,0x1077DE22L,0UL},{8UL,0xA74F33BCL,0UL,0x0200824FL,18446744073709551615UL,0x3C818BB0L,1UL,1UL},{1UL,8UL,0UL,0UL,18446744073709551615UL,18446744073709551615UL,0UL,0UL},{8UL,8UL,7UL,1UL,0x8CEE5110L,8UL,0UL,0x1077DE22L},{8UL,1UL,0x3C818BB0L,0x8CEE5110L,0UL,0x1077DE22L,8UL,0x1077DE22L},{1UL,0xA74F33BCL,7UL,0xA74F33BCL,1UL,0UL,0UL,0UL}};
                        int i, j;
                        (*l_3198) |= ((l_3711 = (void*)0) != &g_513);
                        l_3689 = (l_3420[0][6] ^= l_3712[1][2]);
                    }
                    for (g_65 = 0; (g_65 > (-2)); g_65 = safe_sub_func_int8_t_s_s(g_65, 1))
                    { /* block id: 1700 */
                        uint16_t *l_3725 = &g_2844;
                        int32_t l_3730 = 0x57110039L;
                        int32_t l_3733 = 0xA9223A80L;
                        uint16_t *l_3734 = &g_600;
                        int32_t l_3735[7][1];
                        int i, j;
                        for (i = 0; i < 7; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_3735[i][j] = 0x7444C093L;
                        }
                        if (g_3275)
                            goto lbl_3453;
                        l_3735[1][0] &= ((((safe_add_func_uint32_t_u_u(p_19, ((safe_div_func_int16_t_s_s((safe_div_func_int8_t_s_s((((**g_2578) |= ((safe_lshift_func_uint16_t_u_u(g_1097, 1)) , p_19)) != (((--(*g_2010)) || ((((*l_3725) |= p_18) < ((*l_3734) = (p_17 | (+(((safe_lshift_func_uint64_t_u_u((((l_3703[0][1][0] = (l_3729 , (l_3730 = (-6L)))) & p_19) && ((((safe_lshift_func_int8_t_s_s(0x12L, (*g_1878))) & p_17) , 0x03CE246D053AB736LL) ^ p_19)), l_3733)) && p_19) != (*g_513)))))) < 0x1784284DAE1CF3A4LL)) , (*l_3198))), (-1L))), 9UL)) , 0x636DAA05L))) | 0x8B247179L) & p_17) < p_17);
                        l_3737 = l_3736;
                        if (p_18)
                            continue;
                    }
                }
                else
                { /* block id: 1712 */
                    int32_t l_3740 = 6L;
                    int32_t l_3741 = 0x47D33607L;
                    const uint64_t *l_3749 = &g_3275;
                    const uint64_t **l_3748 = &l_3749;
                    const uint64_t ***l_3747 = &l_3748;
                    const uint64_t ****l_3746[8][4][6] = {{{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747}},{{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747}},{{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{(void*)0,&l_3747,(void*)0,&l_3747,&l_3747,&l_3747},{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747}},{{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747}},{{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747}},{{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{(void*)0,&l_3747,(void*)0,&l_3747,&l_3747,&l_3747},{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747}},{{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{&l_3747,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747}},{{(void*)0,&l_3747,(void*)0,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,(void*)0,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747},{(void*)0,&l_3747,&l_3747,&l_3747,&l_3747,&l_3747}}};
                    const uint64_t *****l_3745[3];
                    int32_t l_3797[4][8] = {{6L,0x12A2F8F7L,0xD73498E1L,0xC920DAA4L,0xC920DAA4L,0xD73498E1L,0x12A2F8F7L,6L},{0x12A2F8F7L,0x9593563DL,6L,(-1L),6L,0x9593563DL,0x12A2F8F7L,0x12A2F8F7L},{0x9593563DL,(-1L),0xD73498E1L,0xD73498E1L,(-1L),0x9593563DL,0xC920DAA4L,0x9593563DL},{(-1L),0x9593563DL,0xC920DAA4L,0x9593563DL,(-1L),0xD73498E1L,0xD73498E1L,(-1L)}};
                    union U0 *l_3842 = &l_3729;
                    int64_t l_3873 = 7L;
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_3745[i] = &l_3746[1][0][0];
                    l_3741 = ((((*l_3389) ^= (p_18 == (g_522[2] >= (safe_rshift_func_uint8_t_u_s((*g_2010), 6))))) | l_3740) && p_18);
                    l_3354[0][4][5] = ((*l_3198) = 0x4FD55ADEL);
                    if (l_3741)
                    { /* block id: 1717 */
                        (**g_2461) = ((l_3742 != l_3745[1]) , (**g_233));
                        (*g_143) |= ((((safe_div_func_uint32_t_u_u((g_3388 || ((safe_lshift_func_int8_t_s_s(p_19, 0)) , (l_3754 == l_3501[0]))), (safe_lshift_func_int32_t_s_s((p_19 == (~(~(safe_add_func_uint8_t_u_u((p_17 | (p_17 & l_3740)), (-7L)))))), p_18)))) , l_3741) < (*g_513)) < p_19);
                    }
                    else
                    { /* block id: 1720 */
                        int64_t l_3778 = 1L;
                        int32_t *****l_3790 = &g_3788[1];
                        int32_t *****l_3791 = (void*)0;
                        int8_t *l_3793[10] = {&l_3197[3][5][0],&l_3197[3][5][0],&g_202,&l_3197[3][5][0],&l_3197[3][5][0],&g_202,&l_3197[3][5][0],&l_3197[3][5][0],&g_202,&l_3197[3][5][0]};
                        uint16_t *l_3794[8] = {&l_3395[4],(void*)0,&l_3395[4],(void*)0,&l_3395[4],(void*)0,&l_3395[4],(void*)0};
                        int32_t l_3795 = (-5L);
                        int32_t l_3798[4][3][3] = {{{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L}},{{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L}},{{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L}},{{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L},{0x6AC45349L,0x6AC45349L,0xA634ABC0L}}};
                        union U0 l_3823 = {-1L};
                        uint32_t ****l_3839 = &g_3836[3];
                        int i, j, k;
                        l_3741 = (safe_mod_func_int16_t_s_s((~(p_17 && (*g_424))), ((*g_513) = (+(*****g_2081)))));
                        l_3703[4][1][8] = ((safe_add_func_uint64_t_u_u(((+(safe_add_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u((safe_div_func_int32_t_s_s(l_3741, p_18)), 4)), (l_3795 = (((safe_lshift_func_uint8_t_u_s((((((safe_sub_func_int64_t_s_s(l_3778, ((safe_div_func_uint64_t_u_u(((void*)0 == &g_1117), ((**l_3521) = (*l_3198)))) != (p_19 = ((*g_1878) = ((safe_mul_func_uint8_t_u_u(((!((g_267 = (*l_3198)) == (safe_rshift_func_uint16_t_u_s((((safe_lshift_func_uint16_t_u_s((((*l_3790) = g_3788[1]) != (l_3546 = (g_3792[3] = (p_19 , &g_3789)))), 5)) < g_197[2]) == g_3708[7][6][0]), (*g_424))))) == p_19), 0x8FL)) == 0x7DL)))))) ^ 0xF4B5L) , l_3778) || l_3740) , (*l_3198)), 2)) & g_3356) | p_18))))) && l_3796[4]), l_3740)) && 0xD7L);
                        l_3801--;
                        l_3703[3][1][1] = (((+(((safe_mod_func_uint32_t_u_u(((safe_div_func_int16_t_s_s(((safe_rshift_func_uint32_t_u_s((((safe_add_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u(0xDF93L, (g_103.f0 | (safe_rshift_func_int16_t_s_s(1L, (safe_lshift_func_uint32_t_u_u(0xC0474BA6L, (safe_lshift_func_uint16_t_u_s((l_3823 , ((safe_add_func_uint64_t_u_u((((**g_2578) ^= ((((((safe_sub_func_uint8_t_u_u(((****g_2082) = 0x56L), (((3L ^ (safe_add_func_int32_t_s_s((safe_lshift_func_uint32_t_u_u((safe_add_func_uint8_t_u_u((*l_3198), ((safe_lshift_func_int64_t_s_s((((*l_3839) = g_3836[3]) == l_3840), 57)) || l_3797[0][4]))), p_19)), 0UL))) < 0x69B0L) && (-10L)))) , 0UL) ^ 0xFAL) , l_3823.f0) >= l_3798[1][1][0]) < p_18)) ^ 0xA3B803D7805F6CC4LL), 0x5482A9D047CB88E3LL)) , 0xBF1DL)), 5))))))))), p_19)) != p_19) > (*g_513)), 25)) , (*g_513)), p_19)) , p_17), p_19)) != (*g_424)) > 255UL)) , l_3740) || 0UL);
                    }
                    if (((l_3841 > (l_3842 != ((*l_3198) , l_3842))) && (safe_rshift_func_uint64_t_u_s((+(p_19 > ((*l_3198) ^ (~((****g_2082) ^= (+((((**g_248) && (safe_div_func_int8_t_s_s(p_19, ((safe_div_func_uint64_t_u_u(p_19, (*g_1096))) | l_3852)))) , 4L) | p_19))))))), 52))))
                    { /* block id: 1739 */
                        return p_18;
                    }
                    else
                    { /* block id: 1741 */
                        int32_t *l_3853 = &l_3689;
                        int32_t l_3870 = 0x8D370F2EL;
                        int32_t l_3871 = 0xC6CECFFAL;
                        int32_t l_3872[7] = {1L,1L,0x7D44206EL,1L,1L,0x7D44206EL,1L};
                        int i;
                        (**l_3695) = l_3853;
                        (*g_143) = (p_17 >= ((safe_unary_minus_func_uint64_t_u((*l_3853))) & (safe_add_func_uint8_t_u_u(p_18, ((((*l_3853) != (safe_sub_func_int16_t_s_s(l_3859[3][3][0], (safe_mul_func_int64_t_s_s(((safe_mul_func_int16_t_s_s((*g_513), (((*l_3853) && 0xA5E7F298L) == (safe_sub_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s(p_17, 1L)) <= (*g_513)), (*g_424)))))) , p_17), (-1L)))))) >= 0x3DBDL) ^ 252UL)))));
                        g_3868 = (*l_3742);
                        --l_3874;
                    }
                }
            }
        }
        --l_3877;
        (*l_3198) = (-1L);
        for (g_2202 = 0; (g_2202 <= 17); ++g_2202)
        { /* block id: 1754 */
            uint32_t l_3916 = 6UL;
            uint64_t l_3921 = 0x5625DEF34BD86D29LL;
            int8_t l_3924 = 0x21L;
            if (l_3874)
                goto lbl_3453;
            for (l_3852 = 3; (l_3852 == 20); l_3852++)
            { /* block id: 1758 */
                union U0 * const **l_3912[3];
                int32_t l_3917 = 0x4D69CBB1L;
                uint8_t l_3920 = 0UL;
                int i;
                for (i = 0; i < 3; i++)
                    l_3912[i] = &g_194;
                for (l_3258 = 0; (l_3258 <= (-6)); l_3258 = safe_sub_func_uint8_t_u_u(l_3258, 1))
                { /* block id: 1761 */
                    int32_t l_3887 = (-1L);
                    const uint16_t l_3919 = 0x9417L;
                    for (g_2949 = 0; (g_2949 <= 2); g_2949 += 1)
                    { /* block id: 1764 */
                        const union U0 l_3886 = {0xECC8F35D8D75DD93LL};
                        uint16_t *l_3892 = &l_3874;
                        int8_t *l_3913[4][6] = {{&g_3356,&l_3522,&g_3356,&g_3356,(void*)0,(void*)0},{&g_202,&l_3522,&l_3522,&g_202,(void*)0,&g_3356},{&g_635,&l_3522,(void*)0,&g_635,(void*)0,&l_3522},{&g_3356,&l_3522,&g_3356,&g_3356,(void*)0,(void*)0}};
                        int i, j;
                        (*l_3198) = (((l_3886 , ((void*)0 == &l_3648)) ^ (l_3887 | l_3887)) != p_19);
                        (***g_2460) = (**g_2461);
                        l_3924 ^= (((safe_mul_func_int16_t_s_s((-8L), ((*l_3892) = (safe_mod_func_int32_t_s_s((-1L), 0x79C928DCL))))) | ((**l_3481) ^= (safe_rshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u((safe_sub_func_int64_t_s_s((safe_sub_func_uint32_t_u_u((safe_div_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(1L, ((*g_1878) = p_17))), (safe_div_func_int32_t_s_s((p_18 , (safe_sub_func_uint32_t_u_u((l_3921 = (((**g_248) = ((!(l_3918 = ((((safe_add_func_int8_t_s_s((p_19 = (l_3912[0] == (void*)0)), ((!(((((((!((*l_3198) || 0L)) | l_3916) , l_3887) && p_17) <= p_17) , l_3887) || p_18)) , l_3917))) > (*l_3198)) > l_3886.f0) != l_3916))) > l_3919)) ^ l_3920)), l_3922))), p_18)))), l_3923[3])), p_17)), p_18)), p_17)))) && p_18);
                        if (p_18)
                            break;
                    }
                    for (g_179 = 18; (g_179 != 10); --g_179)
                    { /* block id: 1779 */
                        union U0 **l_3928 = (void*)0;
                        union U0 **l_3929 = &l_3655;
                        (*l_3929) = (*g_194);
                        if (l_3917)
                            break;
                        return g_2638;
                    }
                    l_3917 |= ((*l_3198) |= p_18);
                }
            }
        }
    }
    return p_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_1878 g_1879 g_2329 g_2345 g_248 g_249 g_2081 g_2082 g_2008 g_2009 g_2010 g_506 g_2368 g_635 g_513 g_82 g_122 g_2431 g_2007 g_2460 g_197 g_65 g_2492 g_2495 g_194 g_195 g_2499 g_202 g_1931 g_267 g_521 g_522 g_631 g_2576 g_2578 g_2579 g_201 g_585 g_1015 g_1016 g_1017 g_2462 g_235 g_2638 g_91 g_424 g_425 g_268 g_2202 g_2715 g_6 g_119 g_2740 g_1096 g_1097 g_436 g_2844 g_887 g_811.f0 g_2461 g_632 g_3031 g_143 g_218 g_3046 g_234 g_335 g_28.f0 g_2581 g_2577 g_213 g_179 g_2032
 * writes: g_28.f0 g_213 g_1808 g_1158 g_2345 g_82 g_218 g_1879 g_122 g_635 g_91 g_2431 g_267 g_197 g_1931 g_179 g_202 g_506 g_2541 g_632 g_2576 g_2581 g_201 g_235 g_2638 g_887 g_119 g_65 g_2010 g_2844 g_2032 g_2943 g_28 g_3059 g_3065
 */
static int8_t  func_22(uint32_t  p_23, int32_t  p_24, union U0  p_25, int16_t  p_26)
{ /* block id: 1083 */
    uint8_t **l_2290 = (void*)0;
    int32_t l_2292 = 0x769E88CDL;
    int32_t l_2322 = 1L;
    int32_t l_2325[7][2] = {{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)}};
    int32_t *l_2353 = &g_122;
    int16_t l_2405[6] = {0xF946L,0xF946L,0xF946L,0xF946L,0xF946L,0xF946L};
    int32_t *l_2497[5][5];
    int32_t **l_2496[9] = {&l_2497[1][0],&l_2497[1][0],&l_2497[1][0],&l_2497[1][0],&l_2497[1][0],&l_2497[1][0],&l_2497[1][0],&l_2497[1][0],&l_2497[1][0]};
    const int32_t **l_2549 = &g_632;
    const int32_t ***l_2548 = &l_2549;
    const int32_t **** const l_2547 = &l_2548;
    const int32_t **** const *l_2546 = &l_2547;
    uint8_t ** const **l_2552 = (void*)0;
    uint8_t ** const ***l_2551[2];
    uint64_t l_2568[2][9][8] = {{{0UL,0UL,18446744073709551614UL,0x08618C5F81281AE5LL,18446744073709551606UL,0x547AB530AFA6C8B9LL,0UL,0UL},{0UL,0x85437AD2F0A55C25LL,9UL,1UL,0UL,9UL,1UL,0UL},{0x85437AD2F0A55C25LL,0xD0E94F79DCE7A24ELL,0UL,0x08618C5F81281AE5LL,0UL,0xD0E94F79DCE7A24ELL,0x85437AD2F0A55C25LL,1UL},{1UL,9UL,0UL,1UL,9UL,0x85437AD2F0A55C25LL,0UL,1UL},{0xF9A2D5659A52E3E6LL,1UL,18446744073709551606UL,0x02BB3FFAD5A4714BLL,9UL,18446744073709551614UL,18446744073709551614UL,9UL},{1UL,0x547AB530AFA6C8B9LL,0x547AB530AFA6C8B9LL,1UL,0x2CC83618A206A817LL,0xF9A2D5659A52E3E6LL,6UL,0x02BB3FFAD5A4714BLL},{0xF1BCC05CCF2D5148LL,6UL,0x08618C5F81281AE5LL,1UL,0UL,0UL,1UL,0xF1BCC05CCF2D5148LL},{0x2CC83618A206A817LL,6UL,18446744073709551606UL,0xF9A2D5659A52E3E6LL,0xD0E94F79DCE7A24ELL,0xF9A2D5659A52E3E6LL,18446744073709551606UL,6UL},{6UL,0x547AB530AFA6C8B9LL,18446744073709551614UL,0UL,18446744073709551606UL,18446744073709551614UL,0xF1BCC05CCF2D5148LL,0x2CC83618A206A817LL}},{{0xF1BCC05CCF2D5148LL,1UL,18446744073709551606UL,9UL,6UL,0x85437AD2F0A55C25LL,0xF1BCC05CCF2D5148LL,0xF1BCC05CCF2D5148LL},{0x02BB3FFAD5A4714BLL,9UL,18446744073709551614UL,18446744073709551614UL,9UL,0x02BB3FFAD5A4714BLL,18446744073709551606UL,1UL},{9UL,0x02BB3FFAD5A4714BLL,18446744073709551606UL,1UL,0xF9A2D5659A52E3E6LL,18446744073709551614UL,1UL,0xF9A2D5659A52E3E6LL},{1UL,0xF1BCC05CCF2D5148LL,0x08618C5F81281AE5LL,1UL,6UL,3UL,6UL,1UL},{0x547AB530AFA6C8B9LL,6UL,0x547AB530AFA6C8B9LL,18446744073709551614UL,0UL,18446744073709551606UL,18446744073709551614UL,0xF1BCC05CCF2D5148LL},{6UL,0x2CC83618A206A817LL,18446744073709551606UL,9UL,0xFFCCEA60AA52B89BLL,0xF9A2D5659A52E3E6LL,0UL,0x2CC83618A206A817LL},{6UL,0xF1BCC05CCF2D5148LL,0UL,0UL,0UL,0UL,0xF1BCC05CCF2D5148LL,6UL},{0x547AB530AFA6C8B9LL,1UL,0x2CC83618A206A817LL,0xF9A2D5659A52E3E6LL,6UL,0x02BB3FFAD5A4714BLL,0x547AB530AFA6C8B9LL,0xF1BCC05CCF2D5148LL},{1UL,0xF9A2D5659A52E3E6LL,18446744073709551614UL,1UL,0xF9A2D5659A52E3E6LL,0x02BB3FFAD5A4714BLL,0UL,0x02BB3FFAD5A4714BLL}}};
    int64_t * const *l_2584[1];
    int64_t * const **l_2583 = &l_2584[0];
    int64_t * const ***l_2582[7];
    int32_t l_2590 = 0x70135B04L;
    uint64_t * const *l_2709 = &g_249[0];
    uint32_t *** const *l_2819 = &g_1929;
    int32_t l_2868 = 0x2C81842FL;
    uint64_t ** const **l_2877 = (void*)0;
    uint64_t ** const ***l_2876[1][1][5];
    union U0 **l_2879 = &g_218;
    int32_t l_2947 = (-10L);
    uint16_t l_3078[8] = {0xA58DL,0xA58DL,0UL,0xA58DL,0xA58DL,0UL,0xA58DL,0xA58DL};
    int32_t *l_3171 = &l_2325[6][0];
    int32_t *l_3172 = (void*)0;
    int32_t *l_3173 = &g_65;
    int32_t *l_3174 = &g_65;
    int32_t *l_3175 = &g_197[1];
    int32_t *l_3176 = &l_2292;
    int32_t *l_3177 = (void*)0;
    int32_t *l_3178 = &l_2868;
    int32_t *l_3179 = (void*)0;
    int32_t *l_3180 = &l_2292;
    int32_t *l_3181 = &l_2947;
    int32_t *l_3182 = (void*)0;
    int32_t *l_3183 = &l_2322;
    int32_t *l_3184 = &g_197[1];
    int32_t *l_3185 = &g_122;
    int32_t *l_3186 = &l_2947;
    int32_t *l_3187 = &l_2325[6][0];
    int32_t *l_3188 = &l_2292;
    int32_t *l_3189 = &l_2325[3][1];
    int32_t *l_3190 = &l_2292;
    int32_t *l_3191 = &g_122;
    int32_t *l_3192 = &g_197[0];
    int32_t *l_3193[10] = {&g_122,&g_197[3],&g_122,&g_197[3],&g_122,&g_197[3],&g_122,&g_197[3],&g_122,&g_197[3]};
    uint32_t l_3194 = 0x8DEFFDAAL;
    int i, j, k;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
            l_2497[i][j] = &g_1931;
    }
    for (i = 0; i < 2; i++)
        l_2551[i] = &l_2552;
    for (i = 0; i < 1; i++)
        l_2584[i] = &g_2579;
    for (i = 0; i < 7; i++)
        l_2582[i] = &l_2583;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 5; k++)
                l_2876[i][j][k] = &l_2877;
        }
    }
lbl_3170:
    if ((0x6298A20B4D66FC9ELL || (+(l_2290 == ((~l_2292) , (void*)0)))))
    { /* block id: 1084 */
        int64_t l_2301 = 0xA89BF9805026E73BLL;
        int32_t l_2320 = 0xF5978B88L;
        int32_t l_2342[10][9] = {{0x9B9F5A9AL,0x9B9F5A9AL,1L,0x9B9F5A9AL,0x9B9F5A9AL,1L,0x9B9F5A9AL,0x9B9F5A9AL,1L},{0xAF9760D5L,0xAF9760D5L,0xF3047BAFL,0xAF9760D5L,0xAF9760D5L,0xF3047BAFL,0xAF9760D5L,0xAF9760D5L,0xF3047BAFL},{0x9B9F5A9AL,0x9B9F5A9AL,1L,0x9B9F5A9AL,0x9B9F5A9AL,1L,0x9B9F5A9AL,0x9B9F5A9AL,1L},{0xAF9760D5L,0xAF9760D5L,0xF3047BAFL,0xAF9760D5L,0xAF9760D5L,0xF3047BAFL,0xAF9760D5L,0xAF9760D5L,0xF3047BAFL},{0x9B9F5A9AL,0x9B9F5A9AL,1L,0x9B9F5A9AL,0x9B9F5A9AL,1L,0x9B9F5A9AL,0x9B9F5A9AL,1L},{0xAF9760D5L,0xAF9760D5L,0xF3047BAFL,0xAF9760D5L,0xAF9760D5L,0xF3047BAFL,0xAF9760D5L,0xF0D90DC8L,0xAF9760D5L},{0x7F40A761L,0x7F40A761L,0x9B9F5A9AL,0x7F40A761L,0x7F40A761L,0x9B9F5A9AL,0x7F40A761L,0x7F40A761L,0x9B9F5A9AL},{0xF0D90DC8L,0xF0D90DC8L,0xAF9760D5L,0xF0D90DC8L,0xF0D90DC8L,0xAF9760D5L,0xF0D90DC8L,0xF0D90DC8L,0xAF9760D5L},{0x7F40A761L,0x7F40A761L,0x9B9F5A9AL,0x7F40A761L,0x7F40A761L,0x9B9F5A9AL,0x7F40A761L,0x7F40A761L,0x9B9F5A9AL},{0xF0D90DC8L,0xF0D90DC8L,0xAF9760D5L,0xF0D90DC8L,0xF0D90DC8L,0xAF9760D5L,0xF0D90DC8L,0xF0D90DC8L,0xAF9760D5L}};
        int8_t l_2344 = 0L;
        union U0 *l_2354 = &g_1353;
        uint64_t *****l_2369 = (void*)0;
        int32_t *l_2385 = &g_197[3];
        uint16_t l_2407 = 65535UL;
        uint32_t l_2436 = 1UL;
        uint32_t l_2445 = 4294967292UL;
        int32_t **l_2498 = &l_2497[1][0];
        uint16_t l_2507 = 65530UL;
        int i, j;
        for (g_28.f0 = 0; (g_28.f0 >= (-11)); g_28.f0 = safe_sub_func_uint64_t_u_u(g_28.f0, 8))
        { /* block id: 1087 */
            int16_t l_2306[4] = {0x7F2DL,0x7F2DL,0x7F2DL,0x7F2DL};
            int32_t l_2310 = (-7L);
            int32_t l_2315 = 7L;
            int32_t l_2316 = 0x075E3015L;
            int32_t l_2317 = 0xCBDB463CL;
            int32_t l_2321 = 0x24DD39D0L;
            int32_t l_2324[4][7] = {{0x22AE80F8L,0x22AE80F8L,6L,0xD3C73EBFL,6L,0x22AE80F8L,0x22AE80F8L},{0x22AE80F8L,6L,0xD3C73EBFL,6L,0x22AE80F8L,0x22AE80F8L,6L},{0x2ED0B757L,0x57C78B2DL,0x2ED0B757L,6L,6L,0x2ED0B757L,0x57C78B2DL},{6L,0x57C78B2DL,0xD3C73EBFL,0xD3C73EBFL,0x57C78B2DL,6L,0x57C78B2DL}};
            union U0 **l_2350 = &g_218;
            int32_t **l_2351 = (void*)0;
            int32_t **l_2352[4] = {&g_1158[3][2],&g_1158[3][2],&g_1158[3][2],&g_1158[3][2]};
            int i, j;
            for (g_213 = (-15); (g_213 <= 6); g_213 = safe_add_func_uint16_t_u_u(g_213, 1))
            { /* block id: 1090 */
                int16_t l_2304 = 0xBC4EL;
                int32_t l_2318 = 5L;
                int32_t l_2319[9][4] = {{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L},{(-6L),4L,(-6L),4L}};
                int8_t l_2323 = 0xE1L;
                int32_t *l_2330 = &l_2319[2][1];
                int32_t *l_2331 = (void*)0;
                int32_t *l_2332 = &l_2316;
                int32_t *l_2333 = &l_2318;
                int32_t *l_2334 = &l_2325[2][0];
                int32_t *l_2335 = &l_2317;
                int32_t *l_2336 = &l_2324[3][5];
                int32_t *l_2337 = &l_2315;
                int32_t *l_2338 = &l_2321;
                int32_t *l_2339 = &l_2324[3][5];
                int32_t *l_2340 = &l_2320;
                int32_t *l_2341[2][4][2] = {{{&l_2321,&l_2321},{&l_2319[8][0],&l_2321},{&l_2321,&l_2319[8][0]},{&l_2321,&l_2321}},{{&l_2319[8][0],&l_2321},{&l_2321,&l_2319[8][0]},{&l_2321,&l_2321},{&l_2319[8][0],&l_2321}}};
                int32_t l_2343 = 0x2F28BEF3L;
                int i, j, k;
                for (g_1808 = 0; (g_1808 > 3); ++g_1808)
                { /* block id: 1093 */
                    int32_t *l_2299 = (void*)0;
                    int32_t *l_2300 = &g_65;
                    int32_t l_2302 = 0xC1DF722EL;
                    int32_t *l_2303 = &g_122;
                    int32_t *l_2305 = (void*)0;
                    int32_t *l_2307 = &g_65;
                    int32_t *l_2308 = (void*)0;
                    int32_t *l_2309 = &g_197[3];
                    int32_t *l_2311 = (void*)0;
                    int32_t *l_2312 = &g_122;
                    int32_t *l_2313 = &g_65;
                    int32_t *l_2314[7][5] = {{&g_6,(void*)0,(void*)0,(void*)0,&g_6},{&l_2292,(void*)0,&g_197[0],&g_197[3],&g_197[0]},{&g_197[0],&g_197[0],(void*)0,&g_6,&g_6},{(void*)0,&l_2292,&l_2292,(void*)0,&g_197[0]},{(void*)0,&g_6,&l_2292,&l_2292,&g_6},{&g_197[0],&l_2292,&g_122,&g_197[0],&g_197[0]},{&g_65,&g_197[0],&g_65,&l_2292,(void*)0}};
                    uint16_t l_2326 = 0x3D8BL;
                    int i, j;
                    l_2326--;
                    return (*g_1878);
                }
                (*g_2329) = &l_2322;
                g_2345--;
            }
            l_2353 = ((l_2324[3][5] = (safe_mod_func_int64_t_s_s(((l_2350 != l_2350) >= 0UL), (l_2292 = ((**g_248) = p_25.f0))))) , &l_2342[1][0]);
            (*l_2350) = l_2354;
        }
        if (l_2320)
        { /* block id: 1106 */
            int8_t *l_2381 = &g_635;
            int32_t l_2382 = 0x0846C0F3L;
            int32_t *l_2383[9][1] = {{&l_2382},{&l_2382},{&l_2325[0][0]},{&l_2382},{&l_2382},{&l_2325[0][0]},{&l_2382},{&l_2382},{&l_2325[0][0]}};
            int16_t l_2404 = 3L;
            int32_t l_2406[3][5][7] = {{{(-3L),(-2L),8L,(-2L),(-3L),0x718EB8ACL,0xF6B1E10EL},{(-7L),0xC8AB5FC4L,8L,0x8F22753FL,(-2L),0xDC7762DAL,0xB8F690F0L},{0x8F22753FL,1L,0xA4189445L,0xDC7762DAL,0xDC7762DAL,0xA4189445L,1L},{0xA4189445L,0xF6B1E10EL,1L,(-7L),1L,0x680A16CCL,8L},{9L,(-5L),0xDC7762DAL,0x8F22753FL,8L,(-3L),8L}},{{(-7L),8L,8L,(-7L),0xC8AB5FC4L,8L,0x8F22753FL},{8L,8L,9L,(-3L),0xA4189445L,0xC8AB5FC4L,0x718EB8ACL},{0x8F22753FL,(-5L),8L,0xF6B1E10EL,8L,(-5L),0x8F22753FL},{1L,0xF6B1E10EL,(-5L),0x718EB8ACL,8L,0xB8F690F0L,8L},{(-2L),0xB8F690F0L,(-3L),8L,0xA4189445L,0xA4189445L,8L}},{{(-5L),1L,(-5L),0x680A16CCL,0xC8AB5FC4L,(-2L),0xB8F690F0L},{(-5L),0x718EB8ACL,8L,0xB8F690F0L,8L,1L,(-2L)},{(-2L),1L,9L,9L,1L,(-2L),(-7L)},{1L,8L,8L,9L,(-3L),0xA4189445L,0xC8AB5FC4L},{0x8F22753FL,(-2L),0xDC7762DAL,0xB8F690F0L,0x718EB8ACL,0xB8F690F0L,0xDC7762DAL}}};
            int16_t l_2459 = 7L;
            int32_t *l_2493 = &l_2320;
            int32_t **l_2494 = (void*)0;
            int i, j, k;
            if ((((l_2292 = ((safe_lshift_func_int16_t_s_s((safe_add_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((((*g_1878) = (safe_unary_minus_func_uint8_t_u((*****g_2081)))) ^ (safe_lshift_func_int16_t_s_s(p_23, 11))) , 0x9A05L), (0xCD64288BL & (((safe_div_func_uint64_t_u_u(((safe_lshift_func_int32_t_s_s((g_2368[1] == l_2369), 10)) | 0L), ((safe_add_func_uint64_t_u_u(((**g_248) |= ((l_2320 = (safe_mod_func_int32_t_s_s((safe_sub_func_uint64_t_u_u(((((*g_513) = (p_26 < (safe_lshift_func_int8_t_s_u(((*l_2381) ^= ((!((((((*l_2353) = ((safe_mul_func_int8_t_s_s(0xCBL, p_24)) <= 0UL)) != p_23) & 0xE8L) | l_2320) ^ p_26)) , 3L)), l_2382)))) && 0xC231L) < 0UL), l_2344)), (-1L)))) , 0UL)), (-1L))) || l_2382))) ^ 3L) < l_2382)))), p_23)), p_23)) > 1L)) >= 1L) | 1L))
            { /* block id: 1114 */
                int32_t **l_2384[3][10][3] = {{{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]}},{{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]}},{{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]},{&l_2353,&l_2353,&l_2353},{&l_2383[0][0],&l_2383[0][0],&l_2383[0][0]}}};
                int i, j, k;
                l_2385 = &l_2342[1][7];
            }
            else
            { /* block id: 1116 */
                int16_t l_2393 = 0L;
                int32_t l_2394 = 0x034F7F43L;
                int32_t l_2395 = 0x83E6DED1L;
                int32_t l_2396 = 0xCDE482A8L;
                int32_t l_2397 = (-1L);
                int32_t l_2398 = (-2L);
                int8_t l_2399 = 0x3FL;
                int32_t l_2400 = 6L;
                int32_t l_2401 = (-1L);
                int32_t l_2402 = 0x6864C590L;
                int32_t l_2403[5][3][8] = {{{(-1L),(-1L),0x7BA4540DL,(-1L),(-1L),0x7BA4540DL,(-1L),(-1L)},{0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL,(-1L)},{0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL}},{{0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL},{0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL},{0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL}},{{0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL},{0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL},{0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL}},{{0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL},{0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL},{0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL}},{{0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL,(-1L),0xEBB0EE1BL,0xEBB0EE1BL},{0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL},{0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL,0x7BA4540DL,0xEBB0EE1BL,0x7BA4540DL}}};
                int i, j, k;
                l_2394 = (safe_mul_func_uint16_t_u_u((!(++(**g_248))), ((safe_div_func_int16_t_s_s(((*l_2353) = (l_2393 = (p_26 = 0x3BC6L))), p_23)) != 0x62DAL)));
                l_2407++;
lbl_2437:
                for (g_213 = 0; (g_213 == (-30)); g_213 = safe_sub_func_uint32_t_u_u(g_213, 4))
                { /* block id: 1125 */
                    int8_t l_2416 = 0xC3L;
                    for (p_23 = 7; (p_23 > 58); p_23 = safe_add_func_int8_t_s_s(p_23, 1))
                    { /* block id: 1128 */
                        int64_t l_2417 = 0xF9082D228DA0AA44LL;
                        uint16_t *l_2422[6][8][4] = {{{&g_267,&g_600,&l_2407,&g_600},{&g_179,&g_179,&g_267,&l_2407},{&g_267,(void*)0,(void*)0,(void*)0},{&g_179,&g_179,&g_600,&l_2407},{&g_179,(void*)0,&l_2407,&g_267},{&g_267,&l_2407,&l_2407,&l_2407},{&g_179,&g_267,&l_2407,&g_179},{&g_600,&g_179,(void*)0,&g_600}},{{&g_267,&g_179,(void*)0,&g_179},{&g_267,&l_2407,&g_267,(void*)0},{&g_600,&g_179,(void*)0,&g_179},{&g_179,&l_2407,&l_2407,&g_179},{&g_267,&g_179,&g_600,(void*)0},{&g_179,&g_179,(void*)0,&g_267},{(void*)0,&g_600,(void*)0,&l_2407},{&l_2407,&g_179,&l_2407,&g_179}},{{&l_2407,(void*)0,&l_2407,&g_179},{&g_267,&g_179,&l_2407,(void*)0},{&l_2407,&g_179,&l_2407,&g_600},{&l_2407,&g_179,(void*)0,&g_179},{(void*)0,&g_179,(void*)0,&g_267},{&g_179,&g_179,&g_600,&g_179},{&g_179,&g_179,&g_600,(void*)0},{(void*)0,(void*)0,&l_2407,&g_600}},{{(void*)0,&g_179,&g_179,&g_179},{&g_179,&g_179,&l_2407,(void*)0},{&g_179,&l_2407,&g_600,&g_267},{(void*)0,&l_2407,&g_179,(void*)0},{&g_179,&g_267,&g_267,&l_2407},{(void*)0,&g_179,&g_267,&l_2407},{(void*)0,&g_179,&g_267,&l_2407},{&g_179,&g_600,&g_267,(void*)0}},{{(void*)0,&l_2407,&g_179,&g_600},{(void*)0,(void*)0,&g_179,&l_2407},{&g_179,&g_179,&g_179,&g_179},{&g_179,&g_267,&g_600,&g_179},{&g_179,&l_2407,&g_179,&g_179},{&l_2407,&g_267,(void*)0,&g_179},{(void*)0,&l_2407,&g_600,&g_179},{&g_267,&g_267,&g_267,&g_179}},{{(void*)0,&g_179,&g_267,&l_2407},{&g_179,(void*)0,(void*)0,&g_600},{&l_2407,&l_2407,&g_179,(void*)0},{&g_600,&g_600,&g_267,&l_2407},{&g_179,&g_179,&l_2407,&l_2407},{&g_179,&g_179,&g_179,&l_2407},{&l_2407,&g_267,(void*)0,(void*)0},{&g_179,&l_2407,&g_179,&g_267}}};
                        uint16_t l_2423 = 0xE07EL;
                        uint8_t *l_2430 = &g_2431;
                        int i, j, k;
                        (*l_2353) = ((safe_add_func_uint32_t_u_u((l_2416 || l_2417), ((safe_sub_func_uint64_t_u_u((((safe_lshift_func_uint16_t_u_s((l_2423 = (0x6FL != (*l_2353))), 7)) ^ (safe_mul_func_int8_t_s_s((((((((g_506 , 0x25L) & (((safe_sub_func_int64_t_s_s((safe_rshift_func_uint8_t_u_u(1UL, ((*l_2430)++))), ((safe_lshift_func_int16_t_s_s(((l_2416 | 0x7FA5B06BL) <= p_26), 1)) < 0x73L))) && p_25.f0) , 1L)) && 0L) < 0xF3L) , l_2400) <= 1UL) ^ l_2417), p_25.f0))) >= l_2398), (-4L))) == p_26))) & 1L);
                        return p_24;
                    }
                    if (l_2344)
                        goto lbl_2437;
                    return l_2436;
                }
                if ((+(safe_div_func_int32_t_s_s((safe_add_func_int64_t_s_s(0x764872840B4C9AE7LL, 18446744073709551615UL)), (safe_mod_func_uint8_t_u_u(l_2445, l_2395))))))
                { /* block id: 1137 */
                    int16_t l_2458[5][8][6] = {{{1L,0x1F7AL,0L,0x29A0L,0x29A0L,0L},{0L,0L,0xB5F1L,(-3L),4L,0xCB03L},{1L,(-1L),(-1L),0xA6E5L,0xA3AAL,0xB5F1L},{0L,1L,(-1L),0L,0L,0xCB03L},{0x731DL,0L,0xB5F1L,0xE8D2L,0L,0L},{0xE8D2L,0L,0L,(-1L),0L,1L},{0xBA7EL,0x6EBEL,0L,0xB407L,0x1E33L,0x83AAL},{0x1E33L,0xCB03L,0x315DL,0x731DL,(-3L),0x3F0CL}},{{1L,1L,0xCB15L,0x6EBEL,0L,0x5965L},{(-8L),0xB5F1L,(-10L),0xCB15L,0xE8D2L,0xC663L},{1L,0x5965L,0x6F73L,(-1L),0xCB03L,0xB407L},{0L,0x2458L,0x2A40L,0xBA7EL,(-10L),0xBA7EL},{(-9L),0x6078L,(-9L),0L,0xBA7EL,1L},{0x315DL,(-1L),0xAC84L,4L,0x782DL,0x6F73L},{1L,0L,0x81DEL,(-1L),2L,0L},{0x3D54L,(-1L),0x6078L,0L,(-8L),2L}},{{0xCA13L,1L,0xA6E5L,0xAC84L,1L,(-1L)},{1L,0x5965L,0x1F7AL,0x6078L,4L,0L},{1L,(-9L),0xB407L,0x0BBBL,0x055AL,6L},{0xF3DEL,4L,0xA3AAL,(-1L),0xC663L,0xCA13L},{(-1L),0xB407L,0L,0L,(-1L),0x83AAL},{0L,0x0BBBL,0x89B2L,1L,0xE8D2L,1L},{0xAC84L,0xCA13L,0x2A40L,(-10L),0x3F0CL,0x3F0CL},{(-1L),(-8L),(-8L),(-1L),(-9L),0x1E33L}},{{0L,(-10L),0x315DL,(-1L),0x7F76L,(-8L)},{0xE8D2L,(-1L),2L,1L,0x7F76L,(-1L)},{0x6F73L,(-10L),0xAC84L,0x782DL,(-9L),0xB5F1L},{1L,(-8L),(-1L),0x83AAL,0x3F0CL,0xC663L},{(-1L),0xCA13L,(-1L),0x99C6L,0xE8D2L,1L},{0xCB03L,0x0BBBL,0x782DL,0x2458L,(-1L),0x7F76L},{0x89B2L,0xB407L,0x99C6L,(-1L),0xC663L,0x2458L},{(-1L),4L,1L,0xA6E5L,0x055AL,0xB407L}},{{1L,(-9L),1L,(-8L),4L,0x29A0L},{0x2A40L,0x5965L,1L,(-1L),1L,0x731DL},{(-8L),1L,1L,1L,(-8L),0L},{0x83AAL,(-1L),1L,0xCB15L,2L,0x99C6L},{(-1L),0L,4L,(-1L),1L,0x99C6L},{0L,0xC663L,1L,0L,0xAC84L,0L},{1L,0x2458L,1L,0x89B2L,0xB5F1L,0x731DL},{0x1E33L,0x1F7AL,1L,6L,0xCB15L,0x29A0L}}};
                    uint16_t *l_2463 = &g_267;
                    int i, j, k;
                    (*l_2385) |= ((((*l_2463) = (safe_sub_func_int64_t_s_s(p_25.f0, (safe_div_func_int8_t_s_s((((((safe_sub_func_int64_t_s_s((*l_2353), ((((p_24 > p_26) ^ 0x13A9174AL) , (*l_2353)) , (p_23 , (((****g_2007) || (safe_sub_func_int16_t_s_s((safe_add_func_uint32_t_u_u((safe_mod_func_int32_t_s_s(l_2458[4][5][5], l_2459)), l_2393)), p_26))) ^ l_2403[2][0][3]))))) | 0xB8E88A2EL) >= (-6L)) , &g_233) == g_2460), p_25.f0))))) != 0xE8BCL) && l_2458[0][6][3]);
                }
                else
                { /* block id: 1140 */
                    int16_t l_2480 = 0x824EL;
                    int8_t l_2481 = 0x7CL;
                    int32_t l_2482 = 0xF3439A26L;
                    int32_t **l_2488 = &g_1158[1][0];
                    int32_t **l_2489 = &l_2383[7][0];
                    for (l_2402 = (-17); (l_2402 < 23); l_2402 = safe_add_func_uint16_t_u_u(l_2402, 6))
                    { /* block id: 1143 */
                        uint32_t l_2474[9];
                        int32_t l_2479[5] = {(-2L),(-2L),(-2L),(-2L),(-2L)};
                        int i;
                        for (i = 0; i < 9; i++)
                            l_2474[i] = 1UL;
                        l_2482 = ((*l_2385) = (&g_425 != ((((safe_rshift_func_int8_t_s_s((((*l_2353) = (safe_mul_func_uint32_t_u_u(0x9F323D68L, ((0x7AD8101201C82C02LL < (--(**g_248))) > ((((**g_2082) == (***g_2081)) > (safe_add_func_uint64_t_u_u(l_2474[0], (safe_sub_func_int64_t_s_s(((((-1L) < ((safe_div_func_uint64_t_u_u((l_2479[1] &= p_24), l_2480)) || 0x33L)) ^ g_65) < p_25.f0), p_23))))) , p_26))))) < (*l_2385)), (*g_1878))) > l_2481) , 1L) , (void*)0)));
                        if (p_23)
                            break;
                    }
                    for (l_2401 = (-6); (l_2401 <= 9); l_2401 = safe_add_func_int64_t_s_s(l_2401, 1))
                    { /* block id: 1153 */
                        uint64_t l_2485 = 0x7152798826D02A29LL;
                        --l_2485;
                        (*l_2385) &= 0x803BF531L;
                        if (p_24)
                            continue;
                        (*l_2353) = 1L;
                    }
                    (*l_2489) = ((*l_2488) = &l_2325[5][0]);
                }
            }
            l_2320 ^= (p_25.f0 > (safe_mul_func_uint8_t_u_u((***g_2008), (*l_2353))));
            (*g_2492) = (p_24 , &l_2342[2][4]);
            (*g_2495) = l_2493;
        }
        else
        { /* block id: 1166 */
lbl_2514:
            (*g_2492) = &l_2320;
        }
        (*g_2499) = ((l_2496[5] != l_2498) , (*g_194));
        for (l_2344 = (-24); (l_2344 <= 5); l_2344 = safe_add_func_int64_t_s_s(l_2344, 1))
        { /* block id: 1172 */
            int32_t *l_2502 = &g_197[3];
            int32_t *l_2503 = &g_197[3];
            int32_t *l_2504 = &g_197[3];
            int32_t l_2505[1][5][6] = {{{9L,9L,6L,0L,(-1L),(-5L)},{0xED13A770L,(-3L),1L,6L,(-2L),6L},{1L,0xED13A770L,1L,1L,9L,(-5L)},{(-3L),1L,6L,(-1L),0x9A0E57ABL,0x9A0E57ABL},{(-1L),0x9A0E57ABL,0x9A0E57ABL,(-1L),6L,1L}}};
            int32_t *l_2506[10][3] = {{&l_2320,&l_2320,(void*)0},{&l_2292,&l_2342[1][1],(void*)0},{(void*)0,&l_2292,&l_2325[0][0]},{&l_2342[7][4],&l_2342[7][4],&g_65},{(void*)0,&g_65,&l_2292},{&l_2292,&g_65,(void*)0},{&g_65,&l_2342[7][4],&l_2342[7][4]},{&l_2325[0][0],&l_2292,(void*)0},{(void*)0,&l_2342[1][1],&l_2292},{(void*)0,&l_2320,&g_65}};
            union U0 ** const *l_2517 = &g_291[2];
            union U0 ** const **l_2518 = &l_2517;
            int i, j, k;
            --l_2507;
            for (g_1931 = 0; (g_1931 <= 1); ++g_1931)
            { /* block id: 1176 */
                for (g_179 = 0; (g_179 >= 7); g_179 = safe_add_func_int32_t_s_s(g_179, 2))
                { /* block id: 1179 */
                    if (g_506)
                        goto lbl_2514;
                    for (g_202 = 0; (g_202 <= 0); g_202 += 1)
                    { /* block id: 1183 */
                        int i, j, k;
                        l_2505[g_202][(g_202 + 3)][(g_202 + 5)] &= (*l_2385);
                    }
                    (*l_2502) = (safe_sub_func_int32_t_s_s(0x6AD0C904L, g_1931));
                }
                (*l_2504) |= (*l_2353);
            }
            (*l_2503) = ((*l_2353) ^ (((*l_2518) = l_2517) != (void*)0));
        }
    }
    else
    { /* block id: 1193 */
        uint32_t *l_2531[4][5] = {{&g_887[1][2][0],&g_887[0][0][0],&g_887[1][2][0],&g_887[1][2][0],&g_887[0][0][0]},{&g_887[0][0][0],&g_887[1][2][0],&g_887[1][2][0],&g_887[0][0][0],&g_887[1][2][0]},{&g_887[0][0][0],&g_887[0][0][0],&g_887[1][2][0],&g_887[0][0][0],&g_887[0][0][0]},{&g_887[1][2][0],&g_887[0][0][0],&g_887[1][2][0],&g_887[1][2][0],&g_887[0][0][0]}};
        int32_t l_2532 = 0x84A8F585L;
        int64_t *l_2537[4] = {&g_213,&g_213,&g_213,&g_213};
        uint8_t *l_2538 = &g_2431;
        uint8_t *l_2539 = (void*)0;
        uint8_t *l_2540 = &g_2541[1];
        int16_t l_2595 = 0L;
        int32_t l_2598 = (-1L);
        int32_t l_2599 = 0x55E3DCA4L;
        int32_t l_2601[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        uint32_t l_2602 = 0x6579A3ABL;
        union U0 l_2616 = {0x41358D941C296875LL};
        int32_t l_2631[5];
        uint16_t l_2686 = 0xD001L;
        uint32_t l_2717 = 18446744073709551615UL;
        int32_t **l_2737 = &l_2497[1][0];
        int32_t *l_2742 = &g_65;
        uint64_t **l_2753[5] = {&g_249[5],&g_249[5],&g_249[5],&g_249[5],&g_249[5]};
        int32_t l_2756 = (-1L);
        uint16_t l_2817 = 0xD88CL;
        int64_t l_2847 = 1L;
        int8_t l_2851 = 0x2FL;
        uint64_t l_2870[8];
        int64_t ***l_2940 = &g_2578;
        int64_t ***l_2942[2][10] = {{&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578},{&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578,&g_2578}};
        uint8_t ***l_3104 = &l_2290;
        uint8_t ****l_3103[9][5] = {{&l_3104,(void*)0,&l_3104,&l_3104,&l_3104},{&l_3104,&l_3104,&l_3104,&l_3104,&l_3104},{&l_3104,(void*)0,&l_3104,&l_3104,&l_3104},{&l_3104,&l_3104,&l_3104,&l_3104,&l_3104},{&l_3104,(void*)0,&l_3104,&l_3104,&l_3104},{&l_3104,&l_3104,&l_3104,&l_3104,&l_3104},{&l_3104,(void*)0,&l_3104,&l_3104,&l_3104},{&l_3104,&l_3104,&l_3104,&l_3104,&l_3104},{&l_3104,(void*)0,&l_3104,&l_3104,&l_3104}};
        int i, j;
        for (i = 0; i < 5; i++)
            l_2631[i] = 0xD3963641L;
        for (i = 0; i < 8; i++)
            l_2870[i] = 8UL;
        if (((*l_2353) = (((safe_div_func_uint64_t_u_u(((safe_mod_func_int64_t_s_s((safe_rshift_func_int32_t_s_u((safe_add_func_int8_t_s_s((((****g_2082) ^= (*l_2353)) || p_24), p_23)), (safe_sub_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((((l_2532 = p_23) == (-4L)) , (safe_rshift_func_int8_t_s_u(((*g_1878) = (safe_mul_func_uint16_t_u_u(0x0CE9L, (g_267 ^= 0x19ADL)))), 7))), 7)), ((p_25.f0 = 3L) < (((((*l_2540) = ((*l_2538) = (*l_2353))) , (*l_2353)) == 0L) & (*l_2353))))))), 18446744073709551611UL)) || 0x1C37C15EL), p_23)) , &g_2460) != &g_2460)))
        { /* block id: 1202 */
            int16_t l_2550 = 1L;
            int32_t *l_2564[9][8] = {{&g_197[1],(void*)0,&g_122,&g_122,&g_122,(void*)0,&g_197[1],&g_197[2]},{&l_2325[0][0],&g_122,&g_65,&g_197[3],&g_122,&g_197[2],&l_2292,&l_2532},{&g_122,(void*)0,&g_6,&g_122,&g_122,&g_6,(void*)0,&g_122},{&l_2325[0][0],&g_122,(void*)0,&l_2532,&g_122,(void*)0,&g_65,(void*)0},{&g_197[1],(void*)0,&g_197[2],(void*)0,&l_2532,(void*)0,&g_197[2],(void*)0},{&g_197[2],&g_122,(void*)0,&g_197[3],&l_2325[0][0],&g_6,&g_122,&g_197[2]},{(void*)0,(void*)0,&g_122,&g_122,&g_197[2],&g_197[2],&g_122,&g_122},{&g_122,&g_122,(void*)0,&l_2325[0][0],(void*)0,&l_2292,&g_122,&g_122},{(void*)0,&l_2292,&g_122,&g_122,&g_197[2],&g_197[3],&g_197[2],&g_122}};
            int8_t l_2589 = 0xF3L;
            int16_t l_2594 = 0x39A7L;
            int16_t l_2695[6][6][4] = {{{(-7L),0x8C22L,0x159AL,1L},{0xEE27L,(-1L),1L,0x147AL},{1L,0x147AL,(-7L),0x147AL},{(-5L),(-1L),0x307BL,1L},{(-9L),0x8C22L,0x147AL,0L},{0x307BL,(-5L),0xE60BL,0xE60BL}},{{0x307BL,0x307BL,0x147AL,(-7L)},{(-9L),0xE60BL,0x307BL,0x8C22L},{(-5L),0xEE27L,(-7L),0x307BL},{1L,0xEE27L,1L,0x8C22L},{0xEE27L,0xE60BL,0x159AL,(-7L)},{(-7L),0x307BL,(-5L),0xE60BL}},{{0L,(-5L),(-5L),0L},{(-7L),0x8C22L,0x159AL,1L},{0xEE27L,(-1L),1L,0x147AL},{1L,0x147AL,(-7L),0x147AL},{(-5L),(-1L),0x307BL,1L},{(-9L),0x8C22L,0x147AL,0L}},{{0x307BL,(-5L),0xE60BL,0xE60BL},{0x307BL,0x307BL,0x147AL,(-7L)},{(-9L),0xE60BL,0x307BL,0x8C22L},{(-5L),0xEE27L,(-7L),0x307BL},{1L,0xEE27L,1L,0x8C22L},{0xEE27L,0xE60BL,0x159AL,(-7L)}},{{(-7L),0x307BL,(-5L),0xE60BL},{0L,(-5L),(-5L),0L},{(-7L),0x8C22L,0x159AL,1L},{0xEE27L,(-1L),1L,0x147AL},{1L,0x147AL,(-7L),0x147AL},{(-5L),(-1L),0x307BL,1L}},{{(-9L),0x8C22L,0x147AL,0L},{0x307BL,(-5L),0xE60BL,0xE60BL},{0x307BL,0x307BL,0x147AL,(-7L)},{(-9L),0xE60BL,0x307BL,0x8C22L},{(-5L),0xEE27L,(-7L),0x307BL},{1L,0xEE27L,1L,0x8C22L}}};
            int64_t l_2724 = 0x0B264D6A40921FE3LL;
            int i, j, k;
lbl_2699:
            if ((safe_sub_func_int32_t_s_s((safe_lshift_func_int64_t_s_s((l_2550 = ((p_25.f0 , l_2546) == &g_2460)), 4)), (((void*)0 != l_2551[1]) , (((safe_mod_func_uint32_t_u_u((l_2532 ^ ((0x1178C8B28DB9A14CLL != (safe_rshift_func_int8_t_s_u((((safe_sub_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u((!p_25.f0), ((***g_2008) & p_25.f0))), (-8L))) < p_23) ^ 0xF0L), p_26))) != (*l_2353))), p_23)) & (*g_521)) <= l_2532)))))
            { /* block id: 1204 */
                int16_t l_2565 = 1L;
                uint8_t ***l_2570 = &l_2290;
                uint8_t ****l_2569 = &l_2570;
                uint32_t l_2575 = 18446744073709551615UL;
                int64_t ** const ***l_2580[8][9][1] = {{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}},{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}},{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}},{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}},{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}},{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}},{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}},{{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576},{&g_2576}}};
                int32_t l_2585 = 0L;
                int32_t l_2587 = 0x93DFA715L;
                int32_t l_2588[5] = {0x1BC7B311L,0x1BC7B311L,0x1BC7B311L,0x1BC7B311L,0x1BC7B311L};
                int8_t l_2596 = 0x60L;
                int8_t l_2597 = 0x78L;
                int32_t ***l_2613 = &g_1157[0];
                int32_t ****l_2612 = &l_2613;
                int64_t l_2635 = 0xE9BAE57EAD49E108LL;
                int i, j, k;
lbl_2617:
                (*g_631) = l_2564[1][7];
                if ((((((l_2532 , l_2565) == ((*l_2353) , (l_2568[0][8][3] |= (safe_lshift_func_int64_t_s_s((p_25.f0 | p_26), 50))))) , ((((*l_2569) = &l_2290) != (*g_2082)) & ((((g_2581 = (g_2576 = (((safe_lshift_func_int32_t_s_s((safe_add_func_uint64_t_u_u(0x3F7C692D28F029C4LL, (l_2575 = l_2532))), p_25.f0)) < 9L) , g_2576))) == l_2582[4]) < (*g_1878)) <= l_2565))) != (*l_2353)) ^ (-1L)))
                { /* block id: 1211 */
                    int32_t l_2586 = 6L;
                    int32_t l_2591 = 0x594C27AEL;
                    int64_t l_2592 = 0L;
                    int32_t l_2593[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_2593[i] = (-1L);
                    ++l_2602;
                }
                else
                { /* block id: 1213 */
                    int64_t l_2625 = 0L;
                    int32_t l_2629 = (-1L);
                    int32_t l_2632 = 1L;
                    int32_t l_2633 = 0x35606793L;
                    int32_t l_2636 = 2L;
                    int32_t l_2637 = 0xA2E5C5F0L;
                    for (l_2550 = 0; l_2550 < 6; l_2550 += 1)
                    {
                        l_2405[l_2550] = 0x1AD0L;
                    }
                    if ((((((safe_mul_func_int64_t_s_s((safe_unary_minus_func_uint32_t_u(g_197[2])), ((((safe_mod_func_uint64_t_u_u(18446744073709551613UL, ((**g_2578) |= p_24))) > ((6L < p_25.f0) > ((g_585 || ((void*)0 == l_2612)) == (safe_lshift_func_int16_t_s_s((l_2616 , 1L), 9))))) && 0x5BBF1EC949949F2ALL) || 1L))) , (***g_2081)) == (void*)0) && 1L) ^ (**g_1015)))
                    { /* block id: 1216 */
                        uint16_t l_2618 = 3UL;
                        if (g_65)
                            goto lbl_2617;
                        ++l_2618;
                    }
                    else
                    { /* block id: 1219 */
                        return (*g_1878);
                    }
                    (*g_2462) = (*g_2462);
                    for (l_2596 = (-2); (l_2596 < 27); l_2596++)
                    { /* block id: 1225 */
                        int32_t l_2623 = (-10L);
                        int32_t l_2624 = 0x68DCEC05L;
                        int32_t l_2626 = 0L;
                        int32_t l_2627 = 1L;
                        int32_t l_2628 = 0x2E930FD7L;
                        int32_t l_2630 = (-1L);
                        int32_t l_2634[5];
                        int i;
                        for (i = 0; i < 5; i++)
                            l_2634[i] = 0xE2502ABFL;
                        g_2638--;
                    }
                }
            }
            else
            { /* block id: 1229 */
                int32_t l_2643 = 0x7DA38674L;
                int32_t l_2645 = 0x677B4BBDL;
                int32_t l_2646[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_2646[i] = 1L;
                if (p_24)
                { /* block id: 1230 */
                    return p_25.f0;
                }
                else
                { /* block id: 1232 */
                    int8_t l_2642 = 0xFCL;
                    int32_t l_2644 = (-1L);
                    int32_t l_2647 = 0xD0B257B3L;
                    int32_t l_2648 = 0x1DC52E88L;
                    uint32_t l_2649 = 0x8AA1EB59L;
                    --l_2649;
                    if ((safe_div_func_int8_t_s_s((~(((*g_513) >= ((safe_sub_func_int64_t_s_s((l_2649 ^ p_25.f0), (-1L))) >= (safe_sub_func_uint64_t_u_u((safe_sub_func_int16_t_s_s((*g_513), (safe_mod_func_uint8_t_u_u((l_2616.f0 & (((*l_2353) &= (((*g_1878) = (((safe_mul_func_int64_t_s_s(p_26, ((**g_248) = ((((((safe_rshift_func_uint8_t_u_u(((-1L) ^ ((***l_2583) = (-1L))), 7)) ^ p_23) == (*g_424)) , 0x4C08B44139F9608BLL) || 0x02A7BB73459025E2LL) == p_24)))) <= l_2643) <= g_506)) != p_25.f0)) || l_2642)), p_25.f0)))), (-5L))))) || p_23)), 0xA5L)))
                    { /* block id: 1238 */
                        uint8_t l_2667 = 250UL;
                        l_2646[2] = p_24;
                        --l_2667;
                        (*l_2353) ^= ((p_24 <= ((*g_1878) = (0UL == ((safe_mod_func_uint64_t_u_u((safe_rshift_func_int32_t_s_s((((((safe_sub_func_uint16_t_u_u(((g_2368[1] == (void*)0) <= p_23), g_268)) || ((l_2667 != (safe_sub_func_int32_t_s_s((-1L), (safe_mod_func_int32_t_s_s((((g_887[1][2][0] = (safe_div_func_int64_t_s_s(0x14EC419B02CBE2ACLL, p_24))) ^ 0UL) > l_2649), l_2643))))) < g_2202)) || 0xA48F6EED0CCDF7C1LL) , &p_23) != &l_2649), p_26)), 18446744073709551615UL)) , 65526UL)))) == l_2645);
                    }
                    else
                    { /* block id: 1244 */
                        uint16_t l_2696 = 0x6906L;
                        (*l_2549) = ((((safe_mod_func_uint8_t_u_u(p_24, (*g_1878))) , (p_23 = 0UL)) > (l_2696 = (l_2532 = (((void*)0 != &g_2461) && (l_2686 | ((l_2695[3][4][2] |= (safe_add_func_uint32_t_u_u((safe_rshift_func_int32_t_s_u(((*l_2353) ^= ((safe_div_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u(0UL, (p_25.f0 , l_2595))) <= 0x8D5CL), 2L)) > p_26)), 31)), p_26))) < l_2642)))))) , &l_2599);
                    }
                }
                return l_2643;
            }
            for (l_2550 = 23; (l_2550 <= 9); l_2550 = safe_sub_func_int32_t_s_s(l_2550, 4))
            { /* block id: 1257 */
                if (l_2595)
                    goto lbl_2699;
                for (g_202 = 4; (g_202 >= 0); g_202 -= 1)
                { /* block id: 1261 */
                    volatile int32_t * volatile l_2700 = &g_1300;/* VOLATILE GLOBAL l_2700 */
                    int32_t l_2716 = 0xF09DDE32L;
                    int i, j;
                    if ((*l_2353))
                        break;
                    l_2700 = (*g_2462);
                    if (p_24)
                        continue;
                    for (p_24 = 0; (p_24 >= 0); p_24 -= 1)
                    { /* block id: 1267 */
                        uint32_t *l_2714 = &g_296;
                        uint32_t **l_2713 = &l_2714;
                        uint32_t ***l_2712 = &l_2713;
                        int i, j, k;
                        l_2716 = ((((((safe_div_func_int64_t_s_s((p_24 ^ 0x78L), p_26)) , ((*g_513) != (p_26 , (((safe_mul_func_uint16_t_u_u((((safe_mod_func_int64_t_s_s((safe_rshift_func_int64_t_s_s(((**g_2578) &= ((void*)0 == l_2709)), 56)), (safe_sub_func_uint16_t_u_u((((void*)0 != (*l_2546)) , 65528UL), 0x3D96L)))) > p_26) , l_2631[2]), (*g_424))) , (void*)0) == l_2712)))) , g_2715) == &p_24) == p_25.f0) != p_23);
                    }
                }
                l_2717--;
            }
            for (l_2599 = (-2); (l_2599 < 16); l_2599++)
            { /* block id: 1276 */
                int8_t l_2739 = 0xA7L;
                int32_t *l_2741 = &g_65;
                uint16_t *l_2757 = (void*)0;
                uint16_t *l_2758 = &g_267;
                (*l_2353) = (((safe_lshift_func_uint32_t_u_u(l_2724, g_91)) , ((*g_2579) != 0x33152A2FFA938C35LL)) >= g_6);
                for (l_2686 = (-23); (l_2686 <= 18); l_2686++)
                { /* block id: 1280 */
                    int32_t **l_2738 = &l_2497[4][0];
                    l_2742 = (p_25 , (((((**g_2009) & ((((safe_div_func_int16_t_s_s(((((*l_2353) ^= ((((*g_513) = (safe_mul_func_uint32_t_u_u((p_23 = (0xE635L ^ p_25.f0)), (0xD4L <= (l_2601[8] = (safe_mod_func_int32_t_s_s((((((++g_119) >= (safe_rshift_func_uint8_t_u_u(((*l_2540) = (l_2737 == l_2738)), (p_25.f0 , l_2739)))) , p_24) && g_2202) > (*g_424)), p_26))))))) && g_1017) && (-7L))) != p_24) ^ (-1L)), l_2631[1])) | 4L) == p_24) >= 0UL)) , g_197[0]) <= g_2740) , l_2741));
                }
                (*l_2353) |= (((safe_lshift_func_uint64_t_u_u((safe_mod_func_int16_t_s_s((1L <= (safe_unary_minus_func_int8_t_s((*g_1878)))), ((*l_2758) = (safe_add_func_int8_t_s_s((*g_1878), (safe_unary_minus_func_uint16_t_u((((safe_add_func_int16_t_s_s(((void*)0 == l_2753[0]), (*l_2741))) >= (((**l_2709) = ((safe_rshift_func_uint8_t_u_s(((l_2540 == (void*)0) | ((((*l_2742) ^ 0x46L) & p_25.f0) && l_2756)), 1)) , 0xD0A22F65CA3C2CDCLL)) & (*g_1096))) , g_436)))))))), 54)) | 65528UL) , (*l_2741));
            }
            (*l_2353) ^= (0x17CDEE6EL ^ (safe_rshift_func_int32_t_s_s((-4L), 13)));
        }
        else
        { /* block id: 1294 */
            uint32_t **l_2761 = (void*)0;
            uint32_t **l_2762 = (void*)0;
            uint32_t **l_2763 = (void*)0;
            uint32_t **l_2764 = (void*)0;
            uint32_t **l_2765 = &l_2531[3][1];
            int32_t l_2782[7][10] = {{(-2L),0x1C447D59L,0x20282C76L,0x1C447D59L,(-2L),0x0440A4C6L,0x1C447D59L,0x8A15E4CCL,0x84EE8528L,(-2L)},{(-2L),0x7075995BL,8L,0x1C447D59L,0x91E2DA97L,0x91E2DA97L,0x1C447D59L,8L,0x7075995BL,(-2L)},{0x91E2DA97L,0x1C447D59L,8L,0x7075995BL,(-2L),0x91E2DA97L,0x7075995BL,0x8A15E4CCL,0x7075995BL,0x91E2DA97L},{(-2L),0x1C447D59L,0x20282C76L,0x1C447D59L,(-2L),0x0440A4C6L,0x1C447D59L,0x8A15E4CCL,0x84EE8528L,(-2L)},{(-2L),0x7075995BL,8L,0x1C447D59L,0x91E2DA97L,0x91E2DA97L,0x1C447D59L,8L,0x7075995BL,(-2L)},{0x91E2DA97L,0x1C447D59L,8L,0x7075995BL,(-2L),0x91E2DA97L,0x7075995BL,0x8A15E4CCL,0x7075995BL,0x91E2DA97L},{(-2L),0x1C447D59L,0x20282C76L,0x1C447D59L,(-2L),0x0440A4C6L,0x1C447D59L,0x8A15E4CCL,0x84EE8528L,(-2L)}};
            int32_t ***l_2888 = &l_2496[5];
            int8_t l_2896 = (-6L);
            int32_t l_2906 = 1L;
            int16_t l_2948 = (-1L);
            uint32_t l_2950 = 0x08E5199EL;
            uint64_t **l_2982 = &g_249[5];
            uint32_t **l_3068[2][7] = {{&g_3066[0][1][3],&g_3066[0][3][2],&g_3066[0][3][2],&g_3066[0][1][3],&g_3066[0][3][2],&g_3066[0][3][2],&g_3066[0][1][3]},{&g_3066[0][3][2],&g_3066[0][1][3],&g_3066[0][3][2],&g_3066[0][3][2],&g_3066[0][1][3],&g_3066[0][3][2],&g_3066[0][3][2]}};
            int i, j;
            if (((p_25.f0 = (((*l_2765) = &p_23) == (void*)0)) , (safe_sub_func_int16_t_s_s(((safe_lshift_func_uint64_t_u_s((**g_248), (*l_2742))) < ((safe_rshift_func_int16_t_s_s((~p_23), (*l_2742))) <= (*l_2742))), p_23))))
            { /* block id: 1297 */
                return (*l_2742);
            }
            else
            { /* block id: 1299 */
                int32_t ***l_2778 = (void*)0;
                int32_t *** const *l_2777 = &l_2778;
                int32_t l_2784[2][4][6] = {{{(-4L),0xE521EDE2L,0xE521EDE2L,(-4L),0x14F122A7L,0L},{0x0F43C9C6L,1L,(-5L),0x8FBE963FL,0x15F07962L,(-1L)},{(-5L),(-9L),0xAD716EAFL,0xDD3B9B61L,0x15F07962L,0xDD3B9B61L},{0xD07B8F8AL,1L,0xD07B8F8AL,0x867D6784L,0x14F122A7L,(-9L)}},{{0L,0xE521EDE2L,(-7L),(-1L),0x0F43C9C6L,0x14F122A7L},{0x8FBE963FL,0xDD3B9B61L,0x867D6784L,(-1L),(-1L),0x867D6784L},{0L,0L,1L,0x867D6784L,(-7L),0xD07B8F8AL},{0xD07B8F8AL,0x15F07962L,0L,0xDD3B9B61L,0xE521EDE2L,1L}}};
                uint32_t **l_2822[10] = {&l_2531[2][2],(void*)0,&l_2531[2][2],&l_2531[2][2],&l_2531[2][2],&l_2531[2][2],(void*)0,&l_2531[2][2],&l_2531[2][2],&l_2531[2][2]};
                uint32_t *** const l_2821 = &l_2822[8];
                uint32_t *** const *l_2820 = &l_2821;
                int8_t l_2842[1][7][4] = {{{0x2AL,(-8L),(-8L),0x2AL},{(-6L),4L,0x49L,0xFDL},{(-8L),6L,0L,6L},{6L,0x49L,(-6L),6L},{(-6L),6L,0xFDL,0xFDL},{4L,4L,0L,(-8L)},{4L,0x49L,0xFDL,4L}}};
                uint32_t l_2853 = 0x9E945FFAL;
                int32_t *l_2869[5];
                uint64_t ** const ***l_2878 = &l_2877;
                uint8_t l_2885 = 0UL;
                int8_t l_2899 = 0L;
                uint64_t l_2902 = 0x05444B296702E4C8LL;
                union U0 *l_2905 = &l_2616;
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_2869[i] = &l_2599;
                if ((safe_rshift_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_s((l_2777 == (void*)0), 3)), ((**g_248) = 0xABBD9615B9E3B955LL))))
                { /* block id: 1301 */
                    int16_t l_2781 = 1L;
                    for (p_24 = 0; (p_24 < (-12)); --p_24)
                    { /* block id: 1304 */
                        if ((*l_2742))
                            break;
                        l_2781 = ((*l_2742) &= p_26);
                        return p_24;
                    }
                }
                else
                { /* block id: 1310 */
                    uint32_t l_2785[3];
                    uint16_t l_2834[6] = {65535UL,0xA77EL,65535UL,65535UL,0xA77EL,65535UL};
                    int32_t l_2837 = (-1L);
                    int32_t l_2840 = 0xD38F0089L;
                    int32_t l_2841 = 0x3F101708L;
                    int32_t l_2843[7] = {0x64CBEC83L,3L,0x64CBEC83L,0x64CBEC83L,3L,0x64CBEC83L,0x64CBEC83L};
                    int32_t l_2852[6] = {(-1L),(-1L),(-6L),(-1L),(-1L),(-6L)};
                    int i;
                    for (i = 0; i < 3; i++)
                        l_2785[i] = 0x302105FAL;
                    for (g_213 = 0; (g_213 <= 3); g_213 += 1)
                    { /* block id: 1313 */
                        int32_t *l_2783[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2783[i] = &l_2292;
                        if (p_23)
                            break;
                        ++l_2785[2];
                    }
                    for (g_213 = (-13); (g_213 > (-6)); g_213 = safe_add_func_int64_t_s_s(g_213, 3))
                    { /* block id: 1319 */
                        uint16_t *l_2798 = (void*)0;
                        uint16_t *l_2799 = &g_267;
                        int16_t *l_2802[8];
                        uint8_t *l_2815 = (void*)0;
                        int32_t l_2816 = 0x583CFD48L;
                        int32_t l_2818 = 0x79406559L;
                        int i;
                        for (i = 0; i < 8; i++)
                            l_2802[i] = &l_2405[4];
                        l_2818 |= ((safe_add_func_int16_t_s_s(((safe_add_func_int16_t_s_s(((*g_513) ^= (*g_424)), (g_1808 = (safe_mod_func_int64_t_s_s((g_6 & ((*l_2799) = (safe_lshift_func_int8_t_s_u(p_26, 3)))), (p_25.f0 = (safe_rshift_func_int32_t_s_u(((void*)0 != &l_2598), 21)))))))) , (safe_add_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s(p_24, 4)), (*g_1878)))), (safe_div_func_int32_t_s_s((safe_lshift_func_uint64_t_u_s(((safe_sub_func_uint16_t_u_u(p_24, (((safe_mod_func_uint32_t_u_u(((g_2010 = (l_2815 = &g_506)) != l_2538), l_2816)) > 6UL) , l_2782[4][4]))) < p_26), l_2817)), 0x5718724FL)))) , p_24);
                    }
                    for (g_635 = 1; (g_635 >= 0); g_635 -= 1)
                    { /* block id: 1330 */
                        uint8_t *l_2827 = &g_2541[1];
                        int32_t l_2835 = 0x2CA2ABDAL;
                        (*l_2353) = (p_25.f0 , (((l_2820 = l_2819) == (((safe_div_func_uint64_t_u_u(((((safe_lshift_func_uint32_t_u_s((((void*)0 == l_2827) , ((**l_2765) = (p_25.f0 , (((safe_add_func_int32_t_s_s((safe_add_func_int64_t_s_s((safe_rshift_func_uint32_t_u_u(0xEF73A879L, l_2834[3])), l_2835)), (0xBE527B2BDF448059LL == p_24))) , 0x99L) > p_26)))), (*l_2742))) < l_2782[5][0]) <= 5L) != 0xEEL), 1UL)) & p_25.f0) , &g_1929)) , l_2782[4][6]));
                    }
                    for (g_506 = 0; (g_506 <= 3); g_506 += 1)
                    { /* block id: 1337 */
                        int32_t *l_2836 = &g_122;
                        int32_t *l_2838 = &g_122;
                        int32_t *l_2839[9][10][2] = {{{(void*)0,&g_65},{(void*)0,&g_6},{&l_2599,&l_2599},{&l_2292,(void*)0},{&l_2599,&l_2601[6]},{&l_2532,&g_65},{(void*)0,&l_2532},{&g_6,&l_2782[4][4]},{&g_6,&l_2532},{(void*)0,&g_65}},{{&l_2532,&l_2601[6]},{&l_2599,(void*)0},{&l_2292,&l_2599},{&l_2599,&g_6},{(void*)0,&g_65},{(void*)0,&g_122},{&l_2532,(void*)0},{&l_2292,&g_65},{&l_2325[6][0],(void*)0},{(void*)0,&g_122}},{{&l_2837,&g_122},{&l_2599,&l_2532},{&g_6,&g_197[0]},{&l_2325[6][0],&l_2782[2][9]},{&l_2599,&l_2325[4][1]},{&l_2784[1][2][5],&g_122},{&l_2322,&g_6},{&l_2784[0][3][4],&g_6},{&l_2599,(void*)0},{&l_2532,&l_2325[4][1]}},{{&l_2837,&l_2601[6]},{(void*)0,(void*)0},{&g_6,&l_2325[6][0]},{&g_6,&g_122},{&l_2599,&g_122},{&g_6,&g_65},{(void*)0,&l_2782[2][9]},{&l_2292,&g_65},{&l_2292,(void*)0},{&l_2322,&g_65}},{{(void*)0,&g_65},{&l_2322,(void*)0},{&l_2292,&g_65},{&l_2292,&l_2782[2][9]},{(void*)0,&g_65},{&g_6,&g_122},{&l_2599,&g_122},{&g_6,&l_2325[6][0]},{&g_6,(void*)0},{(void*)0,&l_2601[6]}},{{&l_2837,&l_2325[4][1]},{&l_2532,(void*)0},{&l_2599,&g_6},{&l_2784[0][3][4],&g_6},{&l_2322,&g_122},{&l_2784[1][2][5],&l_2325[4][1]},{&l_2599,&l_2782[2][9]},{&l_2325[6][0],&g_197[0]},{&g_6,&l_2532},{&l_2599,&g_122}},{{&l_2837,&g_122},{(void*)0,(void*)0},{&l_2325[6][0],&g_65},{&l_2292,(void*)0},{&l_2532,&g_122},{(void*)0,&g_65},{(void*)0,&g_6},{&l_2599,&l_2599},{&l_2292,(void*)0},{&l_2599,&l_2601[6]}},{{&l_2532,&g_65},{(void*)0,&l_2532},{&g_6,&l_2782[4][4]},{&g_6,&l_2532},{(void*)0,&l_2292},{&l_2532,&g_6},{(void*)0,&l_2599},{(void*)0,&g_122},{&g_122,(void*)0},{(void*)0,&l_2784[0][3][4]}},{{(void*)0,&l_2782[4][4]},{(void*)0,&l_2599},{&l_2837,&g_6},{&l_2784[1][2][5],&l_2601[8]},{(void*)0,&l_2292},{&g_65,&l_2325[6][0]},{&l_2325[6][0],&l_2532},{(void*)0,&l_2601[4]},{&l_2784[1][2][5],(void*)0},{(void*)0,&g_197[0]}}};
                        uint8_t l_2848[7] = {0x2BL,0x2BL,0x2BL,0x2BL,0x2BL,0x2BL,0x2BL};
                        int i, j, k;
                        g_2844++;
                        l_2848[6]--;
                        ++l_2853;
                        (*l_2742) &= (g_197[g_506] & p_25.f0);
                    }
                }
                for (l_2599 = 0; (l_2599 <= 1); l_2599 += 1)
                { /* block id: 1346 */
                    int32_t l_2856[1][8] = {{(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)}};
                    uint16_t l_2865 = 0x93D6L;
                    int i, j;
                    (*l_2742) = 0x5E9A878AL;
                    (*l_2353) |= (g_522[l_2599] & l_2856[0][5]);
                    for (g_2032 = 0; (g_2032 <= 2); g_2032 += 1)
                    { /* block id: 1351 */
                        int32_t *l_2857 = &l_2782[4][4];
                        int32_t *l_2858 = &l_2856[0][5];
                        int32_t *l_2859 = &l_2601[8];
                        int32_t *l_2860 = &l_2601[1];
                        int32_t *l_2861 = &l_2325[6][0];
                        int32_t *l_2862 = &l_2598;
                        int32_t *l_2863[10][1][8] = {{{&l_2601[8],(void*)0,&l_2782[3][4],&g_197[3],&l_2601[8],&l_2601[8],&g_197[3],&l_2782[3][4]}},{{&g_197[3],&g_197[3],(void*)0,&l_2782[5][2],&l_2784[0][0][5],&l_2856[0][3],(void*)0,&g_197[3]}},{{&l_2784[0][0][5],&l_2856[0][3],(void*)0,&g_197[3],&l_2322,&l_2782[3][4],&l_2322,&g_197[3]}},{{&l_2856[0][3],(void*)0,&l_2856[0][3],&l_2782[5][2],&l_2598,&l_2601[8],(void*)0,&l_2782[3][4]}},{{&l_2784[1][3][0],&l_2856[0][1],&l_2782[5][2],&g_197[3],(void*)0,&l_2598,&l_2598,(void*)0}},{{&l_2784[1][3][0],&l_2322,&l_2322,&l_2784[1][3][0],&l_2598,&g_197[3],&g_197[3],&l_2601[8]}},{{&l_2856[0][3],&l_2532,&g_197[3],(void*)0,&l_2322,(void*)0,&l_2601[8],(void*)0}},{{&l_2784[0][0][5],&l_2532,&g_197[3],&l_2532,&l_2784[0][0][5],&g_197[3],&l_2784[1][3][0],&l_2599}},{{&g_197[3],&l_2322,&l_2784[0][0][5],&l_2782[3][4],&l_2601[8],&l_2598,&l_2532,&l_2532}},{{&l_2601[8],&l_2856[0][1],&l_2784[0][0][5],&l_2784[0][0][5],&l_2856[0][1],&l_2601[8],&l_2784[1][3][0],&l_2601[8]}}};
                        int32_t l_2864 = 0L;
                        int i, j, k;
                        l_2865--;
                    }
                }
                l_2870[1]++;
                for (l_2595 = 0; (l_2595 != (-6)); l_2595--)
                { /* block id: 1358 */
                    uint32_t l_2884[6] = {0xA490CDD0L,0x6CADEBF4L,0xA490CDD0L,0xA490CDD0L,0x6CADEBF4L,0xA490CDD0L};
                    int32_t l_2891 = 0xC470142EL;
                    int32_t l_2895 = 1L;
                    int32_t l_2898 = (-8L);
                    int32_t l_2900 = 2L;
                    int i;
                    if (((safe_unary_minus_func_uint16_t_u((3L & (((l_2878 = l_2876[0][0][3]) == (void*)0) , ((**l_2709) &= p_23))))) & ((**g_2009) &= (((void*)0 == l_2879) <= ((safe_add_func_uint8_t_u_u((((((safe_mul_func_uint16_t_u_u(l_2884[1], l_2885)) , (((safe_mul_func_int8_t_s_s((l_2888 != &g_1117), l_2884[1])) && p_26) <= (*l_2742))) < 0x03FFF9E042A0AFA5LL) & p_25.f0) >= g_887[4][1][0]), (-2L))) || (*g_1096))))))
                    { /* block id: 1362 */
                        int32_t l_2889 = 0xC2101C0BL;
                        int32_t l_2890 = 0x817C1244L;
                        int32_t l_2892 = (-1L);
                        int32_t l_2893 = 1L;
                        int32_t l_2894[6] = {(-1L),7L,(-1L),(-1L),7L,(-1L)};
                        int64_t l_2901[1][5] = {{0x1CF5AC1815A5F5BCLL,0x1CF5AC1815A5F5BCLL,0x1CF5AC1815A5F5BCLL,0x1CF5AC1815A5F5BCLL,0x1CF5AC1815A5F5BCLL}};
                        int i, j;
                        ++l_2902;
                        (*l_2879) = l_2905;
                        return l_2906;
                    }
                    else
                    { /* block id: 1366 */
                        uint64_t l_2909 = 0xAECB2B4B0A47C828LL;
                        (*l_2742) = (((*g_513) = 0x2A79L) | (p_23 , (l_2909 <= (((safe_add_func_uint16_t_u_u(g_811.f0, ((l_2891 ^ ((safe_rshift_func_uint64_t_u_s(p_24, 18)) && ((*l_2353) &= (l_2737 == ((safe_mul_func_uint32_t_u_u((((1UL < l_2782[2][2]) && 0xFF41453EL) ^ p_23), (*l_2742))) , (*l_2888)))))) >= p_26))) || l_2782[4][4]) != (**g_2578)))));
                        (***g_2460) = (**g_2461);
                    }
                }
            }
            if (p_26)
            { /* block id: 1374 */
                int16_t l_2933 = 0x098CL;
                int32_t l_2945[5][2][8] = {{{(-9L),1L,1L,(-9L),1L,(-9L),1L,1L},{1L,1L,(-5L),(-5L),1L,1L,1L,(-5L)}},{{(-9L),1L,(-9L),1L,1L,(-9L),1L,(-9L)},{0xBB19FEB6L,1L,(-5L),1L,0xBB19FEB6L,0xBB19FEB6L,1L,(-5L)}},{{0xBB19FEB6L,0xBB19FEB6L,1L,(-5L),1L,0xBB19FEB6L,0xBB19FEB6L,1L},{(-9L),1L,1L,(-9L),1L,(-9L),(-9L),(-9L)}},{{(-9L),0xBB19FEB6L,1L,1L,0xBB19FEB6L,(-9L),0xBB19FEB6L,1L},{(-5L),0xBB19FEB6L,(-5L),(-9L),(-9L),(-5L),0xBB19FEB6L,(-5L)}},{{1L,(-9L),1L,(-9L),1L,1L,(-9L),1L},{1L,1L,(-9L),1L,(-9L),1L,1L,(-9L)}}};
                int32_t *l_2946[2];
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_2946[i] = &l_2601[8];
                for (g_267 = (-3); (g_267 <= 20); ++g_267)
                { /* block id: 1377 */
                    uint64_t l_2928 = 0x95D32886362ACA6BLL;
                    int64_t ****l_2941 = &l_2940;
                    int32_t l_2944 = 1L;
                    l_2944 = (safe_mod_func_int16_t_s_s((safe_lshift_func_uint64_t_u_s(((safe_rshift_func_uint32_t_u_u(((((safe_mul_func_uint16_t_u_u((safe_mul_func_uint64_t_u_u(l_2928, ((p_23 , ((safe_lshift_func_uint8_t_u_u(p_23, 5)) ^ ((p_25.f0 = p_26) ^ (g_201[0][1][7] <= (g_179 = (safe_rshift_func_int16_t_s_s(l_2933, 7))))))) >= ((*g_1878) = ((safe_div_func_int64_t_s_s(((safe_div_func_int64_t_s_s((safe_sub_func_uint64_t_u_u((p_24 > (((((((*l_2941) = l_2940) == (g_2943[0] = l_2942[1][2])) > p_23) || (-1L)) >= 255UL) && 0x347EL)), p_26)), 6L)) <= 0UL), 0x45D2294A9F835875LL)) != (****g_2007)))))), 1UL)) > (*l_2742)) & 0xD209L) , 4294967295UL), 3)) , p_23), l_2933)), (*g_424)));
                }
                l_2950++;
                return p_24;
            }
            else
            { /* block id: 1387 */
                uint16_t *l_2957 = &l_2817;
                uint64_t *l_2964[4] = {&g_2202,&g_2202,&g_2202,&g_2202};
                uint32_t **l_2968 = (void*)0;
                uint32_t ***l_2967 = &l_2968;
                int32_t l_2969 = 0xB4DF04DCL;
                int32_t *l_2970 = &l_2782[4][4];
                int i;
                if ((safe_rshift_func_int32_t_s_s((safe_lshift_func_uint64_t_u_u(((p_23 != (((*l_2957) ^= (*l_2742)) == (safe_sub_func_int64_t_s_s((safe_sub_func_int16_t_s_s(0x0FB3L, ((void*)0 != &l_2753[0]))), ((((safe_lshift_func_int64_t_s_u(((*l_2742) > ((void*)0 != l_2964[2])), 50)) , (((safe_div_func_int64_t_s_s(p_26, p_24)) & p_25.f0) , &g_2028[2])) != l_2967) & (*l_2742)))))) ^ (*g_1878)), l_2969)), 28)))
                { /* block id: 1389 */
                    (*l_2353) = (-1L);
                }
                else
                { /* block id: 1391 */
                    uint32_t l_2974[4][7] = {{18446744073709551609UL,0UL,18446744073709551609UL,0UL,18446744073709551609UL,0UL,18446744073709551609UL},{0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L},{18446744073709551609UL,0UL,18446744073709551609UL,0UL,18446744073709551609UL,0UL,18446744073709551609UL},{0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L,0xBFEA1797L}};
                    uint64_t ***l_2981 = (void*)0;
                    int16_t *l_2997 = &l_2595;
                    int i, j;
                    (**l_2548) = (l_2970 = &l_2969);
                    if (l_2595)
                        goto lbl_2998;
lbl_2998:
                    (*l_2353) ^= (safe_sub_func_int64_t_s_s((safe_unary_minus_func_int16_t_s(l_2974[0][3])), ((safe_mod_func_int16_t_s_s((safe_mod_func_int16_t_s_s((*l_2742), (safe_mod_func_int64_t_s_s(((l_2982 = l_2753[4]) != &l_2964[2]), (safe_add_func_int32_t_s_s((-4L), ((safe_add_func_uint8_t_u_u((((((safe_add_func_uint8_t_u_u(((safe_add_func_int64_t_s_s((safe_div_func_uint16_t_u_u(0x69ACL, (safe_div_func_uint8_t_u_u(((void*)0 != &l_2879), (safe_mul_func_int64_t_s_s((((*l_2997) = ((*g_513) = ((p_25 , 0x7C79L) | (-7L)))) , p_25.f0), 0x3BC0D6B72D1B8F33LL)))))), (-1L))) < p_24), p_26)) != (**g_631)) <= 0xB6D4L) & 0x5DL) && p_23), p_25.f0)) || 0x1B66L))))))), p_23)) , l_2974[0][3])));
                    for (l_2948 = 1; (l_2948 <= 4); l_2948 += 1)
                    { /* block id: 1401 */
                        (*l_2970) = (p_26 | p_24);
                        return p_26;
                    }
                    (*l_2970) ^= 0xACBD6E14L;
                }
                for (l_2599 = 23; (l_2599 <= (-28)); l_2599--)
                { /* block id: 1409 */
                    const uint64_t *l_3017 = &l_2568[0][8][3];
                    const uint64_t **l_3016 = &l_3017;
                    int32_t l_3022 = 0x919740EDL;
                    for (g_179 = (-15); (g_179 > 12); g_179++)
                    { /* block id: 1412 */
                        (**l_2548) = &l_2782[4][9];
                    }
                    for (g_267 = (-24); (g_267 == 43); g_267 = safe_add_func_int8_t_s_s(g_267, 4))
                    { /* block id: 1417 */
                        int32_t *l_3015 = &l_2598;
                        (*l_2353) &= (((safe_lshift_func_uint16_t_u_u(((4294967286UL && (safe_lshift_func_uint8_t_u_s(((****g_2082) = 0x63L), 1))) >= ((safe_div_func_int64_t_s_s((safe_rshift_func_int64_t_s_s((safe_lshift_func_int16_t_s_u((((l_3015 != (void*)0) ^ 0L) == (((*l_3015) = ((void*)0 == l_3016)) , (-2L))), 11)), 45)), ((safe_mod_func_uint32_t_u_u((((safe_rshift_func_int64_t_s_s(((((*g_1878) |= ((((*l_2970) , l_2948) >= p_23) != 0x70FFL)) == p_23) != p_23), 30)) , 0xD8366146L) != p_25.f0), p_25.f0)) , p_23))) && (**g_2578))), l_3022)) , (void*)0) != l_2531[3][4]);
                        (*l_2353) ^= (safe_add_func_int32_t_s_s((&g_362 == (((&p_24 == &p_24) ^ ((safe_rshift_func_uint32_t_u_s((1UL | (((safe_sub_func_int16_t_s_s((0xEB6CAE2E157B32FALL != p_26), ((*l_2957) = ((*l_3015) & p_26)))) , (safe_div_func_int32_t_s_s(p_24, 0xB5C5BC8AL))) , g_3031)), p_26)) >= (-6L))) , &g_362)), (*l_2742)));
                    }
                }
            }
lbl_3121:
            (*l_2742) = (((((safe_mod_func_int64_t_s_s((*l_2742), 2L)) , (void*)0) != &l_2896) < (((***g_2008) |= l_2782[0][1]) == ((*g_1878) = (safe_sub_func_int64_t_s_s((l_2896 == (((g_635 || 4294967295UL) > (l_2753[0] != l_2753[0])) , (*l_2742))), 7L))))) , (*g_143));
            for (l_2906 = 0; (l_2906 <= 4); l_2906 += 1)
            { /* block id: 1432 */
                uint16_t l_3041 = 0xA024L;
                int64_t * const **l_3132 = &l_2584[0];
                int8_t l_3144 = 3L;
                int32_t l_3169[7] = {0L,(-4L),0L,0L,(-4L),0L,0L};
                int i;
                for (g_202 = 0; (g_202 <= 5); g_202 += 1)
                { /* block id: 1435 */
                    uint32_t *l_3047 = (void*)0;
                    uint32_t *l_3048 = &l_2602;
                    uint32_t **l_3064 = (void*)0;
                    int32_t l_3076 = 0x036A96B7L;
                    int32_t l_3077 = 1L;
                    int i, j;
                    if (l_2405[(l_2906 + 1)])
                        break;
                    if ((((((*g_218) = p_25) , (safe_lshift_func_int16_t_s_u((0xDEA9L < p_23), 2))) , (((safe_lshift_func_int64_t_s_s(p_23, ((~l_2405[(l_2906 + 1)]) < (((((l_3041 != ((l_2782[3][3] = ((safe_div_func_int64_t_s_s((((safe_sub_func_int64_t_s_s(((***l_2583) = ((((*l_3048) = ((void*)0 == g_3046)) , ((safe_mul_func_int8_t_s_s(0x4EL, (*g_1878))) || (*l_2742))) != (**g_248))), 0x4B4478C416505931LL)) & (-6L)) , 0x8AFCADC8F2BDDED7LL), l_2405[(l_2906 + 1)])) >= 18446744073709551615UL)) , 246UL)) <= p_23) && (*l_2742)) && 1UL) > p_26)))) && p_23) ^ l_3041)) , (-1L)))
                    { /* block id: 1441 */
                        int32_t ** const *l_3058 = &g_1157[1];
                        int32_t ** const **l_3057 = &l_3058;
                        int32_t ** const ** const *l_3056[7];
                        uint32_t ***l_3067 = &l_2765;
                        int i;
                        for (i = 0; i < 7; i++)
                            l_3056[i] = &l_3057;
                        l_2782[4][2] ^= ((p_23 >= ((safe_unary_minus_func_uint64_t_u((((*l_2353) = ((*l_2742) ^= ((safe_rshift_func_int64_t_s_s(0xAAF8B456242FBA06LL, (safe_add_func_int8_t_s_s(p_25.f0, ((g_3059 = l_3056[2]) != &g_2460))))) & (0xE065L != (p_26 <= (safe_add_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((((*l_3067) = (g_3065 = l_3064)) != l_3068[0][5]), p_26)), (*g_1878)))))))) , l_3041))) , 0UL)) || p_25.f0);
                        return (*l_2742);
                    }
                    else
                    { /* block id: 1449 */
                        int32_t *l_3069 = &g_197[0];
                        int32_t *l_3070 = &l_2601[6];
                        int32_t *l_3071 = &g_197[0];
                        int32_t *l_3072 = &l_2322;
                        int32_t *l_3073 = &l_2325[0][0];
                        int32_t *l_3074 = &l_2325[6][0];
                        int32_t *l_3075[10] = {&l_2601[9],&l_2601[9],(void*)0,&l_2601[9],&l_2601[9],(void*)0,&l_2601[9],&l_2601[9],(void*)0,&l_2601[9]};
                        int i;
                        --l_3078[7];
                        if ((*l_2742))
                            break;
                        if ((*l_2742))
                            continue;
                    }
                }
                if ((safe_sub_func_uint32_t_u_u((safe_div_func_uint64_t_u_u(((**l_2982)--), (((((safe_div_func_uint32_t_u_u(4294967292UL, (((safe_rshift_func_uint64_t_u_u((p_23 < (+(safe_mod_func_uint64_t_u_u((safe_mul_func_int64_t_s_s(((safe_mul_func_uint32_t_u_u((safe_mul_func_uint64_t_u_u((safe_div_func_int8_t_s_s(((((!(((void*)0 == l_3103[8][1]) , ((((safe_lshift_func_uint64_t_u_u((((((safe_mod_func_uint32_t_u_u((((safe_sub_func_int8_t_s_s((-8L), (safe_mod_func_uint64_t_u_u((safe_add_func_uint64_t_u_u((safe_mod_func_int64_t_s_s((safe_lshift_func_uint8_t_u_u(((((safe_mod_func_int8_t_s_s(((*g_1878) = (*l_2742)), l_2950)) & (((**l_2737) = (((*l_2353) ^= ((&p_24 != &p_24) ^ p_26)) || p_26)) , (***g_2008))) >= p_24) || (*l_2742)), p_24)), 7UL)), p_26)), l_2948)))) >= (*l_2742)) && (*l_2742)), p_26)) , (*g_1096)) ^ p_25.f0) | l_3041) & 9L), p_25.f0)) || 0x4E34L) , 0xF3EBL) <= 0xD729L))) , 1L) <= l_3041) >= p_26), 0x4EL)), p_24)), (*l_2742))) || l_2950), p_23)), 0xCE277FE1E41DB91ELL)))), l_2782[4][4])) , (*l_2742)) || p_26))) , p_26) <= p_23) | 0x61211B8EB4529A93LL) & (*g_2579)))), p_25.f0)))
                { /* block id: 1459 */
                    if (g_506)
                        goto lbl_3121;
                    for (g_28.f0 = 6; (g_28.f0 >= 0); g_28.f0 -= 1)
                    { /* block id: 1463 */
                        return (*g_1878);
                    }
                }
                else
                { /* block id: 1466 */
                    uint32_t ***l_3143 = &l_2764;
                    int32_t l_3168 = 0L;
                    for (g_2844 = 0; (g_2844 <= 5); g_2844 += 1)
                    { /* block id: 1469 */
                        int64_t * const **l_3133 = &l_2584[0];
                        int64_t ****l_3134[6][8][5] = {{{(void*)0,&g_2943[0],&g_2943[0],&g_2943[0],(void*)0},{&l_2940,&g_2943[0],&l_2942[1][2],&l_2942[1][2],&l_2942[1][1]},{&l_2942[1][2],(void*)0,(void*)0,&l_2942[1][2],&g_2943[0]},{&l_2940,&l_2940,(void*)0,(void*)0,&l_2940},{(void*)0,(void*)0,&l_2940,&g_2943[0],&l_2940},{&l_2940,(void*)0,&l_2940,(void*)0,(void*)0},{&l_2940,(void*)0,&g_2943[0],&l_2942[1][2],(void*)0},{&l_2942[1][2],&l_2942[1][2],&l_2942[1][1],&l_2942[1][2],&l_2942[1][2]}},{{&g_2943[0],(void*)0,(void*)0,&g_2943[0],&g_2943[0]},{&l_2942[1][2],(void*)0,&l_2942[1][2],&l_2940,&l_2942[1][2]},{&g_2943[0],(void*)0,&g_2943[0],(void*)0,&g_2943[0]},{&g_2943[0],&l_2940,&l_2940,&l_2942[1][2],&l_2942[1][2]},{&g_2943[0],(void*)0,&l_2940,&l_2940,(void*)0},{&l_2942[1][2],&g_2943[0],&l_2940,&l_2942[1][2],(void*)0},{(void*)0,&g_2943[0],&g_2943[0],&g_2943[0],&l_2940},{&g_2943[0],&g_2943[0],&l_2942[1][2],&g_2943[0],&l_2940}},{{(void*)0,&l_2940,(void*)0,&g_2943[0],&g_2943[0]},{&l_2942[1][2],(void*)0,&l_2942[1][1],(void*)0,&l_2942[1][1]},{&g_2943[0],&g_2943[0],&g_2943[0],&g_2943[0],(void*)0},{&g_2943[0],&l_2942[1][2],&l_2940,&g_2943[0],&l_2942[1][2]},{&g_2943[0],&g_2943[0],&l_2940,&g_2943[0],&g_2943[0]},{&l_2942[1][2],&l_2942[1][2],&l_2942[1][1],&l_2940,&l_2940},{(void*)0,&g_2943[0],&l_2942[1][2],(void*)0,(void*)0},{&l_2942[1][2],(void*)0,&l_2942[1][2],&g_2943[0],&l_2940}},{{&g_2943[0],(void*)0,&g_2943[0],&g_2943[0],&l_2940},{&l_2940,&g_2943[0],&l_2942[1][2],&g_2943[0],&g_2943[0]},{&l_2942[1][2],(void*)0,&g_2943[0],&l_2940,&l_2940},{&l_2942[1][2],&l_2940,&l_2942[1][2],(void*)0,&g_2943[0]},{&g_2943[0],&l_2942[1][2],&l_2942[1][2],&g_2943[0],(void*)0},{&l_2942[1][2],&g_2943[0],&l_2942[1][1],&l_2942[1][2],&l_2940},{&l_2942[1][2],&g_2943[0],&l_2940,&g_2943[0],&l_2940},{&l_2940,&l_2942[1][2],&l_2940,&l_2942[1][2],&l_2942[1][1]}},{{&g_2943[0],&g_2943[0],(void*)0,&g_2943[0],&l_2942[1][2]},{&l_2942[1][2],(void*)0,&g_2943[0],(void*)0,&l_2942[1][2]},{(void*)0,&g_2943[0],&l_2940,&l_2940,&g_2943[0]},{&l_2942[0][1],&l_2942[1][2],&g_2943[0],&g_2943[0],&l_2942[1][2]},{&l_2940,&g_2943[0],&l_2940,&g_2943[0],&g_2943[0]},{&l_2942[1][2],&g_2943[0],&l_2940,&g_2943[0],&l_2942[1][2]},{&g_2943[0],&l_2942[1][2],(void*)0,(void*)0,&l_2942[1][2]},{&g_2943[0],&l_2940,&l_2940,&l_2940,&l_2942[1][1]}},{{&g_2943[0],(void*)0,&l_2940,(void*)0,&l_2940},{&l_2940,&g_2943[0],&g_2943[0],(void*)0,&l_2940},{&g_2943[0],(void*)0,&l_2940,(void*)0,(void*)0},{&g_2943[0],(void*)0,&g_2943[0],&l_2942[1][2],&g_2943[0]},{&g_2943[0],&g_2943[0],(void*)0,(void*)0,&l_2940},{&l_2942[1][2],&g_2943[0],&l_2940,(void*)0,&g_2943[0]},{&l_2940,(void*)0,&l_2940,(void*)0,&l_2940},{&l_2942[0][1],&g_2943[0],&l_2942[1][1],&l_2940,&l_2940}}};
                        int i, j, k;
                        (*l_2742) ^= (&g_2460 == &g_2460);
                        (*l_2742) = (safe_add_func_uint16_t_u_u((safe_add_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(0x55L, (safe_sub_func_int8_t_s_s((((safe_rshift_func_int16_t_s_u((((l_3133 = (p_26 , l_3132)) == (g_2943[0] = (void*)0)) < (safe_add_func_uint8_t_u_u(((*l_2353) && (((p_25.f0 || (((****g_2007) , (*g_234)) != ((safe_div_func_int8_t_s_s((safe_rshift_func_int32_t_s_u(p_24, 29)), 0x5BL)) , &l_2601[2]))) , p_24) >= p_25.f0)), p_26))), g_811.f0)) & g_335[5]) , 0x8AL), 0xC9L)))), g_28.f0)), 65526UL));
                        (*l_2742) = (safe_add_func_uint8_t_u_u((((void*)0 == l_3143) & l_3144), 0x1EL));
                    }
                    l_3168 = ((safe_add_func_uint64_t_u_u((safe_sub_func_int16_t_s_s((l_3041 && (((safe_rshift_func_int16_t_s_u((*g_513), 15)) <= (((safe_mul_func_int16_t_s_s((~(~(+(*l_2742)))), 0x90F8L)) , (safe_lshift_func_int8_t_s_s((safe_add_func_uint8_t_u_u(((safe_mod_func_int16_t_s_s(((((void*)0 != (*g_2581)) , 2L) != (p_25.f0 | ((safe_mod_func_uint64_t_u_u((safe_add_func_int64_t_s_s((safe_add_func_int8_t_s_s((0x2573C770ED1022EFLL == p_23), (*l_2742))), 0x70C166E38AAE52DELL)), (-8L))) ^ p_24))), l_3168)) <= 0L), 0xADL)), 3))) || (**g_2009))) , 0x0E307ADBL)), 65530UL)), 0x98B31FA99F159414LL)) | p_26);
                    (**g_2461) = (void*)0;
                }
                l_3169[6] |= ((*l_2353) = (-1L));
                for (l_2947 = 0; (l_2947 <= 4); l_2947 += 1)
                { /* block id: 1483 */
                    for (p_26 = 0; (p_26 <= 1); p_26 += 1)
                    { /* block id: 1486 */
                        int i, j;
                        return l_2325[(l_2906 + 1)][p_26];
                    }
                }
                if (l_2686)
                    goto lbl_3170;
            }
        }
    }
    l_3194++;
    return (*l_3175);
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_28 g_65 g_585 g_197 g_122 g_248 g_249 g_82 g_424 g_425 g_213 g_296 g_121 g_267 g_179 g_436 g_101 g_102 g_622 g_143 g_631 g_506 g_233 g_234 g_235 g_513 g_91 g_268 g_335 g_186 g_632 g_521 g_522 g_202 g_600 g_28.f0 g_887 g_888 g_201 g_119 g_1010 g_217 g_218 g_1038 g_811.f0 g_1011 g_635 g_1016 g_1017 g_1095 g_890 g_889 g_1878 g_1879 g_1971 g_2037 g_2007 g_2008 g_2009 g_1096 g_1097 g_2082 g_2010 g_1808 g_241 g_2081 g_2032 g_2202 g_1300
 * writes: g_65 g_291 g_296 g_600 g_122 g_121 g_267 g_179 g_248 g_436 g_197 g_102 g_632 g_506 g_91 g_82 g_119 g_213 g_202 g_635 g_887 g_201 g_1011 g_1014 g_1041 g_811.f0 g_1752 g_1808 g_1929 g_1117 g_1971 g_1484 g_1879 g_1158 g_2009 g_2032 g_2202
 */
static uint64_t  func_29(int16_t  p_30)
{ /* block id: 1 */
    union U0 *l_33 = (void*)0;
    union U0 **l_32[3][3][2] = {{{&l_33,&l_33},{&l_33,&l_33},{&l_33,&l_33}},{{&l_33,&l_33},{&l_33,&l_33},{&l_33,&l_33}},{{&l_33,&l_33},{&l_33,&l_33},{&l_33,&l_33}}};
    union U0 *l_34 = (void*)0;
    int32_t l_41 = 0x3846F263L;
    int8_t *l_42[8];
    int32_t l_43 = 1L;
    int32_t *l_2271[10] = {&g_1931,&g_1931,&g_1931,&g_1931,&g_1931,&g_1931,&g_1931,&g_1931,&g_1931,&g_1931};
    int32_t l_2272 = 0xD916274DL;
    int32_t l_2273 = (-2L);
    uint32_t l_2274 = 0x02E9E0F9L;
    int32_t l_2285 = 0xBA9A64B0L;
    const union U0 *l_2286 = &g_28;
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_42[i] = (void*)0;
    l_34 = (void*)0;
    l_2285 |= ((g_6 | (func_35(((safe_rshift_func_uint8_t_u_u(((safe_div_func_int16_t_s_s((((*g_2010) = (((l_43 ^= l_41) == (safe_mul_func_uint8_t_u_u((l_2274 = (p_30 , (safe_mul_func_uint64_t_u_u((l_2273 = (((safe_lshift_func_uint32_t_u_u(((p_30 >= (((func_50(p_30, l_41) ^ (safe_sub_func_int8_t_s_s(((l_2272 = (safe_rshift_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u(((safe_sub_func_int32_t_s_s(((safe_rshift_func_int16_t_s_s((-1L), 14)) ^ (safe_mul_func_int16_t_s_s((-1L), 0x17C9L))), l_41)) & 0xACL), g_186[1][5])) && l_41), 4))) , 0x2AL), 0x9FL))) >= l_41) ^ p_30)) < l_41), 28)) , l_41) , l_41)), l_41)))), l_41))) , 0xCFL)) || 0x59L), 2UL)) || 0xFEC5BB2DA300D49ELL), p_30)) , (*g_217))) & p_30)) , 0L);
    l_2286 = l_2286;
    return l_2274;
}


/* ------------------------------------------ */
/* 
 * reads : g_1096 g_1097
 * writes:
 */
static uint64_t  func_35(union U0 * p_36)
{ /* block id: 1075 */
    int32_t *l_2275 = &g_197[3];
    int32_t *l_2276 = &g_197[1];
    int32_t *l_2277 = &g_197[1];
    int32_t *l_2278 = &g_65;
    int32_t *l_2279[3][8][8] = {{{&g_6,&g_197[3],&g_197[3],&g_65,&g_197[3],&g_197[1],&g_197[1],&g_197[3]},{&g_197[3],&g_197[3],&g_197[3],&g_197[3],&g_6,&g_197[3],&g_65,&g_197[3]},{&g_197[0],&g_197[3],&g_197[3],&g_197[3],&g_197[3],(void*)0,&g_6,(void*)0},{(void*)0,&g_197[3],(void*)0,&g_197[3],&g_122,&g_197[3],&g_197[3],&g_6},{&g_197[3],&g_197[1],&g_197[2],(void*)0,&g_197[3],(void*)0,&g_197[2],&g_197[1]},{&g_197[0],&g_197[3],&g_197[3],&g_197[3],&g_122,&g_197[3],(void*)0,&g_197[3]},{(void*)0,&g_6,&g_197[3],&g_197[0],&g_197[0],&g_65,(void*)0,&g_197[3]},{&g_197[3],&g_197[0],&g_197[3],&g_197[3],&g_6,&g_65,&g_197[2],&g_197[2]}},{{&g_6,&g_65,&g_197[2],&g_197[2],&g_65,&g_6,&g_197[3],&g_197[3]},{&g_197[1],&g_6,&g_197[3],(void*)0,&g_65,&g_197[0],&g_197[0],&g_197[3]},{(void*)0,(void*)0,&g_197[3],(void*)0,&g_197[3],&g_122,&g_197[3],&g_197[3]},{&g_65,&g_197[3],&g_197[1],&g_197[2],(void*)0,&g_197[3],(void*)0,&g_197[2]},{&g_6,&g_197[3],&g_6,&g_197[3],&g_197[3],(void*)0,&g_65,&g_197[3]},{&g_122,(void*)0,&g_6,&g_197[0],&g_197[3],&g_197[2],&g_197[3],&g_197[3]},{&g_122,&g_122,&g_6,&g_197[3],&g_197[3],&g_65,&g_197[3],&g_197[1]},{&g_6,&g_122,&g_122,(void*)0,(void*)0,&g_122,&g_122,&g_6}},{{&g_65,(void*)0,(void*)0,&g_65,&g_197[3],(void*)0,&g_197[1],&g_6},{(void*)0,&g_197[3],&g_122,&g_197[3],&g_65,(void*)0,&g_197[3],&g_6},{&g_197[1],(void*)0,&g_197[3],&g_197[3],&g_65,&g_122,(void*)0,&g_122},{&g_6,&g_122,&g_65,&g_122,&g_6,&g_65,&g_122,(void*)0},{&g_197[3],&g_122,&g_197[3],&g_197[1],&g_197[0],&g_197[2],&g_197[3],&g_122},{(void*)0,(void*)0,&g_197[3],&g_197[3],&g_122,(void*)0,&g_122,&g_197[3]},{&g_197[0],&g_197[3],&g_65,(void*)0,&g_197[3],&g_197[3],(void*)0,&g_65},{&g_197[3],&g_197[3],&g_197[3],&g_122,(void*)0,&g_122,&g_197[3],&g_197[3]}}};
    int16_t l_2280 = 0L;
    int32_t l_2281 = 0xB2718138L;
    uint32_t l_2282 = 0xF3AF71E1L;
    int i, j, k;
    --l_2282;
    return (*g_1096);
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_65 g_585 g_197 g_122 g_248 g_249 g_82 g_424 g_425 g_213 g_296 g_121 g_267 g_179 g_436 g_101 g_102 g_622 g_143 g_631 g_506 g_233 g_234 g_235 g_513 g_91 g_268 g_335 g_186 g_632 g_521 g_522 g_202 g_600 g_28.f0 g_887 g_888 g_201 g_119 g_6 g_1010 g_217 g_218 g_1038 g_811.f0 g_1011 g_635 g_1016 g_1017 g_1095 g_890 g_889 g_1878 g_1879 g_1971 g_2037 g_2007 g_2008 g_2009 g_1096 g_1097 g_2082 g_2010 g_1808 g_241 g_2081 g_2032 g_2202 g_1300
 * writes: g_65 g_291 g_296 g_600 g_122 g_121 g_267 g_179 g_248 g_436 g_197 g_102 g_632 g_506 g_91 g_82 g_119 g_213 g_202 g_635 g_887 g_201 g_1011 g_1014 g_1041 g_811.f0 g_1752 g_1808 g_1929 g_1117 g_1971 g_1484 g_1879 g_1158 g_2009 g_2032 g_2202
 */
static uint16_t  func_50(int32_t  p_51, uint64_t  p_52)
{ /* block id: 4 */
    union U0 *l_63 = (void*)0;
    union U0 *l_64 = &g_28;
    const int32_t l_1871 = 0x7BA766DAL;
    const uint64_t l_1976 = 0UL;
    int32_t *l_1977 = &g_197[3];
    uint8_t ***l_2016 = (void*)0;
    uint8_t ****l_2015 = &l_2016;
    int16_t **l_2030[6] = {&g_513,&g_514,&g_513,&g_513,&g_514,&g_513};
    uint32_t *l_2069[1];
    uint32_t **l_2068 = &l_2069[0];
    uint32_t ***l_2067[10][2] = {{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068},{&l_2068,&l_2068}};
    int16_t l_2139 = 0xB40DL;
    int32_t l_2158 = 0xAF19C2DDL;
    int32_t l_2189 = 0L;
    int32_t l_2190 = 0x1453C650L;
    int32_t l_2191 = (-1L);
    int32_t l_2192 = 0x696C3FCBL;
    int32_t l_2193 = 0x87FC87DDL;
    int32_t l_2194 = 1L;
    int32_t l_2196 = 1L;
    int32_t l_2197 = 4L;
    int32_t l_2198 = 0xFA5C9F4DL;
    int32_t l_2199 = 0xAB7BB5A9L;
    int32_t l_2200[7][4][6] = {{{0x2C1C2250L,0x289E4CB6L,1L,0xFCC0ADB7L,0x7350C920L,0x4ECDD2A8L},{0x9F758FBFL,0x6F58228EL,0xFCC0ADB7L,(-1L),0L,(-1L)},{(-1L),1L,(-2L),(-5L),0x2C1C2250L,0xB57E5F09L},{8L,1L,0L,0xD51CB084L,0x6F58228EL,(-1L)}},{{0xD0EB964FL,8L,9L,8L,0xD0EB964FL,7L},{0x86EAD320L,(-1L),1L,0x4ECDD2A8L,(-1L),0x86EAD320L},{0L,0xB529A95AL,0x9F758FBFL,(-1L),(-8L),0x86EAD320L},{1L,(-1L),1L,9L,0x2C1C2250L,7L}},{{(-8L),0x6F58228EL,9L,0x93241426L,(-4L),(-1L)},{(-1L),(-8L),0L,1L,0xB57E5F09L,0xB57E5F09L},{0x86EAD320L,(-2L),(-2L),0x86EAD320L,0x6F58228EL,(-1L)},{(-1L),0xB529A95AL,0xFCC0ADB7L,8L,(-1L),0x4ECDD2A8L}},{{0x289E4CB6L,0xD0EB964FL,1L,(-5L),(-1L),0x289E4CB6L},{(-2L),0xB529A95AL,0x2AEE427AL,0x93241426L,0x6F58228EL,8L},{1L,(-2L),(-5L),0x2C1C2250L,0xB57E5F09L,7L},{0x9F758FBFL,(-8L),0x2C1C2250L,(-1L),(-4L),(-1L)}},{{0L,0x6F58228EL,0L,1L,0x2C1C2250L,0xFCC0ADB7L},{0x289E4CB6L,(-1L),(-2L),0xD51CB084L,(-8L),0xD0EB964FL},{(-1L),0xB529A95AL,9L,0xD51CB084L,(-1L),1L},{0x289E4CB6L,(-1L),(-5L),1L,0xD0EB964FL,0x289E4CB6L}},{{0L,8L,(-8L),(-1L),0x6F58228EL,0x86EAD320L},{0x9F758FBFL,1L,0x4ECDD2A8L,0x2C1C2250L,0x2C1C2250L,0x4ECDD2A8L},{1L,1L,0x2C1C2250L,0x93241426L,0L,0xD0EB964FL},{(-2L),0x6F58228EL,0L,(-5L),0x7350C920L,0x2C1C2250L}},{{0x289E4CB6L,(-2L),0L,8L,1L,0xD0EB964FL},{(-1L),8L,0x2C1C2250L,0x86EAD320L,(-1L),0x4ECDD2A8L},{0x86EAD320L,(-1L),0x4ECDD2A8L,1L,(-1L),0x86EAD320L},{(-1L),0x289E4CB6L,(-8L),0x93241426L,(-8L),0x289E4CB6L}}};
    int32_t l_2201 = (-1L);
    union U0 **l_2228[9];
    uint32_t l_2231 = 0xB0931BD7L;
    uint8_t l_2235[8] = {0xE2L,0x1AL,0x1AL,0xE2L,0x1AL,0x1AL,0xE2L,0x1AL};
    const uint16_t l_2252 = 4UL;
    uint16_t l_2253[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2069[i] = &g_296;
    for (i = 0; i < 9; i++)
        l_2228[i] = &l_63;
    (*l_1977) = (safe_rshift_func_int16_t_s_u((func_55(g_28, func_60(l_63, l_64), l_63, ((safe_rshift_func_int16_t_s_s((safe_div_func_int32_t_s_s((safe_div_func_uint32_t_u_u(((safe_mul_func_uint32_t_u_u(l_1871, (l_1871 | (safe_lshift_func_int32_t_s_s((safe_mod_func_uint32_t_u_u((safe_div_func_int32_t_s_s(((((void*)0 == &g_1158[4][0]) || p_52) , 0x194CFBFEL), l_1871)), p_52)), p_52))))) || g_335[4]), l_1871)), p_52)), 14)) , g_1878)) != l_1976), p_52));
    for (g_1971 = (-29); (g_1971 <= 1); g_1971++)
    { /* block id: 928 */
        uint8_t l_1993 = 8UL;
        uint8_t ****l_2018 = &l_2016;
        uint8_t ** const **l_2019 = (void*)0;
        union U0 l_2034 = {-1L};
        union U0 ***l_2035 = &g_291[4];
        int64_t *l_2045 = &g_28.f0;
        int64_t ** const l_2044 = &l_2045;
        uint32_t l_2060 = 1UL;
        int32_t l_2071 = 0xEBC2F783L;
        uint32_t * const *l_2137 = &l_2069[0];
        uint32_t * const ** const l_2136 = &l_2137;
        int32_t *l_2187 = &l_2071;
        int32_t *l_2188[7][10][3] = {{{(void*)0,(void*)0,(void*)0},{&l_2071,(void*)0,&g_197[3]},{&l_2071,&g_6,(void*)0},{&g_122,&g_6,&g_197[3]},{&g_122,(void*)0,&g_197[3]},{&g_122,&g_197[3],&g_122},{&l_2158,&g_197[2],&g_197[2]},{(void*)0,&l_2158,&g_6},{&g_197[3],&g_65,&g_65},{&g_197[3],&g_6,&g_6}},{{(void*)0,&l_2071,(void*)0},{&l_2071,(void*)0,&g_122},{&g_197[3],&g_6,(void*)0},{&g_197[3],&g_6,&g_122},{&g_122,&g_6,&g_6},{&g_6,&g_6,(void*)0},{&l_2071,(void*)0,&g_65},{&l_2071,&l_2071,&l_2071},{&l_2071,&g_6,(void*)0},{&l_2158,&g_65,&g_197[2]}},{{&l_2158,&l_2158,(void*)0},{&l_2071,&g_197[2],&g_197[3]},{&g_6,&g_197[3],&l_2071},{&g_65,(void*)0,&g_197[3]},{&g_122,&g_6,&l_2071},{(void*)0,&l_2071,&g_197[3]},{&g_197[2],&g_197[3],(void*)0},{&g_6,(void*)0,&g_197[2]},{&g_122,&l_2158,(void*)0},{&g_6,&g_122,&l_2071}},{{(void*)0,&l_2071,&g_65},{(void*)0,&l_2158,(void*)0},{(void*)0,&g_197[3],&g_6},{&g_197[3],&l_2158,&g_122},{&g_197[3],&g_122,(void*)0},{(void*)0,(void*)0,&g_122},{(void*)0,&g_197[2],(void*)0},{(void*)0,&l_2158,&g_6},{&g_6,&g_122,&g_65},{&g_122,&g_6,&g_6}},{{&g_6,&g_65,&g_197[2]},{&g_197[2],&l_2071,&g_122},{(void*)0,(void*)0,&g_197[3]},{&g_122,&g_197[3],&g_197[3]},{&g_65,(void*)0,&g_122},{&g_6,&l_2071,&g_197[3]},{&l_2071,&g_65,&g_197[3]},{&l_2158,&g_6,&l_2158},{&l_2158,&g_122,&l_2071},{&l_2071,&l_2158,&g_122}},{{&l_2071,&g_197[2],&g_6},{&l_2071,(void*)0,&g_6},{&g_6,&g_122,&g_65},{&g_122,&l_2158,&g_65},{&g_197[3],&g_197[3],&g_6},{&g_197[3],&l_2158,&g_6},{&l_2071,&l_2071,&g_122},{(void*)0,&g_122,&l_2071},{&g_197[3],&l_2158,&l_2158},{&g_197[3],(void*)0,&g_197[3]}},{{(void*)0,&g_197[3],&g_197[3]},{&l_2158,&l_2071,&g_122},{&g_122,&g_6,&g_197[3]},{&g_122,(void*)0,&g_197[3]},{&g_122,&g_197[3],&g_122},{&l_2158,&g_197[2],&g_197[2]},{(void*)0,&l_2158,&g_197[2]},{&g_197[3],&g_197[3],(void*)0},{&g_6,&g_197[2],&l_2071},{&g_197[3],&l_2158,(void*)0}}};
        int64_t l_2195 = 1L;
        int i, j, k;
        for (g_91 = 18; (g_91 != 12); --g_91)
        { /* block id: 931 */
            uint32_t l_1984[4][6] = {{9UL,0UL,0x3B432E1DL,18446744073709551608UL,0x3C36633EL,18446744073709551608UL},{0x175D7F31L,1UL,0x175D7F31L,0x5A189D1AL,0x3C36633EL,18446744073709551611UL},{0x3B432E1DL,0UL,9UL,0x175D7F31L,0x175D7F31L,9UL},{18446744073709551614UL,18446744073709551614UL,0x452FC75BL,0x175D7F31L,0UL,0x5A189D1AL}};
            int32_t *l_1997 = &g_1931;
            union U0 l_1998 = {0xC5FCFD77E3760B06LL};
            uint8_t **l_2046 = &g_2010;
            union U0 **l_2057 = &l_63;
            uint32_t l_2111 = 0xD62F38C1L;
            const int64_t ***l_2123[4] = {&g_1753,&g_1753,&g_1753,&g_1753};
            uint32_t ***l_2138 = (void*)0;
            int32_t l_2148 = (-10L);
            int i, j;
            for (p_51 = 0; (p_51 < (-30)); --p_51)
            { /* block id: 934 */
                union U0 l_1999 = {0xAC1065D03697B313LL};
                int32_t l_2004 = 0xA1E8837AL;
                uint8_t * const *l_2006 = (void*)0;
                uint8_t * const **l_2005 = &l_2006;
                const int16_t **l_2014 = &g_424;
                int32_t *l_2033[7] = {&g_6,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6};
                int i;
                (*l_1977) = l_1984[2][5];
                for (g_811.f0 = 0; (g_811.f0 <= 1); g_811.f0++)
                { /* block id: 938 */
                    union U0 l_2011 = {0xFD400AA0D269CB2CLL};
                    uint8_t *****l_2017[6][6][2] = {{{&l_2015,&l_2015},{(void*)0,&l_2015},{&l_2015,(void*)0},{&l_2015,(void*)0},{&l_2015,&l_2015},{(void*)0,&l_2015}},{{&l_2015,&l_2015},{&l_2015,(void*)0},{(void*)0,&l_2015},{&l_2015,(void*)0},{&l_2015,&l_2015},{(void*)0,(void*)0}},{{&l_2015,&l_2015},{&l_2015,&l_2015},{(void*)0,&l_2015},{&l_2015,(void*)0},{&l_2015,(void*)0},{&l_2015,&l_2015}},{{(void*)0,&l_2015},{&l_2015,&l_2015},{&l_2015,(void*)0},{(void*)0,&l_2015},{&l_2015,(void*)0},{&l_2015,&l_2015}},{{(void*)0,(void*)0},{&l_2015,&l_2015},{&l_2015,&l_2015},{(void*)0,&l_2015},{&l_2015,(void*)0},{&l_2015,(void*)0}},{{&l_2015,&l_2015},{(void*)0,&l_2015},{&l_2015,&l_2015},{&l_2015,(void*)0},{(void*)0,&l_2015},{&l_2015,(void*)0}}};
                    uint8_t ** const ***l_2020 = (void*)0;
                    uint8_t ** const ***l_2021 = &l_2019;
                    uint8_t ** const **l_2023 = (void*)0;
                    uint8_t ** const ***l_2022 = &l_2023;
                    int i, j, k;
                }
                if ((*l_1977))
                    continue;
                (*g_2037) = l_2035;
            }
            (*l_1977) = p_51;
            if (((safe_sub_func_int8_t_s_s((((18446744073709551615UL && 0xDC053D4B50110E43LL) < (safe_sub_func_int8_t_s_s(((*g_1878) = (safe_lshift_func_int64_t_s_s(((((l_2044 == &g_521) , l_2046) != (**g_2007)) == ((*l_1977) , (*l_1977))), p_51))), l_1993))) != p_51), 255UL)) && (*g_1016)))
            { /* block id: 968 */
                const union U0 *l_2056 = (void*)0;
                const union U0 **l_2055 = &l_2056;
                uint32_t *l_2070 = &g_119;
                uint32_t ***l_2106 = (void*)0;
                int32_t l_2110 = 0x4035C387L;
                int32_t **l_2120 = &g_1158[4][0];
                l_2071 &= ((*g_1096) && (safe_add_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(65531UL, (safe_mul_func_int8_t_s_s(6L, (safe_add_func_int8_t_s_s((l_2055 == l_2057), (safe_rshift_func_uint64_t_u_s(l_2060, p_51)))))))), (safe_div_func_uint32_t_u_u(((*l_2070) = (safe_lshift_func_uint16_t_u_u(0xD409L, (safe_sub_func_uint32_t_u_u((l_2067[1][1] != (void*)0), 1UL))))), p_52)))));
                for (l_1993 = 0; (l_1993 <= 1); l_1993 += 1)
                { /* block id: 973 */
                    uint16_t l_2109 = 0xDB99L;
                    int32_t *l_2113 = (void*)0;
                    int32_t **l_2116[3];
                    int16_t **l_2119 = &g_514;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_2116[i] = (void*)0;
                }
                (*l_1977) = (((&l_1871 == ((*l_2120) = &l_2071)) <= (safe_sub_func_uint16_t_u_u((((((*l_64) , &l_2044) == l_2123[3]) ^ (safe_rshift_func_int32_t_s_s(((((safe_mul_func_uint32_t_u_u(((safe_div_func_uint64_t_u_u((*g_1096), ((safe_lshift_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u((((safe_add_func_int64_t_s_s(((l_2136 != l_2138) && ((0xC4L && (****g_2082)) , 5L)), 18446744073709551608UL)) > (*l_1977)) > p_52), l_2060)) >= (-1L)), p_51)) & p_52))) || p_52), 0xD555E542L)) | (*l_1977)) && g_1879[1][2][0]) , l_2139), 28))) & 0x7CL), p_51))) ^ 65535UL);
            }
            else
            { /* block id: 996 */
                uint64_t l_2147 = 0UL;
                for (g_267 = 0; (g_267 <= 5); g_267 += 1)
                { /* block id: 999 */
                    uint32_t *l_2157 = &g_887[1][2][0];
                    int i;
                    l_2158 &= (safe_div_func_uint16_t_u_u(((((*l_1977) <= ((*l_2157) ^= (safe_mod_func_int64_t_s_s(((l_2148 |= ((!(p_51 > (safe_add_func_int64_t_s_s(((*g_1878) && l_2071), l_2147)))) , ((void*)0 != &g_1845))) , (1UL < (safe_lshift_func_int32_t_s_s(((((safe_div_func_int64_t_s_s(((safe_mod_func_uint64_t_u_u((safe_mul_func_uint64_t_u_u(((&g_1879[2][4][0] == (void*)0) | g_1808), l_1984[2][5])), l_2147)) , l_2060), p_52)) ^ (*l_1977)) > p_51) && l_2147), p_51)))), 0xFB65385D83B5C626LL)))) >= 0x67AF2D74607BE46DLL) , 0UL), g_335[5]));
                    if (((*l_1977) = p_51))
                    { /* block id: 1004 */
                        if (l_2111)
                            break;
                        if (p_52)
                            continue;
                        if (p_52)
                            continue;
                    }
                    else
                    { /* block id: 1008 */
                        int i;
                        l_64 = l_63;
                        return g_241[1];
                    }
                    for (p_52 = 1; (p_52 <= 5); p_52 += 1)
                    { /* block id: 1014 */
                        (*l_1977) = 0L;
                    }
                }
                (*l_1977) = p_51;
            }
        }
        for (l_2158 = 0; (l_2158 <= 7); l_2158 += 1)
        { /* block id: 1023 */
            uint32_t l_2159 = 18446744073709551614UL;
            int64_t **l_2178 = &l_2045;
            int64_t ***l_2177[2];
            int32_t l_2179 = 0x101D3CEDL;
            uint64_t ***l_2182 = (void*)0;
            uint64_t ****l_2181 = &l_2182;
            uint64_t *****l_2180 = &l_2181;
            int i;
            for (i = 0; i < 2; i++)
                l_2177[i] = &l_2178;
            if (p_51)
            { /* block id: 1024 */
                uint16_t l_2160[3][1];
                int i, j;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_2160[i][j] = 0x7C4AL;
                }
                for (g_296 = 0; (g_296 <= 3); g_296 += 1)
                { /* block id: 1027 */
                    return l_2159;
                }
                l_2160[0][0]--;
            }
            else
            { /* block id: 1031 */
                int8_t *l_2183[1];
                uint64_t *l_2184 = &g_2032;
                int32_t l_2185 = 0x202A4BEEL;
                int32_t *l_2186 = &g_65;
                int i;
                for (i = 0; i < 1; i++)
                    l_2183[i] = &g_202;
                (*l_2186) |= (((((safe_mod_func_int8_t_s_s((*g_1878), (safe_div_func_uint32_t_u_u(0x32750C67L, (safe_div_func_uint8_t_u_u((((*l_2184) |= ((safe_sub_func_int8_t_s_s((((**g_248) = p_52) ^ (((***g_2081) = (**g_2007)) != (void*)0)), (++(*g_2010)))) != (l_2071 = (safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s((&g_1753 == (p_51 , l_2177[1])), (g_635 = ((((((l_2179 = p_51) || g_887[1][2][0]) , &l_2159) == (**l_2136)) , l_2180) != (void*)0)))), l_1993))))) != p_51), p_52)))))) != l_2185) != (*l_1977)) < g_6) != (-5L));
                return l_2159;
            }
        }
        g_2202--;
    }
    for (g_436 = 1; (g_436 <= 5); g_436 += 1)
    { /* block id: 1047 */
        uint64_t l_2216[5] = {1UL,1UL,1UL,1UL,1UL};
        uint8_t ****l_2217 = &l_2016;
        union U0 ***l_2220 = &g_291[2];
        union U0 ***l_2221 = &g_291[2];
        union U0 ***l_2222 = &g_291[2];
        union U0 ***l_2223 = &g_291[4];
        union U0 ***l_2224 = &g_291[2];
        union U0 ***l_2225 = &g_291[1];
        union U0 ***l_2226 = &g_291[4];
        union U0 ***l_2227[1][9] = {{&g_291[2],&g_291[3],&g_291[2],&g_291[3],&g_291[2],&g_291[3],&g_291[2],&g_291[3],&g_291[2]}};
        int32_t *l_2230[5][2][3] = {{{(void*)0,(void*)0,&l_2189},{&g_122,&l_2200[3][0][5],&l_2192}},{{&g_122,&g_6,(void*)0},{(void*)0,&l_2198,&l_2200[3][0][5]}},{{(void*)0,&g_122,(void*)0},{&l_2193,&g_65,&l_2192}},{{&g_122,&g_65,&l_2189},{&l_2198,&g_122,&l_2201}},{{&l_2200[6][2][5],&l_2198,&l_2198},{&l_2198,&g_6,(void*)0}}};
        int i, j, k;
        if (p_52)
            break;
        l_2231 &= ((*l_1977) ^= (0xAE01L >= ((safe_add_func_uint16_t_u_u((((((safe_mod_func_int16_t_s_s((safe_sub_func_int16_t_s_s((safe_unary_minus_func_uint16_t_u((((safe_add_func_uint8_t_u_u((l_2216[4] | 0L), p_52)) , l_2217) != &l_2016))), (safe_div_func_int32_t_s_s(((*g_1878) >= ((((l_2228[2] = &l_63) != (void*)0) ^ p_52) || p_52)), 0xCEDC406AL)))), p_51)) >= (*g_424)) | l_2216[2]) >= 0xF4L) , 0x85ACL), l_2216[4])) != (**g_2009))));
        if (p_52)
            break;
        return p_51;
    }
    for (g_202 = 12; (g_202 > (-23)); --g_202)
    { /* block id: 1057 */
        int32_t *l_2234[7] = {&g_197[0],&g_197[0],&g_197[0],&g_197[0],&g_197[0],&g_197[0],&g_197[0]};
        int64_t *l_2238[6] = {&g_213,&g_213,&g_213,&g_213,&g_213,&g_213};
        uint16_t *l_2251 = &g_600;
        int i;
        --l_2235[0];
        if ((((void*)0 == l_2238[2]) , (((safe_div_func_int64_t_s_s((safe_rshift_func_uint8_t_u_u(((safe_div_func_int8_t_s_s(p_51, (((**g_248) = (l_2234[2] == (*l_2068))) , p_51))) < (safe_mul_func_int64_t_s_s((safe_mod_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_u(((*l_2251) = p_51), 13)) , p_51), (*l_1977))), (*l_1977)))), 0)), 18446744073709551615UL)) ^ l_2252) <= l_2253[1])))
        { /* block id: 1061 */
            uint64_t l_2254 = 0x52C827E7DC54FD30LL;
            int64_t *****l_2258 = &g_1845;
            ++l_2254;
            if (p_51)
                continue;
            (*l_1977) = (safe_unary_minus_func_uint32_t_u(((void*)0 != l_2258)));
            if ((*l_1977))
                break;
        }
        else
        { /* block id: 1066 */
            return (*l_1977);
        }
    }
    return g_1300;
}


/* ------------------------------------------ */
/* 
 * reads : g_28.f0 g_143 g_513 g_1878 g_1879 g_197 g_631 g_202 g_82 g_888 g_889 g_890 g_65
 * writes: g_887 g_506 g_122 g_197 g_1808 g_91 g_1929 g_632 g_811.f0 g_65 g_202 g_1117 g_1971
 */
static int8_t  func_55(union U0  p_56, uint64_t  p_57, union U0 * p_58, int8_t * p_59)
{ /* block id: 873 */
    const uint64_t l_1887 = 0x0C5400624D53DC11LL;
    uint32_t *l_1889 = &g_887[1][2][0];
    int64_t *l_1894 = &g_213;
    int64_t **l_1895 = &l_1894;
    int64_t *l_1896 = &g_201[0][2][0];
    int64_t **l_1897 = &l_1896;
    int16_t *l_1898 = &g_1808;
    uint8_t *l_1902 = &g_506;
    union U0 *****l_1913 = (void*)0;
    int32_t *l_1919 = &g_197[3];
    uint32_t l_1920 = 0x71A65997L;
    int16_t l_1926 = 3L;
    uint32_t **l_1928 = &l_1889;
    uint32_t ***l_1927[4][2][7] = {{{&l_1928,&l_1928,&l_1928,&l_1928,&l_1928,&l_1928,&l_1928},{(void*)0,&l_1928,&l_1928,(void*)0,&l_1928,&l_1928,(void*)0}},{{&l_1928,&l_1928,&l_1928,(void*)0,&l_1928,(void*)0,&l_1928},{(void*)0,(void*)0,(void*)0,&l_1928,&l_1928,(void*)0,&l_1928}},{{&l_1928,&l_1928,&l_1928,&l_1928,(void*)0,&l_1928,&l_1928},{(void*)0,&l_1928,(void*)0,(void*)0,&l_1928,(void*)0,&l_1928}},{{(void*)0,&l_1928,&l_1928,&l_1928,&l_1928,&l_1928,&l_1928},{&l_1928,&l_1928,(void*)0,&l_1928,(void*)0,(void*)0,&l_1928}}};
    const int32_t *l_1930 = &g_1931;
    union U0 *l_1934 = &g_1353;
    int i, j, k;
lbl_1932:
    (*g_143) = (safe_div_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((safe_sub_func_int8_t_s_s((((safe_unary_minus_func_uint64_t_u(l_1887)) <= (((g_28.f0 <= ((((*l_1889) = ((!p_56.f0) || l_1887)) || (safe_add_func_int32_t_s_s((((((*l_1895) = l_1894) != ((*l_1897) = l_1896)) , (&g_91 != l_1898)) == ((((safe_mod_func_uint8_t_u_u(((*l_1902) = (safe_unary_minus_func_int16_t_s(((0xBB75A730L && p_56.f0) || 1UL)))), p_56.f0)) > l_1887) | p_57) <= 4294967295UL)), p_57))) , p_56.f0)) == p_56.f0) < l_1887)) == l_1887), l_1887)), (-10L))), l_1887));
    if ((safe_div_func_int16_t_s_s(((*g_513) = ((*l_1898) = ((safe_sub_func_uint32_t_u_u(4294967294UL, (safe_rshift_func_uint8_t_u_s(p_57, 0)))) || (((safe_lshift_func_uint8_t_u_s((safe_unary_minus_func_int64_t_s((l_1887 == 0xDC10L))), 2)) && (((~(&g_888 == (l_1913 = l_1913))) <= p_57) < ((~(((safe_mul_func_int64_t_s_s(1L, ((((*l_1919) = (safe_sub_func_uint64_t_u_u(p_56.f0, l_1887))) ^ p_57) == 0xB11DL))) | 0x6BL) || l_1920)) , 0x33L))) == (-7L))))), p_56.f0)))
    { /* block id: 883 */
        union U0 *l_1933 = &g_28;
        (*l_1919) = (((&p_57 == (((!(((safe_mul_func_uint32_t_u_u(l_1926, (&g_362 != (g_1929 = l_1927[0][0][0])))) < (p_56 , (l_1930 != l_1919))) > (((*g_1878) | p_57) | p_57))) , (*l_1919)) , &p_57)) && g_197[3]) & (*l_1919));
        if (p_57)
            goto lbl_1932;
        l_1934 = l_1933;
    }
    else
    { /* block id: 888 */
        int32_t *l_1937 = (void*)0;
        int32_t *l_1939 = &g_197[3];
        int32_t l_1940 = (-1L);
        int32_t *l_1974[6][8][3] = {{{&g_1931,(void*)0,(void*)0},{&g_1931,&g_1931,&g_1931},{&g_1931,&g_1931,&g_1931},{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931},{(void*)0,(void*)0,(void*)0},{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931}},{{&g_1931,&g_1931,(void*)0},{&g_1931,&g_1931,&g_1931},{(void*)0,(void*)0,(void*)0},{&g_1931,&g_1931,&g_1931},{&g_1931,&g_1931,&g_1931},{&g_1931,(void*)0,(void*)0},{&g_1931,&g_1931,&g_1931},{&g_1931,&g_1931,&g_1931}},{{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931},{(void*)0,(void*)0,(void*)0},{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931},{&g_1931,&g_1931,(void*)0},{&g_1931,&g_1931,&g_1931},{(void*)0,(void*)0,(void*)0}},{{&g_1931,&g_1931,&g_1931},{&g_1931,&g_1931,&g_1931},{&g_1931,(void*)0,(void*)0},{&g_1931,&g_1931,&g_1931},{&g_1931,&g_1931,&g_1931},{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931},{(void*)0,(void*)0,(void*)0}},{{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931},{&g_1931,&g_1931,(void*)0},{&g_1931,&g_1931,&g_1931},{(void*)0,(void*)0,(void*)0},{&g_1931,&g_1931,&g_1931},{&g_1931,&g_1931,&g_1931},{&g_1931,(void*)0,(void*)0}},{{&g_1931,&g_1931,&g_1931},{&g_1931,&g_1931,&g_1931},{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931},{(void*)0,(void*)0,(void*)0},{&g_1931,(void*)0,&g_1931},{&g_1931,(void*)0,&g_1931},{&g_1931,&g_1931,(void*)0}}};
        int32_t **l_1973 = &l_1974[3][2][0];
        int i, j, k;
        for (g_91 = (-28); (g_91 < (-30)); g_91 = safe_sub_func_int64_t_s_s(g_91, 4))
        { /* block id: 891 */
            int32_t **l_1938[8][6][2] = {{{&g_1158[4][0],(void*)0},{&l_1937,&l_1919},{(void*)0,(void*)0},{&g_1158[2][0],&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}},{{&l_1937,&l_1919},{&g_1158[2][0],&g_1158[4][0]},{&g_1158[4][0],&l_1919},{(void*)0,&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}},{{&l_1937,&l_1919},{&g_1158[2][0],&g_1158[4][0]},{&g_1158[4][0],&l_1919},{(void*)0,&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}},{{&l_1937,&l_1919},{&g_1158[2][0],&g_1158[4][0]},{&g_1158[4][0],&l_1919},{(void*)0,&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}},{{&l_1937,&l_1919},{&g_1158[2][0],&g_1158[4][0]},{&g_1158[4][0],&l_1919},{(void*)0,&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}},{{&l_1937,&l_1919},{&g_1158[2][0],&g_1158[4][0]},{&g_1158[4][0],&l_1919},{(void*)0,&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}},{{&l_1937,&l_1919},{&g_1158[2][0],&g_1158[4][0]},{&g_1158[4][0],&l_1919},{(void*)0,&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}},{{&l_1937,&l_1919},{&g_1158[2][0],&g_1158[4][0]},{&g_1158[4][0],&l_1919},{(void*)0,&l_1919},{&g_1158[4][0],&g_1158[4][0]},{&g_1158[2][0],&l_1919}}};
            int32_t *l_1948 = &g_1931;
            int32_t **l_1947 = &l_1948;
            int i, j, k;
            (*g_631) = l_1937;
            l_1939 = (l_1937 = (void*)0);
            for (g_811.f0 = 0; (g_811.f0 <= 1); g_811.f0 += 1)
            { /* block id: 897 */
                return (*p_59);
            }
            for (g_65 = 3; (g_65 >= 0); g_65 -= 1)
            { /* block id: 902 */
                uint32_t l_1941 = 0UL;
                union U0 **l_1968[8] = {&l_1934,&g_218,&l_1934,&g_218,&l_1934,&g_218,&l_1934,&g_218};
                int i;
                --l_1941;
                (*g_631) = &g_197[g_65];
                for (g_202 = 4; (g_202 >= 0); g_202 -= 1)
                { /* block id: 907 */
                    int8_t l_1972 = (-1L);
                    if (((void*)0 == l_1937))
                    { /* block id: 908 */
                        volatile int32_t *** volatile *l_1944 = &g_233;
                        int32_t ***l_1949 = &g_1117;
                        union U0 ***l_1965 = &g_291[3];
                        union U0 ***l_1966 = &g_291[2];
                        union U0 ***l_1967[6] = {&g_291[2],&g_291[2],&g_291[2],&g_291[2],&g_291[2],&g_291[2]};
                        uint64_t *l_1969 = (void*)0;
                        uint64_t *l_1970 = &g_1971;
                        int32_t ***l_1975 = &l_1973;
                        int i, j, k;
                        l_1944 = &g_233;
                        (*l_1919) = (safe_mul_func_int16_t_s_s(g_82[g_202][g_202][(g_202 + 2)], ((((((*l_1949) = l_1947) == ((*l_1975) = ((safe_div_func_uint32_t_u_u((safe_div_func_uint32_t_u_u((safe_add_func_uint8_t_u_u((((*l_1919) >= ((safe_rshift_func_uint8_t_u_s((*l_1919), (((((~((safe_rshift_func_uint16_t_u_u((p_57 , (safe_rshift_func_uint64_t_u_s(((*l_1970) = (p_56.f0 != (safe_mul_func_int32_t_s_s(p_57, ((l_1968[2] = &p_58) == (**g_888)))))), 38))), 4)) ^ p_57)) || 0xBEACADDAL) ^ p_57) & (-1L)) && 0xFBL))) <= g_197[g_65])) ^ l_1972), 0x43L)), p_57)), l_1972)) , l_1973))) , p_56.f0) , g_197[g_65]) < 1UL)));
                    }
                    else
                    { /* block id: 915 */
                        if (p_56.f0)
                            break;
                        (*l_1919) ^= l_1941;
                        return g_197[g_65];
                    }
                }
            }
        }
    }
    return (*l_1919);
}


/* ------------------------------------------ */
/* 
 * reads : g_585 g_197 g_122 g_248 g_249 g_82 g_424 g_425 g_213 g_65 g_296 g_121 g_267 g_436 g_101 g_102 g_622 g_143 g_631 g_506 g_233 g_234 g_235 g_513 g_91 g_28 g_179 g_268 g_335 g_186 g_632 g_521 g_522 g_202 g_600 g_28.f0 g_887 g_888 g_201 g_119 g_6 g_1010 g_217 g_218 g_1038 g_811.f0 g_1011 g_635 g_1016 g_1017 g_1095 g_890 g_889
 * writes: g_65 g_291 g_296 g_600 g_122 g_121 g_267 g_179 g_248 g_436 g_197 g_102 g_632 g_506 g_91 g_82 g_119 g_213 g_202 g_635 g_887 g_201 g_1011 g_1014 g_1041 g_811.f0 g_1752
 */
static uint64_t  func_60(union U0 * p_61, union U0 * p_62)
{ /* block id: 5 */
    uint8_t l_75 = 0x0CL;
    int32_t l_78 = 0x8188558BL;
    union U0 *l_111 = &g_28;
    union U0 ** const l_110 = &l_111;
    int32_t l_146 = 0xE3C26F71L;
    int32_t l_171 = (-1L);
    const int8_t *l_177 = (void*)0;
    volatile int32_t *l_240[6] = {&g_241[0],(void*)0,(void*)0,&g_241[0],(void*)0,(void*)0};
    int32_t *l_245 = &g_122;
    int32_t **l_244 = &l_245;
    int32_t ***l_243 = &l_244;
    uint64_t **l_251[2];
    uint64_t ** const l_305 = &g_249[0];
    uint8_t l_356[8];
    int16_t l_412 = 0x47B6L;
    uint32_t l_437[5] = {1UL,1UL,1UL,1UL,1UL};
    int64_t l_497[7];
    int8_t *l_538 = &g_202;
    union U0 ***l_596 = &g_291[5];
    int32_t l_597[5] = {6L,6L,6L,6L,6L};
    int32_t *l_598 = &g_65;
    int32_t l_611[2][2][4] = {{{0x8B0F99ADL,3L,0x8B0F99ADL,3L},{0x8B0F99ADL,3L,0x8B0F99ADL,3L}},{{0x8B0F99ADL,3L,0x8B0F99ADL,3L},{0x8B0F99ADL,3L,0x8B0F99ADL,3L}}};
    uint32_t l_612 = 0x092A4028L;
    uint8_t l_625 = 0x76L;
    int16_t l_659 = 0x2EEEL;
    uint32_t l_660[7][9][4] = {{{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L},{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL},{0xE8625CBCL,7UL,0x042C2BDDL,7UL},{2UL,4294967295UL,0x260C5D60L,0x6888AB08L},{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL},{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L},{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL},{2UL,0x2ED7B534L,0x260C5D60L,0x85FB8E5DL},{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L}},{{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL},{0xE8625CBCL,7UL,0x042C2BDDL,7UL},{2UL,4294967295UL,0x260C5D60L,0x6888AB08L},{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL},{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L},{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL},{2UL,0x2ED7B534L,0x260C5D60L,0x85FB8E5DL},{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L},{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL}},{{0xE8625CBCL,7UL,0x042C2BDDL,7UL},{2UL,4294967295UL,0x260C5D60L,0x6888AB08L},{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL},{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L},{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL},{2UL,0x2ED7B534L,0x260C5D60L,0x85FB8E5DL},{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L},{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL},{0xE8625CBCL,7UL,0x042C2BDDL,7UL}},{{2UL,4294967295UL,0x260C5D60L,0x6888AB08L},{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL},{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L},{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL},{2UL,0x2ED7B534L,0x260C5D60L,0x85FB8E5DL},{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L},{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL},{0xE8625CBCL,7UL,0x042C2BDDL,7UL},{2UL,4294967295UL,0x260C5D60L,0x6888AB08L}},{{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL},{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L},{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL},{2UL,0x2ED7B534L,0x260C5D60L,0x85FB8E5DL},{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L},{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL},{0xE8625CBCL,7UL,0x042C2BDDL,7UL},{2UL,4294967295UL,0x260C5D60L,0x6888AB08L},{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL}},{{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L},{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL},{2UL,0x2ED7B534L,0x260C5D60L,0x85FB8E5DL},{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L},{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL},{0xE8625CBCL,7UL,0x042C2BDDL,7UL},{2UL,4294967295UL,0x260C5D60L,0x6888AB08L},{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL},{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L}},{{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL},{2UL,0x2ED7B534L,0x260C5D60L,0x85FB8E5DL},{2UL,4294967293UL,0x042C2BDDL,0x3DC789E9L},{0xE8625CBCL,0x6888AB08L,0x260C5D60L,4294967295UL},{0xE8625CBCL,7UL,0x042C2BDDL,7UL},{2UL,4294967295UL,0x260C5D60L,0x6888AB08L},{2UL,0x3DC789E9L,0x042C2BDDL,4294967293UL},{0xE8625CBCL,0x85FB8E5DL,0x260C5D60L,0x2ED7B534L},{0xE8625CBCL,0xFFD7EFBBL,0x042C2BDDL,0xFFD7EFBBL}}};
    uint16_t l_707[6][7][6] = {{{0x99B1L,1UL,0xCA58L,1UL,0x99B1L,0x50C1L},{1UL,0x99B1L,0x50C1L,0xC81AL,65534UL,65535UL},{4UL,65530UL,0x52DEL,0x99B1L,65535UL,65535UL},{0x7B23L,0x7562L,0x50C1L,0UL,0x17C6L,0x50C1L},{65535UL,0x7B23L,0xCA58L,65534UL,0xFB33L,0xD1E8L},{4UL,0x0604L,65535UL,0UL,0UL,0xCA58L},{1UL,0x7562L,65535UL,1UL,0x7B23L,0xD1E8L}},{{65532UL,1UL,0xCA58L,65530UL,65534UL,0x50C1L},{65530UL,65534UL,0x50C1L,0UL,65532UL,65535UL},{0x848DL,1UL,0x52DEL,65532UL,0x7B23L,65535UL},{65535UL,0x848DL,0x50C1L,1UL,1UL,0x50C1L},{0x0604L,0x0604L,0xCA58L,0x99B1L,0xDC0EL,0xD1E8L},{0x848DL,65535UL,65535UL,0UL,0x17C6L,0xCA58L},{1UL,0x848DL,65535UL,65530UL,0x0604L,0xD1E8L}},{{65534UL,65530UL,0xCA58L,1UL,65532UL,0x50C1L},{1UL,65532UL,0x50C1L,0UL,0x99B1L,65535UL},{0x7562L,1UL,0x52DEL,65534UL,0x0604L,65535UL},{0x0604L,4UL,0x50C1L,0x17C6L,0UL,0x50C1L},{0x7B23L,65535UL,0xCA58L,65532UL,0xF944L,0xD1E8L},{0x7562L,0x7B23L,65535UL,0xC81AL,1UL,0xCA58L},{65530UL,4UL,65535UL,1UL,65535UL,0xD1E8L}},{{0x99B1L,1UL,0xCA58L,1UL,0x99B1L,0x50C1L},{1UL,0x99B1L,0x50C1L,0xC81AL,65534UL,65535UL},{4UL,65530UL,0x52DEL,0x99B1L,65535UL,65535UL},{0x7B23L,0x7562L,0x50C1L,0UL,0x17C6L,0x50C1L},{65535UL,0x7B23L,0xCA58L,65534UL,0xFB33L,0xD1E8L},{4UL,0x0604L,65535UL,0UL,0UL,0xCA58L},{1UL,0x7562L,65535UL,1UL,0x7B23L,0xD1E8L}},{{65532UL,1UL,0xCA58L,65530UL,65534UL,0x50C1L},{65530UL,65534UL,0x50C1L,0UL,65532UL,65535UL},{0x848DL,1UL,0x52DEL,65532UL,0x7B23L,4UL},{65534UL,8UL,1UL,0xFFB2L,0xFFB2L,1UL},{0xF189L,0xF189L,0x0604L,2UL,1UL,0xC81AL},{8UL,65534UL,65534UL,0x8229L,0xF0A5L,0x0604L},{3UL,8UL,65534UL,0x046AL,0xF189L,0xC81AL}},{{0x31E3L,0x046AL,0x0604L,5UL,0UL,1UL},{5UL,0UL,1UL,0x8229L,2UL,4UL},{65532UL,5UL,0xFB33L,0x31E3L,0xF189L,4UL},{0xF189L,65535UL,1UL,0xF0A5L,65533UL,1UL},{0UL,65534UL,0x0604L,0UL,0UL,0xC81AL},{65532UL,0UL,65534UL,0x3515L,0xFFB2L,0x0604L},{0x046AL,65535UL,65534UL,5UL,65534UL,0xC81AL}}};
    int16_t l_708 = 0x36DDL;
    uint16_t l_730 = 0xF556L;
    uint16_t l_737 = 0x1AC5L;
    const int32_t l_804 = 1L;
    const uint64_t l_859[10] = {6UL,0x1702C90B5F508141LL,6UL,0x1702C90B5F508141LL,6UL,0x1702C90B5F508141LL,6UL,0x1702C90B5F508141LL,6UL,0x1702C90B5F508141LL};
    uint8_t l_972 = 1UL;
    int16_t l_986 = 9L;
    uint8_t *l_1020[7][1][6] = {{{(void*)0,&g_506,(void*)0,&l_625,&g_506,&l_356[2]}},{{(void*)0,&l_356[2],(void*)0,(void*)0,&g_506,&g_506}},{{&l_75,&l_356[2],&l_356[2],&l_75,&g_506,&l_356[7]}},{{&l_75,&g_506,&l_356[7],(void*)0,&l_356[2],&l_356[7]}},{{(void*)0,&g_506,&l_356[2],&l_625,&l_356[2],&g_506}},{{(void*)0,&g_506,(void*)0,&l_625,&g_506,&l_356[2]}},{{(void*)0,&l_356[2],(void*)0,(void*)0,&g_506,&g_506}}};
    uint8_t **l_1019 = &l_1020[5][0][3];
    uint8_t ***l_1018 = &l_1019;
    uint16_t l_1151 = 0xA7ACL;
    uint64_t ** const *l_1232 = (void*)0;
    uint64_t ** const ** const l_1231 = &l_1232;
    int32_t l_1275 = 0x1870C39EL;
    int64_t *l_1314 = (void*)0;
    int64_t **l_1313 = &l_1314;
    int64_t ***l_1312 = &l_1313;
    uint8_t l_1327 = 0x78L;
    union U0 l_1332 = {1L};
    const uint32_t l_1345 = 9UL;
    int16_t l_1346 = (-1L);
    int64_t l_1463 = (-10L);
    uint32_t *l_1586 = (void*)0;
    uint32_t **l_1585 = &l_1586;
    int32_t ***l_1759[1][7];
    uint16_t *l_1783 = &l_707[5][0][5];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_251[i] = &g_249[5];
    for (i = 0; i < 8; i++)
        l_356[i] = 247UL;
    for (i = 0; i < 7; i++)
        l_497[i] = (-4L);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
            l_1759[i][j] = &g_1117;
    }
lbl_932:
    for (g_65 = (-9); (g_65 == 28); ++g_65)
    { /* block id: 8 */
        uint32_t l_72 = 0x58230B54L;
        union U0 *l_74 = &g_28;
        union U0 **l_73[8][3][2] = {{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}}};
        int32_t *l_160 = &g_6;
        int32_t **l_159 = &l_160;
        const uint32_t l_174 = 5UL;
        uint32_t l_198 = 0UL;
        int32_t l_204 = 0xC51EAD67L;
        uint16_t *l_239 = &g_179;
        const int16_t *l_421 = &g_335[3];
        const int16_t **l_420 = &l_421;
        const int16_t *l_423 = &g_335[0];
        const int16_t **l_422[7][5][7] = {{{&l_423,&l_423,(void*)0,&l_423,&l_423,&l_423,(void*)0},{(void*)0,&l_423,&l_423,&l_423,&l_423,(void*)0,&l_423},{(void*)0,&l_423,&l_423,&l_423,(void*)0,&l_423,&l_423},{(void*)0,&l_423,(void*)0,&l_423,&l_423,&l_423,&l_423},{&l_423,&l_423,&l_423,&l_423,(void*)0,(void*)0,&l_423}},{{&l_423,&l_423,&l_423,(void*)0,(void*)0,&l_423,&l_423},{(void*)0,&l_423,&l_423,(void*)0,&l_423,(void*)0,&l_423},{&l_423,&l_423,&l_423,&l_423,(void*)0,&l_423,&l_423},{&l_423,&l_423,&l_423,(void*)0,&l_423,(void*)0,&l_423},{&l_423,&l_423,&l_423,&l_423,&l_423,(void*)0,(void*)0}},{{(void*)0,&l_423,&l_423,&l_423,&l_423,(void*)0,&l_423},{(void*)0,&l_423,&l_423,(void*)0,&l_423,&l_423,&l_423},{&l_423,&l_423,(void*)0,&l_423,&l_423,(void*)0,&l_423},{&l_423,&l_423,(void*)0,&l_423,&l_423,&l_423,&l_423},{(void*)0,&l_423,&l_423,&l_423,(void*)0,&l_423,&l_423}},{{(void*)0,&l_423,&l_423,&l_423,&l_423,&l_423,&l_423},{&l_423,&l_423,&l_423,(void*)0,&l_423,(void*)0,&l_423},{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,&l_423},{&l_423,&l_423,&l_423,(void*)0,(void*)0,&l_423,(void*)0},{(void*)0,&l_423,&l_423,&l_423,&l_423,(void*)0,&l_423}},{{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,&l_423},{(void*)0,&l_423,&l_423,(void*)0,&l_423,&l_423,&l_423},{&l_423,&l_423,(void*)0,&l_423,(void*)0,&l_423,&l_423},{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,(void*)0},{(void*)0,&l_423,(void*)0,&l_423,&l_423,(void*)0,&l_423}},{{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,&l_423},{(void*)0,&l_423,&l_423,(void*)0,&l_423,&l_423,&l_423},{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,&l_423},{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,&l_423},{(void*)0,(void*)0,&l_423,(void*)0,(void*)0,&l_423,(void*)0}},{{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,(void*)0},{&l_423,&l_423,&l_423,&l_423,&l_423,&l_423,&l_423},{&l_423,&l_423,(void*)0,&l_423,(void*)0,&l_423,(void*)0},{&l_423,&l_423,&l_423,(void*)0,&l_423,&l_423,(void*)0},{&l_423,&l_423,&l_423,&l_423,&l_423,(void*)0,(void*)0}}};
        uint32_t *l_445 = &g_119;
        uint32_t **l_444 = &l_445;
        int32_t l_525 = 6L;
        uint64_t ***l_541 = &g_248;
        int16_t l_573[10][1] = {{(-4L)},{0x8742L},{(-4L)},{0x8742L},{(-4L)},{0x8742L},{(-4L)},{0x8742L},{(-4L)},{0x8742L}};
        int i, j, k;
    }
    if (((*l_598) ^= (safe_add_func_int8_t_s_s((safe_unary_minus_func_uint32_t_u(((~(safe_rshift_func_uint8_t_u_s(g_585, g_197[3]))) < ((safe_mod_func_uint64_t_u_u(((safe_add_func_int16_t_s_s((**l_244), ((l_240[5] != l_240[5]) || ((safe_mod_func_uint64_t_u_u((**g_248), (safe_lshift_func_uint16_t_u_u((safe_sub_func_int16_t_s_s(((l_146 = (((*g_424) , &g_102[0]) != ((*l_596) = &p_61))) , (*l_245)), (**l_244))), g_213)))) != (*l_245))))) >= (**l_244)), 0x0FA85D347A7EC0E9LL)) >= l_597[1])))), g_425))))
    { /* block id: 243 */
        int32_t l_623 = 0xA4CDD33BL;
        int32_t l_624 = (-1L);
lbl_602:
        for (l_75 = 0; (l_75 <= 6); l_75 += 1)
        { /* block id: 246 */
            int i;
            return l_497[l_75];
        }
        for (g_296 = 2; (g_296 <= 6); g_296 += 1)
        { /* block id: 251 */
            uint32_t l_599 = 0xB7BD7B7FL;
            int32_t l_609 = 0L;
            (***l_243) ^= (g_600 = l_599);
            for (l_146 = 3; (l_146 >= 0); l_146 -= 1)
            { /* block id: 256 */
                uint16_t *l_607 = &g_600;
                int i;
                if ((!(g_197[l_146] <= g_197[l_146])))
                { /* block id: 257 */
                    int i;
                    g_121[(l_146 + 1)] = g_121[g_296];
                    if (g_296)
                        goto lbl_602;
                }
                else
                { /* block id: 260 */
                    for (g_267 = 0; (g_267 <= 3); g_267 += 1)
                    { /* block id: 263 */
                        int i, j, k;
                        if (g_82[g_267][(l_146 + 1)][(g_296 + 2)])
                            break;
                    }
                }
                for (g_179 = 0; (g_179 <= 3); g_179 += 1)
                { /* block id: 269 */
                    uint64_t ***l_603 = &l_251[0];
                    uint64_t ***l_604 = &g_248;
                    (*l_604) = ((*l_603) = l_251[1]);
                }
                for (g_436 = 4; (g_436 >= 1); g_436 -= 1)
                { /* block id: 275 */
                    uint8_t *l_608[4][1];
                    int32_t l_615 = (-7L);
                    int32_t l_616 = 0xFF3BE770L;
                    int32_t l_618[10] = {0L,(-5L),1L,1L,(-5L),0L,(-5L),1L,1L,(-5L)};
                    uint8_t l_619 = 255UL;
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_608[i][j] = &l_356[7];
                    }
                    if ((safe_rshift_func_uint8_t_u_u((l_609 = (l_607 == (g_82[g_436][l_146][(g_436 + 2)] , &g_179))), 3)))
                    { /* block id: 277 */
                        uint64_t l_610 = 1UL;
                        int i;
                        g_197[l_146] ^= l_610;
                        l_612--;
                    }
                    else
                    { /* block id: 280 */
                        int32_t l_617 = 0xFE4015C7L;
                        --l_619;
                    }
                    (*g_622) = (*g_101);
                }
            }
        }
        --l_625;
    }
    else
    { /* block id: 288 */
        int64_t l_637 = (-5L);
        int32_t l_638 = 0x5A29EC56L;
        int32_t l_641 = 0xDB21FF5FL;
        int32_t l_644 = 0x41FE537AL;
        int32_t l_645 = 0x763C4347L;
        int32_t l_646 = 0xD8954F00L;
        int32_t l_650 = 0xA80856E0L;
        int64_t l_654[8][8] = {{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)}};
        int32_t l_655 = 0L;
        int32_t l_656[5][9] = {{(-2L),(-2L),1L,(-1L),0xADC7C33EL,0L,(-2L),0xADC7C33EL,0xF708C92BL},{0x7BFA2408L,0L,1L,0xADC7C33EL,0xADC7C33EL,1L,0L,0x7BFA2408L,1L},{0x7BFA2408L,0xADC7C33EL,1L,0x7BFA2408L,0L,1L,0xADC7C33EL,0xADC7C33EL,1L},{(-2L),0xADC7C33EL,0xF708C92BL,0xADC7C33EL,(-2L),0L,0xADC7C33EL,(-1L),1L},{0xADC7C33EL,0L,0xF708C92BL,(-1L),0L,1L,0L,(-1L),0xF708C92BL}};
        const int32_t **l_678[8][6] = {{&g_632,(void*)0,&g_632,&g_632,&g_632,(void*)0},{&g_632,&g_632,&g_632,&g_632,&g_632,&g_632},{&g_632,&g_632,&g_632,&g_632,&g_632,&g_632},{&g_632,&g_632,&g_632,&g_632,&g_632,&g_632},{(void*)0,&g_632,&g_632,(void*)0,&g_632,&g_632},{&g_632,&g_632,&g_632,&g_632,&g_632,&g_632},{&g_632,&g_632,&g_632,&g_632,&g_632,&g_632},{&g_632,&g_632,&g_632,&g_632,&g_632,&g_632}};
        const int32_t *** const l_677 = &l_678[5][3];
        const int32_t *** const *l_676[7] = {&l_677,&l_677,&l_677,&l_677,&l_677,&l_677,&l_677};
        uint8_t * const l_716[10] = {&l_625,&l_625,&l_625,&l_625,&l_625,&l_625,&l_625,&l_625,&l_625,&l_625};
        int16_t * const *l_729 = &g_513;
        uint64_t * const *l_780 = &g_249[5];
        uint64_t * const ** const l_779 = &l_780;
        union U0 *l_809 = &g_28;
        uint32_t l_924 = 0x07FA9D18L;
        int8_t l_927 = 0L;
        uint16_t *l_951 = &g_267;
        uint16_t l_968 = 5UL;
        int i, j;
        if ((*g_143))
        { /* block id: 289 */
            const int32_t *l_630 = &g_65;
            int32_t l_634 = 0x74308C31L;
            int32_t l_640 = 0L;
            int32_t l_648 = 8L;
            int32_t l_651[1];
            int8_t l_657[3];
            uint64_t *l_663[9][8] = {{&g_82[2][3][5],&g_82[3][2][2],&g_82[3][2][4],&g_82[3][2][4],&g_82[4][1][6],&g_82[2][4][0],&g_82[3][2][6],(void*)0},{&g_82[3][4][0],&g_82[3][2][4],(void*)0,(void*)0,&g_82[3][2][4],&g_82[2][4][0],&g_82[2][1][5],&g_82[3][2][4]},{&g_82[2][1][5],&g_82[3][2][2],&g_82[3][2][4],&g_82[3][2][4],&g_82[3][2][2],&g_82[1][3][1],(void*)0,&g_82[4][1][6]},{&g_82[3][2][4],&g_82[3][2][4],&g_82[2][0][1],&g_82[1][2][1],(void*)0,&g_82[1][2][1],&g_82[2][0][1],&g_82[3][2][4]},{&g_82[3][4][0],&g_82[2][0][1],&g_82[2][4][0],&g_82[3][2][2],&g_82[3][2][6],(void*)0,(void*)0,&g_82[3][2][6]},{&g_82[3][2][4],&g_82[4][1][6],&g_82[0][2][3],&g_82[3][2][4],&g_82[3][4][0],&g_82[1][0][7],(void*)0,&g_82[2][1][5]},{&g_82[2][0][1],&g_82[3][2][4],&g_82[2][4][0],(void*)0,&g_82[2][0][6],&g_82[2][3][5],&g_82[2][0][1],(void*)0},{&g_82[2][0][6],&g_82[2][3][5],&g_82[2][0][1],(void*)0,&g_82[1][1][2],&g_82[1][1][2],(void*)0,&g_82[2][0][1]},{&g_82[4][1][6],&g_82[4][1][6],&g_82[3][2][4],&g_82[3][4][0],&g_82[3][2][4],&g_82[0][4][2],&g_82[2][1][5],(void*)0}};
            int32_t ****l_679 = &l_243;
            union U0 ***l_734 = &g_291[2];
            int16_t l_739 = 0xA3EFL;
            int16_t l_764[5][10] = {{0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L,0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L},{0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L,0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L},{0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L,0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L},{0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L,0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L},{0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L,0x3AB7L,(-1L),0xCB2BL,(-1L),0x3AB7L}};
            const uint64_t *l_788 = &g_82[3][2][4];
            const uint64_t **l_787 = &l_788;
            const uint64_t ***l_786 = &l_787;
            uint32_t l_935 = 0UL;
            uint32_t l_938[5] = {1UL,1UL,1UL,1UL,1UL};
            int i, j;
            for (i = 0; i < 1; i++)
                l_651[i] = 0x2E36B844L;
            for (i = 0; i < 3; i++)
                l_657[i] = 1L;
            for (l_171 = 0; (l_171 <= (-15)); l_171--)
            { /* block id: 292 */
                int16_t l_633 = 0L;
                int32_t l_636 = 0x4E82A16EL;
                int32_t l_643 = 0x14756DD3L;
                int32_t l_647 = 1L;
                int32_t l_649 = 0xBB4CE98AL;
                int32_t l_652[3][4] = {{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}};
                int16_t l_653 = 0L;
                int i, j;
                (*g_631) = l_630;
                for (g_506 = 0; (g_506 <= 4); g_506 += 1)
                { /* block id: 296 */
                    int32_t l_639 = 3L;
                    int32_t l_642[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_642[i] = 9L;
                    --l_660[2][8][0];
                    l_642[1] = (((**l_244) = 0L) > (l_437[g_506] | (1L & (*l_630))));
                    return (*l_630);
                }
                (*l_598) &= (((**g_233) == (void*)0) <= l_655);
            }
            if ((((*g_513) = (*g_513)) & (((l_663[0][0] != (void*)0) , (safe_add_func_uint32_t_u_u(0xFC2EDE97L, ((((safe_lshift_func_int32_t_s_s((*l_630), 1)) , ((*l_630) == (((*p_62) , (*l_630)) || ((safe_add_func_int8_t_s_s(0x41L, (**l_244))) <= 0xBCL)))) != l_656[4][5]) || 9UL)))) && l_638)))
            { /* block id: 305 */
                uint16_t l_692 = 0x631CL;
                uint16_t *l_693[8] = {&l_692,&g_267,&l_692,&g_267,&l_692,&g_267,&l_692,&g_267};
                union U0 ****l_703 = &l_596;
                uint8_t *l_704 = &l_75;
                int32_t l_705 = 1L;
                int64_t l_706 = 1L;
                uint32_t *l_709[1];
                int32_t l_710[3][6][1] = {{{0x1FD75FA9L},{0xE111AB3EL},{(-1L)},{(-5L)},{(-5L)},{(-1L)}},{{0xE111AB3EL},{0x1FD75FA9L},{0xE111AB3EL},{0x1FD75FA9L},{0xEC3927D9L},{0xEC3927D9L}},{{0x1FD75FA9L},{(-1L)},{0x6EA7130DL},{(-1L)},{0x1FD75FA9L},{0xEC3927D9L}}};
                int64_t *l_713[7] = {&l_497[0],&l_497[0],&l_497[0],&l_497[0],&l_497[0],&l_497[0],&l_497[0]};
                uint32_t l_731[5][2] = {{0xE195D105L,4294967291UL},{0x73075147L,0x28AA1681L},{4294967291UL,0x28AA1681L},{0x73075147L,4294967291UL},{0xE195D105L,0xE195D105L}};
                uint64_t ***l_781 = (void*)0;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_709[i] = &l_612;
                (****l_679) = (((void*)0 == (*l_305)) > (!((*l_630) ^ (safe_rshift_func_int64_t_s_s((+(safe_lshift_func_int64_t_s_u((l_676[0] == l_679), 51))), ((safe_lshift_func_int64_t_s_s(((l_710[2][2][0] &= (safe_lshift_func_uint64_t_u_u(((((((((**g_248) ^= (((safe_rshift_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((safe_add_func_int32_t_s_s(((((safe_sub_func_int16_t_s_s(l_692, (g_179--))) , ((safe_lshift_func_uint32_t_u_u(((safe_add_func_int16_t_s_s(((((((void*)0 == l_693[7]) && (l_705 = (((~(safe_div_func_int16_t_s_s(((((((((*l_704) = (((*l_703) = &g_291[2]) != (void*)0)) >= (****l_679)) <= l_692) & g_268) | g_506) >= g_425) | (****l_679)), l_692))) == l_692) == (-3L)))) & 18446744073709551611UL) != l_706) != g_335[5]), (*g_424))) , l_692), l_707[0][2][0])) < (-4L))) >= l_692) != 8UL), l_706)), g_335[5])), (*l_630))) < g_186[0][4]) != (*l_598))) > (*l_630)) < (***l_243)) & (-5L)) > (*l_598)) || l_708) != (*l_630)), 23))) == (*l_630)), g_186[0][0])) > g_296))))));
                if (((l_645 |= (((*l_598) = (((safe_sub_func_int64_t_s_s((g_436 = l_692), (safe_add_func_int8_t_s_s(((void*)0 != l_716[6]), ((((safe_sub_func_uint8_t_u_u(0x9CL, (safe_add_func_int32_t_s_s((safe_mul_func_int32_t_s_s(l_692, (((**g_631) , (safe_div_func_int16_t_s_s(0x14E0L, ((safe_sub_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((l_729 != &g_424), 5UL)), l_692)) ^ l_730)))) == l_692))), (*l_630))))) && (*g_513)) == g_82[1][2][2]) < l_710[2][2][0]))))) < 8L) != g_197[3])) ^ 1L)) <= l_731[2][0]))
                { /* block id: 316 */
                    int32_t *l_738 = &l_597[1];
                    for (l_708 = 17; (l_708 <= 16); l_708--)
                    { /* block id: 319 */
                        (*l_703) = l_734;
                        (**l_244) = ((g_506 ^= ((*l_704) = (safe_sub_func_uint16_t_u_u(l_737, (-5L))))) | 0x47L);
                    }
                    for (l_644 = 6; (l_644 >= 0); l_644 -= 1)
                    { /* block id: 327 */
                        (***l_679) = l_738;
                        if (l_692)
                            continue;
                        return l_739;
                    }
                }
                else
                { /* block id: 332 */
                    int8_t l_758 = (-9L);
                    uint16_t l_763 = 65535UL;
                    int32_t l_790 = 0L;
                    int16_t l_803 = 0xC76CL;
                    if ((safe_rshift_func_int32_t_s_s((safe_add_func_uint64_t_u_u(0x86233245FDCFD718LL, ((safe_sub_func_uint16_t_u_u(g_436, (safe_mul_func_int32_t_s_s(((*l_598) = ((safe_rshift_func_uint8_t_u_s((safe_add_func_uint64_t_u_u((((safe_sub_func_int8_t_s_s(((((*l_630) <= (safe_add_func_int8_t_s_s((safe_div_func_int64_t_s_s((*l_630), ((0x6057L <= ((void*)0 != (*l_729))) , l_758))), (safe_add_func_int32_t_s_s(((safe_lshift_func_int16_t_s_u(((void*)0 != l_240[5]), l_763)) && 0xDEL), l_764[3][3]))))) && 0x8F9AA5D3L) && l_710[2][0][0]), 0x7FL)) > l_758) && 0xE2L), (*l_630))), 2)) > l_692)), l_710[2][2][0])))) && 0L))), 13)))
                    { /* block id: 334 */
                        uint32_t l_775 = 0x56A521B6L;
                        int32_t l_789 = 0x15C17D7BL;
                        union U0 ***l_800 = &g_291[2];
                        int32_t *l_805 = &l_651[0];
                        (***l_243) = ((****l_679) ^ ((((safe_mod_func_uint32_t_u_u(l_710[2][2][0], (safe_add_func_int8_t_s_s((safe_lshift_func_uint32_t_u_s((g_119 = l_758), (l_775 = (safe_mod_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(4UL, (-1L))), (*g_424)))))), (l_790 &= ((((((((safe_sub_func_int8_t_s_s((+((l_779 != l_781) != ((((safe_mul_func_uint32_t_u_u(((((safe_lshift_func_uint64_t_u_s((l_786 == (void*)0), 30)) & l_789) && 0x71L) | l_758), 0x5B7A3E00L)) && (*l_630)) & l_789) || l_710[0][4][0]))), 9UL)) > (****l_679)) , l_731[0][0]) <= 0xEEED042221D7C041LL) , (*p_62)) , l_731[3][0]) & l_763) >= l_710[2][2][0])))))) != l_789) , (void*)0) == l_630));
                        if (l_790)
                            goto lbl_791;
lbl_791:
                        (*l_598) = 3L;
                        l_650 &= (safe_lshift_func_int64_t_s_u(((0x98L <= ((****l_679) == ((((safe_lshift_func_uint8_t_u_s(((*g_521) == (((-5L) && (*g_513)) >= (safe_lshift_func_int16_t_s_s(0L, 8)))), 3)) != ((l_800 = &g_291[2]) != (void*)0)) == (((safe_sub_func_int16_t_s_s(0x1596L, l_803)) == 0L) || g_202)) , l_804))) , l_763), (*l_630)));
                        l_805 = ((**l_243) = (**l_243));
                    }
                    else
                    { /* block id: 345 */
                        uint16_t l_806 = 0x2609L;
                        l_806--;
                        (*l_245) = (*l_630);
                        (****l_679) = (****l_679);
                    }
                }
            }
            else
            { /* block id: 351 */
                union U0 *l_810 = &g_811;
                int32_t l_814 = 0xF5639C97L;
                int16_t l_832[8][8][4] = {{{3L,0x844EL,4L,0xA7B1L},{0L,(-9L),4L,0x1BF9L},{3L,(-2L),(-1L),0L},{(-1L),0L,0L,0xB734L},{0L,0xB734L,0xDADFL,0x8946L},{0L,0x61F7L,0x82CEL,0xA7B1L},{0x61F7L,0L,0x1BF9L,1L},{(-7L),3L,0L,0x1BF9L}},{{(-1L),4L,(-3L),0x61F7L},{0xE631L,0x844EL,0x844EL,0xE631L},{(-7L),0x61F7L,4L,0xDADFL},{0xA7B1L,0L,0x82CEL,0L},{(-2L),3L,0L,0L},{0L,0L,0x8946L,0xDADFL},{0x12C8L,0x61F7L,(-1L),0xE631L},{0L,0x844EL,0x1BF9L,0x61F7L}},{{0L,4L,1L,0x1BF9L},{(-2L),3L,(-1L),1L},{0xE631L,0L,(-2L),0xA7B1L},{0L,0x61F7L,0x844EL,0x8946L},{3L,0xB734L,0x82CEL,0xB734L},{0xB734L,0L,1L,0L},{(-7L),(-2L),0xDADFL,0x1BF9L},{0x12C8L,(-9L),(-3L),0xA7B1L}},{{0x12C8L,0x844EL,0xDADFL,0x12C8L},{(-7L),0xA7B1L,1L,0xDADFL},{0xB734L,4L,0x82CEL,1L},{3L,3L,0x844EL,0x853CL},{0L,(-9L),(-2L),0xDADFL},{0xE631L,0xB734L,(-1L),(-1L)},{(-2L),0x844EL,1L,0xB734L},{0L,0L,0x1BF9L,0x1BF9L}},{{0L,0L,(-1L),0x853CL},{0x12C8L,0L,0x8946L,0x61F7L},{0L,0xA7B1L,0L,0x8946L},{(-2L),0xA7B1L,0x82CEL,0x61F7L},{0xA7B1L,0L,4L,0x853CL},{(-7L),0L,0x844EL,0x1BF9L},{0xE631L,0L,(-3L),0xB734L},{(-1L),0x844EL,0L,(-1L)}},{{(-7L),0xB734L,0x1BF9L,0xDADFL},{0x61F7L,(-7L),(-9L),0L},{0L,(-1L),1L,0xA79CL},{0x81A4L,3L,0x81A4L,1L},{0x1BF9L,(-2L),0x12C8L,1L},{0x844EL,(-3L),1L,(-2L)},{(-9L),(-7L),1L,(-6L)},{0x844EL,0xDADFL,0x12C8L,0x4659L}},{{0x1BF9L,(-6L),0x81A4L,0x8946L},{0x81A4L,0x8946L,1L,0xF6F3L},{0L,0L,(-9L),(-2L)},{0L,(-6L),(-6L),0xA79CL},{0xABEAL,0x844EL,(-9L),(-6L)},{0x1BF9L,3L,1L,0L},{4L,(-3L),(-3L),4L},{0xABEAL,0L,1L,1L}},{{(-2L),0x0DD0L,(-9L),0x4659L},{0xDADFL,(-1L),(-9L),0x4659L},{0x81A4L,0x0DD0L,0xF6F3L,1L},{1L,0L,0x12C8L,4L},{0L,(-3L),(-6L),0L},{(-9L),3L,0xA660L,(-6L)},{0xDADFL,0x844EL,0x12C8L,0xA79CL},{4L,(-6L),0x82CEL,(-2L)}}};
                uint16_t *l_835 = &l_707[2][5][4];
                int32_t l_836 = 0x736DEC3DL;
                uint16_t l_860 = 0x690CL;
                int i, j, k;
                l_810 = l_809;
                if ((l_836 ^= ((safe_add_func_int32_t_s_s((****l_679), l_814)) >= (safe_add_func_int8_t_s_s((((((*l_835) ^= (!(((*g_143) & (((safe_div_func_int16_t_s_s(0x6E54L, (safe_lshift_func_int64_t_s_u((safe_div_func_uint32_t_u_u((((((safe_rshift_func_uint32_t_u_u(((void*)0 != &g_425), 22)) == ((safe_mod_func_int8_t_s_s((((safe_mul_func_uint64_t_u_u((safe_sub_func_int64_t_s_s((g_213 = l_832[5][7][3]), ((safe_mul_func_int64_t_s_s(g_91, (****l_679))) != (****l_679)))), 18446744073709551615UL)) || (*g_424)) | 1UL), g_186[0][0])) > (*l_598))) <= (*g_513)) != 0x37534B053A584C31LL) , l_832[0][7][1]), g_600)), 44)))) , 0xF601L) , (*g_632))) >= (**l_244)))) == (*g_513)) || (*l_245)) <= (*l_245)), g_28.f0)))))
                { /* block id: 356 */
                    const int32_t *l_838[2][5][7] = {{{&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1]},{&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3]},{&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1]},{&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3]},{&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1]}},{{&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3]},{&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1]},{&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3]},{&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1],&g_197[1]},{&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3],&l_814,&g_197[3]}}};
                    int32_t *l_863 = &l_638;
                    uint16_t l_879 = 65527UL;
                    int i, j, k;
                    for (l_641 = 0; (l_641 <= 6); l_641 += 1)
                    { /* block id: 359 */
                        const int32_t *l_837 = &l_656[0][4];
                        int8_t *l_843 = &g_635;
                        l_838[1][1][4] = l_837;
                        (**l_244) = (g_65 , ((((*l_837) || ((safe_mul_func_uint64_t_u_u((((safe_lshift_func_int64_t_s_s(((6L && (****l_679)) && (((*l_843) = ((*l_538) = (*l_630))) | ((safe_mul_func_int32_t_s_s((*g_632), ((+(((((safe_div_func_uint8_t_u_u((safe_lshift_func_uint32_t_u_u((((safe_add_func_uint8_t_u_u(((*l_630) ^ (safe_rshift_func_int8_t_s_s((safe_rshift_func_int32_t_s_s(((****l_679) , (safe_rshift_func_int8_t_s_s(((*g_234) != &l_836), (****l_679)))), 16)), l_814))), 0xB7L)) == (*l_630)) && 0x60L), (****l_679))), 0x8FL)) == 65534UL) | (**g_248)) ^ (**g_248)) || 9L)) | g_197[3]))) ^ 0xE6F3CAE9L))), 42)) != l_859[1]) ^ 246UL), (***l_243))) & l_860)) >= (*l_630)) , (**g_631)));
                        (*l_598) ^= (*l_837);
                        return (**g_248);
                    }
                    for (l_641 = 0; (l_641 != (-9)); l_641--)
                    { /* block id: 369 */
                        (***l_679) = l_863;
                        (***l_679) = (**l_243);
                        return (**g_248);
                    }
                    for (l_648 = 0; (l_648 > 10); l_648 = safe_add_func_int64_t_s_s(l_648, 7))
                    { /* block id: 376 */
                        union U0 ****l_876 = (void*)0;
                        union U0 *****l_875 = &l_876;
                        int64_t *l_886[8][8][3] = {{{&g_201[1][3][7],&g_201[1][2][1],&g_201[0][2][4]},{&g_186[3][2],(void*)0,&g_213},{(void*)0,&g_436,(void*)0},{&l_654[7][3],&g_186[3][0],&g_201[0][1][7]},{(void*)0,&g_811.f0,&l_637},{&g_811.f0,&l_654[1][1],(void*)0},{(void*)0,&l_637,&g_28.f0},{&g_201[1][3][7],&g_28.f0,&g_201[0][2][4]}},{{(void*)0,&l_654[7][3],&g_201[1][3][4]},{&l_497[4],&l_497[1],&g_811.f0},{&l_654[2][6],&l_497[0],&l_497[0]},{&l_497[6],&g_201[1][1][6],&l_497[0]},{&l_497[6],&g_28.f0,(void*)0},{&l_654[2][6],&g_213,&g_186[3][0]},{(void*)0,&l_654[6][4],(void*)0},{&l_497[0],&g_811.f0,(void*)0}},{{&g_186[3][0],&l_497[0],&g_201[0][3][2]},{&g_436,&g_213,&g_811.f0},{&g_186[3][2],(void*)0,&l_497[0]},{&l_497[0],&l_637,&g_186[3][0]},{&l_637,(void*)0,(void*)0},{&g_28.f0,&l_497[0],&l_497[0]},{&g_436,&g_811.f0,&g_436},{&g_811.f0,&g_186[1][5],&l_497[1]}},{{&l_654[2][6],(void*)0,&l_654[6][0]},{&g_186[1][0],&g_186[1][5],&l_497[6]},{&l_497[0],&g_811.f0,&g_811.f0},{&l_637,&l_497[0],&g_186[3][0]},{&g_201[0][1][7],(void*)0,&g_811.f0},{&g_201[0][1][7],&l_637,&g_436},{&l_497[0],(void*)0,&g_201[1][3][7]},{&l_637,&g_213,&l_654[1][1]}},{{&g_186[3][0],&l_497[0],&g_186[3][2]},{&l_497[6],&g_811.f0,&l_497[0]},{&g_186[1][5],&l_654[6][4],&g_186[1][0]},{&g_28.f0,&g_213,&l_654[6][0]},{&g_186[1][5],&g_28.f0,(void*)0},{&l_497[0],&g_201[1][1][6],(void*)0},{&l_637,&l_497[0],&l_654[6][0]},{(void*)0,&g_201[0][1][7],&g_186[1][0]}},{{&g_186[3][2],&l_637,&l_497[0]},{&l_497[0],&g_186[1][0],&g_186[3][2]},{(void*)0,(void*)0,&l_654[1][1]},{&l_497[0],&l_497[0],&g_201[1][3][7]},{&g_811.f0,&g_201[1][1][6],&g_436},{&g_186[1][5],&l_497[1],&g_811.f0},{&g_186[3][0],&g_201[0][1][7],&g_186[3][0]},{&g_186[1][0],&g_28.f0,&g_811.f0}},{{&l_497[0],&l_497[0],&l_497[6]},{&g_186[3][0],&l_497[0],&l_654[6][0]},{&g_213,&g_436,&l_497[1]},{&g_186[3][0],(void*)0,&g_436},{&l_497[0],&g_186[1][5],&l_497[0]},{&g_186[1][0],&g_201[0][1][7],(void*)0},{&g_186[3][0],&l_497[0],&g_186[3][0]},{&g_186[1][5],&l_497[0],&l_497[0]}},{{&g_811.f0,&l_654[6][4],&g_811.f0},{&l_497[0],&l_654[1][1],&g_201[0][3][2]},{(void*)0,&g_186[1][5],(void*)0},{&l_497[0],&g_201[0][1][7],(void*)0},{&g_186[3][2],&l_497[0],&g_186[3][0]},{(void*)0,&g_436,(void*)0},{&l_637,&g_186[1][0],&l_497[0]},{&l_497[0],&g_186[1][0],&l_497[0]}}};
                        uint32_t *l_891[6] = {&l_660[2][8][0],&l_660[2][8][0],&l_660[2][8][0],&l_660[2][8][0],&l_660[2][8][0],&l_660[2][8][0]};
                        int i, j, k;
                        l_646 ^= (safe_sub_func_uint8_t_u_u((~(l_814 = ((safe_rshift_func_uint8_t_u_u((((***l_243) , ((safe_sub_func_int32_t_s_s((safe_lshift_func_int8_t_s_s(1L, (****l_679))), (l_832[0][6][0] <= (l_836 = (((*l_875) = (void*)0) == ((safe_sub_func_uint8_t_u_u(l_879, ((safe_lshift_func_uint8_t_u_s((~(safe_mod_func_uint32_t_u_u(((!(*g_521)) , l_832[5][7][3]), ((g_887[1][2][0] |= 0x6CFB2283A80FB5A4LL) || (**g_248))))), g_82[3][2][4])) , (**l_244)))) , g_888)))))) && (****l_679))) >= g_213), 7)) > (-1L)))), g_335[5]));
                        (*l_863) = (safe_mod_func_uint8_t_u_u(255UL, (safe_unary_minus_func_uint16_t_u(g_506))));
                    }
                }
                else
                { /* block id: 384 */
                    int16_t l_905 = (-1L);
                    int32_t l_925 = 1L;
                    int64_t *l_926 = &g_213;
                    int32_t l_928 = 0xAC174C09L;
                    uint16_t l_929 = 0xA72EL;
                    int32_t l_933 = 0x376952F2L;
                    int32_t l_934[4][10] = {{0L,(-1L),(-8L),(-1L),(-7L),0x84FE8E0FL,0x99931B37L,0x84FE8E0FL,(-7L),(-1L)},{(-1L),1L,(-1L),(-1L),(-7L),(-1L),0x0A4A28AFL,0x2F4349C3L,0x2F4349C3L,0x0A4A28AFL},{(-7L),1L,0x99931B37L,0x99931B37L,1L,(-6L),(-1L),0x0A4A28AFL,(-7L),(-8L)},{0L,(-8L),(-1L),1L,0x0A4A28AFL,1L,(-1L),(-8L),0L,(-6L)}};
                    int i, j;
                    if (((((*l_926) = (0x7DL >= (safe_add_func_int32_t_s_s(((*l_598) != ((safe_add_func_uint64_t_u_u((**g_248), (safe_sub_func_uint8_t_u_u((((safe_mul_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(0xADL, 0x0EL)), l_905)) | ((**l_729) = (~(safe_lshift_func_uint64_t_u_u(((~((65528UL && (*l_598)) & (safe_rshift_func_int8_t_s_s((((((safe_mul_func_int32_t_s_s(((l_925 |= (safe_add_func_int32_t_s_s(((--g_506) ^ (safe_rshift_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(l_924, 0x8FL)), l_836))), (****l_679)))) , l_836), l_836)) <= (*l_630)) && l_905) != 0L) >= (****l_679)), 0)))) & (*l_630)), 29))))) && (-4L)), (*l_245))))) && (**l_244))), l_905)))) == l_905) > 0UL))
                    { /* block id: 389 */
                        l_929++;
                        return (**g_248);
                    }
                    else
                    { /* block id: 392 */
                        (*l_598) = 0x5C3845CFL;
                        if (l_804)
                            goto lbl_932;
                    }
                    ++l_935;
                }
                g_197[3] &= (*g_143);
                l_938[3] = (***l_243);
            }
        }
        else
        { /* block id: 401 */
            int32_t l_943 = (-1L);
            for (l_75 = 0; (l_75 > 46); l_75++)
            { /* block id: 404 */
                int64_t * const l_949 = &g_201[1][2][4];
                int32_t l_950 = 1L;
                (*l_245) = ((-1L) || ((1L && (safe_rshift_func_int32_t_s_s((((-9L) ^ l_943) , (safe_sub_func_int16_t_s_s((!((l_943 == 0x7BF5997EL) < (((*l_949) &= ((((safe_lshift_func_int16_t_s_s(0L, (*l_598))) > ((&l_497[0] != l_949) & l_950)) , p_61) == (void*)0)) < l_950))), (*g_424)))), (*l_245)))) > g_268));
            }
        }
        l_655 = (((*l_951) |= g_201[0][1][7]) != ((safe_mod_func_uint16_t_u_u(0UL, (safe_add_func_int32_t_s_s((*l_598), ((safe_mul_func_int16_t_s_s((safe_lshift_func_int32_t_s_u((safe_add_func_int32_t_s_s(8L, (safe_sub_func_int8_t_s_s((-1L), (safe_rshift_func_int8_t_s_s((***l_243), (safe_add_func_int32_t_s_s(0x5571E1BDL, l_968)))))))), (0xAD7BL == 9L))), (***l_243))) , 4294967295UL))))) & (**l_244)));
    }
    if (((((((~((*l_245) , ((((safe_sub_func_int32_t_s_s((((0x7AE28B91L >= ((l_972 >= (!(safe_mod_func_uint8_t_u_u(((***l_243) , (safe_mod_func_int32_t_s_s((*g_632), (l_597[1] = (safe_mod_func_int16_t_s_s((safe_add_func_int16_t_s_s((*g_513), g_119)), (*g_513))))))), (safe_sub_func_int64_t_s_s((safe_rshift_func_int64_t_s_s((*l_598), (*l_598))), (*g_521))))))) && (***l_243))) , g_6) , 1L), g_335[4])) && l_986) ^ g_91) || (***l_243)))) | (*l_598)) > g_296) < (*g_424)) || (*g_521)) & (-8L)))
    { /* block id: 413 */
        uint32_t l_992[7][7] = {{0xD0F5CF4AL,0x918D44DAL,0x918D44DAL,0xD0F5CF4AL,0UL,0x918D44DAL,0xE9C51969L},{9UL,4UL,9UL,0xAD774CA1L,0xDFF309B0L,0xAD774CA1L,9UL},{0xD0F5CF4AL,0xD0F5CF4AL,0x21BE79ABL,0xE9C51969L,0xD0F5CF4AL,0x96F276D3L,0xE9C51969L},{0xED4537D9L,0xAD774CA1L,8UL,4UL,8UL,0xAD774CA1L,0xED4537D9L},{0UL,0xE9C51969L,0x918D44DAL,0UL,0xD0F5CF4AL,0x918D44DAL,0x918D44DAL},{0xDFF309B0L,4UL,0x32FFE73DL,4UL,0xDFF309B0L,0x12585D39L,0xDFF309B0L},{0xD0F5CF4AL,0UL,0x918D44DAL,0xE9C51969L,0UL,0UL,0xE9C51969L}};
        uint8_t * const *l_996 = (void*)0;
        uint8_t * const **l_997 = &l_996;
        int32_t l_1002 = 0x246D9922L;
        uint8_t *l_1005[1];
        int32_t *l_1006[1];
        const uint8_t **l_1013 = (void*)0;
        const uint8_t ***l_1012 = &l_1013;
        uint32_t l_1021 = 0x1D3E6349L;
        int64_t l_1037 = 0x590BA106F2B8631BLL;
        int i, j;
        for (i = 0; i < 1; i++)
            l_1005[i] = (void*)0;
        for (i = 0; i < 1; i++)
            l_1006[i] = &g_197[3];
        for (l_737 = (-22); (l_737 <= 19); l_737++)
        { /* block id: 416 */
            uint32_t l_989 = 18446744073709551608UL;
            if (l_989)
                break;
        }
        l_78 &= (((***l_243) = (safe_sub_func_int16_t_s_s(l_992[0][2], ((l_251[0] != ((***l_243) , l_305)) ^ (g_506 = (((((+((safe_mul_func_int64_t_s_s(((((*l_997) = l_996) != (void*)0) , (safe_sub_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((l_1002 < (safe_div_func_int16_t_s_s(l_992[0][2], (*l_598)))), 0x7BECB628AF255C83LL)), l_992[2][2]))), (*g_521))) & (***l_243))) <= (*l_598)) & (*l_598)) | l_992[2][2]) | 0L)))))) != l_992[4][1]);
        for (g_119 = (-8); (g_119 == 46); ++g_119)
        { /* block id: 425 */
            const int32_t **l_1009 = &g_632;
            (*g_1010) = ((*l_1009) = (**l_243));
        }
        for (l_146 = 0; (l_146 <= 1); l_146 += 1)
        { /* block id: 431 */
            const int32_t l_1024[3] = {0L,0L,0L};
            int32_t l_1049[6] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
            uint16_t l_1052 = 65529UL;
            uint32_t *l_1087[1];
            int i;
            for (i = 0; i < 1; i++)
                l_1087[i] = &l_660[2][8][0];
            (***l_243) &= ((*l_598) = ((g_1014[1][1] = l_1012) != ((**g_217) , l_1018)));
            l_1021++;
            (**l_244) &= l_1024[2];
            for (g_91 = 1; (g_91 >= 0); g_91 -= 1)
            { /* block id: 439 */
                uint32_t *l_1033 = &l_437[4];
                uint32_t **l_1032 = &l_1033;
                uint32_t *** const l_1031 = &l_1032;
                union U0 l_1034[2] = {{0xD42A5D46E62861A6LL},{0xD42A5D46E62861A6LL}};
                int32_t l_1045 = (-5L);
                int32_t l_1046 = 0x696433CDL;
                int32_t l_1047 = (-1L);
                int32_t l_1048 = (-6L);
                int32_t l_1050 = 3L;
                int32_t l_1051 = (-1L);
                union U0 *** const *l_1063 = &l_596;
                int i;
                if ((safe_div_func_int32_t_s_s(l_1024[0], ((safe_div_func_int32_t_s_s((1L | ((255UL == (safe_lshift_func_int32_t_s_u(((**g_631) >= (l_1031 != (l_1034[1] , &g_362))), 11))) | ((g_425 != ((safe_add_func_uint16_t_u_u((3L ^ l_1024[2]), l_1037)) || 0x3D24368FC1BED998LL)) , (*l_245)))), (*g_632))) || l_1024[1]))))
                { /* block id: 440 */
                    for (l_78 = 1; (l_78 >= 0); l_78 -= 1)
                    { /* block id: 443 */
                        const volatile union U0 * volatile *l_1039 = (void*)0;
                        const volatile union U0 * volatile *l_1040 = &g_1041;
                        (*l_1040) = g_1038;
                    }
                }
                else
                { /* block id: 446 */
                    (*l_598) = (!((*g_513) , 0x504D81AFL));
                    return l_1034[1].f0;
                }
                for (g_811.f0 = 1; (g_811.f0 >= 0); g_811.f0 -= 1)
                { /* block id: 452 */
                    if ((*g_1011))
                        break;
                    (**l_244) &= (1L != (safe_div_func_int8_t_s_s(l_1024[1], 0x6EL)));
                    for (l_412 = 0; (l_412 <= 3); l_412 += 1)
                    { /* block id: 457 */
                        int i;
                        g_197[l_412] ^= 0L;
                    }
                }
                l_1052--;
                if ((**g_1010))
                    break;
                for (g_635 = 1; (g_635 >= 0); g_635 -= 1)
                { /* block id: 465 */
                    uint16_t *l_1070 = (void*)0;
                    uint16_t *l_1071 = (void*)0;
                    uint16_t *l_1072[8][10] = {{&l_1052,&l_730,&l_730,&l_1052,&g_600,&l_707[3][3][0],(void*)0,(void*)0,&l_1052,(void*)0},{&l_730,&g_179,(void*)0,(void*)0,(void*)0,&g_179,&l_730,(void*)0,&l_1052,(void*)0},{(void*)0,&l_707[3][3][0],&g_600,&l_1052,&l_730,&l_730,&l_1052,&g_600,&l_707[3][3][0],(void*)0},{&l_707[0][2][0],&l_707[3][3][0],&l_1052,&l_730,(void*)0,(void*)0,&l_730,(void*)0,(void*)0,&l_730},{&l_730,&g_179,&l_730,&l_707[3][3][0],(void*)0,&l_707[5][4][4],(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_730,&l_707[5][4][4],&l_707[5][4][4],&l_730,(void*)0,&l_707[0][2][0],(void*)0,&l_1052,(void*)0},{&g_179,(void*)0,&l_730,&g_600,(void*)0,&g_600,&l_730,(void*)0,&g_179,(void*)0},{&g_179,&l_707[5][4][4],&l_1052,&l_707[0][2][0],&g_600,(void*)0,(void*)0,&g_600,&l_707[0][2][0],&l_1052}};
                    int32_t l_1073[1][4];
                    int32_t l_1074[4] = {0xCC0E3A53L,0xCC0E3A53L,0xCC0E3A53L,0xCC0E3A53L};
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 4; j++)
                            l_1073[i][j] = 0x4119F908L;
                    }
                    if (((***l_243) = (safe_add_func_uint32_t_u_u(((***l_1031) = g_186[3][7]), (+(safe_mul_func_uint8_t_u_u((*g_1016), (safe_sub_func_int32_t_s_s((+(g_201[g_91][(g_635 + 2)][(g_635 + 5)] = 1L)), ((((void*)0 != l_1063) ^ ((***l_243) || (safe_div_func_uint64_t_u_u(((l_1048 ^ (safe_add_func_int8_t_s_s((((l_1073[0][3] = (safe_mod_func_int32_t_s_s(l_1024[1], (*g_1011)))) && (*g_424)) > 253UL), l_1024[1]))) ^ l_1074[2]), l_1074[2])))) >= 0L))))))))))
                    { /* block id: 470 */
                        int32_t *l_1088 = &l_1002;
                        int32_t l_1098 = 5L;
                        if (g_201[g_91][(g_635 + 2)][(g_635 + 5)])
                            break;
                        (*l_598) ^= ((**l_244) = ((safe_mul_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u(l_1052, (safe_lshift_func_uint32_t_u_u(((*l_1033) = (safe_add_func_uint32_t_u_u((((((*p_62) , (safe_div_func_uint16_t_u_u(((((**l_305) = ((safe_rshift_func_int64_t_s_u((((*l_1088) &= (l_1087[0] != l_1087[0])) , l_1045), 11)) , (safe_div_func_int64_t_s_s(((((safe_sub_func_uint32_t_u_u((safe_div_func_int16_t_s_s(((void*)0 == g_1095[0][2]), 0xD4B9L)), ((***l_243) != l_1024[2]))) || 18446744073709551615UL) > g_201[g_91][(g_635 + 2)][(g_635 + 5)]) , l_1049[5]), (-7L))))) || l_1098) == 0x132CD35965C993ABLL), (-1L)))) , 0x71D480D0L) , (void*)0) == &g_1010), l_1098))), 13)))) , g_213), l_1024[2])) , l_1074[2]));
                        l_1049[2] ^= (*l_245);
                        return (*l_598);
                    }
                    else
                    { /* block id: 479 */
                        (*l_244) = &l_1046;
                        return l_1074[2];
                    }
                }
            }
        }
    }
    else
    { /* block id: 486 */
        uint64_t l_1099 = 0xD6241AD5825997E6LL;
        uint64_t ***l_1109 = &l_251[1];
        uint8_t * const *l_1141 = (void*)0;
        uint8_t * const **l_1140 = &l_1141;
        int32_t **l_1248 = (void*)0;
        int32_t l_1257 = 1L;
        int16_t l_1297 = 0x28A4L;
        uint64_t *l_1339 = &l_1099;
        int32_t l_1373[5][1][1] = {{{1L}},{{0xCBCA46FAL}},{{1L}},{{0xCBCA46FAL}},{{1L}}};
        int32_t l_1383 = (-3L);
        int16_t l_1386[10] = {0x9C79L,0x9C79L,0x9C79L,0x9C79L,0x9C79L,0x9C79L,0x9C79L,0x9C79L,0x9C79L,0x9C79L};
        int16_t l_1395[10] = {0x4F59L,0x4F59L,0xE9E7L,0x50FCL,0xE9E7L,0x4F59L,0x4F59L,0xE9E7L,0x50FCL,0xE9E7L};
        uint32_t l_1527 = 0x0561FBEEL;
        uint8_t l_1546[1];
        uint32_t *l_1571 = &g_119;
        uint32_t *l_1574 = &g_887[0][0][0];
        int16_t **l_1577 = (void*)0;
        union U0 ** const *l_1579[9][9][3] = {{{&l_110,&l_110,&g_291[1]},{&g_291[2],&g_291[2],&l_110},{&l_110,&g_291[3],&g_291[2]},{&g_291[2],&g_291[2],&g_291[0]},{&g_291[4],&g_291[1],&g_291[1]},{&g_291[4],&g_291[2],&g_291[2]},{&g_291[2],&g_291[2],&l_110},{&g_291[2],&g_291[4],&g_291[2]},{(void*)0,&g_291[1],&g_291[1]}},{{&g_291[5],&g_291[2],&g_291[0]},{&g_291[0],&g_291[2],&g_291[2]},{(void*)0,(void*)0,&l_110},{&g_291[2],&g_291[2],&g_291[2]},{&l_110,(void*)0,(void*)0},{(void*)0,&g_291[2],(void*)0},{(void*)0,&g_291[2],&g_291[4]},{&g_291[1],&g_291[1],&l_110},{(void*)0,&g_291[4],&l_110}},{{&g_291[2],&g_291[2],(void*)0},{(void*)0,&g_291[2],&g_291[2]},{&g_291[1],&g_291[1],&g_291[2]},{(void*)0,&g_291[2],&g_291[5]},{(void*)0,&g_291[3],&g_291[1]},{&l_110,&g_291[2],&g_291[3]},{&g_291[2],(void*)0,&g_291[1]},{(void*)0,&g_291[5],&g_291[5]},{&g_291[0],&g_291[2],&g_291[2]}},{{&g_291[5],&g_291[0],&g_291[2]},{(void*)0,&g_291[4],(void*)0},{&g_291[2],&l_110,&l_110},{&g_291[2],&g_291[4],&l_110},{&g_291[4],&g_291[0],&g_291[4]},{&g_291[4],&g_291[2],(void*)0},{&g_291[2],&g_291[5],(void*)0},{&l_110,(void*)0,&g_291[2]},{&g_291[2],&g_291[2],&l_110}},{{&l_110,&g_291[3],&g_291[2]},{&g_291[2],&g_291[2],&g_291[0]},{&g_291[4],&g_291[1],&g_291[1]},{&g_291[4],&g_291[2],&g_291[2]},{&g_291[2],&g_291[2],&l_110},{&g_291[2],&g_291[4],&g_291[2]},{(void*)0,&g_291[1],&g_291[1]},{&g_291[5],&g_291[2],&g_291[0]},{&g_291[0],&g_291[2],&g_291[2]}},{{(void*)0,(void*)0,&l_110},{&g_291[2],&g_291[2],&g_291[2]},{&l_110,(void*)0,(void*)0},{(void*)0,&g_291[2],(void*)0},{(void*)0,&g_291[2],&g_291[4]},{&g_291[1],&g_291[1],&l_110},{(void*)0,&g_291[4],&l_110},{&g_291[2],&g_291[2],(void*)0},{(void*)0,&g_291[2],&g_291[2]}},{{&g_291[1],&g_291[1],&g_291[2]},{(void*)0,&g_291[2],&g_291[5]},{(void*)0,&g_291[3],&g_291[1]},{&l_110,&g_291[2],&g_291[3]},{&g_291[2],(void*)0,&g_291[1]},{(void*)0,&g_291[5],&g_291[5]},{&g_291[0],&g_291[2],&g_291[2]},{&g_291[5],&g_291[0],&g_291[2]},{(void*)0,&g_291[4],(void*)0}},{{&g_291[2],&l_110,&l_110},{&g_291[2],&g_291[1],(void*)0},{&l_110,&g_291[2],&l_110},{&g_291[1],(void*)0,&l_110},{&g_291[2],&l_110,&g_291[4]},{(void*)0,&l_110,&l_110},{(void*)0,&l_110,(void*)0},{(void*)0,&g_291[1],&g_291[2]},{&g_291[2],&g_291[2],&g_291[2]}},{{&g_291[1],&g_291[2],&g_291[2]},{&l_110,&g_291[2],&g_291[2]},{&g_291[3],&g_291[2],&l_110},{&g_291[2],&l_110,&g_291[2]},{&g_291[0],&g_291[2],&g_291[2]},{&l_110,(void*)0,&g_291[2]},{(void*)0,&g_291[2],&g_291[2]},{&g_291[5],&g_291[5],(void*)0},{&g_291[2],&g_291[3],&l_110}}};
        union U0 ** const **l_1580 = &l_1579[1][0][0];
        const uint64_t *l_1620 = (void*)0;
        uint32_t l_1666 = 1UL;
        uint32_t l_1704 = 18446744073709551615UL;
        uint16_t *l_1785 = (void*)0;
        uint32_t ***l_1790 = &l_1585;
        int64_t ****l_1827 = &l_1312;
        uint32_t l_1837[10][3] = {{4294967291UL,0xAAB32CE4L,4294967291UL},{4294967295UL,0xF1D931F5L,4294967295UL},{4294967291UL,0xAAB32CE4L,4294967291UL},{4294967295UL,0xF1D931F5L,4294967295UL},{4294967291UL,0xAAB32CE4L,4294967291UL},{4294967295UL,0xF1D931F5L,4294967295UL},{4294967291UL,0xAAB32CE4L,4294967291UL},{4294967295UL,0xF1D931F5L,4294967295UL},{4294967291UL,0xAAB32CE4L,4294967291UL},{4294967295UL,0xF1D931F5L,4294967295UL}};
        int32_t l_1846[8][2] = {{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L}};
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1546[i] = 0x91L;
        if ((***l_243))
        { /* block id: 487 */
            uint16_t l_1108 = 0x477EL;
            uint64_t *l_1113 = &g_82[4][3][3];
            int32_t l_1118 = 0x8FC8BDBFL;
            int16_t *l_1127[4][3][7] = {{{&l_986,&l_986,(void*)0,&l_708,(void*)0,&l_986,&l_986},{&g_91,&l_986,&l_708,(void*)0,&l_708,&l_986,&l_986},{&l_986,&l_986,&l_412,&l_708,&l_708,&l_412,&g_91}},{{&l_412,&g_91,&l_708,(void*)0,&l_986,(void*)0,&l_708},{&l_708,&l_708,(void*)0,(void*)0,&l_659,&l_708,&g_91},{&l_986,&l_659,&l_412,&l_708,&l_986,&g_91,&l_986}},{{&g_91,&l_708,&l_708,(void*)0,&l_659,&l_708,&l_659},{&l_708,&l_986,&l_986,&l_708,&l_986,&l_708,&l_412},{(void*)0,&l_708,&l_708,&g_91,&l_708,&g_91,(void*)0}},{{&l_708,&l_412,&l_659,&l_986,&l_708,&l_708,&l_412},{(void*)0,(void*)0,&l_708,&l_708,(void*)0,(void*)0,&l_659},{(void*)0,&l_708,&g_91,&l_412,&g_91,&l_412,&l_986}}};
            union U0 **l_1159 = &l_111;
            uint8_t * const *l_1179 = &l_1020[5][0][3];
            uint32_t l_1194 = 0UL;
            uint64_t ****l_1233[1];
            int32_t *l_1236 = &l_171;
            int32_t ****l_1243 = &l_243;
            uint32_t *l_1255 = &l_612;
            uint32_t **l_1254 = &l_1255;
            union U0 ****l_1294 = &l_596;
            union U0 ***** const l_1293 = &l_1294;
            uint64_t *l_1338[2][4][7] = {{{&g_82[3][3][5],&g_82[3][2][4],&l_1099,&g_82[4][1][2],&g_82[3][2][4],&g_82[1][0][8],&l_1099},{&g_82[3][2][4],&g_82[3][3][5],&l_1099,&l_1099,&g_82[2][2][7],&g_82[4][1][2],&l_1099},{&g_82[3][2][4],&g_82[3][2][4],&g_82[4][1][2],&l_1099,(void*)0,&g_82[2][2][7],&l_1099},{&l_1099,&g_82[3][2][4],&g_82[1][0][8],&g_82[1][1][2],&l_1099,&g_82[4][1][7],&l_1099}},{{&g_82[4][1][2],&g_82[1][1][2],&l_1099,&l_1099,&g_82[1][0][8],&g_82[1][0][8],&l_1099},{&g_82[3][2][4],&l_1099,&g_82[3][2][4],&g_82[2][2][7],&g_82[1][0][8],&g_82[3][3][5],&g_82[3][2][4]},{&g_82[3][2][4],&g_82[4][1][7],(void*)0,&l_1099,&l_1099,&g_82[3][2][4],&l_1099},{&l_1099,(void*)0,&g_82[4][1][7],&g_82[3][2][4],(void*)0,&g_82[3][3][5],&g_82[3][3][5]}}};
            int32_t l_1344 = 0xD447650DL;
            uint32_t *l_1347 = &l_1194;
            int32_t *l_1348 = &g_65;
            int32_t l_1374 = 0x09136C11L;
            int32_t l_1376 = 0xF306A558L;
            int32_t l_1378 = (-1L);
            int32_t l_1379 = 0x8B43E07EL;
            int32_t l_1381 = 1L;
            int32_t l_1382 = 0L;
            int32_t l_1384 = (-1L);
            int32_t l_1388 = 0x97F4EF77L;
            int32_t l_1389 = 1L;
            int32_t l_1390 = 0xDA382426L;
            int32_t l_1391 = 0x9AC21360L;
            int32_t l_1393 = (-1L);
            int32_t l_1394[6];
            int8_t l_1464 = 0xCCL;
            int16_t l_1528 = 0L;
            int16_t l_1553 = 8L;
            uint16_t l_1554 = 0x6DB8L;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1233[i] = &l_1109;
            for (i = 0; i < 6; i++)
                l_1394[i] = 0x95BAB98EL;
        }
        else
        { /* block id: 719 */
            uint8_t l_1562[2];
            int i;
            for (i = 0; i < 2; i++)
                l_1562[i] = 0UL;
            l_1562[0]--;
            (*g_890) = (void*)0;
            return l_1562[0];
        }
        l_1373[3][0][0] = (safe_mod_func_uint32_t_u_u(((((***l_243) = (***l_243)) >= (l_1395[6] >= ((*g_521) <= (safe_sub_func_uint64_t_u_u((0x8861D86CL != ((*l_1571) = (((*l_1313) = l_1339) == (void*)0))), g_179))))) ^ (safe_div_func_uint32_t_u_u(((++(*l_1574)) && (0x15L & ((void*)0 != l_1577))), l_1546[0]))), (*l_598)));
        if ((((6L & 6UL) , (((+(((l_1386[5] | (((*l_1580) = l_1579[4][7][0]) != ((((*g_521) == (-1L)) , l_1373[1][0][0]) , (*g_888)))) || (((safe_sub_func_uint64_t_u_u((((safe_mod_func_int8_t_s_s(((g_506 ^= ((void*)0 != l_1585)) < 0xD9L), 4L)) , (**l_244)) || (-10L)), (**l_244))) > 0UL) & l_1099)) == (**l_244))) == 0x09C3L) != g_335[5])) , l_1546[0]))
        { /* block id: 731 */
            uint32_t l_1587[5][3] = {{0x98A3F3D7L,0x98A3F3D7L,0x98A3F3D7L},{0x7D316A6EL,0x7D316A6EL,0x7D316A6EL},{0x98A3F3D7L,0x98A3F3D7L,0x98A3F3D7L},{0x7D316A6EL,0x7D316A6EL,0x7D316A6EL},{0x98A3F3D7L,0x98A3F3D7L,0x98A3F3D7L}};
            uint64_t * const *l_1604 = &g_249[4];
            uint64_t * const **l_1603 = &l_1604;
            union U0 l_1606 = {0x413B2FE6F121A9D9LL};
            uint32_t l_1608 = 4294967287UL;
            const uint64_t *l_1619 = &g_82[0][4][1];
            int32_t *l_1640 = &l_611[1][0][0];
            int32_t l_1648 = 0L;
            int32_t l_1649 = (-6L);
            int32_t l_1652 = (-6L);
            int32_t l_1654 = 0x7D4986BCL;
            int32_t l_1657 = (-10L);
            int32_t l_1659 = (-9L);
            int32_t l_1665 = 0xCCD245C6L;
            int i, j;
            if ((**g_631))
            { /* block id: 732 */
                l_1373[4][0][0] = l_1587[0][1];
            }
            else
            { /* block id: 734 */
                uint32_t l_1588[3];
                int16_t *l_1602 = &g_91;
                int32_t **l_1638 = (void*)0;
                int32_t l_1642 = (-1L);
                int32_t l_1645 = 1L;
                int32_t l_1647 = (-10L);
                int32_t l_1651 = (-1L);
                int32_t l_1653 = (-4L);
                int32_t l_1656 = 1L;
                int32_t l_1660 = 1L;
                int i;
                for (i = 0; i < 3; i++)
                    l_1588[i] = 1UL;
                (**l_243) = (**l_243);
                for (l_972 = 0; (l_972 <= 7); l_972 += 1)
                { /* block id: 738 */
                    uint32_t l_1607 = 0UL;
                    uint64_t *l_1618 = &g_82[3][2][4];
                    uint16_t *l_1636 = &g_600;
                    uint64_t l_1637 = 1UL;
                    int32_t l_1639 = 1L;
                }
                l_1666++;
            }
        }
        else
        { /* block id: 769 */
            uint16_t l_1677 = 1UL;
            uint16_t l_1686[10][10] = {{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL},{4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL,4UL,0xF70BL}};
            uint32_t *l_1688 = &g_296;
            uint32_t **l_1687 = &l_1688;
            int32_t l_1692 = 0x9267B534L;
            int32_t l_1693 = 0xD4457AC6L;
            int32_t l_1694[8];
            int8_t l_1697 = 5L;
            int32_t l_1700[8] = {(-1L),1L,(-1L),1L,(-1L),1L,(-1L),1L};
            const uint16_t l_1722[2][7] = {{0x94A2L,9UL,0x94A2L,0x94A2L,9UL,0x94A2L,0x94A2L},{65530UL,65530UL,65533UL,65530UL,65530UL,65533UL,65530UL}};
            union U0 l_1733 = {9L};
            int64_t *** const l_1748[8] = {&l_1313,(void*)0,&l_1313,(void*)0,&l_1313,(void*)0,&l_1313,(void*)0};
            const uint8_t l_1821 = 248UL;
            uint32_t ****l_1826[1][10] = {{&l_1790,&l_1790,&l_1790,&l_1790,&l_1790,&l_1790,&l_1790,&l_1790,&l_1790,&l_1790}};
            int i, j;
            for (i = 0; i < 8; i++)
                l_1694[i] = (-1L);
            if ((((safe_div_func_int32_t_s_s((*g_632), ((l_1257 |= (((l_1383 = (safe_rshift_func_int32_t_s_u(((safe_mul_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u(l_1677, (!0x11622AC3DFC881E7LL))) && 0x62L), (safe_rshift_func_int32_t_s_s(((safe_mod_func_int16_t_s_s((*g_424), (safe_lshift_func_int8_t_s_s((safe_unary_minus_func_uint64_t_u(((l_1677 , (0xC9DC4C74L && 0x73C937EDL)) != l_1677))), l_1386[6])))) , (**g_1010)), 18)))) == l_1686[7][9]), 13))) , (void*)0) == (void*)0)) || l_1686[4][2]))) , (void*)0) != &g_425))
            { /* block id: 772 */
                int32_t l_1695 = 0x1C195D03L;
                int32_t l_1696 = 0x4821EAC3L;
                int32_t l_1698 = 1L;
                int32_t l_1699 = (-1L);
                int32_t l_1701 = (-9L);
                int32_t l_1702 = 0x6E5D5AC5L;
                int32_t l_1703[8] = {3L,7L,7L,3L,7L,7L,3L,7L};
                int i;
                for (l_708 = 3; (l_708 >= 0); l_708 -= 1)
                { /* block id: 775 */
                    uint32_t ***l_1689 = &l_1687;
                    uint32_t **l_1691 = &l_1688;
                    uint32_t ***l_1690 = &l_1691;
                    int i;
                    (**l_244) = 0xBFBB1851L;
                    (*l_1690) = ((*l_1689) = l_1687);
                    return l_1386[(l_708 + 2)];
                }
                ++l_1704;
            }
            else
            { /* block id: 782 */
                int32_t l_1719 = (-1L);
                uint16_t *l_1720 = &l_707[1][0][3];
                int32_t *l_1721 = &l_171;
                int32_t l_1723[2][5][5] = {{{0x3932B1B1L,0x1D60570FL,1L,0x1D60570FL,0x3932B1B1L},{0xBDDB99E7L,0x1D60570FL,(-2L),0x14C341CDL,0x3932B1B1L},{0x3932B1B1L,0x14C341CDL,(-2L),0x1D60570FL,0xBDDB99E7L},{0x3932B1B1L,0x1D60570FL,1L,0x1D60570FL,0x3932B1B1L},{0xBDDB99E7L,0x1D60570FL,(-2L),0x14C341CDL,0x3932B1B1L}},{{0x3932B1B1L,0x14C341CDL,(-2L),0x1D60570FL,0xBDDB99E7L},{0x3932B1B1L,0x1D60570FL,1L,0x1D60570FL,0x3932B1B1L},{0xBDDB99E7L,0x1D60570FL,(-2L),0x14C341CDL,0x3932B1B1L},{0x3932B1B1L,0x14C341CDL,(-2L),0x1D60570FL,0xBDDB99E7L},{0x3932B1B1L,0x1D60570FL,1L,0x1D60570FL,0x3932B1B1L}}};
                union U0 l_1732[5][2][1] = {{{{0L}},{{0x01FB4866021AC6E8LL}}},{{{0L}},{{0x01FB4866021AC6E8LL}}},{{{0L}},{{0x01FB4866021AC6E8LL}}},{{{0L}},{{0x01FB4866021AC6E8LL}}},{{{0L}},{{0x01FB4866021AC6E8LL}}}};
                int i, j, k;
                l_1723[1][4][2] = (((*l_538) |= 0xA4L) | ((l_1686[9][5] ^ (safe_add_func_int32_t_s_s((safe_sub_func_int64_t_s_s((+((*l_598) = ((((((((((*l_1721) &= (g_213 , (safe_mod_func_uint32_t_u_u((((((~(g_506 ^= l_1697)) , ((*l_245) = (safe_mod_func_uint16_t_u_u(((*l_1720) = ((l_1692 < (((*g_143) | (((l_1719 | (((*l_1109) = &g_249[5]) == (void*)0)) | 1L) , 0x505C0CB1L)) ^ 0xE244L)) , g_267)), 5UL)))) > l_1700[0]) , (*g_521)) & l_1719), 0x71B18BD5L)))) , 0x5C0BL) <= g_296) && (**g_1010)) & l_1719) <= 8L) ^ 0x6152B0FCF3F372C9LL) < l_1383) < l_1722[1][5]))), 0UL)), l_1546[0]))) & l_1373[3][0][0]));
                for (l_708 = 0; (l_708 < (-12)); --l_708)
                { /* block id: 793 */
                    uint16_t l_1731 = 0x8AF5L;
                    int32_t l_1734 = (-8L);
                    const int64_t ****l_1749 = (void*)0;
                    const int64_t ***l_1751 = (void*)0;
                    const int64_t ****l_1750 = &l_1751;
                    (***l_243) = ((~(safe_add_func_int64_t_s_s(l_1546[0], (0x02E4L == (((((&l_1345 != (void*)0) , (safe_mul_func_uint16_t_u_u((l_1694[4] >= ((*l_1571) ^= ((0x9C52L >= 0x0715L) < l_1731))), ((l_1733 = l_1732[0][1][0]) , l_1666)))) ^ 0xB9L) , l_1723[0][2][4]) < 4L))))) ^ l_1257);
                    l_1734 |= (*g_632);
                    l_1692 = ((**l_244) = (safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint16_t_u_s((safe_rshift_func_int64_t_s_u((((!l_1697) != ((safe_rshift_func_int32_t_s_s((safe_rshift_func_int32_t_s_s((safe_lshift_func_int16_t_s_u((((*l_598) , l_1748[1]) == (g_1752 = ((*l_1750) = (void*)0))), 13)), 13)), 28)) , ((safe_add_func_int64_t_s_s((((l_1723[1][1][0] , l_1732[0][1][0].f0) , &g_1117) != ((l_1099 != (safe_add_func_uint8_t_u_u((**l_244), 0L))) , l_1759[0][6])), (*g_521))) != l_1257))) < 0x67F4F613L), (**g_248))), 11)), 4)));
                }
            }
            for (l_659 = 0; (l_659 >= 0); l_659 -= 1)
            { /* block id: 806 */
                uint16_t *l_1784 = &l_1677;
                uint32_t ***l_1786[1];
                int32_t l_1791 = 1L;
                int32_t l_1792 = 0x0B2D5979L;
                uint16_t l_1860 = 1UL;
                int i;
                for (i = 0; i < 1; i++)
                    l_1786[i] = (void*)0;
            }
            for (l_171 = 0; (l_171 > (-26)); l_171 = safe_sub_func_int32_t_s_s(l_171, 4))
            { /* block id: 865 */
                (***l_243) = l_1846[0][1];
                (*l_598) ^= (*g_143);
                if ((*g_1011))
                    continue;
            }
        }
    }
    return (**g_248);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_28.f0, "g_28.f0", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_82[i][j][k], "g_82[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_103.f0, "g_103.f0", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_176, "g_176", print_hash_value);
    transparent_crc(g_179, "g_179", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_186[i][j], "g_186[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_197[i], "g_197[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_201[i][j][k], "g_201[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_202, "g_202", print_hash_value);
    transparent_crc(g_213, "g_213", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_241[i], "g_241[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_267, "g_267", print_hash_value);
    transparent_crc(g_268, "g_268", print_hash_value);
    transparent_crc(g_296, "g_296", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_335[i], "g_335[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_425, "g_425", print_hash_value);
    transparent_crc(g_436, "g_436", print_hash_value);
    transparent_crc(g_506, "g_506", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_522[i], "g_522[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_585, "g_585", print_hash_value);
    transparent_crc(g_600, "g_600", print_hash_value);
    transparent_crc(g_635, "g_635", print_hash_value);
    transparent_crc(g_658, "g_658", print_hash_value);
    transparent_crc(g_811.f0, "g_811.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_887[i][j][k], "g_887[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1017, "g_1017", print_hash_value);
    transparent_crc(g_1097, "g_1097", print_hash_value);
    transparent_crc(g_1300, "g_1300", print_hash_value);
    transparent_crc(g_1353.f0, "g_1353.f0", print_hash_value);
    transparent_crc(g_1459, "g_1459", print_hash_value);
    transparent_crc(g_1808, "g_1808", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1879[i][j][k], "g_1879[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1931, "g_1931", print_hash_value);
    transparent_crc(g_1971, "g_1971", print_hash_value);
    transparent_crc(g_2032, "g_2032", print_hash_value);
    transparent_crc(g_2202, "g_2202", print_hash_value);
    transparent_crc(g_2345, "g_2345", print_hash_value);
    transparent_crc(g_2431, "g_2431", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2541[i], "g_2541[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2600, "g_2600", print_hash_value);
    transparent_crc(g_2638, "g_2638", print_hash_value);
    transparent_crc(g_2641, "g_2641", print_hash_value);
    transparent_crc(g_2740, "g_2740", print_hash_value);
    transparent_crc(g_2844, "g_2844", print_hash_value);
    transparent_crc(g_2897, "g_2897", print_hash_value);
    transparent_crc(g_2949, "g_2949", print_hash_value);
    transparent_crc(g_3031, "g_3031", print_hash_value);
    transparent_crc(g_3275, "g_3275", print_hash_value);
    transparent_crc(g_3356, "g_3356", print_hash_value);
    transparent_crc(g_3388, "g_3388", print_hash_value);
    transparent_crc(g_3390, "g_3390", print_hash_value);
    transparent_crc(g_3421, "g_3421", print_hash_value);
    transparent_crc(g_3653, "g_3653", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_3708[i][j][k], "g_3708[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3800, "g_3800", print_hash_value);
    transparent_crc(g_4079, "g_4079", print_hash_value);
    transparent_crc(g_4140, "g_4140", print_hash_value);
    transparent_crc(g_4246, "g_4246", print_hash_value);
    transparent_crc(g_4450, "g_4450", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_4454[i][j], "g_4454[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4571, "g_4571", print_hash_value);
    transparent_crc(g_4572, "g_4572", print_hash_value);
    transparent_crc(g_4673, "g_4673", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_4692[i], "g_4692[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4782, "g_4782", print_hash_value);
    transparent_crc(g_5016, "g_5016", print_hash_value);
    transparent_crc(g_5046, "g_5046", print_hash_value);
    transparent_crc(g_5196, "g_5196", print_hash_value);
    transparent_crc(g_5205, "g_5205", print_hash_value);
    transparent_crc(g_5257, "g_5257", print_hash_value);
    transparent_crc(g_5360, "g_5360", print_hash_value);
    transparent_crc(g_5479, "g_5479", print_hash_value);
    transparent_crc(g_5506, "g_5506", print_hash_value);
    transparent_crc(g_5543, "g_5543", print_hash_value);
    transparent_crc(g_5599, "g_5599", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_5821[i][j][k].f0, "g_5821[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_5837, "g_5837", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_5862[i], "g_5862[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5866, "g_5866", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1544
XXX total union variables: 42

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 793
   depth: 2, occurrence: 198
   depth: 3, occurrence: 17
   depth: 4, occurrence: 7
   depth: 5, occurrence: 9
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 4
   depth: 10, occurrence: 1
   depth: 11, occurrence: 3
   depth: 13, occurrence: 3
   depth: 14, occurrence: 5
   depth: 15, occurrence: 3
   depth: 16, occurrence: 11
   depth: 17, occurrence: 3
   depth: 18, occurrence: 8
   depth: 19, occurrence: 10
   depth: 20, occurrence: 9
   depth: 21, occurrence: 14
   depth: 22, occurrence: 5
   depth: 23, occurrence: 10
   depth: 24, occurrence: 8
   depth: 25, occurrence: 4
   depth: 26, occurrence: 5
   depth: 27, occurrence: 10
   depth: 28, occurrence: 6
   depth: 29, occurrence: 5
   depth: 30, occurrence: 2
   depth: 31, occurrence: 4
   depth: 32, occurrence: 5
   depth: 33, occurrence: 2
   depth: 34, occurrence: 2
   depth: 35, occurrence: 1
   depth: 36, occurrence: 4
   depth: 37, occurrence: 3
   depth: 38, occurrence: 3
   depth: 40, occurrence: 4
   depth: 42, occurrence: 1
   depth: 51, occurrence: 2

XXX total number of pointers: 1108

XXX times a variable address is taken: 2897
XXX times a pointer is dereferenced on RHS: 980
breakdown:
   depth: 1, occurrence: 710
   depth: 2, occurrence: 176
   depth: 3, occurrence: 47
   depth: 4, occurrence: 40
   depth: 5, occurrence: 7
XXX times a pointer is dereferenced on LHS: 703
breakdown:
   depth: 1, occurrence: 549
   depth: 2, occurrence: 103
   depth: 3, occurrence: 35
   depth: 4, occurrence: 10
   depth: 5, occurrence: 6
XXX times a pointer is compared with null: 122
XXX times a pointer is compared with address of another variable: 25
XXX times a pointer is compared with another pointer: 38
XXX times a pointer is qualified to be dereferenced: 25001

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2745
   level: 2, occurrence: 1005
   level: 3, occurrence: 459
   level: 4, occurrence: 388
   level: 5, occurrence: 197
XXX number of pointers point to pointers: 590
XXX number of pointers point to scalars: 486
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 27.4
XXX average alias set size: 1.43

XXX times a non-volatile is read: 5145
XXX times a non-volatile is write: 2368
XXX times a volatile is read: 197
XXX    times read thru a pointer: 65
XXX times a volatile is write: 68
XXX    times written thru a pointer: 22
XXX times a volatile is available for access: 4.7e+03
XXX percentage of non-volatile access: 96.6

XXX forward jumps: 7
XXX backward jumps: 28

XXX stmts: 795
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 35
   depth: 1, occurrence: 65
   depth: 2, occurrence: 102
   depth: 3, occurrence: 156
   depth: 4, occurrence: 190
   depth: 5, occurrence: 247

XXX percentage a fresh-made variable is used: 14.7
XXX percentage an existing variable is used: 85.3
XXX total OOB instances added: 0
********************* end of statistics **********************/

