/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: deddca6
 * Options:   (none)
 * Seed:      128114324
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile signed f0 : 24;
   volatile int8_t  f1;
   unsigned f2 : 5;
   signed f3 : 19;
   int32_t  f4;
};

union U1 {
   uint8_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_31 = 18446744073709551611UL;
static volatile union U0 g_46[8] = {{-9L},{-9L},{-9L},{-9L},{-9L},{-9L},{-9L},{-9L}};
static union U1 g_55 = {5UL};
static int32_t g_63 = 1L;
static int32_t * const g_62 = &g_63;
static int16_t g_75 = 0x6DC3L;
static int16_t g_77 = 0xAA04L;
static uint8_t g_80 = 0x53L;
static uint64_t g_85 = 0xEEACC2001377BC7ALL;
static union U0 g_113 = {-1L};/* VOLATILE GLOBAL g_113 */
static int32_t g_117 = (-10L);
static int32_t * volatile g_116 = &g_117;/* VOLATILE GLOBAL g_116 */
static union U0 g_123 = {-1L};/* VOLATILE GLOBAL g_123 */
static union U1 *g_181 = &g_55;
static union U1 **g_180 = &g_181;
static int32_t *g_190 = &g_117;
static int32_t ** volatile g_189 = &g_190;/* VOLATILE GLOBAL g_189 */
static volatile int32_t g_201 = 0x7BAAA9AAL;/* VOLATILE GLOBAL g_201 */
static volatile int32_t g_203[8][10][3] = {{{0xED1C8C2AL,(-1L),0xDADCB936L},{3L,0xFCEC19F9L,0xE91CA70FL},{0xB666E459L,1L,(-1L)},{0x16B02DDAL,(-3L),0x4A36DFC6L},{0x16B02DDAL,0xD07CE890L,3L},{0xB666E459L,0x6FF05A5CL,(-1L)},{3L,0x7E1829C3L,0x54029CE5L},{0xED1C8C2AL,(-1L),(-10L)},{(-4L),0x7CAA2243L,7L},{0x6D7AE1D0L,1L,0x7561C6BEL}},{{0xF4C25973L,0x51558E0FL,0xD6875EE9L},{0xD6875EE9L,0xC1F0966BL,0x6F6F0179L},{1L,0x16B02DDAL,0x3EEF5A3AL},{0xBD2B6BC9L,0xD3BF737DL,0xD0340F11L},{0x16B02DDAL,0xD0340F11L,(-1L)},{(-10L),0xCC19F950L,0x7561C6BEL},{0xD3BF737DL,1L,0x34840841L},{1L,1L,(-4L)},{7L,(-1L),0xD6875EE9L},{0L,0x6FF05A5CL,0xD41EAB73L}},{{1L,(-4L),0xC1F0966BL},{8L,0L,0xD41EAB73L},{0L,0x202AD850L,0xD6875EE9L},{0xFCEC19F9L,0x34840841L,(-4L)},{0x67738E0FL,0x03736092L,0x34840841L},{0x6FEF38C7L,0x7CAA2243L,0x7561C6BEL},{(-1L),8L,(-1L)},{0x6D7AE1D0L,0L,0xD0340F11L},{(-1L),6L,0x3EEF5A3AL},{(-3L),0x7E1829C3L,0x6D7AE1D0L}},{{0x7561C6BEL,0x4FAA8155L,0x54029CE5L},{(-3L),0x51558E0FL,1L},{1L,0x82E68182L,8L},{0x4A36DFC6L,1L,0xB50047D2L},{8L,(-1L),0xF4C25973L},{0L,1L,0L},{0x93B745A2L,(-1L),0x0774E2FFL},{0x2D6BAA40L,0xFCEC19F9L,(-1L)},{1L,0xFCEC19F9L,0xBD6EBF7BL},{0x4FAA8155L,(-1L),0x67738E0FL}},{{0x8CAC2623L,1L,0x03736092L},{0xD07CE890L,(-1L),0xAF5FF993L},{0x7E1829C3L,1L,8L},{0xE91CA70FL,0x82E68182L,(-1L)},{(-1L),0x51558E0FL,0x36F6A9FAL},{0xBD6EBF7BL,0x4FAA8155L,1L},{1L,0x7E1829C3L,(-8L)},{0xF4B8DB84L,6L,0xD07CE890L},{0x747D80A4L,0L,0xED1C8C2AL},{0x51558E0FL,8L,0xDE72FA70L}},{{1L,0x7CAA2243L,(-3L)},{9L,0x03736092L,9L},{1L,0x34840841L,0xD3BF737DL},{(-1L),0x202AD850L,0xE91CA70FL},{0L,0L,0x2A5F7610L},{1L,(-4L),0xE25FB50DL},{0L,0x6FF05A5CL,0x12841510L},{(-1L),(-1L),5L},{1L,1L,0L},{9L,1L,(-3L)}},{{1L,0xCC19F950L,2L},{0x51558E0FL,0xD0340F11L,0x2D6BAA40L},{0x747D80A4L,0xD3BF737DL,0L},{0xF4B8DB84L,0xC7B1A2CDL,0xDADCB936L},{1L,0L,0xF4B8DB84L},{0xBD6EBF7BL,8L,0x4FAA8155L},{(-1L),0xC1F0966BL,(-8L)},{0xE91CA70FL,(-8L),0x202AD850L},{0x7E1829C3L,0xBD6EBF7BL,1L},{0xD07CE890L,0L,1L}},{{0x8CAC2623L,1L,0x1315DE78L},{0x4FAA8155L,0xD41EAB73L,(-1L)},{1L,0x3A23EFB9L,(-1L)},{0x2D6BAA40L,(-1L),0x1315DE78L},{0x93B745A2L,(-1L),1L},{0L,(-3L),1L},{8L,0x6FF05A5CL,0xFCBFF38EL},{(-1L),1L,0xD0340F11L},{0x7561C6BEL,0x54029CE5L,0x36F6A9FAL},{8L,(-3L),0xA1C93EE8L}}};
static int32_t g_241 = 0L;
static const union U1 g_254 = {5UL};
static const union U1 *g_253 = &g_254;
static const union U1 **g_252 = &g_253;
static const union U1 ***g_251[4][4] = {{&g_252,&g_252,&g_252,&g_252},{&g_252,&g_252,&g_252,&g_252},{&g_252,&g_252,&g_252,&g_252},{&g_252,&g_252,&g_252,&g_252}};
static uint16_t g_267 = 0UL;
static uint32_t g_278 = 0x0DFCB13BL;
static union U1 g_308[1][10] = {{{0x52L},{0x8FL},{0x52L},{0x52L},{0x8FL},{0x52L},{0x52L},{0x8FL},{0x52L},{0x52L}}};
static uint64_t g_321 = 0x8E63CB0EC13243FBLL;
static int32_t g_362 = 0xD83C1E56L;
static volatile uint32_t g_368 = 7UL;/* VOLATILE GLOBAL g_368 */
static int32_t g_430[10][10][2] = {{{0L,0L},{6L,(-7L)},{0x0DA0BF28L,0x8999F5B0L},{0xF6BCE999L,(-10L)},{(-1L),0xEE8459CBL},{0x6124192DL,0x1894A3F9L},{0L,0x6378EC43L},{(-4L),1L},{0xEB36D8EEL,0xF9C2642BL},{0L,1L}},{{0x6124192DL,1L},{0x914B85F4L,1L},{7L,0x8999F5B0L},{6L,0x0B9E2747L},{0x03A97DAFL,(-7L)},{0L,0L},{0x34D8D64DL,1L},{(-1L),1L},{0x6378EC43L,0x0B510125L},{0L,0x6378EC43L}},{{1L,(-10L)},{1L,0x6378EC43L},{0L,0x0B510125L},{0x6378EC43L,1L},{(-1L),1L},{0x34D8D64DL,0L},{0L,(-7L)},{0x03A97DAFL,0x0B9E2747L},{6L,0x8999F5B0L},{7L,1L}},{{0x914B85F4L,1L},{0x6124192DL,1L},{0L,0xF9C2642BL},{0xEB36D8EEL,1L},{(-4L),0x6378EC43L},{0L,0x1894A3F9L},{0x6124192DL,0xEE8459CBL},{(-1L),(-10L)},{0xF6BCE999L,0x8999F5B0L},{0x0DA0BF28L,(-7L)}},{{6L,0L},{0L,6L},{7L,(-10L)},{1L,1L},{0x8A022494L,1L},{0L,0x6124192DL},{1L,0x05218EBEL},{(-4L),0xF9C2642BL},{(-7L),0x0B510125L},{0x8A022494L,0xEE8459CBL}},{{0x914B85F4L,0x8C82E678L},{0x34D8D64DL,6L},{0x0DA0BF28L,0x0B9E2747L},{0xCE228824L,0x0B9E2747L},{0x0DA0BF28L,6L},{0x34D8D64DL,0x8C82E678L},{0x914B85F4L,0xEE8459CBL},{0x8A022494L,0x0B510125L},{(-7L),0xF9C2642BL},{(-4L),0x05218EBEL}},{{1L,0x6124192DL},{0L,1L},{0x8A022494L,1L},{1L,(-10L)},{7L,6L},{0L,0L},{6L,(-7L)},{0x0DA0BF28L,0x8999F5B0L},{0xF6BCE999L,(-10L)},{(-1L),0xEE8459CBL}},{{0x6124192DL,0x1894A3F9L},{0L,0x6378EC43L},{(-4L),1L},{0xEB36D8EEL,0xF9C2642BL},{0L,1L},{0x6124192DL,1L},{0x914B85F4L,0xBE10AED1L},{0xBC4F6B61L,(-10L)},{0x94870DFBL,6L},{0xF4BEFF6FL,0x03A97DAFL}},{{0x05218EBEL,0x05218EBEL},{1L,0xBE10AED1L},{8L,0L},{7L,(-1L)},{0x8A1492C3L,7L},{0xEE8459CBL,0x6378EC43L},{0xEE8459CBL,7L},{0x8A1492C3L,(-1L)},{7L,0L},{8L,0xBE10AED1L}},{{1L,0x05218EBEL},{0x05218EBEL,0x03A97DAFL},{0xF4BEFF6FL,6L},{0x94870DFBL,(-10L)},{0xBC4F6B61L,0xBE10AED1L},{0xEB36D8EEL,(-7L)},{0xF6BCE999L,(-1L)},{0x8A1492C3L,0x34D8D64DL},{1L,0x6124192DL},{0x5824F430L,7L}}};
static int32_t *g_484 = &g_113.f4;
static uint32_t g_527 = 0xCB4B90D1L;
static const int32_t g_542 = 0x5EF36D9DL;
static const int32_t g_544 = 0xB1979AECL;
static const int32_t *g_543 = &g_544;
static union U0 g_560[7] = {{0xE3D3D516L},{0xE3D3D516L},{0xE3D3D516L},{0xE3D3D516L},{0xE3D3D516L},{0xE3D3D516L},{0xE3D3D516L}};
static uint8_t g_571 = 0x18L;
static int32_t g_596 = 0L;
static uint8_t g_613 = 0xE6L;
static int32_t g_614 = 0L;
static volatile uint16_t g_619 = 9UL;/* VOLATILE GLOBAL g_619 */
static volatile uint32_t g_633 = 0x97F16B0BL;/* VOLATILE GLOBAL g_633 */
static uint16_t *g_662 = &g_267;
static union U0 g_682 = {1L};/* VOLATILE GLOBAL g_682 */
static const uint64_t g_689 = 1UL;
static const volatile int8_t ** const g_730 = (void*)0;
static volatile int8_t g_733[3] = {1L,1L,1L};
static const volatile int8_t *g_732 = &g_733[1];
static const volatile int8_t **g_731 = &g_732;
static int64_t g_746 = 1L;
static uint64_t g_764 = 0x24030010A794DB4DLL;
static int32_t g_797 = (-1L);
static union U0 g_822 = {0xE868DD62L};/* VOLATILE GLOBAL g_822 */
static volatile uint64_t g_828 = 18446744073709551615UL;/* VOLATILE GLOBAL g_828 */
static volatile uint64_t *g_827 = &g_828;
static volatile uint64_t * volatile *g_826 = &g_827;
static volatile uint64_t * volatile * volatile * volatile g_825 = &g_826;/* VOLATILE GLOBAL g_825 */
static volatile union U0 g_833 = {0L};/* VOLATILE GLOBAL g_833 */
static int64_t g_846 = 0x7CCD9682FFDAE55ELL;
static int64_t g_847 = 0x40A6C95DB31CEC28LL;
static const uint64_t *g_878 = &g_689;
static const uint64_t **g_877 = &g_878;
static const uint64_t ***g_876 = &g_877;
static const uint64_t ****g_875 = &g_876;
static int32_t ** volatile g_885 = &g_190;/* VOLATILE GLOBAL g_885 */
static int16_t g_904 = 0xF17AL;
static union U0 *g_924 = (void*)0;
static int32_t ** volatile g_953 = &g_190;/* VOLATILE GLOBAL g_953 */
static int16_t *g_969 = &g_904;
static int16_t ** volatile g_968 = &g_969;/* VOLATILE GLOBAL g_968 */
static int16_t ** volatile * volatile g_971 = &g_968;/* VOLATILE GLOBAL g_971 */
static int8_t **g_1060 = (void*)0;
static int8_t ***g_1059 = &g_1060;
static const union U0 ** volatile g_1087 = (void*)0;/* VOLATILE GLOBAL g_1087 */
static const union U0 *g_1088 = (void*)0;
static int32_t *g_1139[1] = {&g_614};
static int32_t ** volatile g_1140 = &g_1139[0];/* VOLATILE GLOBAL g_1140 */
static uint64_t *g_1151 = &g_764;
static uint64_t **g_1150[5] = {&g_1151,&g_1151,&g_1151,&g_1151,&g_1151};
static union U0 g_1164 = {-7L};/* VOLATILE GLOBAL g_1164 */
static union U0 g_1191 = {-6L};/* VOLATILE GLOBAL g_1191 */
static int32_t g_1256 = 0xADE87553L;
static int32_t ** volatile g_1263 = (void*)0;/* VOLATILE GLOBAL g_1263 */
static int32_t ** volatile g_1264 = &g_1139[0];/* VOLATILE GLOBAL g_1264 */
static const volatile union U0 g_1315[5] = {{-1L},{-1L},{-1L},{-1L},{-1L}};
static int8_t g_1329 = 1L;
static int64_t *g_1358 = &g_846;
static int64_t * const  volatile *g_1357 = &g_1358;
static union U1 *****g_1400 = (void*)0;
static union U0 g_1411 = {1L};/* VOLATILE GLOBAL g_1411 */
static int16_t ***g_1424 = (void*)0;
static const int16_t *g_1427[7] = {&g_75,(void*)0,&g_75,&g_75,(void*)0,&g_75,&g_75};
static const int16_t **g_1426[2][6] = {{&g_1427[3],&g_1427[3],(void*)0,&g_1427[3],&g_1427[3],(void*)0},{&g_1427[3],&g_1427[3],(void*)0,&g_1427[3],&g_1427[3],(void*)0}};
static const int16_t ***g_1425 = &g_1426[1][1];
static int32_t ** volatile g_1431 = (void*)0;/* VOLATILE GLOBAL g_1431 */
static int32_t ** volatile g_1432 = &g_1139[0];/* VOLATILE GLOBAL g_1432 */
static volatile union U0 g_1486 = {-6L};/* VOLATILE GLOBAL g_1486 */
static uint32_t g_1496 = 0x0F0C3269L;
static volatile union U0 g_1497 = {0xAF661341L};/* VOLATILE GLOBAL g_1497 */
static int32_t g_1578 = 0x32BB4F0AL;
static int32_t ** volatile g_1625 = &g_1139[0];/* VOLATILE GLOBAL g_1625 */
static uint8_t g_1658[1] = {255UL};
static int16_t g_1681[2][9] = {{8L,(-1L),0L,0L,(-1L),8L,(-1L),0L,0L},{0xAF08L,0xAF08L,8L,0L,8L,0xAF08L,0xAF08L,8L,0L}};
static uint16_t *g_1732 = &g_267;
static int32_t ** volatile g_1735 = &g_190;/* VOLATILE GLOBAL g_1735 */
static union U0 g_1788 = {0xAF04952EL};/* VOLATILE GLOBAL g_1788 */
static int32_t ** volatile g_1831[4][2][5] = {{{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190},{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190}},{{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190},{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190}},{{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190},{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190}},{{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190},{&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_190}}};
static int32_t ** volatile g_1846 = &g_190;/* VOLATILE GLOBAL g_1846 */
static uint32_t g_1935 = 4294967290UL;
static uint32_t g_1937[3] = {4294967295UL,4294967295UL,4294967295UL};
static uint32_t g_1939[2] = {0xCE687C81L,0xCE687C81L};
static union U0 ** volatile g_1942[2] = {&g_924,&g_924};
static const volatile union U0 g_1978 = {6L};/* VOLATILE GLOBAL g_1978 */
static uint32_t *g_1998 = &g_1939[1];
static uint32_t ** volatile g_1997 = &g_1998;/* VOLATILE GLOBAL g_1997 */
static int32_t ** volatile g_1999 = (void*)0;/* VOLATILE GLOBAL g_1999 */
static int32_t ** volatile g_2000[9][2][10] = {{{&g_1139[0],&g_1139[0],(void*)0,&g_1139[0],(void*)0,&g_190,(void*)0,&g_1139[0],(void*)0,&g_1139[0]},{&g_1139[0],&g_1139[0],&g_190,&g_190,&g_1139[0],&g_190,&g_190,&g_190,&g_190,&g_190}},{{&g_190,&g_190,&g_190,&g_190,&g_190,&g_190,(void*)0,(void*)0,(void*)0,(void*)0},{&g_1139[0],&g_1139[0],&g_190,(void*)0,&g_1139[0],&g_190,&g_190,&g_190,(void*)0,&g_1139[0]}},{{&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190,&g_1139[0],(void*)0,&g_1139[0],&g_1139[0],(void*)0},{&g_1139[0],(void*)0,&g_1139[0],&g_1139[0],(void*)0,&g_1139[0],(void*)0,&g_1139[0],&g_1139[0],&g_190}},{{&g_1139[0],(void*)0,&g_190,&g_1139[0],(void*)0,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190},{&g_1139[0],&g_190,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190,(void*)0,(void*)0,&g_190}},{{&g_1139[0],&g_190,(void*)0,(void*)0,&g_190,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190},{&g_1139[0],&g_190,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],(void*)0,&g_1139[0],&g_190,(void*)0}},{{&g_1139[0],&g_190,&g_1139[0],&g_1139[0],(void*)0,&g_1139[0],(void*)0,&g_1139[0],&g_1139[0],(void*)0},{&g_1139[0],(void*)0,&g_1139[0],&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_1139[0],&g_1139[0],&g_1139[0]}},{{&g_1139[0],&g_1139[0],(void*)0,&g_1139[0],&g_190,&g_1139[0],&g_190,(void*)0,&g_1139[0],&g_190},{&g_1139[0],(void*)0,(void*)0,(void*)0,(void*)0,&g_1139[0],&g_190,&g_1139[0],&g_1139[0],&g_1139[0]}},{{&g_1139[0],&g_190,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190,&g_1139[0],&g_1139[0],(void*)0},{&g_1139[0],(void*)0,&g_190,&g_1139[0],(void*)0,&g_1139[0],(void*)0,&g_1139[0],&g_190,(void*)0}},{{&g_1139[0],(void*)0,&g_1139[0],&g_1139[0],&g_190,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190},{&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190,&g_1139[0],(void*)0,(void*)0,(void*)0,(void*)0}}};
static volatile union U0 g_2158[10] = {{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L}};
static int32_t ** volatile g_2222[6][2][10] = {{{&g_190,(void*)0,&g_190,&g_190,&g_190,(void*)0,&g_190,&g_1139[0],&g_1139[0],&g_1139[0]},{&g_190,&g_1139[0],&g_1139[0],(void*)0,(void*)0,&g_1139[0],&g_1139[0],&g_190,&g_190,&g_1139[0]}},{{&g_1139[0],&g_1139[0],&g_190,&g_190,&g_1139[0],&g_190,&g_190,&g_1139[0],&g_1139[0],(void*)0},{&g_190,(void*)0,&g_190,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190,(void*)0,&g_1139[0]}},{{&g_1139[0],(void*)0,(void*)0,&g_1139[0],&g_190,&g_1139[0],&g_190,&g_1139[0],(void*)0,(void*)0},{&g_190,&g_1139[0],&g_1139[0],(void*)0,&g_190,&g_190,&g_190,&g_190,(void*)0,&g_1139[0]}},{{&g_190,&g_190,&g_1139[0],&g_190,&g_190,&g_190,(void*)0,&g_190,&g_190,&g_190},{&g_190,&g_1139[0],&g_190,&g_190,&g_1139[0],&g_1139[0],(void*)0,(void*)0,&g_1139[0],&g_1139[0]}},{{&g_1139[0],&g_190,&g_190,&g_1139[0],&g_190,&g_190,&g_190,(void*)0,&g_190,&g_190},{&g_1139[0],&g_1139[0],&g_190,&g_1139[0],&g_1139[0],(void*)0,&g_190,&g_190,&g_190,&g_190}},{{(void*)0,(void*)0,&g_1139[0],&g_1139[0],(void*)0,(void*)0,&g_1139[0],&g_190,&g_1139[0],&g_190},{&g_1139[0],&g_1139[0],&g_1139[0],&g_190,&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_190,&g_190}}};
static volatile union U0 * volatile *** volatile g_2238 = (void*)0;/* VOLATILE GLOBAL g_2238 */
static union U0 **g_2267 = &g_924;
static int32_t ** volatile g_2299 = &g_1139[0];/* VOLATILE GLOBAL g_2299 */
static volatile union U0 g_2311 = {0x00BF5F1DL};/* VOLATILE GLOBAL g_2311 */
static int16_t * const * volatile g_2489 = (void*)0;/* VOLATILE GLOBAL g_2489 */
static int16_t * const * volatile * volatile g_2488 = &g_2489;/* VOLATILE GLOBAL g_2488 */
static int16_t * const * volatile * volatile * const g_2487 = &g_2488;
static int16_t * const * volatile * volatile * const *g_2486 = &g_2487;
static volatile union U0 g_2511 = {0x5B0738ACL};/* VOLATILE GLOBAL g_2511 */
static union U1 g_2586 = {255UL};
static union U1 * const g_2585 = &g_2586;
static union U1 * const *g_2584 = &g_2585;
static union U1 * const **g_2583 = &g_2584;
static union U1 * const ***g_2582 = &g_2583;
static const uint64_t *****g_2682 = &g_875;
static volatile uint16_t * volatile * const  volatile *g_2834 = (void*)0;
static volatile uint16_t * volatile * const  volatile ** volatile g_2835 = &g_2834;/* VOLATILE GLOBAL g_2835 */
static int8_t g_2882 = 0x08L;
static int8_t ***g_2897 = &g_1060;
static int8_t **** const g_2896 = &g_2897;
static int8_t **** const *g_2895[1] = {&g_2896};
static const int8_t *****g_2948 = (void*)0;
static volatile int32_t * volatile g_2957 = &g_203[6][4][1];/* VOLATILE GLOBAL g_2957 */
static volatile int32_t * volatile * const  volatile g_2958 = &g_2957;/* VOLATILE GLOBAL g_2958 */
static int8_t g_2962 = 0L;
static union U1 ***g_3010 = (void*)0;
static volatile union U0 g_3015 = {0x0A30F2A6L};/* VOLATILE GLOBAL g_3015 */
static volatile union U0 g_3033 = {0x7C3500DAL};/* VOLATILE GLOBAL g_3033 */
static union U0 g_3058[5] = {{0xEA88301DL},{0xEA88301DL},{0xEA88301DL},{0xEA88301DL},{0xEA88301DL}};
static union U0 g_3069[6] = {{2L},{0x92AA31E2L},{0x92AA31E2L},{2L},{0x92AA31E2L},{0x92AA31E2L}};
static const union U0 ** volatile g_3147[8] = {&g_1088,&g_1088,&g_1088,&g_1088,&g_1088,&g_1088,&g_1088,&g_1088};
static volatile union U0 g_3164 = {0L};/* VOLATILE GLOBAL g_3164 */
static union U1 g_3183[4][4][5] = {{{{247UL},{247UL},{6UL},{6UL},{247UL}},{{255UL},{0x9AL},{255UL},{0x9AL},{255UL}},{{247UL},{6UL},{6UL},{247UL},{247UL}},{{0UL},{0x9AL},{0UL},{0x9AL},{0UL}}},{{{247UL},{247UL},{6UL},{6UL},{247UL}},{{255UL},{0x9AL},{255UL},{0x9AL},{255UL}},{{247UL},{6UL},{6UL},{247UL},{247UL}},{{0UL},{0x9AL},{0UL},{0x9AL},{0UL}}},{{{247UL},{247UL},{6UL},{6UL},{247UL}},{{255UL},{0x9AL},{255UL},{0x9AL},{255UL}},{{247UL},{6UL},{6UL},{247UL},{247UL}},{{0UL},{0x9AL},{0UL},{0x9AL},{0UL}}},{{{247UL},{247UL},{6UL},{6UL},{247UL}},{{255UL},{0x9AL},{255UL},{0x9AL},{255UL}},{{247UL},{6UL},{6UL},{247UL},{247UL}},{{0UL},{0x9AL},{0UL},{0x9AL},{0UL}}}};
static union U1 * const g_3182[3] = {&g_3183[1][3][0],&g_3183[1][3][0],&g_3183[1][3][0]};
static union U1 * const * const g_3181 = &g_3182[2];
static union U1 * const * const *g_3180 = &g_3181;
static union U1 * const * const **g_3179[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U1 * const * const ***g_3178 = &g_3179[4];
static int64_t g_3212 = 0x08EF732A4F4EB318LL;
static volatile union U0 g_3224 = {-1L};/* VOLATILE GLOBAL g_3224 */
static volatile union U1 g_3225 = {0xD4L};/* VOLATILE GLOBAL g_3225 */
static int32_t ** volatile g_3255 = &g_1139[0];/* VOLATILE GLOBAL g_3255 */
static uint16_t g_3286 = 0UL;
static const volatile union U0 g_3294 = {1L};/* VOLATILE GLOBAL g_3294 */
static union U0 g_3302[6] = {{0x473495ACL},{0x473495ACL},{0x473495ACL},{0x473495ACL},{0x473495ACL},{0x473495ACL}};
static const uint16_t *g_3326 = &g_3286;
static const uint16_t **g_3325 = &g_3326;
static const uint16_t ***g_3324 = &g_3325;
static const uint16_t ****g_3323 = &g_3324;
static uint32_t g_3411 = 0UL;
static union U0 g_3418[4] = {{0x76E0538AL},{0x76E0538AL},{0x76E0538AL},{0x76E0538AL}};
static const volatile uint16_t * volatile g_3522 = &g_619;/* VOLATILE GLOBAL g_3522 */
static const volatile uint16_t * volatile *g_3521 = &g_3522;
static const volatile uint16_t * volatile **g_3520[7] = {&g_3521,&g_3521,&g_3521,&g_3521,&g_3521,&g_3521,&g_3521};
static volatile uint8_t g_3523 = 0x21L;/* VOLATILE GLOBAL g_3523 */
static union U0 g_3548 = {-1L};/* VOLATILE GLOBAL g_3548 */
static int32_t ** volatile g_3567 = &g_1139[0];/* VOLATILE GLOBAL g_3567 */
static volatile union U0 g_3579[9] = {{-6L},{0x5B640F0BL},{-6L},{0x5B640F0BL},{-6L},{0x5B640F0BL},{-6L},{0x5B640F0BL},{-6L}};
static int32_t ** volatile g_3602 = &g_190;/* VOLATILE GLOBAL g_3602 */
static volatile union U0 g_3615[3] = {{0x129783CDL},{0x129783CDL},{0x129783CDL}};
static uint64_t * const g_3638 = (void*)0;
static uint64_t * const *g_3637 = &g_3638;
static uint64_t * const **g_3636 = &g_3637;
static uint64_t * const ***g_3635[9] = {&g_3636,&g_3636,&g_3636,&g_3636,&g_3636,&g_3636,&g_3636,&g_3636,&g_3636};
static uint64_t * const ****g_3634 = &g_3635[0];
static union U0 ***g_3707 = &g_2267;
static union U0 ****g_3706[2][1][4] = {{{&g_3707,&g_3707,&g_3707,&g_3707}},{{&g_3707,&g_3707,&g_3707,&g_3707}}};
static int32_t ** volatile g_3724[4][4] = {{&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0]},{&g_190,&g_190,&g_190,&g_1139[0]},{&g_1139[0],&g_1139[0],&g_190,&g_1139[0]},{&g_190,&g_1139[0],&g_1139[0],&g_190}};
static union U0 g_3781 = {0xDF0FB4BCL};/* VOLATILE GLOBAL g_3781 */
static union U0 g_3821 = {6L};/* VOLATILE GLOBAL g_3821 */
static int32_t **g_3834[2][9][5] = {{{(void*)0,&g_484,&g_484,&g_484,&g_484},{&g_484,&g_484,(void*)0,&g_484,&g_484},{&g_484,&g_484,&g_484,&g_484,&g_484},{&g_484,&g_484,&g_484,&g_484,&g_484},{(void*)0,&g_484,(void*)0,&g_484,&g_484},{&g_484,&g_484,&g_484,&g_484,&g_484},{&g_484,&g_484,&g_484,(void*)0,&g_484},{&g_484,&g_484,&g_484,(void*)0,(void*)0},{(void*)0,&g_484,(void*)0,&g_484,&g_484}},{{&g_484,&g_484,&g_484,&g_484,(void*)0},{&g_484,&g_484,&g_484,&g_484,(void*)0},{&g_484,&g_484,&g_484,(void*)0,&g_484},{(void*)0,&g_484,(void*)0,&g_484,(void*)0},{&g_484,&g_484,&g_484,(void*)0,&g_484},{&g_484,&g_484,&g_484,&g_484,&g_484},{(void*)0,&g_484,&g_484,&g_484,&g_484},{&g_484,&g_484,(void*)0,&g_484,(void*)0},{&g_484,&g_484,&g_484,(void*)0,&g_484}}};
static int32_t ***g_3833 = &g_3834[1][3][1];
static int32_t ****g_3832 = &g_3833;
static volatile union U0 g_3926 = {0xB170A5E2L};/* VOLATILE GLOBAL g_3926 */
static uint8_t * volatile g_4020 = &g_55.f0;/* VOLATILE GLOBAL g_4020 */
static uint8_t * volatile *g_4019 = &g_4020;
static int64_t g_4027 = 1L;
static union U0 g_4028 = {-1L};/* VOLATILE GLOBAL g_4028 */
static uint32_t g_4045 = 0UL;
static volatile uint64_t g_4055 = 0UL;/* VOLATILE GLOBAL g_4055 */
static uint8_t g_4095 = 0x61L;
static union U1 g_4100 = {7UL};
static int16_t **g_4106[4] = {&g_969,&g_969,&g_969,&g_969};
static int8_t g_4121 = (-8L);
static const uint16_t g_4164[5][4][8] = {{{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL},{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL}},{{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL},{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL}},{{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL},{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL}},{{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL},{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL}},{{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL},{9UL,9UL,0x54EAL,65535UL,0UL,2UL,0UL,0x308FL},{65535UL,9UL,0x308FL,65535UL,2UL,2UL,65535UL,0x308FL}}};
static union U0 g_4207 = {0L};/* VOLATILE GLOBAL g_4207 */
static uint64_t *****g_4235 = (void*)0;
static const volatile union U0 g_4323 = {0xD0CF8071L};/* VOLATILE GLOBAL g_4323 */
static union U1 ****g_4325 = &g_3010;
static int32_t ** volatile g_4370[9][8][3] = {{{(void*)0,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{(void*)0,&g_190,(void*)0},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190}},{{&g_190,&g_190,&g_190},{(void*)0,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{(void*)0,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190}},{{&g_190,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190},{(void*)0,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,(void*)0},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190}},{{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190}},{{(void*)0,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190},{&g_190,&g_190,&g_190}},{{&g_190,&g_190,&g_190},{(void*)0,&g_190,(void*)0},{&g_190,&g_190,&g_190},{(void*)0,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190},{(void*)0,&g_190,&g_190},{&g_190,&g_190,&g_190}},{{(void*)0,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190}},{{&g_190,&g_190,&g_190},{(void*)0,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,(void*)0}},{{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{&g_190,&g_190,&g_190},{(void*)0,(void*)0,&g_190},{&g_190,&g_190,&g_190},{&g_190,(void*)0,&g_190}}};
static volatile uint32_t g_4447 = 0x6F227B95L;/* VOLATILE GLOBAL g_4447 */
static int64_t **g_4453 = &g_1358;
static int64_t ***g_4452 = &g_4453;
static int64_t **** volatile g_4451 = &g_4452;/* VOLATILE GLOBAL g_4451 */
static volatile union U0 g_4462 = {5L};/* VOLATILE GLOBAL g_4462 */
static const int32_t ** volatile g_4519 = &g_543;/* VOLATILE GLOBAL g_4519 */
static union U0 g_4520 = {0xEC86CE7FL};/* VOLATILE GLOBAL g_4520 */
static int32_t g_4555 = 0xB73F8CB7L;
static int8_t *g_4604 = &g_2882;
static int8_t **g_4603[10][4] = {{&g_4604,&g_4604,&g_4604,(void*)0},{&g_4604,&g_4604,&g_4604,&g_4604},{&g_4604,&g_4604,&g_4604,&g_4604},{&g_4604,&g_4604,(void*)0,&g_4604},{&g_4604,&g_4604,(void*)0,(void*)0},{&g_4604,&g_4604,&g_4604,(void*)0},{&g_4604,&g_4604,&g_4604,&g_4604},{&g_4604,&g_4604,&g_4604,&g_4604},{&g_4604,&g_4604,(void*)0,&g_4604},{&g_4604,&g_4604,&g_4604,&g_4604}};
static uint32_t * volatile ** volatile * volatile g_4611 = (void*)0;/* VOLATILE GLOBAL g_4611 */
static int16_t g_4632 = 0x09C6L;
static volatile union U0 g_4669 = {-9L};/* VOLATILE GLOBAL g_4669 */
static union U0 g_4724 = {-1L};/* VOLATILE GLOBAL g_4724 */
static volatile union U0 g_4728[3] = {{-7L},{-7L},{-7L}};
static int32_t ** volatile g_4743 = &g_1139[0];/* VOLATILE GLOBAL g_4743 */
static uint32_t ***g_4776 = (void*)0;
static uint32_t ****g_4775[1][5][6] = {{{&g_4776,&g_4776,&g_4776,&g_4776,&g_4776,&g_4776},{&g_4776,&g_4776,&g_4776,&g_4776,&g_4776,&g_4776},{&g_4776,&g_4776,&g_4776,&g_4776,&g_4776,&g_4776},{&g_4776,&g_4776,&g_4776,&g_4776,&g_4776,&g_4776},{&g_4776,&g_4776,&g_4776,&g_4776,&g_4776,&g_4776}}};
static uint32_t *****g_4774 = &g_4775[0][4][2];
static volatile uint32_t *g_4831 = &g_368;
static volatile uint32_t ** const g_4830[4] = {&g_4831,&g_4831,&g_4831,&g_4831};
static volatile uint32_t ** const *g_4829 = &g_4830[0];
static union U0 g_4843[6] = {{0x9E3CE139L},{0x9E3CE139L},{0x9E3CE139L},{0x9E3CE139L},{0x9E3CE139L},{0x9E3CE139L}};
static uint8_t g_4905 = 0x50L;
static uint8_t g_4906 = 0xDCL;
static uint8_t * const g_4904[6] = {&g_4906,&g_4906,&g_4906,&g_4906,&g_4906,&g_4906};
static uint8_t * const *g_4903[8][8][3] = {{{&g_4904[1],&g_4904[1],&g_4904[1]},{(void*)0,&g_4904[1],&g_4904[5]},{&g_4904[2],&g_4904[4],&g_4904[1]},{&g_4904[1],&g_4904[3],&g_4904[1]},{(void*)0,&g_4904[1],&g_4904[1]},{&g_4904[1],(void*)0,&g_4904[1]},{&g_4904[2],&g_4904[1],&g_4904[3]},{&g_4904[0],&g_4904[1],&g_4904[4]}},{{&g_4904[2],&g_4904[1],(void*)0},{&g_4904[1],(void*)0,&g_4904[1]},{(void*)0,&g_4904[1],&g_4904[1]},{&g_4904[1],(void*)0,&g_4904[0]},{&g_4904[2],&g_4904[3],&g_4904[4]},{(void*)0,(void*)0,&g_4904[1]},{&g_4904[1],&g_4904[5],&g_4904[2]},{&g_4904[1],&g_4904[0],&g_4904[1]}},{{&g_4904[4],&g_4904[2],&g_4904[1]},{(void*)0,&g_4904[1],&g_4904[1]},{&g_4904[3],(void*)0,&g_4904[2]},{&g_4904[1],&g_4904[1],&g_4904[1]},{&g_4904[2],&g_4904[1],&g_4904[4]},{&g_4904[1],(void*)0,&g_4904[0]},{&g_4904[2],&g_4904[1],&g_4904[1]},{&g_4904[1],&g_4904[1],&g_4904[1]}},{{&g_4904[1],&g_4904[1],(void*)0},{(void*)0,(void*)0,&g_4904[4]},{&g_4904[5],&g_4904[4],&g_4904[3]},{&g_4904[1],(void*)0,&g_4904[1]},{&g_4904[1],&g_4904[1],&g_4904[1]},{&g_4904[5],&g_4904[1],&g_4904[1]},{&g_4904[1],&g_4904[1],&g_4904[1]},{&g_4904[1],(void*)0,&g_4904[5]}},{{&g_4904[1],&g_4904[1],&g_4904[1]},{&g_4904[2],&g_4904[1],&g_4904[5]},{&g_4904[3],(void*)0,&g_4904[4]},{&g_4904[1],&g_4904[1],(void*)0},{&g_4904[1],&g_4904[2],&g_4904[1]},{&g_4904[1],&g_4904[0],&g_4904[1]},{&g_4904[3],&g_4904[5],&g_4904[4]},{&g_4904[2],(void*)0,&g_4904[1]}},{{&g_4904[1],&g_4904[3],&g_4904[1]},{&g_4904[1],(void*)0,(void*)0},{&g_4904[1],&g_4904[1],&g_4904[2]},{&g_4904[5],(void*)0,&g_4904[1]},{&g_4904[1],&g_4904[1],&g_4904[2]},{&g_4904[1],&g_4904[1],&g_4904[1]},{&g_4904[5],&g_4904[2],&g_4904[1]},{&g_4904[0],(void*)0,&g_4904[5]}},{{&g_4904[4],(void*)0,&g_4904[2]},{&g_4904[3],&g_4904[5],&g_4904[1]},{&g_4904[1],&g_4904[1],&g_4904[4]},{&g_4904[0],&g_4904[1],&g_4904[1]},{&g_4904[1],&g_4904[1],&g_4904[1]},{&g_4904[1],(void*)0,&g_4904[1]},{&g_4904[1],&g_4904[4],&g_4904[1]},{(void*)0,(void*)0,&g_4904[0]}},{{(void*)0,&g_4904[4],&g_4904[1]},{&g_4904[1],(void*)0,&g_4904[4]},{&g_4904[1],&g_4904[1],&g_4904[5]},{&g_4904[1],&g_4904[1],&g_4904[2]},{&g_4904[1],&g_4904[1],(void*)0},{(void*)0,&g_4904[5],(void*)0},{&g_4904[3],(void*)0,&g_4904[1]},{&g_4904[1],(void*)0,&g_4904[1]}}};
static int8_t *g_4952 = &g_2962;
static int8_t ** const g_4951 = &g_4952;
static int8_t ** const *g_4950 = &g_4951;
static int8_t ** const **g_4949[3][10][8] = {{{&g_4950,(void*)0,(void*)0,&g_4950,&g_4950,(void*)0,(void*)0,&g_4950},{&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0,(void*)0},{&g_4950,&g_4950,&g_4950,&g_4950,(void*)0,(void*)0,&g_4950,&g_4950},{&g_4950,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950},{&g_4950,&g_4950,(void*)0,(void*)0,&g_4950,(void*)0,&g_4950,&g_4950},{(void*)0,(void*)0,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950,(void*)0},{&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0,(void*)0,(void*)0},{&g_4950,(void*)0,&g_4950,(void*)0,(void*)0,&g_4950,&g_4950,&g_4950},{&g_4950,(void*)0,&g_4950,&g_4950,&g_4950,(void*)0,(void*)0,&g_4950},{&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950}},{{(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950},{&g_4950,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0},{&g_4950,&g_4950,&g_4950,(void*)0,(void*)0,&g_4950,&g_4950,(void*)0},{&g_4950,(void*)0,(void*)0,&g_4950,&g_4950,(void*)0,&g_4950,&g_4950},{&g_4950,(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0,&g_4950},{&g_4950,&g_4950,&g_4950,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950},{(void*)0,&g_4950,(void*)0,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950},{&g_4950,(void*)0,(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0},{&g_4950,&g_4950,(void*)0,(void*)0,(void*)0,&g_4950,&g_4950,&g_4950},{(void*)0,&g_4950,&g_4950,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950}},{{&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950},{&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0,(void*)0},{(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0},{&g_4950,&g_4950,&g_4950,(void*)0,&g_4950,&g_4950,(void*)0,&g_4950},{(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950},{&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950},{&g_4950,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950},{&g_4950,&g_4950,(void*)0,&g_4950,&g_4950,(void*)0,&g_4950,&g_4950},{&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,&g_4950,(void*)0,&g_4950},{&g_4950,(void*)0,&g_4950,(void*)0,&g_4950,&g_4950,&g_4950,&g_4950}}};
static int8_t ** const ***g_4948 = &g_4949[0][2][0];
static volatile int32_t * volatile * volatile g_4996[10][1][9] = {{{&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}},{{&g_2957,(void*)0,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}},{{&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}},{{&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,(void*)0,&g_2957}},{{&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}},{{&g_2957,(void*)0,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}},{{&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}},{{&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,(void*)0,&g_2957}},{{&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}},{{&g_2957,(void*)0,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957,&g_2957}}};
static union U0 g_5071 = {0x24073128L};/* VOLATILE GLOBAL g_5071 */
static uint8_t ***** volatile g_5136 = (void*)0;/* VOLATILE GLOBAL g_5136 */
static uint8_t **g_5140 = (void*)0;
static uint8_t ***g_5139 = &g_5140;
static uint8_t ****g_5138[8][3] = {{&g_5139,&g_5139,&g_5139},{&g_5139,&g_5139,&g_5139},{&g_5139,&g_5139,&g_5139},{&g_5139,&g_5139,&g_5139},{&g_5139,&g_5139,&g_5139},{&g_5139,&g_5139,&g_5139},{&g_5139,&g_5139,&g_5139},{&g_5139,&g_5139,&g_5139}};
static const union U0 g_5156 = {1L};/* VOLATILE GLOBAL g_5156 */
static int32_t *****g_5165 = &g_3832;
static uint32_t ** const g_5180 = &g_1998;
static uint32_t ** const *g_5179 = &g_5180;
static uint32_t ** const **g_5178 = &g_5179;
static uint32_t ** const *** volatile g_5177 = &g_5178;/* VOLATILE GLOBAL g_5177 */
static int16_t g_5190 = 0x0803L;
static int32_t ** volatile g_5218 = &g_1139[0];/* VOLATILE GLOBAL g_5218 */
static uint16_t g_5223 = 0x6BD5L;
static uint32_t g_5258 = 0x1DFF5C7EL;
static int32_t * const  volatile g_5299 = &g_797;/* VOLATILE GLOBAL g_5299 */
static int32_t * const  volatile g_5346[5] = {&g_1256,&g_1256,&g_1256,&g_1256,&g_1256};
static union U0 *g_5405[5][2] = {{&g_4520,&g_4520},{&g_4520,&g_4520},{&g_4520,&g_4520},{&g_4520,&g_4520},{&g_4520,&g_4520}};
static union U0 ** volatile g_5404[6] = {&g_5405[2][0],&g_5405[2][0],&g_5405[2][0],&g_5405[2][0],&g_5405[2][0],&g_5405[2][0]};
static union U0 ** volatile g_5406 = &g_5405[4][0];/* VOLATILE GLOBAL g_5406 */
static int32_t ** volatile g_5538 = &g_190;/* VOLATILE GLOBAL g_5538 */
static int32_t **g_5559 = &g_1139[0];
static int32_t **g_5561 = &g_1139[0];
static uint64_t g_5621 = 0x28E8466EE7C8750CLL;
static uint32_t g_5641 = 18446744073709551615UL;
static volatile uint32_t g_5642 = 0x6ECCF24BL;/* VOLATILE GLOBAL g_5642 */
static int16_t g_5676 = 0L;
static int8_t ****g_5713 = &g_1059;
static int8_t ****g_5715 = &g_2897;
static uint16_t g_5784 = 0x0E91L;
static volatile union U0 g_5796[9] = {{0xCB85299DL},{0xCB85299DL},{0xCB85299DL},{0xCB85299DL},{0xCB85299DL},{0xCB85299DL},{0xCB85299DL},{0xCB85299DL},{0xCB85299DL}};
static uint32_t *** volatile g_5823 = (void*)0;/* VOLATILE GLOBAL g_5823 */
static uint32_t **g_5825 = &g_1998;
static uint32_t *** volatile g_5824 = &g_5825;/* VOLATILE GLOBAL g_5824 */
static int32_t *g_5835 = &g_4555;
static int32_t **g_5834 = &g_5835;
static uint8_t g_5844 = 0x54L;
static int8_t g_5846 = 1L;
static int8_t g_5851 = (-1L);
static union U0 g_5867[10][5][5] = {{{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}}},{{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}}},{{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}}},{{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}}},{{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}}},{{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}}},{{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}}},{{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}}},{{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}}},{{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}},{{-6L},{0L},{-6L},{0L},{-6L}},{{8L},{8L},{8L},{8L},{8L}}}};
static int64_t g_5909 = 0xAD38436BEA03B815LL;
static uint8_t g_5946 = 0x5CL;
static union U0 g_5956[7] = {{0x80B0AA2BL},{0x80B0AA2BL},{0x80B0AA2BL},{0x80B0AA2BL},{0x80B0AA2BL},{0x80B0AA2BL},{0x80B0AA2BL}};
static int16_t * const * volatile * volatile *g_5992[1] = {(void*)0};
static int16_t * const * volatile * volatile ** volatile g_5991 = &g_5992[0];/* VOLATILE GLOBAL g_5991 */
static const union U0 g_6053 = {1L};/* VOLATILE GLOBAL g_6053 */
static volatile uint16_t g_6064 = 1UL;/* VOLATILE GLOBAL g_6064 */
static uint16_t g_6098 = 65529UL;
static const int32_t g_6102 = 0L;
static const uint32_t g_6122 = 0xF8DF8831L;
static const uint32_t g_6124[9] = {0UL,0x147400F7L,0UL,0x147400F7L,0UL,0x147400F7L,0UL,0x147400F7L,0UL};
static int16_t * const ***g_6185[5][9] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static int16_t *** volatile *g_6190 = &g_1424;
static const int32_t ***g_6214 = (void*)0;
static const int32_t ****g_6213 = &g_6214;
static uint64_t g_6222 = 18446744073709551615UL;
static uint16_t g_6256 = 0xAACDL;
static const int32_t ** volatile g_6259 = (void*)0;/* VOLATILE GLOBAL g_6259 */
static volatile uint32_t g_6268 = 4294967295UL;/* VOLATILE GLOBAL g_6268 */
static union U0 g_6289 = {-1L};/* VOLATILE GLOBAL g_6289 */
static uint32_t *g_6317[1][7][5] = {{{&g_3411,&g_31,&g_1496,&g_31,&g_3411},{&g_3411,&g_31,&g_1496,&g_31,&g_3411},{&g_3411,&g_31,&g_1496,&g_31,&g_31},{&g_31,&g_3411,&g_1496,&g_3411,&g_31},{&g_31,&g_3411,&g_1496,&g_3411,&g_31},{&g_31,&g_3411,&g_1496,&g_3411,&g_31},{&g_31,&g_3411,&g_1496,&g_3411,&g_31}}};
static uint32_t **g_6316 = &g_6317[0][4][0];
static int32_t g_6338[3][10][6] = {{{3L,0x3D75A304L,(-1L),(-3L),0L,0x0AC0CCA5L},{0xDD678660L,(-9L),0xD4886709L,0xB5D2B4B7L,(-10L),0xF3B49D4CL},{0x0D89CD7DL,0x153F219CL,0x4BAE9FE5L,0x435450DFL,0L,(-1L)},{0L,0x0AC0CCA5L,1L,0x1CEA49A6L,0x435450DFL,(-1L)},{0x6E4DFE47L,0x8A98217DL,4L,0L,0x130DD515L,0xD4886709L},{0x23B55060L,0L,0xD15FC122L,(-3L),0xD51961E2L,1L},{0L,0xD4886709L,0x6E4DFE47L,(-1L),0x8A98217DL,0xDD678660L},{(-1L),0L,0x436802CDL,0xAF72E165L,0x01A6B2F3L,0xB5D2B4B7L},{0x4FA5F3B8L,0x2FD86F0AL,1L,0xD15FC122L,0xC4E0B737L,2L},{0x3D75A304L,2L,1L,1L,2L,0x3D75A304L}},{{0x2FD86F0AL,0xA128D008L,0L,0L,0x963F3989L,0x0AC0CCA5L},{0x4BAE9FE5L,0xD4886709L,0xC4E0B737L,0L,0x153F219CL,0xCF266FACL},{0x4BAE9FE5L,0x78594975L,0L,0L,0x68059B26L,0x0D89CD7DL},{0x2FD86F0AL,0x963F3989L,0x603F5C13L,1L,0x435450DFL,4L},{0x3D75A304L,0x0821E310L,0x1CEA49A6L,0xD15FC122L,(-7L),0L},{0x4FA5F3B8L,0x603F5C13L,0x7092D4B4L,0xAF72E165L,2L,0x963F3989L},{(-1L),(-9L),0L,(-1L),0x78594975L,0xCF266FACL},{0L,(-9L),0L,(-3L),0L,0xAE1F64DDL},{0x23B55060L,1L,0xD4886709L,0L,0L,0x3034D98FL},{0x6E4DFE47L,0x153F219CL,1L,0x1CEA49A6L,(-7L),0L}},{{0L,(-3L),0L,0x435450DFL,0x429CEE12L,(-1L)},{0x0D89CD7DL,0x6E4DFE47L,(-9L),0xB5D2B4B7L,0x130DD515L,0xDD678660L},{0xDD678660L,0x78594975L,0x0D89CD7DL,(-3L),0x603F5C13L,0x436802CDL},{3L,0x23B55060L,0x6E4DFE47L,0x77D1EE11L,0x6E4DFE47L,0x23B55060L},{0L,0L,4L,(-7L),2L,1L},{0x4FA5F3B8L,0x01A6B2F3L,0L,0x6E4DFE47L,0x927D8283L,2L},{0xF3B49D4CL,0x01A6B2F3L,0x68059B26L,0x4BAE9FE5L,2L,0xF3B49D4CL},{1L,0L,0xDD678660L,0L,0x6E4DFE47L,0xAE1F64DDL},{0xFC500AF6L,0x23B55060L,0xCF266FACL,0L,0L,0x68059B26L},{0xDD678660L,0x963F3989L,0L,0x8A98217DL,0x23B55060L,0L}}};
static int32_t g_6361[9][4][5] = {{{0xC9D4B502L,(-1L),7L,0xDABCE857L,0xB93DAA84L},{(-1L),0x06BBEAB2L,(-1L),0xBF1E9A70L,0x27AE97FFL},{0L,0x8A81A5DEL,5L,0x52D3C803L,3L},{(-1L),0L,0x642200F9L,(-1L),7L}},{{0xC9D4B502L,0xBF1E9A70L,(-1L),0xC9D4B502L,0x42336E13L},{0x6C4A7D73L,0x51A6CB6DL,0L,5L,3L},{(-1L),5L,1L,0x6C7A70E2L,0x99B1F23AL},{0xBF1E9A70L,(-3L),6L,(-1L),(-1L)}},{{0x743C51E6L,0x42336E13L,(-1L),0L,0xBEEAF1A2L},{0L,0x4FEDB5D7L,(-1L),(-1L),(-2L)},{(-1L),0x6C7A70E2L,6L,(-1L),0xC9D4B502L},{0x642200F9L,0L,1L,(-6L),(-1L)}},{{0x42336E13L,0L,0L,0xDABCE857L,1L},{0xA68FF254L,0L,(-1L),0L,0xA68FF254L},{0xDAEAB164L,0x42336E13L,0x642200F9L,0L,0L},{0x42336E13L,(-2L),5L,0x51A6CB6DL,(-6L)}},{{0x51A6CB6DL,(-1L),(-1L),0x42336E13L,0L},{0L,0x51A6CB6DL,7L,0xDAEAB164L,0xA68FF254L},{0L,(-6L),0x4FEDB5D7L,0xA68FF254L,1L},{0xDABCE857L,0x424D3C1AL,5L,0x42336E13L,(-1L)}},{{(-6L),0x8A81A5DEL,0xF5A6C10DL,0x642200F9L,0xC9D4B502L},{(-1L),0x88F99355L,0L,(-1L),(-2L)},{(-1L),0xBEEAF1A2L,0x471CFA3FL,0L,0xBEEAF1A2L},{0L,0xBEEAF1A2L,7L,0x743C51E6L,(-1L)}},{{(-1L),0x88F99355L,(-2L),0xBF1E9A70L,0x99B1F23AL},{0x6C7A70E2L,0x8A81A5DEL,0xA414A141L,(-1L),3L},{5L,0x424D3C1AL,0x642200F9L,0x6C4A7D73L,0x42336E13L},{0xC9D4B502L,(-6L),(-6L),0xC9D4B502L,7L}},{{(-1L),0x51A6CB6DL,0xC58D9C24L,(-1L),3L},{0x52D3C803L,(-1L),1L,0L,0x27AE97FFL},{0xBF1E9A70L,(-2L),0x88F99355L,(-1L),0xB93DAA84L},{0xDABCE857L,0x42336E13L,0xF0569BD5L,0xC9D4B502L,0xBEEAF1A2L}},{{0x4FEDB5D7L,0L,(-1L),0x6C4A7D73L,(-3L)},{(-1L),0L,0x88F99355L,(-1L),0L},{0x51A6CB6DL,0L,0x75D6FD9DL,0xBF1E9A70L,(-1L)},{7L,0x6C7A70E2L,0L,0x743C51E6L,0x8A81A5DEL}}};
static volatile union U0 g_6365 = {0x559AF9A8L};/* VOLATILE GLOBAL g_6365 */
static int32_t *g_6419 = &g_117;
static uint16_t **** const g_6439 = (void*)0;
static uint16_t **** const *g_6438[1] = {&g_6439};
static union U0 g_6440 = {0L};/* VOLATILE GLOBAL g_6440 */
static volatile uint64_t g_6443 = 0xBFE413B073AEF340LL;/* VOLATILE GLOBAL g_6443 */
static volatile union U0 g_6465 = {0x583B1EEEL};/* VOLATILE GLOBAL g_6465 */
static union U0 g_6501[3] = {{-5L},{-5L},{-5L}};
static union U0 * const g_6500 = &g_6501[0];
static union U0 * const *g_6499 = &g_6500;
static union U0 * const **g_6498 = &g_6499;
static int16_t *** const g_6616 = (void*)0;
static int16_t *** const *g_6615 = &g_6616;
static int16_t **g_6619 = &g_969;
static int16_t *** const g_6618 = &g_6619;
static int16_t *** const *g_6617 = &g_6618;
static int16_t *** const *g_6620 = &g_1424;
static int32_t ** const  volatile g_6625 = (void*)0;/* VOLATILE GLOBAL g_6625 */
static int32_t ** const  volatile g_6626 = &g_1139[0];/* VOLATILE GLOBAL g_6626 */
static volatile union U0 g_6685 = {-7L};/* VOLATILE GLOBAL g_6685 */
static int16_t ****g_6712 = &g_1424;
static int16_t ***** volatile g_6711[9] = {&g_6712,&g_6712,&g_6712,&g_6712,&g_6712,&g_6712,&g_6712,&g_6712,&g_6712};
static int16_t g_6756[2] = {0xD52CL,0xD52CL};
static uint32_t g_6763[1] = {18446744073709551609UL};
static volatile union U0 g_6775 = {0xC3C49643L};/* VOLATILE GLOBAL g_6775 */
static const int32_t ** const  volatile g_6825 = &g_543;/* VOLATILE GLOBAL g_6825 */
static uint32_t g_6864 = 18446744073709551608UL;
static uint16_t g_6885 = 65532UL;
static volatile union U0 g_6892 = {0x4854C362L};/* VOLATILE GLOBAL g_6892 */
static volatile uint64_t g_6897 = 2UL;/* VOLATILE GLOBAL g_6897 */
static int64_t g_6923 = 0x398B08B8FBAE07AFLL;
static int32_t g_6957 = 0x1017A0ABL;
static uint32_t g_6999 = 0UL;
static uint32_t g_7085 = 18446744073709551615UL;
static const int16_t g_7119 = 1L;
static union U0 g_7162 = {0x65250F36L};/* VOLATILE GLOBAL g_7162 */
static union U0 g_7179 = {0xB3FBA199L};/* VOLATILE GLOBAL g_7179 */
static uint32_t g_7181[5][6] = {{1UL,0x7F5716C7L,0x7F5716C7L,1UL,0xDB46A246L,1UL},{1UL,0xDB46A246L,1UL,0x7F5716C7L,0x7F5716C7L,1UL},{0x5C77447DL,0x5C77447DL,0x7F5716C7L,4294967295UL,0x7F5716C7L,0x5C77447DL},{0x7F5716C7L,0xDB46A246L,4294967295UL,4294967295UL,0xDB46A246L,0x7F5716C7L},{0x5C77447DL,0x7F5716C7L,4294967295UL,0x7F5716C7L,0x5C77447DL,0x5C77447DL}};
static const uint32_t *g_7210 = &g_1937[2];
static const uint32_t **g_7209[8][5][4] = {{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}},{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}},{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}},{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}},{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}},{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}},{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}},{{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210},{&g_7210,&g_7210,&g_7210,&g_7210}}};
static int16_t * volatile g_7252 = &g_6756[0];/* VOLATILE GLOBAL g_7252 */
static int64_t **g_7308 = (void*)0;
static volatile int32_t g_7338 = 0x8368FEA2L;/* VOLATILE GLOBAL g_7338 */
static uint64_t g_7368[9][7][2] = {{{1UL,0UL},{0UL,0x678B7F9CC394D7F0LL},{0x8CF70AB629235F4FLL,0x58DEFB3034A9ADFCLL},{1UL,0x14839DB03DC5237ELL},{0x12750B93B3D16DE5LL,0xE7523E8FD4E309ECLL},{0UL,0xE7523E8FD4E309ECLL},{0x12750B93B3D16DE5LL,0x14839DB03DC5237ELL}},{{1UL,0x58DEFB3034A9ADFCLL},{0x8CF70AB629235F4FLL,0x678B7F9CC394D7F0LL},{0UL,0UL},{1UL,18446744073709551613UL},{0x14839DB03DC5237ELL,0UL},{1UL,18446744073709551614UL},{18446744073709551613UL,1UL}},{{0xCCB9C874B857C2B5LL,18446744073709551613UL},{0xCCB9C874B857C2B5LL,1UL},{18446744073709551613UL,18446744073709551614UL},{1UL,0UL},{0x14839DB03DC5237ELL,18446744073709551613UL},{1UL,0UL},{0UL,0x678B7F9CC394D7F0LL}},{{0x8CF70AB629235F4FLL,0x58DEFB3034A9ADFCLL},{1UL,0x14839DB03DC5237ELL},{0x12750B93B3D16DE5LL,0xE7523E8FD4E309ECLL},{0UL,0xE7523E8FD4E309ECLL},{0x12750B93B3D16DE5LL,0x14839DB03DC5237ELL},{1UL,0x58DEFB3034A9ADFCLL},{0x8CF70AB629235F4FLL,0x678B7F9CC394D7F0LL}},{{0UL,0UL},{1UL,18446744073709551613UL},{0x14839DB03DC5237ELL,0UL},{1UL,18446744073709551614UL},{18446744073709551613UL,1UL},{0xCCB9C874B857C2B5LL,18446744073709551613UL},{0xCCB9C874B857C2B5LL,1UL}},{{18446744073709551613UL,18446744073709551614UL},{1UL,0UL},{0x14839DB03DC5237ELL,18446744073709551613UL},{1UL,0UL},{0UL,0x678B7F9CC394D7F0LL},{0x8CF70AB629235F4FLL,0x58DEFB3034A9ADFCLL},{1UL,0x14839DB03DC5237ELL}},{{0x12750B93B3D16DE5LL,0xE7523E8FD4E309ECLL},{0UL,0xE7523E8FD4E309ECLL},{0x12750B93B3D16DE5LL,0x14839DB03DC5237ELL},{1UL,0x58DEFB3034A9ADFCLL},{0x8CF70AB629235F4FLL,0x678B7F9CC394D7F0LL},{0UL,0UL},{1UL,18446744073709551613UL}},{{0x14839DB03DC5237ELL,0UL},{1UL,18446744073709551614UL},{18446744073709551613UL,1UL},{0xCCB9C874B857C2B5LL,18446744073709551613UL},{0xCCB9C874B857C2B5LL,1UL},{18446744073709551613UL,18446744073709551614UL},{1UL,0UL}},{{0x14839DB03DC5237ELL,18446744073709551613UL},{1UL,0UL},{0UL,0x678B7F9CC394D7F0LL},{0x8CF70AB629235F4FLL,0x58DEFB3034A9ADFCLL},{1UL,0x14839DB03DC5237ELL},{0x12750B93B3D16DE5LL,0xE7523E8FD4E309ECLL},{0UL,0xE7523E8FD4E309ECLL}}};
static volatile uint32_t g_7369 = 18446744073709551615UL;/* VOLATILE GLOBAL g_7369 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint32_t  func_7(const uint64_t  p_8);
static union U1  func_14(uint64_t  p_15, uint32_t  p_16, int64_t  p_17, uint16_t  p_18);
static uint32_t  func_21(union U1  p_22, const uint8_t  p_23, uint8_t  p_24);
static union U1  func_25(int32_t  p_26, union U1  p_27, uint8_t  p_28);
static uint8_t  func_38(union U1  p_39);
static union U1  func_40(uint32_t  p_41, uint64_t  p_42, uint64_t  p_43, uint64_t  p_44, int32_t  p_45);
static uint32_t  func_49(union U1  p_50, int8_t  p_51, uint8_t  p_52);
static union U1  func_53(union U1  p_54);
static int32_t * func_58(int32_t * const  p_59, int16_t  p_60, int32_t * const  p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_31 g_46 g_55 g_55.f0 g_190 g_527 g_77 g_662 g_1997 g_62 g_117 g_362 g_878 g_689 g_308.f0 g_1937 g_875 g_876 g_877 g_733 g_1998 g_1939 g_969 g_1732 g_267 g_1358 g_846 g_614 g_822.f0 g_732 g_181 g_571 g_180 g_968 g_63 g_1658 g_85 g_1151 g_1357 g_764 g_2583 g_2584 g_2585 g_2586 g_80 g_253 g_254 g_885 g_827 g_828 g_746 g_822.f4 g_613 g_2586.f0 g_2267 g_1681 g_1329 g_1256 g_797 g_75 g_430 g_203 g_904 g_2957 g_2958 g_825 g_826 g_3015 g_2882 g_3033 g_3058 g_3069 g_1578 g_971 g_1191.f4 g_560.f0 g_3164 g_1625 g_3212 g_731 g_3224 g_3225 g_3255 g_2511.f0 g_3286 g_1411.f4 g_3294 g_3302 g_3164.f0 g_2582 g_3323 g_3324 g_3325 g_3326 g_321 g_3180 g_3181 g_3182 g_3411 g_3418 g_2962 g_201 g_3520 g_3523 g_2486 g_2487 g_3548 g_2311.f0 g_3567 g_3579 g_3602 g_3615 g_241 g_3548.f4 g_1735 g_116 g_1150 g_3706 g_123.f4 g_1846 g_544 g_1497.f0 g_3781 g_633 g_1935 g_3821 g_484 g_2897 g_1060 g_3926 g_3224.f0 g_4019 g_4027 g_4028 g_4020 g_4045 g_4095 g_4100 g_4121 g_1164 g_4207 g_3833 g_4235 g_3183 g_4100.f0 g_3707 g_4028.f4 g_4603 g_2896 g_4453 g_4611 g_5156 g_5177 g_5190 g_5180 g_5218 g_4950 g_4951 g_4952 g_4452 g_4604 g_5299 g_596 g_3521 g_3522 g_619 g_4905 g_5406 g_4829 g_4830 g_560 g_1425 g_1426 g_4451 g_5538 g_5179 g_1427 g_5561 g_113.f4 g_4774 g_5621 g_682.f4 g_5178 g_5641 g_5642 g_5676 g_4775 g_5784 g_5796 g_5824 g_5834 g_5846 g_5825 g_5909 g_4724.f4 g_5559 g_5946 g_5835 g_5991 g_6053 g_6064 g_6098 g_6102 g_6185 g_6190 g_6213 g_6268 g_6289 g_6214 g_6338 g_924 g_6365 g_6361 g_847 g_6419 g_3634 g_3635 g_3636 g_6440 g_6443 g_6256 g_6626 g_6619 g_6685 g_6316 g_6317 g_1496 g_6864 g_6885 g_6892 g_6897 g_6923 g_6617 g_6618 g_6957 g_5139 g_5140 g_4325 g_6999 g_7085 g_7119 g_7162 g_254.f0 g_7179 g_4906 g_1059 g_7252 g_5405 g_3637 g_3638 g_7338 g_7369 g_6756
 * writes: g_55.f0 g_117 g_527 g_77 g_1329 g_267 g_63 g_362 g_1939 g_904 g_614 g_1139 g_543 g_201 g_822.f1 g_1831 g_571 g_55 g_75 g_190 g_85 g_764 g_80 g_1937 g_746 g_846 g_2682 g_822.f4 g_31 g_1658 g_613 g_596 g_1496 g_2586.f0 g_924 g_1681 g_2882 g_1191.f4 g_1497.f4 g_430 g_797 g_1256 g_2895 g_203 g_2948 g_2957 g_241 g_1427 g_1411.f4 g_181 g_1935 g_1578 g_847 g_1164.f4 g_1088 g_3178 g_308.f0 g_3323 g_321 g_3286 g_3183 g_3548.f4 g_1151 g_3706 g_123.f4 g_3832 g_113.f4 g_180 g_4106 g_3834 g_4027 g_4100.f0 g_4028.f4 g_1060 g_5138 g_5165 g_2962 g_5258 g_1732 g_662 g_4905 g_5405 g_5223 g_560.f3 g_4045 g_1788.f4 g_4095 g_5559 g_5561 g_560.f0 g_368 g_4462.f1 g_4949 g_3212 g_5190 g_4906 g_4775 g_5621 g_682.f4 g_4724.f4 g_3326 g_4632 g_5713 g_5715 g_4121 g_5825 g_1424 g_5834 g_5071.f4 g_1998 g_5835 g_5909 g_252 g_4555 g_5992 g_6064 g_6213 g_6222 g_6268 g_6098 g_2586 g_6316 g_6214 g_6361 g_5784 g_6438 g_6498 g_6256 g_6615 g_6617 g_6620 g_2267 g_6897 g_4207.f4 g_3411 g_3010 g_7181 g_2583 g_4603 g_7308 g_5844 g_7085 g_7368
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_6[7][8][3] = {{{1L,3L,0L},{1L,0L,0x0B963AB1L},{(-8L),(-1L),0L},{(-4L),0xDD253D97L,0xF0A9B27FL},{0L,0L,0x0B963AB1L},{0x3203BD65L,0L,1L},{0L,(-8L),1L},{0L,0L,0x0B963AB1L}},{{0xFD996437L,0xCAB39150L,0xF0A9B27FL},{0x2BFEED1BL,4L,0L},{(-1L),(-2L),0x0B963AB1L},{(-1L),0x2BFEED1BL,0L},{7L,0x3203BD65L,0xF0A9B27FL},{2L,(-1L),0x0B963AB1L},{0xDD253D97L,0x6FE23A26L,1L},{(-8L),(-4L),1L}},{{0x98AAC1E0L,0xB5CF1C94L,0L},{0xBE197E7CL,(-1L),1L},{0L,0x8FAD7494L,(-1L)},{3L,0L,0L},{(-3L),0xD2717F40L,(-1L)},{(-8L),0x6193FE69L,1L},{(-9L),0xD14CD495L,0L},{0x6193FE69L,0x20DD93BAL,0L}},{{9L,0L,0L},{0L,(-1L),0L},{0L,(-5L),1L},{0xD2717F40L,0L,(-1L)},{0xD14CD495L,1L,0L},{(-1L),0L,(-1L)},{(-5L),0x601C8D53L,1L},{1L,3L,0L}},{{4L,(-7L),0L},{(-7L),(-1L),0L},{0L,0L,0L},{0x8FAD7494L,(-8L),1L},{0L,0xBE197E7CL,(-1L)},{0L,(-9L),0L},{0L,0L,(-1L)},{(-1L),4L,1L}},{{0L,0L,0L},{0x601C8D53L,9L,0L},{0x20DD93BAL,(-3L),0L},{(-1L),0L,0L},{0xBE197E7CL,(-1L),1L},{0L,0x8FAD7494L,(-1L)},{3L,0L,0L},{(-3L),0xD2717F40L,(-1L)}},{{(-8L),0x6193FE69L,1L},{(-9L),0xD14CD495L,0L},{0x6193FE69L,0x20DD93BAL,0L},{9L,0L,0L},{0L,(-1L),0L},{0L,(-5L),1L},{0xD2717F40L,0L,(-1L)},{0xD14CD495L,1L,0L}}};
    int16_t ****l_5830 = (void*)0;
    int16_t **l_5833 = (void*)0;
    int16_t ***l_5832 = &l_5833;
    int16_t ****l_5831 = &l_5832;
    int32_t l_5840 = 0x52E29890L;
    int32_t **l_5842 = &g_5835;
    int32_t ***l_5841 = &l_5842;
    uint8_t *l_5843[5];
    int32_t l_5845 = 0x941C9E04L;
    int32_t l_5847 = (-7L);
    uint32_t **l_5880[3];
    uint16_t l_5894 = 0x3E66L;
    uint32_t l_5907 = 9UL;
    union U1 l_5941 = {0xCEL};
    union U0 *****l_5961[3];
    union U0 ****l_6015 = &g_3707;
    int32_t l_6016 = (-1L);
    uint32_t l_6017 = 0x5F617A2DL;
    int8_t l_6018 = 1L;
    uint32_t l_6019 = 0x74FEBFBCL;
    union U1 l_6020 = {0UL};
    union U1 l_6021 = {255UL};
    int8_t l_6022 = 0xA7L;
    int64_t l_6023 = 0x2E005C27C185F69BLL;
    uint16_t **l_6057[2];
    uint16_t ***l_6056[5];
    uint16_t ****l_6055 = &l_6056[4];
    uint16_t l_6108[1];
    uint64_t l_6115[10];
    const uint32_t *l_6123[8][7][4] = {{{&g_6124[2],(void*)0,&g_6124[8],&g_6122},{&g_6122,&g_6124[2],&g_6122,(void*)0},{(void*)0,&g_6124[8],(void*)0,(void*)0},{&g_6122,&g_6124[2],&g_6122,&g_6122},{&g_6124[8],(void*)0,&g_6124[2],&g_6124[2]},{&g_6122,&g_6122,&g_6124[2],(void*)0},{&g_6124[8],&g_6122,&g_6122,(void*)0}},{{&g_6122,&g_6122,(void*)0,&g_6122},{(void*)0,&g_6122,&g_6122,(void*)0},{&g_6122,&g_6122,&g_6124[8],(void*)0},{&g_6124[2],&g_6122,&g_6122,&g_6124[2]},{&g_6124[2],(void*)0,&g_6124[8],&g_6122},{&g_6122,&g_6124[2],&g_6122,(void*)0},{(void*)0,&g_6124[8],(void*)0,(void*)0}},{{&g_6122,&g_6124[2],&g_6122,&g_6122},{&g_6124[8],(void*)0,&g_6124[2],&g_6124[2]},{&g_6122,&g_6122,&g_6124[2],(void*)0},{&g_6124[8],&g_6122,&g_6122,(void*)0},{&g_6122,&g_6124[8],(void*)0,&g_6124[8]},{(void*)0,&g_6124[8],&g_6124[8],&g_6124[2]},{&g_6124[8],&g_6122,(void*)0,(void*)0}},{{&g_6122,(void*)0,(void*)0,&g_6122},{&g_6122,&g_6124[2],(void*)0,&g_6122},{&g_6124[8],&g_6122,&g_6124[8],&g_6122},{(void*)0,&g_6122,(void*)0,&g_6122},{&g_6124[8],&g_6122,&g_6124[8],&g_6122},{(void*)0,&g_6124[2],&g_6122,&g_6122},{(void*)0,(void*)0,&g_6122,(void*)0}},{{(void*)0,&g_6122,&g_6124[8],&g_6124[2]},{&g_6124[8],&g_6124[8],(void*)0,&g_6124[8]},{(void*)0,&g_6124[8],&g_6124[8],&g_6124[2]},{&g_6124[8],&g_6122,(void*)0,(void*)0},{&g_6122,(void*)0,(void*)0,&g_6122},{&g_6122,&g_6124[2],(void*)0,&g_6122},{&g_6124[8],&g_6122,&g_6124[8],&g_6122}},{{(void*)0,&g_6122,(void*)0,&g_6122},{&g_6124[8],&g_6122,&g_6124[8],&g_6122},{(void*)0,&g_6124[2],&g_6122,&g_6122},{(void*)0,(void*)0,&g_6122,(void*)0},{(void*)0,&g_6122,&g_6124[8],&g_6124[2]},{&g_6124[8],&g_6124[8],(void*)0,&g_6124[8]},{(void*)0,&g_6124[8],&g_6124[8],&g_6124[2]}},{{&g_6124[8],&g_6122,(void*)0,(void*)0},{&g_6122,(void*)0,(void*)0,&g_6122},{&g_6122,&g_6124[2],(void*)0,&g_6122},{&g_6124[8],&g_6122,&g_6124[8],&g_6122},{(void*)0,&g_6122,(void*)0,&g_6122},{&g_6124[8],&g_6122,&g_6124[8],&g_6122},{(void*)0,&g_6124[2],&g_6122,&g_6122}},{{(void*)0,(void*)0,&g_6122,(void*)0},{(void*)0,&g_6122,&g_6124[8],&g_6124[2]},{&g_6124[8],&g_6124[8],(void*)0,&g_6124[8]},{(void*)0,&g_6124[8],&g_6124[8],&g_6124[2]},{&g_6124[8],&g_6122,(void*)0,(void*)0},{&g_6122,(void*)0,(void*)0,&g_6122},{&g_6122,&g_6124[2],(void*)0,&g_6122}}};
    int8_t **** const l_6126 = &g_2897;
    int64_t ***l_6162 = (void*)0;
    int16_t * const l_6189 = (void*)0;
    int16_t * const *l_6188 = &l_6189;
    int16_t * const **l_6187 = &l_6188;
    int16_t * const ***l_6186 = &l_6187;
    uint8_t ***l_6223 = &g_5140;
    int32_t ****l_6225 = (void*)0;
    uint8_t l_6247 = 2UL;
    int32_t l_6248 = 0x022F79DBL;
    uint32_t *l_6280[8] = {&l_6019,&g_5641,&l_6019,&l_6019,&g_5641,&l_6019,&l_6019,&g_5641};
    uint32_t **l_6279[10] = {&l_6280[7],&l_6280[7],&l_6280[7],&l_6280[7],&l_6280[7],&l_6280[7],&l_6280[7],&l_6280[7],&l_6280[7],&l_6280[7]};
    uint32_t ***l_6278[7];
    const uint64_t l_6287[9][8] = {{0UL,18446744073709551615UL,18446744073709551614UL,0x568C995A13D4FDFDLL,5UL,18446744073709551615UL,0xCDDB87FFD9CF1E54LL,18446744073709551610UL},{0xCDDB87FFD9CF1E54LL,0x46076D0DF405C78CLL,18446744073709551614UL,0xB166A6C5887F68E1LL,0xB166A6C5887F68E1LL,18446744073709551614UL,0x46076D0DF405C78CLL,0xCDDB87FFD9CF1E54LL},{5UL,7UL,0UL,0x63054E51176339E0LL,0xFC34B61DFEBD757BLL,0x568C995A13D4FDFDLL,0xFC34B61DFEBD757BLL,0x03AD62C617BB0DA0LL},{8UL,0xB7A9BD550A34F0D3LL,0x4CD2A26B0D509D21LL,0x63054E51176339E0LL,0xCDDB87FFD9CF1E54LL,0x568C995A13D4FDFDLL,0xCDDB87FFD9CF1E54LL,0x63054E51176339E0LL},{5UL,18446744073709551614UL,5UL,0x46076D0DF405C78CLL,0x568C995A13D4FDFDLL,0x03AD62C617BB0DA0LL,0xB7A9BD550A34F0D3LL,0xB166A6C5887F68E1LL},{0x63054E51176339E0LL,5UL,0xCDDB87FFD9CF1E54LL,0xFC34B61DFEBD757BLL,8UL,0x25F08B29DE4A0F66LL,0x568C995A13D4FDFDLL,0x568C995A13D4FDFDLL},{0x63054E51176339E0LL,0x568C995A13D4FDFDLL,0UL,0UL,0x568C995A13D4FDFDLL,0x63054E51176339E0LL,18446744073709551614UL,18446744073709551610UL},{5UL,0xB1BDCFBE1845CCBBLL,0x25F08B29DE4A0F66LL,18446744073709551614UL,0xCDDB87FFD9CF1E54LL,7UL,0xB166A6C5887F68E1LL,18446744073709551615UL},{8UL,18446744073709551610UL,7UL,18446744073709551614UL,0x4CD2A26B0D509D21LL,18446744073709551614UL,7UL,18446744073709551610UL}};
    uint32_t l_6327 = 0UL;
    const int32_t l_6357 = 3L;
    int64_t l_6360[4][8] = {{0x95582B7A793F91C9LL,0L,(-3L),0xF0BA65EAD4C867B0LL,0L,0xF0BA65EAD4C867B0LL,(-3L),0L},{0x90BCA38F8FC81637LL,(-3L),0x95582B7A793F91C9LL,0x90BCA38F8FC81637LL,0xF0BA65EAD4C867B0LL,0xF0BA65EAD4C867B0LL,0x90BCA38F8FC81637LL,0x95582B7A793F91C9LL},{0L,0L,(-6L),0xB02333375178DBE4LL,0x90BCA38F8FC81637LL,(-6L),0x90BCA38F8FC81637LL,0xB02333375178DBE4LL},{0x95582B7A793F91C9LL,0xB02333375178DBE4LL,0x95582B7A793F91C9LL,0xF0BA65EAD4C867B0LL,0xB02333375178DBE4LL,(-3L),(-3L),0xB02333375178DBE4LL}};
    int8_t l_6409 = (-1L);
    int32_t *l_6423 = &l_6016;
    int32_t l_6512 = 0x54EE06C3L;
    uint32_t l_6568 = 4294967294UL;
    int32_t l_6571 = 0x16D514EDL;
    uint32_t l_6587 = 0x53CE7555L;
    int16_t l_6590[5] = {0xE22DL,0xE22DL,0xE22DL,0xE22DL,0xE22DL};
    uint32_t l_6593 = 0UL;
    int8_t l_6624 = 0x42L;
    int8_t l_6673 = 6L;
    int8_t l_6738 = 0xBAL;
    int32_t l_6739 = (-9L);
    int8_t l_6750 = 1L;
    int32_t l_6762[1];
    union U1 ****l_6803 = (void*)0;
    int16_t l_6851 = 0x870BL;
    uint32_t l_6854 = 4UL;
    union U1 l_6874 = {0xA6L};
    int16_t ***l_6916 = &g_4106[1];
    int16_t **** const l_6915 = &l_6916;
    int16_t **** const *l_6914 = &l_6915;
    uint8_t l_6922 = 250UL;
    int64_t l_6924 = 0L;
    uint64_t l_6997[3];
    uint32_t l_7016 = 0xFD4F2870L;
    int64_t l_7057 = 0x336ADBC7CBF4361ALL;
    uint32_t l_7120 = 0x3AE28284L;
    uint8_t l_7123[4][8][8] = {{{0x6EL,0UL,0x3BL,0x3EL,255UL,250UL,0x70L,253UL},{0x70L,0UL,253UL,0x1EL,0x23L,0x4AL,8UL,2UL},{8UL,2UL,0x83L,2UL,0x3EL,0x70L,0x3EL,2UL},{8UL,249UL,8UL,0x4FL,255UL,0UL,0UL,8UL},{0UL,255UL,2UL,0UL,0x4AL,0x70L,255UL,0x1EL},{0UL,255UL,249UL,0x6EL,255UL,8UL,0UL,3UL},{8UL,255UL,7UL,255UL,0x3EL,0x3EL,255UL,7UL},{8UL,8UL,250UL,0x70L,0x23L,0UL,0x4FL,0UL}},{{0x70L,0x6EL,0x5FL,253UL,255UL,255UL,2UL,0UL},{0x6EL,0x4FL,3UL,0x70L,0x3BL,0UL,0x32L,7UL},{0x5FL,3UL,0x23L,255UL,4UL,255UL,0x23L,3UL},{253UL,0x70L,255UL,0x6EL,0UL,0x4FL,2UL,0x1EL},{255UL,0x3BL,4UL,0UL,253UL,2UL,2UL,0xFCL},{250UL,255UL,0x3EL,0x3BL,0UL,0x6EL,2UL,4UL},{0UL,0x6EL,2UL,4UL,4UL,2UL,0x6EL,0UL},{255UL,0UL,0x83L,0UL,0xFCL,4UL,0UL,0x4AL}},{{8UL,2UL,2UL,253UL,0UL,4UL,0x3BL,255UL},{0x5FL,0UL,8UL,2UL,0x83L,2UL,0x3EL,0x70L},{255UL,0x6EL,0UL,2UL,0UL,0x6EL,255UL,249UL},{0x32L,255UL,0x5FL,8UL,255UL,0UL,250UL,3UL},{0x83L,249UL,4UL,0x1EL,255UL,0x3BL,0x70L,2UL},{0x32L,255UL,0UL,3UL,0UL,0x3EL,253UL,253UL},{255UL,0x83L,7UL,7UL,0x83L,255UL,0UL,250UL},{0x5FL,0x3BL,0x4AL,0UL,0UL,250UL,0x32L,255UL}},{{8UL,0x23L,249UL,0UL,0xFCL,0x70L,255UL,250UL},{255UL,0xFCL,0UL,7UL,4UL,253UL,255UL,253UL},{0UL,3UL,0x32L,3UL,0UL,0UL,255UL,2UL},{250UL,0x3EL,0x6EL,0x1EL,0x4AL,0x32L,8UL,3UL},{3UL,0x4FL,0x6EL,8UL,255UL,255UL,255UL,249UL},{0x4AL,0x5FL,0x32L,2UL,0x70L,255UL,255UL,0x70L},{2UL,0UL,0UL,2UL,249UL,255UL,255UL,255UL},{0x23L,0x70L,249UL,253UL,3UL,8UL,0x32L,0x4AL}}};
    int32_t l_7124[8][1][10] = {{{0x63935E4DL,0x6E412DF4L,0x7CBF5A23L,7L,(-10L),7L,0x7CBF5A23L,0x6E412DF4L,0x63935E4DL,0x7B146499L}},{{0xE1BE4F0DL,5L,0x7CBF5A23L,(-10L),0x6E412DF4L,0x6E412DF4L,(-10L),0x7CBF5A23L,5L,0xE1BE4F0DL}},{{5L,7L,0x63935E4DL,(-10L),0x0C671B2CL,0xE1BE4F0DL,0x0C671B2CL,(-10L),0x63935E4DL,7L}},{{0x7B146499L,0x7CBF5A23L,0xE1BE4F0DL,7L,0x0C671B2CL,0x5085E4CAL,0x5085E4CAL,0x0C671B2CL,5L,0x63935E4DL}},{{0x5085E4CAL,0x5085E4CAL,0x0C671B2CL,7L,0xE1BE4F0DL,0x7CBF5A23L,0x7B146499L,0x7CBF5A23L,0xE1BE4F0DL,7L}},{{7L,(-10L),7L,0x7CBF5A23L,0x6E412DF4L,0x63935E4DL,0x7B146499L,0x7B146499L,0x63935E4DL,0x6E412DF4L}},{{0x0C671B2CL,0x5085E4CAL,0x5085E4CAL,0x0C671B2CL,7L,0xE1BE4F0DL,0x7CBF5A23L,0x7B146499L,0x7CBF5A23L,0xE1BE4F0DL}},{{0x63935E4DL,(-1L),7L,(-1L),0x63935E4DL,5L,0x5085E4CAL,0x7CBF5A23L,0x7CBF5A23L,0x5085E4CAL}}};
    int64_t l_7146 = (-1L);
    const uint32_t **l_7212 = &l_6123[1][4][1];
    uint16_t l_7281 = 0UL;
    uint8_t ** const **l_7300 = (void*)0;
    uint8_t ** const ***l_7299 = &l_7300;
    int16_t l_7361 = (-4L);
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_5843[i] = &g_5844;
    for (i = 0; i < 3; i++)
        l_5880[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_5961[i] = &g_3706[1][0][2];
    for (i = 0; i < 2; i++)
        l_6057[i] = (void*)0;
    for (i = 0; i < 5; i++)
        l_6056[i] = &l_6057[1];
    for (i = 0; i < 1; i++)
        l_6108[i] = 1UL;
    for (i = 0; i < 10; i++)
        l_6115[i] = 0x6B024BC8D4822678LL;
    for (i = 0; i < 7; i++)
        l_6278[i] = &l_6279[6];
    for (i = 0; i < 1; i++)
        l_6762[i] = (-1L);
    for (i = 0; i < 3; i++)
        l_6997[i] = 0xD5290F8A08BE86FCLL;
    if (((l_6[4][0][0] = (safe_mod_func_uint64_t_u_u(0x9C4C8D3C891C5534LL, ((0x1F90EF30L == (safe_lshift_func_uint8_t_u_u(l_6[4][0][0], 0))) || func_7(l_6[6][1][0]))))) <= ((safe_add_func_int32_t_s_s((safe_sub_func_int16_t_s_s(((((l_5845 ^= (((((((*l_5831) = (g_1424 = (void*)0)) == &g_1426[1][1]) <= ((g_5834 = g_5834) == ((*l_5841) = ((safe_div_func_uint32_t_u_u((safe_mul_func_uint32_t_u_u((l_5840 < l_5840), l_5840)), l_5840)) , (void*)0)))) > 0x47989E0FL) , 0x88L) >= l_5840)) <= 0xA7L) & l_5840) , l_5845), g_5846)), l_5840)) ^ l_5847)))
    { /* block id: 2602 */
        int32_t *l_5848 = &g_1256;
        int32_t *l_5849 = &g_797;
        int32_t *l_5850[3];
        int64_t l_5852 = (-1L);
        uint64_t l_5853[1];
        union U1 *l_5860[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        uint32_t l_5908 = 0x2D93CB4DL;
        int32_t *l_5926 = &g_63;
        uint8_t l_5947 = 254UL;
        int i;
        for (i = 0; i < 3; i++)
            l_5850[i] = &g_614;
        for (i = 0; i < 1; i++)
            l_5853[i] = 0x83727A8E0570BBD4LL;
        ++l_5853[0];
        for (g_904 = 0; (g_904 <= 1); g_904 += 1)
        { /* block id: 2606 */
            int32_t l_5856[4][9] = {{5L,0xA780EEABL,0xA780EEABL,5L,0xA780EEABL,0xA780EEABL,5L,0xA780EEABL,0xA780EEABL},{0x7577C6F9L,(-1L),(-1L),0x7577C6F9L,(-1L),(-1L),0x7577C6F9L,(-1L),(-1L)},{5L,0xA780EEABL,0xA780EEABL,5L,0xA780EEABL,0xA780EEABL,5L,0xA780EEABL,0xA780EEABL},{0x7577C6F9L,(-1L),(-1L),0x7577C6F9L,(-1L),(-1L),0x7577C6F9L,(-1L),(-1L)}};
            union U1 *l_5857 = &g_3183[1][3][0];
            union U0 *l_5866[3];
            int32_t l_5876 = 1L;
            int32_t l_5910 = 0x636BD3B9L;
            uint32_t *l_5924 = &l_5908;
            int i, j;
            for (i = 0; i < 3; i++)
                l_5866[i] = &g_5867[9][3][1];
            for (g_822.f4 = 0; (g_822.f4 <= 1); g_822.f4 += 1)
            { /* block id: 2609 */
                return l_5856[0][4];
            }
            for (g_847 = 0; (g_847 <= 1); g_847 += 1)
            { /* block id: 2614 */
                union U1 *l_5858[10][2] = {{&g_55,&g_308[0][3]},{&g_4100,&g_308[0][3]},{&g_55,&g_4100},{(void*)0,(void*)0},{(void*)0,&g_4100},{&g_55,&g_308[0][3]},{&g_4100,&g_308[0][3]},{&g_55,&g_4100},{(void*)0,(void*)0},{(void*)0,&g_4100}};
                union U1 **l_5859 = &l_5857;
                int32_t l_5865 = 0xE5CE7A58L;
                uint64_t l_5878[8] = {0x9B344A9D59B07B4ALL,0x9B344A9D59B07B4ALL,0x64D060A246F1A9B4LL,0x9B344A9D59B07B4ALL,0x9B344A9D59B07B4ALL,0x64D060A246F1A9B4LL,0x9B344A9D59B07B4ALL,0x9B344A9D59B07B4ALL};
                int i, j;
                l_5860[3] = ((*l_5859) = (l_5858[3][1] = ((*g_180) = l_5857)));
                for (g_5071.f4 = 0; (g_5071.f4 <= 1); g_5071.f4 += 1)
                { /* block id: 2621 */
                    uint32_t *l_5870 = &g_1935;
                    int32_t l_5877 = 0x21B23BD6L;
                    (*g_62) ^= (safe_sub_func_int32_t_s_s((**g_2958), ((safe_add_func_int16_t_s_s((65533UL > l_5865), ((l_5866[0] == ((**g_3707) = l_5866[1])) , (safe_lshift_func_int8_t_s_u(((0x2A7B86B4L != (((**g_5179) = (*g_5180)) == l_5870)) , (((!((safe_sub_func_uint8_t_u_u((l_5876 |= (safe_sub_func_uint32_t_u_u(((0x4BC63AAA7F1CB0F6LL >= (*g_878)) < l_5856[3][1]), l_5865))), l_5877)) == (*l_5849))) <= l_5865) > (-1L))), l_5878[2]))))) >= l_5877)));
                    for (g_1788.f4 = 1; (g_1788.f4 >= 0); g_1788.f4 -= 1)
                    { /* block id: 2628 */
                        uint32_t ***l_5879 = &g_5825;
                        (*g_5834) = l_5850[0];
                        (*l_5849) = (((*l_5879) = (*g_5824)) == l_5880[0]);
                    }
                }
            }
            (*g_5299) = (safe_rshift_func_uint64_t_u_u((~(safe_mul_func_int32_t_s_s((safe_div_func_int8_t_s_s((safe_lshift_func_int64_t_s_s(0xD38CF82FACC85726LL, (safe_mod_func_uint64_t_u_u(((safe_mul_func_int32_t_s_s(((((**g_1357) && ((*g_4952) || (***g_4950))) >= (((*g_1151) = ((****g_3323) > (((l_5894 && ((*g_4604) &= l_5876)) & ((((*g_62) = ((((safe_lshift_func_uint32_t_u_s(((safe_rshift_func_uint16_t_u_u(((0xB171L == (safe_sub_func_int64_t_s_s((safe_sub_func_int32_t_s_s(((safe_mul_func_uint16_t_u_u(((((safe_mul_func_int64_t_s_s(l_5876, l_5856[1][0])) || 0x433205F3L) , g_3224) , l_5856[3][1]), l_5907)) , 7L), (***g_5179))), l_5856[0][4]))) , (*g_3326)), l_5856[1][1])) | 1L), 19)) || l_5876) <= l_5856[0][4]) ^ (***g_4452))) > (*g_1998)) , l_5908)) == g_5909))) > 0UL)) == l_5856[3][0]), l_5876)) >= l_5876), 5UL)))), l_5910)), (*l_5848)))), (*l_5848)));
            for (g_5909 = 1; (g_5909 >= 0); g_5909 -= 1)
            { /* block id: 2641 */
                uint32_t l_5921[2][3][4] = {{{1UL,0xB28892B9L,1UL,0xB28892B9L},{1UL,0xB28892B9L,1UL,0xB28892B9L},{1UL,0xB28892B9L,1UL,0xB28892B9L}},{{1UL,0xB28892B9L,1UL,0xB28892B9L},{1UL,0xB28892B9L,1UL,0xB28892B9L},{1UL,0xB28892B9L,1UL,0xB28892B9L}}};
                int32_t l_5923 = 0xEFED8763L;
                int i, j, k;
                for (g_746 = 1; (g_746 >= 0); g_746 -= 1)
                { /* block id: 2644 */
                    uint64_t *l_5922 = &l_5853[0];
                    int32_t l_5925 = 4L;
                    int i, j, k;
                    if (((safe_sub_func_int32_t_s_s(0L, (safe_lshift_func_int16_t_s_u((safe_div_func_int64_t_s_s((((((g_430[g_5909][(g_904 + 1)][g_746] || ((*g_1151) |= (***g_876))) > (l_5921[0][2][1] &= (safe_rshift_func_uint8_t_u_u(((**g_4019) = l_5856[0][4]), ((*g_4604) <= (safe_rshift_func_int8_t_s_u(0xA4L, 4))))))) < ((*l_5922) = (*l_5848))) > 0x2E11L) || (*l_5849)), l_5923)), (**g_3325))))) ^ (****g_5178)))
                    { /* block id: 2649 */
                        return l_5856[2][4];
                    }
                    else
                    { /* block id: 2651 */
                        (*l_5849) = (l_5925 ^= ((*g_62) = (((***g_5178) = l_5924) != (void*)0)));
                        if (g_430[g_5909][(g_904 + 1)][g_746])
                            break;
                        (*g_5834) = &l_5923;
                        return (**g_968);
                    }
                }
                for (g_4724.f4 = 0; (g_4724.f4 <= 1); g_4724.f4 += 1)
                { /* block id: 2663 */
                    return l_5921[1][2][1];
                }
            }
        }
        (*g_5559) = l_5926;
        (*g_5834) = ((*g_5559) = ((((*l_5848) && (~((((*g_1358) = ((~(safe_mod_func_int64_t_s_s((safe_unary_minus_func_uint8_t_u(((**g_4019)++))), (safe_lshift_func_int64_t_s_s(((*l_5848) || ((safe_unary_minus_func_uint8_t_u((((**g_877) && (((safe_sub_func_uint8_t_u_u(((((*l_5848) > (((safe_mod_func_int16_t_s_s(((((l_5941 , ((*l_5926) ^ (&g_5138[5][1] == (void*)0))) && (safe_add_func_int32_t_s_s(((safe_add_func_uint64_t_u_u(((*l_5849) , (*l_5848)), (-7L))) & (***g_876)), 0L))) , g_5946) <= 9L), (*g_3326))) , (*l_5849)) , (*l_5926))) & (****g_875)) ^ 0x1CBD785B97641365LL), (*l_5926))) , (*l_5849)) < 0x754DB8F8DCEE59ECLL)) < 0xEEABC117838487CCLL))) | 0x7FBDL)), l_5947))))) ^ (*l_5848))) <= 0xB008D83029CC429BLL) == l_6[4][0][0]))) & 0x26L) , (void*)0));
    }
    else
    { /* block id: 2675 */
        int16_t l_5954[10][3] = {{0x8422L,0x1E6BL,(-2L)},{1L,0x7904L,1L},{0xF0E0L,0x8422L,(-2L)},{0xBEF7L,0xBEF7L,0L},{8L,0x8422L,0x8422L},{0L,0x7904L,0xC15EL},{8L,0x1E6BL,8L},{0xBEF7L,0L,0xC15EL},{0xF0E0L,0xF0E0L,0x8422L},{1L,0L,0L}};
        union U0 *l_5955[8];
        int8_t l_5962 = 0x56L;
        uint16_t *l_5963[5];
        union U1 **l_5987 = &g_181;
        int16_t l_5995 = 0x7EC6L;
        int32_t l_5997[10] = {0x4ADCBAB7L,0x43CCADADL,0L,0L,0x43CCADADL,0x4ADCBAB7L,0x43CCADADL,0L,0L,0x43CCADADL};
        int i, j;
        for (i = 0; i < 8; i++)
            l_5955[i] = &g_5956[5];
        for (i = 0; i < 5; i++)
            l_5963[i] = (void*)0;
        if (((((safe_add_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(((***g_971) , ((**g_1357) ^ 0x372003EE875235AELL)), (g_267 = (((safe_div_func_int64_t_s_s((((l_5954[5][2] || l_5954[7][2]) , (l_5955[7] == (void*)0)) > (safe_add_func_int16_t_s_s(0x1E43L, ((((safe_add_func_uint32_t_u_u(((void*)0 != l_5961[0]), l_5954[5][2])) == l_5954[9][1]) > l_5954[4][2]) > (**g_3325))))), l_5962)) <= 6UL) , l_5954[5][2])))), (***g_4452))) & l_5954[5][2]) || (-10L)) ^ l_5954[3][1]))
        { /* block id: 2677 */
            uint64_t l_5983 = 18446744073709551609UL;
            const union U1 ***l_5986 = &g_252;
            union U1 ***l_5988[7][2] = {{&g_180,(void*)0},{&l_5987,(void*)0},{&g_180,&g_180},{&g_180,&g_180},{(void*)0,&l_5987},{(void*)0,&g_180},{&g_180,&g_180}};
            int i, j;
            for (g_571 = 5; (g_571 != 19); g_571 = safe_add_func_uint8_t_u_u(g_571, 7))
            { /* block id: 2680 */
                for (g_5621 = 12; (g_5621 == 43); g_5621 = safe_add_func_int64_t_s_s(g_5621, 1))
                { /* block id: 2683 */
                    int32_t *l_5968 = &g_1578;
                    int32_t *l_5969 = &g_362;
                    int32_t *l_5970 = &l_6[5][3][0];
                    int32_t *l_5971 = &l_6[4][0][0];
                    int32_t *l_5972 = (void*)0;
                    int32_t *l_5973 = &g_63;
                    int32_t *l_5974 = &g_1578;
                    int32_t *l_5975 = &g_797;
                    int32_t *l_5976 = &g_362;
                    int32_t *l_5977 = &l_6[4][0][0];
                    int32_t *l_5978 = (void*)0;
                    int32_t *l_5979 = &l_6[4][0][0];
                    int32_t *l_5980 = &l_5840;
                    int32_t *l_5981[5] = {&l_6[5][7][2],&l_6[5][7][2],&l_6[5][7][2],&l_6[5][7][2],&l_6[5][7][2]};
                    int8_t l_5982[7] = {1L,0x03L,0x03L,1L,0x03L,0x03L,1L};
                    int i;
                    ++l_5983;
                    (*l_5979) ^= (*g_116);
                }
            }
            (**g_5834) = ((((*l_5986) = (void*)0) == (g_180 = l_5987)) < (safe_rshift_func_uint8_t_u_s(0x41L, 4)));
            (*g_5991) = (*g_2486);
        }
        else
        { /* block id: 2692 */
            uint8_t l_5996 = 0UL;
            l_5997[0] ^= ((*g_1998) != ((safe_div_func_uint32_t_u_u(l_5995, l_5954[5][2])) != l_5996));
        }
    }
    if ((safe_add_func_uint8_t_u_u((l_6021 , l_6022), l_6[4][0][0])))
    { /* block id: 2699 */
        int8_t l_6037 = 0xA8L;
        uint64_t l_6039 = 0x911081247170F5F0LL;
        int32_t l_6107 = 1L;
        int32_t l_6227 = 0xCB1ACCEBL;
        uint16_t l_6230 = 0xCD84L;
        int32_t * const l_6253 = &l_6[2][5][1];
        int32_t l_6267 = 0L;
        const int32_t l_6322 = 0L;
        uint32_t *****l_6393[7] = {&g_4775[0][4][2],&g_4775[0][4][2],&g_4775[0][4][2],&g_4775[0][4][2],&g_4775[0][4][2],&g_4775[0][4][2],&g_4775[0][4][2]};
        const int32_t l_6399[5][8] = {{0xF7172A7FL,4L,0x06D24975L,0x06D24975L,4L,0xF7172A7FL,0x0A90C0CEL,0x0A90C0CEL},{0xF7172A7FL,4L,0x06D24975L,0x06D24975L,4L,0xF7172A7FL,0x0A90C0CEL,0x0A90C0CEL},{0xF7172A7FL,4L,0x06D24975L,0x06D24975L,4L,0xF7172A7FL,0x0A90C0CEL,0x0A90C0CEL},{0xF7172A7FL,4L,0x06D24975L,0x06D24975L,4L,0xF7172A7FL,0x0A90C0CEL,0x0A90C0CEL},{0xF7172A7FL,4L,0x06D24975L,0x06D24975L,4L,0xF7172A7FL,0x0A90C0CEL,0x0A90C0CEL}};
        int32_t * const l_6400 = &g_614;
        int32_t *l_6405 = &g_241;
        int64_t *l_6467 = &l_6023;
        uint32_t ****l_6469 = &l_6278[4];
        uint8_t *l_6529 = &g_3183[1][3][0].f0;
        uint16_t l_6567 = 0x67BBL;
        int64_t l_6569[5] = {0x5D40D2A30F21ED14LL,0x5D40D2A30F21ED14LL,0x5D40D2A30F21ED14LL,0x5D40D2A30F21ED14LL,0x5D40D2A30F21ED14LL};
        uint32_t l_6570 = 0xEDACB7E9L;
        uint16_t *****l_6572 = &l_6055;
        uint16_t l_6573 = 0xAB0CL;
        int32_t l_6574 = 1L;
        uint64_t * const ****l_6589 = &g_3635[0];
        uint8_t l_6604[8] = {0x21L,0x21L,0xFFL,0x21L,0x21L,0xFFL,0x21L,0x21L};
        int64_t l_6607 = 7L;
        uint8_t ***l_6622 = &g_5140;
        int i, j;
        if (l_6023)
        { /* block id: 2700 */
            const int32_t l_6024[8][10][1] = {{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}},{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}},{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}},{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}},{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}},{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}},{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}},{{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L},{0x2FD910AEL},{3L}}};
            int32_t l_6027 = 0x5610CC11L;
            int32_t l_6060[3][10] = {{0x747D204FL,0x10DA3370L,0x10DA3370L,0x747D204FL,0x495CF971L,0x6D126AFCL,0x747D204FL,0x6D126AFCL,0x495CF971L,0x747D204FL},{0x6D126AFCL,0x747D204FL,0x6D126AFCL,0x495CF971L,0x747D204FL,0x10DA3370L,0x10DA3370L,0x747D204FL,0x495CF971L,0x6D126AFCL},{0x1D2AEE67L,0x1D2AEE67L,(-4L),0x747D204FL,2L,(-4L),2L,0x747D204FL,(-4L),0x1D2AEE67L}};
            uint8_t l_6103[10][10] = {{0x4CL,0UL,0x5CL,1UL,0x5CL,0UL,0x4CL,0UL,0x5CL,1UL},{0x5CL,0UL,246UL,1UL,0x5CL,1UL,246UL,0UL,246UL,1UL},{0x5CL,0UL,0x4CL,0UL,0x5CL,1UL,0x5CL,0UL,0x4CL,0UL},{0x5CL,1UL,246UL,0UL,246UL,1UL,0x5CL,1UL,246UL,0UL},{246UL,0UL,246UL,1UL,0x5CL,1UL,246UL,0UL,246UL,1UL},{0x5CL,0UL,0x4CL,0UL,0x5CL,1UL,0x5CL,0UL,0x4CL,0UL},{0x5CL,1UL,246UL,0UL,246UL,1UL,0x5CL,1UL,246UL,0UL},{246UL,0UL,246UL,1UL,0x5CL,1UL,246UL,0UL,246UL,1UL},{0x5CL,0UL,0x4CL,0UL,0x5CL,1UL,0x5CL,0UL,0x4CL,0UL},{0x5CL,1UL,246UL,0UL,246UL,1UL,0x5CL,1UL,246UL,0UL}};
            int32_t * const l_6113[7] = {&g_63,&g_63,&g_63,&g_63,&g_63,&g_63,&g_63};
            uint8_t *****l_6168 = &g_5138[5][1];
            int16_t l_6192 = 0x7720L;
            uint32_t l_6212 = 0xFA365AE2L;
            int32_t * const l_6257 = (void*)0;
            int16_t l_6264 = (-1L);
            uint16_t l_6273 = 4UL;
            uint64_t l_6288 = 0x4EA558177F43D515LL;
            union U0 **l_6292 = &g_924;
            uint8_t l_6301 = 2UL;
            union U1 l_6302 = {9UL};
            const uint32_t l_6315[6][1] = {{0xA811EDE0L},{0xA811EDE0L},{0x2E1F5FF8L},{0xA811EDE0L},{0xA811EDE0L},{0x2E1F5FF8L}};
            int64_t l_6320 = 0xCB6F4310AD3A4FA5LL;
            uint8_t l_6358[4];
            uint16_t l_6359[5] = {0x7DA2L,0x7DA2L,0x7DA2L,0x7DA2L,0x7DA2L};
            int64_t l_6362 = 0x2C8B5A403E974D81LL;
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_6358[i] = 0x62L;
            if (l_6024[0][7][0])
            { /* block id: 2701 */
                int16_t l_6036 = 0xEB83L;
                uint32_t *l_6071[4][8];
                uint32_t **l_6070 = &l_6071[3][2];
                uint32_t ***l_6069 = &l_6070;
                uint32_t ****l_6068 = &l_6069;
                uint32_t *****l_6067[1][5] = {{&l_6068,&l_6068,&l_6068,&l_6068,&l_6068}};
                uint8_t l_6081 = 0x0CL;
                const int8_t *l_6100 = &g_4121;
                const int8_t **l_6099 = &l_6100;
                int8_t ****l_6125 = (void*)0;
                int16_t **l_6167 = &g_969;
                const int32_t l_6169 = 0xD0E67411L;
                int32_t ****l_6224[10][7] = {{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833},{&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833,&g_3833}};
                int32_t l_6231[9] = {0xFDBBCA53L,0xFDBBCA53L,0xFDBBCA53L,0xFDBBCA53L,0xFDBBCA53L,0xFDBBCA53L,0xFDBBCA53L,0xFDBBCA53L,0xFDBBCA53L};
                int i, j;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 8; j++)
                        l_6071[i][j] = &g_4045;
                }
lbl_6249:
                if ((safe_div_func_int64_t_s_s(((**g_4453) = l_6024[5][7][0]), l_6024[0][7][0])))
                { /* block id: 2703 */
                    int8_t l_6050 = 0xEAL;
                    uint16_t *l_6051 = &l_5894;
                    uint16_t *l_6052 = &g_3286;
                    uint64_t **l_6054 = &g_1151;
                    int16_t l_6058[10] = {0xE082L,0x2CADL,0xE082L,(-1L),(-1L),0xE082L,0x2CADL,0xE082L,(-1L),(-1L)};
                    int32_t *l_6104 = (void*)0;
                    int32_t *l_6105 = &g_63;
                    int32_t *l_6106[10][1];
                    int32_t **l_6114 = &l_6104;
                    int32_t **l_6116 = (void*)0;
                    int32_t **l_6117 = &l_6106[9][0];
                    int32_t **l_6118 = &l_6104;
                    const uint32_t **l_6119 = (void*)0;
                    const uint32_t *l_6121 = &g_6122;
                    const uint32_t **l_6120[4][3][4] = {{{&l_6121,&l_6121,(void*)0,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121}},{{&l_6121,&l_6121,(void*)0,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121}},{{&l_6121,&l_6121,(void*)0,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121}},{{&l_6121,&l_6121,(void*)0,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121},{&l_6121,&l_6121,&l_6121,&l_6121}}};
                    int i, j, k;
                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_6106[i][j] = (void*)0;
                    }
                    l_6027 = 0x1265C878L;
                    if (((safe_sub_func_uint32_t_u_u(((safe_mod_func_int64_t_s_s((-8L), 0xE8606C40F819E79BLL)) , ((safe_lshift_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((((((l_6036 > 1UL) < (l_6037 , ((~(l_6039 || (safe_lshift_func_uint16_t_u_u(l_6024[6][9][0], 9)))) && ((l_6024[0][7][0] ^ ((((*l_6052) |= ((*l_6051) = ((safe_lshift_func_uint64_t_u_s(((safe_sub_func_uint64_t_u_u((((safe_rshift_func_int64_t_s_s((safe_mul_func_uint32_t_u_u(0UL, l_6024[6][5][0])), 60)) & l_5845) , l_6050), 0x861374F6D089EBB2LL)) , l_6050), 50)) ^ l_6024[3][9][0]))) , g_6053) , 0x9BD3A37988793C4BLL)) , l_6036)))) , (void*)0) == l_6054) == l_6036), l_6024[5][5][0])), 45)) ^ (**g_877))), 4294967295UL)) != 0x6C7BD647B3F9055BLL))
                    { /* block id: 2707 */
                        l_6058[4] = ((void*)0 == l_6055);
                    }
                    else
                    { /* block id: 2709 */
                        int8_t l_6059 = 0x74L;
                        int32_t *l_6061 = &g_1578;
                        int32_t *l_6062 = &l_6[4][0][2];
                        int32_t *l_6063[4][9][7] = {{{&l_6016,&l_6[4][0][0],&g_117,(void*)0,&g_362,&g_362,(void*)0},{&g_1256,&g_362,&g_1256,(void*)0,&g_117,(void*)0,&g_362},{(void*)0,&l_6016,&l_6016,(void*)0,&l_6[0][2][2],(void*)0,(void*)0},{&l_5840,&l_6[4][0][0],&g_117,&g_1256,(void*)0,(void*)0,&l_6[4][0][0]},{&g_117,&g_362,&l_6[4][0][0],&g_1578,&l_6[4][0][0],&g_362,&g_117},{&g_117,&g_117,&l_5845,&l_6[4][0][0],&g_362,&g_117,&l_6[4][0][0]},{&l_5840,&l_6[0][2][2],&g_1256,&l_6[4][0][0],(void*)0,(void*)0,&l_6[0][2][2]},{(void*)0,(void*)0,&l_5845,&g_117,&l_5845,(void*)0,&l_5845},{&g_1256,&l_6[4][0][0],&l_6[4][0][0],&g_1256,&l_5845,(void*)0,&l_6[4][0][0]}},{{&l_6016,&g_362,&g_117,&l_6016,(void*)0,(void*)0,&g_117},{(void*)0,(void*)0,&l_6016,&g_117,&g_362,&l_6016,&l_6[4][0][0]},{(void*)0,&l_5845,&g_1256,&l_6[4][0][0],&l_6[4][0][0],&g_1256,&l_5845},{(void*)0,&l_5845,&g_117,&l_5845,(void*)0,(void*)0,&l_6[0][2][2]},{(void*)0,(void*)0,&l_6[4][0][0],&g_1256,&l_6[0][2][2],&l_5840,&l_6[4][0][0]},{&g_117,&g_362,&l_6[4][0][0],&l_5845,&g_117,&g_117,&g_117},{&g_362,&l_6[4][0][0],&g_1578,&l_6[4][0][0],&g_362,&g_117,&l_6[4][0][0]},{(void*)0,(void*)0,&g_1256,&g_117,&l_6[4][0][0],&l_5840,(void*)0},{(void*)0,&l_6[0][2][2],(void*)0,&l_6016,&l_6016,(void*)0,&g_362}},{{(void*)0,&g_117,(void*)0,&g_1256,&g_362,&g_1256,&l_5840},{(void*)0,(void*)0,&l_5840,&l_6016,(void*)0,&l_6[4][0][0],&g_117},{&l_6[4][0][0],(void*)0,&l_5845,(void*)0,(void*)0,&l_6[4][0][0],(void*)0},{&g_1578,&g_117,(void*)0,(void*)0,(void*)0,&l_5845,&g_117},{&l_5840,&g_362,&g_362,&g_362,&g_362,&l_5840,&g_117},{&l_5845,(void*)0,(void*)0,(void*)0,&g_117,&g_1578,(void*)0},{&l_6[4][0][0],(void*)0,(void*)0,&l_5845,(void*)0,&l_6[4][0][0],&g_117},{&l_6[4][0][0],(void*)0,&l_6016,&l_5840,(void*)0,(void*)0,&l_5840},{(void*)0,&g_362,(void*)0,&l_5840,(void*)0,&l_6016,&g_362}},{{&l_5840,&g_117,(void*)0,&l_5845,(void*)0,&l_5840,&l_6016},{&g_117,(void*)0,(void*)0,(void*)0,&l_6016,&l_6016,(void*)0},{&g_117,(void*)0,&g_1256,&g_362,&g_1256,(void*)0,&g_117},{&g_117,(void*)0,&l_6[0][2][2],(void*)0,(void*)0,&l_6[4][0][0],&g_1256},{&g_117,(void*)0,(void*)0,(void*)0,&l_5840,&g_1578,(void*)0},{&l_5840,&l_6016,&l_6[0][2][2],&l_6016,&g_117,&l_5840,&g_117},{(void*)0,&g_1256,&g_1256,(void*)0,&g_117,&l_5845,(void*)0},{&l_6[4][0][0],(void*)0,(void*)0,(void*)0,&l_5840,&l_6[4][0][0],&g_117},{&l_6[4][0][0],&l_5840,(void*)0,(void*)0,(void*)0,&l_6[4][0][0],(void*)0}}};
                        uint16_t l_6086[9];
                        const uint8_t *l_6101[2][2] = {{&g_613,&g_613},{&g_613,&g_613}};
                        int i, j, k;
                        for (i = 0; i < 9; i++)
                            l_6086[i] = 0UL;
                        --g_6064;
                        l_6067[0][2] = l_6067[0][3];
                        (*g_62) = (((safe_add_func_int8_t_s_s((((((((***g_4452) = 0x41E0B86AE6AF81B9LL) <= (safe_add_func_int64_t_s_s((((((safe_rshift_func_uint64_t_u_u((l_6060[0][1] |= ((**l_6054) ^= 0UL)), 2)) >= (~(safe_lshift_func_int32_t_s_s(((l_6081 >= (((1L & (safe_add_func_uint64_t_u_u(((void*)0 == (*g_1357)), (((((safe_sub_func_uint8_t_u_u(l_6086[6], (safe_mod_func_int32_t_s_s((safe_add_func_int8_t_s_s((**g_731), ((((~((++(*l_6051)) || (((safe_mul_func_int64_t_s_s((safe_mod_func_int64_t_s_s(g_6098, 8L)), g_4121)) , (void*)0) == l_6099))) > l_6037) | 1UL) != (**g_877)))), l_6039)))) , l_6101[0][1]) != (void*)0) | l_6058[7]) ^ l_6036)))) || (-5L)) && (*g_4604))) > l_6039), 28)))) & l_6039) | (****g_3323)) < 0xD313ECD88B9816E2LL), l_6027))) ^ (*g_3326)) < g_6102) , l_6039) != 0x78L), l_6103[4][8])) > 0xC6L) , 0L);
                        return (*l_6061);
                    }
                    l_6108[0]--;
                    (*l_6105) ^= ((*g_3326) >= (((((l_6123[2][5][3] = l_6071[0][2]) != l_6113[4]) , l_6125) != l_6126) == 0x58L));
                }
                else
                { /* block id: 2726 */
                    uint32_t l_6136 = 0xB1E9B394L;
                    int32_t l_6137 = 4L;
                    uint8_t l_6170 = 0xEBL;
                    int64_t l_6191 = 0xCFCA353C84CDCD1BLL;
                    int32_t l_6229[2][2] = {{(-1L),(-1L)},{(-1L),(-1L)}};
                    int32_t l_6239 = 2L;
                    int i, j;
                    if ((safe_lshift_func_uint16_t_u_u(65529UL, ((((!(18446744073709551610UL || (l_6107 = ((l_6039 && (l_6137 = ((safe_div_func_int64_t_s_s((***g_4452), (((((0x59F39DD5L == (l_6036 ^ ((l_6039 == 18446744073709551613UL) != (((safe_lshift_func_int32_t_s_u((l_6136 ^ (-8L)), 22)) <= l_6107) > l_6037)))) == l_6037) , 0x38A38857451786B5LL) != (***g_4452)) , 1L))) < (*g_827)))) != l_6136)))) , 0xD9E90BB90DEA416DLL) > l_6036) >= 4294967288UL))))
                    { /* block id: 2729 */
                        int32_t l_6138 = 0L;
                        int16_t ** const l_6166 = &g_969;
                        int32_t l_6173 = 0x40204CBBL;
                        l_6138 = ((*g_62) = l_6039);
                        (*g_62) = (safe_lshift_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u((l_6081 , (safe_mul_func_uint64_t_u_u((safe_sub_func_int64_t_s_s((safe_lshift_func_int16_t_s_u(((**g_4951) >= l_6036), (g_3286 = ((safe_div_func_uint8_t_u_u((~0xA352FA4FL), (safe_rshift_func_uint32_t_u_s(((((--g_267) && (((safe_div_func_int64_t_s_s(((((safe_mul_func_uint64_t_u_u(4UL, (l_6162 != (((**g_4019) = (~(((safe_lshift_func_int64_t_s_u(((*g_4774) == (*g_5177)), 59)) ^ (l_6166 == l_6167)) | (***g_4452)))) , (*g_4451))))) > l_6081) , l_6168) == &g_5138[5][0]), l_6169)) == l_6136) >= l_6170)) <= l_6039) & l_6039), l_6169)))) , l_6107)))), l_6138)), 0x328C551A62C5EF1CLL))), 3)), 3));
                        l_6173 &= (safe_rshift_func_int32_t_s_s(((*g_62) &= 0x88C1A111L), 25));
                    }
                    else
                    { /* block id: 2738 */
                        uint32_t l_6177 = 0xB045A7DFL;
                        uint8_t l_6184 = 0x57L;
                        l_6192 = (((l_6039 , 1UL) != (((+((**g_4453) = (safe_add_func_int64_t_s_s((l_6177 != ((*g_62) &= (safe_mul_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((((*g_4952) = ((safe_rshift_func_uint64_t_u_s(((l_6177 != (&g_4829 == (void*)0)) , ((((l_6184 , ((l_6186 = g_6185[1][1]) != g_6190)) , l_6184) || l_6184) , (*g_878))), l_6170)) > l_6170)) >= l_6081), l_6191)), 0x54L)))), (**g_1357))))) , (**g_4951)) < 0x3DL)) >= 0x0CE3L);
                    }
                    if (l_6037)
                    { /* block id: 2745 */
                        int32_t *l_6200 = &g_1578;
                        int32_t l_6204 = 0xFF536A18L;
                        (*g_62) = ((safe_add_func_uint64_t_u_u((safe_lshift_func_uint32_t_u_u(((~(safe_sub_func_uint8_t_u_u((255UL >= l_6191), (**g_4019)))) , l_6037), ((((l_6200 = &l_6137) == &l_6137) , l_6170) || l_6191))), ((safe_add_func_uint8_t_u_u(((g_267 ^= ((safe_unary_minus_func_uint64_t_u(((((*g_4604) = (*g_4604)) <= (***g_4950)) | (*g_3326)))) && l_6204)) > l_6036), l_6107)) , (**g_4453)))) || (-1L));
                        (*l_6200) ^= l_6081;
                    }
                    else
                    { /* block id: 2751 */
                        uint8_t l_6209 = 0x44L;
                        const int32_t *****l_6215 = &g_6213;
                        int32_t l_6226 = 0x893F995EL;
                        int32_t l_6228 = 0x992A7126L;
                        l_6231[4] |= ((l_6016 = ((safe_rshift_func_uint16_t_u_s((safe_sub_func_uint16_t_u_u(l_6209, (l_6229[1][1] = (l_6228 = (safe_rshift_func_int8_t_s_u((((**g_1357) & (l_6227 = (l_6209 == ((l_6212 == (&g_3833 == ((*l_6215) = g_6213))) | (l_6226 = (safe_add_func_int8_t_s_s(((l_6137 = (((***g_825) <= (((**l_6167) = (((safe_add_func_uint32_t_u_u((((g_6222 = (l_6037 >= ((*g_62) = (safe_mod_func_int32_t_s_s((*g_62), 3UL))))) , l_6223) != (void*)0), 3UL)) , l_6224[6][1]) != l_6225)) & 0x3609L)) == l_6137)) != l_6037), l_6209))))))) <= l_6170), 7)))))), 4)) < l_6169)) < l_6230);
                        if (g_1329)
                            goto lbl_6232;
lbl_6232:
                        (*g_62) = 0xC9962A83L;
                        l_6226 |= (safe_rshift_func_int8_t_s_u((((safe_mul_func_int32_t_s_s((safe_add_func_int8_t_s_s(((((*g_1358) , (l_6239 >= ((((*g_62) = (safe_mul_func_uint64_t_u_u(1UL, ((***g_4452) , (safe_lshift_func_int32_t_s_s(0L, (safe_unary_minus_func_uint64_t_u(l_6231[6])))))))) && ((safe_mul_func_uint64_t_u_u(0x0F4AADDDF1ED5DACLL, ((***g_4452) = (l_6239 != (((l_6228 = (**g_4019)) != 0x1EL) && l_6191))))) && (**g_731))) == l_6247))) == l_6209) , (**g_731)), l_6229[0][1])), 0x5CDFA80DL)) != (****g_3323)) >= l_6248), 4));
                        if (l_6039)
                            goto lbl_6249;
                    }
                }
                l_6231[3] = (safe_unary_minus_func_uint16_t_u(6UL));
                l_6231[4] ^= (*g_62);
            }
            else
            { /* block id: 2774 */
                uint32_t l_6251 = 1UL;
                const int32_t *l_6258[2][8] = {{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614,&g_614,&g_614}};
                int32_t l_6266 = 0x42DA1306L;
                int32_t *l_6281 = (void*)0;
                int32_t l_6295[6][5][4] = {{{0xF0802C27L,0x98FC69B2L,(-1L),0x98FC69B2L},{0x98FC69B2L,1L,0L,0x98FC69B2L},{0L,0x98FC69B2L,0xC984BED9L,0xC984BED9L},{0xAFEA6DCAL,0xAFEA6DCAL,(-1L),0xF0802C27L},{0xAFEA6DCAL,1L,0xC984BED9L,0xAFEA6DCAL}},{{0L,0xF0802C27L,0L,0xC984BED9L},{0x98FC69B2L,0xF0802C27L,(-1L),0xAFEA6DCAL},{0xF0802C27L,1L,1L,0xF0802C27L},{0L,0xAFEA6DCAL,1L,0xC984BED9L},{0xF0802C27L,0x98FC69B2L,(-1L),0x98FC69B2L}},{{0x98FC69B2L,1L,0L,0x98FC69B2L},{0L,0x98FC69B2L,0xC984BED9L,1L},{0L,0L,0xAFEA6DCAL,1L},{0L,(-1L),1L,0L},{0L,1L,0L,1L}},{{0xC984BED9L,1L,0xAFEA6DCAL,0L},{1L,(-1L),(-1L),1L},{0L,0L,(-1L),1L},{1L,0xC984BED9L,0xAFEA6DCAL,0xC984BED9L},{0xC984BED9L,(-1L),0L,0xC984BED9L}},{{0L,0xC984BED9L,1L,1L},{0L,0L,0xAFEA6DCAL,1L},{0L,(-1L),1L,0L},{0L,1L,0L,1L},{0xC984BED9L,1L,0xAFEA6DCAL,0L}},{{1L,(-1L),(-1L),1L},{0L,0L,(-1L),1L},{1L,0xC984BED9L,0xAFEA6DCAL,0xC984BED9L},{0xC984BED9L,(-1L),0L,0xC984BED9L},{0L,0xC984BED9L,1L,1L}}};
                uint32_t ***l_6298 = &l_6279[6];
                uint32_t ****l_6300 = &l_6278[1];
                uint32_t *****l_6299 = &l_6300;
                uint64_t l_6337[8];
                int i, j, k;
                for (i = 0; i < 8; i++)
                    l_6337[i] = 18446744073709551613UL;
                (*g_5834) = &l_6060[0][1];
                if (l_6251)
                { /* block id: 2776 */
                    int32_t * const l_6252 = (void*)0;
                    int32_t **l_6254[5][4] = {{&g_5835,(void*)0,(void*)0,&g_5835},{(void*)0,(void*)0,&g_1139[0],(void*)0},{(void*)0,&g_1139[0],&g_1139[0],&g_1139[0]},{(void*)0,(void*)0,(void*)0,&g_1139[0]},{&g_5835,&g_1139[0],&g_5835,(void*)0}};
                    int32_t **l_6255 = &g_5835;
                    const int32_t **l_6260 = &g_543;
                    int i, j;
                    (*l_6260) = l_6258[1][0];
                    for (g_3212 = 0; (g_3212 > (-20)); --g_3212)
                    { /* block id: 2781 */
                        uint16_t l_6263[8][9][3] = {{{2UL,0UL,0UL},{0UL,0x86C3L,65531UL},{0x871BL,0x88A5L,1UL},{0x9DF8L,0xC051L,1UL},{0xF216L,0xEF7EL,0UL},{65534UL,9UL,0x0D4FL},{0x82BEL,0x2895L,0UL},{0x6E06L,0x4FDBL,0UL},{65535UL,0UL,0xBA7BL}},{{0x4FDBL,65535UL,0x4FDBL},{1UL,0UL,0x871BL},{0xBE1BL,0UL,0x2506L},{1UL,1UL,1UL},{0x4099L,65535UL,0xEC30L},{1UL,0x4B5EL,0x9D4FL},{0xBE1BL,0x9DF8L,1UL},{1UL,65531UL,0UL},{0x4FDBL,0xE251L,0x7CDEL}},{{65535UL,0xF415L,0x86C3L},{0x6E06L,0xDD65L,8UL},{0x82BEL,0x5B97L,0x6E06L},{65534UL,0xF216L,65526UL},{0xF216L,0x9758L,65535UL},{0x9DF8L,0x9D4FL,0UL},{0x871BL,3UL,0xE251L},{0UL,1UL,0xD4ADL},{2UL,1UL,0xF216L}},{{6UL,1UL,0UL},{0xEF7EL,1UL,0x620AL},{0x44C5L,3UL,0UL},{0xF415L,0x9D4FL,0xD7B8L},{3UL,0x9758L,0x82BEL},{0x620AL,0UL,1UL},{0x4B5EL,65535UL,2UL},{0x7CDEL,65526UL,9UL},{0UL,0x4D2EL,0x82BEL}},{{0xBE1BL,0x0D4FL,0xF415L},{1UL,1UL,0xEC30L},{0x9DF8L,2UL,65531UL},{0xD7B8L,0x8AFBL,65535UL},{0x871BL,0xF415L,0xDD65L},{0x5B97L,0xD7B8L,65535UL},{65535UL,9UL,65531UL},{65535UL,0UL,0xEC30L},{0x9865L,0xF216L,0xF415L}},{{1UL,65535UL,0x82BEL},{65535UL,2UL,9UL},{0xC39EL,0x620AL,2UL},{0x6E06L,0x9758L,1UL},{0xDD65L,0x748BL,0xC051L},{0x8AFBL,65531UL,0x4B5EL},{0UL,65535UL,0x2506L},{0x4099L,0x5B97L,65535UL},{0xBA7BL,0x2506L,0xD4ADL}},{{8UL,0xEC30L,0UL},{8UL,0UL,0x4099L},{0xBA7BL,65534UL,0x0D4FL},{0x4099L,0x4B5EL,65534UL},{0UL,4UL,0x4FDBL},{0x8AFBL,1UL,1UL},{0xDD65L,65535UL,1UL},{0x6E06L,0x1992L,0xC39EL},{0xC39EL,0x6828L,0x5B97L}},{{65535UL,65531UL,0x50A5L},{1UL,0UL,0UL},{0x9865L,1UL,0xD7B8L},{65535UL,0x44C5L,0x6E06L},{65535UL,0xBE1BL,0UL},{0x5B97L,2UL,0UL},{0x871BL,0xBE1BL,0xE797L},{0xD7B8L,0x44C5L,65535UL},{0x9DF8L,1UL,2UL}}};
                        int32_t l_6265 = (-1L);
                        int i, j, k;
                        if (l_6263[6][2][0])
                            break;
                        (*g_180) = (void*)0;
                        g_6268--;
                    }
                    for (g_123.f4 = (-13); (g_123.f4 > (-9)); g_123.f4 = safe_add_func_int64_t_s_s(g_123.f4, 9))
                    { /* block id: 2788 */
                        ++l_6273;
                        (*l_6253) = 1L;
                    }
                    for (g_4027 = 0; (g_4027 == 18); g_4027 = safe_add_func_int32_t_s_s(g_4027, 4))
                    { /* block id: 2794 */
                        (*g_5835) ^= ((void*)0 == l_6278[4]);
                        (*g_5835) ^= 0xA6820BC2L;
                        (*g_5561) = l_6281;
                    }
                }
                else
                { /* block id: 2799 */
                    uint32_t l_6284 = 0x7CF54094L;
                    (*g_5559) = &l_6267;
                    (**g_5834) |= ((safe_add_func_uint8_t_u_u((l_6284 | (l_6284 ^ (safe_lshift_func_int32_t_s_s((((*g_1151) |= 1UL) != ((0x5B68E901L <= l_6287[7][1]) , (0xA5L >= ((g_6098 &= l_6284) == ((((void*)0 == l_6258[1][6]) >= 0x2262C16939FABEC2LL) && l_6288))))), (*g_62))))), 1UL)) && 255UL);
                }
                if ((g_6289 , (((safe_rshift_func_uint64_t_u_s((l_6292 != (((**g_2584) = l_6302) , l_6292)), 18)) | (*g_4020)) ^ (**g_4453))))
                { /* block id: 2808 */
                    int8_t ** const ***l_6303 = &g_4949[0][1][5];
                    int8_t l_6308 = 0L;
                    int32_t l_6321 = (-2L);
                    l_6303 = &g_4949[0][2][0];
                    if ((safe_mod_func_uint8_t_u_u(0xC4L, ((0L != ((safe_rshift_func_int16_t_s_s(l_6308, (((*g_62) &= ((*l_6253) = (safe_div_func_int8_t_s_s((safe_add_func_int32_t_s_s(((safe_sub_func_uint32_t_u_u(0xB9B9C46BL, (l_6315[3][0] , (((***l_6299) == (g_6316 = (void*)0)) == (safe_mul_func_uint64_t_u_u(l_6320, ((l_6321 |= ((**g_968) || l_6308)) && 0xE6L))))))) ^ 1L), (*l_6253))), l_6322)))) , (**g_968)))) == 0x7DL)) , (*l_6253)))))
                    { /* block id: 2814 */
                        (*g_5299) ^= (safe_rshift_func_int32_t_s_s((*g_62), (*l_6253)));
                    }
                    else
                    { /* block id: 2816 */
                        int32_t l_6325[9] = {(-3L),0xBD5A19B6L,(-3L),(-3L),0xBD5A19B6L,(-3L),(-3L),0xBD5A19B6L,(-3L)};
                        int8_t l_6326 = 0xD4L;
                        int i;
                        l_6327++;
                    }
lbl_6332:
                    for (g_764 = 0; (g_764 > 34); ++g_764)
                    { /* block id: 2821 */
                        (*g_6213) = (*g_6213);
                        if (g_55.f0)
                            goto lbl_6332;
                    }
                    for (g_1411.f4 = (-16); (g_1411.f4 <= 12); ++g_1411.f4)
                    { /* block id: 2827 */
                        if ((**g_2958))
                            break;
                    }
                }
                else
                { /* block id: 2830 */
                    for (l_6301 = 13; (l_6301 <= 33); l_6301 = safe_add_func_uint8_t_u_u(l_6301, 3))
                    { /* block id: 2833 */
                        (**g_5834) |= (*g_5299);
                        (*g_5561) = &l_6266;
                        return g_6338[0][1][3];
                    }
                }
            }
            (*l_6253) = (safe_add_func_int8_t_s_s((4294967294UL ^ (g_6361[0][2][2] = ((safe_sub_func_int32_t_s_s(l_6019, (*l_6253))) != (safe_mod_func_int32_t_s_s((safe_mul_func_int32_t_s_s((((((*l_6253) && (((safe_div_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((safe_lshift_func_uint32_t_u_u((((*l_6253) != 7UL) < ((((*l_6253) ^ (safe_add_func_int16_t_s_s(((((*g_969) = (safe_mod_func_int8_t_s_s((*g_4952), (**g_4019)))) | (*g_3326)) < l_6357), 0xCB80L))) && (*l_6253)) == l_6358[2])), 31)), l_6359[0])), (***g_3324))) <= (*l_6253)) || (***g_971))) != l_5907) , l_6360[0][1]) ^ (*l_6253)), (*l_6253))), 0xCA4D73FAL))))), (*l_6253)));
            (*l_6292) = (***l_6015);
            (*l_6253) = (((*g_4952) = (*l_6253)) ^ l_6362);
        }
        else
        { /* block id: 2846 */
            int8_t l_6368 = 0x29L;
            int32_t l_6381 = 1L;
            int32_t l_6384 = 0x83357EFDL;
            uint32_t *****l_6394 = &g_4775[0][4][2];
            int32_t *l_6406 = &g_6338[0][1][3];
            int8_t *** const *l_6454 = &g_1059;
            union U0 *l_6455[9][5] = {{(void*)0,&g_5867[8][3][1],(void*)0,(void*)0,&g_5867[8][3][1]},{&g_4724,(void*)0,&g_1411,&g_4843[0],&g_1411},{&g_5867[8][3][1],&g_5867[8][3][1],&g_5956[3],&g_5867[8][3][1],&g_5867[8][3][1]},{&g_1411,&g_4843[0],&g_1411,(void*)0,&g_4724},{&g_5867[8][3][1],(void*)0,(void*)0,&g_5867[8][3][1],(void*)0},{&g_4724,&g_4843[0],(void*)0,&g_4843[0],&g_4724},{(void*)0,&g_5867[8][3][1],(void*)0,(void*)0,&g_5867[8][3][1]},{&g_4724,(void*)0,&g_1411,&g_4843[0],&g_1411},{&g_5867[8][3][1],&g_5867[8][3][1],&g_5956[3],&g_5867[8][3][1],&g_5867[8][3][1]}};
            uint32_t ****l_6456 = &l_6278[4];
            union U1 l_6472[7] = {{249UL},{249UL},{249UL},{249UL},{249UL},{249UL},{249UL}};
            uint32_t l_6513 = 0x4FDA1735L;
            int8_t l_6540 = (-1L);
            int i, j;
            if ((*l_6253))
            { /* block id: 2847 */
                uint32_t l_6377 = 18446744073709551611UL;
                int32_t *l_6378 = &g_6361[0][2][2];
                for (g_75 = 0; (g_75 == (-6)); g_75 = safe_sub_func_int8_t_s_s(g_75, 4))
                { /* block id: 2850 */
                    uint64_t l_6370[7][8] = {{0UL,0xED0F95E02EB1BFD2LL,0UL,18446744073709551607UL,1UL,0UL,18446744073709551607UL,0x0284CB11E991B368LL},{18446744073709551613UL,0xDB65BF2D71119301LL,0x152141CB012324ECLL,0x99354A906376FB94LL,0x9751AFD81C7C4C95LL,0xED0F95E02EB1BFD2LL,18446744073709551607UL,0xED0F95E02EB1BFD2LL},{0UL,0x9751AFD81C7C4C95LL,18446744073709551610UL,0x9751AFD81C7C4C95LL,0UL,0UL,18446744073709551613UL,18446744073709551607UL},{18446744073709551613UL,0xED0F95E02EB1BFD2LL,0xDB65BF2D71119301LL,1UL,18446744073709551607UL,0UL,2UL,0x9751AFD81C7C4C95LL},{18446744073709551610UL,4UL,0xDB65BF2D71119301LL,1UL,0x0284CB11E991B368LL,18446744073709551613UL,18446744073709551613UL,0x0284CB11E991B368LL},{18446744073709551607UL,18446744073709551610UL,18446744073709551610UL,18446744073709551607UL,0x99354A906376FB94LL,18446744073709551607UL,18446744073709551607UL,2UL},{1UL,0xDB65BF2D71119301LL,4UL,18446744073709551610UL,18446744073709551607UL,0UL,0x152141CB012324ECLL,1UL}};
                    int32_t l_6385 = 0x3D13EFB2L;
                    int32_t l_6386 = 1L;
                    int32_t l_6387[5][10][5] = {{{0L,1L,1L,0xA591DF25L,1L},{0xD7AFD50CL,0x7B7D4C07L,0x7B7D4C07L,0xD7AFD50CL,0xE2DAB8C2L},{0x2891198AL,6L,3L,1L,1L},{0xD12EC8B3L,0xD7AFD50CL,0xD12EC8B3L,0xE2DAB8C2L,0xD7AFD50CL},{1L,1L,0xA591DF25L,1L,0xA591DF25L},{0x2D3E6A72L,0x2D3E6A72L,6L,0xD7AFD50CL,1L},{0L,0x2891198AL,0xA591DF25L,0xA591DF25L,0x2891198AL},{1L,0x7B7D4C07L,0xD12EC8B3L,1L,0xE2DAB8C2L},{6L,0x2891198AL,3L,0x2891198AL,6L},{0xD12EC8B3L,0x2D3E6A72L,0x7B7D4C07L,0xE2DAB8C2L,0x2D3E6A72L}},{{6L,1L,1L,6L,0xA591DF25L},{1L,0xD7AFD50CL,6L,0x2D3E6A72L,0x2D3E6A72L},{0L,6L,0L,0xA591DF25L,6L},{0x2D3E6A72L,0x7B7D4C07L,0xE2DAB8C2L,0x2D3E6A72L,0xE2DAB8C2L},{1L,1L,3L,6L,0x2891198AL},{0xD12EC8B3L,1L,0xE2DAB8C2L,0xE2DAB8C2L,1L},{0x2891198AL,1L,0L,0x2891198AL,0xA591DF25L},{0xD7AFD50CL,1L,6L,1L,0xD7AFD50CL},{0L,1L,1L,0xA591DF25L,1L},{0xD7AFD50CL,0x7B7D4C07L,0x7B7D4C07L,0xD7AFD50CL,0xE2DAB8C2L}},{{0x2891198AL,6L,3L,1L,1L},{0xD12EC8B3L,0xD7AFD50CL,0xD12EC8B3L,0xE2DAB8C2L,0xD7AFD50CL},{1L,1L,0xA591DF25L,1L,0xA591DF25L},{0x2D3E6A72L,0x2D3E6A72L,6L,0xD7AFD50CL,1L},{0L,0x2891198AL,0xA591DF25L,0xA591DF25L,0x2891198AL},{1L,0x7B7D4C07L,0xD12EC8B3L,1L,0xE2DAB8C2L},{6L,0x2891198AL,3L,0x2891198AL,6L},{0xD12EC8B3L,0x2D3E6A72L,0x7B7D4C07L,0xE2DAB8C2L,0x2D3E6A72L},{6L,1L,1L,6L,0xA591DF25L},{1L,0x7B7D4C07L,0x2D3E6A72L,0xD12EC8B3L,0xD12EC8B3L}},{{4L,1L,4L,0x79955036L,1L},{0xD12EC8B3L,6L,6L,0xD12EC8B3L,6L},{0L,0L,1L,1L,0xA591DF25L},{3L,0xE2DAB8C2L,6L,6L,0xE2DAB8C2L},{0xA591DF25L,3L,4L,0xA591DF25L,0x79955036L},{0x7B7D4C07L,0xE2DAB8C2L,0x2D3E6A72L,0xE2DAB8C2L,0x7B7D4C07L},{4L,0L,3L,0x79955036L,0L},{0x7B7D4C07L,6L,6L,0x7B7D4C07L,6L},{0xA591DF25L,1L,1L,0L,0L},{3L,0x7B7D4C07L,3L,6L,0x7B7D4C07L}},{{0L,3L,0x79955036L,0L,0x79955036L},{0xD12EC8B3L,0xD12EC8B3L,0x2D3E6A72L,0x7B7D4C07L,0xE2DAB8C2L},{4L,0xA591DF25L,0x79955036L,0x79955036L,0xA591DF25L},{0xE2DAB8C2L,6L,3L,0xE2DAB8C2L,6L},{1L,0xA591DF25L,1L,0xA591DF25L,1L},{3L,0xD12EC8B3L,6L,6L,0xD12EC8B3L},{1L,3L,3L,1L,0x79955036L},{0xE2DAB8C2L,0x7B7D4C07L,0x2D3E6A72L,0xD12EC8B3L,0xD12EC8B3L},{4L,1L,4L,0x79955036L,1L},{0xD12EC8B3L,6L,6L,0xD12EC8B3L,6L}}};
                    int i, j, k;
                    if ((*l_6253))
                    { /* block id: 2851 */
                        uint64_t l_6375[6][1][8] = {{{0UL,0UL,18446744073709551615UL,0UL,0UL,18446744073709551615UL,0UL,0UL}},{{1UL,0UL,1UL,1UL,0UL,1UL,1UL,0UL}},{{0UL,1UL,1UL,0UL,1UL,1UL,0UL,1UL}},{{0UL,0UL,18446744073709551615UL,0UL,0UL,18446744073709551615UL,0UL,0UL}},{{1UL,0UL,1UL,1UL,0UL,1UL,1UL,0UL}},{{0UL,1UL,1UL,0UL,1UL,1UL,0UL,1UL}}};
                        int32_t l_6376[10][7] = {{0x1BC5D4BEL,0xC962BDD0L,0x7091F80BL,9L,0xDF83800AL,0x4A4E74DDL,0xFB81A177L},{(-10L),0L,0xE76E0BBFL,(-2L),3L,1L,0x1DF144FEL},{0xE37490EDL,0xF32140F2L,0L,0xDF83800AL,(-10L),0xE76E0BBFL,(-10L)},{0x7091F80BL,0L,0L,0x7091F80BL,0L,9L,0xE76E0BBFL},{(-2L),0x1DF144FEL,0xE76E0BBFL,0L,0x6C011695L,0xDF83800AL,(-3L)},{0L,0x1BC5D4BEL,0x7091F80BL,(-3L),0x77A2556AL,1L,9L},{0x71DDEADEL,0xF0882623L,0xFB81A177L,1L,0xD179BADBL,0x1DF144FEL,0x1DF144FEL},{1L,1L,0x64A796C2L,1L,1L,3L,0L},{(-10L),0xFB81A177L,0x7091F80BL,(-3L),0xE76E0BBFL,0x5A1D26EEL,0x1BC5D4BEL},{0x6C011695L,1L,0L,(-10L),0x4A4E74DDL,0x77A2556AL,0xE76E0BBFL}};
                        int i, j, k;
                        l_6378 = ((((((((((**g_1357) = (*l_6253)) , g_6365) , 0xF6L) | ((0xB27EL != (l_6368 & ((!(l_6370[3][1] >= (*g_62))) != (safe_sub_func_uint8_t_u_u((l_6376[9][0] = (safe_mul_func_uint8_t_u_u(l_6375[5][0][7], l_6368))), 0xE9L))))) , 0x23L)) != 4294967288UL) >= 18446744073709551615UL) ^ l_6375[4][0][7]) <= l_6377) , l_6378);
                    }
                    else
                    { /* block id: 2855 */
                        int32_t l_6388 = 0xC680FF62L;
                        uint32_t l_6389 = 0x15C61D77L;
                        (*g_5559) = l_6378;
                        (***l_6015) = (void*)0;
                        (*l_6378) |= ((safe_add_func_int32_t_s_s(l_6381, (safe_mul_func_int8_t_s_s((((***g_825) , (++l_6389)) == ((((l_6384 , 6UL) || l_6384) & 0UL) & (0xFCC7L > (0x6CCABD86L | (0x97658F82L < l_6388))))), l_6385)))) && (*g_4952));
                    }
                    (*l_6253) = (safe_unary_minus_func_uint8_t_u(0xBBL));
                    (*g_5559) = l_6378;
                }
                return l_6368;
            }
            else
            { /* block id: 2865 */
                const int32_t l_6434 = (-2L);
                uint16_t **** const *l_6437 = &l_6055;
                int32_t l_6448 = 1L;
                const uint8_t l_6449 = 8UL;
                uint32_t ****l_6468[10][4] = {{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]},{&l_6278[4],&l_6278[4],&l_6278[4],&l_6278[4]}};
                int8_t l_6485 = 0xF1L;
                int i, j;
                l_6394 = l_6393[3];
                for (g_4028.f4 = 0; (g_4028.f4 > (-26)); g_4028.f4 = safe_sub_func_int16_t_s_s(g_4028.f4, 8))
                { /* block id: 2869 */
                    (*g_3567) = &l_6381;
                    for (g_5784 = 1; (g_5784 >= 19); g_5784++)
                    { /* block id: 2873 */
                        (*g_5559) = (void*)0;
                    }
                }
                if (l_6399[1][1])
                { /* block id: 2877 */
                    uint16_t l_6417 = 0x9B66L;
                    union U1 l_6429 = {1UL};
                    int32_t l_6435 = 0x58D27523L;
                    for (g_847 = 0; (g_847 <= 3); g_847 += 1)
                    { /* block id: 2880 */
                        uint8_t l_6410 = 0UL;
                        int32_t l_6418[7] = {1L,1L,1L,1L,1L,1L,1L};
                        int i;
                        (*g_5559) = g_6419;
                    }
                    for (l_6016 = 7; (l_6016 > 6); l_6016--)
                    { /* block id: 2887 */
                        int32_t *l_6422[9][1] = {{&l_5840},{&l_5840},{&g_797},{&l_5840},{&l_5840},{&g_797},{&l_5840},{&l_5840},{&g_797}};
                        int i, j;
                        (*g_5834) = l_6422[0][0];
                        (*g_5561) = l_6423;
                        (**g_5834) ^= (((safe_div_func_uint64_t_u_u(((*g_1151) = ((safe_unary_minus_func_int16_t_s(0L)) & ((safe_rshift_func_int16_t_s_u((l_6429 , (**g_968)), (safe_lshift_func_int64_t_s_u(((l_6435 = (safe_lshift_func_uint64_t_u_u(l_6434, 14))) >= (l_6384 = ((*l_6253) | l_6429.f0))), 17)))) , (+((g_6438[0] = l_6437) == (void*)0))))), 0x97A7C3B6988EE261LL)) , 4294967289UL) == l_6368);
                    }
                    if ((((**g_3634) == (void*)0) < ((g_6440 , (*l_6253)) , ((safe_add_func_uint8_t_u_u(g_6443, (safe_add_func_uint16_t_u_u((((((**g_2584) , l_6417) == ((l_6448 = ((((l_6381 &= (safe_rshift_func_uint8_t_u_u((l_6434 < 0x8E6000F2L), 6))) && (*l_6253)) > (-1L)) & (*l_6253))) & l_6368)) ^ l_6449) < 7UL), (**g_3325))))) >= 1UL))))
                    { /* block id: 2898 */
                        int8_t *** const **l_6450 = (void*)0;
                        int8_t *** const l_6453 = (void*)0;
                        int8_t *** const *l_6452 = &l_6453;
                        int8_t *** const **l_6451 = &l_6452;
                        l_6454 = ((*l_6451) = &g_1059);
                        (***l_6015) = l_6455[4][4];
                    }
                    else
                    { /* block id: 2902 */
                        uint32_t *****l_6457 = &l_6456;
                        int32_t l_6470[4][9] = {{0x4234C284L,0x4234C284L,1L,0L,0xC6591B4CL,0L,1L,0x4234C284L,0x4234C284L},{3L,(-5L),0x4234C284L,0L,0x4234C284L,(-5L),3L,3L,(-5L)},{0L,(-5L),1L,(-5L),0L,0x9D931B20L,0x9D931B20L,0L,(-5L)},{3L,0x4234C284L,3L,0x9D931B20L,1L,1L,0x9D931B20L,3L,0x4234C284L}};
                        int32_t l_6471[6][2] = {{0x039C5286L,0x039C5286L},{(-4L),0x039C5286L},{0x039C5286L,(-4L)},{0x039C5286L,0x039C5286L},{(-4L),0x039C5286L},{0x039C5286L,(-4L)}};
                        int i, j;
                        (*g_62) ^= ((((*l_6457) = l_6456) != (((l_6448 == (+(**g_4019))) , l_6472[5]) , &g_4829)) || (*l_6400));
                    }
                }
                else
                { /* block id: 2909 */
                    union U0 * const * const l_6479[8] = {&g_924,&g_924,&g_924,&g_924,&g_924,&g_924,&g_924,&g_924};
                    union U0 * const * const * const l_6478 = &l_6479[6];
                    int32_t l_6491 = 1L;
                    int i;
                    for (l_6019 = 23; (l_6019 >= 37); l_6019 = safe_add_func_uint16_t_u_u(l_6019, 1))
                    { /* block id: 2912 */
                        uint64_t l_6475 = 18446744073709551609UL;
                        union U1 l_6492 = {1UL};
                        union U0 * const ***l_6493 = (void*)0;
                        union U0 * const l_6497 = (void*)0;
                        union U0 * const *l_6496 = &l_6497;
                        union U0 * const **l_6495 = &l_6496;
                        union U0 * const ***l_6494[10] = {&l_6495,&l_6495,&l_6495,&l_6495,&l_6495,&l_6495,&l_6495,&l_6495,&l_6495,&l_6495};
                        int i;
                        (*g_5559) = &l_6384;
                        if (l_6475)
                            continue;
                        if (l_6475)
                            break;
                        (*g_5299) = ((((*l_6253) = (safe_sub_func_uint64_t_u_u((l_6449 == l_6475), 0x2410ABBF8D96679BLL))) , l_6478) == (g_6498 = ((safe_unary_minus_func_int32_t_s((((*l_6400) , ((safe_lshift_func_int16_t_s_u((l_6492 , 0L), 1)) != 65535UL)) <= (-6L)))) , (void*)0)));
                    }
                }
                for (g_2586.f0 = 0; (g_2586.f0 <= 4); g_2586.f0 += 1)
                { /* block id: 2925 */
                    int32_t *l_6504 = (void*)0;
                    int32_t *l_6505 = &l_6384;
                    int32_t *l_6506 = &g_1578;
                    int32_t *l_6507 = &g_614;
                    int32_t *l_6508 = &l_6384;
                    int32_t *l_6509 = &g_1578;
                    int32_t *l_6510 = (void*)0;
                    int32_t *l_6511[5][10];
                    int i, j;
                    for (i = 0; i < 5; i++)
                    {
                        for (j = 0; j < 10; j++)
                            l_6511[i][j] = &l_6107;
                    }
                    for (g_6256 = 1; (g_6256 <= 4); g_6256 += 1)
                    { /* block id: 2928 */
                        int64_t ****l_6503 = &l_6162;
                        int64_t *****l_6502 = &l_6503;
                        if (l_6449)
                            break;
                        (*l_6253) ^= (*l_6400);
                        (*l_6400) = (*l_6400);
                        (*l_6502) = &g_4452;
                    }
                    l_6513++;
                    (*l_6506) &= ((*l_6507) = (safe_mod_func_int16_t_s_s((&g_5715 != (void*)0), (*l_6400))));
                    for (g_4095 = 0; (g_4095 <= 3); g_4095 += 1)
                    { /* block id: 2939 */
                        return (***g_971);
                    }
                }
            }
            (*g_6419) = (*l_6253);
            (*g_6419) |= ((safe_sub_func_uint16_t_u_u((((safe_div_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(((*g_969) , (((*l_6467) = (safe_div_func_int8_t_s_s((safe_div_func_uint16_t_u_u((((!((void*)0 != l_6529)) & (**g_731)) <= ((l_6381 &= ((safe_mul_func_uint8_t_u_u(((*l_6423) , (*l_6253)), ((((safe_div_func_uint8_t_u_u((safe_rshift_func_uint32_t_u_s(((safe_rshift_func_int32_t_s_u(((l_6472[5].f0 <= (safe_add_func_int64_t_s_s(((***g_4452) |= 0x36C0C415124478B5LL), l_6540))) ^ (*l_6400)), (*l_6400))) && (*l_6423)), 3)), l_6384)) | (*l_6400)) > l_6513) || (*g_62)))) ^ l_6368)) & (*l_6423))), (***g_3324))), (*l_6423)))) | (**g_877))), (*l_6400))), 246UL)) , (*g_3326)) || (*l_6400)), 4UL)) != l_6513);
        }
        (*g_6419) ^= (*g_62);
        if (((safe_mul_func_int32_t_s_s((safe_mul_func_int32_t_s_s((safe_lshift_func_int16_t_s_u((-3L), (((safe_rshift_func_int16_t_s_s((safe_lshift_func_uint32_t_u_s((safe_add_func_uint32_t_u_u(((+((*l_6253) | (**g_4019))) != (safe_mod_func_uint32_t_u_u(((safe_mod_func_uint8_t_u_u((safe_add_func_int8_t_s_s((safe_div_func_int8_t_s_s((((((*l_6423) = (*l_6400)) , &g_6439) == ((0xB6L != ((safe_lshift_func_int16_t_s_u((l_6570 = ((safe_rshift_func_int32_t_s_s((((*g_4604) = ((((*l_6253) | ((***g_4950) &= (~(((*l_6400) , l_6567) <= l_6568)))) || (*g_1151)) & (*g_1151))) | l_6569[4]), 0)) , (*g_969))), 4)) != l_6571)) , l_6572)) & l_6573), 7UL)), (*l_6253))), (*l_6400))) == (*l_6400)), l_6021.f0))), l_6574)), 18)), (*l_6400))) != (*g_6419)) ^ (*l_6400)))), (*l_6400))), (*l_6400))) == (*l_6400)))
        { /* block id: 2955 */
            uint32_t *l_6577 = &l_6017;
            uint64_t *l_6588[2][2];
            int32_t l_6591 = 0x990ADF01L;
            int32_t *l_6592[6][7][6] = {{{&l_5840,&g_1256,(void*)0,&l_6107,&g_117,(void*)0},{&l_6267,&g_117,&g_614,&g_614,&g_117,&l_6267},{&g_6361[0][2][2],(void*)0,&l_5840,&l_6016,&g_6361[5][3][1],&l_6107},{&l_6[4][0][0],&g_6361[1][3][3],&g_6361[4][2][4],&g_117,&l_6107,&l_6016},{&l_6[4][0][0],&l_6591,&g_117,&l_6016,&l_5840,&l_6267},{&g_6361[0][2][2],&g_6361[5][3][1],&l_6574,&g_614,&l_6[4][0][0],&g_6361[1][3][3]},{&l_6267,(void*)0,&l_6107,&g_614,&l_6[4][0][0],&l_6591}},{{&g_6361[0][2][2],&l_6574,(void*)0,&l_6[4][0][0],(void*)0,&l_6574},{&l_5840,&g_362,&g_6361[0][2][2],&l_6591,&g_1256,&g_117},{&l_6[4][0][0],&l_6107,&l_6267,&g_117,&g_117,&g_6361[4][2][4]},{&l_5840,&l_6107,&g_614,&l_6591,&g_1256,&l_5840},{(void*)0,&g_362,&g_117,(void*)0,(void*)0,&g_614},{&l_6267,&l_6574,&l_5840,&l_6016,&l_6[4][0][0],(void*)0},{&l_6107,(void*)0,&l_6267,&l_6016,&l_6016,&l_6267}},{{&l_6267,&l_6267,&g_6361[0][2][2],&g_117,&g_6361[0][2][2],&l_6[4][0][0]},{&l_6016,&l_6107,&l_6[4][0][0],(void*)0,&g_614,&g_6361[0][2][2]},{&l_6016,&l_6016,&l_6[4][0][0],&l_6267,&l_6267,&l_6[4][0][0]},{&g_6361[6][0][3],&l_6267,&g_6361[0][2][2],&g_1256,&g_6361[1][3][3],&l_6267},{&g_1256,&g_6361[1][3][3],&l_6267,&g_362,&g_6361[4][2][4],(void*)0},{&g_362,&g_6361[0][2][2],&l_5840,&g_614,&g_117,&g_614},{&g_117,&l_6[4][0][0],&g_117,&g_117,&g_6361[6][0][3],&l_5840}},{{(void*)0,&l_6591,&g_614,&l_5840,&l_5840,&g_6361[4][2][4]},{&l_6107,&g_117,&l_6267,&l_5840,&l_6016,&g_117},{(void*)0,&g_117,&g_6361[0][2][2],&g_117,&l_6267,&l_6574},{&g_117,(void*)0,(void*)0,&g_614,(void*)0,&l_6591},{&g_362,&g_6361[6][0][3],&l_6107,&g_362,&l_6016,&l_6016},{&g_1256,&g_6361[5][3][1],&g_6361[5][3][1],&g_1256,&g_362,&l_5840},{&g_6361[6][0][3],&l_6591,&g_6361[1][3][3],&l_6267,&l_6[4][0][0],(void*)0}},{{&l_6016,&g_1256,(void*)0,(void*)0,&l_6[4][0][0],&l_6107},{&l_6016,&l_6591,(void*)0,&g_117,&g_362,&l_6016},{&l_6267,&g_6361[5][3][1],&g_362,&l_6016,&l_6016,&l_6267},{&l_6107,&g_6361[6][0][3],&g_614,&l_6016,(void*)0,&g_6361[5][3][1]},{&l_6267,(void*)0,&l_6016,(void*)0,&l_6267,&g_1256},{(void*)0,&g_117,&l_6016,&l_6591,&l_6016,&g_614},{&l_5840,&g_117,&l_6591,&g_117,&l_5840,&g_614}},{{&l_6[4][0][0],&l_6591,&l_6016,&l_6591,&g_6361[6][0][3],&g_1256},{&l_5840,&l_6[4][0][0],&l_6016,&l_6[4][0][0],&g_117,&g_6361[5][3][1]},{&g_6361[0][2][2],&g_6361[0][2][2],&g_614,&g_614,&g_6361[4][2][4],&l_6267},{&g_117,&l_6016,&g_1256,&g_1256,&l_6016,&g_117},{&l_6107,&l_5840,&g_6361[6][0][3],&l_6574,&l_6016,&g_614},{&g_117,(void*)0,&l_6016,&l_6016,&l_6[4][0][0],&l_6267},{&g_117,&l_6107,&l_6016,&l_6574,(void*)0,&g_6361[0][2][2]}}};
            int i, j, k;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 2; j++)
                    l_6588[i][j] = &l_6115[1];
            }
            l_6590[4] |= (((*l_6253) = (safe_sub_func_uint8_t_u_u((((void*)0 == l_6577) <= (-8L)), (safe_rshift_func_int8_t_s_s((safe_lshift_func_uint64_t_u_u(((*g_1151) = ((safe_div_func_uint8_t_u_u((~(safe_div_func_uint8_t_u_u(0xBEL, ((*g_4604) = (*l_6253))))), (-3L))) > l_6587)), 12)), (*l_6423)))))) >= (&g_3635[0] != l_6589));
            l_6593++;
        }
        else
        { /* block id: 2961 */
            int16_t l_6597 = (-3L);
            int32_t l_6608[2];
            const int16_t *l_6621[3];
            int i;
            for (i = 0; i < 2; i++)
                l_6608[i] = (-7L);
            for (i = 0; i < 3; i++)
                l_6621[i] = &l_6590[0];
            (*l_6253) ^= ((((((((((*l_6400) &= ((****g_2582) , 1UL)) || ((l_6020 = (***g_3180)) , 0x84D491225046B819LL)) , l_6597) != l_6597) <= 0x5614L) <= 0x22D3L) == (*l_6423)) ^ 0UL) & (*l_6423));
            (*g_6419) ^= (l_6608[1] = (((safe_mod_func_uint32_t_u_u(((*l_6423) = (*l_6400)), 0x3882D90EL)) || ((**g_4453) < (((0UL || (*l_6400)) || (~(((((*l_6529) = (~(safe_mul_func_uint32_t_u_u((((l_6604[4] , (((*l_6467) = (l_6597 < 0xD56AEAFA0CCE0389LL)) > (((((safe_add_func_int32_t_s_s(((l_6597 != (-6L)) >= (*l_6400)), l_6607)) >= (*l_6253)) , 0x4A60L) != (*g_3326)) && (*l_6400)))) , &l_6467) != (*g_4452)), (*l_6423))))) , (*l_6400)) <= l_6597) | 0x52L))) , (**g_4453)))) ^ (*g_5299)));
            for (g_2882 = (-9); (g_2882 >= (-10)); g_2882 = safe_sub_func_uint64_t_u_u(g_2882, 1))
            { /* block id: 2973 */
                int16_t **l_6614 = &g_969;
                int16_t *** const l_6613 = &l_6614;
                int16_t *** const *l_6612 = &l_6613;
                int16_t *** const **l_6611[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_6611[i] = &l_6612;
                g_6620 = (g_6617 = (g_6615 = &g_1424));
            }
            (*l_6400) ^= ((7L ^ ((l_6621[2] != (void*)0) == ((*l_6253) = 1UL))) , ((void*)0 == l_6622));
        }
    }
    else
    { /* block id: 2981 */
        int32_t * const l_6623 = &l_5840;
        int32_t l_6751 = 0L;
        int32_t l_6753 = 1L;
        int32_t l_6754 = 0x14019BB5L;
        int32_t l_6760 = (-6L);
        union U0 *****l_6766 = &l_6015;
        union U1 l_6786[5] = {{0x53L},{0x53L},{0x53L},{0x53L},{0x53L}};
        int8_t l_6804 = 0xD6L;
        uint64_t **l_6835[7] = {&g_1151,&g_1151,&g_1151,&g_1151,&g_1151,&g_1151,&g_1151};
        int16_t l_6848 = (-10L);
        uint32_t l_6861 = 0x865D4863L;
        uint8_t l_6862 = 0x0EL;
        int16_t l_7045 = 0x4AE4L;
        uint32_t l_7058 = 0UL;
        uint16_t l_7063 = 5UL;
        uint64_t *** const l_7077 = &g_1150[1];
        uint64_t *** const *l_7076 = &l_7077;
        int8_t l_7149[8][3] = {{(-7L),(-7L),0xF4L},{0x87L,(-6L),0xF4L},{(-6L),0x87L,0xF4L},{(-7L),(-7L),0xF4L},{0x87L,(-6L),0xF4L},{(-6L),0x87L,0xF4L},{(-7L),(-7L),0xF4L},{0x87L,(-6L),0xF4L}};
        int64_t *l_7150 = &l_7057;
        int32_t *l_7160 = &g_6361[0][2][2];
        int8_t **l_7228 = (void*)0;
        uint32_t l_7243 = 18446744073709551615UL;
        uint64_t l_7253 = 0x621EC0BD15490D74LL;
        int64_t ****l_7256 = &g_4452;
        const int32_t l_7309[10] = {1L,1L,0xA1C734B7L,1L,1L,0xA1C734B7L,1L,1L,0xA1C734B7L,1L};
        uint8_t l_7337 = 0x3EL;
        uint64_t l_7364 = 18446744073709551615UL;
        int i, j;
lbl_6709:
        (*g_6626) = l_6623;
lbl_7167:
        if ((*l_6623))
        { /* block id: 2983 */
            union U0 *l_6630[9];
            int32_t l_6650 = 9L;
            int32_t l_6663 = (-1L);
            const int8_t **l_6670 = (void*)0;
            const int8_t ***l_6669[1];
            int16_t ****l_6710 = &l_5832;
            int64_t l_6740 = 2L;
            int32_t l_6741[9] = {0x6E137B32L,0x5331A52CL,0x5331A52CL,0x6E137B32L,0x5331A52CL,0x5331A52CL,0x6E137B32L,0x5331A52CL,0x5331A52CL};
            int32_t l_6761 = 0x131E1B96L;
            int i;
            for (i = 0; i < 9; i++)
                l_6630[i] = &g_5867[9][3][1];
            for (i = 0; i < 1; i++)
                l_6669[i] = &l_6670;
lbl_6681:
            for (g_4121 = 0; (g_4121 == 22); g_4121 = safe_add_func_int8_t_s_s(g_4121, 3))
            { /* block id: 2986 */
                int16_t l_6629 = 4L;
                union U0 *l_6631[8];
                int i;
                for (i = 0; i < 8; i++)
                    l_6631[i] = &g_4843[1];
                if (l_6629)
                    break;
                l_6631[2] = l_6630[2];
            }
            for (l_6568 = 0; (l_6568 >= 57); l_6568 = safe_add_func_int64_t_s_s(l_6568, 6))
            { /* block id: 2992 */
                const int8_t ****l_6671 = &l_6669[0];
                const int32_t l_6672 = 0x662A3864L;
                uint16_t l_6686 = 0x04F0L;
                union U1 ****l_6689 = &g_3010;
                int32_t l_6708 = 0x3882866AL;
                int16_t *****l_6713 = (void*)0;
                (*g_62) = (safe_add_func_uint8_t_u_u(((*l_6623) = (((safe_mod_func_int16_t_s_s((*l_6623), (**g_6619))) != (safe_mul_func_int64_t_s_s((safe_div_func_int8_t_s_s(((((((*l_6623) != (((**g_4019)--) && (safe_mul_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(((safe_add_func_int16_t_s_s(l_6650, (safe_lshift_func_int16_t_s_u(((safe_rshift_func_int64_t_s_s((((safe_lshift_func_int8_t_s_s(l_6650, 1)) , ((**g_4951) = (safe_lshift_func_uint32_t_u_u((safe_mod_func_uint32_t_u_u(l_6663, l_6663)), 10)))) ^ (((safe_lshift_func_uint32_t_u_s(0UL, 10)) ^ ((safe_sub_func_int32_t_s_s(((safe_unary_minus_func_uint64_t_u(((((*l_6671) = l_6669[0]) != (void*)0) ^ 0x90L))) && l_6672), l_6672)) && (*l_6623))) > l_6672)), 9)) && (*g_3522)), 2)))) & 0xF4CA0DA8416F6D83LL), (***g_4452))), (*l_6423))))) > (*l_6423)) | 0x04L) <= l_6650) <= 0x2525L), l_6673)), l_6650))) , 0x61L)), 0x43L));
                for (g_2962 = 0; (g_2962 != 16); g_2962++)
                { /* block id: 3000 */
                    int64_t l_6678 = 6L;
                    union U1 ****l_6691 = &g_3010;
                    for (g_117 = 13; (g_117 <= (-2)); g_117 = safe_sub_func_uint16_t_u_u(g_117, 2))
                    { /* block id: 3003 */
                        if (l_6663)
                            break;
                        return l_6678;
                    }
                    if ((safe_div_func_int8_t_s_s(6L, (*g_732))))
                    { /* block id: 3007 */
                        l_6650 &= ((*l_6623) = ((*g_62) = (l_6678 , l_6678)));
                        if (g_3212)
                            goto lbl_6681;
                        (*l_6423) &= (safe_lshift_func_uint64_t_u_s((****g_875), 53));
                    }
                    else
                    { /* block id: 3013 */
                        int64_t l_6684 = 0xAB8B3A454B338E72LL;
                        if (l_6650)
                            break;
                        (*g_6419) ^= (l_6684 == ((*l_6623) , (*l_6623)));
                    }
                    (*g_6419) = (g_6685 , l_6686);
                    for (g_527 = 0; (g_527 <= 32); g_527 = safe_add_func_int8_t_s_s(g_527, 8))
                    { /* block id: 3020 */
                        union U1 ****l_6690 = &g_3010;
                        int32_t l_6706 = 1L;
                        int16_t ****l_6707 = &l_5832;
                        (*g_62) = (((*g_253) , 1UL) | 0x1E494B9AL);
                    }
                }
                for (g_1788.f4 = 2; (g_1788.f4 >= 0); g_1788.f4 -= 1)
                { /* block id: 3030 */
                    (*l_6423) ^= ((*l_6623) |= l_6708);
                    if (l_6663)
                        continue;
                    if (g_5190)
                        goto lbl_6709;
                }
                l_6710 = l_6710;
            }
            if (g_613)
                goto lbl_6709;
            for (g_4121 = 28; (g_4121 == (-2)); g_4121 = safe_sub_func_int32_t_s_s(g_4121, 1))
            { /* block id: 3041 */
                uint8_t l_6716 = 0UL;
                int32_t l_6717 = 0x8595B3CAL;
                uint16_t l_6727 = 0x2B3EL;
                int32_t l_6752 = 0xC4239AF1L;
                int32_t l_6755 = 0x01DE433FL;
                int32_t l_6757 = 0xEB351869L;
                int32_t l_6758 = 0x02C27F90L;
                int32_t l_6759[2][7] = {{0xA7AFB4A0L,6L,0xA7AFB4A0L,6L,0xA7AFB4A0L,6L,0xA7AFB4A0L},{0x6877732CL,0x6877732CL,0x6877732CL,0x6877732CL,0x6877732CL,0x6877732CL,0x6877732CL}};
                const uint64_t l_6777[8][8] = {{0xF52E378BD0BA2FD6LL,8UL,0x881996B4356A6A12LL,8UL,0xF52E378BD0BA2FD6LL,0xF52E378BD0BA2FD6LL,8UL,0x881996B4356A6A12LL},{0xF52E378BD0BA2FD6LL,0xF52E378BD0BA2FD6LL,8UL,0x881996B4356A6A12LL,8UL,0xF52E378BD0BA2FD6LL,0xF52E378BD0BA2FD6LL,8UL},{5UL,8UL,8UL,5UL,18446744073709551615UL,5UL,8UL,8UL},{8UL,18446744073709551615UL,0x881996B4356A6A12LL,0x881996B4356A6A12LL,18446744073709551615UL,8UL,18446744073709551615UL,0x881996B4356A6A12LL},{5UL,18446744073709551615UL,5UL,8UL,8UL,5UL,18446744073709551615UL,5UL},{0xF52E378BD0BA2FD6LL,8UL,0x881996B4356A6A12LL,8UL,0xF52E378BD0BA2FD6LL,0xF52E378BD0BA2FD6LL,8UL,0x881996B4356A6A12LL},{0xF52E378BD0BA2FD6LL,0xF52E378BD0BA2FD6LL,8UL,0x881996B4356A6A12LL,8UL,0xF52E378BD0BA2FD6LL,0xF52E378BD0BA2FD6LL,8UL},{5UL,8UL,8UL,5UL,18446744073709551615UL,5UL,8UL,8UL}};
                int32_t l_6789 = 0xF630CE76L;
                int16_t l_6807 = 0x876AL;
                int32_t *l_6808 = &l_6650;
                uint64_t l_6824 = 0x2F63069BE5411AA8LL;
                int i, j;
                l_6717 ^= l_6716;
                for (l_6022 = 0; (l_6022 == (-28)); l_6022 = safe_sub_func_int32_t_s_s(l_6022, 4))
                { /* block id: 3045 */
                    int16_t l_6720 = 0xCD22L;
                    (*l_6623) = l_6720;
                }
            }
        }
        else
        { /* block id: 3086 */
            int8_t l_6832 = 0x3AL;
            int32_t l_6849 = 0L;
            int32_t l_6850 = 0x1915E308L;
            int32_t l_6852 = 0xEBAA2DF5L;
            int32_t l_6853 = 0xEC334572L;
            int32_t l_6863 = 2L;
            union U1 l_6866 = {255UL};
            union U0 **l_6867 = (void*)0;
            union U0 *l_6884 = (void*)0;
            uint32_t ***l_6998 = &l_5880[0];
            int64_t l_7014 = (-10L);
            uint32_t l_7026[5][2] = {{0x6959912AL,0x6959912AL},{0x6959912AL,0x6959912AL},{0x6959912AL,0x6959912AL},{0x6959912AL,0x6959912AL},{0x6959912AL,0x6959912AL}};
            int32_t l_7084[7][2] = {{0xDB673B34L,4L},{0xDB673B34L,4L},{0xDB673B34L,4L},{0xDB673B34L,4L},{0xDB673B34L,4L},{0xDB673B34L,4L},{0xDB673B34L,4L}};
            uint32_t l_7095 = 0UL;
            int i, j;
            if (((*g_6419) = (safe_lshift_func_uint8_t_u_u((((safe_mod_func_uint32_t_u_u((((*g_1151) = ((safe_sub_func_uint16_t_u_u((**g_3521), (l_6832 < (((safe_div_func_uint32_t_u_u((l_6835[2] != (void*)0), (*l_6423))) | ((**g_4453) = ((*l_6423) | ((((((safe_rshift_func_uint8_t_u_s((safe_div_func_int32_t_s_s((((*g_484) = ((safe_add_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_s((0x760FC5C2L <= (((safe_lshift_func_int8_t_s_s((l_6848 | (++l_6854)), 6)) | ((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint32_t_u_s((((**g_6316) , (void*)0) != &l_6760), 6)), l_6861)) == 0xCFB42DE3L)) & l_6852)), 5)), l_6852)) ^ l_6862)) , l_6852), l_6863)), (*l_6623))) >= 0x845F054FL) , (void*)0) != (void*)0) ^ g_6864) | (***g_876))))) | (*l_6623))))) == l_6850)) == (-6L)), (*l_6623))) , 0x1CL) == 0x13L), 7))))
            { /* block id: 3092 */
                union U1 l_6865 = {0xEAL};
                int16_t l_6868 = 0x6EDAL;
                int32_t *l_6891 = &l_6753;
                int16_t **** const *l_6917 = (void*)0;
                uint32_t l_6925 = 0x414B7E93L;
                uint32_t l_6928 = 4294967294UL;
                int32_t l_6937 = (-9L);
                int16_t l_6938 = 0x7AF9L;
                int32_t ****l_6971 = (void*)0;
                const int32_t l_7015 = 0xAFDF0422L;
                int32_t l_7021 = 1L;
                int32_t l_7022 = 1L;
                int32_t l_7023 = 0xB146604AL;
                int32_t l_7024 = (-7L);
                int32_t l_7025 = 0L;
                if ((l_6866 , ((**g_4019) >= (((*g_3707) = l_6867) != (void*)0))))
                { /* block id: 3094 */
                    int64_t l_6869 = (-1L);
                    if (l_6848)
                        goto lbl_6709;
                    l_6869 ^= l_6868;
                }
                else
                { /* block id: 3097 */
                    int32_t l_6886 = (-2L);
                    uint64_t l_6889 = 1UL;
                    (*g_62) &= ((safe_add_func_int32_t_s_s(((void*)0 != (**g_4451)), ((safe_lshift_func_int32_t_s_s(((((((((**g_1357) , l_6874) , ((*l_6623) == ((safe_div_func_uint8_t_u_u(l_6868, ((*l_6423) || 8L))) != (!((safe_sub_func_int64_t_s_s(((*g_1358) = (safe_mod_func_int8_t_s_s((((void*)0 != l_6884) & g_6885), (*l_6623)))), (-8L))) == l_6886))))) ^ l_6850) <= 0xA1L) > l_6886) < (*l_6623)) , 0xB12FA99DL), 6)) && l_6886))) && l_6886);
                    l_6889 ^= (safe_add_func_int32_t_s_s((*g_6419), (*l_6423)));
                    for (g_5071.f4 = 0; (g_5071.f4 <= 1); g_5071.f4 += 1)
                    { /* block id: 3103 */
                        int32_t *l_6890 = &g_6361[7][3][3];
                        (*g_5834) = &l_6849;
                        (*g_5834) = ((*g_5559) = l_6890);
                        l_6886 ^= 1L;
                        (*g_6419) = 0L;
                    }
                    (*g_5561) = l_6891;
                }
                if ((g_6892 , ((*g_1358) && (**g_877))))
                { /* block id: 3112 */
                    int32_t l_6893 = (-1L);
                    int32_t *l_6894 = &g_6361[6][2][4];
                    int32_t *l_6895 = &l_6751;
                    int32_t *l_6896[9] = {&g_1578,&l_6[1][4][2],&l_6[1][4][2],&g_1578,&l_6[1][4][2],&l_6[1][4][2],&g_1578,&l_6[1][4][2],&l_6[1][4][2]};
                    union U1 l_6908[10][1] = {{{248UL}},{{1UL}},{{248UL}},{{1UL}},{{248UL}},{{1UL}},{{248UL}},{{1UL}},{{248UL}},{{1UL}}};
                    uint32_t l_6939 = 18446744073709551615UL;
                    int32_t ****l_6968[1];
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_6968[i] = &g_3833;
                    g_6897++;
                    if ((safe_sub_func_int16_t_s_s((((((****g_6617) = ((((safe_rshift_func_int64_t_s_s(((((*l_6891) > (((((safe_rshift_func_int16_t_s_u(((safe_rshift_func_int8_t_s_u((((l_6908[0][0] , l_6832) , (safe_sub_func_uint64_t_u_u((safe_unary_minus_func_uint8_t_u((*l_6623))), (--(*g_1151))))) > 0x6EBA2134L), ((((((((****g_4451) &= 0xAF67A6C79135E92ALL) < (&l_6186 != (l_6917 = (l_6914 = &g_6712)))) < (safe_rshift_func_uint8_t_u_s((safe_div_func_int16_t_s_s(0xF80BL, (***g_3324))), (*l_6891)))) & 0xA23B2AD6262BB9ADLL) || (***g_4452)) , (-9L)) & 0x60L))) & l_6922), (*l_6891))) & l_6863) && l_6849) & g_6923) && (*g_878))) && 0xE3505F3852FF1F9DLL) || 0x6C3613B7L), 42)) || l_6924) && 18446744073709551615UL) <= l_6852)) & 0x3DF0L) <= (*l_6623)) , 0x7AF7L), l_6925)))
                    { /* block id: 3119 */
                        uint64_t l_6942 = 18446744073709551613UL;
                        int8_t l_6948 = 0xF3L;
                        const int8_t l_6950 = 0x1AL;
                        (*g_62) |= (safe_add_func_int32_t_s_s(((l_6928 || ((**g_4019) && (safe_div_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((safe_div_func_int16_t_s_s(((**g_968) &= (((-7L) ^ ((*l_6891) != (safe_div_func_int8_t_s_s((*l_6623), (*l_6891))))) | (0x47L && (*l_6891)))), 8UL)) || (***g_6618)), (*l_6423))), (*l_6623))))) == (*l_6623)), 0x05539D5BL));
                        ++l_6939;
                        (*g_62) = (l_6942 | (*l_6891));
                        (*g_62) = (((((safe_add_func_uint32_t_u_u((+(*l_6423)), (safe_lshift_func_uint64_t_u_u(0x557159C7574EA98CLL, l_6948)))) && (*g_827)) || ((*l_6895) = (*l_6891))) | (((*l_6894) = ((safe_unary_minus_func_int8_t_s((l_6950 > ((1UL && (l_6865 , (((safe_mod_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(((safe_sub_func_int64_t_s_s(((g_6957 , l_6853) <= (*g_1151)), 0x4C91E03B00BEA9BBLL)) , (*l_6894)), (*l_6623))), 0x43E1L)) , (***g_3324)) || (*g_3326)))) ^ 0x9E97L)))) >= (***g_4452))) == l_6950)) < (*g_3326));
                    }
                    else
                    { /* block id: 3127 */
                        (*g_6419) = (*l_6423);
                        (*g_62) = ((safe_add_func_uint32_t_u_u((1UL & ((*g_1151) &= (*l_6891))), ((*l_6894) |= l_6852))) || 0x2AB72F02FFE034FBLL);
                    }
                    for (l_6939 = 0; (l_6939 > 34); l_6939 = safe_add_func_uint8_t_u_u(l_6939, 7))
                    { /* block id: 3135 */
                        uint32_t **l_6964 = &g_1998;
                        int32_t *****l_6969 = &g_3832;
                        int32_t *****l_6970 = &l_6225;
                        int32_t *****l_6972 = &g_3832;
                        int32_t *****l_6973 = &l_6971;
                        uint16_t l_6974 = 0UL;
                        (*l_6891) &= ((((safe_mul_func_int64_t_s_s((l_6964 != (void*)0), 18446744073709551610UL)) != (0xBD7499049CAA41AALL | ((void*)0 == (*g_5139)))) & ((+(((safe_lshift_func_uint32_t_u_s(((*g_3326) == ((((*l_6970) = l_6968[0]) == ((*l_6973) = l_6971)) , (***g_3324))), 10)) >= 1L) == l_6974)) | l_6974)) != (*l_6623));
                        (*l_6894) = (safe_div_func_uint16_t_u_u(((0x369C8CF9179F1E3DLL < 18446744073709551613UL) == (0xBB7C23DFL >= (&g_3179[8] == (void*)0))), (***g_971)));
                    }
                    (*l_6891) = (*l_6623);
                }
                else
                { /* block id: 3142 */
                    uint32_t l_6981 = 0x95176A3AL;
                    union U1 ***l_6995 = (void*)0;
                    int64_t l_7000 = 0x264D0DC1B115D806LL;
                    int32_t *l_7017 = &l_6512;
                    int32_t *l_7018 = &l_6850;
                    int32_t *l_7019[9];
                    int16_t l_7020 = 0x8DA4L;
                    uint64_t l_7042 = 5UL;
                    int i;
                    for (i = 0; i < 9; i++)
                        l_7019[i] = &g_6361[8][3][1];
                    for (g_4207.f4 = 8; (g_4207.f4 >= 0); g_4207.f4 -= 1)
                    { /* block id: 3145 */
                        union U1 ***l_6996 = (void*)0;
                        int32_t l_7013 = (-1L);
                        int i;
                        (*g_6419) = ((safe_mod_func_int64_t_s_s((((l_6786[4] , (l_6981 , (1UL >= 0x6E79L))) & (((*g_4604) &= ((((safe_sub_func_uint8_t_u_u(((**g_4019) = ((l_6981 , ((++(**g_6316)) , (***g_971))) == ((safe_lshift_func_int64_t_s_u((safe_add_func_uint16_t_u_u((l_6997[2] ^= (~(safe_lshift_func_int16_t_s_u((!((~(((*g_4325) = l_6995) == ((***g_6618) , l_6996))) >= 1L)), l_6850)))), l_6852)), l_6981)) ^ (*g_3326)))), (**g_4951))) , l_6998) == (void*)0) <= 0x472D96CCF5C8286BLL)) != g_6999)) <= l_7000), 0x963C327B0E3E12D5LL)) == (***g_4452));
                        (*l_6423) = ((*g_62) = (((*l_6623) = ((((*l_6891) ^= (***g_971)) <= 7UL) ^ ((((void*)0 != (*g_2486)) == (!(safe_lshift_func_int32_t_s_u(((safe_lshift_func_int64_t_s_s((*g_1358), ((*l_6423) < (safe_mul_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u((safe_unary_minus_func_int32_t_s(((***g_4452) , ((l_6863 | ((*l_6623) >= l_7013)) ^ l_7014)))), l_7015)), l_7016))))) , (-2L)), l_7013)))) != l_6866.f0))) && 0UL));
                    }
                    --l_7026[1][1];
                    for (g_5223 = (-12); (g_5223 != 22); g_5223++)
                    { /* block id: 3160 */
                        const uint64_t l_7041 = 1UL;
                        (*l_7017) &= ((safe_sub_func_uint32_t_u_u(((l_7045 = (((safe_lshift_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_u(((**g_4019) ^= (safe_add_func_uint64_t_u_u(((0x22L ^ (l_7041 & l_7014)) != ((void*)0 == &l_5830)), (***g_4452)))), 3)), ((*l_6623) |= l_7042))) == ((*l_7018) ^ ((***g_4950) |= (((*g_969) = (safe_mul_func_int8_t_s_s((((*l_6891) != 0L) ^ 0xA7L), l_7041))) , (*l_6891))))) && 0xBC7DL)) >= 0L), (*l_6891))) ^ 0x4D4CL);
                        if ((*l_7018))
                            continue;
                    }
                }
                for (l_6019 = 0; (l_6019 != 56); l_6019++)
                { /* block id: 3172 */
                    int32_t l_7056 = (-6L);
                    uint64_t l_7061 = 0xD07EFA30DC9C6B8BLL;
                    int32_t l_7062 = 0x24F6DBB4L;
                    for (g_746 = 8; (g_746 >= 0); g_746 -= 1)
                    { /* block id: 3175 */
                        int32_t *l_7048 = &l_6754;
                        int32_t *l_7049 = &l_6016;
                        int32_t *l_7050 = &g_117;
                        int32_t *l_7051 = &g_4555;
                        int32_t *l_7052 = &l_6853;
                        int32_t *l_7053 = (void*)0;
                        int32_t *l_7054 = &l_7023;
                        int32_t *l_7055[10] = {&g_6361[0][0][3],(void*)0,&g_6361[0][0][3],(void*)0,(void*)0,&g_6361[0][0][3],(void*)0,&g_6361[0][0][3],(void*)0,(void*)0};
                        int i;
                        --l_7058;
                        (*g_5561) = &l_7024;
                    }
                    (*g_62) ^= (0L && (((l_7062 = ((*l_6623) = l_7061)) ^ l_7063) || l_6849));
                    return (****g_6617);
                }
            }
            else
            { /* block id: 3184 */
                uint32_t l_7066 = 0x82B56A3FL;
                int64_t l_7086 = 0x72607A46C010700FLL;
                l_6850 = (*l_6423);
                for (g_77 = 0; (g_77 < 7); g_77 = safe_add_func_int32_t_s_s(g_77, 6))
                { /* block id: 3188 */
                    uint32_t l_7069 = 18446744073709551606UL;
                    int32_t l_7087 = 0xEA59CFC9L;
                    (*g_62) = l_7066;
                    l_7087 = (safe_mod_func_uint16_t_u_u((((**g_4019) = l_7069) <= ((((void*)0 != &l_6863) , ((((safe_rshift_func_uint64_t_u_s(0x72ED07A093D23DAALL, (((safe_lshift_func_uint8_t_u_s((*l_6623), 2)) & (safe_mod_func_int16_t_s_s(((void*)0 == l_7076), (((l_6852 ^= ((((****l_7076) ^= 0x52FB5A596C84EBD3LL) || (safe_lshift_func_uint32_t_u_u((safe_div_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u((((*l_6423) = (*l_6623)) <= l_7084[3][0]), 13)), g_7085)), (*l_6623)))) ^ l_6850)) ^ l_7086) | 9L)))) <= (*l_6623)))) > (-3L)) , l_7086) ^ l_7069)) >= l_7084[2][0])), (****g_3323)));
                }
            }
            (*g_6419) = ((safe_sub_func_uint16_t_u_u((+(safe_rshift_func_uint16_t_u_s(65535UL, 7))), ((***g_6618) = (***g_971)))) >= (*l_6623));
            for (l_6248 = 21; (l_6248 > 9); l_6248 = safe_sub_func_uint16_t_u_u(l_6248, 3))
            { /* block id: 3201 */
                uint64_t l_7100 = 18446744073709551611UL;
                --l_7095;
                (*l_6623) = (safe_div_func_uint64_t_u_u((l_6852 &= l_7100), (safe_add_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(0x31B31FCEL, (&l_6123[2][5][3] == (*g_5824)))), ((safe_add_func_uint8_t_u_u(l_7026[1][1], (l_7100 , ((safe_unary_minus_func_int32_t_s((!((safe_mul_func_int32_t_s_s((((safe_lshift_func_int32_t_s_u(((safe_mod_func_uint64_t_u_u((((safe_add_func_int8_t_s_s(((***g_4950) &= (safe_mod_func_uint8_t_u_u((g_7119 & (l_7120++)), (((*g_1151) = l_7123[3][4][6]) , (((**l_7077) == (void*)0) && (*l_6623)))))), l_7100)) && (*l_6423)) != (*l_6423)), l_6832)) , 0x561C66C7L), l_7124[6][0][2])) <= (*l_6623)) , (*g_6419)), 4294967295UL)) != l_7084[3][0])))) || l_7014)))) != 0x55L)))));
                (*g_6419) = (**g_2958);
            }
        }
        (*g_5834) = (void*)0;
        for (g_55.f0 = 18; (g_55.f0 != 43); g_55.f0 = safe_add_func_uint16_t_u_u(g_55.f0, 1))
        { /* block id: 3214 */
            uint16_t *l_7145 = (void*)0;
            int32_t l_7147[1][5][5] = {{{0x953AF312L,0x953AF312L,(-1L),0x953AF312L,0x953AF312L},{(-10L),0x953AF312L,(-10L),(-10L),0x953AF312L},{0x953AF312L,(-10L),(-10L),0x953AF312L,(-10L)},{0x953AF312L,0x953AF312L,(-1L),0x953AF312L,0x953AF312L},{(-10L),0x953AF312L,(-10L),(-10L),0x953AF312L}}};
            uint32_t *l_7166 = &g_1496;
            const union U1 l_7168 = {255UL};
            int32_t * const l_7182 = &g_614;
            uint16_t l_7214[10][8] = {{65535UL,0x58E6L,65535UL,0xF79CL,0x62A4L,65535UL,0xEDC0L,65535UL},{0xFB2EL,0xF79CL,65529UL,0xF79CL,0xFB2EL,0UL,0xF79CL,65529UL},{0xCCB5L,0xFB2EL,0x62A4L,7UL,0xF79CL,0xCCB5L,0xCCB5L,0xF79CL},{65535UL,0x62A4L,0x62A4L,65535UL,0x58E6L,65535UL,0xF79CL,0x62A4L},{0xF79CL,0xEDC0L,65529UL,65529UL,0xEDC0L,0x8C7CL,0xEDC0L,65529UL},{65535UL,0xEDC0L,65535UL,0x62A4L,0xF79CL,65535UL,0x58E6L,65535UL},{0xFB2EL,0x62A4L,7UL,0xF79CL,0xCCB5L,0xCCB5L,0xF79CL,7UL},{0xFB2EL,0xFB2EL,0x8C7CL,65529UL,0xF79CL,0UL,0xFB2EL,0xF79CL},{65535UL,0xF79CL,0x62A4L,65535UL,0xEDC0L,65535UL,0x62A4L,0xF79CL},{0xF79CL,0x58E6L,7UL,65529UL,0x58E6L,0x62A4L,0xEDC0L,7UL}};
            int32_t l_7286 = 2L;
            int8_t l_7287[1];
            const uint8_t l_7290 = 255UL;
            uint32_t l_7298 = 6UL;
            uint32_t ****l_7318 = &l_6278[4];
            uint32_t ***** const l_7317 = &l_7318;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_7287[i] = 0xDAL;
            for (g_5071.f4 = (-15); (g_5071.f4 < (-8)); g_5071.f4 = safe_add_func_uint16_t_u_u(g_5071.f4, 6))
            { /* block id: 3217 */
                uint32_t l_7148 = 0x7B531321L;
                int32_t l_7154 = 1L;
                if ((safe_div_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((safe_mod_func_uint32_t_u_u((safe_add_func_int8_t_s_s(((((safe_lshift_func_int8_t_s_u(((safe_mul_func_int16_t_s_s((*l_6423), (safe_mul_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s((l_7146 = ((l_7145 = &l_7063) != &l_7063)), 3)), ((((*g_1151) &= 0x9D871380876934D0LL) != (((**g_1357) = 2L) != 0xFF21260DAC13ECC0LL)) == l_7147[0][0][1]))))) >= 0x88L), l_7147[0][2][0])) , 9UL) , l_7147[0][4][3]) , l_7148), l_7149[7][0])), 0xCC4C8BBCL)), l_7148)), l_7148)))
                { /* block id: 3222 */
                    int64_t l_7155[1][10] = {{0x3AEBE81074C56C39LL,0x3AEBE81074C56C39LL,0xC45AA4533AE2E07ELL,0x3AEBE81074C56C39LL,0x3AEBE81074C56C39LL,0xC45AA4533AE2E07ELL,0x3AEBE81074C56C39LL,0x3AEBE81074C56C39LL,0xC45AA4533AE2E07ELL,0x3AEBE81074C56C39LL}};
                    int32_t * const l_7156[1][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                    uint16_t l_7161 = 65535UL;
                    uint16_t l_7178[9][6] = {{0UL,0x70C0L,0x7CF5L,0x7D1DL,65535UL,3UL},{3UL,65535UL,0x6388L,3UL,65535UL,5UL},{0xF641L,0x70C0L,0UL,0x70C0L,0xF641L,3UL},{0x6388L,0UL,65535UL,65533UL,0UL,3UL},{65535UL,0x08B6L,0xF641L,0UL,1UL,3UL},{3UL,5UL,65535UL,65535UL,5UL,3UL},{1UL,0x7D1DL,0UL,65535UL,0x6388L,5UL},{0x7D1DL,0xF641L,0x6388L,0x7CF5L,65535UL,3UL},{0x7D1DL,65533UL,0x7CF5L,65535UL,0xF641L,0x7CF5L}};
                    int i, j;
                    if (((void*)0 != l_7150))
                    { /* block id: 3223 */
                        return (**g_6619);
                    }
                    else
                    { /* block id: 3225 */
                        uint64_t l_7157 = 0x5BA079E25A3B67BFLL;
                        int32_t * const l_7158 = &l_6[4][0][0];
                        int32_t * const l_7159 = &g_6361[0][2][2];
                        l_7147[0][0][1] = ((((safe_rshift_func_int64_t_s_s((l_7148 >= (*g_732)), ((((void*)0 == &g_4775[0][1][3]) ^ (!((l_7154 = ((l_7148 , l_7147[0][0][1]) < 0x462FL)) != (*l_6623)))) > ((65535UL || l_7155[0][9]) && (*l_6423))))) > (*l_6623)) <= l_7147[0][0][4]) > 18446744073709551613UL);
                        (*g_5834) = l_7160;
                    }
                    if ((*l_6623))
                    { /* block id: 3231 */
                        (*l_7160) = (l_7147[0][4][4] != (-3L));
                        (**g_5834) = l_7161;
                        return (*l_7160);
                    }
                    else
                    { /* block id: 3235 */
                        uint32_t l_7165 = 0UL;
                        (**g_5834) |= (g_7162 , (((safe_mul_func_uint64_t_u_u(l_7165, (***g_4452))) , l_7166) == ((*g_827) , (*g_6316))));
                        if (g_254.f0)
                            goto lbl_7167;
                        if (l_7154)
                            break;
                    }
                    if (l_7147[0][0][1])
                    { /* block id: 3240 */
                        uint32_t l_7180 = 0x7625645CL;
                        int32_t l_7187 = 0x0FB4A794L;
                        const uint32_t ***l_7211[10][4][3] = {{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}},{{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{&g_7209[0][4][0],&g_7209[4][1][3],&g_7209[0][4][1]},{&g_7209[2][3][3],&g_7209[2][3][3],&g_7209[2][3][3]},{(void*)0,&g_7209[4][1][3],&g_7209[2][3][3]}}};
                        uint16_t l_7213 = 0xC73DL;
                        int i, j, k;
                        (*l_6623) = (-2L);
                        g_7181[3][2] = (0x62L >= (l_7168 , (safe_add_func_uint64_t_u_u(0xFCF0DD83AAD2DEE9LL, (((safe_div_func_uint16_t_u_u((((!(-1L)) >= ((**g_1357) = (*g_1358))) < (((safe_rshift_func_uint32_t_u_u((0x14L || (safe_lshift_func_uint16_t_u_u((((((l_7178[8][2] & (((*l_7160) = ((g_7179 , l_7180) != (*g_4952))) , 0xF0L)) == (****g_3323)) >= g_80) <= l_7180) != (*l_6423)), 14))), (*l_6623))) , 1UL) , (*l_7160))), (*l_6623))) >= (-5L)) , (***g_4452))))));
                        (*g_5561) = &l_7187;
                    }
                    else
                    { /* block id: 3252 */
                        if (l_7214[8][0])
                            break;
                        (*g_62) = (*g_5299);
                    }
                    if ((*l_6423))
                        break;
                }
                else
                { /* block id: 3257 */
                    union U1 *l_7215[8][5] = {{(void*)0,&l_6021,&l_6021,(void*)0,&g_4100},{&g_3183[1][1][3],&l_6786[4],&l_6786[4],&g_3183[1][1][3],&l_5941},{(void*)0,&l_6021,&l_6021,(void*)0,&g_4100},{&g_3183[1][1][3],&l_6786[4],&l_6786[4],&g_3183[1][1][3],&l_5941},{(void*)0,&l_6021,&l_6021,(void*)0,&g_4100},{&g_3183[1][1][3],&l_6786[4],&l_6786[4],&g_3183[1][1][3],&l_5941},{(void*)0,&l_6021,&l_6021,(void*)0,&g_4100},{&g_3183[1][1][3],&l_6786[4],&l_6786[4],&g_3183[1][1][3],&l_5941}};
                    int32_t l_7216[6] = {0x468D8FB6L,0x468D8FB6L,0x468D8FB6L,0x468D8FB6L,0x468D8FB6L,0x468D8FB6L};
                    int i, j;
                    l_7215[1][1] = ((*g_180) = &l_6786[0]);
                    return l_7216[5];
                }
            }
            for (l_6022 = 0; (l_6022 <= 2); l_6022 += 1)
            { /* block id: 3265 */
                uint16_t l_7233 = 0xB9CCL;
                int32_t l_7234[1];
                union U1 l_7255 = {0UL};
                int32_t l_7297 = 0xDD14846FL;
                uint64_t l_7303 = 0x173A80463DD543BELL;
                const union U1 *** const *l_7314 = (void*)0;
                const union U1 *** const **l_7313 = &l_7314;
                uint32_t l_7344 = 0x6988F4E8L;
                int i;
                for (i = 0; i < 1; i++)
                    l_7234[i] = 0xFD6CCFBDL;
                for (g_4906 = 0; (g_4906 <= 2); g_4906 += 1)
                { /* block id: 3268 */
                    uint16_t l_7232 = 0x259EL;
                    for (g_746 = 7; (g_746 >= 0); g_746 -= 1)
                    { /* block id: 3271 */
                        union U1 ***l_7223[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int8_t ***l_7229 = &g_4603[0][1];
                        int32_t *l_7235 = (void*)0;
                        int32_t * const l_7242[3][6] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                        int i, j;
                        l_7234[0] |= (((safe_mul_func_uint32_t_u_u(((safe_rshift_func_uint32_t_u_s(l_7214[(l_6022 + 1)][(g_4906 + 2)], 26)) < ((safe_lshift_func_int8_t_s_u(((((*g_2582) = (*g_2582)) == l_7223[1]) , 3L), ((((safe_lshift_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_s(l_7214[(l_6022 + 3)][(g_4906 + 2)], (*l_6423))), 58)) > (((*g_1059) = (*g_1059)) == ((*l_7229) = l_7228))) >= ((safe_mod_func_int16_t_s_s(((****g_6617) = (l_7232 ^ (****g_3323))), 1UL)) , (*l_6623))) , (*g_4020)))) && (-6L))), l_7233)) <= 0xA006DCF6L) == (-1L));
                        (*g_5559) = l_7235;
                        (*g_5834) = &l_6753;
                        l_7243++;
                    }
                    (*l_7182) ^= ((*g_62) = ((*l_6623) ^ ((safe_add_func_int32_t_s_s((((safe_add_func_uint8_t_u_u(((((*l_7160) | (((g_7252 == (***l_6186)) ^ (l_7253 >= (*g_969))) == ((*l_6623) , (~l_7232)))) || 0x6DBFC584L) > 0xE0A56A53L), 0x8EL)) | l_7234[0]) != 0UL), 0x6327CC19L)) != l_7234[0])));
                }
                (*l_6423) = (((*g_2582) == (l_7255 , (*g_2582))) , (&g_4452 != l_7256));
                for (g_1935 = 0; (g_1935 <= 2); g_1935 += 1)
                { /* block id: 3293 */
                    const uint32_t l_7261[9] = {18446744073709551615UL,0x839D1DCCL,18446744073709551615UL,18446744073709551615UL,0x839D1DCCL,18446744073709551615UL,18446744073709551615UL,0x839D1DCCL,18446744073709551615UL};
                    int i;
                    (*l_6623) = ((safe_rshift_func_uint64_t_u_s((safe_add_func_int16_t_s_s(((***g_6618) &= (l_7261[4] || ((safe_rshift_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((((safe_rshift_func_uint64_t_u_s((0xAEB33C0940A9D51ALL < ((l_7261[0] < ((safe_rshift_func_int64_t_s_s(((+0x720EL) != ((safe_rshift_func_uint32_t_u_u(((safe_add_func_int32_t_s_s((-10L), (safe_add_func_int64_t_s_s(0xCB51F0FAA19B2AE3LL, (*l_7182))))) , ((safe_div_func_int32_t_s_s(l_7255.f0, (*l_6423))) && 1L)), 22)) <= l_7255.f0)), l_7261[4])) , l_7233)) == (**g_4019))), 30)) || l_7234[0]) ^ (*l_7182)), (*l_6623))), l_7234[0])), 36)) & 0xB5B98E4DBC960CFELL))), l_7281)), l_7261[4])) <= 0xD54DL);
                    (*g_5834) = &l_7147[0][4][3];
                }
                if (((((*l_7166)++) , (*l_7160)) == (safe_add_func_uint64_t_u_u(((l_7286 | (((*l_6423) > ((*g_1358) & (&g_5138[0][1] != (l_7287[0] , (((((((safe_mul_func_uint64_t_u_u((l_7290 , (((safe_add_func_uint64_t_u_u((((l_7255.f0 == (safe_sub_func_uint32_t_u_u(((safe_div_func_uint64_t_u_u((*l_7182), (-7L))) ^ 0x78L), (*l_6423)))) != (*l_7182)) & (*l_7160)), (*g_1358))) , 1UL) & (*g_4952))), (*l_6423))) || 0xA4FBE6FAL) >= (*l_7182)) , l_7297) || (*l_7182)) , l_7298) , l_7299))))) < l_7297)) | (*l_7182)), 0x835232A828CB34B4LL))))
                { /* block id: 3299 */
                    uint8_t l_7302[3];
                    const union U1 *** const **l_7315 = &l_7314;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_7302[i] = 0xC4L;
                    for (g_3212 = 2; (g_3212 >= 0); g_3212 -= 1)
                    { /* block id: 3302 */
                        union U0 *l_7301[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_7301[i] = &g_4207;
                        l_7301[0] = (*g_5406);
                        if (l_7302[0])
                            continue;
                        (*l_7182) = ((void*)0 == (*g_1357));
                        if (l_7303)
                            continue;
                    }
                    for (l_6624 = 3; (l_6624 >= 0); l_6624 -= 1)
                    { /* block id: 3310 */
                        int64_t **l_7307 = &g_1358;
                        int64_t ***l_7306[9][7] = {{&l_7307,&g_4453,(void*)0,&g_4453,&g_4453,&g_4453,(void*)0},{&g_4453,&g_4453,&l_7307,&l_7307,(void*)0,(void*)0,&l_7307},{&g_4453,(void*)0,&g_4453,&g_4453,(void*)0,&l_7307,&g_4453},{&g_4453,&g_4453,(void*)0,(void*)0,&g_4453,(void*)0,&g_4453},{(void*)0,(void*)0,&g_4453,&g_4453,&l_7307,&l_7307,&l_7307},{&g_4453,&g_4453,(void*)0,&g_4453,&g_4453,(void*)0,&l_7307},{&l_7307,&l_7307,&g_4453,&g_4453,&l_7307,&g_4453,&g_4453},{&g_4453,(void*)0,&g_4453,&l_7307,&l_7307,&g_4453,&g_4453},{&l_7307,&g_4453,(void*)0,&g_4453,(void*)0,&g_4453,&l_7307}};
                        int16_t *l_7310 = &g_4632;
                        int32_t l_7316 = (-1L);
                        int i, j;
                        if (l_6016)
                            goto lbl_6709;
                        (*l_7160) = (((safe_lshift_func_int8_t_s_s(((*g_4452) != (g_7308 = (**g_4451))), 0)) == (((((l_7309[5] || (l_7310 != ((**g_6316) , (void*)0))) == 1UL) <= (safe_mod_func_uint16_t_u_u(((l_7315 = l_7313) != (void*)0), l_7316))) || 0xA4L) >= (****g_3323))) < (-1L));
                        if ((*l_6423))
                            break;
                        return (*l_7182);
                    }
                    if (((*l_7160) = ((*g_62) = ((void*)0 != (*l_7299)))))
                    { /* block id: 3320 */
                        if ((*l_7182))
                            break;
                    }
                    else
                    { /* block id: 3322 */
                        return (**g_6619);
                    }
                    for (l_6851 = 2; (l_6851 >= 0); l_6851 -= 1)
                    { /* block id: 3327 */
                        uint64_t l_7328 = 0x60D4BD9FAC21F643LL;
                        (*l_7160) = (l_7317 != (void*)0);
                        (*g_62) ^= (safe_unary_minus_func_uint8_t_u(((((*l_6623) ^= 8L) ^ 0xA192L) <= (0x2A39L < (safe_div_func_uint16_t_u_u(0xF16AL, (safe_mod_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((safe_rshift_func_uint32_t_u_s(l_7328, 23)) >= ((*g_3637) == (*g_826))), ((safe_div_func_int16_t_s_s((safe_mod_func_uint8_t_u_u((*l_7182), (safe_rshift_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(l_7337, 2)) & 0xC464A7D2C4370C23LL), 6)))), g_7338)) >= (*l_6423)))), (****g_3323)))))))));
                        return l_7328;
                    }
                }
                else
                { /* block id: 3333 */
                    int64_t l_7339[4][9][7] = {{{0L,8L,0x977EC3D8817911ACLL,0xA78F790AF38509B1LL,8L,0x929444579EC6F0FBLL,0x977EC3D8817911ACLL},{1L,0x68B8257271939D2FLL,0xE9A5A581FA7C76EALL,2L,0xBBF2B9FAB4121A72LL,(-1L),0xBBF2B9FAB4121A72LL},{0x53045BD1E8B36E41LL,0x977EC3D8817911ACLL,0x977EC3D8817911ACLL,0x53045BD1E8B36E41LL,0x929444579EC6F0FBLL,(-1L),(-6L)},{(-2L),0L,(-6L),0x83CC6DC02D0B2555LL,0x1513209C76993A80LL,(-1L),0xD85CFED93C9B7DA3LL},{0L,0x53045BD1E8B36E41LL,1L,(-1L),8L,1L,(-6L)},{0xBBF2B9FAB4121A72LL,(-3L),0xA2D6456FFEAEDE35LL,0L,0xF0EDB10875E4088BLL,0x83CC6DC02D0B2555LL,0xBBF2B9FAB4121A72LL},{0L,(-6L),(-1L),0x929444579EC6F0FBLL,0x53045BD1E8B36E41LL,0x977EC3D8817911ACLL,0x977EC3D8817911ACLL},{0L,0L,2L,0L,0L,(-1L),0xD96ECEE04306BCA2LL},{8L,0x7300EACFC8219228LL,0xA78F790AF38509B1LL,(-1L),0x929444579EC6F0FBLL,0x7300EACFC8219228LL,(-1L)}},{{0xA2D6456FFEAEDE35LL,0x68B8257271939D2FLL,0xEC8C7C8FD7A6F7CDLL,0x83CC6DC02D0B2555LL,1L,0x83CC6DC02D0B2555LL,0xEC8C7C8FD7A6F7CDLL},{8L,(-1L),1L,0x53045BD1E8B36E41LL,0L,1L,0L},{0L,(-3L),0xD85CFED93C9B7DA3LL,2L,(-6L),(-1L),0L},{0L,0L,0xA78F790AF38509B1LL,0xA78F790AF38509B1LL,0L,0L,0x977EC3D8817911ACLL},{0xBBF2B9FAB4121A72LL,2L,0xE9A5A581FA7C76EALL,0x68B8257271939D2FLL,1L,(-1L),1L},{0L,0x977EC3D8817911ACLL,(-1L),0L,0x929444579EC6F0FBLL,0xA78F790AF38509B1LL,0L},{(-2L),2L,(-2L),0x83CC6DC02D0B2555LL,0L,(-3L),0xD85CFED93C9B7DA3LL},{0x7300EACFC8219228LL,0x929444579EC6F0FBLL,(-1L),0xA78F790AF38509B1LL,0x7300EACFC8219228LL,8L,(-1L)},{0xA2D6456FFEAEDE35LL,(-1L),0x06C3FCD1B3D68BFCLL,(-1L),0x06C3FCD1B3D68BFCLL,(-1L),0xA2D6456FFEAEDE35LL}},{{0x84E6CF95B47DF706LL,(-1L),1L,1L,0L,(-9L),1L},{(-2L),(-1L),0xD96ECEE04306BCA2LL,(-3L),(-6L),0x68B8257271939D2FLL,(-6L)},{0x7300EACFC8219228LL,1L,1L,0x977EC3D8817911ACLL,1L,0x84E6CF95B47DF706LL,0x977EC3D8817911ACLL},{0xBD133554188E9C54LL,0x83CC6DC02D0B2555LL,0x06C3FCD1B3D68BFCLL,1L,0xF0EDB10875E4088BLL,0x584E6B7770A53E3ALL,0xE9A5A581FA7C76EALL},{0x929444579EC6F0FBLL,0x977EC3D8817911ACLL,(-1L),0L,0L,(-1L),0x977EC3D8817911ACLL},{(-6L),(-1L),0L,0x83CC6DC02D0B2555LL,0x60FEBB07E3D37425LL,1L,(-6L)},{0x84E6CF95B47DF706LL,0x7300EACFC8219228LL,0xFA9227C41B7BAAE1LL,(-9L),0x7300EACFC8219228LL,1L,1L},{0xEC8C7C8FD7A6F7CDLL,0x83CC6DC02D0B2555LL,1L,0x83CC6DC02D0B2555LL,0xEC8C7C8FD7A6F7CDLL,0x68B8257271939D2FLL,0xA2D6456FFEAEDE35LL},{0L,1L,(-9L),0L,1L,1L,(-1L)}},{{0L,(-1L),2L,1L,(-2L),1L,2L},{0L,0L,(-1L),0x977EC3D8817911ACLL,0x929444579EC6F0FBLL,8L,0xA78F790AF38509B1LL},{0xEC8C7C8FD7A6F7CDLL,(-1L),0xE9A5A581FA7C76EALL,(-3L),0x06C3FCD1B3D68BFCLL,0x584E6B7770A53E3ALL,0xEC8C7C8FD7A6F7CDLL},{0x84E6CF95B47DF706LL,0xA78F790AF38509B1LL,(-9L),1L,0x929444579EC6F0FBLL,0xFA9227C41B7BAAE1LL,1L},{(-6L),(-3L),0xD96ECEE04306BCA2LL,(-1L),(-2L),0x68B8257271939D2FLL,0xD85CFED93C9B7DA3LL},{0x929444579EC6F0FBLL,1L,0xFA9227C41B7BAAE1LL,0xA78F790AF38509B1LL,1L,1L,0xA78F790AF38509B1LL},{0xBD133554188E9C54LL,(-3L),0xBD133554188E9C54LL,1L,0xEC8C7C8FD7A6F7CDLL,(-1L),0xE9A5A581FA7C76EALL},{0x7300EACFC8219228LL,0xA78F790AF38509B1LL,(-1L),0x929444579EC6F0FBLL,0x7300EACFC8219228LL,(-1L),(-1L)},{(-2L),(-1L),0x60FEBB07E3D37425LL,(-1L),0x60FEBB07E3D37425LL,(-1L),(-2L)}}};
                    int i, j, k;
                    for (g_5844 = 0; (g_5844 <= 2); g_5844 += 1)
                    { /* block id: 3336 */
                        if (l_7339[2][1][2])
                            break;
                    }
                }
                for (l_7146 = 2; (l_7146 >= 0); l_7146 -= 1)
                { /* block id: 3342 */
                    for (l_5847 = 0; (l_5847 <= 2); l_5847 += 1)
                    { /* block id: 3345 */
                        int32_t l_7343 = 0x0586F8B9L;
                        (*g_62) = (safe_rshift_func_uint16_t_u_s((((*l_6423) != ((**g_4951) &= (safe_unary_minus_func_uint64_t_u((l_7343 && l_7344))))) != l_7255.f0), 10));
                    }
                    for (g_7085 = 2; (g_7085 <= 7); g_7085 += 1)
                    { /* block id: 3351 */
                        int i;
                        (*g_5561) = (void*)0;
                        (*g_5561) = l_6280[(l_7146 + 3)];
                        if (g_5909)
                            goto lbl_7167;
                    }
                }
            }
            if (((*g_62) >= ((safe_lshift_func_uint16_t_u_s((((+((**g_4951) &= (safe_mul_func_int16_t_s_s((safe_mod_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((((((*g_253) , (*l_6423)) != (safe_add_func_uint16_t_u_u((*l_7182), (((***l_7077) ^= (((safe_div_func_uint8_t_u_u(((void*)0 != (**g_4451)), (~(safe_lshift_func_uint16_t_u_u((*l_7160), 14))))) <= ((*g_6419) ^= (l_7361 & (((((safe_div_func_int64_t_s_s((*l_6423), (*l_6623))) > 255UL) > 0x7BEF7BCEL) != (*l_7182)) != l_7364)))) != (*l_7160))) ^ (**g_4453))))) == 1L) , 0x22L), (-7L))), (****g_3323))), 65532UL)))) < (-5L)) ^ (*l_7160)), 11)) > (*l_7182))))
            { /* block id: 3361 */
                return (*l_7160);
            }
            else
            { /* block id: 3363 */
                uint32_t l_7367 = 0UL;
                for (g_682.f4 = 0; (g_682.f4 == 10); g_682.f4 = safe_add_func_uint16_t_u_u(g_682.f4, 1))
                { /* block id: 3366 */
                    return l_7367;
                }
                g_7368[2][1][0] = ((**g_3181) , l_7367);
            }
            return (*l_7160);
        }
    }
    (*l_6423) = g_7369;
    return (*g_7252);
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_46 g_55 g_55.f0 g_190 g_527 g_77 g_662 g_1997 g_62 g_117 g_362 g_878 g_689 g_308.f0 g_1937 g_875 g_876 g_877 g_733 g_1998 g_1939 g_969 g_1732 g_267 g_1358 g_846 g_614 g_822.f0 g_732 g_181 g_571 g_180 g_968 g_63 g_1658 g_85 g_1151 g_1357 g_764 g_2583 g_2584 g_2585 g_2586 g_80 g_253 g_254 g_885 g_827 g_828 g_746 g_822.f4 g_613 g_2586.f0 g_2267 g_1681 g_1329 g_1256 g_797 g_75 g_430 g_203 g_904 g_2957 g_2958 g_825 g_826 g_3015 g_2882 g_3033 g_3058 g_3069 g_1578 g_971 g_1191.f4 g_560.f0 g_3164 g_1625 g_3212 g_731 g_3224 g_3225 g_3255 g_2511.f0 g_3286 g_1411.f4 g_3294 g_3302 g_3164.f0 g_2582 g_3323 g_3324 g_3325 g_3326 g_321 g_3180 g_3181 g_3182 g_3411 g_3418 g_2962 g_201 g_3520 g_3523 g_2486 g_2487 g_3548 g_2311.f0 g_3567 g_3579 g_3602 g_3615 g_241 g_3548.f4 g_1735 g_116 g_1150 g_3706 g_123.f4 g_1846 g_544 g_1497.f0 g_3781 g_633 g_1935 g_3821 g_484 g_2897 g_1060 g_3926 g_3224.f0 g_4019 g_4027 g_4028 g_4020 g_4045 g_4095 g_4100 g_4121 g_1164 g_4207 g_3833 g_4235 g_3183 g_4100.f0 g_3707 g_4028.f4 g_4603 g_2896 g_4453 g_4611 g_5156 g_5177 g_5190 g_5180 g_5218 g_4950 g_4951 g_4952 g_4452 g_4604 g_5299 g_596 g_3521 g_3522 g_619 g_4905 g_5406 g_4829 g_4830 g_560 g_1425 g_1426 g_4451 g_5538 g_5179 g_1427 g_5561 g_113.f4 g_4774 g_5621 g_682.f4 g_5178 g_5641 g_5642 g_5676 g_4775 g_5784 g_5796 g_5824
 * writes: g_55.f0 g_117 g_527 g_77 g_1329 g_267 g_63 g_362 g_1939 g_904 g_614 g_1139 g_543 g_201 g_822.f1 g_1831 g_571 g_55 g_75 g_190 g_85 g_764 g_80 g_1937 g_746 g_846 g_2682 g_822.f4 g_31 g_1658 g_613 g_596 g_1496 g_2586.f0 g_924 g_1681 g_2882 g_1191.f4 g_1497.f4 g_430 g_797 g_1256 g_2895 g_203 g_2948 g_2957 g_241 g_1427 g_1411.f4 g_181 g_1935 g_1578 g_847 g_1164.f4 g_1088 g_3178 g_308.f0 g_3323 g_321 g_3286 g_3183 g_3548.f4 g_1151 g_3706 g_123.f4 g_3832 g_113.f4 g_180 g_4106 g_3834 g_4027 g_4100.f0 g_4028.f4 g_1060 g_5138 g_5165 g_2962 g_5258 g_1732 g_662 g_4905 g_5405 g_5223 g_560.f3 g_4045 g_1788.f4 g_4095 g_5559 g_5561 g_560.f0 g_368 g_4462.f1 g_4949 g_3212 g_5190 g_4906 g_4775 g_5621 g_682.f4 g_4724.f4 g_3326 g_4632 g_5713 g_5715 g_4121 g_5825
 */
static uint32_t  func_7(const uint64_t  p_8)
{ /* block id: 1 */
    uint32_t l_47 = 0x425F8E10L;
    uint16_t l_1281[3];
    uint32_t l_2567 = 4294967295UL;
    union U1 l_2568 = {0UL};
    uint8_t ****l_5135 = (void*)0;
    int32_t *****l_5166 = &g_3832;
    int32_t l_5167 = 1L;
    int32_t l_5168[2];
    int16_t l_5169 = 1L;
    int32_t * const *l_5170 = &g_484;
    int32_t l_5204[5];
    uint16_t ** const l_5254[10] = {&g_1732,&g_662,&g_1732,&g_1732,&g_662,&g_1732,&g_662,&g_1732,&g_1732,&g_662};
    uint16_t ** const * const l_5253 = &l_5254[9];
    uint16_t ** const * const *l_5252 = &l_5253;
    uint16_t ** const * const **l_5251 = &l_5252;
    uint64_t *l_5275[5];
    const union U1 ****l_5283[10][3][5] = {{{&g_251[0][2],&g_251[0][2],&g_251[2][0],&g_251[3][3],&g_251[0][2]},{&g_251[0][2],&g_251[0][2],&g_251[1][2],&g_251[1][1],&g_251[0][2]},{&g_251[0][2],&g_251[1][0],&g_251[0][2],&g_251[3][3],&g_251[1][0]}},{{(void*)0,&g_251[0][2],&g_251[1][1],&g_251[1][2],&g_251[0][2]},{&g_251[1][1],&g_251[0][2],&g_251[0][2],&g_251[0][2],&g_251[0][2]},{(void*)0,&g_251[2][3],&g_251[1][2],&g_251[1][2],&g_251[3][2]}},{{&g_251[0][2],&g_251[0][2],&g_251[2][0],&g_251[3][3],&g_251[0][2]},{&g_251[0][2],&g_251[0][2],&g_251[1][2],&g_251[1][1],&g_251[0][2]},{&g_251[0][2],&g_251[1][0],(void*)0,&g_251[1][0],&g_251[1][0]}},{{(void*)0,(void*)0,&g_251[0][2],&g_251[2][3],&g_251[0][2]},{(void*)0,&g_251[0][1],(void*)0,(void*)0,&g_251[0][1]},{(void*)0,&g_251[0][2],(void*)0,&g_251[2][3],&g_251[0][2]}},{{&g_251[0][2],&g_251[0][1],&g_251[0][2],&g_251[1][0],&g_251[0][1]},{&g_251[0][0],(void*)0,(void*)0,&g_251[0][1],&g_251[0][2]},{&g_251[0][2],&g_251[1][0],(void*)0,&g_251[1][0],&g_251[1][0]}},{{(void*)0,(void*)0,&g_251[0][2],&g_251[2][3],&g_251[0][2]},{(void*)0,&g_251[0][1],(void*)0,(void*)0,&g_251[0][1]},{(void*)0,&g_251[0][2],(void*)0,&g_251[2][3],&g_251[0][2]}},{{&g_251[0][2],&g_251[0][1],&g_251[0][2],&g_251[1][0],&g_251[0][1]},{&g_251[0][0],(void*)0,(void*)0,&g_251[0][1],&g_251[0][2]},{&g_251[0][2],&g_251[1][0],(void*)0,&g_251[1][0],&g_251[1][0]}},{{(void*)0,(void*)0,&g_251[0][2],&g_251[2][3],&g_251[0][2]},{(void*)0,&g_251[0][1],(void*)0,(void*)0,&g_251[0][1]},{(void*)0,&g_251[0][2],(void*)0,&g_251[2][3],&g_251[0][2]}},{{&g_251[0][2],&g_251[0][1],&g_251[0][2],&g_251[1][0],&g_251[0][1]},{&g_251[0][0],(void*)0,(void*)0,&g_251[0][1],&g_251[0][2]},{&g_251[0][2],&g_251[1][0],(void*)0,&g_251[1][0],&g_251[1][0]}},{{(void*)0,(void*)0,&g_251[0][2],&g_251[2][3],&g_251[0][2]},{(void*)0,&g_251[0][1],(void*)0,(void*)0,&g_251[0][1]},{(void*)0,&g_251[0][2],(void*)0,&g_251[2][3],&g_251[0][2]}}};
    int32_t l_5332 = 0x91B10154L;
    int64_t l_5334[2];
    union U0 *l_5341 = (void*)0;
    int32_t ***l_5394[3];
    const int16_t * const *l_5401 = &g_1427[3];
    const int16_t * const **l_5400 = &l_5401;
    const int16_t * const ** const *l_5399 = &l_5400;
    const int16_t * const ** const **l_5398 = &l_5399;
    uint64_t ***l_5445 = (void*)0;
    uint32_t l_5448 = 0x5ED568BFL;
    uint32_t *l_5452 = &g_3411;
    uint32_t **l_5451[8][6] = {{(void*)0,&l_5452,&l_5452,&l_5452,&l_5452,(void*)0},{&l_5452,(void*)0,&l_5452,(void*)0,&l_5452,&l_5452},{(void*)0,(void*)0,(void*)0,(void*)0,&l_5452,(void*)0},{(void*)0,&l_5452,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5452,&l_5452,(void*)0,&l_5452,(void*)0,&l_5452},{(void*)0,&l_5452,&l_5452,&l_5452,&l_5452,(void*)0},{&l_5452,(void*)0,&l_5452,(void*)0,&l_5452,&l_5452},{(void*)0,(void*)0,(void*)0,(void*)0,&l_5452,(void*)0}};
    int32_t l_5504 = (-1L);
    int8_t l_5506[4] = {0x55L,0x55L,0x55L,0x55L};
    uint16_t l_5556 = 6UL;
    uint16_t l_5617 = 5UL;
    uint64_t *****l_5634 = (void*)0;
    int64_t l_5694 = 0L;
    union U1 **l_5718 = &g_181;
    union U1 **l_5720 = &g_181;
    int16_t l_5724 = 0x007DL;
    uint8_t *l_5792[9] = {&g_4100.f0,(void*)0,(void*)0,&g_4100.f0,(void*)0,(void*)0,&g_4100.f0,(void*)0,(void*)0};
    int16_t **l_5821 = &g_969;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1281[i] = 0UL;
    for (i = 0; i < 2; i++)
        l_5168[i] = 0xB05672E5L;
    for (i = 0; i < 5; i++)
        l_5204[i] = 0xEDB20D38L;
    for (i = 0; i < 5; i++)
        l_5275[i] = &g_764;
    for (i = 0; i < 2; i++)
        l_5334[i] = 0x91748BE201F5B619LL;
    for (i = 0; i < 3; i++)
        l_5394[i] = (void*)0;
    if ((safe_mul_func_uint8_t_u_u(((~((safe_rshift_func_int8_t_s_u((func_14(((*g_1151) = (safe_mul_func_uint32_t_u_u(func_21((l_2568 = func_25(((*g_190) = ((safe_div_func_uint64_t_u_u(g_31, (safe_rshift_func_uint32_t_u_s((safe_rshift_func_uint16_t_u_s(((*g_662) = (safe_mod_func_int64_t_s_s(((((func_38(func_40(g_31, (((g_46[6] , l_47) , ((safe_unary_minus_func_int64_t_s(p_8)) && g_31)) , (func_49(func_53(((p_8 < g_31) , g_55)), l_1281[2], l_47) , (****g_875))), l_1281[2], l_1281[2], p_8)) >= 0xB9L) & (-5L)) || p_8) , 5L), 18446744073709551615UL))), l_2567)), l_2567)))) > 0xFBL)), l_2568, g_1658[0])), p_8, p_8), l_47))), l_47, l_1281[2], p_8) , l_1281[2]), l_47)) <= 1UL)) | p_8), 0UL)))
    { /* block id: 2200 */
        uint8_t *****l_5137[3];
        int32_t *l_5141 = (void*)0;
        int32_t **l_5142 = (void*)0;
        int32_t *****l_5164 = &g_3832;
        int32_t l_5194 = (-9L);
        int32_t l_5196 = 0L;
        int64_t l_5198 = 0x46529DDF33E56C48LL;
        int32_t l_5199 = (-1L);
        int32_t l_5203 = 0xC1A699F3L;
        int32_t l_5205 = 0xDB278476L;
        int32_t l_5206 = 0L;
        uint32_t *****l_5302 = &g_4775[0][4][2];
        int16_t ***l_5313 = (void*)0;
        uint64_t l_5315 = 0xA417460DC3D406D8LL;
        uint64_t l_5333 = 0xF847D091AE22E54BLL;
        int16_t l_5382 = 0x07E4L;
        int i;
        for (i = 0; i < 3; i++)
            l_5137[i] = &l_5135;
        g_5138[5][1] = l_5135;
lbl_5171:
        l_5141 = l_5141;
        if ((((p_8 > (safe_div_func_int16_t_s_s(((*g_969) = (!(safe_mul_func_uint8_t_u_u(((safe_div_func_uint16_t_u_u((safe_add_func_uint64_t_u_u(((p_8 , ((safe_lshift_func_uint8_t_u_s((safe_add_func_uint32_t_u_u((l_5168[1] ^= (p_8 || (((((l_5167 = ((**g_1357) ^= (((g_5156 , (safe_add_func_uint32_t_u_u((((safe_div_func_uint16_t_u_u(0x0963L, ((*g_662) = p_8))) >= (+((safe_lshift_func_int32_t_s_u(p_8, (((g_5165 = l_5164) == (l_5166 = &g_3832)) > 0xE5FF07B805DFF00CLL))) < 65528UL))) >= 0x5D4D8103L), l_2567))) && l_1281[1]) , 0xB7A19939738C6A61LL))) | p_8) != l_2568.f0) & l_47) <= p_8))), 1UL)), 7)) > l_5169)) || 1L), 0x8D39F6E73FE1AAD8LL)), p_8)) != p_8), 0UL)))), l_2567))) , l_5168[1]) != 0x2A48L))
        { /* block id: 2210 */
            const int8_t l_5181 = 0L;
            int32_t l_5195 = 0xF90C78AEL;
            int32_t l_5197 = (-1L);
            int32_t l_5200 = 1L;
            int32_t l_5201 = 0L;
            int32_t l_5202[5] = {0x423D8D18L,0x423D8D18L,0x423D8D18L,0x423D8D18L,0x423D8D18L};
            int16_t ****l_5210 = &g_1424;
            uint8_t l_5231[7] = {5UL,5UL,5UL,5UL,5UL,5UL,5UL};
            uint32_t *l_5270 = (void*)0;
            uint32_t **l_5269 = &l_5270;
            uint32_t l_5279 = 0x7CBB4FBDL;
            uint32_t l_5321 = 0x46997DDDL;
            uint16_t *l_5344 = (void*)0;
            const uint32_t l_5393 = 18446744073709551606UL;
            int i;
            if (((void*)0 == l_5170))
            { /* block id: 2211 */
                uint64_t l_5191[5];
                int32_t *l_5192 = &g_797;
                int32_t *l_5193[10][1][7] = {{{&g_614,&g_1256,&g_614,(void*)0,(void*)0,&g_614,&g_1256}},{{(void*)0,&g_63,&g_1256,&g_1256,&g_63,&g_614,&g_63}},{{(void*)0,&g_614,&g_614,(void*)0,&g_63,(void*)0,&g_614}},{{(void*)0,(void*)0,&g_614,&g_1256,&g_614,(void*)0,(void*)0}},{{(void*)0,&g_614,&g_1256,&g_614,(void*)0,(void*)0,&g_614}},{{(void*)0,&g_63,(void*)0,&g_614,&g_614,(void*)0,&g_63}},{{&g_614,&g_63,&g_1256,&g_1256,&g_63,&g_614,&g_63}},{{(void*)0,&g_614,&g_614,(void*)0,&g_63,(void*)0,&g_614}},{{(void*)0,(void*)0,&g_614,&g_1256,&g_614,(void*)0,(void*)0}},{{(void*)0,&g_614,&g_1256,&g_614,(void*)0,(void*)0,&g_614}}};
                uint32_t l_5207 = 0xD99BE668L;
                int32_t * const l_5219 = &l_5199;
                union U1 l_5224[6] = {{0x9FL},{0x88L},{0x9FL},{0x9FL},{0x88L},{0x9FL}};
                uint32_t l_5256 = 8UL;
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_5191[i] = 0xBD23C1ABB5AF5D45LL;
                if (g_4121)
                    goto lbl_5171;
                (*g_62) ^= (safe_lshift_func_uint64_t_u_s(((safe_rshift_func_int16_t_s_u((+((((&g_4775[0][4][2] != g_5177) && l_5181) && p_8) & ((((safe_mul_func_int32_t_s_s((safe_sub_func_uint32_t_u_u(p_8, p_8)), ((safe_lshift_func_uint32_t_u_u(((l_5181 != ((l_5167 = (((1UL ^ ((safe_sub_func_int16_t_s_s(0x29F6L, p_8)) < (**g_3325))) && 0x006B69A7L) && 0xB2L)) , g_5190)) > 9UL), (**g_5180))) <= l_47))) && 1UL) , l_5181) >= (-1L)))), l_5191[4])) ^ p_8), p_8));
                l_5207++;
                if (((void*)0 != l_5210))
                { /* block id: 2216 */
                    int32_t l_5216 = 0x80132B4BL;
                    int32_t *l_5217 = &g_63;
                    for (g_3548.f4 = 0; (g_3548.f4 <= 1); g_3548.f4 += 1)
                    { /* block id: 2219 */
                        int32_t * const l_5211[8][7] = {{&l_5197,&l_5206,&l_5197,&l_5194,&g_1256,&l_5194,&l_5197},{&l_5194,&l_5194,&l_5204[0],&l_5194,&l_5194,&l_5204[0],&l_5194},{&g_1256,&l_5194,&l_5197,&l_5206,&l_5197,&l_5194,&g_1256},{&l_5205,&l_5194,&l_5205,&l_5205,&l_5194,&l_5205,&l_5205},{&g_1256,&l_5206,&g_1578,&l_5206,&g_1256,&l_5197,&g_1256},{&l_5194,&l_5205,&l_5205,&l_5194,&l_5205,&l_5205,&l_5194},{&l_5197,&l_5206,&l_5197,&l_5194,&g_1256,&l_5194,&l_5197},{&l_5194,&l_5194,&l_5204[0],&l_5194,&l_5194,&l_5204[0],&l_5194}};
                        int i, j;
                        (*g_5218) = l_5217;
                        return p_8;
                    }
                }
                else
                { /* block id: 2224 */
                    uint8_t l_5236 = 8UL;
                    int32_t l_5246 = 0xA67FE2CCL;
                    for (g_746 = 2; (g_746 >= 0); g_746 -= 1)
                    { /* block id: 2227 */
                        int32_t * const l_5220[8] = {&l_5201,&l_5201,&l_5201,&l_5201,&l_5201,&l_5201,&l_5201,&l_5201};
                        int32_t **l_5225[8][4][2] = {{{&l_5193[9][0][3],(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_5193[9][0][3],&l_5193[9][0][3]}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_5193[9][0][3]},{&l_5193[9][0][3],(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_5193[9][0][3],&l_5193[9][0][3]},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,&l_5193[9][0][3]},{&l_5193[9][0][3],(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{&l_5193[9][0][3],&l_5193[9][0][3]},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,&l_5193[9][0][3]},{&l_5193[9][0][3],(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{&l_5193[9][0][3],&l_5193[9][0][3]},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_5193[9][0][3]}},{{&l_5193[9][0][3],(void*)0},{(void*)0,&l_5192},{(void*)0,(void*)0},{&g_1139[0],&g_1139[0]}}};
                        int32_t **l_5226 = &l_5192;
                        int i, j, k;
                        (*l_5226) = &l_5204[4];
                        (*g_2267) = &g_3069[(g_746 + 1)];
                    }
                    for (l_2568.f0 = (-20); (l_2568.f0 >= 37); l_2568.f0++)
                    { /* block id: 2238 */
                        int16_t l_5243 = 0xEA7FL;
                        int32_t l_5255 = 0xAA114243L;
                        int64_t *l_5257[2];
                        int16_t l_5259 = 0x9241L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_5257[i] = &g_3212;
                        (*g_62) |= (((((safe_mod_func_uint32_t_u_u(((*g_1998) |= p_8), (0x7BBD197740DB7A93LL | ((((l_5231[6] == (l_5204[2] = (safe_sub_func_uint64_t_u_u(l_5204[0], (safe_rshift_func_uint64_t_u_s((--l_5236), 3)))))) <= (l_5202[1] = (g_5258 = ((***g_4452) = ((safe_rshift_func_uint64_t_u_s((safe_div_func_int32_t_s_s((((l_5255 = ((l_5167 ^= (((((***g_4950) ^= ((((l_5243 <= (((((1UL >= ((--(*g_1732)) != (((*g_1151)++) != ((safe_mod_func_uint16_t_u_u(((((*l_5219) = ((&l_5197 != &l_5246) >= 0x30C9CEAEL)) , 65533UL) , l_5181), p_8)) && 0xCA7DL)))) <= 0x5FE5L) && l_5246) ^ p_8) && 0L)) , (-5L)) & l_5246) , l_5201)) , l_5243) , (void*)0) != l_5251)) , p_8)) ^ l_5256) > p_8), p_8)), (**g_4453))) > l_5246))))) , 0xF9001113L) , 1L)))) > l_2568.f0) <= l_5259) || p_8) <= 0x77L);
                    }
                }
            }
            else
            { /* block id: 2254 */
                int16_t l_5276 = 6L;
                int32_t l_5277 = 0x916D3ECAL;
                int32_t *l_5278[9];
                uint16_t **l_5282 = (void*)0;
                int i;
                for (i = 0; i < 9; i++)
                    l_5278[i] = &l_5199;
                (*g_62) = (((safe_lshift_func_int32_t_s_u((safe_rshift_func_uint32_t_u_u((+(((safe_rshift_func_int32_t_s_u((safe_lshift_func_int8_t_s_s(((*g_4604) = 0x7AL), 4)), ((void*)0 == l_5269))) <= (safe_sub_func_int16_t_s_s(p_8, ((****l_5252) |= ((safe_rshift_func_int32_t_s_s(p_8, 2)) ^ ((l_5201 ^ ((**g_4951) = ((void*)0 != l_5275[0]))) != ((-1L) || p_8))))))) | p_8)), 27)), 23)) != 0UL) , p_8);
                for (g_77 = 0; (g_77 <= 1); g_77 += 1)
                { /* block id: 2261 */
                    return p_8;
                }
                l_5279++;
                l_5167 = (((void*)0 == l_5282) & l_5167);
            }
            if (((void*)0 == l_5283[2][0][4]))
            { /* block id: 2267 */
                int32_t l_5288 = 3L;
                int32_t **l_5296 = &g_484;
                (*g_62) |= ((((*g_1732) = (***g_3324)) > (safe_add_func_int64_t_s_s(((safe_div_func_uint8_t_u_u((*g_4020), p_8)) | (l_5288 ^= 0UL)), (safe_lshift_func_int8_t_s_s((safe_add_func_int32_t_s_s((0xD4D86F9D174262F2LL & 0UL), (safe_div_func_int32_t_s_s((((*g_2585) , &g_1139[0]) != ((((~(((((*g_3833) = l_5296) == (void*)0) || (-8L)) || p_8)) > l_5204[4]) | l_5202[4]) , &l_5141)), p_8)))), 2))))) , p_8);
                for (l_5288 = 0; (l_5288 >= (-2)); --l_5288)
                { /* block id: 2274 */
                    (*g_5299) = ((*g_62) = 9L);
                }
                for (l_5169 = 4; (l_5169 == (-6)); l_5169 = safe_sub_func_int32_t_s_s(l_5169, 2))
                { /* block id: 2280 */
                    uint32_t l_5316 = 0x60DB3C57L;
                    l_5302 = &g_4775[0][4][2];
                    for (g_596 = 0; (g_596 != 19); g_596++)
                    { /* block id: 2284 */
                        uint8_t l_5314 = 0UL;
                        l_5202[1] = ((0xA7L | (((**g_3521) <= (safe_add_func_int64_t_s_s(((safe_rshift_func_uint16_t_u_u(65529UL, 15)) | 1UL), ((safe_mul_func_uint64_t_u_u(p_8, (safe_mod_func_uint64_t_u_u(p_8, ((*g_1151) = (((l_5313 == (((((((*g_969) = (l_5314 || ((*g_4604) |= 0x63L))) < l_5315) >= p_8) & 0UL) == p_8) , (void*)0)) , l_5316) , l_5316)))))) == 0x62L)))) , p_8)) && (*g_1358));
                        if (p_8)
                            continue;
                    }
                    l_5167 = 0xB0296603L;
                }
            }
            else
            { /* block id: 2293 */
                return p_8;
            }
            for (g_75 = 2; (g_75 >= 0); g_75 -= 1)
            { /* block id: 2298 */
                uint16_t *l_5345 = (void*)0;
                union U1 * const l_5352 = &g_4100;
                int32_t l_5371 = (-3L);
                if (p_8)
                    break;
                l_5197 = (((((l_5334[1] |= ((safe_add_func_uint64_t_u_u(((safe_div_func_uint64_t_u_u(l_5321, (safe_div_func_int8_t_s_s(0xAEL, (safe_lshift_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((((p_8 , 0x4F73D1D156A481BDLL) < l_5195) & (safe_mul_func_uint64_t_u_u(l_5321, p_8))), (safe_lshift_func_uint32_t_u_s((((*g_4952) = l_5181) >= 0x49L), l_5332)))), 15)))))) ^ l_5195), (-1L))) || l_5333)) < (***g_825)) == p_8) > 0xECL) ^ p_8);
                l_5199 = (p_8 <= (safe_div_func_uint16_t_u_u(((0x77F5L != (((((**g_5180) = (safe_lshift_func_int8_t_s_u((safe_mod_func_uint8_t_u_u(((void*)0 == l_5341), 1L)), 1))) > (l_5283[2][0][4] == (void*)0)) || (safe_rshift_func_int8_t_s_s((&g_3520[4] != (((*g_62) ^= (((***l_5252) = l_5344) != l_5345)) , (void*)0)), 0))) , p_8)) ^ 7L), l_47)));
                for (l_5333 = 0; (l_5333 <= 1); l_5333 += 1)
                { /* block id: 2309 */
                    int16_t ****l_5367 = &g_1424;
                    uint32_t l_5370 = 1UL;
                    int32_t l_5392 = 0x427ED02DL;
                    for (g_822.f4 = 0; (g_822.f4 <= 1); g_822.f4 += 1)
                    { /* block id: 2312 */
                        union U1 *l_5351[4][4] = {{&g_308[0][7],&g_3183[1][3][0],&g_308[0][7],&g_3183[1][3][0]},{&g_308[0][7],&g_3183[1][3][0],&g_308[0][7],&g_3183[1][3][0]},{&g_308[0][7],&g_3183[1][3][0],&g_308[0][7],&g_3183[1][3][0]},{&g_308[0][7],&g_3183[1][3][0],&g_308[0][7],&g_3183[1][3][0]}};
                        const int16_t ****l_5369[5][6] = {{&g_1425,&g_1425,&g_1425,&g_1425,&g_1425,&g_1425},{&g_1425,&g_1425,&g_1425,&g_1425,&g_1425,&g_1425},{&g_1425,&g_1425,&g_1425,&g_1425,&g_1425,&g_1425},{&g_1425,&g_1425,&g_1425,&g_1425,&g_1425,&g_1425},{&g_1425,&g_1425,&g_1425,&g_1425,&g_1425,&g_1425}};
                        const int16_t *****l_5368 = &l_5369[0][5];
                        int i, j;
                        (*g_62) = (l_5371 = (((safe_div_func_int32_t_s_s(g_1939[l_5333], (safe_add_func_int32_t_s_s((l_5351[3][1] != l_5352), ((safe_lshift_func_int16_t_s_u((safe_mul_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((((p_8 , (0xFE0D8BE0L < ((safe_div_func_uint64_t_u_u((((-1L) > (safe_div_func_uint16_t_u_u((safe_mul_func_int64_t_s_s((p_8 == (safe_div_func_uint8_t_u_u(((l_5367 != ((*l_5368) = (void*)0)) >= (*g_3326)), l_5370))), 0x63DDAE0E481B70C0LL)), 65535UL))) , p_8), 9L)) , l_5370))) >= 0xE942L) > (*g_4020)), l_5370)), 0xE303L)), 1)) | (-1L)))))) > 0UL) && p_8));
                    }
                    for (g_4905 = 0; (g_4905 <= 8); g_4905 += 1)
                    { /* block id: 2319 */
                        const int32_t l_5391 = (-1L);
                        (*g_62) &= ((0x9601L ^ ((l_5231[5] >= (safe_lshift_func_uint64_t_u_u((~(safe_mod_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((safe_unary_minus_func_uint32_t_u(((*g_1998) = (((**g_4019)++) <= (((l_5371 >= p_8) != (l_5392 = (l_5370 < (l_5382 <= (safe_mul_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((0xA069D2C12C3464EALL >= ((**g_1357) = ((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_s(((*l_5269) != (void*)0), p_8)), l_5391)) || 0x71D8L))), p_8)) != 1UL), 1UL)))))) , 0xEDL))))), 7)), l_5393))), 30))) < 0xA22CBBFEC5FD45EFLL)) > p_8);
                    }
                }
            }
        }
        else
        { /* block id: 2328 */
            (*g_62) = l_5203;
        }
    }
    else
    { /* block id: 2331 */
        int32_t l_5430 = 1L;
        int32_t * const l_5449[1][9][2] = {{{(void*)0,&g_797},{&g_797,(void*)0},{&g_797,&g_797},{(void*)0,&g_797},{&g_797,(void*)0},{&g_797,&g_797},{(void*)0,&g_797},{&g_797,(void*)0},{&g_797,&g_797}}};
        uint8_t ** const *l_5480 = &g_5140;
        int32_t l_5483 = 3L;
        uint8_t l_5484 = 0x66L;
        union U0 ***l_5489 = &g_2267;
        uint32_t * const *l_5535 = (void*)0;
        uint32_t * const **l_5534 = &l_5535;
        int32_t **l_5558 = &g_190;
        int i, j, k;
        for (g_3548.f4 = 1; (g_3548.f4 >= 0); g_3548.f4 -= 1)
        { /* block id: 2334 */
            uint32_t **l_5412 = (void*)0;
            uint32_t ***l_5411 = &l_5412;
            int32_t l_5431 = 1L;
            uint64_t ***l_5444 = &g_1150[0];
            union U1 l_5455 = {0UL};
            union U1 l_5456 = {0x9DL};
            int32_t **l_5457 = &g_1139[0];
            int16_t **l_5466[3];
            union U0 ***l_5492 = &g_2267;
            int64_t *l_5494 = &l_5334[1];
            const int64_t l_5503 = 4L;
            int32_t l_5573 = 0xEA5AD786L;
            int i;
            for (i = 0; i < 3; i++)
                l_5466[i] = &g_969;
            if (l_5334[g_3548.f4])
                break;
            for (g_571 = 0; (g_571 <= 6); g_571 += 1)
            { /* block id: 2338 */
                uint8_t l_5426 = 0xA2L;
                uint64_t l_5429 = 3UL;
                int32_t *l_5432 = &g_117;
                uint64_t ****l_5446 = &l_5445;
                int8_t l_5447[3];
                volatile int32_t * volatile *l_5450 = &g_2957;
                volatile union U0 *l_5459 = &g_2158[4];
                volatile union U0 **l_5458 = &l_5459;
                int i;
                for (i = 0; i < 3; i++)
                    l_5447[i] = 0x2FL;
                if (((void*)0 == l_5394[0]))
                { /* block id: 2339 */
                    uint32_t l_5395 = 5UL;
                    const int16_t * const ** const **l_5402 = &l_5399;
                    union U0 *l_5403[4][5][8] = {{{&g_4520,&g_3058[1],&g_560[0],&g_4843[1],(void*)0,(void*)0,&g_3302[4],&g_123},{&g_4028,&g_4843[4],(void*)0,&g_3302[2],&g_4843[1],(void*)0,&g_3302[3],&g_3821},{&g_3302[4],&g_3058[1],(void*)0,&g_4520,&g_1411,&g_4207,&g_560[0],&g_4207},{&g_3821,(void*)0,&g_1411,(void*)0,&g_3821,&g_3069[3],&g_3302[3],&g_560[0]},{&g_3302[3],&g_3302[3],&g_1191,&g_3302[4],&g_4028,&g_3302[2],(void*)0,(void*)0}},{{&g_3418[2],&g_4028,&g_1191,&g_3302[3],(void*)0,&g_560[2],&g_3302[3],(void*)0},{&g_4028,&g_4843[1],&g_1411,&g_560[0],&g_1191,&g_1191,&g_560[0],&g_1411},{(void*)0,(void*)0,(void*)0,&g_3302[3],&g_560[2],(void*)0,&g_3302[3],&g_1191},{(void*)0,(void*)0,(void*)0,(void*)0,&g_3302[2],&g_4028,&g_3302[4],&g_1191},{(void*)0,&g_3058[1],&g_560[0],&g_3302[3],&g_3069[3],&g_3821,(void*)0,&g_1411}},{{&g_4520,&g_1411,&g_4207,&g_560[0],&g_4207,&g_1411,&g_4520,(void*)0},{&g_560[0],&g_4843[1],&g_3821,&g_3302[3],(void*)0,&g_4843[1],&g_3302[2],(void*)0},{&g_560[2],&g_3821,&g_123,&g_3302[4],(void*)0,(void*)0,&g_4843[1],&g_560[0]},{&g_560[0],&g_3302[2],&g_3058[1],(void*)0,&g_4207,&g_3418[2],&g_3418[2],&g_4207},{&g_4520,&g_3302[4],&g_3302[4],&g_4520,&g_3069[3],&g_3302[2],&g_1191,&g_3821}},{{(void*)0,&g_4207,&g_4207,&g_3058[1],&g_4520,&g_3821,(void*)0,&g_3069[3]},{&g_3821,&g_4843[4],&g_4520,&g_1191,&g_4028,&g_3058[1],&g_4843[1],&g_4843[1]},{&g_4843[1],&g_3418[2],&g_4520,&g_3302[3],&g_3302[2],&g_3302[3],&g_4520,&g_3418[2]},{&g_4843[1],&g_3058[1],(void*)0,&g_3302[2],&g_560[2],&g_4843[1],(void*)0,&g_4207},{&g_3302[3],&g_560[0],&g_3058[1],(void*)0,&g_4843[1],&g_1191,(void*)0,&g_4520}}};
                    int i, j, k;
                    --l_5395;
                    l_5402 = l_5398;
                    (*g_5406) = ((**g_3707) = (((*g_969) = p_8) , l_5403[0][0][1]));
                }
                else
                { /* block id: 2345 */
                    uint8_t *l_5425 = &g_3183[1][3][0].f0;
                    int i;
                    l_5431 = ((*g_62) = (safe_sub_func_int8_t_s_s((p_8 < ((safe_add_func_int32_t_s_s((l_5411 != ((safe_add_func_uint32_t_u_u((p_8 & (((l_5334[g_3548.f4] |= (safe_lshift_func_uint8_t_u_s((safe_sub_func_int16_t_s_s(((0xE9928604L == (safe_lshift_func_int64_t_s_s((safe_sub_func_int32_t_s_s((((l_5426 = ((p_8 , l_5425) != l_5425)) , p_8) != (safe_sub_func_uint8_t_u_u(4UL, p_8))), p_8)), (***g_4452)))) <= (-10L)), 0UL)), (**g_4951)))) != 4L) != 0xC7612D6AADB97D10LL)), l_5429)) , &l_5412)), l_5429)) , (***g_4452))), l_5430)));
                    for (l_5426 = 0; (l_5426 <= 2); l_5426 += 1)
                    { /* block id: 2352 */
                        l_5432 = &l_5431;
                    }
                }
                (*l_5450) = (*g_2958);
                (**l_5450) = (((*g_4829) != l_5451[3][5]) || (safe_mod_func_int64_t_s_s((p_8 , ((((*g_1151) = (*g_827)) <= ((((((*g_484) = (l_5456 , (*l_5432))) , l_5457) == &l_5432) ^ p_8) , 0x7DA17DBEBB899E1ELL)) | p_8)), p_8)));
                (*l_5458) = &g_4728[(g_3548.f4 + 1)];
            }
            if (((g_560[(g_3548.f4 + 4)] , ((((*****l_5251) = (*g_3326)) ^ (g_5223 = 0UL)) & (((safe_mod_func_uint64_t_u_u(p_8, 0xEF02BB12C127D6AFLL)) ^ (*g_4952)) | ((safe_mul_func_int32_t_s_s((g_560[(g_3548.f4 + 4)].f3 = ((*g_62) &= (l_5466[0] == (*g_1425)))), ((***g_4452) ^ p_8))) == p_8)))) && p_8))
            { /* block id: 2369 */
                int64_t l_5477 = 0xA606627434E0C387LL;
                uint8_t ** const *l_5481 = &g_5140;
                int32_t l_5482 = 0x698C8280L;
                (*g_62) ^= (safe_lshift_func_int64_t_s_u((p_8 != ((safe_rshift_func_uint32_t_u_u(((((l_5455.f0 == 0L) >= ((safe_lshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((18446744073709551613UL & 0x9E4B8917FC865B9ALL), p_8)), (0xF34B8F835BC5F336LL >= (safe_mod_func_int8_t_s_s((l_5477 | (l_5482 = ((safe_mul_func_int64_t_s_s((l_5480 == l_5481), p_8)) != (**g_4019)))), p_8))))) == 0x9AL)) < l_5483) & l_5477), l_5484)) <= p_8)), 8));
            }
            else
            { /* block id: 2372 */
                int32_t **l_5485 = &g_190;
                union U0 ***l_5490 = &g_2267;
                union U0 ****l_5491[8] = {&l_5490,&l_5490,&l_5490,&l_5490,&l_5490,&l_5490,&l_5490,&l_5490};
                int32_t l_5505 = 0L;
                uint32_t *l_5515 = &l_47;
                uint8_t l_5523 = 255UL;
                union U1 l_5536 = {253UL};
                int i;
                (*l_5485) = l_5449[0][8][1];
                l_5506[0] &= (((safe_add_func_int64_t_s_s((!((l_5489 != (l_5492 = l_5490)) , (+((p_8 && (((**g_4951) &= ((**g_4452) != (l_5494 = (void*)0))) , 0xA250E069E50F7831LL)) && (safe_mod_func_int64_t_s_s(((safe_sub_func_uint64_t_u_u((p_8 , (l_5505 = ((*g_1151) |= (safe_sub_func_uint64_t_u_u((l_5504 = ((****g_4451) >= (l_5503 <= p_8))), (**g_1357)))))), (***g_876))) < p_8), 6UL)))))), 0x0A9F9D44D7EB7D0ELL)) & 0xF792AE8C6DB5792ALL) <= 0x97L);
                (*g_62) = (safe_lshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_u(((*g_4604) |= p_8), ((*g_662) < (safe_mod_func_int16_t_s_s(0x6BF4L, (p_8 || (((((*l_5515) = ((**g_5180)++)) <= 1UL) , (+(safe_mul_func_int64_t_s_s(((safe_sub_func_int64_t_s_s(p_8, (((((p_8 & ((*g_1151) = (safe_mul_func_uint32_t_u_u(((p_8 , 252UL) , l_5523), (*g_62))))) <= 1UL) , p_8) , 65529UL) != 0xF50EL))) < p_8), p_8)))) , p_8))))))), p_8));
                for (g_1329 = 2; (g_1329 >= 0); g_1329 -= 1)
                { /* block id: 2388 */
                    uint32_t l_5524 = 0xF891B487L;
                    int32_t **l_5527 = &g_190;
                    int32_t * const l_5528 = &g_614;
                    int32_t **l_5537[5] = {&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0],&g_1139[0]};
                    int i;
                    for (g_4045 = 0; (g_4045 <= 0); g_4045 += 1)
                    { /* block id: 2391 */
                        l_5524++;
                        return p_8;
                    }
                    (*g_5538) = l_5449[0][8][0];
                    for (g_1788.f4 = 0; (g_1788.f4 <= 6); g_1788.f4 += 1)
                    { /* block id: 2401 */
                        if (p_8)
                            break;
                        if (p_8)
                            break;
                        if (p_8)
                            continue;
                        if (p_8)
                            continue;
                    }
                }
            }
            for (g_55.f0 = 0; (g_55.f0 <= 2); g_55.f0 += 1)
            { /* block id: 2411 */
                int16_t *l_5539 = &g_77;
                int32_t l_5541 = 0x4C72EC67L;
                uint32_t l_5568[9][10][2] = {{{6UL,6UL},{0xA24945F6L,0x8C8C2DE7L},{4294967295UL,0UL},{1UL,1UL},{0xD47B3FB6L,4294967295UL},{4294967290UL,0UL},{0x4E21F009L,0xB5F16551L},{0x1106CDD0L,0x0B6EB6BEL},{0xE70073D2L,0x00CA5135L},{0x731ADFB9L,0x9A4B5B1EL}},{{0UL,4294967294UL},{0x5D5984DAL,0x3C02F268L},{1UL,4294967290UL},{1UL,4294967295UL},{4294967295UL,0xE70073D2L},{0UL,0xDA1EF124L},{0x45A6DC8AL,0x9EB49BFCL},{4294967295UL,0xD47B3FB6L},{6UL,0x77FB36BFL},{4294967295UL,0UL}},{{4UL,4294967294UL},{0x6D31BD12L,0x4E21F009L},{1UL,0xE1EAB4C4L},{0x77FB36BFL,1UL},{0x1ACBE74DL,0xD842F3DFL},{0xED7816EFL,0x6EC33CD1L},{1UL,4294967293UL},{4294967287UL,0x886C75D9L},{0x6EC33CD1L,6UL},{0UL,0x5BD03419L}},{{4294967289UL,4294967295UL},{2UL,1UL},{4294967295UL,4294967287UL},{0xA7B51055L,4294967292UL},{0x56083250L,4294967292UL},{0xA7B51055L,4294967287UL},{4294967295UL,1UL},{2UL,4294967295UL},{4294967289UL,0x5BD03419L},{0UL,6UL}},{{0x6EC33CD1L,0x886C75D9L},{4294967287UL,4294967293UL},{1UL,0x6EC33CD1L},{0xED7816EFL,0xD842F3DFL},{0x1ACBE74DL,1UL},{0x77FB36BFL,0xE1EAB4C4L},{1UL,0x4E21F009L},{0x6D31BD12L,4294967294UL},{4UL,0UL},{4294967295UL,0x77FB36BFL}},{{6UL,0xD47B3FB6L},{4294967295UL,0x9EB49BFCL},{0x45A6DC8AL,0xDA1EF124L},{0UL,0xE70073D2L},{4294967295UL,4294967295UL},{1UL,4294967290UL},{1UL,0x3C02F268L},{0x5D5984DAL,4294967294UL},{0UL,0x9A4B5B1EL},{0x731ADFB9L,0x00CA5135L}},{{0xE70073D2L,0x0B6EB6BEL},{0x1106CDD0L,0xB5F16551L},{0x4E21F009L,0UL},{4294967290UL,4294967295UL},{0xD47B3FB6L,1UL},{1UL,0UL},{4294967295UL,0x8C8C2DE7L},{0xA24945F6L,6UL},{6UL,0x45A6DC8AL},{4294967294UL,0xDD0E5C4DL}},{{4294967290UL,4294967290UL},{0xA7B51055L,0x0B6EB6BEL},{0x0983F3A7L,0UL},{0xD47B3FB6L,0UL},{0x9A4B5B1EL,0xD47B3FB6L},{1UL,1UL},{1UL,0xD47B3FB6L},{0x9A4B5B1EL,0UL},{0xD47B3FB6L,0UL},{0x0983F3A7L,0x0B6EB6BEL}},{{0xA7B51055L,4294967290UL},{4294967290UL,0xDD0E5C4DL},{0xE50613C1L,0x85E8C0E2L},{0x4E21F009L,0xABF41F95L},{1UL,0x5BD03419L},{0x1DC33718L,0x6D31BD12L},{0UL,0x8C8C2DE7L},{4UL,4294967292UL},{0xD842F3DFL,0x572423B7L},{0x9BE2F481L,4294967289UL}}};
                union U1 *l_5572 = &g_308[0][2];
                int i, j, k;
                (*g_62) = (l_5539 == (((((***g_5179) = ((safe_unary_minus_func_int8_t_s(l_5541)) > p_8)) >= (p_8 < (**g_4453))) & (safe_rshift_func_uint64_t_u_s(0UL, 35))) , (*l_5401)));
                for (l_5456.f0 = 0; (l_5456.f0 <= 2); l_5456.f0 += 1)
                { /* block id: 2416 */
                    int32_t **l_5560 = &g_190;
                    int i, j;
                    (*g_62) = 2L;
                    if (p_8)
                        break;
                    for (l_5332 = 0; (l_5332 <= 6); l_5332 += 1)
                    { /* block id: 2421 */
                        int32_t *l_5544[7][2][1] = {{{&g_1578},{&g_614}},{{&g_1578},{&g_614}},{{&g_1578},{&g_614}},{{&g_1578},{&g_614}},{{&g_1578},{&g_614}},{{&g_1578},{&g_614}},{{&g_1578},{&g_614}}};
                        int i, j, k;
                        l_5544[5][1][0] = &l_5541;
                    }
                    for (g_4095 = 2; (g_4095 <= 6); g_4095 += 1)
                    { /* block id: 2426 */
                        const uint16_t l_5557 = 0x2B14L;
                        int32_t l_5569[7][4][8] = {{{0xF2BA0942L,(-1L),3L,0x9C9ABCBEL,0x9C9ABCBEL,3L,(-1L),0xF2BA0942L},{3L,0x08CD306CL,0x4E85A307L,(-3L),7L,(-1L),0x8AD32D70L,0xD6172537L},{(-2L),0x41924DF6L,0L,0L,(-3L),(-1L),0L,1L},{0L,0x08CD306CL,(-7L),0xAB552BDDL,0x4F7B5798L,3L,0xD658952DL,(-5L)}},{{1L,(-1L),1L,(-10L),3L,0xB76D1776L,0x5E3123F4L,0xECCBBE68L},{0x302E6F36L,0x5E3123F4L,(-3L),0L,0L,0xAB8D3CE6L,0xE3BD32D1L,0xB76D1776L},{0x41924DF6L,(-3L),0xD6172537L,0xCCD57574L,0xD6172537L,(-3L),0x41924DF6L,0L},{(-10L),0L,0x5E3123F4L,(-1L),0x1628D78DL,0L,8L,0L}},{{(-1L),0L,(-2L),(-7L),0x1628D78DL,(-5L),1L,0xCCD57574L},{(-10L),0xB76D1776L,0xCCD57574L,0L,0xD6172537L,0x302E6F36L,0L,0x08CD306CL},{0x41924DF6L,0xAB552BDDL,0xDC30F529L,0xF2BA0942L,0L,0L,0x4F7B5798L,1L},{0x302E6F36L,0L,0xECCBBE68L,0x4E85A307L,3L,0L,0L,0L}},{{1L,0x4F7B5798L,0xFC32F230L,0xFC32F230L,0x4F7B5798L,1L,0L,0x1628D78DL},{0L,0xE3BD32D1L,0L,0x08CD306CL,(-3L),0L,0xAB8D3CE6L,(-2L)},{(-2L),0xFC32F230L,(-1L),0x08CD306CL,7L,0xBE2FC16BL,(-10L),0x1628D78DL},{3L,7L,0x8AD32D70L,0xFC32F230L,0x9C9ABCBEL,0xDC30F529L,0xD6172537L,0L}},{{0xF2BA0942L,0xAB8D3CE6L,0x4F7B5798L,0x4E85A307L,0xBE2FC16BL,0L,7L,1L},{8L,1L,0L,0x302E6F36L,0L,0xD658952DL,0L,0xD658952DL},{1L,0xF2BA0942L,0xD6172537L,0xF2BA0942L,1L,0L,1L,0xB76D1776L},{0L,1L,0x1628D78DL,1L,(-3L),1L,0xBE2FC16BL,0xF2BA0942L}},{{(-5L),0L,0x1628D78DL,0xD6172537L,0xD658952DL,0x08CD306CL,1L,0L},{(-3L),(-1L),0xD6172537L,0xB76D1776L,0xECCBBE68L,0L,0L,1L},{(-1L),(-3L),0L,0L,0x41924DF6L,(-2L),0xFE152070L,0xBE2FC16BL},{0L,0xCCD57574L,3L,0L,0x519293C2L,0xE3BD32D1L,0xE3BD32D1L,0x519293C2L}},{{0x5E3123F4L,0x4F7B5798L,0x4F7B5798L,0x5E3123F4L,0L,(-1L),0L,(-1L)},{0x9C9ABCBEL,(-1L),(-3L),(-7L),0xB76D1776L,1L,0x41924DF6L,0xE3BD32D1L},{0x519293C2L,(-1L),7L,0xAB8D3CE6L,(-5L),(-1L),0xF2BA0942L,0x302E6F36L},{0xFE152070L,0x4F7B5798L,0x9C9ABCBEL,0L,1L,0xE3BD32D1L,7L,(-2L)}}};
                        int i, j, k;
                        l_5569[1][1][5] = (safe_add_func_int32_t_s_s((safe_lshift_func_uint8_t_u_s((((safe_add_func_uint8_t_u_u((safe_mod_func_int64_t_s_s((((safe_unary_minus_func_uint64_t_u((safe_add_func_int64_t_s_s((l_5556 | ((g_5559 = (l_5557 , l_5558)) == (g_5561 = l_5560))), ((safe_rshift_func_int32_t_s_s(((*g_62) &= ((safe_div_func_int32_t_s_s((safe_mod_func_uint16_t_u_u(p_8, 0xCA4FL)), p_8)) ^ (1UL && p_8))), (**g_2958))) | p_8))))) != p_8) ^ p_8), 0x99354117804A507ALL)), p_8)) > p_8) < p_8), 7)), l_5568[0][7][1]));
                    }
                }
                for (g_321 = 0; (g_321 <= 0); g_321 += 1)
                { /* block id: 2435 */
                    for (g_1935 = 0; (g_1935 <= 2); g_1935 += 1)
                    { /* block id: 2438 */
                        int i;
                        (*g_5561) = &l_5541;
                        return g_1658[g_321];
                    }
                    for (g_4905 = 0; (g_4905 <= 6); g_4905 += 1)
                    { /* block id: 2444 */
                        uint16_t l_5570 = 0x35FFL;
                        union U1 **l_5571 = &g_181;
                        (*g_62) = l_5570;
                        g_560[(g_3548.f4 + 4)].f0 = p_8;
                        (*l_5571) = (*g_2584);
                    }
                    l_5572 = &l_5455;
                }
            }
            for (l_5556 = 0; (l_5556 <= 2); l_5556 += 1)
            { /* block id: 2454 */
                uint16_t l_5574 = 7UL;
                l_5574++;
            }
        }
        for (g_63 = 0; g_63 < 3; g_63 += 1)
        {
            for (g_368 = 0; g_368 < 10; g_368 += 1)
            {
                for (g_4462.f1 = 0; g_4462.f1 < 8; g_4462.f1 += 1)
                {
                    g_4949[g_63][g_368][g_4462.f1] = (void*)0;
                }
            }
        }
        for (g_846 = 0; (g_846 == (-19)); g_846 = safe_sub_func_uint64_t_u_u(g_846, 7))
        { /* block id: 2461 */
            int16_t l_5579 = 0x06C3L;
            l_5579 ^= p_8;
            (*g_62) |= p_8;
        }
    }
    for (g_3212 = 2; (g_3212 >= 0); g_3212 -= 1)
    { /* block id: 2468 */
        int32_t l_5612 = 1L;
        int16_t l_5615 = 6L;
        int32_t l_5616 = (-1L);
        union U1 l_5627 = {0x1AL};
        int i;
        if (g_733[g_3212])
        { /* block id: 2469 */
            if (g_733[g_3212])
                break;
        }
        else
        { /* block id: 2471 */
            uint16_t l_5604 = 4UL;
            int32_t l_5606 = (-1L);
            int32_t l_5610 = (-1L);
            int32_t l_5611 = 0xE5F329C1L;
            uint32_t ****l_5620 = &g_4776;
            if (g_733[g_3212])
                break;
            for (g_113.f4 = 1; (g_113.f4 >= 0); g_113.f4 -= 1)
            { /* block id: 2475 */
                uint32_t *l_5598 = &l_47;
                uint32_t l_5603[5][2] = {{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL}};
                int32_t l_5608 = 0x8714ED0CL;
                int32_t l_5613[10][2][1] = {{{0xCC107171L},{(-9L)}},{{5L},{(-9L)}},{{0xCC107171L},{0L}},{{0xCC107171L},{(-9L)}},{{5L},{(-9L)}},{{0xCC107171L},{0L}},{{0xCC107171L},{(-9L)}},{{5L},{(-9L)}},{{0xCC107171L},{0L}},{{0xCC107171L},{(-9L)}}};
                int i, j, k;
                for (g_5190 = 0; (g_5190 <= 0); g_5190 += 1)
                { /* block id: 2478 */
                    int32_t * const l_5600 = &l_5167;
                    int32_t l_5605 = 0xBFF7E2D3L;
                    int32_t l_5609[10][9] = {{0L,0x0CCF5288L,0x0CCF5288L,0L,0L,0L,0x0CCF5288L,0x0CCF5288L,0L},{(-10L),0x0CCF5288L,0xD09C3FC2L,0x0CCF5288L,(-10L),(-10L),0x0CCF5288L,0xD09C3FC2L,0x0CCF5288L},{0x0CCF5288L,0L,0xD09C3FC2L,0xD09C3FC2L,0L,0x0CCF5288L,0L,0xD09C3FC2L,0xD09C3FC2L},{(-10L),(-10L),0x0CCF5288L,0xD09C3FC2L,0x0CCF5288L,(-10L),(-10L),0x0CCF5288L,0xD09C3FC2L},{0L,0L,0L,0x0CCF5288L,0x0CCF5288L,0L,0L,0L,0x0CCF5288L},{0L,0x0CCF5288L,0x0CCF5288L,0L,0L,0L,0x0CCF5288L,0x0CCF5288L,0L},{(-10L),0x0CCF5288L,0xD09C3FC2L,0x0CCF5288L,(-10L),(-10L),0x0CCF5288L,0xD09C3FC2L,0x0CCF5288L},{0x0CCF5288L,0L,0xD09C3FC2L,0xD09C3FC2L,0L,0x0CCF5288L,0L,0xD09C3FC2L,0xD09C3FC2L},{0x0CCF5288L,0x0CCF5288L,0L,0L,0L,0x0CCF5288L,0x0CCF5288L,0L,0L},{0xD09C3FC2L,(-10L),0xD09C3FC2L,0L,0L,0xD09C3FC2L,(-10L),0xD09C3FC2L,0L}};
                    int i, j;
                    for (g_4906 = 0; (g_4906 <= 0); g_4906 += 1)
                    { /* block id: 2481 */
                        uint16_t * const ****l_5582 = (void*)0;
                        int32_t * const l_5599 = &l_5167;
                        const uint32_t *l_5602 = (void*)0;
                        const uint32_t **l_5601 = &l_5602;
                        int i, j, k;
                        (*l_5600) = (safe_rshift_func_uint64_t_u_s((l_5582 == (void*)0), (((safe_lshift_func_uint64_t_u_s((~0x7DEA5EADL), ((safe_lshift_func_uint32_t_u_s(((void*)0 != l_5135), 14)) != (((safe_mod_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(((****g_2582) , 0x75C4L), (***g_3324))) ^ (**g_4019)), (**g_3325))), p_8)) < 255UL) , p_8)))) <= p_8) || 0x9FA5C07B009C0237LL)));
                    }
                    if (l_5604)
                    { /* block id: 2485 */
                        int32_t l_5607 = 0x2C6E4DFCL;
                        int32_t l_5614 = (-2L);
                        int i, j, k;
                        ++l_5617;
                        (*g_4774) = l_5620;
                        ++g_5621;
                    }
                    else
                    { /* block id: 2489 */
                        uint16_t l_5624 = 0xD9EEL;
                        ++l_5624;
                    }
                    (*g_5561) = (l_5627 , &l_5610);
                }
                for (g_682.f4 = 0; (g_682.f4 <= 0); g_682.f4 += 1)
                { /* block id: 2496 */
                    for (g_4724.f4 = 3; (g_4724.f4 >= 0); g_4724.f4 -= 1)
                    { /* block id: 2499 */
                        int i, j;
                        return l_5603[g_682.f4][g_113.f4];
                    }
                }
            }
            l_5612 |= (-1L);
        }
        return (****g_5178);
    }
    for (g_4028.f4 = 2; (g_4028.f4 >= 0); g_4028.f4 -= 1)
    { /* block id: 2510 */
        int16_t l_5677[10][10][2] = {{{(-1L),(-1L)},{0xE2F4L,0L},{0x0506L,0L},{0xC182L,0x08D4L},{(-8L),0xC182L},{1L,(-4L)},{1L,0xC182L},{(-8L),0x08D4L},{0xC182L,0L},{0x0506L,0L}},{{0xE2F4L,(-1L)},{(-1L),0xB586L},{0L,(-4L)},{(-1L),0xE2F4L},{0x2BB6L,0x6310L},{0xB586L,(-1L)},{0x0506L,(-2L)},{(-4L),(-8L)},{0x08D4L,1L},{0x6F8AL,(-4L)}},{{0L,(-4L)},{0x8F3DL,0xC512L},{1L,1L},{0x0506L,0x6F8AL},{0x3137L,0x2BB6L},{0x6310L,1L},{(-2L),(-4L)},{0L,0x3137L},{0xC512L,0x8F3DL},{1L,0L}},{{0x0506L,0L},{1L,0x8F3DL},{0xC512L,0x3137L},{0L,(-4L)},{(-2L),1L},{0x6310L,0x2BB6L},{0x3137L,0x6F8AL},{0x0506L,1L},{1L,0xC512L},{0x8F3DL,(-4L)}},{{0L,(-4L)},{0x6F8AL,1L},{0x08D4L,(-8L)},{(-4L),(-2L)},{0x0506L,(-1L)},{0xB586L,0x6310L},{0x2BB6L,0xE2F4L},{(-1L),(-4L)},{0L,0xB586L},{(-1L),(-1L)}},{{0xE2F4L,0L},{0x0506L,0L},{0xC182L,0x08D4L},{(-8L),0xC182L},{1L,(-4L)},{1L,0xC182L},{(-8L),0x08D4L},{0xC182L,0L},{0x0506L,0L},{0xE2F4L,(-1L)}},{{(-1L),0xB586L},{0L,(-4L)},{(-1L),0xE2F4L},{0x2BB6L,0x6310L},{0xB586L,(-1L)},{0x0506L,(-2L)},{(-4L),(-8L)},{0x08D4L,1L},{0x6F8AL,(-4L)},{0L,(-4L)}},{{0x8F3DL,0xC512L},{1L,1L},{0x0506L,0x6F8AL},{0x3137L,0x2BB6L},{0x6310L,1L},{(-2L),(-4L)},{0L,0x3137L},{0xC512L,0x8F3DL},{1L,0L},{0x0506L,0L}},{{1L,0x8F3DL},{0xC512L,0x3137L},{0L,(-4L)},{(-2L),1L},{0x6310L,0x2BB6L},{0x3137L,0x6F8AL},{0x0506L,1L},{(-4L),0x67F7L},{0xFC20L,0x0506L},{0xB586L,0xD6F3L}},{{1L,(-4L)},{(-1L),0x9C22L},{0x0506L,0xC182L},{0x87C4L,(-4L)},{0xD4C4L,0x8CFFL},{0xF2A4L,0x3C09L},{(-4L),0xD6F3L},{0xE2F4L,0xD4C4L},{4L,4L},{0x3C09L,0x3137L}}};
        int32_t l_5679 = 0xB13B4343L;
        int32_t l_5684 = 0x63D7D22AL;
        int32_t l_5685 = 0x85BEFD36L;
        int32_t l_5686 = (-1L);
        int32_t l_5687 = 0x43E6A8A7L;
        int32_t l_5689 = (-3L);
        int32_t l_5690 = (-1L);
        int32_t l_5691 = (-3L);
        int32_t l_5692 = 0L;
        int32_t l_5693[6][9][4] = {{{0x4591BFDAL,0xC2675B35L,(-7L),0x4591BFDAL},{0x201B8232L,0xDC0844A5L,0L,7L},{0L,0x9EE26711L,0x1829E86EL,0L},{(-8L),6L,(-1L),0L},{(-2L),(-1L),5L,7L},{(-1L),0x3195E766L,0x02014533L,0x9EE26711L},{6L,0xC2675B35L,(-9L),0x68C76116L},{4L,0x5FBD6E58L,0L,8L},{(-1L),7L,(-1L),7L}},{{1L,0L,(-2L),0xDC0844A5L},{5L,0x57E88F9FL,0L,(-1L)},{0x9EE26711L,0x4668F994L,(-4L),(-1L)},{0x9EE26711L,1L,0L,(-10L)},{5L,(-1L),(-2L),0xA3A0B4ADL},{1L,0x35381D8FL,(-1L),0L},{(-1L),(-9L),0L,(-2L)},{4L,(-1L),(-9L),0x76FE595DL},{6L,(-1L),0x02014533L,1L}},{{(-1L),(-2L),5L,0xDC0844A5L},{(-2L),7L,(-1L),(-1L)},{(-8L),0L,0x1829E86EL,0x3195E766L},{0L,(-2L),0L,(-8L)},{0x201B8232L,6L,(-7L),0x76FE595DL},{0x4591BFDAL,0x3195E766L,0xD6247AC4L,(-10L)},{(-8L),(-9L),0x9D7AEEE8L,0L},{0x63B099A7L,(-8L),0L,0xA3A0B4ADL},{(-1L),0x4591BFDAL,(-6L),(-9L)}},{{(-1L),1L,0x201B8232L,0x4591BFDAL},{(-7L),(-1L),0x76FE595DL,(-1L)},{0L,0x5FBD6E58L,(-6L),0x3195E766L},{0xAFFBFE2EL,0L,(-1L),0L},{0x63B099A7L,(-8L),(-2L),8L},{7L,0xD3BCD996L,0xD6247AC4L,(-8L)},{(-1L),0xC2675B35L,0xC2675B35L,(-1L)},{0x201B8232L,(-1L),0xA10FED21L,7L},{(-8L),0x4591BFDAL,0x1829E86EL,0L}},{{1L,6L,0x63B099A7L,0L},{(-2L),0x4591BFDAL,(-1L),7L},{0L,(-1L),0x02014533L,(-1L)},{0x4668F994L,0xC2675B35L,0x76FE595DL,(-8L)},{4L,0xD3BCD996L,5L,(-8L)},{0L,6L,(-1L),0x0854DBE2L},{1L,0x7F47BB8DL,0xD6247AC4L,(-9L)},{0xE1223526L,(-2L),(-1L),1L},{0xC2675B35L,0xA3A0B4ADL,0L,(-9L)}},{{(-9L),0x02014533L,0x0F1C435DL,(-1L)},{0xE1223526L,(-9L),1L,(-10L)},{0xF7DC1B7AL,0L,(-1L),0L},{4L,(-4L),0L,(-1L)},{0x0F1C435DL,(-9L),1L,0x4CC74064L},{0xA3A0B4ADL,0L,0x4668F994L,0xF7DC1B7AL},{0L,0x1829E86EL,0x7F47BB8DL,(-9L)},{(-8L),0x0854DBE2L,0x43400450L,0L},{1L,0xDFE43F42L,0L,0x76FE595DL}}};
        int32_t *l_5754[5][7][7] = {{{&l_5686,&l_5691,(void*)0,&l_5679,&l_5687,&l_5692,&l_5693[3][8][2]},{(void*)0,&l_5693[5][4][1],(void*)0,&g_797,&g_117,&g_797,&l_5679},{&l_5693[2][6][3],&l_5684,(void*)0,(void*)0,&g_797,&l_5692,&g_1578},{&g_1578,&l_5692,(void*)0,&l_5679,&g_797,&l_5691,&l_5684},{&g_1578,&l_5204[4],&g_362,&g_797,&l_5679,&g_614,&g_797},{(void*)0,&l_5204[4],&g_797,(void*)0,&g_614,(void*)0,(void*)0},{&g_117,&l_5692,&l_5692,&l_5692,&g_117,(void*)0,&g_1578}},{{&l_5692,&l_5684,&l_5693[5][4][1],&l_5691,&l_5679,&l_5685,(void*)0},{&l_5692,&l_5693[5][4][1],&g_4555,&l_5679,(void*)0,&g_614,(void*)0},{&l_5692,&l_5691,&l_5679,&l_5692,&g_797,&l_5686,&g_614},{&g_117,&l_5679,(void*)0,&g_797,(void*)0,(void*)0,(void*)0},{(void*)0,&l_5685,&g_614,&l_5686,(void*)0,&l_5692,(void*)0},{&g_1578,(void*)0,(void*)0,&g_614,(void*)0,(void*)0,&g_614},{&g_1578,&g_4555,&g_1578,&g_614,&l_5686,&l_5693[5][4][0],(void*)0}},{{&l_5693[2][6][3],&l_5692,&g_117,&g_1578,&g_1578,&l_5679,(void*)0},{(void*)0,&g_362,&l_5691,&l_5692,&l_5691,&l_5693[5][4][0],&g_1578},{&l_5686,&l_5687,&l_5693[3][8][2],&l_5693[2][6][3],&g_362,(void*)0,(void*)0},{&l_5685,&l_5692,(void*)0,&g_63,&g_1578,&l_5692,&g_797},{&l_5679,&l_5693[5][4][0],&l_5679,&g_797,&g_1578,(void*)0,&l_5684},{&g_63,&g_1578,&l_5686,&g_362,&g_362,(void*)0,&l_5692},{&l_5679,&l_5691,&l_5686,&g_797,&g_614,&l_5679,&g_797}},{{&l_5679,&g_362,&g_1578,&l_5687,&g_117,&g_797,&g_797},{&l_5685,(void*)0,&l_5691,&g_797,&l_5693[3][8][2],&g_797,&g_1578},{&g_1578,&g_797,&g_362,&l_5685,(void*)0,&l_5684,&l_5687},{&l_5692,&l_5679,&g_1578,&l_5204[4],&l_5685,&g_4555,&g_1578},{&l_5686,(void*)0,&g_1578,&l_5679,&l_5692,&g_614,&g_614},{&g_1578,&l_5686,&g_362,&g_362,&l_5686,&g_1578,&g_63},{&l_5693[5][4][1],&l_5692,&l_5691,(void*)0,&g_797,&l_5204[4],&l_5693[3][8][2]}},{{&g_117,&g_1578,&g_1578,&l_5679,(void*)0,(void*)0,&l_5204[4]},{&g_614,&l_5692,&l_5686,&l_5679,&l_5691,(void*)0,&g_797},{&l_5693[5][4][0],&l_5686,(void*)0,&g_4555,&l_5679,&l_5679,(void*)0},{&g_797,(void*)0,(void*)0,(void*)0,&l_5686,&g_1578,&l_5691},{&g_797,&l_5679,(void*)0,&l_5686,&l_5692,&g_1578,&l_5692},{&l_5693[5][4][0],&g_797,&g_797,&l_5693[5][4][0],&g_614,&g_117,&l_5693[5][4][1]},{&g_614,(void*)0,(void*)0,&g_797,&l_5679,&l_5692,&g_362}}};
        int16_t l_5765 = 0x638FL;
        uint32_t **l_5822[7] = {&g_1998,&g_1998,&g_1998,&g_1998,&g_1998,&g_1998,&g_1998};
        int i, j, k;
        for (g_822.f4 = 7; (g_822.f4 >= 0); g_822.f4 -= 1)
        { /* block id: 2513 */
            int16_t ****l_5640[5][7][7] = {{{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,(void*)0,&g_1424,&g_1424,&g_1424,(void*)0,&g_1424},{(void*)0,(void*)0,&g_1424,&g_1424,&g_1424,(void*)0,&g_1424},{(void*)0,&g_1424,(void*)0,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424,(void*)0},{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,(void*)0},{(void*)0,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424,&g_1424}},{{&g_1424,&g_1424,(void*)0,(void*)0,&g_1424,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,(void*)0,&g_1424},{&g_1424,(void*)0,&g_1424,&g_1424,(void*)0,(void*)0,&g_1424},{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,(void*)0,&g_1424},{(void*)0,(void*)0,&g_1424,(void*)0,&g_1424,&g_1424,(void*)0},{&g_1424,(void*)0,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424}},{{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424},{(void*)0,&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,(void*)0,&g_1424,&g_1424,&g_1424,&g_1424,(void*)0},{&g_1424,(void*)0,(void*)0,&g_1424,&g_1424,&g_1424,&g_1424}},{{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,(void*)0,(void*)0},{(void*)0,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,(void*)0,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,(void*)0,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424},{&g_1424,(void*)0,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,(void*)0,&g_1424,(void*)0,&g_1424,(void*)0,&g_1424}},{{&g_1424,(void*)0,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424},{(void*)0,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,(void*)0,(void*)0,&g_1424,&g_1424},{(void*)0,&g_1424,&g_1424,(void*)0,&g_1424,(void*)0,&g_1424},{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,(void*)0},{&g_1424,&g_1424,&g_1424,(void*)0,&g_1424,&g_1424,&g_1424},{&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424,&g_1424}}};
            int16_t *****l_5639 = &l_5640[4][4][2];
            int32_t *l_5644 = &g_614;
            union U1 l_5654 = {0UL};
            int16_t l_5681 = 0L;
            int32_t l_5682 = (-1L);
            int32_t l_5683 = 0xE098DC9BL;
            int32_t l_5688 = (-1L);
            int32_t l_5695 = 0x7523B77CL;
            int32_t l_5696 = 1L;
            int32_t l_5697 = 0xF205B0E3L;
            int32_t l_5698 = 0xF2FFA4DAL;
            int32_t l_5699 = 0xB4392BFDL;
            int32_t l_5700 = 0x0D307CEEL;
            int32_t l_5701 = (-6L);
            int32_t l_5702 = 0x1A1ADAB5L;
            int32_t l_5703 = 0xF1EF8754L;
            int32_t l_5704 = 0L;
            int8_t ****l_5714 = &g_1059;
            int64_t *l_5751 = &g_846;
            const uint16_t ****l_5755[1];
            uint64_t **l_5757[4][5][3] = {{{(void*)0,&g_1151,&l_5275[4]},{(void*)0,&l_5275[1],(void*)0},{&g_1151,&l_5275[0],&g_1151},{&l_5275[0],(void*)0,(void*)0},{&g_1151,&l_5275[0],&l_5275[4]}},{{&l_5275[0],&l_5275[0],&l_5275[0]},{&g_1151,&l_5275[0],&l_5275[0]},{&l_5275[0],&l_5275[4],&l_5275[0]},{&l_5275[0],&l_5275[3],&l_5275[0]},{&l_5275[0],(void*)0,&l_5275[0]}},{{&g_1151,&g_1151,&l_5275[0]},{&l_5275[0],&l_5275[0],&l_5275[0]},{&l_5275[4],&l_5275[0],&g_1151},{&l_5275[0],&l_5275[0],&l_5275[1]},{&g_1151,&l_5275[0],&l_5275[0]}},{{&l_5275[0],&l_5275[0],&l_5275[0]},{&l_5275[0],&l_5275[0],(void*)0},{(void*)0,&l_5275[0],&l_5275[0]},{(void*)0,&g_1151,&l_5275[0]},{&l_5275[4],(void*)0,&l_5275[1]}}};
            uint32_t l_5785 = 1UL;
            uint32_t l_5815 = 1UL;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_5755[i] = &g_3324;
            for (l_5169 = 0; (l_5169 <= 2); l_5169 += 1)
            { /* block id: 2516 */
                int i;
                return g_1937[g_4028.f4];
            }
            for (g_596 = 2; (g_596 >= 0); g_596 -= 1)
            { /* block id: 2521 */
                int8_t ***l_5643 = &g_4603[1][3];
                int32_t l_5645[6][2] = {{1L,1L},{0x90AEF378L,1L},{1L,0x90AEF378L},{1L,1L},{0x90AEF378L,1L},{1L,0x90AEF378L}};
                uint32_t l_5705[1][9] = {{4294967295UL,4294967295UL,0xB409DE49L,4294967295UL,4294967295UL,0xB409DE49L,4294967295UL,4294967295UL,0xB409DE49L}};
                int8_t *****l_5712[1];
                union U1 ***l_5719 = &l_5718;
                union U1 ***l_5721 = &l_5720;
                uint8_t *l_5723 = &l_5654.f0;
                const int32_t l_5753[2] = {(-1L),(-1L)};
                uint8_t l_5758 = 255UL;
                int8_t l_5795 = (-9L);
                int64_t **l_5816[4] = {&g_1358,&g_1358,&g_1358,&g_1358};
                int i, j;
                for (i = 0; i < 1; i++)
                    l_5712[i] = (void*)0;
                if ((safe_div_func_uint16_t_u_u(((((safe_mul_func_uint64_t_u_u(((((g_662 = &g_3286) != ((**g_3324) = (**g_3324))) , (safe_sub_func_int16_t_s_s((&g_875 == l_5634), g_1937[g_4028.f4]))) & (((safe_lshift_func_int64_t_s_s((1UL >= ((-1L) ^ (((void*)0 == l_5639) != 0x58F65898L))), g_5641)) | p_8) == 0xF4E23D0DL)), p_8)) | g_5642) , l_5643) != (void*)0), g_1937[g_4028.f4])))
                { /* block id: 2524 */
                    (*g_5561) = l_5644;
                    return p_8;
                }
                else
                { /* block id: 2527 */
                    for (g_4632 = 3; (g_4632 >= 0); g_4632 -= 1)
                    { /* block id: 2530 */
                        int32_t l_5675 = (-5L);
                        int32_t l_5678[9] = {0x857D5C6DL,0x857D5C6DL,0x857D5C6DL,0x857D5C6DL,0x857D5C6DL,0x857D5C6DL,0x857D5C6DL,0x857D5C6DL,0x857D5C6DL};
                        int32_t l_5680 = (-4L);
                        int i, j;
                        l_5645[4][1] = (p_8 <= p_8);
                        l_5680 &= (safe_lshift_func_int8_t_s_u((safe_div_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((((++(**g_4019)) != p_8) && (l_5654 , ((*g_4952) = (p_8 & g_1937[g_4028.f4])))) < (0x06L == (+p_8))), (l_5678[5] &= (safe_mod_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s((safe_sub_func_int64_t_s_s((+(safe_mod_func_uint8_t_u_u(((((l_5677[8][0][1] |= (((***g_5179) | ((!(((g_1937[g_4028.f4] < (((safe_lshift_func_int8_t_s_s((+(((safe_add_func_int32_t_s_s((safe_sub_func_int8_t_s_s((safe_sub_func_uint16_t_u_u(l_5675, g_5676)), l_5675)), 0x2A8440A0L)) <= p_8) || 0xE742L)), (*g_4604))) | p_8) && p_8)) , 0UL) || 1UL)) == p_8)) == p_8)) != p_8) ^ (-1L)) && (*l_5644)), p_8))), (-1L))), 2)), (**g_1357)))))), l_5679)), 3));
                    }
                }
                ++l_5705[0][4];
                if (((*l_5644) != (safe_add_func_int8_t_s_s(((***g_4950) = ((safe_sub_func_uint32_t_u_u(p_8, ((g_5713 = (void*)0) == (g_5715 = l_5714)))) == ((*g_4604) = ((safe_add_func_int8_t_s_s(((((*l_5719) = l_5718) != ((*l_5721) = l_5720)) , 0xC9L), ((****g_4451) > ((+((*l_5723) = l_5645[3][1])) , l_5685)))) ^ 0xFDL)))), l_5724))))
                { /* block id: 2547 */
                    uint16_t l_5752 = 1UL;
                    const uint16_t *****l_5756 = &l_5755[0];
                    for (g_4121 = 2; (g_4121 >= 0); g_4121 -= 1)
                    { /* block id: 2550 */
                        (*l_5644) = (safe_mod_func_uint32_t_u_u(((safe_lshift_func_int8_t_s_u((((safe_div_func_int32_t_s_s(((((*g_1151) = ((*g_4774) != (*g_5177))) < (***g_4452)) && ((((safe_div_func_int32_t_s_s(((safe_sub_func_uint64_t_u_u(l_5645[4][1], ((p_8 > ((safe_sub_func_uint32_t_u_u(((l_5645[0][0] & (((((*l_5644) != ((**g_4951) = (safe_mod_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(((safe_div_func_int32_t_s_s((safe_rshift_func_uint32_t_u_s((4294967291UL > ((l_5751 = ((((*g_62) = (safe_lshift_func_int8_t_s_s((((safe_rshift_func_int16_t_s_s(0xBFAFL, p_8)) < 0UL) , p_8), (*g_732)))) & p_8) , (void*)0)) == (*g_4453))), l_5752)), 1UL)) == 0UL), 0xC46954F8BF185361LL)), p_8)))) , l_5753[0]) , 255UL) != p_8)) <= (-5L)), (-2L))) <= 1L)) | l_5753[0]))) && l_5753[0]), p_8)) , p_8) < 0x16F1C597L) ^ l_5685)), l_5752)) >= 0x20F3AAA7L) || l_5753[0]), 3)) == (**g_3325)), p_8));
                        l_5754[2][4][5] = ((*g_3255) = &l_5698);
                    }
                    (*l_5756) = l_5755[0];
                    return p_8;
                }
                else
                { /* block id: 2561 */
                    uint64_t l_5762 = 18446744073709551613UL;
                    uint8_t *l_5790[5][10] = {{(void*)0,(void*)0,(void*)0,&g_571,(void*)0,(void*)0,(void*)0,&g_571,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_2586.f0,&g_2586.f0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_2586.f0,(void*)0,&g_2586.f0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_571,(void*)0,(void*)0,(void*)0,(void*)0,&g_571,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_2586.f0,(void*)0,&g_2586.f0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                    int32_t l_5799 = (-1L);
                    int32_t l_5812[3][7][1] = {{{(-10L)},{0L},{0L},{(-10L)},{0L},{0L},{(-10L)}},{{0L},{0L},{(-10L)},{0L},{0L},{(-10L)},{0L}},{{0L},{(-10L)},{0L},{0L},{(-10L)},{0L},{0L}}};
                    int16_t **l_5820[3];
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_5820[i] = &g_969;
                    (*l_5644) = (((l_5757[0][3][2] == (void*)0) && (((l_5758 & (l_5753[1] | (safe_div_func_uint16_t_u_u(((safe_unary_minus_func_uint16_t_u(l_5762)) >= (safe_mul_func_uint32_t_u_u((**g_1997), l_5765))), ((g_596 , 0xBF58FA3591D00F97LL) || 0x65A099AA222AD956LL))))) != l_5762) >= 251UL)) <= 1L);
                    if ((safe_mul_func_int32_t_s_s(((safe_add_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u(((((((safe_div_func_int8_t_s_s(((*g_4952) ^= (p_8 , p_8)), (safe_lshift_func_uint8_t_u_s(0xBFL, 6)))) > 0x56L) != 18446744073709551615UL) <= (p_8 != p_8)) , (&p_8 == (void*)0)) , (*****g_5177)), (*g_62))) <= p_8), (*l_5644))) , (*l_5644)), l_5762)))
                    { /* block id: 2564 */
                        int32_t *****l_5782 = &g_3832;
                        int32_t l_5783[6];
                        uint8_t **l_5791[3];
                        int i;
                        for (i = 0; i < 6; i++)
                            l_5783[i] = 0x711A5458L;
                        for (i = 0; i < 3; i++)
                            l_5791[i] = &l_5790[0][6];
                        (*g_62) = ((((p_8 , ((((safe_div_func_int16_t_s_s((-9L), l_5762)) == ((p_8 ^ (l_5762 > (safe_lshift_func_int16_t_s_u((((((-6L) || p_8) , ((safe_mul_func_uint32_t_u_u(((l_5782 != (void*)0) < p_8), (-3L))) <= l_5762)) || l_5783[3]) | 0x6D0AL), g_5784)))) < 0x3F20L)) , l_5783[3]) > (-1L))) & (**g_1997)) && p_8) >= l_5783[3]);
                        (*l_5644) = l_5785;
                        (*l_5644) ^= l_5645[4][1];
                        l_5645[4][1] |= ((safe_rshift_func_uint8_t_u_s(((*l_5644) < (((void*)0 == l_5341) <= ((safe_div_func_int64_t_s_s((((l_5792[0] = l_5790[2][9]) == (void*)0) || l_5783[3]), p_8)) > (((((safe_rshift_func_int16_t_s_u(((*g_4020) , ((p_8 == 0x91142D50L) | l_5783[3])), p_8)) < p_8) > l_5795) <= p_8) | p_8)))), p_8)) , 0x07D12F10L);
                    }
                    else
                    { /* block id: 2570 */
                        int32_t l_5813 = 0xAA6BB031L;
                        int32_t l_5814[10][10][2] = {{{0x77FDA489L,(-5L)},{0L,(-1L)},{(-1L),0x4C1735D5L},{0x391EBAFCL,0x90D989D5L},{0xCAACFB5EL,0x77FDA489L},{0x906D2190L,0L},{7L,0L},{0x906D2190L,0x77FDA489L},{0xCAACFB5EL,0x90D989D5L},{0x391EBAFCL,0x4C1735D5L}},{{(-1L),(-1L)},{0L,(-5L)},{0x77FDA489L,7L},{0x7C664A14L,0x3C4F5160L},{(-5L),0x7C664A14L},{0xC01A4520L,0L},{0xC01A4520L,0x7C664A14L},{(-5L),0x3C4F5160L},{0x7C664A14L,7L},{0x77FDA489L,(-5L)}},{{0L,(-1L)},{(-1L),0x4C1735D5L},{0x391EBAFCL,0x90D989D5L},{0L,0L},{0x391EBAFCL,0xCAACFB5EL},{0x4C1735D5L,0xCAACFB5EL},{0x391EBAFCL,0L},{0L,0L},{0x77FDA489L,(-1L)},{0xC01A4520L,0xC01A4520L}},{{0x3C4F5160L,0L},{0L,0x4C1735D5L},{7L,0x53F43BA1L},{0L,7L},{0x35F47DF0L,(-3L)},{0x35F47DF0L,7L},{0L,0x53F43BA1L},{7L,0x4C1735D5L},{0L,0L},{0x3C4F5160L,0xC01A4520L}},{{0xC01A4520L,(-1L)},{0x77FDA489L,0L},{0L,0L},{0x391EBAFCL,0xCAACFB5EL},{0x4C1735D5L,0xCAACFB5EL},{0x391EBAFCL,0L},{0L,0L},{0x77FDA489L,(-1L)},{0xC01A4520L,0xC01A4520L},{0x3C4F5160L,0L}},{{0L,0x4C1735D5L},{7L,0x53F43BA1L},{0L,7L},{0x35F47DF0L,(-3L)},{0x35F47DF0L,7L},{0L,0x53F43BA1L},{7L,0x4C1735D5L},{0L,0L},{0x3C4F5160L,0xC01A4520L},{0xC01A4520L,(-1L)}},{{0x77FDA489L,0L},{0L,0L},{0x391EBAFCL,0xCAACFB5EL},{0x4C1735D5L,0xCAACFB5EL},{0x391EBAFCL,0L},{0L,0L},{0x77FDA489L,(-1L)},{0xC01A4520L,0xC01A4520L},{0x3C4F5160L,0L},{0L,0x4C1735D5L}},{{7L,0x53F43BA1L},{0L,7L},{0x35F47DF0L,(-3L)},{0x35F47DF0L,7L},{0L,0x53F43BA1L},{7L,0x4C1735D5L},{0L,0L},{0x3C4F5160L,0xC01A4520L},{0xC01A4520L,(-1L)},{0x77FDA489L,0L}},{{0L,0L},{0x391EBAFCL,0xCAACFB5EL},{0x4C1735D5L,0xCAACFB5EL},{0x391EBAFCL,0L},{0L,0L},{0x77FDA489L,(-1L)},{0xC01A4520L,0xC01A4520L},{0x3C4F5160L,0L},{0L,0x4C1735D5L},{7L,0x53F43BA1L}},{{0L,7L},{0x35F47DF0L,(-3L)},{0x35F47DF0L,7L},{0L,0x53F43BA1L},{7L,0x4C1735D5L},{0L,0L},{0x3C4F5160L,0xC01A4520L},{0xC01A4520L,(-1L)},{0x77FDA489L,0L},{0L,0L}}};
                        int32_t l_5817 = 0xBF88C03AL;
                        int i, j, k;
                        (*l_5644) = (g_5796[6] , p_8);
                        (*g_62) = (safe_mul_func_int64_t_s_s((l_5799 = (****g_4451)), ((((l_5817 ^= (safe_lshift_func_uint64_t_u_s((l_5654 , p_8), (safe_add_func_int32_t_s_s(((l_5762 || (((safe_rshift_func_int64_t_s_u((safe_mod_func_int64_t_s_s(((*l_5644) ^= ((safe_unary_minus_func_int16_t_s((((l_5813 = (safe_mod_func_int16_t_s_s(((*g_969) = (4UL != (l_5812[1][2][0] &= (+l_5762)))), (p_8 , p_8)))) && l_5812[1][2][0]) && p_8))) <= l_5814[1][9][1])), l_5815)), l_5814[7][8][1])) , l_5816[2]) == (void*)0)) || p_8), p_8))))) && 1UL) ^ 4294967295UL) ^ (***g_3324))));
                        if ((*g_116))
                            break;
                        (*l_5644) &= (safe_rshift_func_int16_t_s_u(((*g_969) &= ((g_4106[0] = l_5820[2]) != (l_5821 = l_5821))), 8));
                    }
                }
            }
            (*g_5561) = &l_5684;
        }
        for (g_4027 = 0; (g_4027 <= 1); g_4027 += 1)
        { /* block id: 2591 */
            (*g_5824) = l_5822[1];
        }
    }
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_3579 g_1998 g_1939 g_731 g_732 g_733 g_878 g_689 g_1329 g_3323 g_3324 g_3325 g_3326 g_3286 g_3602 g_3212 g_3615 g_1997 g_62 g_63 g_3548.f4 g_321 g_430 g_1735 g_190 g_116 g_571 g_1937 g_614 g_1150 g_1151 g_1357 g_1358 g_846 g_3706 g_971 g_968 g_969 g_904 g_1846 g_544 g_1497.f0 g_2586.f0 g_241 g_662 g_267 g_3781 g_764 g_633 g_1935 g_1732 g_3821 g_3411 g_484 g_2958 g_2957 g_203 g_2897 g_1060 g_3926 g_2585 g_2586 g_876 g_877 g_3224.f0 g_4019 g_4027 g_4028 g_308.f0 g_4020 g_55.f0 g_4045 g_4095 g_4100 g_4121 g_1164 g_875 g_4207 g_117 g_3833 g_4235 g_1578 g_3181 g_3182 g_3183 g_2882 g_75 g_4100.f0 g_3707 g_2267 g_4028.f4 g_4603 g_2896 g_4453 g_4611 g_77 g_123.f4 g_527
 * writes: g_77 g_1939 g_190 g_63 g_241 g_3548.f4 g_764 g_321 g_1139 g_1256 g_614 g_571 g_117 g_1151 g_55.f0 g_3706 g_123.f4 g_527 g_267 g_846 g_3832 g_113.f4 g_1578 g_904 g_85 g_180 g_596 g_4106 g_203 g_31 g_1329 g_3286 g_3834 g_4027 g_2882 g_75 g_4100.f0 g_924 g_4028.f4 g_1060
 */
static union U1  func_14(uint64_t  p_15, uint32_t  p_16, int64_t  p_17, uint16_t  p_18)
{ /* block id: 1530 */
    int32_t l_3570 = 1L;
    uint8_t * const l_3588 = &g_571;
    int16_t l_3594 = (-10L);
    int32_t l_3599 = 1L;
    const uint64_t l_3600 = 0UL;
    int32_t *l_3603 = (void*)0;
    union U1 l_3604 = {0x34L};
    int64_t ** const l_3610 = &g_1358;
    uint32_t l_3622 = 0xAF345470L;
    int32_t l_3658 = 0x9092DAA3L;
    int32_t l_3659[1];
    union U0 ****l_3712[7][9][2] = {{{(void*)0,&g_3707},{(void*)0,(void*)0},{(void*)0,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{(void*)0,&g_3707},{&g_3707,(void*)0},{(void*)0,&g_3707},{(void*)0,&g_3707}},{{&g_3707,&g_3707},{&g_3707,&g_3707},{(void*)0,(void*)0},{(void*)0,&g_3707},{(void*)0,&g_3707},{&g_3707,&g_3707},{(void*)0,&g_3707},{(void*)0,&g_3707},{(void*)0,&g_3707}},{{&g_3707,&g_3707},{(void*)0,(void*)0},{&g_3707,(void*)0},{&g_3707,&g_3707},{&g_3707,(void*)0},{&g_3707,&g_3707},{(void*)0,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707}},{{&g_3707,(void*)0},{(void*)0,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{(void*)0,(void*)0},{&g_3707,(void*)0},{(void*)0,&g_3707}},{{&g_3707,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{(void*)0,(void*)0},{&g_3707,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{(void*)0,&g_3707}},{{&g_3707,(void*)0},{&g_3707,&g_3707},{&g_3707,(void*)0},{&g_3707,(void*)0},{(void*)0,&g_3707},{&g_3707,(void*)0},{&g_3707,&g_3707},{&g_3707,(void*)0},{&g_3707,&g_3707}},{{(void*)0,(void*)0},{&g_3707,(void*)0},{&g_3707,&g_3707},{&g_3707,(void*)0},{&g_3707,&g_3707},{(void*)0,&g_3707},{&g_3707,&g_3707},{&g_3707,&g_3707},{&g_3707,(void*)0}}};
    int32_t ***l_3718 = (void*)0;
    int32_t **l_3733 = &g_1139[0];
    int32_t ***l_3732 = &l_3733;
    uint32_t *l_3749[6][3][5] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31}}};
    uint32_t **l_3748 = &l_3749[5][0][3];
    uint32_t ***l_3747 = &l_3748;
    int32_t **** const l_3758 = (void*)0;
    int8_t *** const *l_3826 = &g_2897;
    int32_t l_3838 = 0x4CDC0398L;
    uint32_t l_3839 = 0xC9FE3EBFL;
    uint16_t *l_3856 = &g_267;
    uint16_t l_3882 = 0xF127L;
    uint32_t l_3889 = 1UL;
    int16_t **l_3905[10][10][2] = {{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}},{{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969},{&g_969,&g_969}}};
    uint16_t l_3918 = 1UL;
    union U0 *l_3960[2][9] = {{(void*)0,&g_1164,(void*)0,&g_1164,&g_1164,(void*)0,&g_1164,&g_1164,(void*)0},{&g_1164,&g_1164,(void*)0,&g_1164,&g_1164,(void*)0,&g_1164,&g_1164,(void*)0}};
    union U1 **l_3996 = (void*)0;
    uint64_t ***l_3999 = &g_1150[1];
    uint64_t ****l_3998[7][2] = {{&l_3999,&l_3999},{&l_3999,&l_3999},{&l_3999,&l_3999},{&l_3999,&l_3999},{&l_3999,&l_3999},{&l_3999,&l_3999},{&l_3999,&l_3999}};
    uint64_t *****l_3997 = &l_3998[5][0];
    uint64_t *****l_4000 = (void*)0;
    int8_t l_4058 = (-8L);
    uint16_t **l_4087 = &g_1732;
    uint16_t ***l_4086[7][8] = {{(void*)0,&l_4087,(void*)0,&l_4087,&l_4087,&l_4087,&l_4087,(void*)0},{&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087},{&l_4087,(void*)0,&l_4087,&l_4087,&l_4087,&l_4087,(void*)0,&l_4087},{(void*)0,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,(void*)0,(void*)0},{&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087},{&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087},{&l_4087,(void*)0,(void*)0,&l_4087,&l_4087,&l_4087,&l_4087,&l_4087}};
    uint16_t ****l_4085 = &l_4086[4][6];
    const int32_t ***l_4115 = (void*)0;
    const int32_t ****l_4114 = &l_4115;
    const int32_t **** const *l_4113 = &l_4114;
    int16_t l_4122 = 0x178CL;
    union U1 ****l_4125[5] = {&g_3010,&g_3010,&g_3010,&g_3010,&g_3010};
    union U1 *****l_4124[8] = {&l_4125[2],&l_4125[2],&l_4125[2],&l_4125[2],&l_4125[2],&l_4125[2],&l_4125[2],&l_4125[2]};
    int32_t l_4192 = 0L;
    union U1 l_4219 = {9UL};
    int64_t l_4220 = (-7L);
    uint16_t l_4315 = 0x806EL;
    uint64_t l_4363[2];
    uint32_t l_4490 = 0xAB32E5AAL;
    int8_t l_4551 = 0x2FL;
    int32_t * const l_4557 = (void*)0;
    uint32_t l_4637 = 0UL;
    const int8_t l_4665 = (-1L);
    uint32_t l_4666[1];
    uint32_t *****l_4773[1];
    uint32_t l_4853 = 0x698B2B73L;
    uint64_t l_5039 = 0x3C538AAC0D675F5DLL;
    union U1 l_5070 = {0x23L};
    union U1 *l_5086 = &g_3183[0][1][3];
    union U1 ** const l_5085 = &l_5086;
    union U1 ** const *l_5084 = &l_5085;
    uint32_t l_5110 = 18446744073709551613UL;
    int16_t l_5134 = 0L;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_3659[i] = 0x638F439BL;
    for (i = 0; i < 2; i++)
        l_4363[i] = 0UL;
    for (i = 0; i < 1; i++)
        l_4666[i] = 1UL;
    for (i = 0; i < 1; i++)
        l_4773[i] = (void*)0;
lbl_3759:
    for (g_77 = 1; (g_77 >= (-28)); --g_77)
    { /* block id: 1533 */
        if (l_3570)
            break;
    }
    if ((((safe_sub_func_uint64_t_u_u(((safe_mul_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u((((safe_div_func_uint64_t_u_u((g_3579[7] , (safe_mod_func_int32_t_s_s(((safe_add_func_uint32_t_u_u((l_3570 , ((safe_sub_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_u((l_3588 == (void*)0), 8)) >= (safe_unary_minus_func_uint32_t_u(((*g_1998) &= p_17)))) ^ ((-1L) <= (((safe_mod_func_uint8_t_u_u((safe_mul_func_int32_t_s_s(((((l_3594 , p_17) , (((((((((safe_lshift_func_uint32_t_u_s((safe_mod_func_uint8_t_u_u(252UL, l_3594)), 9)) != p_17) == (**g_731)) && l_3594) && 0xE968EE00L) , 4L) | (*g_878)) && l_3594) && l_3599)) & g_1329) & l_3594), l_3600)), p_18)) | p_15) || p_15))), p_18)) <= p_16)), 1L)) && p_15), p_15))), 1UL)) | 0xA546L) , l_3600), (****g_3323))), p_18)) != p_16), l_3570)) ^ 0x24L) , p_18))
    { /* block id: 1537 */
        int32_t * const l_3601 = &g_1578;
        (*g_3602) = l_3601;
        l_3603 = &l_3599;
        return l_3604;
    }
    else
    { /* block id: 1541 */
        const int16_t l_3609 = 0x3328L;
        int32_t l_3621 = 0L;
        uint64_t ***l_3641 = &g_1150[1];
        uint64_t *** const *l_3640 = &l_3641;
        uint64_t *** const **l_3639[6] = {&l_3640,&l_3640,&l_3640,&l_3640,&l_3640,&l_3640};
        int32_t l_3654 = 0xDFE40902L;
        int32_t l_3662 = (-1L);
        int32_t l_3667 = 0xE6570EFCL;
        int32_t l_3668[10][2][7] = {{{0L,0x4A0D206CL,0xE29FA51DL,0L,0x7037BB9AL,0x96455D58L,0L},{0x4A0D206CL,(-1L),0xF2B4ECADL,0x29E6821CL,(-1L),1L,(-1L)}},{{0x4A0D206CL,0xD2D50B9BL,0xD2D50B9BL,0x4A0D206CL,0L,0x5C1B0C78L,(-1L)},{0L,1L,0x26EA123BL,0L,(-4L),0x26EA123BL,0x5C1B0C78L}},{{(-4L),9L,1L,(-1L),(-1L),(-8L),(-1L)},{0x7037BB9AL,0L,0L,9L,0xE29FA51DL,0x7FE3491CL,(-1L)}},{{0x26EA123BL,1L,0L,0x7FE3491CL,0x29E6821CL,0x7FE3491CL,0L},{(-1L),(-1L),0xE3563BDFL,(-4L),1L,(-8L),0x898DA5A8L}},{{0x898DA5A8L,0x7FE3491CL,0x96455D58L,0x4A0D206CL,0x7FE3491CL,0x26EA123BL,0x29E6821CL},{0xE29FA51DL,0x4A0D206CL,0L,0x3BEC0B4DL,1L,0x5C1B0C78L,0x3BEC0B4DL}},{{(-4L),0x6FF52B24L,0L,(-1L),0x29E6821CL,1L,0x898DA5A8L},{9L,0x96455D58L,0xE29FA51DL,(-1L),0xE29FA51DL,0x96455D58L,9L}},{{0x96455D58L,0x96455D58L,0L,(-1L),0L,0xF2B4ECADL,(-8L)},{0xD2D50B9BL,0L,(-1L),0xD2D50B9BL,0x7FE3491CL,0x7037BB9AL,0L}},{{0x009FF02FL,1L,0L,0x7FE3491CL,2L,0L,0xE29FA51DL},{2L,0x009FF02FL,0xF2B4ECADL,0xE3563BDFL,0L,(-5L),(-5L)}},{{0x26EA123BL,0x009FF02FL,(-1L),0x009FF02FL,0x26EA123BL,0x4A0D206CL,0L},{0L,1L,1L,0x96455D58L,(-1L),0xE3563BDFL,0x009FF02FL}},{{(-8L),0L,1L,2L,0xE29FA51DL,(-5L),0L},{0L,0x96455D58L,(-1L),0xD2D50B9BL,0x96455D58L,(-4L),0x5C1B0C78L}}};
        uint16_t l_3678 = 65534UL;
        int8_t **** const *l_3681 = (void*)0;
        int32_t **l_3720 = &g_484;
        int32_t ***l_3719 = &l_3720;
        union U1 l_3723[9] = {{247UL},{0xD4L},{247UL},{0xD4L},{247UL},{0xD4L},{247UL},{0xD4L},{247UL}};
        int32_t * const *l_3790[6] = {&g_62,&l_3603,&l_3603,&g_62,&l_3603,&l_3603};
        int16_t ****l_3806 = (void*)0;
        int16_t ***** const l_3805 = &l_3806;
        union U1 **l_3845 = &g_181;
        union U1 * const *l_3849 = &g_3182[2];
        int8_t l_3883[10][9][2] = {{{0x5FL,8L},{0x5FL,6L},{4L,0x3BL},{6L,0L},{0xE0L,(-1L)},{0xA0L,(-1L)},{(-1L),4L},{0x6CL,0xEFL},{0L,(-1L)}},{{2L,0x6EL},{0xE0L,1L},{0xAFL,0x3BL},{0xEFL,0xAFL},{0x5FL,(-10L)},{1L,6L},{0xEFL,0x7BL},{6L,1L},{1L,(-1L)}},{{2L,0L},{(-1L),0xEFL},{0L,0xEFL},{(-1L),0L},{2L,(-1L)},{1L,1L},{6L,0x7BL},{0xEFL,6L},{1L,(-10L)}},{{0x5FL,0xAFL},{0xEFL,0x3BL},{0xAFL,1L},{0xE0L,0x6EL},{2L,(-1L)},{0L,0xEFL},{0x6CL,4L},{(-1L),(-1L)},{0xA0L,(-1L)}},{{0xE0L,0L},{6L,0x3BL},{4L,6L},{0x5FL,8L},{0x5FL,6L},{4L,0x3BL},{6L,0L},{0xE0L,(-1L)},{0xA0L,(-1L)}},{{(-1L),4L},{0x6CL,0xEFL},{0L,(-1L)},{2L,0x6EL},{0xE0L,1L},{0xAFL,0x3BL},{0xEFL,0xAFL},{0x5FL,(-10L)},{1L,6L}},{{0xEFL,0x7BL},{6L,1L},{1L,(-1L)},{2L,0L},{(-1L),0xEFL},{0L,0xEFL},{(-1L),5L},{0x6EL,0x7BL},{1L,4L}},{{0xA0L,1L},{0L,0xA0L},{0L,0xAFL},{0L,0x4FL},{0L,(-1L)},{0x4FL,4L},{1L,0L},{0x6EL,8L},{5L,0L}},{{0L,0x24L},{8L,8L},{0x9CL,0x7BL},{1L,0x5EL},{0xA0L,(-1L)},{0x24L,0xA0L},{0L,0x2AL},{0L,0xA0L},{0x24L,(-1L)}},{{0xA0L,0x5EL},{1L,0x7BL},{0x9CL,8L},{8L,0x24L},{0L,0L},{5L,8L},{0x6EL,0L},{1L,4L},{0x4FL,(-1L)}}};
        int64_t l_3915 = (-10L);
        union U1 l_3948 = {0xEBL};
        union U0 ***l_3953 = (void*)0;
        int64_t **l_4057 = &g_1358;
        int32_t *l_4059 = &l_3668[3][1][6];
        uint8_t *l_4060 = &l_3723[4].f0;
        int32_t l_4068 = (-9L);
        const int32_t **** const *l_4116 = (void*)0;
        const uint16_t ****l_4138 = (void*)0;
        uint64_t l_4147 = 18446744073709551611UL;
        int64_t l_4183 = 0xD63D518071FB3A53LL;
        int i, j, k;
        (*g_62) |= (g_3212 == (safe_mul_func_int32_t_s_s((((safe_add_func_int16_t_s_s((l_3609 , ((void*)0 != l_3610)), ((0x97L == (safe_add_func_int16_t_s_s(0x7091L, ((((((4294967294UL != (safe_rshift_func_int16_t_s_s(((g_3615[1] , (((!(((safe_mod_func_int8_t_s_s((l_3621 = (safe_mul_func_int32_t_s_s(0L, (**g_1997)))), p_18)) , l_3588) == l_3588)) , 250UL) <= 0xF0L)) ^ l_3609), 15))) <= l_3599) < 0xA7170BF7L) ^ l_3609) <= p_18) , p_15)))) <= (*g_1998)))) <= l_3622) ^ p_16), 0x293E6EA1L)));
        for (g_241 = 8; (g_241 >= 0); g_241 -= 1)
        { /* block id: 1546 */
            int32_t l_3630 = 0x728EB850L;
            uint64_t * const ****l_3633 = (void*)0;
            int32_t l_3656 = 0x6FC0D3B8L;
            int16_t l_3657 = 0x8B96L;
            int16_t l_3660 = 0L;
            int32_t l_3661 = 0x61A2B0AEL;
            int32_t l_3665 = (-3L);
            int32_t l_3671 = 0x5F758D61L;
            int32_t l_3672[5][2][8] = {{{(-9L),0L,(-7L),(-7L),0L,(-9L),0x8C1F958DL,(-5L)},{0xCF3F7A54L,2L,0x5BAFCE64L,(-9L),(-1L),(-10L),9L,0xCF3F7A54L}},{{0L,0xA0191CBEL,8L,(-9L),(-4L),0x2D6883AAL,0x40EFA1CBL,(-5L)},{0x3356D2FCL,(-4L),0xA0191CBEL,(-7L),0x595FA082L,0x5EA38133L,0x2807EFFAL,0xA0191CBEL}},{{0xFF95A2A1L,0x40EFA1CBL,0x595FA082L,0xCF3F7A54L,1L,0xCF3F7A54L,0x595FA082L,0x40EFA1CBL},{0x40EFA1CBL,1L,(-7L),1L,0x8C1F958DL,1L,1L,0xB26B55F4L}},{{0xB657A6F0L,2L,0xFF95A2A1L,(-1L),0x40EFA1CBL,(-1L),1L,0xB657A6F0L},{0L,(-1L),(-7L),1L,0x2D6883AAL,0L,0x595FA082L,(-5L)}},{{0x2D6883AAL,0L,0x595FA082L,(-5L),(-1L),0x2807EFFAL,0x2807EFFAL,(-1L)},{(-1L),0xA0191CBEL,0xA0191CBEL,(-1L),0x6D3427C9L,0xCF3F7A54L,0x40EFA1CBL,(-9L)}}};
            uint64_t *l_3684 = &g_321;
            union U1 l_3693[9] = {{0xABL},{0xABL},{0xABL},{0xABL},{0xABL},{0xABL},{0xABL},{0xABL},{0xABL}};
            uint32_t *l_3695[8][3] = {{&g_1496,&g_1496,&g_1496},{&g_1496,&g_1496,&g_1496},{&g_1496,&g_1496,&g_1496},{&g_1496,&g_1496,&g_1496},{&g_1496,&g_1496,&g_1496},{&g_1496,&g_1496,&g_1496},{&g_1496,&g_1496,&g_1496},{&g_1496,&g_1496,&g_1496}};
            uint32_t **l_3694[4] = {&l_3695[3][2],&l_3695[3][2],&l_3695[3][2],&l_3695[3][2]};
            int32_t ***l_3734 = (void*)0;
            int16_t l_3750 = 0x8F72L;
            int32_t ****l_3836[5][3];
            int32_t *****l_3835 = &l_3836[0][2];
            int i, j, k;
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 3; j++)
                    l_3836[i][j] = &l_3718;
            }
            for (g_3548.f4 = 7; (g_3548.f4 >= 0); g_3548.f4 -= 1)
            { /* block id: 1549 */
                int32_t **l_3623 = (void*)0;
                int32_t **l_3624 = (void*)0;
                int32_t *l_3625[8] = {&g_1256,&g_117,&g_117,&g_1256,&g_117,&g_117,&g_1256,&g_117};
                uint16_t l_3646 = 0x63CAL;
                int i;
                l_3625[4] = ((*g_3602) = &l_3570);
                for (g_764 = 1; (g_764 <= 8); g_764 += 1)
                { /* block id: 1554 */
                    int32_t *l_3626 = &g_1256;
                    uint64_t ****l_3648 = &l_3641;
                    union U1 l_3649 = {0x57L};
                    for (g_321 = 0; (g_321 <= 1); g_321 += 1)
                    { /* block id: 1557 */
                        int32_t **l_3627 = &g_1139[0];
                        uint64_t * const ***l_3647 = &g_3636;
                        int i, j, k;
                        (*l_3627) = (l_3603 = l_3626);
                        if (g_430[(g_3548.f4 + 2)][(g_321 + 6)][g_321])
                            break;
                        (**g_1735) = (safe_rshift_func_uint32_t_u_s(((6L > (p_16 < 1L)) & l_3630), (l_3649 , 0xE21B72FEL)));
                        (*l_3626) = (0xA5L | p_16);
                    }
                }
                if (p_18)
                    break;
                for (g_614 = 0; (g_614 <= 7); g_614 += 1)
                { /* block id: 1569 */
                    int16_t l_3653 = 0xECE6L;
                    int32_t l_3664 = (-10L);
                    int32_t l_3670 = 0xA1FA39C2L;
                    int32_t l_3675 = 0x9B3BA0F2L;
                    int32_t l_3676 = 0x80476AE9L;
                    uint64_t *l_3685 = &g_764;
                    uint32_t *l_3691[3][8][9] = {{{(void*)0,&g_31,&g_1496,&g_31,(void*)0,&g_3411,&g_1496,&g_3411,(void*)0},{(void*)0,(void*)0,&g_31,(void*)0,(void*)0,(void*)0,&g_3411,&g_3411,&g_3411},{(void*)0,&g_31,&g_31,&g_3411,(void*)0,&g_31,&g_31,&g_31,(void*)0},{(void*)0,&g_3411,&g_31,&g_1496,(void*)0,&g_1496,(void*)0,&g_1496,(void*)0},{&g_1496,&g_31,(void*)0,&g_3411,&g_3411,&g_3411,&g_1496,&g_3411,(void*)0},{(void*)0,(void*)0,&g_1496,&g_3411,&g_1496,(void*)0,&g_1496,&g_1496,(void*)0},{(void*)0,&g_31,&g_3411,&g_31,(void*)0,&g_31,(void*)0,&g_3411,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1496,&g_1496,&g_31,&g_1496,&g_1496,&g_3411}},{{&g_3411,&g_3411,(void*)0,&g_31,&g_1496,&g_31,&g_1496,&g_31,(void*)0},{&g_1496,(void*)0,&g_1496,(void*)0,&g_1496,(void*)0,(void*)0,&g_3411,(void*)0},{(void*)0,&g_3411,&g_31,&g_31,(void*)0,&g_3411,&g_31,&g_3411,(void*)0},{&g_1496,&g_3411,&g_1496,&g_1496,&g_1496,&g_1496,&g_3411,&g_1496,&g_1496},{&g_1496,&g_3411,(void*)0,&g_31,&g_3411,&g_31,&g_1496,&g_31,(void*)0},{&g_1496,(void*)0,(void*)0,&g_3411,(void*)0,(void*)0,&g_3411,&g_1496,&g_1496},{(void*)0,&g_3411,&g_3411,&g_3411,(void*)0,&g_31,(void*)0,&g_31,(void*)0},{&g_1496,(void*)0,&g_1496,&g_1496,(void*)0,&g_31,&g_3411,&g_1496,(void*)0}},{{&g_3411,&g_31,(void*)0,&g_3411,&g_1496,&g_31,&g_1496,&g_3411,(void*)0},{(void*)0,(void*)0,&g_31,(void*)0,(void*)0,(void*)0,&g_3411,&g_3411,&g_3411},{(void*)0,&g_31,&g_31,&g_3411,(void*)0,&g_31,&g_31,&g_31,(void*)0},{(void*)0,&g_3411,&g_31,&g_1496,(void*)0,&g_1496,(void*)0,&g_1496,(void*)0},{&g_1496,&g_31,(void*)0,&g_3411,&g_3411,&g_3411,&g_1496,&g_3411,(void*)0},{(void*)0,(void*)0,&g_1496,&g_3411,&g_1496,(void*)0,&g_1496,&g_1496,&g_1496},{&g_1496,&g_3411,(void*)0,&g_3411,&g_1496,&g_3411,(void*)0,&g_1496,(void*)0},{(void*)0,&g_3411,&g_3411,&g_31,&g_1496,&g_1496,&g_1496,&g_1496,&g_1496}}};
                    uint32_t **l_3690 = &l_3691[0][2][3];
                    uint32_t ***l_3692 = &l_3690;
                    int i, j, k;
                    for (g_571 = 0; (g_571 <= 2); g_571 += 1)
                    { /* block id: 1572 */
                        const uint32_t l_3652 = 3UL;
                        int8_t l_3655 = 8L;
                        int32_t l_3663 = (-4L);
                        int32_t l_3666 = (-1L);
                        int32_t l_3669 = (-7L);
                        int32_t l_3673 = 0x80BB0E51L;
                        int32_t l_3674 = 0x80D127EAL;
                        int32_t l_3677 = 1L;
                        int i;
                        (*g_116) = (-2L);
                        (*g_190) |= (safe_lshift_func_uint16_t_u_s(((void*)0 == &g_3635[0]), (g_1937[g_571] <= ((g_1937[g_571] <= ((g_3579[(g_614 + 1)] , (l_3652 | 4294967286UL)) , p_16)) | 2L))));
                        --l_3678;
                    }
                    l_3681 = &g_2896;
                    if (((safe_sub_func_int32_t_s_s((((((l_3684 = ((**l_3641) = (**l_3641))) == l_3685) ^ (safe_rshift_func_uint64_t_u_s((((*l_3692) = (func_53(((safe_rshift_func_uint32_t_u_s(0xAA8A01A0L, 10)) , l_3604)) , l_3690)) != (l_3693[1] , l_3694[1])), (**g_1357)))) , l_3604) , l_3670), 0xDD716E8EL)) > 4294967288UL))
                    { /* block id: 1581 */
                        uint16_t l_3696 = 0x0522L;
                        union U0 *****l_3708 = &g_3706[1][0][3];
                        union U0 *****l_3709 = (void*)0;
                        union U0 ****l_3711 = &g_3707;
                        union U0 *****l_3710 = &l_3711;
                        int32_t l_3721 = 0xA5EBFC47L;
                        int32_t l_3722 = (-2L);
                        (*g_190) |= p_17;
                        l_3696++;
                        (*g_62) = (l_3722 = (l_3721 = (safe_add_func_uint8_t_u_u((safe_div_func_int8_t_s_s(l_3696, (~(safe_div_func_uint16_t_u_u(0UL, (p_16 , 0x73DEL)))))), ((((*l_3710) = ((*l_3708) = g_3706[1][0][2])) == (l_3712[5][0][0] = &g_3707)) <= (p_18 < (!(safe_lshift_func_int16_t_s_s((((*l_3588) |= (p_18 <= (l_3718 == l_3719))) , (***g_971)), 13)))))))));
                        return l_3723[4];
                    }
                    else
                    { /* block id: 1592 */
                        if (p_15)
                            break;
                    }
                }
            }
            for (g_123.f4 = 8; (g_123.f4 >= 2); g_123.f4 -= 1)
            { /* block id: 1599 */
                if (l_3609)
                    break;
            }
            for (g_527 = 0; (g_527 <= 1); g_527 += 1)
            { /* block id: 1604 */
                uint64_t l_3725[7][6] = {{18446744073709551615UL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551607UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551607UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551607UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551607UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551607UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551607UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551607UL}};
                int8_t *l_3737 = (void*)0;
                int8_t *l_3738[8] = {&g_2882,&g_2962,&g_2882,&g_2962,&g_2882,&g_2962,&g_2882,&g_2962};
                int32_t l_3739 = 0L;
                uint32_t *l_3744 = &l_3622;
                int32_t *l_3752 = &l_3659[0];
                int8_t l_3792[7];
                int8_t ****l_3827 = (void*)0;
                int i, j;
                for (i = 0; i < 7; i++)
                    l_3792[i] = 0L;
                (*g_1846) = &l_3570;
                if (l_3725[3][5])
                    continue;
                (*g_62) = (safe_sub_func_uint32_t_u_u((*g_1998), ((*g_1998) != ((safe_mul_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(l_3725[6][4], (((l_3732 != l_3734) , (safe_lshift_func_int8_t_s_u((l_3739 = 0x33L), 2))) || ((safe_sub_func_int64_t_s_s(((((0UL ^ (((safe_add_func_uint32_t_u_u(((*l_3744) = p_18), (safe_div_func_uint64_t_u_u((((((g_544 , l_3747) != &l_3748) == g_1497.f0) <= p_18) != g_2586.f0), 0xC429BD25BF052859LL)))) >= 4294967290UL) && 0x35582F764B6F10BDLL)) != (*g_3326)) , p_15) == 1UL), l_3750)) | 1UL)))), 255UL)) , 0x9A68BC2AL))));
                for (p_18 = 0; (p_18 <= 1); p_18 += 1)
                { /* block id: 1612 */
                    int32_t **l_3751 = (void*)0;
                    union U1 l_3757 = {6UL};
                    uint8_t l_3791 = 0x38L;
                    uint32_t l_3793 = 5UL;
                    int32_t ****l_3829[7][8] = {{&l_3718,&l_3719,&l_3719,&l_3719,&l_3719,&l_3719,&l_3718,&l_3719},{&l_3719,&l_3719,&l_3718,&l_3719,&l_3718,&l_3718,&l_3719,&l_3718},{&l_3719,&l_3719,&l_3719,&l_3718,&l_3718,&l_3719,(void*)0,&l_3719},{&l_3719,&l_3718,&l_3718,&l_3718,&l_3719,(void*)0,&l_3719,&l_3719},{&l_3718,&l_3718,(void*)0,&l_3718,&l_3718,(void*)0,&l_3718,&l_3718},{&l_3719,(void*)0,(void*)0,&l_3719,&l_3719,&l_3719,&l_3719,&l_3719},{&l_3718,&l_3719,&l_3718,&l_3719,&l_3719,&l_3719,(void*)0,(void*)0}};
                    int i, j, k;
                    l_3752 = (g_3579[g_241] , ((**l_3732) = &l_3739));
                    if (((((safe_sub_func_int32_t_s_s(((((*l_3588) = 1UL) ^ (((*l_3752) >= ((safe_lshift_func_int64_t_s_s((l_3757 , (func_53(l_3757) , (((*g_1358) , p_15) < (p_16 | ((l_3758 != &l_3719) > 0xDEL))))), 45)) , p_18)) < (*g_662))) > p_17), p_18)) != p_16) > 3UL) & (**g_1357)))
                    { /* block id: 1616 */
                        return l_3693[1];
                    }
                    else
                    { /* block id: 1618 */
                        if (p_17)
                            goto lbl_3759;
                    }
                    (*g_190) = (safe_mul_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s((safe_div_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u(((void*)0 != l_3751), (p_15 > ((((safe_mul_func_int16_t_s_s(l_3609, ((*g_1732) = (safe_lshift_func_uint8_t_u_s((safe_sub_func_int64_t_s_s((safe_unary_minus_func_int16_t_s((safe_div_func_uint8_t_u_u(((((safe_mul_func_uint16_t_u_u((0x515BBF6F7984D070LL != (safe_mod_func_uint32_t_u_u((g_3781 , (safe_sub_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u(1UL, (g_764 | (safe_unary_minus_func_int64_t_s((safe_add_func_uint64_t_u_u((!((*l_3752) ^= (((l_3790[4] == (*l_3732)) == 0xE758E111L) >= g_633))), l_3791))))))) < 0xE01C645CL), p_17))), (*g_1998)))), l_3792[5])) , &l_3720) == &l_3720) & 0x84L), g_1935)))), l_3791)), 1))))) >= 0x77B5L) != p_18) || 6L)))) || p_17), l_3793)), 5)), p_15));
                    if ((safe_add_func_int8_t_s_s(((*l_3752) , ((((0x89D29AF78BB7CA52LL > (safe_sub_func_int32_t_s_s(1L, 0x2D4DB504L))) > (safe_mul_func_int8_t_s_s((*l_3752), ((+(safe_add_func_int64_t_s_s(((safe_rshift_func_int8_t_s_s((&g_2487 == l_3805), ((-9L) ^ (safe_div_func_int32_t_s_s((((*g_662) = (safe_lshift_func_int16_t_s_s(p_15, (*l_3752)))) > p_15), (-1L)))))) , p_16), 0xFA91496A98D1496CLL))) == (**g_1357))))) && p_17) >= (-10L))), 255UL)))
                    { /* block id: 1625 */
                        (*l_3752) ^= (safe_add_func_int8_t_s_s(0xE9L, ((*g_1998) ^ ((*g_1998) > (*g_62)))));
                    }
                    else
                    { /* block id: 1627 */
                        int32_t *****l_3830 = (void*)0;
                        int32_t *****l_3831[8];
                        int32_t l_3837 = 1L;
                        int i;
                        for (i = 0; i < 8; i++)
                            l_3831[i] = &l_3829[6][5];
                        if ((**g_1846))
                            break;
                        (*l_3752) = (safe_mod_func_int16_t_s_s((((safe_div_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((*l_3588) = (safe_rshift_func_int32_t_s_u(((g_3821 , (safe_add_func_uint32_t_u_u((safe_div_func_int64_t_s_s((l_3826 != l_3827), ((**g_1357) = p_15))), (!0x75407200L)))) >= ((g_3832 = l_3829[3][3]) != (((((*g_1998) = 0xC27BD225L) != (((((((**l_3720) = ((0UL && ((g_3411 , (*g_878)) ^ p_18)) < (*l_3752))) , l_3835) != (void*)0) , 0xAE12L) != (*g_662)) ^ (*g_969))) & 249UL) , &g_3833))), 26))), p_17)), l_3837)) , p_15) >= l_3838), p_18));
                    }
                }
            }
            if (l_3839)
                break;
        }
        if (p_16)
        { /* block id: 1640 */
            uint32_t l_3840 = 8UL;
            uint64_t l_3858 = 0x2C161C573AC414A0LL;
            int32_t *l_3860 = &g_1578;
            union U0 * const *l_3876 = &g_924;
            union U0 * const **l_3875 = &l_3876;
            int32_t l_3888 = 0x36B481EEL;
            if (l_3840)
            { /* block id: 1641 */
                int64_t l_3859 = 0x33B29554B891867BLL;
                int16_t l_3868 = 1L;
                int32_t l_3884 = 0x3A5A3CE1L;
                for (g_117 = (-28); (g_117 > 24); g_117 = safe_add_func_uint8_t_u_u(g_117, 4))
                { /* block id: 1644 */
                    union U1 ***l_3846 = &l_3845;
                    int32_t l_3857 = 0x2EBA0834L;
                    int32_t *l_3885 = (void*)0;
                    (*g_62) |= ((void*)0 != &g_62);
                }
            }
            else
            { /* block id: 1668 */
                int8_t *l_3900 = &g_2882;
                int8_t **l_3899 = &l_3900;
                int32_t l_3914 = (-2L);
                int16_t **l_3917[3][8] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                int16_t ***l_3916 = &l_3917[1][1];
                int i, j;
                (*g_62) = (!(safe_mod_func_int16_t_s_s((((**g_2958) > (safe_mul_func_int32_t_s_s((*g_62), ((*l_3860) = (0xB3L > (safe_rshift_func_uint8_t_u_u(p_16, 2))))))) < (((l_3899 == (**l_3826)) < ((safe_rshift_func_int16_t_s_u((((*g_1998) &= (((((*l_3588) = (((((safe_mul_func_uint16_t_u_u((***g_3324), (((l_3905[1][1][1] = l_3905[4][8][0]) == ((*l_3916) = (((*g_969) = (safe_sub_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((((safe_lshift_func_uint32_t_u_s((((((p_15 ^= (((((safe_sub_func_uint8_t_u_u((((*g_62) && 7L) ^ p_16), p_17)) | p_17) | p_18) , 0x3781E6B4L) >= p_16)) ^ l_3914) > p_18) | (*g_662)) , 8UL), l_3915)) , 0xAB0D1995L) < 0x3E0759A8L), p_17)), p_17))) , &g_969))) ^ 1L))) <= 0UL) <= l_3914) , 6L) > p_17)) | (-1L)) ^ 0L) >= p_17)) || p_15), 9)) , l_3918)) >= p_17)), 0x622BL)));
            }
        }
        else
        { /* block id: 1678 */
            int32_t * const l_3927 = &g_596;
            union U1 ****l_3928 = (void*)0;
            int32_t l_3929 = 0x2D6DF0ABL;
            int32_t l_3930[8][7] = {{1L,(-1L),(-1L),1L,0xBB2DB1A4L,1L,1L},{1L,0xB8DC07C1L,3L,3L,0xB8DC07C1L,1L,8L},{0x1869CD47L,1L,1L,(-8L),(-8L),1L,1L},{0xB8DC07C1L,8L,1L,0xB8DC07C1L,3L,3L,0xB8DC07C1L},{1L,1L,1L,0xBB2DB1A4L,1L,(-1L),(-1L)},{1L,0xB8DC07C1L,(-7L),0xB8DC07C1L,1L,(-7L),1L},{1L,1L,0xF45FBA26L,1L,0xF45FBA26L,1L,1L},{0x660594BDL,1L,(-7L),(-2L),1L,(-2L),(-7L)}};
            union U0 ***l_3955 = &g_2267;
            uint16_t l_4096 = 0x0BFEL;
            int32_t *****l_4112 = &g_3832;
            int i, j;
            for (g_85 = 1; (g_85 == 59); g_85 = safe_add_func_int16_t_s_s(g_85, 1))
            { /* block id: 1681 */
                int32_t *l_3925 = &g_241;
                int32_t l_3931 = 4L;
                int8_t l_3944 = 0x8BL;
                union U1 l_3954 = {0x3AL};
                if ((safe_div_func_int8_t_s_s((p_15 != ((l_3931 ^= (safe_lshift_func_int8_t_s_s((((*g_969) &= (l_3925 != (g_3926 , l_3927))) , ((l_3928 != (void*)0) ^ (l_3929 = (-8L)))), l_3930[1][6]))) & ((((safe_rshift_func_int32_t_s_s((*g_62), l_3930[4][4])) & p_17) != 0x20B1658AL) & 4UL))), p_18)))
                { /* block id: 1685 */
                    uint8_t l_3945 = 0xDFL;
                    int8_t *l_3946 = &l_3883[6][7][0];
                    int32_t l_3947 = (-5L);
                    l_3947 = (safe_mul_func_uint32_t_u_u(((safe_sub_func_int64_t_s_s((**g_1357), (safe_div_func_uint32_t_u_u((0xE0A9E2486EF653C4LL == l_3931), 0x285F4AA9L)))) != (safe_sub_func_uint8_t_u_u(p_18, (safe_mul_func_uint8_t_u_u((l_3944 == (**g_1997)), ((*l_3946) = l_3945)))))), 4294967289UL));
                }
                else
                { /* block id: 1688 */
                    return l_3948;
                }
                (*g_62) = ((safe_lshift_func_uint64_t_u_u(((((*g_1358) = (safe_mod_func_int64_t_s_s((l_3953 == (l_3954 , l_3955)), (**g_1357)))) & (((((l_3930[1][6] = ((safe_rshift_func_uint32_t_u_u((*g_1998), (((((*g_969) = (safe_sub_func_int32_t_s_s(((((void*)0 == l_3960[0][8]) | (safe_rshift_func_uint32_t_u_s((safe_div_func_int8_t_s_s((((safe_add_func_int64_t_s_s((safe_rshift_func_int32_t_s_u((safe_mul_func_uint8_t_u_u(0xC0L, (((safe_div_func_uint16_t_u_u((p_18 == 0xED9FD5AAL), p_17)) && p_15) != 0x5522FA84339709E7LL))), 8)), l_3930[5][6])) <= p_18) >= 1L), g_430[8][4][0])), 25))) >= p_17), (*g_1998)))) >= (*g_3326)) , &l_3604) == (void*)0))) & l_3931)) , p_16) > p_17) , l_3930[1][6]) <= l_3944)) <= p_15), 4)) && (*g_662));
                (*g_62) &= (safe_unary_minus_func_uint8_t_u((safe_div_func_int32_t_s_s((safe_sub_func_int8_t_s_s((safe_lshift_func_int32_t_s_u((((1L == (((safe_sub_func_uint32_t_u_u((p_16 <= (***g_3324)), p_15)) | p_18) || (((safe_rshift_func_int64_t_s_u(p_16, 1)) <= ((safe_mul_func_int8_t_s_s((safe_mod_func_int16_t_s_s(((void*)0 == &l_3849), (-1L))), p_17)) != p_18)) >= l_3944))) || 255UL) >= p_16), l_3944)), 0x1DL)), p_16))));
            }
            if ((((safe_mul_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s((p_15 || ((safe_mul_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(0xA7A3L, (((g_180 = l_3845) == l_3996) > (l_3997 != l_4000)))), (safe_div_func_int64_t_s_s(((*g_2585) , ((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint64_t_u_s((***g_876), (&l_3928 != &l_3928))) , 0UL), 0UL)) || l_3929)), p_18)))) > p_18)), p_17)), g_3224.f0)) || p_15) >= (**g_1357)))
            { /* block id: 1698 */
                int16_t l_4029 = 0xBCEAL;
                uint32_t l_4030 = 18446744073709551615UL;
                uint64_t l_4031 = 0xE3C4A44011EC5BCELL;
                int32_t l_4047 = 0xC96104A8L;
                int32_t l_4070 = (-1L);
                int32_t l_4072 = 1L;
                int32_t l_4073 = 7L;
                int32_t l_4074 = (-1L);
                uint16_t **l_4083 = (void*)0;
                uint16_t ***l_4082[5];
                uint16_t ****l_4081 = &l_4082[3];
                union U1 l_4101[10] = {{0x2CL},{0x2CL},{4UL},{0x2CL},{0x2CL},{4UL},{0x2CL},{0x2CL},{4UL},{0x2CL}};
                int i;
                for (i = 0; i < 5; i++)
                    l_4082[i] = &l_4083;
                (*g_62) |= (-7L);
                if (((safe_div_func_int8_t_s_s((((*l_3748) = &g_31) == (void*)0), ((safe_lshift_func_int16_t_s_u(((safe_div_func_int16_t_s_s((safe_add_func_uint32_t_u_u(((*g_1998) ^= (((p_18 >= ((safe_lshift_func_uint16_t_u_s(p_16, ((safe_sub_func_uint32_t_u_u(((void*)0 == g_4019), p_15)) <= ((safe_div_func_uint8_t_u_u(((**g_4019) = (((((safe_lshift_func_uint8_t_u_u((g_4027 != (l_4029 = ((g_4028 , p_16) && 1UL))), g_308[0][2].f0)) && p_16) <= p_17) != l_4030) != 0UL)), p_16)) <= 0x83258099L)))) && 5L)) && (-7L)) >= 0L)), p_17)), l_4030)) , l_4031), 4)) , 0xB1L))) | (*g_62)))
                { /* block id: 1704 */
                    int32_t * const l_4048 = &g_362;
                    l_4047 = ((*g_62) = ((safe_add_func_int32_t_s_s((((((safe_div_func_int32_t_s_s((p_16 < ((~(p_18 ^ (8UL > (safe_add_func_int8_t_s_s(((p_17 < (**g_4019)) ^ (safe_div_func_uint16_t_u_u(((safe_div_func_int64_t_s_s((*g_1358), ((safe_add_func_int32_t_s_s(0xAA1B9101L, g_4045)) || (((~(0x4171C23AL || l_4031)) > 4294967294UL) | p_18)))) <= p_18), 0x1D64L))), p_18))))) | p_18)), l_4031)) , p_17) && 0xE07425E2L) >= (*g_1998)) || l_3930[1][6]), p_15)) > p_18));
                    for (g_596 = 6; (g_596 >= 0); g_596 -= 1)
                    { /* block id: 1709 */
                        int64_t l_4056[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                        int i;
                        l_4059 = l_4048;
                        (*g_62) = (((l_4060 == l_3588) != p_15) & (safe_unary_minus_func_uint64_t_u(((***l_3999) &= p_16))));
                    }
                }
                else
                { /* block id: 1714 */
                    int8_t l_4066 = 0xF5L;
                    int32_t l_4067 = 0L;
                    int32_t l_4069 = 0xCA6E7FE7L;
                    uint16_t l_4077 = 5UL;
                    for (l_3918 = (-27); (l_3918 == 44); l_3918 = safe_add_func_int64_t_s_s(l_3918, 2))
                    { /* block id: 1717 */
                        int16_t l_4064 = 0xCA24L;
                        int32_t l_4065 = 7L;
                        int32_t l_4071 = (-5L);
                        int8_t l_4075 = (-7L);
                        int32_t l_4076 = 0x9F4F2FDEL;
                        --l_4077;
                    }
                    for (l_4029 = 1; (l_4029 >= 0); l_4029 -= 1)
                    { /* block id: 1722 */
                        uint16_t *****l_4084[1];
                        int32_t l_4097 = 0x03BDCD9DL;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_4084[i] = (void*)0;
                        (*g_62) = ((p_15 , ((~(5UL != p_18)) != l_4077)) , 0xB8EB5263L);
                        (*g_62) = (p_18 >= (((((p_18 , &g_3520[6]) != (l_4085 = l_4081)) <= (((safe_lshift_func_uint32_t_u_s(0UL, 11)) && ((safe_rshift_func_uint32_t_u_s(((safe_unary_minus_func_int64_t_s(9L)) , ((*g_1998) = 2UL)), 26)) , (safe_lshift_func_int8_t_s_s((p_16 || (((((l_3929 == p_17) & g_4095) ^ l_4096) == 0x2D40C0EDL) || 0xE3L)), l_4097)))) || p_18)) , p_15) , 0xDDB614D48B5A1DABLL));
                        if (p_16)
                            break;
                    }
                    for (l_3570 = 0; (l_3570 <= 8); ++l_3570)
                    { /* block id: 1731 */
                        return g_4100;
                    }
                    return l_4101[9];
                }
                if (l_4072)
                { /* block id: 1736 */
                    union U1 l_4102 = {255UL};
                    return l_4102;
                }
                else
                { /* block id: 1738 */
                    return (*g_2585);
                }
            }
            else
            { /* block id: 1741 */
                int16_t ***l_4105 = (void*)0;
                union U1 l_4107 = {255UL};
                union U1 **** const *l_4123[1][9] = {{&l_3928,&l_3928,&l_3928,&l_3928,&l_3928,&l_3928,&l_3928,&l_3928,&l_3928}};
                int i, j;
                (*l_4059) = (safe_mod_func_int32_t_s_s((((g_4106[0] = l_3905[5][1][0]) != (((((l_4107 , 18446744073709551615UL) < p_18) == p_15) ^ l_3930[0][5]) , (void*)0)) , (-1L)), 0x7801E843L));
                (**g_2958) &= (safe_rshift_func_uint32_t_u_s(((4294967295UL <= ((((l_4112 = &g_3832) == (l_4116 = l_4113)) , ((safe_lshift_func_uint16_t_u_s(0x6211L, (safe_mod_func_uint64_t_u_u(p_18, g_4121)))) <= l_4122)) , (l_4123[0][0] != l_4124[4]))) >= p_15), p_17));
            }
        }
        for (g_31 = 0; (g_31 <= 16); g_31 = safe_add_func_int8_t_s_s(g_31, 9))
        { /* block id: 1752 */
            uint32_t l_4146 = 0x4F56A3A1L;
            int32_t l_4148 = (-6L);
            uint16_t ****l_4149 = &l_4086[3][2];
            const uint16_t ** const *l_4158[3][10] = {{&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325},{&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325},{&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325,&g_3325}};
            const uint16_t ** const **l_4159 = &l_4158[1][7];
            const uint16_t *l_4163 = &g_4164[3][2][6];
            const uint16_t *l_4165 = &g_4164[3][2][6];
            const uint16_t *l_4166 = &g_4164[4][1][3];
            const uint16_t *l_4167 = &g_4164[3][2][5];
            const uint16_t *l_4168[2][6];
            const uint16_t *l_4169 = &g_4164[0][2][7];
            const uint16_t *l_4170[8][6][5] = {{{&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[2][1][5],&g_4164[3][2][6],&g_4164[1][2][4]},{&g_4164[1][1][3],&g_4164[1][3][5],&g_4164[2][3][4],&g_4164[3][2][6],&g_4164[4][0][0]},{&g_4164[3][2][6],&g_4164[1][1][1],&g_4164[2][1][5],&g_4164[1][2][4],&g_4164[1][1][1]},{(void*)0,&g_4164[3][1][3],&g_4164[4][0][2],&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[0][2][1],&g_4164[3][2][6],&g_4164[0][2][1],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[1][1][3],&g_4164[4][3][7],&g_4164[3][2][6],(void*)0}},{{&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[4][1][5],&g_4164[3][2][6],&g_4164[2][1][5]},{&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[4][2][5],&g_4164[1][1][3],(void*)0},{&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[4][3][1],&g_4164[2][1][5],&g_4164[3][2][6]},{(void*)0,&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[1][3][5],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[3][2][6],(void*)0,&g_4164[0][2][5],&g_4164[1][1][1]},{&g_4164[4][0][2],&g_4164[4][0][0],(void*)0,&g_4164[3][2][6],&g_4164[4][0][0]}},{{&g_4164[0][2][1],&g_4164[4][1][5],&g_4164[4][1][1],&g_4164[3][2][6],&g_4164[1][2][4]},{&g_4164[3][2][6],&g_4164[4][0][0],&g_4164[4][2][5],(void*)0,&g_4164[3][2][6]},{&g_4164[4][3][1],&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[1][2][4],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[3][2][6],(void*)0},{&g_4164[1][1][1],&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[4][0][2],&g_4164[3][2][6],(void*)0,(void*)0,&g_4164[3][2][6]}},{{&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[0][2][4],&g_4164[3][2][6],&g_4164[1][2][4]},{&g_4164[1][3][5],&g_4164[1][1][3],&g_4164[2][3][4],&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[0][2][1],&g_4164[1][2][4],&g_4164[1][2][4],&g_4164[0][2][1]},{&g_4164[4][0][0],&g_4164[3][1][3],&g_4164[3][2][6],(void*)0,&g_4164[3][2][6]},{&g_4164[0][2][5],&g_4164[1][1][1],&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[1][3][5],&g_4164[3][1][3],&g_4164[3][2][6],&g_4164[4][0][2]}},{{&g_4164[3][2][6],&g_4164[2][2][4],(void*)0,&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[4][3][7],&g_4164[1][1][3],&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[2][1][5],(void*)0,&g_4164[2][1][5],&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[3][2][6],(void*)0,&g_4164[4][0][2],&g_4164[3][2][6]},{&g_4164[3][2][6],&g_4164[4][3][1],&g_4164[3][2][6],&g_4164[4][1][5],&g_4164[1][2][4]},{&g_4164[3][2][6],(void*)0,(void*)0,&g_4164[3][2][6],(void*)0}},{{&g_4164[2][1][5],&g_4164[3][2][6],&g_4164[2][1][5],&g_4164[0][2][4],(void*)0},{&g_4164[4][3][7],(void*)0,&g_4164[1][1][3],(void*)0,&g_4164[4][3][7]},{(void*)0,&g_4164[3][2][6],(void*)0,(void*)0,&g_4164[4][1][1]},{&g_4164[3][1][3],&g_4164[3][2][6],&g_4164[4][2][5],&g_4164[3][1][3],(void*)0},{&g_4164[0][2][4],&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[4][1][1]},{&g_4164[3][2][6],&g_4164[3][1][3],&g_4164[2][2][5],(void*)0,&g_4164[4][3][7]}},{{&g_4164[4][1][1],&g_4164[2][2][4],(void*)0,&g_4164[4][3][1],(void*)0},{(void*)0,(void*)0,&g_4164[1][3][5],&g_4164[3][2][6],(void*)0},{&g_4164[2][1][5],&g_4164[1][2][4],&g_4164[2][3][6],(void*)0,&g_4164[1][2][4]},{(void*)0,&g_4164[4][2][5],&g_4164[3][2][3],&g_4164[3][2][6],&g_4164[3][2][6]},{&g_4164[4][1][5],&g_4164[1][2][4],&g_4164[3][2][6],&g_4164[2][1][5],&g_4164[3][2][6]},{&g_4164[2][2][5],(void*)0,&g_4164[3][2][6],&g_4164[3][2][6],&g_4164[3][2][6]}},{{(void*)0,&g_4164[2][2][4],&g_4164[2][2][4],(void*)0,&g_4164[3][2][6]},{(void*)0,&g_4164[3][1][3],&g_4164[1][1][3],(void*)0,&g_4164[4][0][2]},{&g_4164[2][1][5],&g_4164[3][2][6],&g_4164[2][3][3],&g_4164[3][2][6],&g_4164[4][1][5]},{&g_4164[4][0][2],&g_4164[3][2][6],(void*)0,(void*)0,&g_4164[3][2][6]},{&g_4164[4][3][1],&g_4164[3][2][6],&g_4164[3][2][6],(void*)0,&g_4164[0][2][4]},{&g_4164[3][2][6],(void*)0,&g_4164[3][2][6],&g_4164[3][2][6],(void*)0}}};
            const uint16_t *l_4171 = &g_4164[4][3][6];
            const uint16_t *l_4172 = &g_4164[3][2][6];
            const uint16_t *l_4173 = &g_4164[3][2][6];
            const uint16_t *l_4174 = &g_4164[3][2][6];
            const uint16_t *l_4175 = &g_4164[0][1][4];
            const uint16_t *l_4176 = &g_4164[3][1][4];
            const uint16_t *l_4177[6][1] = {{&g_4164[2][2][3]},{(void*)0},{&g_4164[2][2][3]},{(void*)0},{&g_4164[2][2][3]},{(void*)0}};
            const uint16_t *l_4178 = &g_4164[3][2][6];
            const uint16_t ** const l_4162[5][8] = {{&l_4172,&l_4165,&l_4173,&l_4169,&l_4167,&l_4166,&l_4167,&l_4169},{&l_4165,&l_4163,&l_4165,&l_4168[1][0],(void*)0,&l_4178,&l_4171,&l_4166},{(void*)0,&l_4174,&l_4168[1][0],&l_4177[3][0],&l_4173,(void*)0,(void*)0,&l_4173},{(void*)0,&l_4167,&l_4167,(void*)0,(void*)0,&l_4177[3][0],&l_4169,&l_4178},{&l_4165,&l_4170[5][2][3],&l_4177[3][0],&l_4171,&l_4167,&l_4163,&l_4178,&l_4163}};
            const uint16_t ** const *l_4161 = &l_4162[0][6];
            const uint16_t ** const **l_4160 = &l_4161;
            int8_t *l_4197 = &g_1329;
            uint16_t l_4198[1];
            int i, j, k;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 6; j++)
                    l_4168[i][j] = &g_4164[3][2][6];
            }
            for (i = 0; i < 1; i++)
                l_4198[i] = 5UL;
            (*g_62) = ((((safe_lshift_func_uint8_t_u_s(((*l_3588) = ((((safe_mul_func_uint64_t_u_u((p_18 ^ ((safe_mul_func_uint32_t_u_u(p_18, (safe_mod_func_int32_t_s_s((safe_add_func_uint16_t_u_u(p_16, ((-5L) & (((l_4138 != (((g_1164 , ((*g_969) = (safe_sub_func_uint8_t_u_u((+0xC2L), 0xC3L)))) ^ ((l_4148 ^= (l_4147 = (l_4146 &= (safe_rshift_func_int8_t_s_u((safe_lshift_func_uint64_t_u_s(p_15, p_17)), 6))))) , 0xBF99L)) , l_4149)) & 0x8FL) , p_16)))), (*g_1998))))) | p_15)), (****g_875))) >= 0x0785736267D2828BLL) ^ 3UL) || 0x53CAE042C1D48917LL)), p_16)) && p_15) || p_17) && 3L);
            if (p_18)
                continue;
            l_4148 = (safe_rshift_func_int32_t_s_s((safe_mul_func_int16_t_s_s((((safe_rshift_func_int8_t_s_u(p_16, 3)) , (safe_sub_func_uint32_t_u_u(((((((*l_4160) = ((*l_4159) = l_4158[1][9])) == (void*)0) , ((safe_mul_func_uint32_t_u_u(((safe_sub_func_uint16_t_u_u((**g_3325), l_4183)) , (safe_sub_func_int64_t_s_s((safe_add_func_int8_t_s_s(((((*g_662) = (5L < (safe_mul_func_uint8_t_u_u((safe_mul_func_uint64_t_u_u(l_4192, p_18)), (safe_lshift_func_uint64_t_u_s(((safe_mod_func_int8_t_s_s(((*l_4197) &= ((((((*g_1998) = (0L != 0xB695L)) , 0UL) <= p_17) == p_15) ^ p_16)), p_16)) && l_4148), 32)))))) & p_18) ^ (*l_4059)), p_18)), p_15))), l_4148)) < 0x66E8E4BE4EE1A6DALL)) <= l_4198[0]) <= 65529UL), p_15))) || p_18), p_16)), p_16));
        }
    }
    if ((p_15 && (safe_mul_func_int32_t_s_s((safe_rshift_func_int32_t_s_s(((((safe_lshift_func_int32_t_s_s((safe_sub_func_int32_t_s_s((g_4207 , (((safe_mod_func_int16_t_s_s(((~p_18) <= (0x77L < (safe_mul_func_uint16_t_u_u((safe_add_func_int64_t_s_s(0xEBCC231A0CEC00D2LL, ((**l_3610) = ((safe_div_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((l_4219 , 0x3BL), (**g_4019))), (*g_662))) || p_17)))), l_4220)))), p_17)) , p_18) ^ 0UL)), p_18)), 27)) >= p_16) ^ p_16) | 0xDE50E5D2E0951C01LL), 19)), 0x8B8AD760L))))
    { /* block id: 1769 */
        union U1 l_4253 = {0xF9L};
        int32_t l_4259 = 0xDCC24EACL;
        int32_t l_4281[7] = {8L,1L,8L,8L,1L,8L,8L};
        int32_t l_4282 = 0x2AF0F3C8L;
        uint8_t *l_4313 = &g_1658[0];
        uint8_t **l_4312 = &l_4313;
        int i;
        for (p_15 = 0; (p_15 == 38); ++p_15)
        { /* block id: 1772 */
            uint8_t l_4223[5][9] = {{0xA9L,0xA9L,0xCBL,0UL,0xE9L,0xE9L,0UL,0xCBL,0xA9L},{250UL,0xCDL,0x08L,0xCDL,250UL,0xCDL,0x08L,0xCDL,250UL},{0xE9L,0UL,0xCBL,0xA9L,0xA9L,0xCBL,0UL,0xE9L,0xE9L},{0xFFL,0xCDL,0xFFL,3UL,0xFFL,0xCDL,0xFFL,3UL,0xFFL},{0xE9L,0xA9L,0UL,0UL,0xA9L,0xE9L,0xCBL,0xCBL,0xE9L}};
            int64_t l_4243 = 0xB00C8C9A33479494LL;
            int32_t l_4260[8][8][4] = {{{1L,0L,0xC6044BE4L,1L},{1L,(-5L),(-5L),1L},{0xAC12B946L,1L,0x99F10780L,(-5L)},{1L,0L,1L,0x785B9C70L},{9L,0xAC12B946L,(-5L),0x785B9C70L},{0xE020473FL,0L,0xE020473FL,(-5L)},{1L,1L,0xD0B68505L,1L},{9L,(-5L),0x99F10780L,1L}},{{(-5L),0L,0x99F10780L,0x99F10780L},{9L,9L,0xD0B68505L,0x785B9C70L},{1L,0L,0xE020473FL,1L},{0xE020473FL,1L,(-5L),0xE020473FL},{9L,1L,1L,1L},{1L,0L,0x99F10780L,0x785B9C70L},{0xAC12B946L,9L,(-5L),0x99F10780L},{1L,0L,0xC6044BE4L,1L}},{{1L,(-5L),(-5L),1L},{0xAC12B946L,1L,0x99F10780L,(-5L)},{1L,0L,1L,0x785B9C70L},{9L,0xAC12B946L,(-5L),0x785B9C70L},{0xE020473FL,0L,0xE020473FL,(-5L)},{1L,1L,0xD0B68505L,1L},{9L,(-5L),0x99F10780L,1L},{(-5L),0L,0x99F10780L,0x99F10780L}},{{9L,9L,0xD0B68505L,0x785B9C70L},{1L,0L,0xE020473FL,1L},{0xE020473FL,1L,(-5L),0xE020473FL},{9L,1L,1L,1L},{1L,0L,0x99F10780L,0x785B9C70L},{0xAC12B946L,9L,(-5L),0x99F10780L},{1L,0L,0xC6044BE4L,1L},{1L,(-5L),(-5L),1L}},{{0xAC12B946L,1L,0x99F10780L,(-5L)},{1L,0L,1L,0x785B9C70L},{9L,0xAC12B946L,(-5L),0x785B9C70L},{0xE020473FL,0L,0xE020473FL,(-5L)},{1L,1L,0xD0B68505L,1L},{9L,(-5L),0x99F10780L,1L},{(-5L),0L,0x99F10780L,0x99F10780L},{9L,9L,0xD0B68505L,0x785B9C70L}},{{1L,0x82D4A03CL,1L,0xE020473FL},{1L,0xE020473FL,0xC6044BE4L,1L},{(-5L),0xE020473FL,0L,0xE020473FL},{0xE020473FL,0x82D4A03CL,0x729C00E9L,0L},{0xD0B68505L,(-5L),0xC6044BE4L,0x729C00E9L},{0x99F10780L,0xAC12B946L,0x785B9C70L,0xE020473FL},{0x99F10780L,0xC6044BE4L,0xC6044BE4L,0x99F10780L},{0xD0B68505L,0xE020473FL,0x729C00E9L,0xC6044BE4L}},{{0xE020473FL,0xAC12B946L,0L,0L},{(-5L),0xD0B68505L,0xC6044BE4L,0L},{1L,0xAC12B946L,1L,0xC6044BE4L},{0x99F10780L,0xE020473FL,1L,0x99F10780L},{(-5L),0xC6044BE4L,0x729C00E9L,0xE020473FL},{0xC6044BE4L,0xAC12B946L,0x729C00E9L,0x729C00E9L},{(-5L),(-5L),1L,0L},{0x99F10780L,0x82D4A03CL,1L,0xE020473FL}},{{1L,0xE020473FL,0xC6044BE4L,1L},{(-5L),0xE020473FL,0L,0xE020473FL},{0xE020473FL,0x82D4A03CL,0x729C00E9L,0L},{0xD0B68505L,(-5L),0xC6044BE4L,0x729C00E9L},{0x99F10780L,0xAC12B946L,0x785B9C70L,0xE020473FL},{0x99F10780L,0xC6044BE4L,0xC6044BE4L,0x99F10780L},{0xD0B68505L,0xE020473FL,0x729C00E9L,0xC6044BE4L},{0xE020473FL,0xAC12B946L,0L,0L}}};
            uint8_t l_4283 = 0x75L;
            const int8_t l_4316[6][9] = {{0x89L,0L,0x89L,(-9L),(-1L),0xA0L,0xF1L,0x4CL,1L},{0x12L,0x89L,0x0BL,0xDEL,0x3DL,0x4CL,0x3DL,0xDEL,0x0BL},{1L,1L,0L,(-9L),0x12L,0x89L,0x0BL,0xDEL,0x3DL},{0xA0L,0xF1L,0x4CL,1L,0xCCL,0xCCL,1L,0x4CL,0xF1L},{0xCCL,2L,0L,0xB4L,0L,(-9L),1L,0x0BL,(-1L)},{0xDEL,0xA0L,0x0BL,0xF1L,0x61L,0xF1L,0x0BL,0xA0L,0xDEL}};
            int i, j, k;
            --l_4223[1][5];
            for (g_117 = 0; (g_117 != 2); ++g_117)
            { /* block id: 1776 */
                uint32_t l_4234 = 0xEAAFC108L;
                uint64_t l_4269 = 0x771EFDC4EB0F2D87LL;
                int32_t l_4279 = 0L;
                int32_t l_4280[6] = {5L,5L,5L,5L,5L,5L};
                int i;
                for (g_3286 = 3; (g_3286 <= 8); g_3286 += 1)
                { /* block id: 1779 */
                    (*g_3833) = (void*)0;
                }
                for (g_614 = 0; (g_614 < (-11)); g_614 = safe_sub_func_uint8_t_u_u(g_614, 1))
                { /* block id: 1784 */
                    uint64_t *****l_4236 = &l_3998[4][0];
                    int8_t ***l_4244 = &g_1060;
                    int32_t l_4246 = 0x5935CB4BL;
                    int32_t *l_4254 = (void*)0;
                    int32_t *l_4255 = (void*)0;
                    int32_t *l_4256 = (void*)0;
                    int32_t *l_4257 = &g_241;
                    int64_t *l_4258 = &g_4027;
                    int16_t ****l_4267 = &g_1424;
                    int32_t l_4268 = 1L;
                    union U1 l_4317[8][5][6] = {{{{0xECL},{0x97L},{255UL},{6UL},{0x47L},{246UL}},{{250UL},{7UL},{248UL},{254UL},{0x47L},{0xCAL}},{{0x20L},{248UL},{0x27L},{255UL},{0x27L},{248UL}},{{0x96L},{0x82L},{1UL},{3UL},{0xB1L},{255UL}},{{0x82L},{8UL},{0x47L},{0x20L},{246UL},{0UL}}},{{{0xFDL},{8UL},{248UL},{250UL},{0xB1L},{0xB3L}},{{248UL},{0x58L},{0x54L},{0xE3L},{0x59L},{0xB9L}},{{0x97L},{0UL},{2UL},{250UL},{0xD5L},{2UL}},{{255UL},{0x72L},{255UL},{0xABL},{2UL},{2UL}},{{0x47L},{2UL},{251UL},{255UL},{0xDEL},{255UL}}},{{{7UL},{0x59L},{251UL},{253UL},{0x72L},{2UL}},{{247UL},{0x59L},{255UL},{248UL},{0x64L},{2UL}},{{248UL},{0x64L},{2UL},{0xCAL},{0x85L},{0xB9L}},{{252UL},{6UL},{0x54L},{0xD2L},{255UL},{0xB3L}},{{1UL},{0xB9L},{0UL},{255UL},{0UL},{1UL}}},{{{1UL},{251UL},{0xD5L},{255UL},{0xB3L},{1UL}},{{1UL},{0x40L},{0xB9L},{0xD2L},{1UL},{0UL}},{{252UL},{0xDEL},{0x59L},{0xCAL},{0x02L},{0x02L}},{{248UL},{1UL},{1UL},{248UL},{251UL},{7UL}},{{247UL},{1UL},{0UL},{253UL},{0xA7L},{255UL}}},{{{7UL},{2UL},{1UL},{255UL},{0xA7L},{0xD5L}},{{0x47L},{1UL},{0x64L},{0xABL},{251UL},{0x40L}},{{255UL},{1UL},{0xBDL},{250UL},{0x02L},{0x58L}},{{0x97L},{0xDEL},{1UL},{0xE3L},{1UL},{0x54L}},{{248UL},{0x40L},{6UL},{7UL},{0xB3L},{1UL}}},{{{0xE3L},{251UL},{0x85L},{0UL},{0UL},{1UL}},{{255UL},{0xB9L},{6UL},{0x47L},{255UL},{0x54L}},{{246UL},{6UL},{1UL},{0x47L},{0x85L},{0x58L}},{{0UL},{0x64L},{0xBDL},{0x27L},{0x64L},{0x40L}},{{1UL},{0x59L},{0x64L},{0xB1L},{0x72L},{0xD5L}}},{{{0xABL},{0x59L},{1UL},{246UL},{0xDEL},{255UL}},{{0xABL},{2UL},{0UL},{0xB1L},{2UL},{7UL}},{{1UL},{0x72L},{1UL},{0x27L},{0xD5L},{0x02L}},{{0UL},{0UL},{0x59L},{0x47L},{0x59L},{0UL}},{{246UL},{0x58L},{0xB9L},{0x47L},{0x40L},{1UL}}},{{{255UL},{0x86L},{0xD5L},{0UL},{7UL},{1UL}},{{0xE3L},{0x86L},{0UL},{7UL},{0x40L},{0xB3L}},{{248UL},{0x58L},{0x54L},{0xE3L},{0xD6L},{0x96L}},{{2UL},{255UL},{0x8CL},{0x85L},{0xECL},{0x8CL}},{{0UL},{0xB6L},{3UL},{255UL},{0x8CL},{0x21L}}}};
                    int i, j, k;
                    (*g_62) &= (safe_rshift_func_int16_t_s_s((safe_sub_func_int8_t_s_s((0x2E86EEEDL > l_4234), ((l_4236 = g_4235) == &l_3998[0][1]))), 11));
                    l_4260[4][6][2] ^= (l_4259 = ((!l_4223[1][5]) == (safe_div_func_int64_t_s_s(((*l_4258) ^= ((+l_4223[3][3]) & ((*g_878) < (l_4234 , (safe_rshift_func_uint8_t_u_u(((**g_4019) &= l_4243), (l_4244 != ((((safe_unary_minus_func_uint16_t_u(l_4246)) , (((*l_4257) ^= (((safe_sub_func_uint8_t_u_u((!(safe_mul_func_uint16_t_u_u((!(l_4253 , ((*g_62) = p_16))), p_15))), g_2586.f0)) >= l_4234) ^ (*g_1358))) , &g_3411)) == &g_1496) , (*l_3826))))))))), 2UL))));
                    (*g_62) = ((((safe_add_func_uint64_t_u_u((l_4268 &= (((*g_1998) = ((safe_mul_func_int64_t_s_s(0x78A7717FC3762908LL, 1L)) >= (((l_4246 , l_4259) == p_15) == 4L))) | ((l_4267 != (void*)0) >= 0x688562D1L))), p_15)) >= p_15) <= p_17) != l_4269);
                    for (l_3918 = 0; (l_3918 < 26); ++l_3918)
                    { /* block id: 1798 */
                        int32_t *l_4272 = &g_1578;
                        int32_t *l_4273 = &l_4260[7][3][0];
                        int32_t *l_4274 = (void*)0;
                        int32_t *l_4275 = &l_3658;
                        int32_t *l_4276 = &l_4246;
                        int32_t *l_4277 = &g_1256;
                        int32_t *l_4278[5] = {&l_3570,&l_3570,&l_3570,&l_3570,&l_3570};
                        uint8_t ***l_4314 = &l_4312;
                        int i;
                        ++l_4283;
                        (*l_4272) ^= (0x33205B11L | (safe_div_func_uint8_t_u_u((l_4260[4][6][2] = (~(+((((safe_div_func_int32_t_s_s(l_4253.f0, (safe_mul_func_int64_t_s_s((safe_div_func_int16_t_s_s(((*g_969) |= ((((safe_lshift_func_int64_t_s_s((safe_mul_func_uint64_t_u_u(((p_15 != ((safe_add_func_uint64_t_u_u(l_4253.f0, ((*l_4258) = 0x96A483540CBA326DLL))) ^ p_17)) ^ l_4246), (safe_add_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_u((l_4280[4] ^= 0x56L), 5)) >= (safe_mod_func_int8_t_s_s((safe_rshift_func_int32_t_s_s(((safe_rshift_func_uint64_t_u_s((((*l_4314) = l_4312) == (void*)0), (**g_1357))) , p_18), 22)), (*g_4020)))), p_15)))), 49)) == 18446744073709551606UL) < l_4315) & p_16)), l_4223[2][6])), (**g_1357))))) , (**g_4019)) >= p_17) >= l_4316[5][6])))), (-6L))));
                        return l_4317[7][1][0];
                    }
                }
            }
        }
        return (**g_3181);
    }
    else
    { /* block id: 1812 */
        int32_t * const l_4318[9][7] = {{&g_797,&g_1578,(void*)0,&g_614,&l_3659[0],&g_797,&g_1578},{&g_362,(void*)0,&g_362,&g_117,&g_362,&g_362,&g_117},{&g_1256,(void*)0,&g_1256,&g_1578,&g_797,&l_3659[0],&g_614},{(void*)0,&g_1578,(void*)0,&g_797,(void*)0,&g_797,&l_3838},{&g_797,&l_3599,&g_362,&g_63,&l_3659[0],&l_3659[0],&l_4192},{(void*)0,&g_1578,&g_797,(void*)0,&g_797,&g_362,&g_797},{(void*)0,&g_797,&g_797,(void*)0,&g_1578,&g_797,&g_362},{&g_63,&l_4192,&g_362,&g_797,&g_362,(void*)0,(void*)0},{&l_3599,(void*)0,(void*)0,&g_63,&g_1578,&l_3659[0],&g_362}};
        uint32_t *** const l_4328 = (void*)0;
        union U1 *****l_4396 = &l_4125[0];
        uint32_t **l_4486 = &g_1998;
        uint32_t ***l_4485 = &l_4486;
        const int32_t *l_4518[8][3] = {{&g_614,&l_3599,(void*)0},{(void*)0,(void*)0,&l_4192},{&g_614,&l_3599,(void*)0},{(void*)0,(void*)0,&l_4192},{&g_614,&l_3599,(void*)0},{(void*)0,(void*)0,&l_4192},{&g_614,&l_3599,(void*)0},{(void*)0,(void*)0,&l_4192}};
        uint16_t l_4553 = 0xCAD5L;
        int32_t l_4563 = (-3L);
        int i, j;
        if (p_16)
        { /* block id: 1813 */
            int32_t *l_4332[8] = {&g_1578,&g_1578,&g_1578,&g_1578,&g_1578,&g_1578,&g_1578,&g_1578};
            int i;
            for (g_2882 = 1; (g_2882 >= 0); g_2882 -= 1)
            { /* block id: 1816 */
                int32_t **l_4319[7] = {&l_3603,&l_3603,&l_3603,&l_3603,&l_3603,&l_3603,&l_3603};
                int32_t **l_4320 = &g_190;
                union U1 ****l_4324 = &g_3010;
                uint32_t ****l_4329 = (void*)0;
                uint32_t ****l_4330 = (void*)0;
                uint32_t ****l_4331 = &l_3747;
                uint64_t l_4335 = 0UL;
                int i;
                (**l_3732) = l_4332[3];
                (*g_62) = (safe_rshift_func_uint16_t_u_s((p_18 = ((*g_662) = l_4335)), (safe_add_func_int64_t_s_s((0x5DL <= (safe_rshift_func_int32_t_s_u(0x4BA94D47L, 22))), ((**l_3610) = p_15)))));
                for (g_75 = 0; (g_75 <= 1); g_75 += 1)
                { /* block id: 1828 */
                    int16_t l_4344 = 0L;
                    int64_t l_4347 = (-6L);
                    int32_t l_4348 = 0xD97C2517L;
                    int32_t l_4359 = 1L;
                    for (g_4100.f0 = 0; (g_4100.f0 <= 1); g_4100.f0 += 1)
                    { /* block id: 1831 */
                        int32_t l_4357 = 0L;
                        int32_t l_4358 = 1L;
                        int32_t l_4360 = 0x8DFBA48AL;
                        int32_t l_4361[2][10][10] = {{{9L,(-1L),(-8L),(-1L),9L,9L,(-1L),(-8L),(-1L),9L},{9L,(-1L),(-8L),(-1L),9L,9L,(-1L),(-8L),(-1L),9L},{9L,(-1L),(-8L),(-1L),9L,9L,(-1L),(-8L),(-1L),9L},{9L,(-1L),(-8L),(-1L),9L,9L,(-1L),(-8L),(-1L),9L},{9L,(-1L),(-8L),(-1L),9L,9L,(-1L),(-8L),(-1L),9L},{9L,(-1L),(-8L),(-1L),9L,9L,(-1L),(-8L),(-1L),9L},{9L,(-1L),(-8L),(-1L),9L,9L,(-1L),(-8L),(-1L),(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)}},{{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)},{(-1L),0L,0xC7108C09L,0L,(-1L),(-1L),0L,0xC7108C09L,0L,(-1L)}}};
                        int32_t l_4362 = 0L;
                        int i, j, k;
                        l_4357 = (((safe_rshift_func_uint16_t_u_u(((**l_4087)++), p_17)) , (l_4344 , (safe_div_func_int32_t_s_s(((((*g_4020) & 254UL) & ((*g_62) = (((((l_4347 = ((***l_3999) = (*g_1151))) || l_4348) == ((((251UL == (((safe_rshift_func_int32_t_s_s((((g_1939[g_2882] = (*g_1998)) && (safe_sub_func_int32_t_s_s((safe_lshift_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((p_18 != p_15) && p_15), p_17)), p_17)), p_16))) && p_15), p_15)) < 0xE3L) <= 1L)) & p_16) == l_4357) || 0xA0L)) & l_4344) > (**g_1357)))) || (**g_1357)), 0xA4E2C9A2L)))) && p_17);
                        l_4363[0]++;
                    }
                }
            }
        }
        else
        { /* block id: 1842 */
            union U0 *l_4368[7] = {&g_3058[1],&g_3058[1],&g_3058[1],&g_3058[1],&g_3058[1],&g_3058[1],&g_3058[1]};
            int32_t *l_4369[5] = {&g_117,&g_117,&g_117,&g_117,&g_117};
            int32_t **l_4371 = &g_190;
            int i;
            (*g_62) = (65535UL >= (safe_mod_func_int8_t_s_s((((**g_3707) = l_4368[2]) != (void*)0), (**g_731))));
            (*l_4371) = ((**l_3732) = l_4369[3]);
        }
        for (g_4028.f4 = 7; (g_4028.f4 > 28); g_4028.f4++)
        { /* block id: 1850 */
            uint32_t l_4376 = 1UL;
            int16_t ****l_4378 = &g_1424;
            int16_t *****l_4377 = &l_4378;
            int32_t l_4379 = 0x0FE7823CL;
            int32_t l_4380 = 0x61311F59L;
            int32_t l_4400[6][3] = {{0xF39FB40EL,0L,0xF39FB40EL},{0x69A8D6BBL,0xBD7057A6L,0x4CEE3298L},{0x69A8D6BBL,0x69A8D6BBL,0xBD7057A6L},{0xF39FB40EL,0xBD7057A6L,0xBD7057A6L},{0xBD7057A6L,0L,0x4CEE3298L},{0xF39FB40EL,0L,0xF39FB40EL}};
            uint32_t l_4415[4];
            uint32_t l_4459[2];
            int32_t *l_4515 = &g_4207.f4;
            int32_t *l_4522[4] = {&l_3659[0],&l_3659[0],&l_3659[0],&l_3659[0]};
            int i, j;
            for (i = 0; i < 4; i++)
                l_4415[i] = 0x4BCF4098L;
            for (i = 0; i < 2; i++)
                l_4459[i] = 6UL;
        }
    }
    for (l_4551 = 0; (l_4551 <= 1); l_4551 += 1)
    { /* block id: 1979 */
        int8_t **l_4607 = &g_4604;
        int32_t * const l_4620 = &g_1256;
        int32_t * const l_4624[2] = {&l_3570,&l_3570};
        int32_t *l_4625 = &l_3838;
        uint16_t *l_4670[9] = {&l_3882,&l_3882,&l_3882,&l_3882,&l_3882,&l_3882,&l_3882,&l_3882,&l_3882};
        union U1 l_4731 = {253UL};
        uint32_t l_4751[4][8] = {{0x34804F9BL,4294967293UL,4294967295UL,4294967293UL,0x34804F9BL,4294967293UL,4294967295UL,4294967293UL},{0x34804F9BL,4294967293UL,4294967295UL,4294967293UL,0x34804F9BL,4294967293UL,4294967295UL,4294967293UL},{0x34804F9BL,4294967293UL,4294967295UL,4294967293UL,0x34804F9BL,4294967293UL,4294967295UL,4294967293UL},{0x34804F9BL,4294967293UL,4294967295UL,4294967293UL,0x34804F9BL,4294967293UL,4294967295UL,4294967293UL}};
        int32_t *****l_4770[2];
        union U0 *l_4779 = &g_3058[3];
        uint8_t **l_4900 = (void*)0;
        uint16_t ** const *l_4913 = (void*)0;
        int8_t ****l_4932[5][10] = {{&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0},{&g_2897,(void*)0,&g_2897,(void*)0,&g_2897,(void*)0,&g_2897,(void*)0,&g_2897,(void*)0},{&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0},{&g_2897,(void*)0,&g_2897,(void*)0,&g_2897,(void*)0,&g_2897,(void*)0,&g_2897,(void*)0},{&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0,&g_1059,(void*)0}};
        int8_t ***** const l_4931 = &l_4932[2][0];
        uint32_t *****l_4961 = &g_4775[0][4][2];
        uint32_t *****l_4962 = &g_4775[0][4][2];
        uint32_t **l_4994 = &l_3749[0][1][4];
        volatile int32_t * volatile l_4998 = &g_203[6][4][1];/* VOLATILE GLOBAL l_4998 */
        union U1 ***l_4999 = &g_180;
        uint32_t ***l_5021 = (void*)0;
        int16_t l_5062 = (-1L);
        int32_t l_5091 = 0x5F885715L;
        int i, j;
        for (i = 0; i < 2; i++)
            l_4770[i] = &g_3832;
        for (l_4192 = 0; (l_4192 <= 1); l_4192 += 1)
        { /* block id: 1982 */
            uint32_t ****l_4609 = (void*)0;
            uint32_t *****l_4610 = &l_4609;
            int32_t l_4618 = 0x03B36FEEL;
            union U1 l_4622 = {0UL};
            int32_t l_4623 = 0x2ED76940L;
            int32_t l_4629 = 1L;
            int8_t l_4630 = 0x0DL;
            int32_t l_4633[4][8][2] = {{{1L,1L},{5L,1L},{1L,5L},{1L,1L},{5L,1L},{1L,5L},{1L,1L},{5L,1L}},{{1L,5L},{1L,1L},{5L,1L},{1L,5L},{1L,1L},{5L,1L},{1L,5L},{1L,1L}},{{5L,1L},{1L,5L},{1L,1L},{5L,1L},{1L,5L},{1L,1L},{5L,1L},{1L,5L}},{{1L,1L},{5L,1L},{1L,5L},{1L,1L},{5L,1L},{1L,5L},{1L,1L},{5L,1L}}};
            int i, j, k;
            l_4618 = (((safe_rshift_func_int16_t_s_u((((**g_2896) = g_4603[4][1]) == (((*g_62) = (safe_add_func_int64_t_s_s(((**l_3610) = (**g_4453)), 0UL))) , l_4607)), (+4294967295UL))) , (((*l_4610) = l_4609) != g_4611)) , ((safe_div_func_int16_t_s_s(((safe_add_func_uint32_t_u_u(((safe_mul_func_uint64_t_u_u(0UL, 0x39EB62D55C429A0FLL)) ^ (*g_1358)), p_17)) == 0x88B9L), p_15)) && l_4618));
            for (g_1578 = 0; (g_1578 <= 1); g_1578 += 1)
            { /* block id: 1990 */
                int32_t * const l_4619 = &g_1578;
                int32_t l_4626 = 2L;
                int32_t l_4627 = 1L;
                int32_t l_4628 = 0x67C25602L;
                int32_t l_4631 = (-1L);
                int32_t l_4634 = (-1L);
                int32_t l_4635 = 0x758AF71CL;
                int32_t l_4636[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_4636[i] = (-1L);
                (**l_3732) = l_4625;
                l_4637++;
            }
        }
        for (l_3658 = 1; (l_3658 >= 0); l_3658 -= 1)
        { /* block id: 1998 */
            int64_t l_4652 = (-1L);
            uint32_t *l_4656 = (void*)0;
            uint32_t *l_4657 = &l_3839;
            int32_t l_4715 = 0xD1A43B2DL;
            uint8_t l_4740 = 254UL;
            uint32_t *****l_4777 = &g_4775[0][4][2];
            int32_t l_4780 = 0x9F7A4396L;
            int32_t l_4781 = (-1L);
            int32_t l_4782 = 0L;
            int32_t l_4783 = 0x7198ECC7L;
            int32_t l_4784 = 0x3653626FL;
            uint64_t *l_4838 = &g_321;
            uint64_t l_4844 = 18446744073709551615UL;
            union U1 l_4866 = {255UL};
            const union U1 l_4909 = {0xD9L};
            int8_t ***l_5019 = &g_4603[8][2];
            uint32_t ***l_5020 = &l_3748;
            const int32_t *l_5022 = &l_4784;
            uint64_t l_5043 = 0xCE6E0EEFF1D3D2D0LL;
            const uint16_t *l_5055 = &g_4164[3][2][6];
            union U0 **l_5098 = &g_924;
            union U1 **l_5113[8][1][8] = {{{&l_5086,&g_181,(void*)0,&l_5086,&l_5086,(void*)0,&g_181,&l_5086}},{{(void*)0,&l_5086,&g_181,&g_181,&l_5086,&g_181,&g_181,(void*)0}},{{&l_5086,&g_181,&l_5086,&l_5086,&g_181,&g_181,&g_181,&l_5086}},{{&g_181,&l_5086,&g_181,&g_181,&g_181,(void*)0,&g_181,(void*)0}},{{&l_5086,&g_181,&g_181,&g_181,&l_5086,&l_5086,&g_181,&g_181}},{{&l_5086,&g_181,&l_5086,&l_5086,&g_181,&l_5086,&l_5086,(void*)0}},{{&g_181,&l_5086,&l_5086,&l_5086,&g_181,&l_5086,(void*)0,&l_5086}},{{&l_5086,(void*)0,&l_5086,(void*)0,&l_5086,(void*)0,&l_5086,&l_5086}}};
            int i, j, k;
        }
    }
    return (**l_5085);
}


/* ------------------------------------------ */
/* 
 * reads : g_969 g_613 g_732 g_733 g_62 g_63 g_662 g_267 g_1358 g_846 g_827 g_828 g_2586.f0 g_2267 g_1681 g_1151 g_764 g_1998 g_1939 g_1997 g_1329 g_362 g_1357 g_1256 g_75 g_85 g_430 g_117 g_203 g_904 g_1732 g_968 g_797 g_2957 g_2958 g_825 g_826 g_614 g_878 g_689 g_3015 g_180 g_3033 g_3058 g_3069 g_1578 g_2585 g_2586 g_876 g_877 g_746 g_80 g_971 g_2882 g_1191.f4 g_560.f0 g_3164 g_1625 g_3212 g_527 g_731 g_3224 g_3225 g_3255 g_875 g_571 g_2511.f0 g_3286 g_308.f0 g_1411.f4 g_3294 g_3302 g_3164.f0 g_2582 g_2583 g_3323 g_3324 g_3325 g_3326 g_321 g_181 g_3180 g_3181 g_3182 g_3411 g_3418 g_2962 g_201 g_3520 g_3523 g_2486 g_2487 g_3548 g_2311.f0 g_3567 g_822.f4
 * writes: g_822.f4 g_31 g_1658 g_904 g_613 g_596 g_190 g_1496 g_63 g_571 g_2586.f0 g_924 g_846 g_746 g_1681 g_75 g_1329 g_2882 g_1191.f4 g_1497.f4 g_201 g_430 g_797 g_85 g_1256 g_117 g_2895 g_203 g_267 g_1939 g_2948 g_2957 g_764 g_241 g_527 g_1427 g_1411.f4 g_181 g_55.f0 g_1935 g_1139 g_1578 g_847 g_1164.f4 g_1088 g_3178 g_308.f0 g_3323 g_321 g_3286 g_3183 g_80
 */
static uint32_t  func_21(union U1  p_22, const uint8_t  p_23, uint8_t  p_24)
{ /* block id: 1114 */
    uint16_t l_2762 = 0x163BL;
    union U0 ***l_2787 = &g_2267;
    union U0 ****l_2786 = &l_2787;
    uint32_t *l_2795 = &g_1939[1];
    union U0 *l_2824 = &g_123;
    int32_t l_2831 = 0x0D2B9DF8L;
    int8_t *l_2866 = &g_1329;
    uint32_t l_2885[10] = {0xCF2C2DCBL,0xA927656AL,0UL,0xA927656AL,0xCF2C2DCBL,0xCF2C2DCBL,0xA927656AL,0UL,0xA927656AL,0xCF2C2DCBL};
    int8_t **** const l_2894 = (void*)0;
    int8_t **** const *l_2893[8][9] = {{&l_2894,(void*)0,(void*)0,(void*)0,&l_2894,&l_2894,(void*)0,&l_2894,&l_2894},{(void*)0,(void*)0,(void*)0,&l_2894,(void*)0,&l_2894,(void*)0,&l_2894,(void*)0},{&l_2894,&l_2894,&l_2894,&l_2894,(void*)0,&l_2894,&l_2894,(void*)0,(void*)0},{&l_2894,(void*)0,&l_2894,(void*)0,(void*)0,&l_2894,(void*)0,&l_2894,&l_2894},{&l_2894,(void*)0,&l_2894,&l_2894,(void*)0,&l_2894,(void*)0,(void*)0,&l_2894},{&l_2894,(void*)0,(void*)0,(void*)0,&l_2894,&l_2894,(void*)0,&l_2894,&l_2894},{(void*)0,(void*)0,(void*)0,&l_2894,(void*)0,&l_2894,(void*)0,&l_2894,(void*)0},{&l_2894,&l_2894,&l_2894,&l_2894,(void*)0,&l_2894,&l_2894,(void*)0,(void*)0}};
    int32_t l_2961 = 1L;
    uint32_t l_2963 = 18446744073709551614UL;
    int8_t l_2994 = 0x7CL;
    union U1 l_2997 = {1UL};
    uint16_t l_2998 = 0x4BDEL;
    union U1 ** const *l_3005[10][1][4] = {{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}},{{&g_180,&g_180,&g_180,&g_180}}};
    int32_t *l_3145 = (void*)0;
    union U1 * const * const *l_3176 = (void*)0;
    union U1 * const * const **l_3175[5];
    union U1 * const * const ***l_3174 = &l_3175[4];
    uint16_t **l_3194 = (void*)0;
    int32_t l_3242 = 0L;
    uint32_t l_3285 = 0xAA147F40L;
    const uint16_t *l_3331[9] = {&g_267,&g_267,&g_267,&g_267,&g_267,&g_267,&g_267,&g_267,&g_267};
    int32_t l_3339[6][10] = {{(-1L),(-5L),(-5L),(-1L),0L,(-1L),(-5L),(-5L),(-1L),0L},{(-1L),(-5L),(-5L),(-1L),0L,(-1L),(-5L),(-5L),(-1L),0L},{(-1L),(-5L),(-5L),(-1L),0L,(-1L),(-5L),(-5L),(-1L),0L},{(-1L),(-5L),(-5L),(-1L),0L,(-1L),(-5L),(-5L),(-1L),0L},{(-1L),(-5L),(-5L),(-1L),0L,(-1L),(-5L),(-5L),(-1L),0L},{(-1L),(-5L),(-5L),(-1L),0L,1L,(-1L),(-1L),1L,0x4EADF9BCL}};
    int16_t l_3341[2];
    uint16_t l_3349 = 0UL;
    int8_t l_3364 = 4L;
    int32_t **l_3389 = (void*)0;
    int32_t ***l_3388 = &l_3389;
    uint64_t l_3439 = 0x2D99D6635EA3839ELL;
    union U0 *****l_3505 = &l_2786;
    int8_t l_3549 = 0x20L;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_3175[i] = &l_3176;
    for (i = 0; i < 2; i++)
        l_3341[i] = (-3L);
lbl_3316:
    for (g_822.f4 = 7; (g_822.f4 >= 0); g_822.f4 -= 1)
    { /* block id: 1117 */
        int16_t l_2767[10] = {0xCACCL,0xCACCL,0xCACCL,0xCACCL,0xCACCL,0xCACCL,0xCACCL,0xCACCL,0xCACCL,0xCACCL};
        uint64_t l_2782 = 1UL;
        int16_t l_2783 = 0x4FB4L;
        union U0 *l_2823 = &g_1191;
        uint16_t l_2874 = 6UL;
        int32_t l_2877 = 0x9EF41A72L;
        int32_t l_2884 = 0x8843E94BL;
        int i;
        for (g_31 = 1; (g_31 <= 7); g_31 += 1)
        { /* block id: 1120 */
            uint8_t *l_2771 = &g_1658[0];
            uint8_t *l_2774 = &g_613;
            int32_t l_2779 = 0x39585662L;
            if ((l_2762 <= (safe_sub_func_uint64_t_u_u((safe_sub_func_int16_t_s_s((l_2767[3] , (!(safe_mod_func_int8_t_s_s(p_23, (((*l_2771) = l_2767[0]) ^ 8L))))), ((*g_969) = 0x295AL))), (safe_add_func_uint64_t_u_u((((*l_2774)--) == (safe_div_func_uint8_t_u_u(p_22.f0, ((0x7DL <= ((p_24 , (-7L)) && (*g_732))) & l_2779)))), p_24))))))
            { /* block id: 1124 */
                for (g_596 = 0; (g_596 <= 7); g_596 += 1)
                { /* block id: 1127 */
                    int32_t **l_2780 = &g_190;
                    (*l_2780) = (void*)0;
                    for (g_1496 = 2; (g_1496 <= 7); g_1496 += 1)
                    { /* block id: 1131 */
                        (*g_62) ^= p_22.f0;
                    }
                }
            }
            else
            { /* block id: 1135 */
                int32_t l_2781 = 0xA6764E20L;
                if (l_2781)
                    break;
                for (g_571 = 0; (g_571 <= 7); g_571 += 1)
                { /* block id: 1139 */
                    return p_22.f0;
                }
            }
        }
        if (l_2782)
            continue;
        if (((((*g_662) , l_2783) != ((safe_mod_func_int16_t_s_s((((*g_1358) >= (((l_2786 != (void*)0) < ((((safe_sub_func_uint32_t_u_u((safe_add_func_uint8_t_u_u((safe_unary_minus_func_uint32_t_u((l_2762 || 0x91F4L))), (safe_lshift_func_int32_t_s_u((l_2795 != (void*)0), l_2762)))), p_23)) , p_23) != l_2762) , 5UL)) != l_2783)) <= l_2767[3]), l_2767[4])) , (*g_827))) == p_24))
        { /* block id: 1145 */
            int32_t l_2808 = 1L;
            uint8_t *l_2809 = &g_2586.f0;
            uint8_t *l_2818 = &g_1658[0];
            int8_t **l_2825 = (void*)0;
            int64_t *l_2826 = (void*)0;
            int64_t *l_2827 = &g_746;
            const uint16_t l_2828 = 0x8CF2L;
            int16_t *l_2829 = &g_1681[0][1];
            int32_t l_2830[9] = {0xBD99BB7EL,0xBD99BB7EL,0xBD99BB7EL,0xBD99BB7EL,0xBD99BB7EL,0xBD99BB7EL,0xBD99BB7EL,0xBD99BB7EL,0xBD99BB7EL};
            int i;
            l_2831 |= (safe_mod_func_uint32_t_u_u(((((*g_62) |= 5L) , ((((*g_662) >= (safe_lshift_func_uint8_t_u_s((safe_lshift_func_int32_t_s_s(((*g_62) ^= (safe_mod_func_uint16_t_u_u(((safe_mul_func_uint32_t_u_u(((safe_mod_func_uint32_t_u_u(((((l_2808 >= (((*l_2809)--) != (0x83EE2227L && ((((safe_mod_func_int8_t_s_s(((l_2808 || (safe_rshift_func_int16_t_s_u(((*g_969) = p_23), 6))) & (safe_sub_func_int8_t_s_s((-1L), ((*l_2818) = p_23)))), ((safe_sub_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((l_2830[7] |= ((*l_2829) ^= (((*l_2827) = ((*g_1358) ^= (((((*g_2267) = l_2823) != l_2824) , (void*)0) != l_2825))) < l_2828))), 1UL)), (*g_1151))) , l_2762))) || p_23) > 0x96E61A8A0F5BF3B9LL) == l_2762)))) <= l_2762) , 0xEB1BD8D8L) | p_24), l_2783)) > 0x8414C053C6102A21LL), p_22.f0)) < (*g_1998)), 2L))), p_24)), l_2762))) <= p_23) && l_2762)) , 0x8621FC1AL), p_22.f0));
        }
        else
        { /* block id: 1157 */
            int32_t *l_2833[8];
            int8_t *l_2881 = &g_2882;
            int32_t l_2883 = (-1L);
            int i;
            for (i = 0; i < 8; i++)
                l_2833[i] = &g_63;
            if (l_2783)
                break;
            for (g_75 = 1; (g_75 <= 7); g_75 += 1)
            { /* block id: 1161 */
                union U0 *l_2832 = (void*)0;
                uint32_t *l_2868 = &g_1935;
                int32_t l_2871 = 0x8D72D8F0L;
                (**l_2787) = l_2832;
            }
            if ((l_2884 = (safe_rshift_func_int64_t_s_u((((*l_2881) = ((l_2782 , (((*l_2866) ^= (l_2762 ^ (**g_1997))) <= ((((((((((l_2877 = (l_2874++)) , (((~l_2762) < ((l_2783 & g_362) <= (p_24 <= ((safe_div_func_int64_t_s_s(((**g_1357) = 0xE7FA2B54AEE330D2LL), (*g_1151))) == p_22.f0)))) , g_1256)) <= l_2783) >= 0xB3A69C49E455D2B0LL) | l_2762) == 0x1D91E8C78AAB1787LL) | l_2762) <= 0x8BBA93F2L) , 0x4CL) >= p_23))) >= p_24)) >= l_2883), 10))))
            { /* block id: 1188 */
                l_2885[2]++;
            }
            else
            { /* block id: 1190 */
                for (g_1191.f4 = 0; g_1191.f4 < 10; g_1191.f4 += 1)
                {
                    for (g_1497.f4 = 0; g_1497.f4 < 10; g_1497.f4 += 1)
                    {
                        for (g_201 = 0; g_201 < 2; g_201 += 1)
                        {
                            g_430[g_1191.f4][g_1497.f4][g_201] = (-1L);
                        }
                    }
                }
            }
        }
    }
    for (g_797 = 1; (g_797 >= 0); g_797 -= 1)
    { /* block id: 1197 */
        const uint32_t l_2900 = 4294967290UL;
        int32_t l_2906 = (-2L);
        volatile int32_t *l_2911 = &g_201;
        int64_t l_2943 = 1L;
        uint8_t *l_2985 = &g_613;
        int32_t *l_2986 = &g_113.f4;
        int32_t *l_2987 = &g_113.f4;
        int32_t *l_2988 = &g_117;
        uint64_t **l_2992 = &g_1151;
        uint64_t **l_2993[4];
        int32_t ***l_3004[1];
        union U1 l_3011 = {0xBBL};
        uint8_t l_3012 = 255UL;
        int i;
        for (i = 0; i < 4; i++)
            l_2993[i] = (void*)0;
        for (i = 0; i < 1; i++)
            l_3004[i] = (void*)0;
        for (g_85 = 0; (g_85 <= 0); g_85 += 1)
        { /* block id: 1200 */
            uint16_t l_2908 = 3UL;
            int32_t l_2960[3];
            int i;
            for (i = 0; i < 3; i++)
                l_2960[i] = 0x253BFF9FL;
            (*g_62) = p_24;
            for (g_1256 = 0; (g_1256 <= 1); g_1256 += 1)
            { /* block id: 1204 */
                uint32_t l_2926 = 1UL;
                uint32_t *l_2954 = (void*)0;
                uint32_t **l_2953 = &l_2954;
                int32_t *l_2959[8];
                int i, j, k;
                for (i = 0; i < 8; i++)
                    l_2959[i] = &g_117;
                for (g_75 = 0; (g_75 <= 1); g_75 += 1)
                { /* block id: 1207 */
                    int8_t l_2907 = 1L;
                    int i, j, k;
                    for (g_117 = 0; (g_117 <= 0); g_117 += 1)
                    { /* block id: 1210 */
                        int32_t *l_2901 = &g_63;
                        int32_t *l_2902 = &g_1578;
                        int32_t *l_2903 = &g_362;
                        int32_t *l_2904 = &l_2831;
                        int32_t *l_2905[9];
                        int i, j, k;
                        for (i = 0; i < 9; i++)
                            l_2905[i] = &g_63;
                        g_203[(g_117 + 4)][(g_75 + 2)][g_75] = ((g_430[(g_75 + 3)][(g_85 + 7)][g_85] || (safe_lshift_func_int32_t_s_s((safe_sub_func_int64_t_s_s((!(((g_2895[0] = l_2893[3][7]) != &g_2896) | (safe_mod_func_uint8_t_u_u((g_203[(g_1256 + 2)][(g_117 + 4)][g_1256] <= l_2900), 255UL)))), 0L)), 3))) != p_23);
                        --l_2908;
                    }
                    l_2911 = &g_203[(g_85 + 7)][g_75][g_797];
                    for (l_2831 = 0; (l_2831 <= 7); l_2831 += 1)
                    { /* block id: 1218 */
                        int i, j, k;
                        g_203[l_2831][(g_85 + 2)][g_1256] = (((safe_lshift_func_uint32_t_u_s(1UL, (safe_rshift_func_uint64_t_u_u(((g_430[(g_1256 + 5)][(g_1256 + 2)][g_75] != (*g_969)) >= ((*g_1732) |= l_2762)), (l_2926 = (safe_div_func_uint64_t_u_u((((safe_add_func_uint32_t_u_u((((1L | ((safe_add_func_uint16_t_u_u((safe_add_func_int8_t_s_s(1L, (((safe_mod_func_int32_t_s_s(0x893A0ACDL, p_22.f0)) | ((**g_968) != l_2906)) == 1UL))), p_23)) , p_22.f0)) | 9UL) | (*g_62)), p_24)) ^ (*g_1998)) > 0x2FL), p_23))))))) <= (**g_1357)) > 249UL);
                    }
                    for (g_267 = 0; (g_267 <= 0); g_267 += 1)
                    { /* block id: 1225 */
                        uint16_t *l_2955 = &l_2762;
                        uint8_t *l_2956 = &g_613;
                        int i, j, k;
                        g_203[(g_797 + 2)][(g_85 + 6)][(g_797 + 1)] = (safe_mul_func_int64_t_s_s((((*l_2956) = (safe_add_func_int16_t_s_s((~g_430[g_85][(g_1256 + 3)][(g_85 + 1)]), ((*l_2955) = ((++(**g_1997)) >= ((0x6C0CL || (safe_mul_func_uint32_t_u_u((+((safe_sub_func_uint32_t_u_u((safe_mod_func_uint32_t_u_u(((((*g_62) = (safe_mod_func_uint32_t_u_u(p_23, l_2943))) || p_24) && p_23), (safe_mod_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u(0x44E141A7L, ((g_2948 = (void*)0) == (((((((safe_lshift_func_uint8_t_u_s((safe_add_func_int16_t_s_s(0x8411L, p_23)), 6)) != (**g_1357)) < 255UL) , l_2953) != (void*)0) , 0xC946L) , (void*)0)))) | g_2586.f0), 0x92L)))), p_22.f0)) <= p_22.f0)), p_22.f0))) | p_24)))))) <= l_2943), l_2926));
                        (*g_2958) = g_2957;
                    }
                }
                l_2963--;
            }
        }
        (*l_2988) |= (~(safe_add_func_uint32_t_u_u(((*g_1998) = (safe_mul_func_uint64_t_u_u(((*g_1151) = ((*g_1998) || ((*g_62) |= ((l_2831 &= ((((safe_mul_func_int8_t_s_s(0xD1L, 0x8DL)) ^ (safe_rshift_func_int64_t_s_s(0xA0EA45F520571C9FLL, 61))) || ((65530UL < ((*g_1358) <= (248UL != ((*l_2985) ^= (safe_rshift_func_uint8_t_u_s(((((p_24 ^ (safe_lshift_func_int8_t_s_u((safe_sub_func_uint64_t_u_u((safe_div_func_uint64_t_u_u(((((((0UL < p_23) , p_24) <= p_23) && p_23) >= l_2885[0]) , (***g_825)), l_2906)), l_2943)), g_614))) != l_2961) , 0x2BL) | g_1939[1]), 1)))))) != 18446744073709551615UL)) | 0xC3930D0FL)) , p_23)))), p_23))), p_23)));
        l_2998 = (((((((+(0x2BA4BB1F5EDC4BCDLL == (((0x7921B041L == (safe_add_func_uint64_t_u_u((1L ^ ((l_2992 == (l_2993[1] = &g_1151)) | l_2994)), 0xF840A09781AE2441LL))) , l_2997) , (**g_1357)))) || l_2762) == (*l_2988)) != l_2885[2]) < p_24) & (*g_1358)) || p_24);
        if (p_22.f0)
            break;
        for (g_241 = 1; (g_241 >= 0); g_241 -= 1)
        { /* block id: 1249 */
            int16_t l_3001 = 0L;
            union U1 l_3009[9][6] = {{{0x13L},{0x39L},{0x41L},{0x37L},{0x67L},{1UL}},{{0x39L},{5UL},{0x67L},{0x46L},{1UL},{1UL}},{{0x39L},{252UL},{0x46L},{0x37L},{0x46L},{252UL}},{{0x13L},{0x67L},{255UL},{249UL},{252UL},{0x41L}},{{0x74L},{0UL},{0x37L},{255UL},{0x87L},{0x46L}},{{249UL},{0UL},{0x49L},{252UL},{252UL},{0x49L}},{{0x67L},{0x67L},{0UL},{0x1FL},{0x46L},{0x39L}},{{5UL},{252UL},{1UL},{0x74L},{1UL},{0UL}},{{0x87L},{5UL},{1UL},{0x39L},{0x67L},{0x39L}}};
            int32_t *l_3032[1][9][9] = {{{(void*)0,&g_241,(void*)0,&g_596,&g_430[8][4][0],(void*)0,&g_596,&g_241,&g_822.f4},{&g_822.f4,&g_430[8][4][0],&g_430[8][4][0],&g_430[8][4][0],(void*)0,&g_596,&g_430[8][4][0],&g_596,(void*)0},{&g_596,&g_430[8][4][0],&g_430[8][4][0],&g_596,&g_430[8][4][0],&g_822.f4,(void*)0,&g_430[8][4][0],&g_596},{&g_241,&g_822.f4,&g_430[8][4][0],&g_430[8][4][0],(void*)0,&g_430[8][4][0],&g_596,&g_596,&g_430[8][4][0]},{&g_430[8][4][0],&g_596,&g_596,&g_596,&g_430[8][4][0],&g_430[8][4][0],(void*)0,&g_596,&g_430[8][4][0]},{&g_430[8][4][0],&g_241,&g_596,&g_241,(void*)0,&g_822.f4,&g_822.f4,&g_241,&g_822.f4},{&g_430[8][4][0],&g_430[8][4][0],(void*)0,(void*)0,&g_430[8][4][0],&g_430[8][4][0],&g_241,&g_430[8][4][0],&g_430[5][2][1]},{(void*)0,&g_596,&g_241,(void*)0,&g_822.f4,&g_430[8][4][0],(void*)0,&g_430[8][4][0],&g_430[8][4][0]},{&g_241,&g_822.f4,&g_822.f4,&g_596,&g_822.f4,&g_822.f4,&g_241,(void*)0,(void*)0}}};
            int i, j, k;
            for (g_527 = 0; (g_527 <= 1); g_527 += 1)
            { /* block id: 1252 */
                for (g_822.f4 = 0; g_822.f4 < 7; g_822.f4 += 1)
                {
                    g_1427[g_822.f4] = (void*)0;
                }
            }
            (*l_2911) = (safe_lshift_func_int64_t_s_u((p_22 , l_3012), (*g_878)));
            (*l_2911) = (((safe_lshift_func_int8_t_s_u((g_3015 , (safe_sub_func_uint16_t_u_u(((*g_1732) &= 0x66BCL), (((((safe_mul_func_uint64_t_u_u(((!((p_23 ^ 0x2563L) || (safe_unary_minus_func_uint32_t_u((safe_add_func_uint32_t_u_u((--(*l_2795)), (safe_lshift_func_uint8_t_u_s((p_23 , ((((safe_mod_func_uint8_t_u_u(255UL, p_24)) & l_3001) || ((safe_lshift_func_int32_t_s_s(((*g_62) = ((((*l_2988) <= 0x5C82E099DC2932FDLL) , l_3032[0][8][7]) == (void*)0)), p_24)) > 0x1829CEFB51699DD5LL)) ^ l_3009[6][0].f0)), l_3001)))))))) <= (*g_1151)), (*g_827))) >= p_23) >= (*l_2988)) == 1UL) ^ 0x27364839L)))), 1)) != (**g_1357)) , l_3001);
            for (g_1411.f4 = 0; (g_1411.f4 <= 1); g_1411.f4 += 1)
            { /* block id: 1266 */
                (*l_2988) |= ((*g_1732) && p_22.f0);
            }
        }
    }
    (*g_180) = &p_22;
    for (g_2882 = 0; (g_2882 >= 0); g_2882 -= 1)
    { /* block id: 1274 */
        uint32_t l_3044[6] = {18446744073709551615UL,0xB06FF22EL,18446744073709551615UL,18446744073709551615UL,0xB06FF22EL,18446744073709551615UL};
        uint64_t *l_3065 = &g_321;
        int32_t *l_3072 = &g_1578;
        uint64_t l_3091[3][3];
        uint32_t *l_3143 = (void*)0;
        uint32_t **l_3142[7][1][1] = {{{&l_3143}},{{&l_3143}},{{&l_3143}},{{&l_3143}},{{&l_3143}},{{&l_3143}},{{&l_3143}}};
        uint32_t l_3191 = 0x145BC8E6L;
        uint32_t **l_3211 = &g_1998;
        uint32_t ***l_3210 = &l_3211;
        int16_t l_3213 = 0xF960L;
        uint64_t l_3228 = 0x2AE5363650FE79E0LL;
        int32_t **l_3253 = &g_484;
        int32_t *** const l_3252[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t *l_3257 = &g_63;
        int16_t ****l_3291[2][7][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}}};
        int8_t *l_3295 = (void*)0;
        int32_t l_3336 = 0L;
        int32_t l_3337[6] = {0x34B46A8EL,0x34B46A8EL,0x34B46A8EL,0x34B46A8EL,0x34B46A8EL,0x34B46A8EL};
        uint32_t l_3342 = 1UL;
        union U1 l_3354 = {247UL};
        uint32_t l_3359 = 0x2F0D6701L;
        union U0 **l_3375 = &g_924;
        union U0 ****l_3417 = &l_2787;
        uint16_t l_3436 = 0x4BD7L;
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 3; j++)
                l_3091[i][j] = 18446744073709551615UL;
        }
        for (g_1411.f4 = 2; (g_1411.f4 >= 0); g_1411.f4 -= 1)
        { /* block id: 1277 */
            uint64_t l_3041 = 18446744073709551615UL;
            int32_t * const *l_3089 = (void*)0;
            int32_t l_3090 = (-1L);
            uint32_t l_3126 = 0x823F2740L;
            const union U0 *l_3146 = &g_822;
            int64_t l_3161[2][2][9] = {{{0xCF02193DEF16B13CLL,(-1L),0L,(-1L),0xCF02193DEF16B13CLL,0xF997BEF50005582CLL,0xF81346A56731AAD3LL,(-4L),(-4L)},{(-1L),(-3L),0xCF02193DEF16B13CLL,(-4L),0xCF02193DEF16B13CLL,(-3L),(-1L),0xBB076520AEF351B0LL,0xC54D1310F6FE04ACLL}},{{0x54B0AD9458845447LL,0xC54D1310F6FE04ACLL,(-1L),0xF997BEF50005582CLL,0xBB076520AEF351B0LL,0xF997BEF50005582CLL,(-1L),0xC54D1310F6FE04ACLL,0x54B0AD9458845447LL},{(-3L),0xF997BEF50005582CLL,0x54B0AD9458845447LL,0xBB076520AEF351B0LL,0xF81346A56731AAD3LL,0xCF02193DEF16B13CLL,0xF81346A56731AAD3LL,0xBB076520AEF351B0LL,0x54B0AD9458845447LL}}};
            uint8_t *l_3199 = &g_1658[0];
            int i, j, k;
            if (((g_3033 , ((safe_lshift_func_int32_t_s_s(1L, ((*g_62) = (safe_mod_func_uint32_t_u_u(l_2885[2], p_23))))) , ((void*)0 != &g_1087))) >= (+(safe_sub_func_uint16_t_u_u(l_3041, (safe_sub_func_int8_t_s_s(p_23, l_3041)))))))
            { /* block id: 1279 */
                return p_24;
            }
            else
            { /* block id: 1281 */
                uint32_t l_3066 = 0x315612C2L;
                uint16_t *l_3077 = &l_2762;
                int32_t ***l_3086 = (void*)0;
                int32_t **l_3088 = &g_190;
                int32_t ***l_3087 = &l_3088;
                uint8_t *l_3092 = &g_2586.f0;
                int32_t **l_3154[2];
                int32_t l_3167 = (-3L);
                union U1 ** const **l_3185 = &l_3005[6][0][0];
                union U1 ** const ***l_3184 = &l_3185;
                uint64_t *l_3188[5];
                uint32_t *l_3189[5] = {&l_3044[4],&l_3044[4],&l_3044[4],&l_3044[4],&l_3044[4]};
                int i;
                for (i = 0; i < 2; i++)
                    l_3154[i] = &g_484;
                for (i = 0; i < 5; i++)
                    l_3188[i] = &l_3091[2][0];
                for (l_3041 = 1; (l_3041 <= 7); l_3041 += 1)
                { /* block id: 1284 */
                    if ((*g_62))
                        break;
                    if (p_24)
                        continue;
                    for (g_55.f0 = 0; (g_55.f0 <= 2); g_55.f0 += 1)
                    { /* block id: 1289 */
                        return l_3044[4];
                    }
                }
                if ((safe_add_func_uint64_t_u_u((((safe_add_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((safe_rshift_func_int32_t_s_s((~(safe_mul_func_uint8_t_u_u(((((*g_662) |= l_3041) <= (((*l_3092) |= (safe_rshift_func_int32_t_s_s((g_3058[1] , ((safe_rshift_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((g_571 = (safe_sub_func_int8_t_s_s((l_3066 = ((void*)0 != l_3065)), ((safe_mod_func_int8_t_s_s((g_3069[4] , (safe_mul_func_uint32_t_u_u((l_3072 != ((safe_rshift_func_int64_t_s_u((safe_sub_func_int32_t_s_s(((((*l_3077) ^= p_22.f0) != (safe_rshift_func_uint64_t_u_s(((safe_sub_func_uint64_t_u_u((3UL != (((**g_1357) ^= (safe_div_func_int8_t_s_s((safe_sub_func_int16_t_s_s(((((*l_3087) = &g_1139[0]) != l_3089) <= (**g_826)), (-3L))), p_22.f0))) != l_3090)), l_3091[0][0])) && p_24), (*l_3072)))) & p_24), 1L)), 2)) , (void*)0)), l_2997.f0))), l_2994)) , 0x9BL)))), p_23)), 4)) <= p_23)), p_23))) || 0x8EL)) != p_22.f0), (*l_3072)))), p_22.f0)), p_22.f0)), 6UL)) <= p_24) >= (*g_969)), (*l_3072))))
                { /* block id: 1300 */
                    uint32_t l_3122[6][8][5] = {{{0xE52A5779L,0x524827E9L,0x034E17DBL,0xE0C5A0DEL,0xE0C5A0DEL},{0x4B9BA959L,1UL,0x4B9BA959L,0x3F22070DL,0UL},{0x034E17DBL,0x524827E9L,0xE52A5779L,0UL,0x488010CFL},{4294967295UL,4294967295UL,0UL,4294967295UL,0x4B9BA959L},{4294967295UL,4294967291UL,0xE52A5779L,0x488010CFL,0x524827E9L},{0UL,4294967295UL,0x4B9BA959L,4294967295UL,0UL},{4294967291UL,0UL,0x034E17DBL,0x488010CFL,0x016919F1L},{4294967290UL,0x6E1A9BF0L,4294967295UL,4294967295UL,1UL}},{{0xE0C5A0DEL,0xE52A5779L,4294967295UL,0UL,0x016919F1L},{0xC3DEC5D0L,4294967295UL,0UL,0x3F22070DL,0UL},{0x016919F1L,0x016919F1L,4294967291UL,0xE0C5A0DEL,0x524827E9L},{0xC3DEC5D0L,0x3C64F2ACL,4294967290UL,0xBC6E5A1FL,0x4B9BA959L},{0xE0C5A0DEL,0x593AD144L,0xE0C5A0DEL,0UL,0x488010CFL},{4294967290UL,0x3C64F2ACL,0xC3DEC5D0L,0x6E1A9BF0L,0UL},{4294967291UL,0x016919F1L,0x016919F1L,4294967291UL,0xE0C5A0DEL},{0UL,4294967295UL,0xC3DEC5D0L,0xB21EB06BL,1UL}},{{4294967295UL,0xE52A5779L,0xE0C5A0DEL,0xE52A5779L,4294967295UL},{4294967295UL,0x6E1A9BF0L,4294967290UL,0xB21EB06BL,0UL},{0x034E17DBL,0UL,4294967291UL,4294967291UL,0UL},{0x4B9BA959L,4294967295UL,0UL,0x6E1A9BF0L,0UL},{0xE52A5779L,4294967291UL,4294967295UL,0UL,4294967295UL},{0UL,4294967295UL,4294967295UL,0xBC6E5A1FL,1UL},{0xE52A5779L,0x524827E9L,0x034E17DBL,0xE0C5A0DEL,0xE0C5A0DEL},{0x4B9BA959L,1UL,0x4B9BA959L,0x3F22070DL,0UL}},{{0x034E17DBL,0x524827E9L,0xE52A5779L,0UL,0x488010CFL},{4294967295UL,4294967295UL,0UL,4294967295UL,1UL},{0x034E17DBL,0x016919F1L,0x593AD144L,0x524827E9L,4294967295UL},{4294967290UL,1UL,1UL,1UL,4294967290UL},{0x016919F1L,4294967291UL,0xE0C5A0DEL,0x524827E9L,0UL},{0x4B9BA959L,4294967295UL,0UL,4294967295UL,4294967295UL},{0UL,0x593AD144L,0x034E17DBL,4294967291UL,0UL},{0x9227CD94L,4294967295UL,4294967290UL,4294967295UL,4294967290UL}},{{0UL,0UL,0x016919F1L,0UL,4294967295UL},{0x9227CD94L,0x8D065EE2L,0x4B9BA959L,0x6E1A9BF0L,1UL},{0UL,0x488010CFL,0UL,0xE52A5779L,0x524827E9L},{0x4B9BA959L,0x8D065EE2L,0x9227CD94L,4294967295UL,1UL},{0x016919F1L,0UL,0UL,0x016919F1L,0UL},{4294967290UL,4294967295UL,0x9227CD94L,0x3C64F2ACL,0UL},{0x034E17DBL,0x593AD144L,0UL,0x593AD144L,0x034E17DBL},{0UL,4294967295UL,0x4B9BA959L,0x3C64F2ACL,0xB92AE4EBL}},{{0xE0C5A0DEL,4294967291UL,0x016919F1L,0x016919F1L,4294967291UL},{1UL,1UL,4294967290UL,4294967295UL,0xB92AE4EBL},{0x593AD144L,0x016919F1L,0x034E17DBL,0xE52A5779L,0x034E17DBL},{0xB92AE4EBL,0x3F22070DL,0UL,0x6E1A9BF0L,0UL},{0x593AD144L,4294967295UL,0xE0C5A0DEL,0UL,0UL},{1UL,0xB21EB06BL,1UL,4294967295UL,1UL},{0xE0C5A0DEL,4294967295UL,0x593AD144L,4294967291UL,0x524827E9L},{0UL,0x3F22070DL,0xB92AE4EBL,4294967295UL,1UL}}};
                    int32_t l_3127 = 0x701EC2C9L;
                    int i, j, k;
                    for (g_1935 = 0; (g_1935 <= 2); g_1935 += 1)
                    { /* block id: 1303 */
                        int32_t *l_3093 = (void*)0;
                        int64_t *l_3125 = &g_746;
                        int i, j, k;
                        (*l_3088) = l_3093;
                        (*l_3072) = ((*g_62) = (((*g_2585) , ((l_2998 & (safe_mul_func_uint8_t_u_u(((safe_div_func_int32_t_s_s((safe_lshift_func_int8_t_s_u((((safe_lshift_func_uint8_t_u_s((safe_lshift_func_int8_t_s_u((((*g_1732) != ((safe_mul_func_int8_t_s_s((l_3127 = (safe_rshift_func_uint32_t_u_s((((safe_sub_func_int8_t_s_s((l_3126 = (safe_div_func_int8_t_s_s((safe_mul_func_uint64_t_u_u((((((safe_div_func_int16_t_s_s((safe_mul_func_int64_t_s_s(((*l_3125) &= (((((safe_lshift_func_uint8_t_u_s((safe_mod_func_uint16_t_u_u(p_22.f0, ((l_3122[3][7][1] && ((safe_mul_func_uint16_t_u_u(0xCACAL, ((void*)0 == &l_3093))) == ((((*l_2866) = ((((p_23 , p_24) == p_23) | (*g_662)) , p_22.f0)) == (-5L)) >= (*l_3072)))) & p_22.f0))), l_3122[4][4][2])) <= (*g_1358)) , (***g_876)) || p_22.f0) , (*l_3072))), 18446744073709551615UL)), l_3122[3][7][1])) > 0L) | l_3122[3][7][1]) && g_80) ^ p_22.f0), 0UL)), 0x8EL))), p_22.f0)) != 1L) <= (**g_968)), 8))), 0x5FL)) || (**g_1997))) != p_22.f0), p_23)), l_3122[3][7][1])) == p_23) == (*g_662)), 3)), (*g_1998))) & p_22.f0), (*l_3072)))) || (-6L))) > p_22.f0));
                    }
                }
                else
                { /* block id: 1312 */
                    uint32_t l_3131 = 0x3E0F2242L;
                    int32_t l_3140 = 9L;
                    int64_t *l_3141 = &g_847;
                    (*l_3072) = (((((((safe_unary_minus_func_int32_t_s((safe_div_func_int64_t_s_s((l_3131 || (safe_lshift_func_int16_t_s_s(((*l_3072) & ((((((safe_rshift_func_uint32_t_u_u((*g_1998), (((safe_mul_func_uint16_t_u_u((((p_24 > ((safe_mul_func_int64_t_s_s(((**g_1357) = ((*l_3072) == (***g_971))), (0x0B8D12EBL >= ((*g_62) ^= 0x7D8B7CC1L)))) == ((*l_3141) = (((*l_2866) |= (l_3140 &= (((*g_1732) & (*g_969)) >= g_1578))) < l_2994)))) | l_2994) | l_2998), p_23)) ^ (*l_3072)) ^ 0xDAL))) & (***g_876)) != 65535UL) | 65531UL) ^ 0xBAL) <= (*g_1732))), l_2994))), p_23)))) , (-1L)) < 0xE3L) != 0xAFL) >= (*g_1998)) <= p_22.f0) != (*g_1998));
                }
                for (p_24 = 2; (p_24 <= 7); p_24 += 1)
                { /* block id: 1322 */
                    uint32_t ***l_3144 = &l_3142[3][0][0];
                    int32_t l_3149 = 0x97A04A76L;
                    (*l_3144) = l_3142[3][0][0];
                    for (g_1191.f4 = 0; (g_1191.f4 >= 0); g_1191.f4 -= 1)
                    { /* block id: 1326 */
                        int i, j, k;
                        return g_203[p_24][(g_2882 + 5)][g_1191.f4];
                    }
                    l_3145 = l_3145;
                    for (g_1164.f4 = 0; (g_1164.f4 <= 1); g_1164.f4 += 1)
                    { /* block id: 1332 */
                        const union U0 **l_3148 = &g_1088;
                        if (p_22.f0)
                            break;
                        (*l_3148) = l_3146;
                        if (l_3149)
                            break;
                    }
                }
                for (l_2994 = 0; (l_2994 <= 2); l_2994 += 1)
                { /* block id: 1340 */
                    uint32_t l_3162 = 0xA712DB90L;
                    int32_t l_3190 = (-7L);
                    int32_t l_3192 = (-1L);
                    if ((safe_add_func_uint8_t_u_u(((safe_sub_func_int8_t_s_s(0x52L, ((void*)0 != l_3154[0]))) , 0x42L), (((((safe_mul_func_uint32_t_u_u(0xC241A749L, ((--(*g_1998)) == p_24))) <= p_23) < g_560[2].f0) == ((safe_mul_func_int32_t_s_s((-7L), l_3161[1][1][3])) > (**g_1357))) || l_3162))))
                    { /* block id: 1342 */
                        l_3167 |= (!(g_3164 , (safe_rshift_func_int32_t_s_u(2L, 8))));
                        (*l_3088) = l_3143;
                        return (**g_1997);
                    }
                    else
                    { /* block id: 1346 */
                        union U1 * const * const ***l_3177[2][8][5] = {{{&l_3175[4],&l_3175[1],(void*)0,&l_3175[4],&l_3175[4]},{&l_3175[4],(void*)0,(void*)0,&l_3175[4],&l_3175[4]},{&l_3175[0],&l_3175[4],(void*)0,&l_3175[4],(void*)0},{&l_3175[4],&l_3175[4],(void*)0,&l_3175[4],(void*)0},{&l_3175[1],&l_3175[0],&l_3175[4],&l_3175[4],&l_3175[0]},{&l_3175[4],&l_3175[2],(void*)0,&l_3175[4],&l_3175[0]},{&l_3175[4],&l_3175[4],&l_3175[4],&l_3175[4],(void*)0},{&l_3175[2],&l_3175[4],&l_3175[4],(void*)0,(void*)0}},{{&l_3175[4],(void*)0,&l_3175[4],&l_3175[4],&l_3175[4]},{&l_3175[4],(void*)0,&l_3175[4],&l_3175[2],&l_3175[4]},{&l_3175[1],&l_3175[4],(void*)0,&l_3175[4],&l_3175[4]},{&l_3175[4],&l_3175[4],&l_3175[4],&l_3175[4],&l_3175[4]},{&l_3175[0],&l_3175[2],&l_3175[4],&l_3175[4],&l_3175[4]},{&l_3175[4],&l_3175[0],&l_3175[4],&l_3175[4],(void*)0},{&l_3175[4],&l_3175[4],&l_3175[4],&l_3175[2],&l_3175[4]},{&l_3175[4],&l_3175[4],(void*)0,&l_3175[4],&l_3175[4]}}};
                        int i, j, k;
                        l_3191 = (safe_sub_func_int8_t_s_s((safe_mul_func_int8_t_s_s(p_23, (((g_3178 = (l_3177[0][1][3] = l_3174)) != l_3184) <= ((l_3190 = (((++(*l_3077)) > (((((*g_662) = ((void*)0 == &g_2834)) == ((void*)0 == l_3188[2])) | (p_22.f0 & ((l_3189[2] = l_3189[2]) != &g_1496))) && (-1L))) != p_22.f0)) > (**g_1357))))), 0UL));
                        l_3192 ^= l_3190;
                        return p_24;
                    }
                }
            }
            for (g_746 = 0; (g_746 <= 0); g_746 += 1)
            { /* block id: 1361 */
                int16_t l_3193 = 1L;
                int32_t l_3195[5][9] = {{0xD48E60D9L,1L,0x1D96C7D9L,0x1D96C7D9L,1L,0xD48E60D9L,1L,0x1D96C7D9L,0x1D96C7D9L},{0L,0L,0xD48E60D9L,0x1D96C7D9L,0xD48E60D9L,0L,0L,0xD48E60D9L,0x1D96C7D9L},{0x31E59400L,1L,0x31E59400L,0xD48E60D9L,0xD48E60D9L,0x31E59400L,1L,0x31E59400L,0xD48E60D9L},{0x31E59400L,0xD48E60D9L,0xD48E60D9L,0x31E59400L,1L,0x31E59400L,0xD48E60D9L,0xD48E60D9L,0x31E59400L},{0L,0xD48E60D9L,0x1D96C7D9L,0xD48E60D9L,0L,0L,0xD48E60D9L,0x1D96C7D9L,0xD48E60D9L}};
                int32_t **l_3196 = (void*)0;
                int i, j;
                l_3193 &= l_2998;
                (*g_1625) = ((((l_3195[3][3] = (l_3194 != (p_24 , &g_1732))) >= 0xE1L) , p_23) , &l_2831);
                (*g_62) = (((*l_3072) & (&g_2834 != &g_2834)) | ((l_3199 == l_2866) >= ((((safe_lshift_func_uint16_t_u_s((*g_1732), (safe_rshift_func_uint8_t_u_s(((p_24 && (((safe_mul_func_int32_t_s_s((p_22.f0 ^ (safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint64_t_u_s((((void*)0 == l_3210) | (*g_827)), g_3212)), 7))), 1UL)) || g_527) >= p_23)) < 0xACBEBE6F683F1DEELL), l_3213)))) != 0x27L) < 0xA3474DDEL) && p_22.f0)));
            }
        }
        if (((*l_3072) ^= (safe_div_func_int32_t_s_s((p_22.f0 , 0xEC865561L), (safe_add_func_uint8_t_u_u((p_23 || (++(*g_1151))), (0UL != (p_22.f0 ^ (**g_731)))))))))
        { /* block id: 1370 */
            uint32_t l_3229 = 5UL;
            (*l_3072) = (safe_rshift_func_int16_t_s_s(((((((safe_mul_func_uint8_t_u_u((((g_3224 , (g_3225 , 0xFA2A2134L)) , 18446744073709551615UL) ^ (((*g_1151) >= (safe_mul_func_int8_t_s_s((p_24 , ((*l_2866) ^= ((((0x1A99L == ((18446744073709551615UL | (*g_1358)) , 0xF7DBL)) > p_22.f0) , 3UL) <= 0xB5798D8CL))), g_2882))) < p_22.f0)), p_22.f0)) < p_22.f0) , p_22.f0) , l_3228) ^ l_3229) & p_22.f0), (*l_3072)));
        }
        else
        { /* block id: 1373 */
            int8_t l_3239 = 1L;
            int32_t l_3240 = 0xB68C8DD3L;
            int32_t l_3241 = 0xEF29C574L;
            uint64_t l_3243 = 0xD47C27996D1699AALL;
            uint32_t l_3247 = 8UL;
            uint8_t l_3284 = 0x11L;
            int16_t ****l_3287 = &g_1424;
            int32_t l_3334 = (-1L);
            int32_t l_3335 = 1L;
            int32_t l_3338 = 2L;
            int32_t l_3340 = 0L;
            int32_t *l_3355 = &g_117;
            int32_t *l_3356 = &g_1256;
            int32_t *l_3357 = (void*)0;
            int32_t *l_3358 = &l_3241;
            for (l_3213 = 0; (l_3213 <= 0); l_3213 += 1)
            { /* block id: 1376 */
                int32_t *l_3230 = &g_1256;
                int32_t *l_3231 = &g_117;
                int32_t *l_3232 = &l_2961;
                int32_t *l_3233 = (void*)0;
                int32_t *l_3234 = &g_614;
                int32_t *l_3235 = &g_1256;
                int32_t *l_3236 = &g_614;
                int32_t *l_3237 = (void*)0;
                int32_t *l_3238[6] = {&g_63,&g_63,&g_63,&g_63,&g_63,&g_63};
                int32_t **l_3246[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int32_t *l_3256 = &l_2831;
                int8_t *l_3296 = &g_2962;
                int16_t * const ** const **l_3319[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int i;
                --l_3243;
                l_3072 = l_3232;
                for (l_2762 = 0; (l_2762 <= 2); l_2762 += 1)
                { /* block id: 1381 */
                    int32_t * const l_3254[1][3][7] = {{{&g_1256,&g_1256,&g_1256,&g_1256,&g_1256,&g_1256,&g_1256},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_1256,&g_1256,&g_1256,&g_1256,&g_1256,&g_1256,&g_1256}}};
                    int16_t ****l_3290[4];
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                        l_3290[i] = &g_1424;
                    if ((p_22 , p_23))
                    { /* block id: 1382 */
                        return l_3247;
                    }
                    else
                    { /* block id: 1384 */
                        int32_t * const l_3248 = &g_1256;
                        int32_t **l_3249[10][6] = {{(void*)0,&l_3235,&l_3072,&l_3230,&l_3230,&l_3072},{(void*)0,(void*)0,&g_190,&l_3230,&l_3235,&l_3231},{(void*)0,&g_190,&l_3235,&l_3231,&l_3235,&g_190},{&l_3230,(void*)0,&l_3235,&l_3233,(void*)0,&l_3231},{&l_3072,&l_3233,&g_190,&g_190,&l_3233,&l_3072},{&g_190,&l_3233,&l_3072,&l_3072,(void*)0,&l_3235},{&l_3235,(void*)0,&l_3230,(void*)0,&l_3235,&l_3233},{&l_3235,&g_190,(void*)0,&l_3072,&l_3235,&l_3235},{&g_190,(void*)0,(void*)0,&g_190,&l_3230,&l_3235},{&l_3072,&l_3235,(void*)0,&l_3233,&l_3072,&l_3233}};
                        int32_t **l_3250 = (void*)0;
                        int32_t **l_3251 = &l_3235;
                        int i, j;
                        (*g_3255) = l_3254[0][1][1];
                    }
                    for (g_1496 = 0; (g_1496 <= 5); g_1496 += 1)
                    { /* block id: 1392 */
                        (*l_3230) = p_22.f0;
                    }
                    l_3257 = l_3256;
                    if ((~0xD72C0CC4L))
                    { /* block id: 1396 */
                        int32_t l_3276 = 0x9BBE4032L;
                        int16_t *****l_3288 = (void*)0;
                        int16_t *****l_3289[7][7] = {{&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287},{&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287},{&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287},{&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287},{&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287},{&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287},{&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287,&l_3287}};
                        int i, j;
                        (*l_3232) &= (((safe_mul_func_uint64_t_u_u((safe_unary_minus_func_uint8_t_u((((0x72L > (((*l_3257) || ((****g_875) == (safe_mod_func_uint64_t_u_u((safe_add_func_uint8_t_u_u(((l_3290[0] = ((safe_mod_func_int16_t_s_s(((safe_sub_func_int32_t_s_s(((0x25F9FE35L <= ((safe_sub_func_uint64_t_u_u((((safe_div_func_uint32_t_u_u(p_23, (((safe_lshift_func_int8_t_s_s((l_3276 != p_24), 7)) , ((*g_62) = (safe_mul_func_uint16_t_u_u(l_3241, (safe_mod_func_int32_t_s_s((l_3284 = (((safe_mod_func_int32_t_s_s(((+0x9683A64CL) != p_22.f0), (-6L))) , g_571) | p_22.f0)), p_22.f0)))))) && p_23))) , (void*)0) == (void*)0), l_3285)) ^ (-1L))) & g_2511.f0), g_3286)) == 0x6112L), 8L)) , l_3287)) != l_3291[0][0][0]), 0xCAL)), (*g_1358))))) | p_23)) | p_23) , p_23))), l_3240)) || 1UL) == (*g_1358));
                        if ((**g_2958))
                            break;
                        (*l_3232) = (p_24 >= ((*l_3230) = (((p_23 , ((0x39L != ((*l_3257) >= g_308[0][2].f0)) , (--(*l_2795)))) & ((((((*g_1151) = 0x0F3E6AA540E062BCLL) , (((((*g_969) = (p_22.f0 != ((((g_1411.f4 & (*g_732)) <= 0x5494L) || p_22.f0) <= 0xF77C5B8133679597LL))) , g_3294) , l_3295) == l_3296)) , p_24) ^ p_24) , (*l_3231))) <= p_22.f0)));
                    }
                    else
                    { /* block id: 1407 */
                        uint8_t *l_3313 = (void*)0;
                        uint8_t *l_3314 = &g_308[0][2].f0;
                        int32_t l_3315 = 0x23A9E78DL;
                        const uint16_t *****l_3327 = (void*)0;
                        const uint16_t *****l_3328 = &g_3323;
                        (*l_3231) &= (safe_rshift_func_int16_t_s_u(((+p_23) >= ((**g_1357) = ((*l_3072) & (safe_lshift_func_uint16_t_u_u((g_3302[2] , (g_3164.f0 <= (0x2FF6BAF2283E3960LL && 0x80D0799F1D92361FLL))), ((safe_lshift_func_int16_t_s_u((safe_add_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((*l_2866) = p_23), ((*l_3314) = (((p_22.f0 != ((safe_mul_func_uint8_t_u_u((((*g_2582) == (void*)0) , 0x46L), (*l_3257))) == (*g_1358))) < (*g_969)) >= p_24)))), 1UL)), l_3315)) , 0xD4FCL)))))), 5));
                        if (g_75)
                            goto lbl_3316;
                        (*l_3072) |= (safe_sub_func_uint64_t_u_u((l_3319[0] != (void*)0), (safe_add_func_uint16_t_u_u((((p_23 >= (p_24 | ((0UL | (~(p_23 && (((((p_22.f0 , ((*l_3328) = (p_24 , g_3323))) != &g_3324) , l_3239) && 0UL) | 2L)))) ^ l_3284))) <= p_23) , l_3315), (***g_971)))));
                    }
                }
                for (p_22.f0 = 0; (p_22.f0 <= 2); p_22.f0 += 1)
                { /* block id: 1419 */
                    int32_t l_3332 = 0x093775CAL;
                    int32_t l_3333[4][7] = {{0x0607966FL,0x17B804EAL,(-1L),0x17B804EAL,0x0607966FL,0x0607966FL,0x17B804EAL},{(-3L),1L,(-3L),0x17B804EAL,0x17B804EAL,(-3L),1L},{0x17B804EAL,1L,(-1L),(-1L),1L,0x17B804EAL,1L},{(-3L),0x17B804EAL,0x17B804EAL,(-3L),1L,(-3L),0x17B804EAL}};
                    int i, j;
                    (*l_3257) ^= (safe_lshift_func_uint16_t_u_s((((**g_3324) != l_3331[0]) < p_23), 13));
                    for (l_2994 = 0; (l_2994 <= 2); l_2994 += 1)
                    { /* block id: 1423 */
                        return (*g_1998);
                    }
                    l_3342++;
                    (*l_3235) |= (((safe_add_func_uint64_t_u_u((safe_mul_func_uint32_t_u_u((*l_3072), (l_3349 == (l_3333[3][0] &= (p_24 | ((--(*l_3065)) , (safe_sub_func_int8_t_s_s((((0UL || p_22.f0) , ((((p_24 , l_3354) , (l_3243 < ((*g_878) > p_22.f0))) , l_2885[7]) | p_23)) >= (-10L)), (*l_3257))))))))), (**g_1357))) != 0L) | g_75);
                }
            }
            l_3359++;
        }
        for (g_1411.f4 = 0; (g_1411.f4 <= 0); g_1411.f4 += 1)
        { /* block id: 1436 */
            int16_t l_3401 = (-1L);
            union U0 ****l_3415 = &l_2787;
            const int32_t l_3421 = 0x03153FB2L;
            int32_t l_3468[9][4] = {{1L,0xC10995CEL,4L,4L},{0x3D00E222L,0x3D00E222L,(-8L),0xC10995CEL},{0xC10995CEL,1L,(-8L),1L},{0x3D00E222L,(-3L),4L,(-8L)},{1L,(-3L),(-3L),1L},{(-3L),1L,0x3D00E222L,0xC10995CEL},{(-3L),0x3D00E222L,(-3L),4L},{1L,0xC10995CEL,4L,4L},{0x3D00E222L,0x3D00E222L,(-8L),0xC10995CEL}};
            union U1 ***l_3507 = (void*)0;
            int32_t *l_3552 = &l_3337[3];
            int i, j;
            if ((safe_rshift_func_uint64_t_u_s(0xCFC571F8E0C1728CLL, 5)))
            { /* block id: 1437 */
                return p_23;
            }
            else
            { /* block id: 1439 */
                int64_t l_3367 = 1L;
                int32_t ***l_3387 = &l_3253;
                int32_t **l_3403 = &l_3145;
                int32_t ***l_3402 = &l_3403;
                union U1 l_3410 = {0x9EL};
                if (l_3364)
                { /* block id: 1440 */
                    uint32_t l_3372 = 0x51C6AB87L;
                    if ((((safe_mod_func_uint32_t_u_u(p_23, l_3367)) , ((253UL >= 0x1BL) <= ((safe_sub_func_int64_t_s_s((safe_lshift_func_uint32_t_u_u(4294967287UL, (**g_1997))), l_3372)) > (safe_mod_func_uint16_t_u_u(((*g_1732) = (((((void*)0 != l_3375) , (****g_3323)) && (*l_3072)) && 0x6768F2FEFBA19D24LL)), 0x26A9L))))) >= l_3367))
                    { /* block id: 1442 */
                        uint16_t *l_3378 = &g_3286;
                        int32_t ****l_3390 = &l_3388;
                        (*l_3072) ^= (safe_mul_func_uint32_t_u_u((((*l_3378) = ((*g_662) ^= p_24)) , ((safe_lshift_func_uint64_t_u_s(p_22.f0, 25)) ^ (*l_3257))), (safe_rshift_func_uint32_t_u_s(((**l_3211) |= (safe_mod_func_uint16_t_u_u(0UL, ((safe_mul_func_int16_t_s_s(((l_3387 == ((*l_3390) = (((***g_3180) = (l_3354 = (**g_180))) , l_3388))) == (*g_1358)), (-1L))) ^ 0x3C4238F2L)))), 8))));
                        return (**g_1997);
                    }
                    else
                    { /* block id: 1451 */
                        return p_23;
                    }
                }
                else
                { /* block id: 1454 */
                    union U0 * const *l_3414 = &g_924;
                    union U0 * const **l_3413 = &l_3414;
                    union U0 * const ***l_3412[3];
                    union U0 *****l_3416[7] = {(void*)0,&l_3415,&l_3415,(void*)0,&l_3415,&l_3415,(void*)0};
                    int i;
                    for (i = 0; i < 3; i++)
                        l_3412[i] = &l_3413;
                    (*l_3072) = ((*g_62) = (+((safe_div_func_int64_t_s_s(((l_3367 < (+(safe_lshift_func_int32_t_s_s(((safe_rshift_func_int32_t_s_u((((safe_mod_func_uint8_t_u_u(((l_3367 , ((*g_1358) = l_3401)) , 2UL), (((l_3402 = l_3402) == (void*)0) || (safe_div_func_int32_t_s_s((safe_rshift_func_uint64_t_u_s((safe_add_func_uint64_t_u_u(((*g_1151) = (*l_3257)), p_22.f0)), 31)), ((l_3410 = p_22) , 4294967295UL)))))) , g_3411) && 0x73L), (**g_1997))) , p_22.f0), 3)))) , (*l_3257)), l_3401)) & 0x5F710AEDL)));
                    (*l_3403) = (*l_3403);
                    (*g_62) = (l_3412[1] == (l_3417 = l_3415));
                    (*l_3072) = (p_22.f0 || (**g_1997));
                }
                (*g_62) = (g_3418[2] , (safe_lshift_func_int64_t_s_s(p_24, 39)));
                if ((l_3421 >= ((1L >= l_3421) , (safe_mul_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((0L & p_24), 14)), (safe_lshift_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((safe_mul_func_uint64_t_u_u((((*l_3257) < (((safe_rshift_func_int32_t_s_u(((*l_3072) ^= p_22.f0), ((safe_mod_func_uint32_t_u_u((l_3436 | (safe_div_func_uint8_t_u_u((((0xFEC9L && p_23) != l_3421) != (-1L)), p_22.f0))), l_3421)) , (*g_1998)))) ^ (*l_3257)) , l_3439)) , p_24), p_24)), l_3421)), 2)))))))
                { /* block id: 1468 */
                    const uint16_t l_3469 = 1UL;
                    uint16_t l_3472 = 1UL;
                    for (g_1578 = 0; (g_1578 >= 0); g_1578 -= 1)
                    { /* block id: 1471 */
                        uint8_t *l_3467[1][6][1] = {{{(void*)0},{&g_1658[0]},{&g_1658[0]},{(void*)0},{&g_1658[0]},{&g_1658[0]}}};
                        int32_t l_3470 = 0x78CD0CA6L;
                        int32_t *l_3471[3];
                        int32_t **l_3485 = &g_484;
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_3471[i] = (void*)0;
                        (*g_180) = &p_22;
                        l_3472 = ((safe_sub_func_uint64_t_u_u(((l_3470 = (g_31 = ((safe_mod_func_uint16_t_u_u(((safe_unary_minus_func_int64_t_s((((*l_3072) , (0x73BE04EBB89775C2LL <= p_24)) , (safe_sub_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u(((p_22.f0 == (safe_mul_func_int16_t_s_s(p_23, (safe_mul_func_uint8_t_u_u(((0xB21AL || p_22.f0) ^ (((*g_1358) = ((((((*l_3257) = (((safe_mod_func_uint8_t_u_u((((l_3468[2][1] |= ((safe_mul_func_int8_t_s_s(((*l_2866) = (safe_div_func_int16_t_s_s(((((**g_1997) = (safe_mul_func_uint8_t_u_u((safe_sub_func_int64_t_s_s((safe_rshift_func_uint32_t_u_s(((safe_add_func_int64_t_s_s((**g_1357), p_23)) <= l_3401), 13)), p_24)), l_3421))) > p_24) && p_24), p_24))), p_24)) | g_80)) ^ l_3469) , p_23), g_63)) , p_23) == l_3401)) , (**g_1997)) < 0L) || l_3470) != (**g_877))) < p_22.f0)), g_308[0][2].f0))))) | p_22.f0), 6)), 0x9C1DL))))) && (*l_3257)), p_24)) || 0xC67F53DEL))) , p_22.f0), 1L)) != g_2962);
                        (*l_3257) &= ((safe_mul_func_int32_t_s_s((*g_2957), ((safe_rshift_func_int16_t_s_s((g_1681[0][7] = ((*g_969) ^= (safe_div_func_int8_t_s_s(((safe_rshift_func_int32_t_s_u(0L, p_23)) <= (((p_22 , (safe_lshift_func_int64_t_s_u(((p_22.f0 >= ((safe_sub_func_int8_t_s_s(p_22.f0, (((*l_3388) = l_3485) == (*l_3387)))) <= p_24)) ^ p_22.f0), p_22.f0))) , (void*)0) != (void*)0)), g_846)))), 12)) , p_24))) && l_3468[2][3]);
                        l_3242 = ((*g_62) = (p_22.f0 == (-8L)));
                    }
                }
                else
                { /* block id: 1488 */
                    uint32_t l_3493 = 4294967295UL;
                    for (l_3436 = 0; (l_3436 <= 0); l_3436 += 1)
                    { /* block id: 1491 */
                        int i, j;
                        (*g_62) ^= ((l_3468[(g_2882 + 2)][(g_1411.f4 + 1)] <= ((**l_3402) != (((p_23 , (safe_lshift_func_int32_t_s_u((((safe_rshift_func_int32_t_s_u((p_22.f0 | ((safe_rshift_func_int32_t_s_u((((~l_3493) && 0x42A5C735A4B84818LL) == g_201), ((safe_sub_func_uint16_t_u_u(((((**g_3325) & (+(0xB5L != g_614))) <= p_22.f0) , (***g_3324)), l_3493)) == p_22.f0))) != l_3493)), 3)) > 4294967291UL) ^ p_23), 25))) , (*l_3072)) , &l_3468[4][1]))) , p_22.f0);
                        if ((*l_3072))
                            continue;
                    }
                    if ((safe_add_func_uint64_t_u_u(((((*g_1151) = ((safe_add_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(p_23, 2)), g_430[8][4][0])) != (safe_div_func_uint8_t_u_u((((l_3493 , ((((p_22 , (*g_732)) , (void*)0) != (l_3505 = &l_2786)) || ((safe_unary_minus_func_int16_t_s((-1L))) != ((void*)0 == l_3507)))) | p_22.f0) , g_2882), p_24)))) , (**g_1997)) | 6L), (*g_1358))))
                    { /* block id: 1497 */
                        (*l_3403) = (**l_3402);
                        (*l_3072) = (safe_rshift_func_uint32_t_u_u((!((((safe_unary_minus_func_int32_t_s((l_3410 , 0xD192A297L))) || (p_22.f0 != ((safe_sub_func_uint8_t_u_u((safe_sub_func_int8_t_s_s((((safe_div_func_int8_t_s_s(0x0BL, (((safe_rshift_func_int16_t_s_s(l_3401, ((void*)0 == g_3520[2]))) == 0xB530F166L) && (*l_3072)))) , p_23) & p_24), 0x26L)), 0xE3L)) ^ l_3493))) & l_3468[2][1]) <= g_3523)), l_3493));
                        (*l_3072) |= 3L;
                    }
                    else
                    { /* block id: 1501 */
                        if (g_2962)
                            goto lbl_3316;
                        return l_3493;
                    }
                }
                if (p_22.f0)
                    break;
            }
            (*l_3072) = (*l_3257);
            (*l_3552) ^= (safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((p_24 | (((((0x5E4E1D05D3F14342LL != ((*g_1151) = (safe_div_func_int16_t_s_s(0xDB1EL, ((*g_1732) = 65535UL))))) || (safe_sub_func_uint32_t_u_u(p_24, ((((*l_3257) = ((*l_3072) = ((*g_2486) == (*g_2486)))) ^ (safe_lshift_func_uint8_t_u_s((safe_lshift_func_int32_t_s_s(((safe_mul_func_uint32_t_u_u(((((((safe_sub_func_int32_t_s_s((safe_unary_minus_func_uint8_t_u(((safe_rshift_func_int16_t_s_u((((safe_mod_func_uint16_t_u_u((!(((g_3548 , ((++(*l_2795)) ^ (-1L))) ^ 0x45L) == 0x31L)), l_3401)) , 0xB21CL) < p_23), p_23)) && p_24))), p_23)) & 4UL) , g_2311.f0) , 0x19A9C51DL) | p_23) & l_3468[8][1]), p_24)) == l_3421), p_24)), l_3421))) != p_24)))) & p_22.f0) != l_3468[2][1]) <= l_3468[2][1])), l_3468[2][1])), p_24));
            for (g_80 = 0; (g_80 <= 2); g_80 += 1)
            { /* block id: 1517 */
                uint64_t l_3563[6];
                int32_t *l_3566 = &g_1578;
                int i;
                for (i = 0; i < 6; i++)
                    l_3563[i] = 18446744073709551615UL;
                for (g_527 = 0; (g_527 <= 0); g_527 += 1)
                { /* block id: 1520 */
                    int16_t l_3553 = (-1L);
                    int32_t *l_3554 = &l_2961;
                    int32_t *l_3555 = &g_1256;
                    int32_t *l_3556 = &l_3468[2][1];
                    int32_t *l_3557 = &g_362;
                    int32_t *l_3558 = &l_3339[3][6];
                    int32_t *l_3559 = &g_797;
                    int32_t *l_3560 = &g_117;
                    int32_t *l_3561 = &g_362;
                    int32_t *l_3562[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_3562[i] = &l_2831;
                    ++l_3563[1];
                    (*g_3567) = l_3566;
                    return (*g_1998);
                }
            }
        }
    }
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_190 g_85 g_732 g_733 g_1151 g_1358 g_846 g_1998 g_1732 g_267 g_62 g_63 g_117 g_1939 g_1357 g_764 g_2583 g_2584 g_2585 g_2586 g_80 g_253 g_254 g_885 g_827 g_828 g_746
 * writes: g_190 g_85 g_764 g_1939 g_267 g_117 g_75 g_63 g_80 g_1937 g_746 g_846 g_2682
 */
static union U1  func_25(int32_t  p_26, union U1  p_27, uint8_t  p_28)
{ /* block id: 1012 */
    int32_t * const l_2569 = (void*)0;
    union U1 **l_2572 = &g_181;
    union U1 **l_2573 = &g_181;
    uint64_t *l_2576[2];
    int32_t l_2577 = 0xC51B1DB2L;
    union U1 * const ***l_2579 = (void*)0;
    union U1 * const ****l_2578 = &l_2579;
    union U1 * const ***l_2581 = (void*)0;
    union U1 * const ****l_2580[7][4] = {{&l_2581,&l_2581,&l_2581,&l_2581},{&l_2581,&l_2581,&l_2581,&l_2581},{&l_2581,&l_2581,&l_2581,&l_2581},{&l_2581,(void*)0,&l_2581,&l_2581},{&l_2581,(void*)0,(void*)0,&l_2581},{(void*)0,&l_2581,&l_2581,&l_2581},{(void*)0,&l_2581,(void*)0,&l_2581}};
    uint64_t l_2587 = 18446744073709551608UL;
    int32_t **l_2588 = &g_190;
    int8_t l_2639 = 7L;
    int8_t l_2642 = 0L;
    int32_t **l_2654 = &g_484;
    int32_t ** const *l_2653 = &l_2654;
    int32_t l_2732[4];
    int16_t l_2755 = 3L;
    union U0 ***l_2761[1][3][2] = {{{&g_2267,&g_2267},{(void*)0,&g_2267},{&g_2267,(void*)0}}};
    union U0 ****l_2760[10][1] = {{&l_2761[0][2][0]},{&l_2761[0][1][1]},{&l_2761[0][2][0]},{&l_2761[0][1][1]},{&l_2761[0][2][0]},{&l_2761[0][1][1]},{&l_2761[0][2][0]},{&l_2761[0][1][1]},{&l_2761[0][2][0]},{&l_2761[0][1][1]}};
    union U0 *****l_2759 = &l_2760[6][0];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2576[i] = &g_321;
    for (i = 0; i < 4; i++)
        l_2732[i] = 0x9381AE92L;
lbl_2609:
    (*l_2588) = (*l_2588);
    for (g_85 = (-20); (g_85 <= 30); g_85++)
    { /* block id: 1021 */
        int32_t l_2607 = 0xDB851076L;
        int32_t l_2608 = 0L;
        int16_t ****l_2626[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t ***l_2655 = &l_2654;
        int32_t l_2664[1];
        int32_t l_2731 = 0x1F4849F9L;
        int32_t l_2734 = 1L;
        int32_t l_2735 = 0x04893502L;
        int32_t l_2737 = (-9L);
        int32_t l_2738 = 0xCC83977CL;
        int i;
        for (i = 0; i < 1; i++)
            l_2664[i] = (-7L);
        (*g_190) ^= (safe_div_func_int32_t_s_s(((safe_add_func_uint16_t_u_u((g_85 | p_27.f0), ((*g_1732) ^= (safe_mul_func_uint16_t_u_u((((safe_div_func_int8_t_s_s((*g_732), 0x29L)) >= 1L) , 0x95A3L), (((((*g_1151) = 0x0D58DC1C85574EF5LL) != 0xA7F1D6DDF1ECF283LL) | (((safe_sub_func_uint32_t_u_u(((safe_div_func_int8_t_s_s((((safe_div_func_int8_t_s_s(((((*g_1998) = (safe_div_func_uint64_t_u_u(l_2607, (*g_1358)))) < 4294967295UL) ^ l_2607), l_2607)) >= 0x3019L) || p_28), p_28)) | (*g_1358)), p_28)) && l_2608) , 1L)) & p_26)))))) <= 0UL), (*g_62)));
        if (g_846)
            goto lbl_2609;
        for (g_75 = 0; (g_75 <= 3); g_75 += 1)
        { /* block id: 1029 */
            int32_t l_2614 = 0x58B86F09L;
            union U1 ***l_2616 = &l_2573;
            union U1 ****l_2615 = &l_2616;
            int32_t l_2627 = 0L;
            uint32_t *l_2651 = &g_1937[1];
            int64_t *l_2679 = &g_746;
            int16_t *****l_2680 = (void*)0;
            const uint64_t *****l_2681 = (void*)0;
            int8_t ** const *l_2692 = &g_1060;
            int8_t ** const **l_2691 = &l_2692;
            int32_t l_2733 = 0xC543EE69L;
            int32_t *l_2754 = &l_2577;
            uint8_t l_2756[1][2];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 2; j++)
                    l_2756[i][j] = 1UL;
            }
            for (g_63 = 6; (g_63 >= 2); g_63 -= 1)
            { /* block id: 1032 */
                int32_t l_2621 = 0x49766D96L;
                int32_t *l_2628 = &l_2621;
                if (p_26)
                { /* block id: 1033 */
                    int32_t l_2623[6][9] = {{2L,2L,2L,2L,2L,2L,2L,2L,2L},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)},{2L,2L,2L,2L,2L,2L,2L,2L,2L},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)},{2L,2L,2L,2L,2L,2L,2L,2L,2L},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)}};
                    int i, j;
                    if (((((safe_sub_func_int32_t_s_s((l_2607 ^ ((0x621E1BFCL != (**l_2588)) | ((*g_1998) , (l_2608 ^ (safe_sub_func_uint64_t_u_u(((l_2614 = (**g_1357)) == ((void*)0 != l_2615)), (safe_mul_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(((p_26 = (*g_62)) < p_28), (*g_1732))), p_28)))))))), 0x9332AC86L)) <= (*g_1732)) || l_2621) >= (-2L)))
                    { /* block id: 1036 */
                        int64_t l_2622 = (-1L);
                        p_26 = ((*g_190) = l_2622);
                        (*l_2588) = &p_26;
                    }
                    else
                    { /* block id: 1040 */
                        return p_27;
                    }
                    (**l_2588) ^= 0xAFD5BAC7L;
                    (*g_190) = (((&g_2238 != (void*)0) , ((((*g_1151) <= (l_2623[0][7] = p_28)) ^ (&g_1732 == (void*)0)) == 0x1FA734FC837D2C51LL)) , p_26);
                    return (***g_2583);
                }
                else
                { /* block id: 1047 */
                    int32_t *l_2629[7] = {&l_2577,&l_2627,&l_2627,&l_2627,&g_797,&g_797,&l_2627};
                    int i;
                    l_2628 = (((*g_1998) ^= (safe_rshift_func_int32_t_s_u((l_2626[2] == (void*)0), (4294967295UL && l_2627)))) , &p_26);
                    for (g_80 = 0; (g_80 <= 1); g_80 += 1)
                    { /* block id: 1052 */
                        uint32_t l_2630 = 18446744073709551613UL;
                        int i;
                        l_2629[2] = (*l_2588);
                        l_2630 = ((*l_2628) = ((**l_2588) = g_1939[g_80]));
                        return (*g_253);
                    }
                }
                (*g_190) = 0L;
            }
            (*g_62) ^= (safe_div_func_int32_t_s_s(((*g_190) = (((((safe_add_func_uint64_t_u_u(p_27.f0, ((safe_lshift_func_uint32_t_u_u(p_27.f0, 10)) , (*g_1358)))) == (1L >= l_2639)) < ((*g_253) , (safe_sub_func_int64_t_s_s((l_2614 = l_2642), (((((safe_rshift_func_int64_t_s_s((((l_2608 = ((safe_add_func_int64_t_s_s((safe_mod_func_uint32_t_u_u(((*l_2651) = ((*g_1998)++)), (0xFCE3L | ((safe_unary_minus_func_uint16_t_u(0x3523L)) & p_26)))), (**l_2588))) != 4294967286UL)) , (**g_885)) , 7L), 3)) <= 0x747EL) , l_2653) != l_2655) < p_28))))) | 0x5CE52F805E2ECF68LL) >= 0x34L)), p_28));
            g_2682 = (((*g_1151) ^ (safe_mul_func_uint32_t_u_u(((((l_2627 <= ((l_2614 |= 0xDAE6L) , p_28)) ^ ((((*g_1358) = (l_2608 && (safe_rshift_func_int64_t_s_s(p_27.f0, (((safe_mul_func_uint16_t_u_u(((safe_mod_func_int8_t_s_s(((((*l_2679) ^= ((l_2664[0] && ((((**l_2588) ^= (safe_mod_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint64_t_u_s((safe_rshift_func_uint64_t_u_u(((l_2608 |= ((0xD9L < (safe_rshift_func_int8_t_s_u(((safe_unary_minus_func_uint64_t_u(((!(**g_1357)) == p_28))) ^ (-1L)), 6))) , (*g_827))) > l_2664[0]), p_26)), 21)), 5)), p_28)), 4L))) ^ 0xC92ECC818A4E67DBLL) , (*g_1998))) != p_26)) & p_26) || p_26), l_2607)) < l_2664[0]), l_2664[0])) & (-1L)) == p_26))))) , (void*)0) != l_2680)) != l_2664[0]) > 0L), p_27.f0))) , l_2681);
            for (l_2639 = 4; (l_2639 >= 1); l_2639 -= 1)
            { /* block id: 1076 */
                int8_t ** const ***l_2693 = &l_2691;
                int32_t l_2715 = 0xF68489E2L;
                int32_t l_2736 = 0x54A440FAL;
                uint32_t l_2739[5][7][7];
                const int32_t ** const l_2752[4][1] = {{&g_543},{(void*)0},{&g_543},{(void*)0}};
                int i, j, k;
                for (i = 0; i < 5; i++)
                {
                    for (j = 0; j < 7; j++)
                    {
                        for (k = 0; k < 7; k++)
                            l_2739[i][j][k] = 0x838B5C87L;
                    }
                }
                (*g_62) = p_26;
            }
        }
        (*g_62) |= (-1L);
    }
    l_2759 = l_2759;
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_614 g_1939 g_571 g_732 g_733 g_190 g_180 g_181 g_968 g_969 g_1732 g_267 g_62 g_63
 * writes: g_543 g_614 g_201 g_822.f1 g_1831 g_571 g_55.f0 g_117 g_55 g_904 g_75 g_63
 */
static uint8_t  func_38(union U1  p_39)
{ /* block id: 817 */
    int8_t l_2097[7] = {0xE4L,0xE4L,4L,0xE4L,0xE4L,4L,0xE4L};
    int32_t l_2102 = 9L;
    int32_t l_2103 = 7L;
    int32_t l_2104 = 0xD3EA3738L;
    int32_t l_2105 = 0x5142DB11L;
    int32_t l_2106[6][5][3] = {{{0xC6C392C2L,(-1L),(-1L)},{0xC6C392C2L,1L,(-1L)},{0L,(-1L),(-1L)},{0L,(-1L),0x14500B44L},{0x48B829BAL,1L,(-1L)}},{{0L,(-1L),(-1L)},{0L,0xC33267DEL,0x14500B44L},{0xC6C392C2L,(-1L),(-1L)},{0xC6C392C2L,1L,(-1L)},{0L,(-1L),(-1L)}},{{0L,(-1L),0x14500B44L},{0x48B829BAL,1L,(-1L)},{0L,(-1L),(-1L)},{0L,0xC33267DEL,0x14500B44L},{0xC6C392C2L,(-1L),(-1L)}},{{0xC6C392C2L,1L,(-1L)},{0L,(-1L),(-1L)},{0L,(-1L),0x14500B44L},{0x48B829BAL,1L,(-1L)},{0L,(-1L),(-1L)}},{{0L,0xC33267DEL,0x14500B44L},{0xC6C392C2L,(-1L),(-1L)},{0xC6C392C2L,1L,(-1L)},{0L,(-1L),(-1L)},{0L,(-1L),0x14500B44L}},{{0x48B829BAL,1L,(-1L)},{0L,(-1L),(-1L)},{0L,0xC33267DEL,0x14500B44L},{0xC6C392C2L,(-1L),(-1L)},{0xC6C392C2L,1L,(-1L)}}};
    uint16_t l_2119[7][10][3] = {{{65535UL,1UL,0xB73CL},{0x9182L,0x7769L,1UL},{65529UL,1UL,65535UL},{0xEADEL,1UL,65535UL},{0x4152L,6UL,1UL},{65535UL,0x1F92L,0UL},{1UL,65535UL,65535UL},{0UL,0UL,0xEADEL},{0xA1E1L,0xEE2FL,0xA175L},{0x0C50L,65529UL,0xAB72L}},{{0x5FE3L,65535UL,1UL},{0x2807L,65529UL,0UL},{1UL,0xEE2FL,0x6911L},{8UL,0UL,1UL},{0x69E4L,65535UL,1UL},{0UL,0x1F92L,0xE5EEL},{0x38A6L,6UL,7UL},{0x7B13L,1UL,0x1F92L},{0x5311L,1UL,0xCCFFL},{0xE5EEL,0x7769L,1UL}},{{0x15CAL,1UL,0x5B08L},{0x74B6L,1UL,0UL},{65534UL,0x5FE3L,65534UL},{1UL,0x1B50L,65535UL},{3UL,0x6911L,65535UL},{0UL,0UL,0x7769L},{0xD2F4L,0xA175L,0x5FE3L},{0UL,0x74B6L,65535UL},{3UL,1UL,4UL},{1UL,0x9182L,1UL}},{{65535UL,0x38A6L,0xEE2FL},{0UL,65534UL,0UL},{0xD2F4L,0xCCFFL,0x7E0CL},{0UL,65528UL,0xEADEL},{2UL,0xF05FL,0xF1ACL},{1UL,0x1F92L,0x0FB2L},{0x5311L,0xD2F4L,0xB73CL},{0UL,0x0372L,0UL},{0x4152L,0x4152L,3UL},{65535UL,0UL,0x1B50L}},{{0x31D0L,0x15CAL,0xCCFFL},{0UL,0UL,65534UL},{65534UL,0x31D0L,0xCCFFL},{65535UL,0x2807L,0x1B50L},{0x38A6L,0xC5BEL,3UL},{0x1F92L,0UL,0UL},{1UL,0x1550L,0xB73CL},{0x6697L,65529UL,0x0FB2L},{0x38E8L,65534UL,0xF1ACL},{65530UL,0x1B50L,0xEADEL}},{{4UL,0xE384L,0x7E0CL},{0x74B6L,65535UL,0UL},{0x7E0CL,6UL,0xEE2FL},{65529UL,1UL,1UL},{0xCCFFL,65535UL,4UL},{0x0372L,1UL,0UL},{65535UL,1UL,65534UL},{0UL,0x6697L,1UL},{65535UL,1UL,0x5B08L},{65529UL,1UL,0x2807L}},{{0xA175L,65535UL,65535UL},{0x9182L,1UL,65529UL},{65535UL,6UL,65528UL},{0x8451L,65535UL,1UL},{7UL,0xE384L,6UL},{8UL,0x1B50L,0x0C50L},{65528UL,65534UL,0x1550L},{65534UL,65529UL,0UL},{0x15CAL,0x1550L,0x31D0L},{0UL,0UL,0UL}}};
    int8_t ****l_2146 = &g_1059;
    union U0 **l_2161 = &g_924;
    union U0 ***l_2160 = &l_2161;
    union U0 ****l_2159 = &l_2160;
    int32_t *l_2221 = &l_2103;
    int32_t l_2319 = 0x1308BAC5L;
    union U1 **l_2365[1];
    uint32_t **l_2380[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint64_t l_2391 = 1UL;
    uint32_t l_2455 = 4UL;
    uint32_t l_2529 = 0x7171BC52L;
    uint8_t *l_2538 = (void*)0;
    uint8_t *l_2539 = &g_571;
    int16_t *l_2556 = &g_75;
    int32_t *l_2557 = &g_63;
    int32_t *l_2558 = &l_2105;
    int32_t *l_2559 = &l_2104;
    int32_t *l_2560 = &l_2103;
    int32_t *l_2561 = &l_2102;
    int32_t *l_2562[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_2563 = 1L;
    uint64_t l_2564 = 0xFBEAA2B06BDCF934LL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2365[i] = &g_181;
    if ((safe_rshift_func_uint8_t_u_s((safe_add_func_uint64_t_u_u(l_2097[3], 0xF8050946ADCC13D5LL)), 5)))
    { /* block id: 818 */
        const int32_t **l_2098 = &g_543;
        int32_t *l_2099 = &g_614;
        int32_t *l_2100 = (void*)0;
        int32_t *l_2101[1];
        uint16_t l_2107[3];
        int i;
        for (i = 0; i < 1; i++)
            l_2101[i] = &g_362;
        for (i = 0; i < 3; i++)
            l_2107[i] = 0x5F51L;
        (*l_2098) = (void*)0;
        l_2107[2]--;
    }
    else
    { /* block id: 821 */
        int32_t *l_2110 = (void*)0;
        int32_t *l_2111 = (void*)0;
        int32_t *l_2112 = &g_117;
        int32_t *l_2113 = &l_2102;
        int32_t *l_2114 = &g_1578;
        int32_t *l_2115 = (void*)0;
        int32_t *l_2116 = &g_1256;
        int32_t *l_2117 = (void*)0;
        int32_t *l_2118[1];
        int i;
        for (i = 0; i < 1; i++)
            l_2118[i] = &g_362;
        ++l_2119[6][2][1];
    }
    for (g_614 = (-17); (g_614 >= (-20)); g_614--)
    { /* block id: 826 */
        int32_t *l_2128[1][7] = {{&g_430[8][2][1],&g_241,&g_430[8][2][1],&g_430[8][2][1],&g_241,&g_430[8][2][1],&g_430[8][2][1]}};
        int32_t l_2129 = 5L;
        uint16_t **l_2130 = (void*)0;
        uint16_t ***l_2131 = &l_2130;
        int32_t l_2140 = 5L;
        int16_t l_2141 = 0xC195L;
        int8_t ****l_2148 = (void*)0;
        uint8_t l_2151 = 0x65L;
        int32_t l_2176 = (-1L);
        int32_t l_2178 = 1L;
        uint16_t l_2180 = 0UL;
        int32_t *l_2223 = &g_797;
        const uint64_t *l_2231 = (void*)0;
        const int32_t *l_2285 = &g_430[6][1][0];
        const int32_t **l_2284 = &l_2285;
        union U1 **l_2423[2];
        int16_t l_2445 = 0x75E5L;
        int32_t l_2451 = 0x847FF09BL;
        int8_t l_2452 = (-3L);
        int32_t l_2453[3];
        uint16_t l_2503 = 0xE7E8L;
        int i, j;
        for (i = 0; i < 2; i++)
            l_2423[i] = (void*)0;
        for (i = 0; i < 3; i++)
            l_2453[i] = 0L;
        for (g_201 = 0; g_201 < 4; g_201 += 1)
        {
            for (l_2102 = 0; l_2102 < 2; l_2102 += 1)
            {
                for (g_822.f1 = 0; g_822.f1 < 5; g_822.f1 += 1)
                {
                    g_1831[g_201][l_2102][g_822.f1] = &g_1139[0];
                }
            }
        }
    }
    (*g_62) &= (safe_add_func_uint64_t_u_u((((*l_2221) && (safe_div_func_uint64_t_u_u((((**g_180) = func_53((((safe_lshift_func_uint8_t_u_u(g_1939[1], (++(*l_2539)))) > (*g_732)) , p_39))) , ((((*l_2556) = ((*l_2221) = ((**g_968) = ((safe_sub_func_int64_t_s_s((((safe_sub_func_uint32_t_u_u((*l_2221), ((safe_add_func_int8_t_s_s((safe_rshift_func_uint32_t_u_s((safe_lshift_func_uint64_t_u_s(((void*)0 != &l_2529), 53)), (safe_add_func_int8_t_s_s(((safe_add_func_int16_t_s_s(((*l_2221) != 0x1A6A542F5B43EED7LL), p_39.f0)) , 0x19L), 0x69L)))), (*l_2221))) == 0x54L))) && (*l_2221)) || p_39.f0), 0x25055108CFCD1ABBLL)) , 0x115DL)))) <= (*g_1732)) && (-1L))), 0x8B5089B286FDEDEALL))) <= 0UL), p_39.f0));
    ++l_2564;
    return p_39.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_733 g_1998 g_1939 g_969 g_1937 g_1732 g_267 g_1358 g_846 g_62 g_614 g_822.f0 g_732 g_662 g_190 g_181 g_55
 * writes: g_1939 g_904 g_63 g_614 g_267 g_117 g_1139
 */
static union U1  func_40(uint32_t  p_41, uint64_t  p_42, uint64_t  p_43, uint64_t  p_44, int32_t  p_45)
{ /* block id: 798 */
    uint64_t *l_2059 = (void*)0;
    int32_t l_2075 = 0x5DA0AFD7L;
    int16_t *l_2078[6][2] = {{&g_75,(void*)0},{&g_75,(void*)0},{&g_75,(void*)0},{&g_75,(void*)0},{&g_75,(void*)0},{&g_75,(void*)0}};
    int32_t l_2079[3][9] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),0x53A95024L,0x35392D1DL},{0x3C7EB21FL,1L,(-1L),0L,0L,(-1L),1L,0x3C7EB21FL,(-1L)},{0x35392D1DL,(-1L),0x3C7EB21FL,(-1L),1L,1L,(-1L),0x3C7EB21FL,(-1L)}};
    uint32_t *l_2087 = (void*)0;
    union U1 l_2092 = {1UL};
    int i, j;
    (*g_62) = ((safe_add_func_int16_t_s_s((l_2075 = (safe_mul_func_int8_t_s_s((safe_div_func_int16_t_s_s((safe_div_func_int64_t_s_s((safe_div_func_int16_t_s_s(((safe_add_func_uint16_t_u_u((l_2059 == (((((safe_lshift_func_uint32_t_u_u(0x3DA34D9AL, (!4294967295UL))) == ((safe_add_func_uint16_t_u_u((((*g_969) = ((((*g_1998) &= ((safe_mod_func_uint8_t_u_u((((safe_sub_func_uint32_t_u_u(p_44, ((safe_add_func_uint16_t_u_u((((g_733[1] , (safe_mul_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(18446744073709551615UL, 0x0E0055ED08D3B59FLL)), (l_2075 ^ (safe_mul_func_uint8_t_u_u(0x7AL, p_41)))))) , p_41) >= 0xB5532C07E61CAA87LL), 4UL)) == 6L))) || (-1L)) <= p_41), p_43)) > l_2075)) < p_43) , p_42)) != l_2075), p_45)) < 0x257E93A659F531A0LL)) <= g_1937[2]) <= l_2075) , (void*)0)), (*g_1732))) , p_42), (-1L))), (*g_1358))), p_45)), 8L))), p_43)) != l_2079[1][1]);
    for (g_614 = (-25); (g_614 > (-3)); g_614 = safe_add_func_int16_t_s_s(g_614, 3))
    { /* block id: 805 */
        int32_t l_2088 = 2L;
        (*g_190) = (+((((p_42 != (safe_sub_func_int16_t_s_s((((*g_662) ^= (safe_add_func_int8_t_s_s((((((l_2079[1][1] || p_44) == ((g_822.f0 , &g_31) == l_2087)) && ((((l_2075 = (0UL <= (0xEDL && (*g_732)))) , l_2075) && p_44) ^ p_42)) && l_2088) != p_43), 0xAAL))) && (*g_662)), 0UL))) <= 0xB5L) ^ p_45) , 0L));
        for (g_267 = 0; (g_267 < 1); g_267 = safe_add_func_uint8_t_u_u(g_267, 4))
        { /* block id: 811 */
            int32_t **l_2091 = &g_1139[0];
            (*l_2091) = &l_2075;
            return (*g_181);
        }
    }
    return l_2092;
}


/* ------------------------------------------ */
/* 
 * reads : g_527 g_77 g_662 g_1997 g_62 g_117 g_190 g_362 g_878 g_689 g_308.f0 g_1937
 * writes: g_527 g_77 g_1329 g_267 g_63 g_117 g_362
 */
static uint32_t  func_49(union U1  p_50, int8_t  p_51, uint8_t  p_52)
{ /* block id: 519 */
    int16_t l_1292[9][6][2] = {{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}},{{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL},{0x55AAL,0x55AAL}}};
    int32_t * const l_1335 = (void*)0;
    uint64_t **l_1336 = &g_1151;
    int32_t * const l_1340 = &g_362;
    int32_t l_1389 = 8L;
    int32_t **l_1405 = &g_484;
    const int16_t ***l_1429 = &g_1426[0][2];
    uint8_t l_1450[2][1][6] = {{{0x5FL,0x5FL,0UL,0x5FL,0x5FL,0UL}},{{0x5FL,0x5FL,0UL,0x5FL,0x5FL,0UL}}};
    union U1 l_1519 = {0UL};
    int32_t l_1633 = 1L;
    int32_t l_1635[4][5][3] = {{{0xD5C5547FL,0x1536D6EAL,9L},{0xE2E7A844L,0x91D1C39EL,0x91D1C39EL},{9L,0xD5C5547FL,0L},{0x17E4E837L,0xE2E7A844L,0L},{9L,9L,0xFC47F46AL}},{{0xE2E7A844L,0x17E4E837L,0xC64BEEEDL},{0xD5C5547FL,9L,0xD5C5547FL},{0x91D1C39EL,0xE2E7A844L,6L},{0x1536D6EAL,0xD5C5547FL,0xD5C5547FL},{6L,0x91D1C39EL,0xC64BEEEDL}},{{0xBBFB52A2L,0x1536D6EAL,0xFC47F46AL},{6L,6L,0L},{0x1536D6EAL,0xBBFB52A2L,0L},{0x91D1C39EL,6L,0x91D1C39EL},{0xD5C5547FL,0x1536D6EAL,9L}},{{0xE2E7A844L,0x91D1C39EL,0x91D1C39EL},{9L,0xD5C5547FL,0L},{0x17E4E837L,0xE2E7A844L,0L},{9L,9L,0xFC47F46AL},{0xE2E7A844L,0x17E4E837L,0xC64BEEEDL}}};
    uint16_t l_1766 = 0x2A20L;
    int16_t ***l_1778 = (void*)0;
    union U0 ***l_1842[9];
    int32_t *l_1882 = (void*)0;
    uint64_t **l_1889 = (void*)0;
    uint16_t l_1983 = 1UL;
    const union U1 ****l_1992[8][10] = {{(void*)0,(void*)0,&g_251[0][2],&g_251[1][0],&g_251[0][2],(void*)0,(void*)0,&g_251[0][2],&g_251[1][0],&g_251[0][2]},{(void*)0,(void*)0,&g_251[0][2],&g_251[1][0],&g_251[0][2],(void*)0,(void*)0,(void*)0,&g_251[0][2],(void*)0},{&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0,&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0},{&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0,&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0},{&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0,&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0},{&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0,&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0},{&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0,&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0},{&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0,&g_251[0][2],&g_251[0][2],(void*)0,&g_251[0][2],(void*)0}};
    int8_t l_2019 = 0x9DL;
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_1842[i] = (void*)0;
lbl_1986:
    for (g_527 = 0; (g_527 < 55); g_527 = safe_add_func_uint8_t_u_u(g_527, 8))
    { /* block id: 522 */
        uint32_t l_1295 = 1UL;
        int32_t *l_1341 = &g_614;
        union U0 **l_1363 = &g_924;
        int32_t l_1392 = 0xB9AA2192L;
        union U1 ***l_1399 = &g_180;
        union U1 ****l_1398[6][8][5] = {{{(void*)0,&l_1399,(void*)0,&l_1399,&l_1399},{(void*)0,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{(void*)0,&l_1399,&l_1399,&l_1399,(void*)0},{&l_1399,(void*)0,(void*)0,&l_1399,&l_1399},{&l_1399,(void*)0,(void*)0,&l_1399,(void*)0},{&l_1399,(void*)0,&l_1399,(void*)0,&l_1399},{&l_1399,&l_1399,&l_1399,(void*)0,(void*)0}},{{&l_1399,&l_1399,(void*)0,&l_1399,&l_1399},{&l_1399,(void*)0,(void*)0,(void*)0,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{(void*)0,&l_1399,&l_1399,(void*)0,&l_1399},{(void*)0,(void*)0,&l_1399,&l_1399,&l_1399},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1399,(void*)0,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,&l_1399,(void*)0,&l_1399}},{{(void*)0,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,&l_1399,(void*)0,&l_1399},{&l_1399,&l_1399,&l_1399,(void*)0,&l_1399},{(void*)0,(void*)0,&l_1399,&l_1399,(void*)0},{(void*)0,&l_1399,&l_1399,&l_1399,(void*)0},{(void*)0,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399}},{{&l_1399,&l_1399,&l_1399,&l_1399,(void*)0},{&l_1399,&l_1399,&l_1399,(void*)0,(void*)0},{(void*)0,&l_1399,&l_1399,&l_1399,&l_1399},{(void*)0,(void*)0,(void*)0,(void*)0,&l_1399},{&l_1399,&l_1399,&l_1399,(void*)0,(void*)0},{&l_1399,&l_1399,&l_1399,&l_1399,(void*)0},{&l_1399,&l_1399,(void*)0,(void*)0,&l_1399},{(void*)0,&l_1399,(void*)0,(void*)0,&l_1399}},{{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{(void*)0,(void*)0,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,(void*)0,&l_1399,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{(void*)0,&l_1399,(void*)0,&l_1399,&l_1399}},{{(void*)0,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,(void*)0,(void*)0,&l_1399},{&l_1399,&l_1399,(void*)0,(void*)0,&l_1399},{&l_1399,&l_1399,&l_1399,(void*)0,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399},{&l_1399,&l_1399,(void*)0,&l_1399,(void*)0},{(void*)0,&l_1399,&l_1399,(void*)0,&l_1399},{&l_1399,&l_1399,&l_1399,&l_1399,&l_1399}}};
        union U1 *****l_1397 = &l_1398[2][7][2];
        union U0 * const l_1410 = &g_1411;
        union U0 * const *l_1409 = &l_1410;
        int32_t l_1509 = (-1L);
        int32_t l_1511 = (-2L);
        uint16_t l_1607[8] = {4UL,4UL,4UL,4UL,4UL,4UL,4UL,4UL};
        int32_t l_1632 = 0xC6E2BCD7L;
        int32_t l_1634 = 0x5CA4ED29L;
        int32_t l_1636[6][6];
        int32_t l_1657 = 0x6C119457L;
        uint64_t l_1718 = 1UL;
        uint64_t ***l_1750 = &g_1150[1];
        const int8_t l_1755 = (-8L);
        int32_t l_1760 = 0x5CA56BDCL;
        int16_t **l_1776 = (void*)0;
        int16_t ** const *l_1775 = &l_1776;
        int16_t ****l_1793[5][1][1] = {{{&g_1424}},{{&g_1424}},{{&g_1424}},{{&g_1424}},{{&g_1424}}};
        uint64_t l_1827 = 0x46C43716437F302CLL;
        uint16_t l_1839 = 8UL;
        uint64_t l_1863 = 1UL;
        int8_t l_1891 = 0xC0L;
        uint64_t l_1952 = 0x0C135A00D67D1322LL;
        uint32_t *l_1982 = &g_1939[1];
        uint32_t **l_1981 = &l_1982;
        int i, j, k;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 6; j++)
                l_1636[i][j] = 0xCF327153L;
        }
    }
    for (g_77 = 11; (g_77 == 1); --g_77)
    { /* block id: 771 */
        uint8_t l_1987 = 0xCCL;
        union U1 ***l_1991[7] = {&g_180,&g_180,&g_180,&g_180,&g_180,&g_180,&g_180};
        union U1 ****l_1990 = &l_1991[2];
        int32_t *l_2003 = &g_117;
        int32_t l_2004 = (-10L);
        uint16_t *l_2020[6] = {&g_267,&g_267,&g_267,&g_267,&g_267,&g_267};
        int32_t l_2025 = 1L;
        int32_t l_2026 = 3L;
        int32_t l_2027 = 0L;
        int32_t l_2028 = 0x07F07E13L;
        int32_t l_2029[1];
        uint32_t l_2030 = 18446744073709551610UL;
        int i;
        for (i = 0; i < 1; i++)
            l_2029[i] = 0xDF8920FCL;
        if (g_527)
            goto lbl_1986;
        if (l_1987)
            continue;
        if ((safe_add_func_int16_t_s_s(1L, (l_1990 == l_1992[7][6]))))
        { /* block id: 774 */
            int8_t *l_1993 = &g_1329;
            int32_t l_2006 = 0xC53728F1L;
            int32_t l_2007[2][8] = {{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}};
            int32_t *l_2024[9][9] = {{&l_2007[0][2],&l_1389,(void*)0,&g_117,&g_117,(void*)0,&l_1389,&l_2007[0][2],&l_2004},{(void*)0,&l_1633,&g_614,&l_2006,&g_614,&l_1633,(void*)0,&l_2006,(void*)0},{&l_2007[0][2],&g_117,&l_1389,&l_1389,&g_117,&l_2007[0][2],(void*)0,&l_1389,&l_2004},{&l_1635[0][4][2],&l_1633,&g_63,&l_1633,&l_1635[0][4][2],&l_2006,&g_63,&l_2006,&l_1635[0][4][2]},{&g_117,&l_2006,&l_2006,&g_117,&l_2004,&l_1389,(void*)0,&l_2007[0][2],&g_117},{&g_614,&l_2006,&g_614,&l_1633,(void*)0,&l_2006,(void*)0,&l_1633,&g_614},{&g_117,&g_117,&l_1389,&l_2006,&l_2004,&l_2007[0][2],&l_1389,(void*)0,&g_117},{&l_1635[0][4][2],&l_2007[0][2],&g_1256,&l_1633,&l_1635[0][4][2],&l_1633,&g_1256,&l_2007[0][2],&l_1635[0][4][2]},{&l_2004,&l_1389,&l_1389,&g_117,&g_117,(void*)0,&l_2006,&l_2007[0][2],&l_2007[0][2]}};
            uint8_t *l_2043[3][7][5] = {{{&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1450[1][0][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1450[1][0][0],&l_1519.f0,&g_571,&l_1519.f0,&l_1450[1][0][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1450[1][0][0],&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1519.f0},{(void*)0,(void*)0,&l_1987,(void*)0,(void*)0},{&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1450[1][0][0]}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1450[1][0][0],&l_1519.f0,&g_571,&l_1519.f0,&l_1450[1][0][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1450[1][0][0],&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1519.f0},{(void*)0,(void*)0,&l_1987,(void*)0,(void*)0},{&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1450[1][0][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&l_1450[1][0][0],&l_1519.f0,&g_571,&l_1519.f0,&l_1450[1][0][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1450[1][0][0],&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1519.f0},{(void*)0,(void*)0,&l_1987,(void*)0,(void*)0},{&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1519.f0,&l_1450[1][0][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1450[1][0][0],&l_1519.f0,&g_571,&l_1519.f0,&l_1450[1][0][0]}}};
            uint8_t **l_2044 = (void*)0;
            uint8_t *l_2046[7] = {&l_1450[1][0][0],&l_1450[1][0][0],&l_1450[1][0][0],&l_1450[1][0][0],&l_1450[1][0][0],&l_1450[1][0][0],&l_1450[1][0][0]};
            uint8_t **l_2045 = &l_2046[2];
            int i, j, k;
            if ((255UL ^ ((*l_1993) = p_51)))
            { /* block id: 776 */
                int32_t **l_2001 = (void*)0;
                int32_t **l_2002[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
                int8_t l_2005 = 0x55L;
                uint32_t l_2008 = 1UL;
                int i;
                (*g_62) = (safe_sub_func_uint16_t_u_u(((*g_662) = 65531UL), (0xDA204D060A7C49E7LL == ((+((void*)0 != g_1997)) > 0UL))));
                l_2003 = &l_1633;
                if (p_51)
                    goto lbl_1986;
                ++l_2008;
            }
            else
            { /* block id: 782 */
                const uint32_t l_2023 = 1UL;
                if (p_50.f0)
                    break;
                (*g_190) = (safe_add_func_uint8_t_u_u(((safe_sub_func_uint8_t_u_u((((safe_lshift_func_int64_t_s_s(((safe_mod_func_int64_t_s_s(l_2019, (((((-1L) < (*l_2003)) , l_2020[0]) != &g_267) , 0x97A7922671B73A5FLL))) < (safe_add_func_int32_t_s_s((4294967295UL >= l_2023), (*l_2003)))), p_51)) , 0L) <= p_50.f0), p_52)) && p_50.f0), p_51));
                (*l_2003) = (-6L);
                return l_2007[0][5];
            }
            --l_2030;
            (*l_1340) ^= (p_51 , ((void*)0 != l_1335));
            (*g_190) = (((((247UL <= (safe_rshift_func_uint8_t_u_s(0x10L, (safe_add_func_uint8_t_u_u(((*l_2003) || 0xDBL), (((safe_div_func_int32_t_s_s(p_51, p_51)) | ((*l_2003) , (safe_div_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u((&g_80 != ((*l_2045) = (l_2043[2][4][1] = &l_1987))), p_52)), p_50.f0)))) || 0x2DDDC396L)))))) , (*g_878)) ^ (*l_2003)) , p_50.f0) <= p_51);
        }
        else
        { /* block id: 793 */
            return g_308[0][2].f0;
        }
    }
    return g_1937[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_55.f0 g_190
 * writes: g_55.f0 g_117 g_362 g_63
 */
static union U1  func_53(union U1  p_54)
{ /* block id: 2 */
    uint64_t l_1141 = 0x3EC9C2C492DED8AFLL;
    uint64_t **l_1153[8];
    uint64_t ** const l_1154 = (void*)0;
    const union U1 ****l_1155 = &g_251[0][2];
    union U1 ***l_1157 = (void*)0;
    union U1 ****l_1156 = &l_1157;
    int8_t ***l_1189 = &g_1060;
    union U0 *l_1190 = &g_1191;
    int32_t *l_1196[10][6][4] = {{{&g_614,&g_797,(void*)0,&g_614},{&g_797,&g_63,&g_117,&g_614},{&g_362,&g_63,&g_63,&g_797},{(void*)0,&g_797,&g_362,(void*)0},{&g_117,&g_797,&g_614,&g_797},{(void*)0,&g_797,&g_797,&g_614}},{{&g_614,&g_117,&g_614,(void*)0},{&g_63,&g_797,(void*)0,&g_362},{(void*)0,&g_63,&g_797,&g_117},{&g_362,&g_362,&g_117,&g_63},{&g_63,&g_797,&g_797,(void*)0},{&g_614,&g_63,&g_63,&g_63}},{{&g_614,&g_63,&g_614,&g_63},{(void*)0,&g_63,&g_614,&g_797},{&g_614,&g_117,&g_614,&g_614},{&g_797,&g_797,&g_117,(void*)0},{&g_614,&g_797,&g_117,(void*)0},{&g_362,&g_362,(void*)0,&g_117}},{{&g_117,&g_362,&g_117,(void*)0},{&g_362,&g_797,&g_797,(void*)0},{&g_63,&g_797,&g_117,&g_614},{&g_614,&g_117,&g_117,&g_797},{&g_117,&g_63,&g_362,&g_63},{&g_614,&g_63,&g_63,&g_63}},{{(void*)0,&g_63,&g_614,(void*)0},{(void*)0,&g_797,(void*)0,&g_63},{&g_117,&g_362,&g_797,&g_117},{&g_797,&g_63,&g_63,&g_362},{&g_63,&g_797,&g_63,&g_614},{&g_797,&g_614,&g_797,&g_362}},{{&g_117,&g_614,(void*)0,&g_117},{(void*)0,&g_117,&g_614,&g_63},{(void*)0,&g_117,&g_63,&g_614},{&g_614,&g_797,&g_362,&g_797},{&g_117,&g_614,&g_117,&g_797},{&g_614,&g_117,&g_117,&g_614}},{{&g_63,(void*)0,&g_797,&g_117},{&g_362,&g_614,&g_117,&g_614},{&g_117,(void*)0,(void*)0,&g_614},{&g_362,&g_614,&g_117,&g_117},{&g_614,(void*)0,&g_117,&g_614},{&g_797,&g_117,&g_614,&g_797}},{{&g_614,&g_614,&g_614,&g_797},{(void*)0,&g_797,&g_614,&g_614},{&g_614,&g_117,&g_63,&g_63},{&g_614,&g_117,&g_797,&g_117},{&g_63,&g_614,&g_117,&g_362},{&g_362,&g_614,&g_797,&g_614}},{{(void*)0,&g_797,(void*)0,&g_362},{(void*)0,&g_63,&g_797,&g_117},{&g_362,&g_362,&g_117,&g_63},{&g_63,&g_797,&g_797,(void*)0},{&g_614,&g_63,&g_63,&g_63},{&g_614,&g_63,&g_614,&g_63}},{{(void*)0,&g_63,&g_614,&g_797},{&g_797,&g_797,&g_117,&g_117},{&g_117,&g_117,&g_63,(void*)0},{&g_117,&g_614,&g_614,&g_63},{&g_63,&g_362,&g_614,&g_614},{&g_614,&g_362,&g_797,&g_63}}};
    uint16_t l_1235 = 65535UL;
    int64_t *l_1280[6][9][4] = {{{&g_746,&g_746,&g_847,(void*)0},{&g_746,&g_746,(void*)0,&g_847},{&g_746,&g_746,&g_847,&g_847},{&g_746,&g_846,&g_746,(void*)0},{&g_846,&g_846,&g_746,(void*)0},{&g_746,&g_847,&g_746,&g_847},{&g_847,&g_846,&g_746,&g_746},{&g_746,&g_846,&g_847,&g_746},{&g_847,&g_746,&g_846,&g_746}},{{&g_847,&g_846,&g_847,&g_746},{&g_746,&g_746,&g_746,&g_746},{&g_847,&g_746,&g_746,&g_847},{&g_746,&g_847,&g_746,&g_846},{&g_846,(void*)0,&g_746,&g_847},{&g_746,(void*)0,&g_847,&g_846},{&g_746,&g_746,(void*)0,&g_846},{&g_746,(void*)0,&g_847,&g_846},{&g_746,&g_847,&g_746,&g_846}},{{&g_846,&g_746,&g_746,&g_847},{&g_847,&g_846,&g_746,&g_847},{(void*)0,&g_746,&g_847,&g_847},{(void*)0,&g_746,&g_746,&g_846},{&g_847,&g_846,&g_847,&g_847},{&g_846,&g_847,&g_847,&g_847},{&g_846,(void*)0,&g_846,&g_746},{&g_847,&g_847,(void*)0,&g_846},{&g_746,&g_746,&g_847,&g_846}},{{&g_847,&g_746,&g_746,&g_746},{&g_846,&g_846,&g_746,&g_846},{&g_846,&g_846,(void*)0,&g_746},{&g_746,&g_847,&g_746,(void*)0},{&g_846,&g_847,&g_746,&g_746},{&g_847,&g_846,&g_847,&g_846},{&g_746,&g_846,&g_746,&g_746},{(void*)0,&g_746,&g_846,&g_846},{&g_746,&g_746,&g_846,&g_846}},{{&g_746,&g_847,&g_746,&g_746},{&g_846,(void*)0,&g_746,&g_847},{(void*)0,&g_847,(void*)0,&g_847},{&g_847,&g_846,&g_746,&g_846},{&g_847,&g_746,&g_847,&g_847},{&g_846,&g_746,&g_846,&g_847},{&g_847,&g_846,&g_847,&g_846},{&g_746,&g_847,&g_746,&g_846},{&g_746,&g_846,(void*)0,&g_746}},{{&g_847,&g_847,&g_746,&g_847},{(void*)0,(void*)0,&g_847,(void*)0},{&g_847,&g_847,&g_746,&g_846},{&g_746,&g_746,&g_746,&g_846},{&g_746,&g_746,&g_846,&g_746},{&g_746,(void*)0,&g_746,(void*)0},{&g_746,&g_847,&g_746,&g_846},{&g_847,(void*)0,(void*)0,&g_847},{&g_846,&g_847,(void*)0,&g_746}}};
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_1153[i] = &g_1151;
    for (g_55.f0 = (-6); (g_55.f0 >= 50); g_55.f0 = safe_add_func_int32_t_s_s(g_55.f0, 6))
    { /* block id: 5 */
        int32_t * const l_64 = &g_63;
        int32_t l_1160[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
        uint64_t ***l_1172 = &g_1150[3];
        uint64_t ****l_1171[10][3][1] = {{{(void*)0},{&l_1172},{&l_1172}},{{(void*)0},{&l_1172},{(void*)0}},{{&l_1172},{&l_1172},{(void*)0}},{{&l_1172},{&l_1172},{(void*)0}},{{&l_1172},{&l_1172},{(void*)0}},{{&l_1172},{(void*)0},{&l_1172}},{{&l_1172},{(void*)0},{&l_1172}},{{&l_1172},{(void*)0},{&l_1172}},{{&l_1172},{(void*)0},{&l_1172}},{{(void*)0},{&l_1172},{&l_1172}}};
        uint64_t ***** const l_1170 = &l_1171[1][1][0];
        int32_t *l_1223 = &g_362;
        union U1 l_1251 = {5UL};
        int8_t l_1257 = 0xC9L;
        int i, j, k;
    }
    (*g_190) = ((p_54.f0 , l_1280[5][1][1]) == (void*)0);
    return p_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_75 g_46.f0 g_85 g_63 g_55 g_113 g_62 g_116 g_117 g_123 g_77 g_189 g_190 g_201 g_113.f0 g_46 g_55.f0 g_241 g_80 g_203 g_267 g_278 g_252 g_253 g_254 g_321 g_614 g_731 g_732 g_733 g_308.f0 g_1139
 * writes: g_75 g_77 g_80 g_85 g_63 g_117 g_190 g_241 g_251 g_267 g_278 g_321 g_614 g_924 g_662 g_308
 */
static int32_t * func_58(int32_t * const  p_59, int16_t  p_60, int32_t * const  p_61)
{ /* block id: 6 */
    int8_t l_67 = (-1L);
    int16_t *l_72 = (void*)0;
    int16_t *l_73 = (void*)0;
    int16_t *l_74 = &g_75;
    int16_t *l_76 = &g_77;
    int32_t l_78 = (-1L);
    int32_t l_79 = 3L;
    int64_t l_150 = 0xDED785604A185305LL;
    int32_t l_159[3][9] = {{0x9567760CL,0x7F728D9CL,1L,0x08BCBAD6L,0xBDB4F01BL,0x08BCBAD6L,1L,0x7F728D9CL,0x9567760CL},{3L,0x08BCBAD6L,0x9567760CL,0xBDB4F01BL,0x7C57D7CEL,8L,0x7C57D7CEL,0xBDB4F01BL,0x9567760CL},{0x7C57D7CEL,0x7C57D7CEL,3L,0L,0x7F728D9CL,(-1L),0x9567760CL,(-1L),0x7F728D9CL}};
    int32_t l_204 = (-1L);
    uint8_t l_205 = 0x24L;
    const int32_t **l_215 = (void*)0;
    uint8_t l_237 = 0xB4L;
    union U1 *l_291 = &g_55;
    uint64_t *l_344[9][8] = {{&g_321,&g_85,&g_85,&g_85,&g_85,&g_321,&g_85,&g_85},{&g_85,&g_85,&g_85,&g_85,&g_85,&g_85,&g_85,&g_321},{&g_85,&g_85,&g_321,&g_85,&g_85,&g_321,&g_85,&g_85},{&g_321,&g_85,&g_85,&g_85,&g_85,&g_85,&g_85,&g_85},{&g_85,&g_85,&g_321,&g_85,&g_85,&g_85,&g_85,&g_321},{&g_85,&g_85,&g_321,&g_85,&g_85,&g_321,&g_85,&g_85},{&g_321,&g_85,&g_321,&g_85,&g_85,&g_85,&g_85,&g_85},{&g_85,&g_85,&g_85,&g_85,&g_85,&g_321,&g_85,&g_321},{&g_85,&g_85,&g_321,&g_85,&g_85,&g_321,&g_85,&g_85}};
    uint32_t *l_351 = &g_278;
    int8_t l_363 = 2L;
    int64_t l_429 = 4L;
    int8_t l_457 = 0x37L;
    uint32_t l_568 = 0x94EE358DL;
    int8_t * const l_702 = (void*)0;
    int8_t * const *l_701 = &l_702;
    int32_t l_723 = 0x7022A5A5L;
    int32_t l_726 = (-1L);
    const int16_t l_795 = 0L;
    int32_t *l_821 = &g_63;
    int64_t **l_870 = (void*)0;
    int64_t l_881 = 0x6446362D3EAFA367LL;
    uint32_t l_905 = 0xD135F5F1L;
    uint32_t l_909[8] = {0xBD40C477L,0xBD40C477L,0xBD40C477L,0xBD40C477L,0xBD40C477L,0xBD40C477L,0xBD40C477L,0xBD40C477L};
    const union U0 *l_925 = &g_123;
    const int16_t *l_945 = &g_77;
    uint64_t **l_948[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint64_t ***l_947 = &l_948[7];
    uint64_t ****l_946 = &l_947;
    int32_t *l_954 = (void*)0;
    union U1 ** const *l_958 = &g_180;
    union U1 ** const **l_957 = &l_958;
    union U1 ** const ***l_956 = &l_957;
    int32_t **l_1110 = (void*)0;
    int32_t *l_1137 = &l_159[1][0];
    int32_t *l_1138 = &l_79;
    int i, j;
    if ((p_60 , (safe_div_func_uint8_t_u_u((g_80 = (p_60 >= (((-9L) & (g_31 > l_67)) , ((l_67 , &g_63) != (((((safe_mod_func_uint64_t_u_u((((l_79 = (l_78 = ((safe_div_func_int16_t_s_s(((*l_76) = ((*l_74) &= (l_67 , p_60))), 0x30A8L)) || p_60))) , &l_79) == &g_63), p_60)) | l_67) != g_46[6].f0) || g_75) , &l_79))))), l_67))))
    { /* block id: 12 */
        int16_t l_86[9][2];
        int32_t l_88 = 1L;
        uint8_t l_105[4] = {0xCAL,0xCAL,0xCAL,0xCAL};
        int32_t l_149 = 0x7C28FDDEL;
        int32_t *l_152 = &g_117;
        int32_t *l_153 = &l_78;
        int32_t *l_154 = &l_149;
        int32_t *l_155 = (void*)0;
        int32_t *l_156 = &g_117;
        int32_t *l_157 = (void*)0;
        int32_t *l_158[10] = {(void*)0,&l_78,(void*)0,(void*)0,&l_78,(void*)0,(void*)0,&l_78,(void*)0,(void*)0};
        uint8_t l_160 = 255UL;
        int32_t l_202 = 0xB4A03188L;
        int i, j;
        for (i = 0; i < 9; i++)
        {
            for (j = 0; j < 2; j++)
                l_86[i][j] = 0x1057L;
        }
        for (p_60 = 6; (p_60 != 27); p_60++)
        { /* block id: 15 */
            uint64_t *l_83 = (void*)0;
            uint64_t *l_84[10] = {&g_85,&g_85,&g_85,&g_85,&g_85,&g_85,&g_85,&g_85,&g_85,&g_85};
            int32_t l_87 = (-1L);
            uint8_t *l_124 = &l_105[0];
            int64_t *l_151 = &l_150;
            int i;
            if ((l_67 <= (--g_85)))
            { /* block id: 17 */
                int32_t *l_92 = &l_79;
                int32_t **l_91 = &l_92;
                (*l_91) = p_59;
            }
            else
            { /* block id: 19 */
                if ((safe_add_func_uint32_t_u_u(p_60, ((p_60 < g_31) ^ (1L != ((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s(0xC7L, g_63)), p_60)) >= p_60))))))
                { /* block id: 20 */
                    int64_t l_112 = 1L;
                    union U1 *l_114 = &g_55;
                    union U1 **l_115 = &l_114;
                    (*p_61) = ((((((safe_sub_func_int32_t_s_s((safe_lshift_func_int8_t_s_s(l_105[3], 1)), (safe_lshift_func_int32_t_s_u((safe_lshift_func_uint16_t_u_u((safe_add_func_int16_t_s_s(((*l_74) &= (g_55 , ((g_31 && l_112) , ((g_113 , 0x19369D4055D0160BLL) , p_60)))), ((void*)0 == &g_62))), p_60)), p_60)))) | p_60) , g_63) , p_60) ^ l_78) > p_60);
                    (*l_115) = l_114;
                }
                else
                { /* block id: 24 */
                    (*g_116) ^= (*g_62);
                }
            }
            l_87 = (p_60 , (safe_mul_func_int16_t_s_s(0xB4A0L, ((safe_add_func_int64_t_s_s((+((g_123 , ((*l_124)--)) | 0x55L)), (0L || (safe_mul_func_int64_t_s_s(((safe_add_func_int8_t_s_s((((*l_151) = ((l_88 ^ (g_85 = (safe_mod_func_uint64_t_u_u((safe_add_func_uint8_t_u_u((!(((safe_mod_func_int64_t_s_s(((((safe_sub_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_s(((safe_add_func_uint8_t_u_u((l_149 = (safe_add_func_int32_t_s_s((safe_add_func_uint16_t_u_u((l_87 < (0xB2L ^ ((safe_unary_minus_func_int64_t_s(g_31)) , 0UL))), 0x811DL)), l_79))), 0x69L)) , l_150), 7)) ^ p_60), p_60)) > 0x8FL) || 1L) , 0xC3B02FF5F5FB1240LL), 0x72C646EC4B94AD5ALL)) ^ p_60) || p_60)), 4L)), p_60)))) < p_60)) == g_77), (-6L))) <= p_60), 0UL))))) | (-1L)))));
            return &g_117;
        }
        l_160++;
        for (g_63 = 0; (g_63 <= (-11)); g_63 = safe_sub_func_int64_t_s_s(g_63, 5))
        { /* block id: 38 */
            union U1 *l_179 = &g_55;
            union U1 **l_178 = &l_179;
            for (l_88 = (-10); (l_88 > 2); l_88++)
            { /* block id: 41 */
                int32_t l_191 = 0L;
                uint64_t *l_200 = (void*)0;
                if ((*g_62))
                    break;
                for (l_160 = 0; (l_160 <= 3); l_160 += 1)
                { /* block id: 45 */
                    int32_t *l_185 = &l_149;
                }
            }
            (*g_189) = (*g_189);
        }
        ++l_205;
    }
    else
    { /* block id: 75 */
        int32_t l_210 = 5L;
        int32_t **l_216[8] = {&g_190,&g_190,&g_190,&g_190,&g_190,&g_190,&g_190,&g_190};
        const union U1 *l_250 = (void*)0;
        const union U1 **l_249 = &l_250;
        const union U1 ***l_248 = &l_249;
        const int8_t *l_300[1];
        const int8_t *l_302 = &l_67;
        uint8_t l_319 = 0UL;
        uint64_t *l_342[4];
        int32_t l_459 = 0xACE968B8L;
        uint64_t l_463 = 18446744073709551612UL;
        uint64_t l_485 = 18446744073709551614UL;
        uint32_t l_505[9] = {0xEEB1A529L,0xEEB1A529L,0xEEB1A529L,0xEEB1A529L,0xEEB1A529L,0xEEB1A529L,0xEEB1A529L,0xEEB1A529L,0xEEB1A529L};
        uint32_t l_697 = 0x5375E05EL;
        uint8_t l_705 = 0xF1L;
        int32_t *l_912 = &l_78;
        int i;
        for (i = 0; i < 1; i++)
            l_300[i] = (void*)0;
        for (i = 0; i < 4; i++)
            l_342[i] = &g_321;
        for (g_77 = (-20); (g_77 != (-26)); g_77 = safe_sub_func_uint64_t_u_u(g_77, 1))
        { /* block id: 78 */
            uint32_t l_263 = 0x23C0D81AL;
            int32_t *l_276 = &g_241;
            union U1 * const l_306[8] = {&g_55,&g_55,&g_55,&g_55,&g_55,&g_55,&g_55,&g_55};
            union U1 *l_307 = &g_308[0][2];
            int64_t *l_318 = &l_150;
            int32_t l_324[10];
            int i;
            for (i = 0; i < 10; i++)
                l_324[i] = (-4L);
            (*p_61) |= l_210;
            for (l_79 = (-23); (l_79 == 1); l_79 = safe_add_func_uint64_t_u_u(l_79, 4))
            { /* block id: 82 */
                int8_t *l_236[2][8][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}}};
                int32_t l_238 = 0x0BED4B98L;
                int32_t *l_239 = (void*)0;
                int32_t *l_240[10] = {&g_123.f4,&g_241,&g_241,&g_241,&g_123.f4,&g_123.f4,&g_241,&g_241,&g_241,&g_123.f4};
                uint32_t *l_242 = (void*)0;
                union U1 **l_289[1][2][6] = {{{&g_181,&g_181,&g_181,&g_181,&g_181,&g_181},{&g_181,&g_181,&g_181,&g_181,&g_181,&g_181}}};
                int32_t l_296 = 0x206E7069L;
                int i, j, k;
                if ((safe_sub_func_uint32_t_u_u((l_215 != l_216[0]), (l_159[1][0] = (safe_add_func_int64_t_s_s(((g_241 &= ((p_60 , 0x28838847L) == (((safe_lshift_func_uint32_t_u_s((safe_lshift_func_int8_t_s_s(((safe_sub_func_int32_t_s_s(((void*)0 == p_59), ((l_237 = ((safe_sub_func_int8_t_s_s(((safe_add_func_uint32_t_u_u(((((safe_mod_func_uint16_t_u_u((safe_div_func_int8_t_s_s((((((((safe_sub_func_int32_t_s_s((*p_61), (!g_201))) != ((-1L) == (*g_62))) , 8L) , 0x42D0F614L) ^ (*g_190)) && 1UL) == 65528UL), 0x3BL)), 0x24BCL)) , g_113.f0) , g_46[2]) , p_60), 4294967288UL)) != 0x1BEFFD9DL), p_60)) ^ g_55.f0)) && 0x71L))) != (-4L)), 7)), (*g_190))) == l_238) & 0x8A6834DD0C7240D8LL))) , g_75), g_117))))))
                { /* block id: 86 */
                    const union U1 ****l_255 = &l_248;
                    int32_t l_262 = 1L;
                    const int32_t l_275 = (-3L);
                    int32_t l_292[6] = {1L,0xA759260AL,1L,1L,0xA759260AL,1L};
                    int i;
                    l_263 &= ((g_80 , ((safe_mod_func_int16_t_s_s((!((safe_sub_func_int32_t_s_s((((*l_255) = (g_251[0][2] = l_248)) != &l_249), ((safe_lshift_func_int32_t_s_u((*g_190), 27)) , 0x58DF00F4L))) , 1L)), (safe_add_func_uint16_t_u_u(0x18BAL, (l_262 ^= ((p_60 ^ ((**g_189) ^ (*g_62))) >= 0UL)))))) , (void*)0)) != (void*)0);
                    if ((*p_61))
                        continue;
                    (*p_61) ^= (*g_116);
                    if ((*p_61))
                    { /* block id: 93 */
                        union U1 ****l_265 = (void*)0;
                        uint16_t *l_266 = &g_267;
                        uint32_t *l_277 = &g_278;
                        int32_t l_290 = 1L;
                        l_292[5] |= (((*l_74) = (g_203[6][4][1] ^ (((~((void*)0 != l_265)) || ((*l_266)--)) | ((((((((((safe_sub_func_uint64_t_u_u((safe_add_func_uint8_t_u_u((~((l_275 | ((p_59 == l_276) < g_55.f0)) < (++(*l_277)))), (safe_unary_minus_func_uint16_t_u(((safe_mul_func_int64_t_s_s((safe_mod_func_uint16_t_u_u(((safe_lshift_func_int64_t_s_u(0xB573957DEBA7D998LL, (((!(((l_289[0][1][5] == (*l_248)) & 9UL) | g_117)) ^ p_60) , l_290))) == l_238), g_77)), l_262)) > 0L))))), g_63)) & (-2L)) < 0xEE604584355FB1D9LL) && 0x0A3CL) | g_85) >= 0x8AL) , 6L) , l_291) != (*l_249)) | 4294967295UL)))) && 0x8C65L);
                    }
                    else
                    { /* block id: 98 */
                        uint32_t l_293 = 4294967294UL;
                        l_293++;
                        (*p_61) = ((void*)0 == &g_267);
                        (*g_189) = (*g_189);
                    }
                }
                else
                { /* block id: 103 */
                    uint8_t l_297 = 0xF6L;
                    const int8_t **l_301 = &l_300[0];
                    ++l_297;
                    if ((((*l_301) = l_300[0]) == l_302))
                    { /* block id: 106 */
                        (*g_190) = ((*g_62) = 0L);
                    }
                    else
                    { /* block id: 109 */
                        int32_t *l_303[6][10][4] = {{{&l_204,&g_117,&l_78,&l_210},{&l_238,&l_78,&l_210,&g_63},{&l_159[1][3],&l_78,&g_117,&l_296},{&l_159[0][8],&l_79,(void*)0,&l_159[1][0]},{(void*)0,&g_117,&l_79,(void*)0},{&l_210,&l_78,&l_159[1][0],&l_78},{&l_238,&l_159[1][3],&l_159[1][0],&g_63},{&l_210,&l_210,&g_117,(void*)0},{&g_63,&l_238,(void*)0,&l_79},{&l_238,&l_159[1][0],&l_210,(void*)0}},{{&g_63,&l_238,(void*)0,&g_63},{&l_238,(void*)0,&l_159[1][3],&g_117},{&g_117,&l_159[1][0],&g_117,&l_159[1][0]},{&l_159[1][0],&l_159[0][8],&l_79,&l_159[1][0]},{&g_117,&l_78,(void*)0,(void*)0},{&l_79,&l_238,&l_204,&l_204},{&l_79,&l_78,(void*)0,&l_238},{&g_117,&l_204,&g_117,&l_210},{&g_63,&l_78,&l_79,&l_296},{&l_79,&l_210,&l_296,(void*)0}},{{(void*)0,&g_63,&g_63,&l_79},{&l_159[1][3],&l_159[1][0],&l_78,&l_210},{&l_159[0][1],(void*)0,&l_238,&g_63},{&l_210,&l_79,&l_79,&l_159[0][8]},{&l_159[1][0],&l_159[1][0],&l_210,&l_204},{&l_79,&l_296,(void*)0,&g_63},{&l_296,&l_79,&l_79,&l_296},{&g_117,&g_117,&g_63,&l_238},{&l_238,&g_63,&l_296,(void*)0},{&l_296,&g_63,(void*)0,&l_159[1][3]}},{{&l_210,&g_63,&l_159[1][0],&l_159[1][0]},{&l_79,&l_159[1][0],&l_159[1][0],&l_79},{&l_78,&l_210,(void*)0,&l_238},{&l_204,&l_159[1][3],&l_78,&l_210},{(void*)0,&l_79,&l_79,&l_296},{&l_296,(void*)0,&l_78,(void*)0},{&l_78,&l_79,(void*)0,&g_63},{&l_79,&g_63,(void*)0,&l_78},{&l_238,&l_79,&g_63,&l_159[1][0]},{&g_117,&g_117,&l_204,&l_204}},{{&l_78,&l_78,&l_296,&l_78},{(void*)0,&l_210,&g_63,&g_117},{(void*)0,(void*)0,&g_117,&g_63},{&l_79,(void*)0,&g_117,&g_117},{(void*)0,&l_210,&l_79,&l_78},{&l_159[1][0],&l_78,&l_238,&l_204},{&l_238,&g_117,&l_79,&l_159[1][0]},{&l_78,&l_79,(void*)0,&l_78},{&l_159[1][0],&g_63,&l_210,&g_63},{&l_79,&l_79,&l_204,(void*)0}},{{(void*)0,(void*)0,&l_78,&l_296},{&g_117,&l_79,&g_117,&l_210},{&g_63,&l_159[1][3],&g_117,&l_238},{&g_117,&l_210,&l_210,&l_79},{&l_159[1][0],&l_159[1][0],&l_210,&l_159[1][0]},{&l_296,&g_63,&l_79,&l_159[1][3]},{&l_159[1][0],&g_63,&l_79,(void*)0},{&l_210,&g_63,(void*)0,&l_238},{(void*)0,&g_117,&l_296,&l_296},{(void*)0,&l_79,&l_159[1][0],&g_63}}};
                        int i, j, k;
                        return (*g_189);
                    }
                }
            }
            for (g_267 = (-21); (g_267 == 38); g_267++)
            { /* block id: 116 */
                const uint32_t l_311[7][9][4] = {{{0xF796F7ADL,4294967294UL,4294967289UL,0x24607D91L},{0xB1DB1BB6L,0x602E2CF9L,1UL,4294967290UL},{0x035DC35DL,0x0DB10948L,0x73FCD9E7L,4294967290UL},{4294967288UL,0x602E2CF9L,0xEAA7AA2BL,0x24607D91L},{4294967295UL,4294967294UL,4294967291UL,5UL},{0x65951A69L,0xE1F03AA0L,1UL,0UL},{1UL,5UL,4294967295UL,3UL},{0xEAA7AA2BL,0xB2F358D3L,1UL,0x25D2DD31L},{0xEDC7D469L,0x24A831C9L,1UL,0xB2F358D3L}},{{0xBABC1A27L,0x9F10D2EEL,0xF104C48CL,0xD765B617L},{0x0DB10948L,0x24607D91L,1UL,4294967292UL},{4294967292UL,1UL,0xA75C545DL,1UL},{1UL,9UL,4294967292UL,1UL},{0x25D2DD31L,0x73FCD9E7L,0UL,4294967293UL},{0UL,1UL,1UL,4294967288UL},{4294967295UL,1UL,0x54E5BD1AL,3UL},{0x143401A0L,4294967293UL,4294967294UL,4294967295UL},{4294967293UL,1UL,0x079757A9L,1UL}},{{0xBABC1A27L,0x25D2DD31L,1UL,1UL},{5UL,0x143401A0L,0xA7EA4D04L,0x143401A0L},{0x561D6E94L,1UL,0xABD5F4E8L,0xEAA7AA2BL},{0xA75C545DL,4294967295UL,7UL,0xD765B617L},{1UL,0UL,0UL,0x0DB10948L},{1UL,0x24A831C9L,7UL,0x73FCD9E7L},{0xA75C545DL,0x0DB10948L,0xABD5F4E8L,3UL},{0x561D6E94L,4294967289UL,0xA7EA4D04L,0x9F10D2EEL},{5UL,0xE1F03AA0L,1UL,5UL}},{{0xBABC1A27L,4294967288UL,0x079757A9L,4294967292UL},{4294967293UL,0xE1433713L,4294967294UL,4294967295UL},{0x143401A0L,1UL,0x54E5BD1AL,0x561D6E94L},{4294967295UL,4294967292UL,1UL,4294967292UL},{0UL,4294967295UL,0UL,4294967289UL},{0x25D2DD31L,0xE1F03AA0L,4294967292UL,0xF796F7ADL},{1UL,4294967292UL,0xA75C545DL,3UL},{4294967292UL,0xEDC7D469L,1UL,0xF35F916BL},{0x0DB10948L,0x24A831C9L,0xF104C48CL,0xEDC7D469L}},{{0xBABC1A27L,0xF796F7ADL,1UL,0xD765B617L},{0xEDC7D469L,0x561D6E94L,1UL,0xE1433713L},{0xEAA7AA2BL,1UL,4294967295UL,9UL},{1UL,1UL,1UL,1UL},{0xF35F916BL,0xF35F916BL,0UL,1UL},{0xF796F7ADL,1UL,3UL,1UL},{4294967295UL,1UL,0x7F73C634L,3UL},{9UL,1UL,4294967294UL,1UL},{1UL,1UL,4294967291UL,1UL}},{{0xBABC1A27L,0xF35F916BL,0xE1F03AA0L,1UL},{4294967292UL,1UL,0xA7EA4D04L,9UL},{4294967295UL,1UL,0xBABC1A27L,0xE1433713L},{0xA75C545DL,0x561D6E94L,0x229954B3L,0xD765B617L},{4294967288UL,0xF796F7ADL,0UL,0xEDC7D469L},{4294967295UL,0x24A831C9L,0UL,0xF35F916BL},{0xA75C545DL,0xEDC7D469L,0xC77F9D6CL,3UL},{0x24607D91L,4294967292UL,0xA7EA4D04L,0xBABC1A27L},{4294967291UL,0UL,0UL,4294967291UL}},{{0xA39DE8ADL,1UL,4294967295UL,5UL},{0xE1F03AA0L,0UL,1UL,1UL},{0x229954B3L,4294967294UL,0x012BB54EL,0xD765B617L},{4294967290UL,1UL,0xB1DB1BB6L,5UL},{0xABD5F4E8L,4294967295UL,0x9F10D2EEL,0x401A7045L},{0x7F73C634L,0UL,4294967294UL,0xABD5F4E8L},{4294967295UL,4294967291UL,4294967295UL,5UL},{1UL,1UL,4294967295UL,0x7F73C634L},{0UL,0UL,1UL,1UL}}};
                uint64_t *l_314 = &g_85;
                int32_t l_320 = 0L;
                int i, j, k;
                l_307 = l_306[2];
                g_321 ^= (l_320 |= (safe_mul_func_int8_t_s_s(l_311[2][7][2], ((safe_add_func_uint64_t_u_u(((*l_314) = g_203[1][7][0]), ((safe_rshift_func_int32_t_s_s((~l_311[2][7][2]), 11)) != ((**g_252) , (*p_61))))) , ((g_85 = (((((*l_74) = (((p_60 && p_60) , (l_318 != l_314)) && 0x0065L)) , l_319) <= l_311[0][4][2]) , g_55.f0)) < g_267)))));
                if ((*p_61))
                    continue;
                (*g_189) = (*g_189);
            }
            for (p_60 = 0; (p_60 >= 24); p_60 = safe_add_func_int8_t_s_s(p_60, 7))
            { /* block id: 128 */
                uint32_t l_325 = 0x22650834L;
                --l_325;
                for (l_204 = 8; (l_204 >= 0); l_204 -= 1)
                { /* block id: 132 */
                    int i;
                    if (l_324[(l_204 + 1)])
                        break;
                }
                return (*g_189);
            }
        }
        for (g_75 = 2; (g_75 >= 0); g_75 -= 1)
        { /* block id: 140 */
            union U1 l_328 = {0xA1L};
            int32_t *l_330 = &g_63;
            int32_t l_353 = 0x14374E92L;
            int32_t l_354 = 0x85567A75L;
            int32_t l_358[3][9][5] = {{{0L,0L,0x6A8AA791L,1L,0x0B818053L},{0x5685CE02L,0xF52238DBL,(-10L),0x897AE2AFL,(-5L)},{0x0B818053L,0L,0L,0L,0x0B818053L},{(-5L),0x897AE2AFL,(-10L),0xF52238DBL,0x5685CE02L},{0x0B818053L,1L,0x6A8AA791L,0L,0L},{0x5685CE02L,0x897AE2AFL,0x3F373618L,0x897AE2AFL,0x5685CE02L},{0L,0L,0x6A8AA791L,1L,0x0B818053L},{0x5685CE02L,0xF52238DBL,(-10L),0x897AE2AFL,(-5L)},{0x0B818053L,0L,0L,0L,0x0B818053L}},{{(-5L),0x897AE2AFL,(-10L),0xF52238DBL,0x5685CE02L},{0x0B818053L,1L,0x6A8AA791L,0L,0L},{0x5685CE02L,0x897AE2AFL,0x3F373618L,0x897AE2AFL,0x5685CE02L},{0L,0L,0x6A8AA791L,1L,0x0B818053L},{0x5685CE02L,0xF52238DBL,(-10L),0x897AE2AFL,(-5L)},{0x0B818053L,0L,0L,0L,0x0B818053L},{(-5L),0x897AE2AFL,(-10L),0xF52238DBL,0x5685CE02L},{0x0B818053L,1L,0x6A8AA791L,0L,0L},{0x5685CE02L,0x897AE2AFL,0x3F373618L,0x897AE2AFL,0x5685CE02L}},{{0L,0L,0x6A8AA791L,1L,0x0B818053L},{0x5685CE02L,0xF52238DBL,(-10L),0x897AE2AFL,(-5L)},{0x0B818053L,0L,0L,0L,0x0B818053L},{(-5L),0x897AE2AFL,(-10L),0xF52238DBL,0x5685CE02L},{0x0B818053L,1L,0x6A8AA791L,0L,0L},{0x5685CE02L,0x897AE2AFL,0x3F373618L,0x897AE2AFL,0x5685CE02L},{0L,0L,0x6A8AA791L,1L,0x0B818053L},{0x5685CE02L,0xF52238DBL,(-10L),0x897AE2AFL,(-5L)},{0x0B818053L,0L,0L,0L,0x0B818053L}}};
            uint16_t l_407 = 65526UL;
            int8_t l_409 = 0x5DL;
            int64_t l_410 = 0x9F30D6A8AFE621D3LL;
            uint64_t **l_432 = &l_344[1][3];
            uint64_t ***l_431 = &l_432;
            uint16_t l_460[5][6][6] = {{{0xDA34L,65528UL,65528UL,65528UL,0x6BA3L,0xC290L},{3UL,65528UL,0UL,0UL,65528UL,3UL},{65528UL,0x5515L,0x7DB4L,65528UL,65534UL,3UL},{0x7DB4L,0xC290L,0x6920L,0x5515L,0x6BA3L,0UL},{0x7DB4L,65528UL,0x5515L,65528UL,0x7DB4L,65534UL},{1UL,65534UL,0x6BA3L,0x7DB4L,0UL,65528UL}},{{0x46E5L,3UL,0UL,65534UL,65528UL,65528UL},{0x58AFL,0x6BA3L,0x6BA3L,0x58AFL,1UL,65534UL},{65528UL,0x9682L,0x5515L,0xDA34L,65528UL,0UL},{0x5515L,0x46E5L,0x6920L,3UL,65528UL,3UL},{0xC290L,0x9682L,0xC290L,65528UL,1UL,0x46E5L},{65534UL,0x6BA3L,0x7DB4L,0UL,65528UL,1UL}},{{0xDA34L,3UL,65528UL,0UL,0UL,65528UL},{65534UL,65534UL,0x9682L,65528UL,0x7DB4L,0xC290L},{0xC290L,65528UL,65534UL,3UL,0x6BA3L,0x9682L},{0x5515L,0xC290L,65534UL,0xDA34L,65534UL,0xC290L},{65528UL,0xDA34L,0x9682L,0x58AFL,1UL,65528UL},{0x58AFL,1UL,65528UL,65534UL,0x6920L,1UL}},{{0x46E5L,1UL,0x7DB4L,0x7DB4L,1UL,0x46E5L},{1UL,0xDA34L,0xC290L,65528UL,65534UL,3UL},{0x7DB4L,0xC290L,0x6920L,0x5515L,0x6BA3L,0UL},{0x7DB4L,65528UL,0x5515L,65528UL,0x7DB4L,65534UL},{1UL,65534UL,0x6BA3L,0x7DB4L,0UL,65528UL},{0x46E5L,3UL,0UL,65534UL,65528UL,65528UL}},{{0x58AFL,0x6BA3L,0x6BA3L,0x58AFL,1UL,65534UL},{65528UL,0x9682L,0x5515L,0xDA34L,65528UL,0UL},{0x5515L,0x46E5L,0x6920L,3UL,65528UL,3UL},{0xC290L,0x9682L,0xC290L,65528UL,1UL,0x46E5L},{65534UL,0x6BA3L,0x7DB4L,0UL,65528UL,1UL},{0xDA34L,3UL,65528UL,0UL,0UL,65528UL}}};
            union U1 ***l_502 = &g_180;
            int8_t * const *l_703 = &l_702;
            int32_t l_725 = 0xD36101D0L;
            const uint32_t l_798 = 0x305981EBL;
            const uint64_t ****l_873[4][1] = {{(void*)0},{(void*)0},{(void*)0},{(void*)0}};
            int32_t l_908 = 0x92FD8C1FL;
            int i, j, k;
        }
        (*g_189) = l_912;
    }
    for (g_614 = 0; (g_614 <= 1); g_614 += 1)
    { /* block id: 367 */
        union U0 *l_921 = (void*)0;
        union U0 **l_922 = (void*)0;
        union U0 **l_923[2];
        int32_t l_928[6] = {7L,7L,7L,7L,7L,7L};
        uint16_t **l_929 = &g_662;
        union U1 *l_930 = &g_308[0][6];
        uint16_t *l_931 = &g_267;
        int32_t l_1032[8][10][3] = {{{9L,0x5775A549L,6L},{0xEF4F9845L,(-1L),0L},{0L,0x8ED42F6DL,1L},{0L,0x93788D38L,0xED429F5DL},{0x928F795CL,0x8ED42F6DL,0xDE676071L},{0x13AB95ACL,0x1D0778CCL,0x8ED42F6DL},{0L,0x7C0110E6L,1L},{4L,0x5775A549L,0L},{0x8ED42F6DL,0x414C6888L,(-3L)},{1L,0x9F0EB304L,0xDA7D90E5L}},{{1L,0xAA0963AEL,0x89BF1DA2L},{(-9L),0xA4BA24BAL,0x89017A75L},{0xFA551717L,0L,0xEC3A11DEL},{(-1L),0x6F4B1E27L,4L},{0x6F4B1E27L,1L,0x928F795CL},{0xB134C048L,0x0EDCE3ACL,2L},{(-8L),2L,0xA13100FBL},{0L,0x048EB0B8L,0x32A512CCL},{0xA4BA24BAL,0x13B34EBAL,2L},{0x390DCA9FL,0xB46D49B6L,(-8L)}},{{(-1L),1L,0L},{(-1L),0x4A21A382L,0xA4BA24BAL},{0x390DCA9FL,6L,0xEF4F9845L},{0xA4BA24BAL,0L,0x1D0778CCL},{0L,(-8L),0xDE676071L},{(-8L),0x89017A75L,(-2L)},{0xB134C048L,0x319C755AL,0xEA9C9BD8L},{0x6F4B1E27L,8L,(-1L)},{(-1L),0x93788D38L,0x9E0D1AD9L},{0xFA551717L,(-1L),(-8L)}},{{(-9L),0x8ED42F6DL,0xEE42AA2BL},{1L,0xEE42AA2BL,0xB46D49B6L},{1L,0xE833F68FL,0x65E637D2L},{0x8ED42F6DL,0x5DF6B468L,1L},{4L,4L,0x05931951L},{0L,0L,1L},{0x13AB95ACL,0L,0x4A21A382L},{0xEC3A11DEL,0x05931951L,0x319C755AL},{(-2L),0x13AB95ACL,0x4A21A382L},{0L,0x390DCA9FL,1L}},{{1L,1L,0x05931951L},{2L,0x32A512CCL,1L},{0L,0x01DA0648L,0x65E637D2L},{0xAA0963AEL,(-2L),0xB46D49B6L},{0x9E0D1AD9L,0xEF4F9845L,0xEE42AA2BL},{0xE8ABBED7L,0x376B0047L,(-8L)},{0L,0L,0x9E0D1AD9L},{0x65E637D2L,0x981A0806L,(-1L)},{0x048EB0B8L,8L,0xEA9C9BD8L},{1L,0xCDD01AB3L,(-2L)}},{{0x46A6F545L,1L,0xDE676071L},{8L,0xBF6F7BF0L,0x1D0778CCL},{(-3L),0xEA9C9BD8L,0xEF4F9845L},{0xB5DCEED3L,0x928F795CL,0xA4BA24BAL},{3L,1L,0L},{0xCAD3E15DL,1L,(-8L)},{0x981A0806L,0x928F795CL,2L},{6L,0xEA9C9BD8L,0x32A512CCL},{0x89BF1DA2L,0xBF6F7BF0L,0xA13100FBL},{0L,1L,2L}},{{9L,0xCDD01AB3L,0x928F795CL},{0xB46D49B6L,8L,4L},{(-8L),0x981A0806L,0xEC3A11DEL},{1L,0L,0x89017A75L},{8L,0x376B0047L,0x89BF1DA2L},{0L,0xEF4F9845L,0xDA7D90E5L},{8L,(-2L),(-3L)},{0xF78FCBA9L,0x01DA0648L,0L},{1L,0x32A512CCL,0x0EDCE3ACL},{4L,0x05931951L,0x46A6F545L}},{{(-8L),(-1L),2L},{1L,0x2EE2B5F1L,1L},{0x414C6888L,0x5775A549L,0x6E4040D0L},{1L,6L,0x4A317628L},{(-8L),0L,0xB446BC24L},{4L,0xFA551717L,0x7C0110E6L},{0x0EDCE3ACL,(-10L),2L},{0xB46D49B6L,1L,0L},{8L,0xCDD01AB3L,0xE8ABBED7L},{0xD7B8E676L,0x46A6F545L,(-3L)}}};
        int16_t l_1033 = 0xFDC3L;
        uint16_t l_1034 = 0x7B40L;
        uint64_t l_1106 = 0x5585F295404BDC87LL;
        int32_t *l_1117[9][4][1] = {{{&g_614},{&g_797},{&l_159[0][3]},{&l_159[1][0]}},{{&g_362},{&l_159[1][0]},{&l_159[0][3]},{&g_797}},{{&g_614},{&l_1032[6][1][1]},{&g_614},{&g_797}},{{&l_159[0][3]},{&l_159[1][0]},{&g_362},{&l_159[1][0]}},{{&l_159[0][3]},{&g_797},{&g_614},{&l_1032[6][1][1]}},{{&g_614},{&g_797},{&l_159[0][3]},{&l_159[1][0]}},{{&g_362},{&l_159[1][0]},{&l_159[0][3]},{&g_797}},{{&g_614},{&l_1032[6][1][1]},{&g_614},{&g_797}},{{&l_159[0][3]},{&l_159[1][0]},{&g_362},{&l_159[1][0]}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_923[i] = &l_921;
        (*p_61) = (safe_add_func_uint8_t_u_u((safe_sub_func_int32_t_s_s((((safe_rshift_func_int64_t_s_u(((*l_821) < p_60), ((safe_sub_func_uint16_t_u_u((((g_924 = l_921) != l_925) , ((*l_931) = (safe_div_func_int64_t_s_s((((*g_190) = (*p_59)) < (l_928[0] | ((l_74 == ((*l_929) = l_73)) , ((((*l_930) = (*l_291)) , p_60) >= (**g_731))))), p_60)))), (*l_821))) , l_928[0]))) , g_308[0][2].f0) & g_31), (*l_821))), p_60));
        for (l_205 = 0; (l_205 <= 1); l_205 += 1)
        { /* block id: 376 */
            int16_t l_963 = 0xF85DL;
            int32_t *l_967 = &l_79;
            union U1 *l_985 = &g_55;
            uint16_t *l_997 = (void*)0;
            int32_t l_1017 = (-1L);
            int32_t l_1018 = (-7L);
            int32_t l_1019 = 0xEAE93932L;
            int32_t l_1020 = 7L;
            int32_t l_1022 = 0x7A5E9797L;
            int32_t l_1023 = 0L;
            int32_t l_1024 = 0L;
            int32_t l_1025[3][5];
            int64_t l_1056 = 0x7709800FECF54DA7LL;
            int32_t **l_1109 = &g_484;
            int32_t *l_1118 = (void*)0;
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                    l_1025[i][j] = 1L;
            }
        }
    }
    return g_1139[0];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_31, "g_31", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_46[i].f0, "g_46[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_55.f0, "g_55.f0", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_201, "g_201", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_203[i][j][k], "g_203[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_241, "g_241", print_hash_value);
    transparent_crc(g_254.f0, "g_254.f0", print_hash_value);
    transparent_crc(g_267, "g_267", print_hash_value);
    transparent_crc(g_278, "g_278", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_308[i][j].f0, "g_308[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_321, "g_321", print_hash_value);
    transparent_crc(g_362, "g_362", print_hash_value);
    transparent_crc(g_368, "g_368", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_430[i][j][k], "g_430[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_527, "g_527", print_hash_value);
    transparent_crc(g_542, "g_542", print_hash_value);
    transparent_crc(g_544, "g_544", print_hash_value);
    transparent_crc(g_571, "g_571", print_hash_value);
    transparent_crc(g_596, "g_596", print_hash_value);
    transparent_crc(g_613, "g_613", print_hash_value);
    transparent_crc(g_614, "g_614", print_hash_value);
    transparent_crc(g_619, "g_619", print_hash_value);
    transparent_crc(g_633, "g_633", print_hash_value);
    transparent_crc(g_689, "g_689", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_733[i], "g_733[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_746, "g_746", print_hash_value);
    transparent_crc(g_764, "g_764", print_hash_value);
    transparent_crc(g_797, "g_797", print_hash_value);
    transparent_crc(g_828, "g_828", print_hash_value);
    transparent_crc(g_833.f0, "g_833.f0", print_hash_value);
    transparent_crc(g_846, "g_846", print_hash_value);
    transparent_crc(g_847, "g_847", print_hash_value);
    transparent_crc(g_904, "g_904", print_hash_value);
    transparent_crc(g_1256, "g_1256", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1315[i].f0, "g_1315[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1329, "g_1329", print_hash_value);
    transparent_crc(g_1486.f0, "g_1486.f0", print_hash_value);
    transparent_crc(g_1496, "g_1496", print_hash_value);
    transparent_crc(g_1497.f0, "g_1497.f0", print_hash_value);
    transparent_crc(g_1578, "g_1578", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1658[i], "g_1658[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1681[i][j], "g_1681[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1935, "g_1935", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1937[i], "g_1937[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1939[i], "g_1939[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1978.f0, "g_1978.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2158[i].f0, "g_2158[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2311.f0, "g_2311.f0", print_hash_value);
    transparent_crc(g_2511.f0, "g_2511.f0", print_hash_value);
    transparent_crc(g_2586.f0, "g_2586.f0", print_hash_value);
    transparent_crc(g_2882, "g_2882", print_hash_value);
    transparent_crc(g_2962, "g_2962", print_hash_value);
    transparent_crc(g_3015.f0, "g_3015.f0", print_hash_value);
    transparent_crc(g_3033.f0, "g_3033.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_3058[i].f0, "g_3058[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_3069[i].f0, "g_3069[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3164.f0, "g_3164.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_3183[i][j][k].f0, "g_3183[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3212, "g_3212", print_hash_value);
    transparent_crc(g_3224.f0, "g_3224.f0", print_hash_value);
    transparent_crc(g_3225.f0, "g_3225.f0", print_hash_value);
    transparent_crc(g_3286, "g_3286", print_hash_value);
    transparent_crc(g_3294.f0, "g_3294.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_3302[i].f0, "g_3302[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3411, "g_3411", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3418[i].f0, "g_3418[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3523, "g_3523", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3579[i].f0, "g_3579[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3615[i].f0, "g_3615[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3781.f0, "g_3781.f0", print_hash_value);
    transparent_crc(g_3821.f0, "g_3821.f0", print_hash_value);
    transparent_crc(g_3926.f0, "g_3926.f0", print_hash_value);
    transparent_crc(g_4027, "g_4027", print_hash_value);
    transparent_crc(g_4045, "g_4045", print_hash_value);
    transparent_crc(g_4055, "g_4055", print_hash_value);
    transparent_crc(g_4095, "g_4095", print_hash_value);
    transparent_crc(g_4100.f0, "g_4100.f0", print_hash_value);
    transparent_crc(g_4121, "g_4121", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_4164[i][j][k], "g_4164[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4323.f0, "g_4323.f0", print_hash_value);
    transparent_crc(g_4447, "g_4447", print_hash_value);
    transparent_crc(g_4462.f0, "g_4462.f0", print_hash_value);
    transparent_crc(g_4520.f0, "g_4520.f0", print_hash_value);
    transparent_crc(g_4555, "g_4555", print_hash_value);
    transparent_crc(g_4632, "g_4632", print_hash_value);
    transparent_crc(g_4669.f0, "g_4669.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_4728[i].f0, "g_4728[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_4843[i].f0, "g_4843[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4905, "g_4905", print_hash_value);
    transparent_crc(g_4906, "g_4906", print_hash_value);
    transparent_crc(g_5156.f0, "g_5156.f0", print_hash_value);
    transparent_crc(g_5190, "g_5190", print_hash_value);
    transparent_crc(g_5223, "g_5223", print_hash_value);
    transparent_crc(g_5258, "g_5258", print_hash_value);
    transparent_crc(g_5621, "g_5621", print_hash_value);
    transparent_crc(g_5641, "g_5641", print_hash_value);
    transparent_crc(g_5642, "g_5642", print_hash_value);
    transparent_crc(g_5676, "g_5676", print_hash_value);
    transparent_crc(g_5784, "g_5784", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_5796[i].f0, "g_5796[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5844, "g_5844", print_hash_value);
    transparent_crc(g_5846, "g_5846", print_hash_value);
    transparent_crc(g_5851, "g_5851", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_5867[i][j][k].f0, "g_5867[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_5909, "g_5909", print_hash_value);
    transparent_crc(g_5946, "g_5946", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_5956[i].f0, "g_5956[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6053.f0, "g_6053.f0", print_hash_value);
    transparent_crc(g_6064, "g_6064", print_hash_value);
    transparent_crc(g_6098, "g_6098", print_hash_value);
    transparent_crc(g_6102, "g_6102", print_hash_value);
    transparent_crc(g_6122, "g_6122", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_6124[i], "g_6124[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6222, "g_6222", print_hash_value);
    transparent_crc(g_6256, "g_6256", print_hash_value);
    transparent_crc(g_6268, "g_6268", print_hash_value);
    transparent_crc(g_6289.f0, "g_6289.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_6338[i][j][k], "g_6338[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_6361[i][j][k], "g_6361[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_6365.f0, "g_6365.f0", print_hash_value);
    transparent_crc(g_6440.f0, "g_6440.f0", print_hash_value);
    transparent_crc(g_6443, "g_6443", print_hash_value);
    transparent_crc(g_6465.f0, "g_6465.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_6501[i].f0, "g_6501[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6685.f0, "g_6685.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_6756[i], "g_6756[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_6763[i], "g_6763[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6775.f0, "g_6775.f0", print_hash_value);
    transparent_crc(g_6864, "g_6864", print_hash_value);
    transparent_crc(g_6885, "g_6885", print_hash_value);
    transparent_crc(g_6892.f0, "g_6892.f0", print_hash_value);
    transparent_crc(g_6897, "g_6897", print_hash_value);
    transparent_crc(g_6923, "g_6923", print_hash_value);
    transparent_crc(g_6957, "g_6957", print_hash_value);
    transparent_crc(g_6999, "g_6999", print_hash_value);
    transparent_crc(g_7085, "g_7085", print_hash_value);
    transparent_crc(g_7119, "g_7119", print_hash_value);
    transparent_crc(g_7162.f0, "g_7162.f0", print_hash_value);
    transparent_crc(g_7179.f0, "g_7179.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_7181[i][j], "g_7181[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_7338, "g_7338", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_7368[i][j][k], "g_7368[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_7369, "g_7369", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1949
XXX total union variables: 115

XXX non-zero bitfields defined in structs: 3
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 113
breakdown:
   indirect level: 0, occurrence: 53
   indirect level: 1, occurrence: 24
   indirect level: 2, occurrence: 10
   indirect level: 3, occurrence: 13
   indirect level: 4, occurrence: 9
   indirect level: 5, occurrence: 4
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 56
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 72
XXX times a single bitfield on LHS: 3
XXX times a single bitfield on RHS: 28

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 774
   depth: 2, occurrence: 223
   depth: 3, occurrence: 24
   depth: 4, occurrence: 8
   depth: 5, occurrence: 7
   depth: 6, occurrence: 11
   depth: 7, occurrence: 4
   depth: 8, occurrence: 3
   depth: 9, occurrence: 4
   depth: 10, occurrence: 4
   depth: 13, occurrence: 4
   depth: 14, occurrence: 4
   depth: 15, occurrence: 5
   depth: 16, occurrence: 6
   depth: 17, occurrence: 10
   depth: 18, occurrence: 9
   depth: 19, occurrence: 8
   depth: 20, occurrence: 10
   depth: 21, occurrence: 7
   depth: 22, occurrence: 8
   depth: 23, occurrence: 11
   depth: 24, occurrence: 8
   depth: 25, occurrence: 2
   depth: 26, occurrence: 5
   depth: 27, occurrence: 4
   depth: 28, occurrence: 3
   depth: 29, occurrence: 6
   depth: 30, occurrence: 2
   depth: 31, occurrence: 7
   depth: 32, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 2
   depth: 35, occurrence: 6
   depth: 36, occurrence: 2
   depth: 37, occurrence: 5
   depth: 38, occurrence: 2
   depth: 40, occurrence: 2
   depth: 41, occurrence: 1
   depth: 42, occurrence: 1
   depth: 43, occurrence: 1
   depth: 44, occurrence: 1
   depth: 45, occurrence: 2
   depth: 47, occurrence: 2
   depth: 51, occurrence: 2

XXX total number of pointers: 1414

XXX times a variable address is taken: 3480
XXX times a pointer is dereferenced on RHS: 1299
breakdown:
   depth: 1, occurrence: 911
   depth: 2, occurrence: 244
   depth: 3, occurrence: 104
   depth: 4, occurrence: 39
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 1093
breakdown:
   depth: 1, occurrence: 939
   depth: 2, occurrence: 112
   depth: 3, occurrence: 30
   depth: 4, occurrence: 11
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 148
XXX times a pointer is compared with address of another variable: 39
XXX times a pointer is compared with another pointer: 32
XXX times a pointer is qualified to be dereferenced: 25238

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 5297
   level: 2, occurrence: 1294
   level: 3, occurrence: 780
   level: 4, occurrence: 307
   level: 5, occurrence: 182
XXX number of pointers point to pointers: 774
XXX number of pointers point to scalars: 590
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31
XXX average alias set size: 1.51

XXX times a non-volatile is read: 6770
XXX times a non-volatile is write: 3131
XXX times a volatile is read: 486
XXX    times read thru a pointer: 211
XXX times a volatile is write: 118
XXX    times written thru a pointer: 45
XXX times a volatile is available for access: 1.69e+04
XXX percentage of non-volatile access: 94.3

XXX forward jumps: 3
XXX backward jumps: 23

XXX stmts: 813
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 39
   depth: 1, occurrence: 69
   depth: 2, occurrence: 108
   depth: 3, occurrence: 156
   depth: 4, occurrence: 194
   depth: 5, occurrence: 247

XXX percentage a fresh-made variable is used: 16.3
XXX percentage an existing variable is used: 83.7
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

