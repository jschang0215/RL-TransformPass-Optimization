/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: deddca6
 * Options:   (none)
 * Seed:      3968254710
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   volatile unsigned f0 : 9;
   uint32_t  f1;
   signed f2 : 2;
   const signed f3 : 28;
};
#pragma pack(pop)

union U1 {
   volatile uint32_t  f0;
   int8_t  f1;
   uint32_t  f2;
};

union U2 {
   int8_t  f0;
   int64_t  f1;
   const volatile uint64_t  f2;
};

union U3 {
   volatile uint64_t  f0;
   uint32_t  f1;
};

union U4 {
   volatile int64_t  f0;
   int8_t  f1;
   const volatile int8_t  f2;
   const int64_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_41 = 0xF9C32812L;/* VOLATILE GLOBAL g_41 */
static uint64_t g_49 = 0xAEABA4A2C6EB81F9LL;
static uint64_t g_55 = 1UL;
static const uint64_t * const g_54[3] = {&g_55,&g_55,&g_55};
static int64_t g_56[5] = {0xF7CC73EE49CE5708LL,0xF7CC73EE49CE5708LL,0xF7CC73EE49CE5708LL,0xF7CC73EE49CE5708LL,0xF7CC73EE49CE5708LL};
static int8_t g_58 = 0xF7L;
static uint32_t g_82 = 0x60280E44L;
static volatile uint32_t g_101 = 0x4FAE1B8EL;/* VOLATILE GLOBAL g_101 */
static volatile uint32_t *g_100 = &g_101;
static int32_t g_103 = (-3L);
static uint8_t g_106 = 0xE6L;
static int32_t *g_112[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint16_t g_137 = 0x84F5L;
static union U3 g_140 = {0x0381031E146C4C10LL};/* VOLATILE GLOBAL g_140 */
static volatile union U3 g_213 = {0x077B5E051AC87C86LL};/* VOLATILE GLOBAL g_213 */
static volatile union U3 *g_212 = &g_213;
static int64_t g_220 = 9L;
static union U3 g_223 = {0x0E73B8899DCF5AF9LL};/* VOLATILE GLOBAL g_223 */
static int32_t g_281 = 0x6ECEB4F8L;
static const struct S0 g_313 = {15,0x0BF72AC0L,-1,4392};/* VOLATILE GLOBAL g_313 */
static volatile uint32_t **g_362 = &g_100;
static volatile uint32_t *** volatile g_361 = &g_362;/* VOLATILE GLOBAL g_361 */
static const union U2 g_374 = {0L};/* VOLATILE GLOBAL g_374 */
static union U3 g_375 = {18446744073709551611UL};/* VOLATILE GLOBAL g_375 */
static union U4 g_380 = {0x17F5805D818E217BLL};/* VOLATILE GLOBAL g_380 */
static int32_t **g_383 = &g_112[1];
static int32_t ** volatile * const g_382[6][6][4] = {{{(void*)0,&g_383,(void*)0,(void*)0},{&g_383,&g_383,&g_383,&g_383},{&g_383,(void*)0,(void*)0,&g_383},{(void*)0,&g_383,(void*)0,(void*)0},{&g_383,&g_383,&g_383,&g_383},{&g_383,(void*)0,(void*)0,&g_383}},{{(void*)0,&g_383,(void*)0,(void*)0},{&g_383,&g_383,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0},{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0}},{{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0},{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0}},{{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0},{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0}},{{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0},{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0}},{{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0},{&g_383,(void*)0,&g_383,&g_383},{(void*)0,(void*)0,&g_383,(void*)0},{(void*)0,&g_383,&g_383,(void*)0}}};
static union U2 g_429 = {0L};/* VOLATILE GLOBAL g_429 */
static const uint32_t *g_485 = (void*)0;
static const uint32_t **g_484[6][2] = {{&g_485,(void*)0},{(void*)0,&g_485},{(void*)0,(void*)0},{&g_485,(void*)0},{(void*)0,&g_485},{(void*)0,(void*)0}};
static const uint32_t ***g_483 = &g_484[4][0];
static volatile uint16_t *g_495 = (void*)0;
static volatile uint16_t ** const g_494[5] = {&g_495,&g_495,&g_495,&g_495,&g_495};
static union U3 g_510 = {18446744073709551615UL};/* VOLATILE GLOBAL g_510 */
static uint16_t g_559 = 65535UL;
static volatile uint8_t *g_574 = (void*)0;
static volatile uint8_t * const *g_573 = &g_574;
static uint32_t ****g_586[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint32_t *g_591[8][9] = {{(void*)0,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82,(void*)0,&g_82,&g_82,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0,&g_82,&g_82,&g_82,&g_82,&g_82},{&g_82,(void*)0,&g_82,&g_82,(void*)0,&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82,(void*)0,(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,(void*)0,&g_82,&g_82,&g_82,&g_82,(void*)0},{(void*)0,&g_82,(void*)0,&g_82,(void*)0,&g_82,&g_82,&g_82,&g_82}};
static uint32_t * volatile *g_590 = &g_591[7][8];
static uint32_t * volatile **g_589 = &g_590;
static uint32_t * volatile ** volatile * volatile g_588 = &g_589;/* VOLATILE GLOBAL g_588 */
static int64_t *g_609 = &g_220;
static int64_t **g_608 = &g_609;
static volatile struct S0 g_619 = {14,0UL,-1,-12049};/* VOLATILE GLOBAL g_619 */
static union U1 g_620 = {0x68929372L};/* VOLATILE GLOBAL g_620 */
static union U2 g_630[8] = {{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L}};
static union U3 *g_634 = &g_375;
static volatile union U3 g_648 = {0UL};/* VOLATILE GLOBAL g_648 */
static int8_t g_651 = 0x02L;
static volatile union U3 g_701 = {1UL};/* VOLATILE GLOBAL g_701 */
static const struct S0 *g_727[10][9][2] = {{{&g_313,(void*)0},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313}},{{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,(void*)0},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313}},{{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313}},{{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313}},{{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,(void*)0},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{(void*)0,&g_313}},{{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,(void*)0},{&g_313,&g_313},{&g_313,&g_313}},{{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313}},{{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313}},{{&g_313,&g_313},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{&g_313,(void*)0},{&g_313,&g_313},{&g_313,&g_313}},{{(void*)0,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313},{(void*)0,&g_313},{&g_313,&g_313}}};
static const struct S0 ** volatile g_726 = &g_727[5][3][0];/* VOLATILE GLOBAL g_726 */
static volatile union U3 g_740 = {0x4AD4E9A257E26188LL};/* VOLATILE GLOBAL g_740 */
static const int32_t g_774 = 0x27B93A3AL;
static volatile union U1 g_776 = {0xA37D90DDL};/* VOLATILE GLOBAL g_776 */
static struct S0 g_789 = {5,0x69816E7FL,-1,1144};/* VOLATILE GLOBAL g_789 */
static volatile union U3 g_799 = {0x6BE0C8F5497CDF66LL};/* VOLATILE GLOBAL g_799 */
static const int32_t *g_805 = &g_281;
static const int32_t ** volatile g_804[7] = {&g_805,&g_805,&g_805,&g_805,&g_805,&g_805,&g_805};
static const int32_t ** volatile g_806 = (void*)0;/* VOLATILE GLOBAL g_806 */
static const volatile struct S0 g_853 = {18,18446744073709551608UL,1,-3724};/* VOLATILE GLOBAL g_853 */
static volatile union U1 g_866 = {4294967295UL};/* VOLATILE GLOBAL g_866 */
static uint16_t *g_887 = &g_137;
static uint16_t **g_886 = &g_887;
static volatile struct S0 g_917 = {18,5UL,1,13768};/* VOLATILE GLOBAL g_917 */
static uint8_t *g_933 = &g_106;
static uint8_t **g_932 = &g_933;
static uint8_t *** volatile g_931 = &g_932;/* VOLATILE GLOBAL g_931 */
static union U4 g_957 = {0L};/* VOLATILE GLOBAL g_957 */
static int32_t ** volatile * const *g_1019 = &g_382[2][2][2];
static int32_t ** volatile * const ** volatile g_1018 = &g_1019;/* VOLATILE GLOBAL g_1018 */
static union U3 *g_1022 = &g_140;
static union U3 ** volatile g_1021 = &g_1022;/* VOLATILE GLOBAL g_1021 */
static uint16_t ** const * const ** volatile g_1026 = (void*)0;/* VOLATILE GLOBAL g_1026 */
static uint16_t ** const *g_1029[6][9][4] = {{{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,&g_886}},{{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{(void*)0,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,(void*)0},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{(void*)0,(void*)0,&g_886,(void*)0},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886}},{{&g_886,&g_886,(void*)0,&g_886},{(void*)0,&g_886,&g_886,&g_886},{&g_886,(void*)0,&g_886,&g_886},{&g_886,(void*)0,&g_886,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,&g_886}},{{&g_886,&g_886,&g_886,&g_886},{&g_886,(void*)0,(void*)0,&g_886},{&g_886,(void*)0,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{(void*)0,&g_886,&g_886,&g_886},{(void*)0,&g_886,&g_886,(void*)0},{&g_886,(void*)0,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886}},{{(void*)0,&g_886,&g_886,(void*)0},{(void*)0,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886}},{{&g_886,&g_886,(void*)0,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,(void*)0,&g_886},{(void*)0,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{(void*)0,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886,(void*)0},{(void*)0,(void*)0,&g_886,&g_886}}};
static uint16_t ** const * const *g_1028[9][6] = {{(void*)0,&g_1029[3][6][2],&g_1029[2][8][1],&g_1029[3][6][2],(void*)0,(void*)0},{&g_1029[2][8][1],&g_1029[3][6][2],&g_1029[3][6][2],&g_1029[2][8][1],(void*)0,&g_1029[2][8][1]},{&g_1029[2][8][1],(void*)0,&g_1029[2][8][1],&g_1029[3][6][2],&g_1029[3][6][2],&g_1029[2][8][1]},{(void*)0,(void*)0,&g_1029[3][6][2],&g_1029[2][8][1],&g_1029[3][6][2],(void*)0},{&g_1029[3][6][2],(void*)0,&g_1029[2][8][1],&g_1029[2][8][1],(void*)0,&g_1029[3][6][2]},{(void*)0,&g_1029[3][6][2],&g_1029[2][8][1],&g_1029[3][6][2],(void*)0,(void*)0},{&g_1029[2][8][1],&g_1029[3][6][2],&g_1029[3][6][2],&g_1029[2][8][1],(void*)0,&g_1029[2][8][1]},{&g_1029[2][8][1],(void*)0,&g_1029[2][8][1],&g_1029[3][6][2],&g_1029[3][6][2],&g_1029[2][8][1]},{(void*)0,(void*)0,&g_1029[3][6][2],&g_1029[2][8][1],&g_1029[3][6][2],(void*)0}};
static uint16_t ** const * const ** volatile g_1027 = &g_1028[4][2];/* VOLATILE GLOBAL g_1027 */
static int32_t g_1043 = 0x2F2BAE0EL;
static int16_t g_1048 = 0L;
static uint8_t ***g_1053 = &g_932;
static uint8_t **** volatile g_1052 = &g_1053;/* VOLATILE GLOBAL g_1052 */
static union U1 g_1059 = {0x0BB43D8DL};/* VOLATILE GLOBAL g_1059 */
static uint8_t *** volatile *g_1075[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static uint8_t *** volatile ** volatile g_1074 = &g_1075[1];/* VOLATILE GLOBAL g_1074 */
static volatile union U4 g_1086 = {0xE41C7800BE42E347LL};/* VOLATILE GLOBAL g_1086 */
static const uint64_t *g_1101 = &g_49;
static const uint64_t **g_1100 = &g_1101;
static union U2 g_1102 = {0x11L};/* VOLATILE GLOBAL g_1102 */
static volatile union U1 g_1108 = {0xED950FD1L};/* VOLATILE GLOBAL g_1108 */
static const volatile union U1 g_1117 = {0xED660E3FL};/* VOLATILE GLOBAL g_1117 */
static struct S0 *g_1144 = &g_789;
static struct S0 **g_1143[7][2][9] = {{{&g_1144,&g_1144,(void*)0,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144},{(void*)0,&g_1144,(void*)0,&g_1144,(void*)0,&g_1144,&g_1144,&g_1144,&g_1144}},{{&g_1144,&g_1144,(void*)0,&g_1144,(void*)0,&g_1144,&g_1144,&g_1144,&g_1144},{(void*)0,&g_1144,&g_1144,&g_1144,(void*)0,&g_1144,(void*)0,&g_1144,&g_1144}},{{&g_1144,(void*)0,&g_1144,&g_1144,(void*)0,(void*)0,(void*)0,&g_1144,&g_1144},{(void*)0,(void*)0,&g_1144,&g_1144,(void*)0,&g_1144,(void*)0,&g_1144,&g_1144}},{{&g_1144,(void*)0,&g_1144,&g_1144,&g_1144,&g_1144,(void*)0,&g_1144,(void*)0},{(void*)0,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,(void*)0,&g_1144,(void*)0}},{{&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,(void*)0},{(void*)0,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144}},{{&g_1144,&g_1144,&g_1144,(void*)0,(void*)0,&g_1144,&g_1144,(void*)0,(void*)0},{&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,(void*)0}},{{&g_1144,(void*)0,&g_1144,&g_1144,(void*)0,&g_1144,(void*)0,(void*)0,&g_1144},{&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,(void*)0}}};
static struct S0 ***g_1142 = &g_1143[6][1][0];
static struct S0 **** volatile g_1141 = &g_1142;/* VOLATILE GLOBAL g_1141 */
static int64_t ***g_1149 = &g_608;
static int64_t **** volatile g_1148 = &g_1149;/* VOLATILE GLOBAL g_1148 */
static union U2 g_1188 = {0x9DL};/* VOLATILE GLOBAL g_1188 */
static volatile union U3 g_1195 = {0x64F56F3060B557EALL};/* VOLATILE GLOBAL g_1195 */
static volatile union U1 g_1217[9][1] = {{{0x5D7734D5L}},{{0xA6E238C3L}},{{0x5D7734D5L}},{{0xA6E238C3L}},{{0x5D7734D5L}},{{0xA6E238C3L}},{{0x5D7734D5L}},{{0xA6E238C3L}},{{0x5D7734D5L}}};
static int64_t ***g_1228[6][10][4] = {{{&g_608,(void*)0,&g_608,&g_608},{&g_608,&g_608,(void*)0,&g_608},{(void*)0,&g_608,&g_608,(void*)0},{&g_608,&g_608,(void*)0,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,(void*)0},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608}},{{&g_608,(void*)0,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,(void*)0,&g_608},{&g_608,&g_608,&g_608,&g_608},{(void*)0,&g_608,(void*)0,&g_608},{&g_608,(void*)0,&g_608,&g_608}},{{&g_608,&g_608,(void*)0,&g_608},{(void*)0,&g_608,&g_608,(void*)0},{&g_608,&g_608,(void*)0,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,(void*)0},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,(void*)0,&g_608,&g_608}},{{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,(void*)0},{&g_608,&g_608,&g_608,&g_608},{(void*)0,&g_608,&g_608,&g_608},{(void*)0,&g_608,&g_608,&g_608}},{{&g_608,&g_608,&g_608,&g_608},{&g_608,(void*)0,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{(void*)0,&g_608,&g_608,&g_608},{&g_608,(void*)0,&g_608,&g_608},{&g_608,&g_608,(void*)0,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,(void*)0,(void*)0}},{{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,(void*)0},{(void*)0,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,(void*)0},{&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,(void*)0},{&g_608,&g_608,&g_608,&g_608},{(void*)0,&g_608,&g_608,&g_608},{(void*)0,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608}}};
static int64_t ***g_1229 = &g_608;
static int32_t ***g_1244[2] = {&g_383,&g_383};
static int32_t ****g_1243 = &g_1244[0];
static int32_t *****g_1242 = &g_1243;
static volatile union U1 g_1248 = {0x9B79F77BL};/* VOLATILE GLOBAL g_1248 */
static int16_t g_1253[3][7][7] = {{{0xC6A9L,1L,(-1L),0x5F31L,1L,0x5F31L,(-1L)},{2L,2L,0x706DL,0xC564L,0xBFC4L,0x706DL,0xBFC4L},{0xB84DL,(-1L),(-1L),0xB84DL,0x5F31L,0xC6A9L,0xB84DL},{(-8L),0xBFC4L,0xE1BBL,0xE1BBL,0xBFC4L,(-8L),3L},{(-2L),0xB84DL,0x1E72L,1L,1L,0x1E72L,0xB84DL},{0xBFC4L,3L,(-8L),0xBFC4L,0xE1BBL,0xE1BBL,0xBFC4L},{0xC6A9L,0xB84DL,0xC6A9L,0x5F31L,0xB84DL,(-1L),(-1L)}},{{0xC564L,0xBFC4L,0x706DL,0xBFC4L,0xC564L,0x706DL,2L},{1L,(-1L),0x5F31L,1L,0x5F31L,(-1L),1L},{(-8L),2L,3L,0xE1BBL,2L,0xE1BBL,3L},{1L,1L,0x1E72L,0xB84DL,(-2L),0x1E72L,(-2L)},{0xC564L,3L,3L,0xC564L,0xE1BBL,(-8L),0xC564L},{0xC6A9L,(-2L),0x5F31L,0x5F31L,(-2L),9L,0x1E72L},{0xE1BBL,3L,2L,(-8L),(-8L),2L,3L}},{{0x5F31L,0x1E72L,9L,0x5F31L,0xDC0CL,0xDC0CL,0x5F31L},{(-7L),3L,(-7L),0x550EL,3L,0x706DL,0x706DL},{(-1L),0x5F31L,1L,0x5F31L,(-1L),1L,0xC6A9L},{(-8L),0x706DL,0x550EL,(-8L),0x550EL,0x706DL,(-8L)},{9L,0xC6A9L,0x1E72L,0xDC0CL,0xC6A9L,0xDC0CL,0x1E72L},{(-8L),(-8L),2L,3L,0xE1BBL,2L,0xE1BBL},{(-1L),0x1E72L,0x1E72L,(-1L),0xDC0CL,9L,(-1L)}}};
static volatile union U2 g_1261[7][2] = {{{7L},{7L}},{{7L},{7L}},{{7L},{7L}},{{7L},{7L}},{{7L},{7L}},{{7L},{7L}},{{7L},{7L}}};
static int32_t ***g_1305[8] = {&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383};
static volatile uint64_t g_1326 = 0x452015939219448BLL;/* VOLATILE GLOBAL g_1326 */
static int16_t g_1327 = 0x1E1EL;
static volatile union U1 g_1341 = {4294967295UL};/* VOLATILE GLOBAL g_1341 */
static volatile union U1 g_1342 = {0x62D27455L};/* VOLATILE GLOBAL g_1342 */
static union U1 g_1343[3][2] = {{{0xE6AB8D0EL},{0xE6AB8D0EL}},{{0xE6AB8D0EL},{0xE6AB8D0EL}},{{0xE6AB8D0EL},{0xE6AB8D0EL}}};
static union U1 *g_1352 = (void*)0;
static union U1 ** volatile g_1351 = &g_1352;/* VOLATILE GLOBAL g_1351 */
static volatile union U2 * volatile g_1390 = &g_1261[1][1];/* VOLATILE GLOBAL g_1390 */
static volatile union U2 * volatile *g_1389 = &g_1390;
static const volatile union U2 g_1400 = {-1L};/* VOLATILE GLOBAL g_1400 */
static volatile int8_t g_1401 = 0L;/* VOLATILE GLOBAL g_1401 */
static union U1 g_1412 = {0x2084D917L};/* VOLATILE GLOBAL g_1412 */
static union U2 g_1425 = {-1L};/* VOLATILE GLOBAL g_1425 */
static const uint16_t g_1429 = 0UL;
static union U4 g_1456 = {-1L};/* VOLATILE GLOBAL g_1456 */
static union U4 g_1459 = {5L};/* VOLATILE GLOBAL g_1459 */
static union U4 *g_1458 = &g_1459;
static union U4 g_1461 = {-4L};/* VOLATILE GLOBAL g_1461 */
static volatile union U3 g_1511 = {8UL};/* VOLATILE GLOBAL g_1511 */
static uint64_t g_1538 = 18446744073709551615UL;
static volatile union U4 g_1560 = {1L};/* VOLATILE GLOBAL g_1560 */
static volatile union U3 g_1566 = {18446744073709551606UL};/* VOLATILE GLOBAL g_1566 */
static volatile int16_t g_1580 = 0xA6C0L;/* VOLATILE GLOBAL g_1580 */
static union U4 g_1635 = {0L};/* VOLATILE GLOBAL g_1635 */
static struct S0 g_1652 = {5,18446744073709551615UL,-0,-1435};/* VOLATILE GLOBAL g_1652 */
static uint64_t g_1687 = 0xD14660A246A9CEE6LL;
static struct S0 g_1690 = {3,0xB6714378L,0,-4997};/* VOLATILE GLOBAL g_1690 */
static union U3 ** volatile g_1713 = &g_1022;/* VOLATILE GLOBAL g_1713 */
static struct S0 g_1798[4] = {{17,0UL,-1,-16259},{17,0UL,-1,-16259},{17,0UL,-1,-16259},{17,0UL,-1,-16259}};
static struct S0 g_1811 = {2,0x167E7D31L,1,424};/* VOLATILE GLOBAL g_1811 */
static union U4 g_1816 = {0L};/* VOLATILE GLOBAL g_1816 */
static union U4 g_1830 = {-1L};/* VOLATILE GLOBAL g_1830 */
static volatile union U1 g_1864 = {0x9E349677L};/* VOLATILE GLOBAL g_1864 */
static union U2 * const *g_1872 = (void*)0;
static struct S0 g_1879 = {7,0x605E2DFCL,1,4082};/* VOLATILE GLOBAL g_1879 */
static struct S0 *** const g_1904 = (void*)0;
static struct S0 *** const *g_1903 = &g_1904;
static uint8_t *****g_1952 = (void*)0;
static union U2 g_1969 = {4L};/* VOLATILE GLOBAL g_1969 */
static volatile uint32_t g_1994 = 4UL;/* VOLATILE GLOBAL g_1994 */
static const int32_t ** volatile g_2000[7][5][6] = {{{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805},{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805},{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805},{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805},{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805}},{{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805},{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805},{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805},{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805},{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805}},{{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805},{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805},{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805},{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805},{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805}},{{(void*)0,&g_805,&g_805,&g_805,&g_805,&g_805},{(void*)0,&g_805,&g_805,(void*)0,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805}},{{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805}},{{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805}},{{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805},{&g_805,&g_805,&g_805,&g_805,&g_805,&g_805}}};
static const int32_t *g_2001 = (void*)0;
static volatile union U4 g_2032 = {0x83FDEF0639313B65LL};/* VOLATILE GLOBAL g_2032 */
static int8_t g_2211 = 0xB3L;
static uint32_t *g_2220[8] = {&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82};
static int32_t g_2244 = 0x833775BAL;
static volatile union U1 g_2301 = {0x750682C5L};/* VOLATILE GLOBAL g_2301 */
static union U3 g_2322 = {0x71FA290E433B6E96LL};/* VOLATILE GLOBAL g_2322 */
static struct S0 g_2327 = {12,1UL,-0,1831};/* VOLATILE GLOBAL g_2327 */
static int32_t * volatile g_2363 = &g_281;/* VOLATILE GLOBAL g_2363 */
static uint64_t * const g_2366 = (void*)0;
static uint64_t * const *g_2365 = &g_2366;
static uint64_t * const **g_2364 = &g_2365;
static volatile union U2 g_2379 = {-1L};/* VOLATILE GLOBAL g_2379 */
static volatile union U1 g_2401 = {0x3AE606FBL};/* VOLATILE GLOBAL g_2401 */
static union U2 g_2418 = {0xBAL};/* VOLATILE GLOBAL g_2418 */
static const union U2 *g_2457 = &g_630[2];
static const union U2 ** volatile g_2456 = &g_2457;/* VOLATILE GLOBAL g_2456 */
static uint16_t g_2472 = 0UL;
static union U4 g_2479[8][3] = {{{-1L},{0x46B01905BA0CF04CLL},{0x46B01905BA0CF04CLL}},{{0xCE96C51E9E2BA9A0LL},{0x46B01905BA0CF04CLL},{5L}},{{0L},{-1L},{0x85FFCD0AF169059ELL}},{{0xCE96C51E9E2BA9A0LL},{0xCE96C51E9E2BA9A0LL},{0x85FFCD0AF169059ELL}},{{-1L},{0L},{5L}},{{0x46B01905BA0CF04CLL},{0xCE96C51E9E2BA9A0LL},{0x46B01905BA0CF04CLL}},{{0x46B01905BA0CF04CLL},{-1L},{0xCE96C51E9E2BA9A0LL}},{{-1L},{0x46B01905BA0CF04CLL},{0x46B01905BA0CF04CLL}}};
static union U4 g_2481[2] = {{8L},{8L}};
static uint16_t ***g_2542 = (void*)0;
static uint16_t ****g_2541 = &g_2542;
static uint16_t *****g_2540 = &g_2541;
static int32_t *g_2550 = &g_103;
static struct S0 ****g_2585 = &g_1142;
static struct S0 *****g_2584[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const struct S0 **g_2589 = &g_727[9][4][1];
static const struct S0 ***g_2588 = &g_2589;
static const struct S0 ****g_2587[1][3] = {{&g_2588,&g_2588,&g_2588}};
static const struct S0 *****g_2586[7][10][3] = {{{(void*)0,&g_2587[0][0],(void*)0},{(void*)0,&g_2587[0][1],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][0],(void*)0},{(void*)0,&g_2587[0][1],&g_2587[0][0]},{&g_2587[0][2],&g_2587[0][0],&g_2587[0][2]},{(void*)0,(void*)0,&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][0]},{(void*)0,&g_2587[0][2],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][0]}},{{(void*)0,&g_2587[0][0],&g_2587[0][2]},{&g_2587[0][0],(void*)0,&g_2587[0][1]},{(void*)0,(void*)0,&g_2587[0][0]},{&g_2587[0][2],(void*)0,&g_2587[0][0]},{&g_2587[0][1],&g_2587[0][2],(void*)0},{&g_2587[0][0],&g_2587[0][1],&g_2587[0][2]},{&g_2587[0][2],&g_2587[0][1],(void*)0},{&g_2587[0][0],&g_2587[0][2],&g_2587[0][2]},{&g_2587[0][0],(void*)0,&g_2587[0][2]},{(void*)0,(void*)0,&g_2587[0][0]}},{{&g_2587[0][2],&g_2587[0][0],(void*)0},{(void*)0,&g_2587[0][0],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][1],&g_2587[0][0]},{&g_2587[0][0],(void*)0,&g_2587[0][0]},{(void*)0,(void*)0,(void*)0},{&g_2587[0][1],&g_2587[0][0],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][2]},{(void*)0,&g_2587[0][0],&g_2587[0][2]},{&g_2587[0][0],&g_2587[0][2],(void*)0},{&g_2587[0][0],&g_2587[0][2],&g_2587[0][2]}},{{&g_2587[0][0],&g_2587[0][2],(void*)0},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][0]},{(void*)0,&g_2587[0][0],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][1],(void*)0},{&g_2587[0][1],(void*)0,(void*)0},{(void*)0,&g_2587[0][0],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][2],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][0]},{(void*)0,(void*)0,&g_2587[0][2]},{&g_2587[0][2],&g_2587[0][1],&g_2587[0][2]}},{{(void*)0,&g_2587[0][0],&g_2587[0][1]},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][1]},{&g_2587[0][0],&g_2587[0][2],(void*)0},{&g_2587[0][2],&g_2587[0][2],(void*)0},{&g_2587[0][0],&g_2587[0][2],&g_2587[0][1]},{&g_2587[0][1],&g_2587[0][0],&g_2587[0][1]},{&g_2587[0][2],&g_2587[0][0],&g_2587[0][2]},{(void*)0,&g_2587[0][0],&g_2587[0][2]},{(void*)0,(void*)0,&g_2587[0][0]},{(void*)0,(void*)0,&g_2587[0][0]}},{{&g_2587[0][0],&g_2587[0][1],&g_2587[0][0]},{(void*)0,&g_2587[0][0],(void*)0},{(void*)0,&g_2587[0][0],(void*)0},{(void*)0,(void*)0,&g_2587[0][0]},{&g_2587[0][2],(void*)0,&g_2587[0][0]},{&g_2587[0][1],&g_2587[0][2],(void*)0},{&g_2587[0][0],&g_2587[0][1],&g_2587[0][2]},{&g_2587[0][2],&g_2587[0][1],(void*)0},{&g_2587[0][0],&g_2587[0][2],&g_2587[0][2]},{&g_2587[0][0],(void*)0,&g_2587[0][2]}},{{(void*)0,(void*)0,&g_2587[0][0]},{&g_2587[0][2],&g_2587[0][0],(void*)0},{(void*)0,&g_2587[0][0],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][1],&g_2587[0][0]},{&g_2587[0][0],(void*)0,&g_2587[0][0]},{(void*)0,(void*)0,(void*)0},{&g_2587[0][1],&g_2587[0][0],&g_2587[0][0]},{&g_2587[0][0],&g_2587[0][0],&g_2587[0][2]},{(void*)0,&g_2587[0][0],&g_2587[0][2]},{&g_2587[0][0],&g_2587[0][2],(void*)0}}};
static struct S0 g_2599 = {20,0xD731CE40L,-1,8317};/* VOLATILE GLOBAL g_2599 */
static union U4 g_2605 = {0xEE2744B206060E6BLL};/* VOLATILE GLOBAL g_2605 */
static volatile union U4 g_2629 = {0L};/* VOLATILE GLOBAL g_2629 */
static union U2 g_2653 = {0L};/* VOLATILE GLOBAL g_2653 */
static union U2 *g_2662 = &g_1188;
static union U2 **g_2661 = &g_2662;
static union U2 ***g_2660[6][1] = {{&g_2661},{&g_2661},{&g_2661},{&g_2661},{&g_2661},{&g_2661}};
static union U2 ****g_2659[2] = {&g_2660[2][0],&g_2660[2][0]};
static union U4 g_2679 = {-5L};/* VOLATILE GLOBAL g_2679 */
static uint32_t *g_2704 = (void*)0;
static const volatile union U1 g_2717[5][10][2] = {{{{0x158FF38EL},{4294967295UL}},{{4294967291UL},{0x158FF38EL}},{{0xD86D5735L},{0x8848D164L}},{{0xD86D5735L},{0x158FF38EL}},{{4294967291UL},{0UL}},{{0x8F03CF64L},{4294967291UL}},{{0xD86D5735L},{4294967295UL}},{{4294967295UL},{0x8848D164L}},{{0x8848D164L},{0x5234EE09L}},{{4294967295UL},{0x5234EE09L}}},{{{0x8848D164L},{0x8848D164L}},{{4294967295UL},{4294967295UL}},{{0xD86D5735L},{4294967291UL}},{{0x8F03CF64L},{0UL}},{{0x5234EE09L},{0x8F03CF64L}},{{1UL},{0x158FF38EL}},{{1UL},{0x8F03CF64L}},{{0x5234EE09L},{0UL}},{{0x8F03CF64L},{4294967291UL}},{{0xD86D5735L},{4294967295UL}}},{{{4294967295UL},{0x8848D164L}},{{0x8848D164L},{0x5234EE09L}},{{4294967295UL},{0x5234EE09L}},{{0x8848D164L},{0x8848D164L}},{{4294967295UL},{4294967295UL}},{{0xD86D5735L},{4294967291UL}},{{0x8F03CF64L},{0UL}},{{0x5234EE09L},{0x8F03CF64L}},{{1UL},{0x158FF38EL}},{{1UL},{0x8F03CF64L}}},{{{0x5234EE09L},{0UL}},{{0x8F03CF64L},{4294967291UL}},{{0xD86D5735L},{4294967295UL}},{{4294967295UL},{0x8848D164L}},{{0x8848D164L},{0x5234EE09L}},{{4294967295UL},{0x5234EE09L}},{{0x8848D164L},{0x8848D164L}},{{4294967295UL},{4294967295UL}},{{0xD86D5735L},{4294967291UL}},{{0x8F03CF64L},{0UL}}},{{{0x5234EE09L},{0x8F03CF64L}},{{1UL},{0x158FF38EL}},{{1UL},{0x8F03CF64L}},{{0x5234EE09L},{0UL}},{{0x8F03CF64L},{4294967291UL}},{{0xD86D5735L},{4294967295UL}},{{4294967295UL},{0x8848D164L}},{{0x8848D164L},{0x5234EE09L}},{{4294967295UL},{0x5234EE09L}},{{0x8848D164L},{0x8848D164L}}}};
static uint16_t g_2769 = 0xCBEEL;
static volatile union U1 g_2775 = {0x5C5AF663L};/* VOLATILE GLOBAL g_2775 */
static const volatile union U2 g_2797 = {-3L};/* VOLATILE GLOBAL g_2797 */
static struct S0 g_2885 = {5,1UL,-0,-3482};/* VOLATILE GLOBAL g_2885 */
static union U2 g_2911 = {0x96L};/* VOLATILE GLOBAL g_2911 */
static union U4 g_2912 = {0xAC16811977794DE6LL};/* VOLATILE GLOBAL g_2912 */
static union U4 g_2925 = {0xEB8A1E6D019FE60FLL};/* VOLATILE GLOBAL g_2925 */
static int8_t g_3033 = 5L;
static union U3 **g_3118 = &g_1022;
static volatile struct S0 g_3162 = {11,0x06F79EDBL,0,10222};/* VOLATILE GLOBAL g_3162 */
static const volatile union U2 g_3199 = {0x3CL};/* VOLATILE GLOBAL g_3199 */
static int16_t g_3207 = (-2L);
static const union U4 g_3209 = {-2L};/* VOLATILE GLOBAL g_3209 */
static union U3 g_3217 = {0UL};/* VOLATILE GLOBAL g_3217 */
static union U3 g_3220 = {9UL};/* VOLATILE GLOBAL g_3220 */
static const volatile union U2 g_3260 = {0x9EL};/* VOLATILE GLOBAL g_3260 */
static union U2 g_3290 = {0L};/* VOLATILE GLOBAL g_3290 */
static union U4 ** volatile g_3309 = (void*)0;/* VOLATILE GLOBAL g_3309 */
static union U4 g_3312[3][4][2] = {{{{0x90A8CDA56F671C2DLL},{0x0F49F9322D9E0C97LL}},{{0x90A8CDA56F671C2DLL},{0L}},{{8L},{0L}},{{0x90A8CDA56F671C2DLL},{0x0F49F9322D9E0C97LL}}},{{{0x90A8CDA56F671C2DLL},{0L}},{{8L},{0L}},{{0x90A8CDA56F671C2DLL},{0x0F49F9322D9E0C97LL}},{{0x90A8CDA56F671C2DLL},{0L}}},{{{8L},{0L}},{{0x90A8CDA56F671C2DLL},{0x0F49F9322D9E0C97LL}},{{0x90A8CDA56F671C2DLL},{0L}},{{8L},{0L}}}};
static volatile union U3 g_3318[1] = {{0x5E0BC5371BB85DB1LL}};
static volatile int16_t g_3326[3] = {0L,0L,0L};
static union U3 g_3406[8] = {{18446744073709551606UL},{1UL},{18446744073709551606UL},{18446744073709551606UL},{1UL},{18446744073709551606UL},{18446744073709551606UL},{1UL}};
static int32_t g_3408 = 0L;
static volatile union U4 g_3494 = {0x2BF05411E8E27EF3LL};/* VOLATILE GLOBAL g_3494 */
static volatile union U4 g_3546 = {-8L};/* VOLATILE GLOBAL g_3546 */
static union U4 g_3564 = {0x6FE9296E240E10CELL};/* VOLATILE GLOBAL g_3564 */
static union U1 g_3578 = {0xC2808D93L};/* VOLATILE GLOBAL g_3578 */
static const struct S0 g_3584 = {6,18446744073709551606UL,1,-7987};/* VOLATILE GLOBAL g_3584 */
static volatile uint8_t g_3667 = 255UL;/* VOLATILE GLOBAL g_3667 */
static int32_t g_3674 = (-4L);
static struct S0 g_3692 = {18,0UL,-0,-15338};/* VOLATILE GLOBAL g_3692 */
static union U1 g_3697[10][7] = {{{4294967295UL},{4294967294UL},{4294967294UL},{4294967295UL},{0xFBBFE867L},{1UL},{4294967295UL}},{{4294967292UL},{4294967294UL},{0x0613B1D2L},{0x0613B1D2L},{4294967294UL},{4294967292UL},{1UL}},{{4294967289UL},{4294967295UL},{0x1392DDD3L},{1UL},{1UL},{0x1392DDD3L},{4294967295UL}},{{4294967294UL},{1UL},{4294967292UL},{4294967294UL},{0x0613B1D2L},{0x0613B1D2L},{4294967294UL}},{{1UL},{4294967295UL},{1UL},{0xFBBFE867L},{4294967295UL},{4294967294UL},{4294967294UL}},{{4294967295UL},{4294967294UL},{4294967293UL},{4294967294UL},{4294967295UL},{4294967293UL},{0UL}},{{1UL},{4294967294UL},{0xFBBFE867L},{1UL},{0xFBBFE867L},{4294967294UL},{1UL}},{{4294967292UL},{0UL},{1UL},{0x0613B1D2L},{0UL},{0x0613B1D2L},{1UL}},{{1UL},{1UL},{0x1392DDD3L},{4294967295UL},{4294967289UL},{0x1392DDD3L},{4294967289UL}},{{4294967295UL},{4294967293UL},{4294967293UL},{1UL},{0UL},{1UL},{1UL}}};
static union U1 g_3747 = {5UL};/* VOLATILE GLOBAL g_3747 */
static union U1 g_3748 = {1UL};/* VOLATILE GLOBAL g_3748 */
static const uint8_t g_3787 = 0x27L;
static const union U3 g_3807 = {0xB4EC78117BC44E4FLL};/* VOLATILE GLOBAL g_3807 */
static volatile int64_t **g_3821 = (void*)0;
static volatile int64_t ***g_3820 = &g_3821;
static volatile int64_t *** volatile *g_3819 = &g_3820;
static union U3 g_3837 = {1UL};/* VOLATILE GLOBAL g_3837 */
static union U1 g_3933 = {1UL};/* VOLATILE GLOBAL g_3933 */
static union U4 g_3940 = {0L};/* VOLATILE GLOBAL g_3940 */
static struct S0 g_3970[1] = {{8,6UL,0,16096}};
static volatile union U3 g_3974 = {0xF79495FC1B7D13AFLL};/* VOLATILE GLOBAL g_3974 */
static int64_t **g_3986 = &g_609;
static union U1 g_4008 = {4294967289UL};/* VOLATILE GLOBAL g_4008 */
static const int32_t ** volatile g_4020 = &g_805;/* VOLATILE GLOBAL g_4020 */
static volatile union U3 g_4133 = {1UL};/* VOLATILE GLOBAL g_4133 */
static int32_t g_4142 = 9L;
static volatile union U2 g_4145 = {0xC9L};/* VOLATILE GLOBAL g_4145 */
static volatile union U2 g_4184 = {0L};/* VOLATILE GLOBAL g_4184 */
static uint8_t *** volatile ** volatile g_4237 = &g_1075[1];/* VOLATILE GLOBAL g_4237 */
static const struct S0 g_4244 = {13,0x1D3A4CB9L,0,-8960};/* VOLATILE GLOBAL g_4244 */
static int8_t *g_4248 = &g_1969.f0;
static int8_t **g_4247 = &g_4248;
static const union U1 g_4265 = {0x92737941L};/* VOLATILE GLOBAL g_4265 */
static union U2 * volatile g_4269 = &g_3290;/* VOLATILE GLOBAL g_4269 */
static union U2 * volatile * volatile g_4270 = (void*)0;/* VOLATILE GLOBAL g_4270 */
static union U2 * volatile * volatile g_4271 = (void*)0;/* VOLATILE GLOBAL g_4271 */
static union U2 g_4274 = {-1L};/* VOLATILE GLOBAL g_4274 */
static volatile union U4 g_4282 = {1L};/* VOLATILE GLOBAL g_4282 */
static const volatile struct S0 g_4290 = {19,0xB63C9BB6L,-1,-10625};/* VOLATILE GLOBAL g_4290 */
static union U4 g_4297 = {1L};/* VOLATILE GLOBAL g_4297 */
static uint16_t ****g_4313 = &g_2542;
static union U1 g_4364 = {5UL};/* VOLATILE GLOBAL g_4364 */
static volatile union U1 g_4394 = {0xD26FB0D8L};/* VOLATILE GLOBAL g_4394 */
static const union U1 *g_4417 = (void*)0;
static const union U1 **g_4416 = &g_4417;
static const union U1 ***g_4415 = &g_4416;
static const union U1 ****g_4414 = &g_4415;
static const union U1 *****g_4413 = &g_4414;
static union U3 g_4428 = {0xDF927329EC49B44ALL};/* VOLATILE GLOBAL g_4428 */
static union U2 g_4437 = {0x4AL};/* VOLATILE GLOBAL g_4437 */
static volatile union U4 g_4443[2] = {{1L},{1L}};
static volatile union U1 g_4488 = {0xC919B584L};/* VOLATILE GLOBAL g_4488 */
static volatile union U4 g_4513 = {0xDBAE2B226853BB1ELL};/* VOLATILE GLOBAL g_4513 */
static volatile uint64_t g_4528 = 0x9AFD5020EB62A683LL;/* VOLATILE GLOBAL g_4528 */
static union U4 * volatile * volatile g_4564 = (void*)0;/* VOLATILE GLOBAL g_4564 */
static union U4 * volatile * volatile *g_4563 = &g_4564;
static union U3 g_4580[1] = {{0UL}};
static union U3 g_4589[1] = {{1UL}};
static uint16_t g_4598 = 0x05FCL;
static int32_t * volatile g_4625[8][4] = {{&g_2244,&g_103,&g_103,&g_2244},{&g_281,&g_103,&g_4142,&g_2244},{&g_2244,&g_103,&g_103,&g_2244},{&g_281,&g_103,&g_4142,&g_2244},{&g_2244,&g_103,&g_103,&g_2244},{&g_281,&g_103,&g_4142,&g_2244},{&g_2244,&g_103,&g_103,&g_2244},{&g_281,&g_103,&g_4142,&g_2244}};
static const int32_t g_4694 = (-8L);
static union U1 g_4723 = {0x38DD0182L};/* VOLATILE GLOBAL g_4723 */
static struct S0 g_4725 = {7,1UL,0,3964};/* VOLATILE GLOBAL g_4725 */
static struct S0 g_4727[7][8] = {{{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047},{2,0xDCDD349CL,-1,-15200},{13,0xF2FBE347L,0,14047},{7,0x0BA15CCFL,-1,11429},{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047},{2,0xDCDD349CL,-1,-15200}},{{7,0x0BA15CCFL,-1,11429},{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047},{2,0xDCDD349CL,-1,-15200},{13,0xF2FBE347L,0,14047},{7,0x0BA15CCFL,-1,11429},{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047}},{{10,18446744073709551613UL,1,2389},{13,0xF2FBE347L,0,14047},{13,0xF2FBE347L,0,14047},{10,18446744073709551613UL,1,2389},{4,0UL,0,-3984},{10,18446744073709551613UL,1,2389},{13,0xF2FBE347L,0,14047},{13,0xF2FBE347L,0,14047}},{{13,0xF2FBE347L,0,14047},{4,0UL,0,-3984},{2,0xDCDD349CL,-1,-15200},{2,0xDCDD349CL,-1,-15200},{4,0UL,0,-3984},{13,0xF2FBE347L,0,14047},{4,0UL,0,-3984},{2,0xDCDD349CL,-1,-15200}},{{10,18446744073709551613UL,1,2389},{4,0UL,0,-3984},{10,18446744073709551613UL,1,2389},{13,0xF2FBE347L,0,14047},{13,0xF2FBE347L,0,14047},{10,18446744073709551613UL,1,2389},{4,0UL,0,-3984},{10,18446744073709551613UL,1,2389}},{{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047},{2,0xDCDD349CL,-1,-15200},{13,0xF2FBE347L,0,14047},{7,0x0BA15CCFL,-1,11429},{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047},{2,0xDCDD349CL,-1,-15200}},{{7,0x0BA15CCFL,-1,11429},{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047},{2,0xDCDD349CL,-1,-15200},{13,0xF2FBE347L,0,14047},{7,0x0BA15CCFL,-1,11429},{7,0x0BA15CCFL,-1,11429},{13,0xF2FBE347L,0,14047}}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(int32_t  p_3, int8_t  p_4, int32_t  p_5, int64_t  p_6);
static int32_t  func_8(int16_t  p_9, int8_t  p_10, uint16_t  p_11);
static int32_t  func_14(int32_t  p_15, int32_t  p_16, uint64_t  p_17, uint32_t  p_18, int8_t  p_19);
static int8_t  func_20(int64_t  p_21);
static struct S0  func_26(int16_t  p_27, int64_t  p_28, int32_t  p_29, uint64_t  p_30, uint32_t  p_31);
static uint16_t  func_35(int64_t  p_36);
static uint8_t  func_42(uint16_t  p_43, uint8_t  p_44, uint32_t  p_45);
static uint32_t  func_52(const uint64_t * const  p_53);
static int16_t  func_68(const uint16_t  p_69);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_41 g_49 g_54 g_55 g_56 g_82 g_58 g_100 g_106 g_103 g_137 g_140.f1 g_212 g_220 g_281 g_313 g_223.f0 g_223.f1 g_361 g_374 g_375 g_380 g_382 g_429 g_213.f0 g_494 g_429.f0 g_510 g_213 g_483 g_559 g_573 g_586 g_588 g_619 g_620 g_648 g_651 g_362 g_101 g_608 g_609 g_383 g_701 g_726 g_375.f1 g_740 g_776 g_774 g_799 g_429.f1 g_789.f0 g_805 g_853 g_866 g_1248 g_1261 g_1101 g_932 g_933 g_1052 g_1053 g_1217.f0 g_1305 g_1326 g_886 g_887 g_1327 g_1253 g_1341 g_1342 g_1343 g_1149 g_1229 g_799.f0 g_1351 g_957.f0 g_1389 g_1400 g_1401 g_1102.f0 g_1412 g_1425 g_1261.f0 g_1100 g_866.f0 g_776.f0 g_1511 g_1043 g_1195.f0 g_1538 g_1560 g_1566 g_1059.f0 g_1148 g_630.f0 g_1217 g_1635 g_957 g_1652 g_1687 g_1690 g_1021 g_1022 g_1713 g_1243 g_1244 g_1798 g_1242 g_1811 g_1816 g_1830 g_1864 g_1879 g_1969 g_1994 g_1390 g_789.f3 g_2032 g_1459.f1 g_510.f1 g_1969.f0 g_2211 g_2220 g_374.f0 g_1412.f2 g_1566.f0 g_2301 g_2322 g_2363 g_2379 g_589 g_590 g_2401 g_2418 g_2327.f3 g_2456 g_957.f1 g_2472 g_1425.f0 g_1412.f1 g_2540 g_1511.f0 g_2586 g_2599.f3 g_2605 g_2629 g_2653 g_2659 g_2585 g_1142 g_2679 g_2717 g_2550 g_2769 g_2775 g_2797 g_1341.f0 g_2885 g_2911 g_2912 g_2679.f0 g_2925 g_2481 g_3033 g_3207 g_2418.f0 g_3209 g_2301.f0 g_3260 g_3290 g_2244 g_3318 g_1248.f0 g_3406 g_3408 g_2797.f0 g_3494 g_2599.f0 g_3209.f0 g_789.f1 g_3546 g_3564 g_3578 g_3584 g_1560.f0 g_3667 g_3674 g_3692 g_3697 g_2032.f0 g_3747 g_3748 g_1018 g_1019 g_3819 g_3837 g_3162.f3 g_2541 g_2542 g_3933 g_3940 g_3970 g_3974 g_3820 g_3821 g_3986 g_3312.f0 g_2925.f1 g_4008 g_4020 g_1342.f0 g_4133 g_3217.f1 g_4142 g_4145 g_591 g_4184 g_4282 g_4248 g_4290 g_917.f3 g_4297 g_4313 g_4247 g_4364 g_4394 g_2479 g_4414 g_4415 g_4428 g_4437 g_2589 g_4443 g_4488 g_3118 g_4416 g_4417 g_4513 g_4528 g_4563 g_1635.f1 g_3940.f1 g_4580 g_4589 g_1830.f1 g_3578.f1 g_4244.f2 g_1461.f1 g_4723 g_4723.f2 g_789 g_2588 g_4580.f0 g_4244.f1
 * writes: g_49 g_55 g_58 g_82 g_106 g_112 g_137 g_103 g_140.f1 g_220 g_56 g_281 g_223.f1 g_362 g_429.f1 g_483 g_559 g_586 g_608 g_634 g_727 g_375.f1 g_886 g_651 g_933 g_1048 g_1352 g_1343.f1 g_1458 g_1108.f2 g_1102.f0 g_1687 g_1022 g_1043 g_1872 g_1412.f2 g_1188.f0 g_1102.f1 g_1903 g_1952 g_1253 g_1994 g_2001 g_957.f1 g_1459.f1 g_510.f1 g_1327 g_620.f1 g_1149 g_2244 g_2364 g_2457 g_2472 g_1412.f1 g_1811.f1 g_620.f2 g_1830.f1 g_2481.f1 g_2540 g_2211 g_1188.f1 g_2550 g_2584 g_1969.f0 g_1538 g_1142 g_2704 g_1459.f0 g_1244 g_429.f0 g_1816.f1 g_3207 g_2418.f0 g_1652.f1 g_1228 g_3408 g_1879.f1 g_2660 g_3667 g_3674 g_380.f1 g_2911.f1 g_2605.f1 g_2599.f1 g_2679.f1 g_2925.f1 g_3033 g_3748.f2 g_805 g_3217.f1 g_1059.f2 g_3940.f1 g_2541 g_4274.f1 g_4413 g_1635.f1 g_4417 g_4598 g_3578.f1 g_1461.f1 g_4723.f2 g_1143 g_2418.f1 g_4274.f0
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_7 = 0x3D783989L;
    uint16_t l_2470[1];
    uint16_t *l_2471 = &g_2472;
    int32_t l_2473[3][2][9] = {{{0x8CDC0A4AL,(-1L),(-1L),0x8CDC0A4AL,0x3524ABB6L,0x177A25CEL,0x177A25CEL,0x3524ABB6L,0x8CDC0A4AL},{(-1L),0x3C8D7FFEL,(-1L),6L,(-1L),0x3C8D7FFEL,(-1L),6L,(-1L)}},{{0x8CDC0A4AL,0x8CDC0A4AL,0x177A25CEL,(-1L),0x3524ABB6L,0x3524ABB6L,(-1L),0x177A25CEL,0x8CDC0A4AL},{0x4BBF3058L,6L,1L,6L,0x4BBF3058L,6L,1L,6L,0x4BBF3058L}},{{0x3524ABB6L,(-1L),0x177A25CEL,0x8CDC0A4AL,0x8CDC0A4AL,0x177A25CEL,(-1L),0x3524ABB6L,0x3524ABB6L},{(-1L),6L,(-1L),0x3C8D7FFEL,(-1L),6L,(-1L),0x3C8D7FFEL,(-1L)}}};
    int32_t l_2474 = 3L;
    int16_t *l_3206 = &g_3207;
    int32_t *l_3673 = &g_3674;
    uint64_t l_3675 = 0xC7807967CF00A2F4LL;
    int32_t *l_4819 = &g_281;
    uint32_t l_4830 = 18446744073709551615UL;
    uint16_t l_4833 = 8UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2470[i] = 65533UL;
    if (func_2(l_7, l_7, ((*l_3673) |= func_8(((*l_3206) |= (safe_sub_func_int64_t_s_s((func_14((l_2473[1][0][7] &= (func_20((safe_rshift_func_uint64_t_u_s(l_7, l_7))) <= (safe_div_func_int8_t_s_s((((safe_div_func_uint64_t_u_u(((((safe_div_func_uint64_t_u_u((safe_mod_func_int16_t_s_s(((((safe_div_func_int8_t_s_s((2L ^ (7UL < ((((*l_2471) |= l_2470[0]) > ((l_2470[0] , g_1425.f0) <= 0x1EL)) , l_2470[0]))), g_1811.f3)) || 8L) >= g_1690.f1) || l_2470[0]), l_7)), l_2470[0])) < 0xEBL) || 0xA59CFC95L) == l_2470[0]), l_2470[0])) && (-7L)) & g_1798[0].f1), (-1L))))), l_2470[0], l_2470[0], l_2470[0], l_2474) , l_2474), l_7))), l_2470[0], l_7)), l_3675))
    { /* block id: 2055 */
        int32_t *l_4796 = &g_2244;
        int32_t *****l_4801 = &g_1243;
        const uint8_t l_4812 = 0x3DL;
        uint32_t *l_4822[8][6] = {{(void*)0,(void*)0,(void*)0,&g_82,&g_82,&g_82},{&g_82,(void*)0,(void*)0,&g_82,(void*)0,(void*)0},{&g_82,&g_82,(void*)0,&g_82,(void*)0,&g_82},{&g_82,&g_82,(void*)0,(void*)0,&g_82,&g_82},{(void*)0,&g_82,&g_82,&g_82,(void*)0,(void*)0},{(void*)0,&g_82,&g_82,&g_82,(void*)0,&g_82},{(void*)0,(void*)0,&g_82,&g_82,(void*)0,(void*)0},{(void*)0,&g_82,&g_82,(void*)0,&g_82,(void*)0}};
        const int16_t l_4829 = 0x3434L;
        uint8_t l_4831 = 0x71L;
        int i, j;
        (*l_4796) = (l_7 = (safe_sub_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint32_t_u_u(((0xAA521685L || ((*g_4020) != (g_313.f1 , l_4796))) < 0xC8463980L), (safe_sub_func_int16_t_s_s((safe_sub_func_uint16_t_u_u((&g_1019 == l_4801), ((*l_2471) &= ((0UL | (!(safe_add_func_int32_t_s_s((~(safe_mod_func_int16_t_s_s((safe_lshift_func_int8_t_s_u((safe_sub_func_int64_t_s_s(l_2470[0], (**g_3986))), 5)), 65535UL))), l_4812)))) & (*g_609))))), l_2470[0])))), l_7)) || l_2470[0]), (*l_4796))) & (*l_4796)), 0xF1B40F8C69B6AE25LL)));
        l_2473[1][1][3] ^= (*l_4796);
        (*l_4796) = ((&g_2660[3][0] != (void*)0) != (**g_4020));
        l_7 = ((safe_rshift_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_s((safe_rshift_func_int16_t_s_s(g_4580[0].f0, 4)), g_4244.f1)) , ((*l_4796) = (((*l_3206) = (-10L)) >= ((*l_4796) && (1UL && (&l_7 == (l_4819 = &l_2473[2][0][7]))))))), (safe_sub_func_uint32_t_u_u((l_2473[1][0][7] = l_4812), ((safe_sub_func_uint64_t_u_u((safe_rshift_func_int32_t_s_s(((safe_div_func_int16_t_s_s(g_3970[0].f3, l_4829)) != l_7), (*g_805))), l_4830)) < l_3675))))) & l_4831);
    }
    else
    { /* block id: 2066 */
        uint16_t l_4832 = 0x38DDL;
        l_4832 = 2L;
        return g_776.f0;
    }
    return l_4833;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_1538 g_3692 g_3697 g_887 g_1390 g_1261 g_2032.f0 g_220 g_1412 g_588 g_589 g_2885.f1 g_1242 g_1243 g_1244 g_383 g_3747 g_3748 g_1100 g_1101 g_49 g_106 g_3408 g_1811.f2 g_2885.f0 g_1018 g_1019 g_382 g_3819 g_3837 g_1652.f2 g_3162.f3 g_1652.f1 g_55 g_2244 g_2540 g_2541 g_2542 g_1389 g_137 g_3033 g_3933 g_3940 g_103 g_1021 g_1022 g_3970 g_3974 g_789.f0 g_3820 g_3821 g_3986 g_1148 g_1149 g_212 g_213 g_3312.f0 g_609 g_2925.f1 g_2363 g_281 g_4008 g_4020 g_1195.f0 g_2301.f0 g_1342.f0 g_3207 g_56 g_4133 g_3217.f1 g_4142 g_4145 g_590 g_591 g_2629 g_1690.f2 g_1879.f1 g_1327 g_4184 g_805 g_4282 g_4248 g_1969.f0 g_4290 g_917.f3 g_1351 g_4297 g_2211 g_4313 g_4247 g_1798 g_4364 g_4394 g_2418.f0 g_2479 g_4414 g_4415 g_4428 g_4437 g_2589 g_4443 g_4488 g_2769 g_1879.f2 g_3118 g_4416 g_4417 g_4513 g_4528 g_776.f0 g_1053 g_932 g_4563 g_2885.f3 g_4580 g_4589 g_4244.f2 g_4723 g_1811.f1 g_799.f0 g_1142 g_1248.f0 g_789 g_2588 g_1635.f1 g_3940.f1 g_1830.f1 g_3578.f1 g_1461.f1 g_4723.f2
 * writes: g_82 g_380.f1 g_1048 g_1538 g_137 g_2911.f1 g_2605.f1 g_58 g_1969.f0 g_112 g_220 g_106 g_1327 g_1458 g_55 g_103 g_1022 g_2599.f1 g_2679.f1 g_1412.f2 g_2925.f1 g_3033 g_281 g_3748.f2 g_805 g_1687 g_620.f1 g_1228 g_3207 g_3217.f1 g_56 g_1059.f2 g_1253 g_1352 g_2211 g_3940.f1 g_2541 g_1816.f1 g_1459.f1 g_4274.f1 g_4413 g_2418.f0 g_727 g_1635.f1 g_4417 g_4598 g_49 g_1830.f1 g_3578.f1 g_1461.f1 g_4723.f2 g_1143 g_2418.f1 g_4274.f0
 */
static int32_t  func_2(int32_t  p_3, int8_t  p_4, int32_t  p_5, int64_t  p_6)
{ /* block id: 1551 */
    uint8_t l_3677 = 0x7DL;
    union U2 *l_3706[4][8][4] = {{{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653}},{{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]}},{{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653}},{{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653},{&g_2653,&g_630[3],&g_630[3],&g_2653},{&g_630[3],&g_2653,&g_630[3],&g_630[3]},{&g_2653,&g_2653,&g_2911,&g_2653}}};
    uint32_t **l_3719 = (void*)0;
    uint32_t ***l_3718[10][3] = {{&l_3719,&l_3719,&l_3719},{&l_3719,(void*)0,(void*)0},{&l_3719,&l_3719,&l_3719},{&l_3719,(void*)0,(void*)0},{&l_3719,&l_3719,&l_3719},{&l_3719,(void*)0,(void*)0},{&l_3719,&l_3719,&l_3719},{&l_3719,(void*)0,(void*)0},{&l_3719,&l_3719,&l_3719},{&l_3719,(void*)0,(void*)0}};
    uint16_t l_3740 = 0x6F00L;
    int32_t l_3749 = 1L;
    const uint8_t *l_3786[2][5] = {{&g_3787,(void*)0,(void*)0,&g_3787,&g_3787},{&g_3787,(void*)0,(void*)0,&g_3787,&g_3787}};
    const uint8_t **l_3785 = &l_3786[1][3];
    const uint8_t ***l_3784 = &l_3785;
    const uint8_t ****l_3783 = &l_3784;
    int16_t *l_3804 = &g_1327;
    union U4 *l_3845[4][6] = {{&g_2679,&g_2679,&g_2679,&g_2679,&g_2679,&g_2679},{&g_2679,&g_2679,&g_2679,&g_2679,&g_2679,&g_2679},{&g_2679,&g_2679,&g_2679,&g_2679,&g_2679,&g_2679},{&g_2679,&g_2679,&g_2679,&g_2679,&g_2679,&g_2679}};
    uint32_t l_3851 = 18446744073709551615UL;
    uint32_t **l_3855 = (void*)0;
    int32_t l_3882 = 0xED864625L;
    int32_t l_3886[9] = {7L,0xEE432D61L,7L,7L,0xEE432D61L,7L,7L,0xEE432D61L,7L};
    int32_t **l_3976 = (void*)0;
    uint8_t *l_4000 = &g_106;
    int32_t l_4057 = 0xF316C588L;
    int64_t *l_4091[7] = {&g_220,&g_220,&g_220,&g_220,&g_220,&g_220,&g_220};
    uint16_t l_4122[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    struct S0 * const *l_4170 = &g_1144;
    int32_t l_4220 = 0x87FF4ED3L;
    int8_t *l_4246 = &g_2211;
    int8_t **l_4245 = &l_4246;
    uint32_t l_4283 = 1UL;
    uint64_t l_4293 = 0xB1A930AC77B25053LL;
    const uint64_t *l_4309 = &g_1687;
    int32_t l_4325 = 0xA29ADFA5L;
    int16_t l_4340 = 0xFDD6L;
    int64_t l_4358[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    const union U1 **l_4412 = (void*)0;
    const union U1 ***l_4411 = &l_4412;
    const union U1 ****l_4410 = &l_4411;
    const union U1 *****l_4409 = &l_4410;
    int16_t l_4447 = 0x8719L;
    int64_t l_4468[6];
    const int8_t l_4504 = (-2L);
    union U4 **l_4517 = &g_1458;
    struct S0 *****l_4605[4] = {&g_2585,&g_2585,&g_2585,&g_2585};
    uint8_t l_4646 = 2UL;
    int8_t l_4714[5];
    struct S0 *l_4726 = &g_4727[3][1];
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_4468[i] = 0L;
    for (i = 0; i < 5; i++)
        l_4714[i] = 0x7FL;
    for (g_82 = 1; (g_82 <= 4); g_82 += 1)
    { /* block id: 1554 */
        int16_t l_3676 = 7L;
        int32_t l_3699[5][9] = {{0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL},{0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L},{0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL},{0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L,0xC5E8F9E2L},{0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL,0xA461F67FL}};
        struct S0 ****l_3789 = (void*)0;
        uint32_t l_3793 = 0x6069C02BL;
        int64_t l_3843 = 0xBF3E1CFD0711EC4DLL;
        int16_t l_3871 = 0x41C9L;
        uint32_t l_3936 = 0x4DE4C0FFL;
        int16_t l_3948 = 1L;
        int32_t *l_3968[9][3][9] = {{{(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_103,&g_103,(void*)0,&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244}},{{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103}},{{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244}},{{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103}},{{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244}},{{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244,(void*)0,&g_2244,&g_2244},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103}}};
        const uint32_t l_3975 = 0xC9DDAAFCL;
        int64_t **l_3989 = &g_609;
        int8_t *l_4049 = &g_2418.f0;
        uint64_t l_4092 = 0UL;
        const int32_t l_4093[5] = {0x44F99D1AL,0x44F99D1AL,0x44F99D1AL,0x44F99D1AL,0x44F99D1AL};
        uint8_t ***l_4193 = &g_932;
        int64_t l_4222 = 1L;
        int32_t l_4229 = 9L;
        int8_t l_4230 = 0x99L;
        int8_t **l_4250 = &l_4049;
        const union U1 *l_4264 = &g_4265;
        const union U1 **l_4263[6][2][9] = {{{&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264},{(void*)0,(void*)0,&l_4264,&l_4264,(void*)0,(void*)0,&l_4264,&l_4264,(void*)0}},{{&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264},{(void*)0,&l_4264,&l_4264,(void*)0,(void*)0,&l_4264,&l_4264,(void*)0,(void*)0}},{{&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264},{(void*)0,(void*)0,&l_4264,&l_4264,(void*)0,(void*)0,&l_4264,&l_4264,(void*)0}},{{&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264},{(void*)0,&l_4264,&l_4264,(void*)0,(void*)0,&l_4264,&l_4264,(void*)0,(void*)0}},{{&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264},{(void*)0,(void*)0,&l_4264,&l_4264,(void*)0,(void*)0,&l_4264,&l_4264,(void*)0}},{{&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264,(void*)0,&l_4264},{(void*)0,&l_4264,&l_4264,(void*)0,(void*)0,&l_4264,&l_4264,(void*)0,(void*)0}}};
        const union U1 ***l_4262 = &l_4263[0][1][0];
        const union U1 ****l_4261 = &l_4262;
        uint64_t l_4284 = 18446744073709551607UL;
        uint64_t l_4287[7][2][9] = {{{0x7D956E6CDA561795LL,1UL,1UL,0x7D956E6CDA561795LL,0x605346F7CA8C6D9CLL,0x9A9EE1FCEEB9A91ALL,0UL,0UL,0xEFF648C51254CA76LL},{0UL,0UL,1UL,1UL,1UL,1UL,0UL,0UL,0x23B7BDE48DDDB469LL}},{{0x2AF201FA34B62777LL,1UL,0xEFF648C51254CA76LL,0UL,0x605346F7CA8C6D9CLL,0UL,0UL,0x605346F7CA8C6D9CLL,0UL},{0x38A4656B053F47ECLL,0x2AF201FA34B62777LL,0x38A4656B053F47ECLL,0x9A9EE1FCEEB9A91ALL,0UL,1UL,0UL,0x23B7BDE48DDDB469LL,0x23B7BDE48DDDB469LL}},{{1UL,0x2AF201FA34B62777LL,0x23B7BDE48DDDB469LL,0UL,0x23B7BDE48DDDB469LL,0x2AF201FA34B62777LL,1UL,0UL,0xEFF648C51254CA76LL},{0UL,1UL,0UL,0x9A9EE1FCEEB9A91ALL,0x38A4656B053F47ECLL,0x2AF201FA34B62777LL,0x38A4656B053F47ECLL,0x9A9EE1FCEEB9A91ALL,0UL}},{{0UL,0UL,0x605346F7CA8C6D9CLL,0UL,0xEFF648C51254CA76LL,1UL,0x2AF201FA34B62777LL,0UL,0x2AF201FA34B62777LL},{0UL,1UL,1UL,1UL,1UL,0UL,0UL,0x23B7BDE48DDDB469LL,0x7D956E6CDA561795LL}},{{0UL,0x9A9EE1FCEEB9A91ALL,0x605346F7CA8C6D9CLL,0x7D956E6CDA561795LL,1UL,1UL,0x7D956E6CDA561795LL,0x605346F7CA8C6D9CLL,0x9A9EE1FCEEB9A91ALL},{1UL,0UL,0UL,0x38A4656B053F47ECLL,0xEFF648C51254CA76LL,0x9A9EE1FCEEB9A91ALL,0UL,0UL,0x9A9EE1FCEEB9A91ALL}},{{0x38A4656B053F47ECLL,0x605346F7CA8C6D9CLL,0x23B7BDE48DDDB469LL,0x605346F7CA8C6D9CLL,0x38A4656B053F47ECLL,0UL,0x2AF201FA34B62777LL,0UL,0x7D956E6CDA561795LL},{0x2AF201FA34B62777LL,0UL,0x38A4656B053F47ECLL,0x605346F7CA8C6D9CLL,0x23B7BDE48DDDB469LL,0x605346F7CA8C6D9CLL,0x38A4656B053F47ECLL,0UL,0x2AF201FA34B62777LL}},{{0UL,0x9A9EE1FCEEB9A91ALL,0xEFF648C51254CA76LL,0x38A4656B053F47ECLL,0UL,0UL,1UL,0UL,0UL},{0x7D956E6CDA561795LL,1UL,1UL,0x7D956E6CDA561795LL,0x605346F7CA8C6D9CLL,0UL,0x38A4656B053F47ECLL,0x605346F7CA8C6D9CLL,0x23B7BDE48DDDB469LL}}};
        const int32_t l_4350 = 0xB6D85FC0L;
        uint32_t **l_4356 = &g_2220[0];
        int64_t l_4359[8] = {1L,1L,0xD68C539D9E66D174LL,1L,1L,0xD68C539D9E66D174LL,1L,1L};
        const uint64_t l_4436 = 0x7322CEEC352537A5LL;
        int i, j, k;
        if ((l_3676 || l_3677))
        { /* block id: 1555 */
            int16_t l_3698[10][6][3] = {{{0xE568L,0x821AL,0x1148L},{(-1L),0L,(-6L)},{0L,1L,(-1L)},{(-1L),5L,0x6D59L},{0xE568L,4L,4L},{0L,(-1L),(-1L)}},{{0x14BDL,1L,1L},{0L,(-1L),(-1L)},{0xF012L,0x821AL,4L},{0L,0L,0x6D59L},{1L,0L,(-1L)},{0L,1L,(-6L)}},{{0x1148L,0L,0x1148L},{0L,0L,5L},{0L,0x821AL,0x14BDL},{(-1L),(-1L),(-6L)},{0L,1L,0L},{(-1L),(-1L),0x6D59L}},{{0L,4L,0xB516L},{0L,5L,(-1L)},{0x1148L,1L,0xF012L},{0L,0L,(-1L)},{1L,0x821AL,0xB516L},{0L,0x7BFFL,0x6D59L}},{{0xF012L,0L,0L},{0L,0L,(-6L)},{0x14BDL,0L,0x14BDL},{0L,0x7BFFL,5L},{0xE568L,0x821AL,0x1148L},{(-1L),0L,(-6L)}},{{0L,1L,(-1L)},{(-1L),5L,0x6D59L},{0xE568L,4L,4L},{0L,(-1L),(-1L)},{0x14BDL,1L,1L},{0L,(-1L),(-1L)}},{{0xF012L,0x821AL,4L},{0L,0L,0x6D59L},{1L,0L,(-1L)},{0L,1L,(-6L)},{0x1148L,0L,0x1148L},{0L,0L,5L}},{{0L,0x821AL,0x14BDL},{(-1L),(-1L),(-6L)},{0L,1L,0L},{(-1L),(-1L),0x6D59L},{0L,4L,0xB516L},{0L,5L,(-1L)}},{{0x1148L,1L,0xF012L},{0L,0L,(-1L)},{1L,0x821AL,0xB516L},{0L,0x7BFFL,0x6D59L},{0xF012L,0L,0L},{0L,0L,(-6L)}},{{0x14BDL,0L,0x14BDL},{0L,0x7BFFL,5L},{0xE568L,0x821AL,0x1148L},{(-1L),0L,(-6L)},{0L,1L,(-1L)},{(-1L),(-1L),5L}}};
            int32_t l_3713 = (-3L);
            uint32_t ***l_3717 = (void*)0;
            int8_t l_3738 = 0xBFL;
            int32_t l_3739 = 0x29A6DCA4L;
            int i, j, k;
            for (g_380.f1 = 1; (g_380.f1 <= 4); g_380.f1 += 1)
            { /* block id: 1558 */
                int16_t *l_3681 = &g_1048;
                const uint8_t l_3688[7][10] = {{252UL,0xA8L,0xAFL,0x17L,0x9FL,0x9FL,0x17L,0xAFL,0xA8L,252UL},{0xA8L,0x9EL,0UL,0x17L,0xFEL,252UL,0xFEL,0x17L,0UL,0x9EL},{255UL,0xAFL,252UL,0x9EL,0xFEL,0x62L,0x62L,0xFEL,0x9EL,252UL},{0xFEL,0xFEL,0xA8L,255UL,0x9FL,0x62L,0UL,0x62L,0x9FL,255UL},{255UL,0x0FL,255UL,0x62L,0x17L,252UL,0UL,0UL,252UL,0x17L},{0xA8L,0xFEL,0xFEL,0xA8L,255UL,0x9FL,0x62L,0UL,0x62L,0x9FL},{252UL,0xAFL,255UL,0xAFL,252UL,0x9EL,0xFEL,0x62L,0x62L,0xFEL}};
                uint64_t *l_3689 = &g_1538;
                union U2 *l_3711[5] = {&g_1969,&g_1969,&g_1969,&g_1969,&g_1969};
                int32_t l_3712 = (-1L);
                int32_t l_3714 = (-1L);
                int i, j;
                l_3699[0][1] = (safe_mod_func_int16_t_s_s((~((*l_3681) = (0L ^ l_3676))), (safe_div_func_int8_t_s_s(((p_4 >= ((safe_add_func_uint32_t_u_u((p_6 && (safe_sub_func_int64_t_s_s(l_3688[6][7], (++(*l_3689))))), ((g_3692 , (safe_add_func_int64_t_s_s((safe_sub_func_uint32_t_u_u(p_4, (g_3697[0][0] , (l_3677 , l_3676)))), l_3688[6][7]))) < l_3698[1][5][0]))) ^ 1L)) == p_5), l_3677))));
                l_3714 = (l_3688[1][4] ^ (safe_sub_func_uint16_t_u_u(((*g_887) = l_3699[0][1]), (((safe_sub_func_uint32_t_u_u(6UL, (l_3713 ^= (l_3712 = ((*g_1390) , (safe_mul_func_uint16_t_u_u((1UL & (l_3706[2][5][3] == (((p_5 < (((safe_lshift_func_int8_t_s_u((safe_mod_func_uint32_t_u_u((8L < p_3), l_3688[0][9])), 5)) , 0x2CL) >= p_6)) == l_3677) , l_3711[3]))), g_2032.f0))))))) , 0L) <= p_6))));
                for (g_2911.f1 = 4; (g_2911.f1 >= 0); g_2911.f1 -= 1)
                { /* block id: 1568 */
                    int64_t ** const *l_3730[1];
                    int32_t l_3737 = (-2L);
                    int i;
                    for (i = 0; i < 1; i++)
                        l_3730[i] = &g_608;
                    for (g_2605.f1 = 0; (g_2605.f1 <= 0); g_2605.f1 += 1)
                    { /* block id: 1571 */
                        int8_t *l_3726 = &g_58;
                        int32_t *l_3734 = &l_3714;
                        int32_t *l_3735 = &l_3699[0][1];
                        int32_t *l_3736[7] = {&l_3699[2][5],&l_3699[2][5],&l_3699[2][5],&l_3699[2][5],&l_3699[2][5],&l_3699[2][5],&l_3699[2][5]};
                        int64_t l_3743 = 1L;
                        int i;
                        l_3713 = (g_220 ^ ((safe_mul_func_int32_t_s_s(((l_3718[5][0] = l_3717) != (g_1412 , (*g_588))), ((safe_div_func_uint32_t_u_u((((((((safe_add_func_uint32_t_u_u((((safe_rshift_func_int8_t_s_u((g_1969.f0 = ((*l_3726) = g_220)), l_3677)) || ((~(safe_add_func_int64_t_s_s(((l_3730[0] == (void*)0) == (safe_mul_func_int64_t_s_s((+(-1L)), 0x1BDAB93BE07197D9LL))), p_3))) , 0UL)) , l_3698[8][0][2]), p_5)) >= (-1L)) , 0xC51B4A1F4233F090LL) && l_3698[1][5][0]) , p_4) > 1UL) ^ 18446744073709551613UL), p_4)) | p_5))) | g_2885.f1));
                        ++l_3740;
                        (****g_1242) = &l_3737;
                        return l_3743;
                    }
                }
            }
        }
        else
        { /* block id: 1582 */
            int64_t l_3760 = 1L;
            int32_t l_3761 = 0x5EE850A6L;
            const union U3 *l_3805 = &g_510;
            int32_t l_3876 = 1L;
            int32_t l_3877 = 2L;
            int32_t l_3879 = 0L;
            int32_t l_3880 = 0x7C9B68D4L;
            int32_t l_3883 = 0xD3DA8AA1L;
            int32_t l_3884 = 1L;
            int32_t l_3885 = (-6L);
            uint8_t l_3888[4] = {0x61L,0x61L,0x61L,0x61L};
            union U1 ***l_3943 = (void*)0;
            int32_t l_3949 = 1L;
            int64_t *l_3995[3][3][5] = {{{(void*)0,&g_220,(void*)0,&l_3760,(void*)0},{&l_3760,&l_3760,&g_220,(void*)0,&g_56[0]},{&l_3760,&l_3760,&g_220,&l_3760,&l_3760}},{{&g_56[0],(void*)0,&g_220,&l_3760,&l_3760},{(void*)0,&l_3760,(void*)0,&g_220,(void*)0},{&g_56[0],&l_3760,(void*)0,(void*)0,&l_3760}},{{&l_3760,&g_220,&g_220,&g_220,&l_3760},{&l_3760,(void*)0,(void*)0,&l_3760,&g_56[0]},{(void*)0,&g_220,(void*)0,&l_3760,(void*)0}}};
            int64_t ** const l_3994 = &l_3995[0][2][4];
            int64_t ** const *l_3993[3][9][9] = {{{&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,(void*)0,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{(void*)0,&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,(void*)0},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994}},{{(void*)0,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,(void*)0},{(void*)0,(void*)0,&l_3994,&l_3994,&l_3994,(void*)0,(void*)0,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,(void*)0,&l_3994,(void*)0,&l_3994},{&l_3994,(void*)0,(void*)0,(void*)0,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,(void*)0,&l_3994,&l_3994,(void*)0,(void*)0,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994}},{{&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,(void*)0},{&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,(void*)0},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994,&l_3994},{&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,(void*)0,&l_3994,(void*)0,(void*)0},{&l_3994,&l_3994,(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,&l_3994},{(void*)0,&l_3994,&l_3994,&l_3994,&l_3994,(void*)0,(void*)0,&l_3994,&l_3994}}};
            const int8_t *l_4050[1][9][5] = {{{(void*)0,&g_374.f0,&g_630[2].f0,&g_1425.f0,&g_58},{&g_374.f0,(void*)0,(void*)0,(void*)0,&g_2418.f0},{&g_1425.f0,&g_374.f0,&g_630[2].f0,&g_58,&g_2653.f0},{&g_1969.f0,&g_630[2].f0,(void*)0,(void*)0,&g_630[2].f0},{&g_58,&g_2911.f0,&g_2418.f0,&g_374.f0,&g_2653.f0},{(void*)0,(void*)0,&g_2418.f0,(void*)0,&g_2418.f0},{&g_2653.f0,&g_2653.f0,&g_1425.f0,&g_58,(void*)0},{(void*)0,&g_374.f0,&g_1969.f0,(void*)0,(void*)0},{&g_58,&g_1425.f0,&g_58,&g_630[2].f0,&g_58}}};
            uint8_t l_4078 = 255UL;
            union U4 *l_4090[5][10] = {{&g_2479[5][2],(void*)0,&g_2481[0],&g_3564,&g_2481[0],(void*)0,&g_2479[5][2],&g_2479[4][2],(void*)0,(void*)0},{(void*)0,&g_2479[5][2],&g_2479[4][2],(void*)0,(void*)0,&g_1816,&g_2481[0],&g_2479[4][2],&g_2479[4][2],&g_2479[4][2]},{(void*)0,&g_2479[5][2],&g_2479[4][2],&g_2605,&g_2605,&g_2479[4][2],&g_2479[5][2],(void*)0,(void*)0,&g_380},{&g_3564,(void*)0,(void*)0,&g_2479[4][2],&g_1816,&g_2925,&g_380,&g_1816,(void*)0,&g_2605},{&g_2481[0],(void*)0,(void*)0,&g_1816,&g_2481[0],&g_1816,(void*)0,(void*)0,&g_2481[0],(void*)0}};
            uint32_t l_4094 = 0x849D76ADL;
            int i, j, k;
            if ((~(l_3676 , (1UL == (l_3761 = (safe_sub_func_uint16_t_u_u((((((-2L) <= l_3677) > ((g_3747 , g_3748) , ((l_3749 = l_3699[3][3]) && (safe_mod_func_uint8_t_u_u(255UL, (safe_lshift_func_int32_t_s_s(((safe_mod_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((l_3749 = (p_3 || l_3760)), l_3699[3][4])), (-1L))), 18446744073709551608UL)) || 9UL), p_5))))))) != (**g_1100)) ^ p_5), 0x8AE5L)))))))
            { /* block id: 1586 */
                const struct S0 ****l_3788 = &g_2588;
                int32_t l_3794 = (-1L);
                union U3 **l_3828 = &g_1022;
                int32_t l_3844 = 0xF33A4C15L;
                uint32_t **l_3856 = &g_591[1][2];
                int32_t l_3870 = 0x5A02DC82L;
                int64_t l_3872[1][10] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
                int32_t l_3873 = 0L;
                int32_t l_3874[10][3] = {{0L,0xEF6E0B34L,0xEF6E0B34L},{0x56DA349BL,1L,1L},{0L,0xEF6E0B34L,0xEF6E0B34L},{0x56DA349BL,1L,1L},{0L,0xEF6E0B34L,0xEF6E0B34L},{0x56DA349BL,1L,1L},{0L,0xEF6E0B34L,0xEF6E0B34L},{0x56DA349BL,1L,1L},{0L,0xEF6E0B34L,0xEF6E0B34L},{0x56DA349BL,1L,1L}};
                int16_t l_3950 = 0x4D00L;
                uint32_t l_3952 = 0UL;
                int32_t **l_3967 = &g_112[4];
                int8_t *l_3969 = &g_2679.f1;
                union U2 ** const l_3973[10] = {&g_2662,&l_3706[2][5][3],&g_2662,&g_2662,&g_2662,&g_2662,&l_3706[2][5][3],&g_2662,&g_2662,&g_2662};
                int i, j;
                for (g_220 = 1; (g_220 <= 4); g_220 += 1)
                { /* block id: 1589 */
                    uint8_t *l_3764 = &g_106;
                    uint8_t *l_3771 = &l_3677;
                    int8_t *l_3774[4][8][6] = {{{&g_1816.f1,&g_2211,&g_2211,&g_2418.f0,&g_3033,(void*)0},{&g_2418.f0,&g_3033,(void*)0,&g_2911.f0,&g_3033,&g_2418.f0},{&g_2911.f0,(void*)0,&g_3290.f0,&g_1425.f0,&g_3290.f0,&g_2911.f0},{&g_3290.f0,&g_3290.f0,&g_630[2].f0,&g_2911.f0,&g_2211,&g_2211},{&g_630[2].f0,&g_2653.f0,&g_2211,&g_2211,&g_2211,&g_2653.f0},{(void*)0,&g_3290.f0,&g_3290.f0,&g_3290.f0,&g_2211,&g_3033},{&g_2911.f0,&g_1969.f0,&g_1969.f0,&g_2211,&g_1816.f1,&g_2911.f0},{&g_2653.f0,&g_1969.f0,&g_58,&g_2418.f0,&g_2211,&g_1425.f0}},{{(void*)0,&g_3290.f0,&g_2211,&g_2911.f0,&g_630[2].f0,(void*)0},{&g_58,&g_2911.f0,&g_2211,(void*)0,&g_1816.f1,&g_630[2].f0},{&g_3033,&g_2211,&g_2911.f0,&g_3290.f0,&g_2911.f0,&g_2211},{&g_2211,&g_2211,(void*)0,&g_2211,&g_3290.f0,&g_630[2].f0},{&g_630[2].f0,(void*)0,&g_1969.f0,&g_1969.f0,(void*)0,&g_630[2].f0},{&g_3290.f0,&g_2911.f0,&g_2653.f0,&g_2911.f0,&g_2911.f0,&g_2211},{&g_3290.f0,&g_1969.f0,&g_2211,&g_651,&g_3290.f0,&g_1969.f0},{&g_3290.f0,&g_630[2].f0,&g_651,&g_2911.f0,&g_3033,(void*)0}},{{&g_3290.f0,&g_2911.f0,&g_3033,&g_1969.f0,&g_3290.f0,&g_2211},{&g_630[2].f0,&g_2418.f0,&g_3033,&g_2211,&g_3290.f0,&g_58},{&g_2211,&g_1969.f0,&g_3290.f0,&g_3290.f0,&g_630[2].f0,&g_2911.f0},{&g_3033,&g_2653.f0,&g_2211,(void*)0,&g_2418.f0,&g_2418.f0},{&g_58,&g_2911.f0,&g_2211,&g_2911.f0,&g_58,&g_2211},{&g_2211,&g_2418.f0,&g_2211,&g_2211,&g_2211,(void*)0},{&g_3033,&g_651,&g_1816.f1,&g_2418.f0,&g_2653.f0,(void*)0},{&g_630[2].f0,&g_2653.f0,&g_2211,&g_3033,&g_3290.f0,&g_2211}},{{&g_2653.f0,(void*)0,&g_2211,&g_3290.f0,&g_3290.f0,&g_2418.f0},{&g_2418.f0,&g_1425.f0,&g_2211,(void*)0,&g_2211,&g_2911.f0},{&g_2911.f0,&g_2211,&g_3290.f0,&g_3290.f0,&g_630[2].f0,&g_58},{&g_3290.f0,&g_630[2].f0,&g_3033,&g_1969.f0,&g_2211,&g_2211},{&g_1425.f0,&g_3033,&g_3033,&g_1425.f0,&g_3290.f0,(void*)0},{&g_2911.f0,&g_3290.f0,&g_651,&g_2911.f0,&g_2911.f0,&g_1969.f0},{(void*)0,&g_2418.f0,&g_2211,&g_2211,&g_2911.f0,&g_2211},{&g_1969.f0,&g_3290.f0,&g_2653.f0,&g_2211,&g_3290.f0,&g_630[2].f0}}};
                    uint64_t *l_3792 = (void*)0;
                    uint64_t ** const l_3791[5] = {&l_3792,&l_3792,&l_3792,&l_3792,&l_3792};
                    uint64_t ** const *l_3790 = &l_3791[4];
                    const union U3 *l_3806[9][7][4] = {{{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,(void*)0,(void*)0,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,(void*)0,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807}},{{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,(void*)0,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807}},{{&g_3807,(void*)0,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807},{(void*)0,&g_3807,&g_3807,&g_3807}},{{&g_3807,&g_3807,&g_3807,&g_3807},{(void*)0,&g_3807,&g_3807,&g_3807},{&g_3807,(void*)0,&g_3807,&g_3807},{&g_3807,(void*)0,(void*)0,&g_3807},{(void*)0,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807}},{{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,(void*)0,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,(void*)0,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,(void*)0,(void*)0,&g_3807},{(void*)0,&g_3807,&g_3807,&g_3807}},{{(void*)0,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,(void*)0,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807}},{{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,(void*)0,&g_3807},{(void*)0,&g_3807,&g_3807,(void*)0},{&g_3807,(void*)0,&g_3807,&g_3807}},{{(void*)0,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807},{(void*)0,&g_3807,(void*)0,&g_3807},{&g_3807,(void*)0,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,&g_3807}},{{&g_3807,&g_3807,(void*)0,&g_3807},{(void*)0,&g_3807,&g_3807,&g_3807},{&g_3807,(void*)0,&g_3807,(void*)0},{&g_3807,&g_3807,(void*)0,&g_3807},{&g_3807,&g_3807,&g_3807,(void*)0},{&g_3807,&g_3807,&g_3807,&g_3807},{&g_3807,&g_3807,&g_3807,(void*)0}}};
                    int i, j, k;
                    l_3761 = (safe_div_func_uint8_t_u_u(((*l_3764)--), ((safe_add_func_int8_t_s_s((safe_mod_func_uint8_t_u_u((--(*l_3771)), (l_3699[0][1] &= g_3408))), (safe_mod_func_int8_t_s_s((g_1811.f2 & (safe_mul_func_int8_t_s_s(((l_3794 = (((l_3793 = (safe_mul_func_uint8_t_u_u((safe_rshift_func_int64_t_s_u(l_3676, ((((void*)0 != l_3783) < ((l_3788 == l_3789) >= ((((void*)0 == l_3790) & p_4) == p_4))) , (**g_1100)))), l_3761))) | 0xAAAF19039AD77348LL) <= l_3676)) , 0x98L), g_2885.f0))), 0x0CL)))) || 0xD1B5A749L)));
                    (*g_383) = &l_3761;
                    l_3749 = (safe_mod_func_int8_t_s_s(((((safe_add_func_int8_t_s_s((safe_unary_minus_func_uint64_t_u((safe_mul_func_int32_t_s_s(0x410CC2B5L, (safe_lshift_func_int32_t_s_u(l_3749, 27)))))), 0x9BL)) & (0UL < ((**g_1018) != (*g_1243)))) >= ((*l_3804) = ((void*)0 != l_3804))) >= l_3761), l_3760));
                    for (g_1327 = 4; (g_1327 >= 0); g_1327 -= 1)
                    { /* block id: 1601 */
                        const union U3 **l_3808 = &l_3805;
                        int32_t *l_3829 = &l_3699[0][1];
                        (*l_3808) = (l_3806[5][5][3] = l_3805);
                        if (l_3699[0][1])
                            continue;
                        l_3699[0][1] = (safe_div_func_uint8_t_u_u(((safe_rshift_func_int64_t_s_u(((safe_lshift_func_uint16_t_u_s((safe_mul_func_int8_t_s_s((safe_div_func_int8_t_s_s((g_3819 == &g_1229), 0x83L)), 0L)), 15)) && ((safe_mod_func_uint8_t_u_u(((((void*)0 == &g_2587[0][0]) && (safe_mul_func_int32_t_s_s((0x0298F66C31C1B599LL < (((safe_rshift_func_uint64_t_u_u(l_3749, 35)) ^ ((void*)0 != l_3828)) | p_5)), l_3793))) && 0x2AEEL), 1L)) != p_3)), 49)) <= l_3760), l_3761));
                        l_3829 = &l_3749;
                    }
                }
                if ((((safe_unary_minus_func_int8_t_s(((safe_rshift_func_int16_t_s_s(((l_3794 & ((safe_add_func_int8_t_s_s(((g_3837 , p_5) > ((safe_unary_minus_func_uint64_t_u(((p_6 , 0xA36FC1FCL) > (l_3844 |= (((safe_div_func_int16_t_s_s((p_5 , ((-7L) && (((safe_div_func_int8_t_s_s((p_5 > p_3), 0x6AL)) < l_3843) >= 0xB719L))), 0x2700L)) == (**g_1100)) & 0xD2L))))) > 0xCD61L)), p_4)) && (**g_1100))) , p_6), 7)) >= g_1652.f2))) , p_4) > 0xDE8AA4DE6D33E826LL))
                { /* block id: 1610 */
                    union U4 **l_3846 = &g_1458;
                    int32_t *l_3847 = &l_3794;
                    int32_t *l_3848 = &g_2244;
                    int32_t *l_3849 = &l_3761;
                    int32_t *l_3850[4] = {&l_3794,&l_3794,&l_3794,&l_3794};
                    uint8_t ***l_3863 = &g_932;
                    int i;
                    l_3845[2][2] = ((*l_3846) = l_3845[2][2]);
                    l_3851++;
                    if ((~((l_3856 = l_3855) != (void*)0)))
                    { /* block id: 1615 */
                        uint64_t *l_3867 = (void*)0;
                        uint64_t *l_3868 = &g_55;
                        int32_t l_3869 = 0x8D9356B7L;
                        int32_t l_3875 = 0xF3C17BB1L;
                        int32_t l_3878 = 0xFE051030L;
                        int32_t l_3881[5][5][4] = {{{0xF3001D79L,(-1L),0x123B2AA4L,(-1L)},{0L,(-1L),0x123B2AA4L,2L},{0xF3001D79L,0x438E140CL,0L,2L},{(-10L),(-1L),(-10L),(-1L)},{(-10L),(-1L),0L,7L}},{{0xF3001D79L,(-1L),0x123B2AA4L,(-1L)},{0L,(-1L),0x123B2AA4L,2L},{0xF3001D79L,0x438E140CL,0L,2L},{(-10L),(-1L),(-10L),(-1L)},{(-10L),(-1L),0L,7L}},{{0xF3001D79L,(-1L),0x123B2AA4L,(-1L)},{0L,(-1L),0x123B2AA4L,2L},{0xF3001D79L,0x438E140CL,0L,2L},{(-10L),(-1L),(-10L),(-1L)},{(-10L),(-1L),0L,7L}},{{0xF3001D79L,(-1L),0x123B2AA4L,(-1L)},{0L,(-1L),0x123B2AA4L,2L},{0xF3001D79L,0x438E140CL,0L,2L},{(-10L),(-1L),(-10L),(-1L)},{(-10L),(-1L),0L,7L}},{{0xF3001D79L,(-1L),0x123B2AA4L,(-1L)},{0L,(-1L),0x123B2AA4L,2L},{0xF3001D79L,0x438E140CL,0L,2L},{(-10L),(-1L),(-10L),(-1L)},{(-10L),(-1L),0L,7L}}};
                        int32_t l_3887 = (-1L);
                        int i, j, k;
                        l_3794 = (safe_mod_func_uint32_t_u_u(p_5, (safe_mod_func_uint32_t_u_u((((l_3749 , ((p_3 ^ ((safe_mul_func_int64_t_s_s(0x650CB9F3CA59F077LL, (((l_3869 = (((*l_3783) == l_3863) && ((safe_add_func_uint64_t_u_u(((*l_3868) &= (!((p_3 && g_3162.f3) & g_1652.f1))), p_5)) || 1UL))) != (*l_3848)) || 0xA420A10F2A7F7FF6LL))) && l_3760)) < 0xBE32C2695FEFB32ALL)) || l_3760) != 0xC967L), p_4))));
                        l_3888[3]++;
                        (***g_1243) = l_3848;
                    }
                    else
                    { /* block id: 1621 */
                        uint16_t l_3893 = 0UL;
                        (*l_3849) &= (((void*)0 == (**g_2540)) || ((**g_1389) , (++(*g_887))));
                        --l_3893;
                    }
                }
                else
                { /* block id: 1626 */
                    int64_t l_3908 = 0x04EC9950D15FBA7FLL;
                    int32_t l_3927 = (-1L);
                    int16_t l_3928 = 0x6834L;
                    int32_t l_3929[7][4][5] = {{{(-5L),4L,0xB8255A63L,4L,(-5L)},{0x634955F1L,0x1A05AD15L,0x691EA4CBL,0x9721B321L,0x3602A113L},{0xC3C2DBC5L,0x089B0F0CL,(-1L),(-1L),0x089B0F0CL},{0x7CB7882AL,(-1L),0x9E660508L,0x1A05AD15L,0x3602A113L}},{{0L,(-1L),0x1BB6BD02L,1L,(-5L)},{0x3602A113L,0x17C3858AL,0x634955F1L,0x7CB7882AL,0x900D9BB1L},{4L,(-3L),(-2L),0x07F48B31L,0x07F48B31L},{0x6426FB97L,0x3613CB8BL,0x6426FB97L,0L,(-1L)}},{{0xC3C2DBC5L,0xFC833295L,0L,0xFED05E5CL,0xA7ED072CL},{0xE48DC2E6L,0x3602A113L,0xE3A51427L,0xE48DC2E6L,0x7CB7882AL},{0x1BB6BD02L,(-1L),0L,0xA7ED072CL,(-3L)},{0L,0x13166606L,0x6426FB97L,(-1L),0x7CAFB5BEL}},{{(-1L),0xFED05E5CL,(-2L),0x548E5105L,0x6DE94830L},{0x691EA4CBL,0x1A05AD15L,0x634955F1L,0x634955F1L,0x1A05AD15L},{0x089B0F0CL,0x4E88DDA8L,(-2L),(-1L),0x03710A38L},{0L,0x17C3858AL,0xAD4A1C16L,0x13166606L,0x691EA4CBL}},{{0x03710A38L,1L,(-6L),2L,0x1BB6BD02L},{0L,0x9E660508L,9L,2L,(-2L)},{0x089B0F0CL,0xA7ED072CL,0xFED05E5CL,0L,0xFC833295L},{9L,0x7CAFB5BEL,(-8L),0L,0x900D9BB1L}},{{0x30C6ADCBL,0x03710A38L,0x03710A38L,0x30C6ADCBL,2L},{0x691EA4CBL,0x17C3858AL,0x3613CB8BL,0x900D9BB1L,0x7CAFB5BEL},{(-2L),0L,2L,0x4E88DDA8L,0xB58BF23DL},{0x17C3858AL,0L,9L,0x900D9BB1L,0L}},{{7L,(-1L),0x6DE94830L,0x30C6ADCBL,(-1L)},{(-2L),0L,0x9F8F2E2AL,0L,0L},{0L,(-6L),(-2L),0L,(-2L)},{0L,0L,0x3602A113L,2L,0x7CAFB5BEL}}};
                    uint8_t l_3930 = 255UL;
                    int32_t *l_3946 = &l_3873;
                    int32_t *l_3947[5][6][1] = {{{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]}},{{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]}},{{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]}},{{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]}},{{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]},{&l_3929[3][3][1]},{&l_3874[0][0]}}};
                    int64_t l_3951 = 0L;
                    int i, j, k;
                    if ((((((~(safe_mod_func_int16_t_s_s((safe_rshift_func_int64_t_s_s(((p_4 ^ (~(p_5 & (l_3884 || (safe_mod_func_int64_t_s_s(p_6, (safe_mod_func_uint8_t_u_u(0x41L, (safe_sub_func_uint8_t_u_u((l_3908 > (safe_rshift_func_int64_t_s_u((l_3884 & ((((safe_div_func_uint64_t_u_u(((p_6 , l_3880) | 0x7B20E021L), p_3)) < 0x4DEADF58ABB30A92LL) , (-1L)) < l_3908)), p_6))), g_3033)))))))))) | l_3908), 29)), 0xD756L))) != p_3) < 0x96L) <= l_3740) | (-4L)))
                    { /* block id: 1627 */
                        int32_t *l_3913 = &l_3876;
                        int32_t *l_3914 = &l_3761;
                        int32_t *l_3915 = &l_3761;
                        int32_t *l_3916 = &g_103;
                        int32_t *l_3917 = &l_3699[2][7];
                        int32_t *l_3918 = (void*)0;
                        int32_t *l_3919 = &l_3699[0][1];
                        int32_t *l_3920 = &l_3876;
                        int32_t *l_3921 = &l_3873;
                        int32_t *l_3922 = &l_3877;
                        int32_t *l_3923 = &l_3874[6][0];
                        int32_t *l_3924 = (void*)0;
                        int32_t *l_3925 = &l_3879;
                        int32_t *l_3926[5][3][8] = {{{&l_3870,&l_3876,&g_281,&l_3885,&l_3870,&g_2244,(void*)0,&g_2244},{(void*)0,&l_3886[5],&g_2244,&l_3699[4][8],&l_3885,&g_2244,&g_281,&g_103},{&l_3873,&l_3876,(void*)0,&l_3886[5],&l_3877,&l_3885,(void*)0,&l_3844}},{{&g_103,&l_3877,&l_3886[5],&l_3879,(void*)0,&l_3885,&l_3885,&g_281},{&l_3886[1],&l_3885,(void*)0,&l_3844,&l_3886[5],&l_3844,(void*)0,&l_3885},{&g_2244,&g_103,(void*)0,&l_3876,&l_3876,&l_3874[6][0],&l_3873,&l_3884}},{{&g_2244,(void*)0,&l_3876,&g_2244,&g_2244,&g_281,&l_3873,&l_3876},{&l_3876,&g_2244,(void*)0,&l_3874[6][0],&l_3699[4][8],&l_3883,(void*)0,&l_3885},{&l_3699[4][8],&l_3883,(void*)0,&l_3885,(void*)0,&g_281,&l_3885,&l_3699[1][3]}},{{&l_3885,&g_281,&l_3886[5],(void*)0,&l_3884,&l_3884,(void*)0,&l_3886[5]},{&l_3870,&l_3870,(void*)0,(void*)0,(void*)0,(void*)0,&g_281,&l_3883},{&l_3876,&l_3882,&g_2244,&l_3699[4][8],(void*)0,(void*)0,&l_3886[5],&g_2244}},{{&g_2244,&g_103,&l_3699[1][3],&l_3699[4][1],&g_281,&l_3879,&g_281,&l_3876},{&l_3876,&l_3844,&l_3874[6][0],(void*)0,&g_103,(void*)0,&g_2244,(void*)0},{&g_281,&g_281,&l_3876,&l_3884,(void*)0,(void*)0,(void*)0,&l_3884}}};
                        int i, j, k;
                        ++l_3930;
                        return p_6;
                    }
                    else
                    { /* block id: 1630 */
                        uint16_t l_3944 = 0xCDBDL;
                        int32_t *l_3945 = &g_103;
                        l_3794 ^= (g_3933 , (safe_mod_func_int32_t_s_s(((p_6 != l_3936) & (0x9CC85903L >= ((+(safe_sub_func_uint8_t_u_u(((l_3929[2][3][2] = p_3) || l_3936), ((g_3940 , (l_3873 <= ((void*)0 != l_3943))) < l_3843)))) , 1L))), l_3944)));
                        (*l_3945) &= p_4;
                        (*l_3945) &= (p_5 && 4UL);
                        if (p_3)
                            continue;
                    }
                    (*l_3828) = (*g_1021);
                    --l_3952;
                    for (g_2599.f1 = 1; (g_2599.f1 <= 4); g_2599.f1 += 1)
                    { /* block id: 1641 */
                        int8_t l_3955[10][7] = {{(-1L),(-1L),(-2L),0x4DL,0x95L,0x4DL,(-2L)},{(-1L),(-1L),0xCFL,(-6L),0x55L,(-6L),0xCFL},{(-1L),(-1L),(-2L),0x4DL,0x95L,0x4DL,(-2L)},{(-1L),(-1L),0xCFL,(-6L),0x55L,(-6L),0xCFL},{(-1L),(-1L),(-2L),0x4DL,0x95L,0x4DL,(-2L)},{(-1L),(-1L),0xCFL,(-6L),0x55L,(-6L),0xCFL},{(-1L),(-1L),(-2L),0x4DL,0x95L,0x4DL,(-2L)},{(-1L),(-1L),0xCFL,(-6L),0x55L,(-6L),0xCFL},{(-1L),(-1L),(-2L),0x4DL,0x95L,0x4DL,(-2L)},{(-1L),(-1L),0xCFL,(-6L),0x55L,(-6L),0xCFL}};
                        uint16_t l_3956[7] = {0UL,0UL,7UL,0UL,0UL,7UL,0UL};
                        int i, j;
                        l_3870 = 1L;
                        l_3956[1]--;
                    }
                }
                l_3873 = (l_3885 = (l_3699[0][8] = ((l_3886[1] = ((safe_mul_func_uint32_t_u_u((((safe_add_func_int8_t_s_s((safe_div_func_int32_t_s_s((l_3793 ^ ((((((safe_mul_func_int32_t_s_s(((l_3976 = ((((*l_3969) = (&l_3874[6][0] != (l_3968[6][2][3] = &l_3877))) , g_3970[0]) , ((safe_add_func_int8_t_s_s(((l_3876 = ((*g_887) ^= (((l_3749 = p_5) , l_3973[2]) == l_3973[4]))) == (g_3974 , (p_3 && p_6))), l_3975)) , &l_3968[6][2][3]))) == (***g_1242)), l_3883)) & l_3676) < p_3) , p_3) | 18446744073709551615UL) < 0L)), p_6)), l_3936)) > p_6) >= p_3), p_4)) && l_3949)) || g_789.f0)));
                (*l_3828) = (*l_3828);
            }
            else
            { /* block id: 1657 */
                int32_t l_4001 = 0x737F83A0L;
                int32_t l_4003[6][8] = {{(-5L),(-1L),0xD1CED691L,1L,0xD8BD0328L,1L,0xE893912DL,(-1L)},{(-5L),0x6BAAD180L,(-1L),0xE893912DL,0xE893912DL,(-1L),0x6BAAD180L,(-5L)},{(-4L),(-9L),(-1L),1L,(-5L),0x2D2DD59DL,(-4L),0x6BAAD180L},{(-9L),1L,0xCD53127BL,8L,1L,0x2D2DD59DL,0xE893912DL,0x2D2DD59DL},{1L,(-9L),0xCB8AADBCL,(-9L),1L,(-1L),8L,1L},{0x2D2DD59DL,0x6BAAD180L,(-4L),0x2D2DD59DL,(-5L),1L,(-1L),(-9L)}};
                int8_t *l_4015 = (void*)0;
                uint32_t *l_4018[9][1] = {{&g_620.f2},{&g_82},{&g_620.f2},{&g_620.f2},{&g_82},{&g_620.f2},{&g_620.f2},{&g_82},{&g_620.f2}};
                int32_t l_4081 = 1L;
                union U4 **l_4082 = &l_3845[2][1];
                int32_t l_4083 = 0x45FFC8ADL;
                int i, j;
                if (p_3)
                    break;
                for (l_3740 = 0; (l_3740 <= 4); l_3740 += 1)
                { /* block id: 1661 */
                    uint16_t l_3983 = 0UL;
                    int32_t l_4004[6][5] = {{0x8A33D63BL,(-1L),0x8A33D63BL,(-1L),0x8A33D63BL},{9L,9L,9L,9L,9L},{0x8A33D63BL,(-1L),0x8A33D63BL,(-1L),0x8A33D63BL},{9L,9L,9L,9L,9L},{0x8A33D63BL,(-1L),0x8A33D63BL,(-1L),0x8A33D63BL},{9L,9L,9L,9L,9L}};
                    uint8_t l_4005 = 0x34L;
                    int i, j;
                    for (g_1412.f2 = 0; (g_1412.f2 <= 1); g_1412.f2 += 1)
                    { /* block id: 1664 */
                        int32_t * const l_3977 = &l_3949;
                        int32_t **l_3978 = &g_112[1];
                        (*l_3978) = l_3977;
                        (*l_3977) = p_5;
                        (*g_383) = &l_3879;
                        (*l_3977) = (safe_lshift_func_int32_t_s_u(p_5, p_5));
                    }
                    for (g_2925.f1 = 0; (g_2925.f1 <= 4); g_2925.f1 += 1)
                    { /* block id: 1672 */
                        int64_t ***l_3987 = &g_608;
                        int64_t ***l_3988 = &g_608;
                        int64_t ** const **l_3992 = (void*)0;
                        int32_t l_4002[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_4002[i] = 4L;
                        l_4002[0] |= ((safe_rshift_func_uint8_t_u_u((l_3983 || (0x7BC048D333F5FE2DLL < (((*g_609) = (safe_rshift_func_uint16_t_u_u((((*g_3820) == (l_3989 = g_3986)) == (p_5 >= (safe_mul_func_int64_t_s_s(((((*g_1148) == (l_3993[2][8][7] = &g_608)) , ((*l_4000) &= ((((safe_rshift_func_uint32_t_u_s(((*g_212) , ((((safe_add_func_int64_t_s_s(((p_3 < p_5) ^ (-3L)), p_3)) , p_3) && p_3) >= g_3312[1][2][1].f0)), 4)) != (*g_1101)) , (void*)0) == l_4000))) , p_4), 0x6A8F19A2CE2A7C15LL)))), 12))) , l_4001))), p_4)) != g_2925.f1);
                    }
                    --l_4005;
                    for (g_3033 = 4; (g_3033 >= 0); g_3033 -= 1)
                    { /* block id: 1682 */
                        int64_t l_4012[8] = {0x5348B348BF20BDB2LL,0x5348B348BF20BDB2LL,0x5348B348BF20BDB2LL,0x5348B348BF20BDB2LL,0x5348B348BF20BDB2LL,0x5348B348BF20BDB2LL,0x5348B348BF20BDB2LL,0x5348B348BF20BDB2LL};
                        int32_t *l_4013 = &l_3882;
                        int32_t *l_4014[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_4014[i] = &l_3876;
                        (*g_2363) |= l_4005;
                        l_4012[4] = (g_4008 , (+(safe_rshift_func_uint64_t_u_u(p_5, 53))));
                        l_4014[0] = l_4013;
                        if (l_3879)
                            continue;
                    }
                }
                if ((*g_2363))
                    break;
                if (((((((p_6 != p_5) , l_4015) != ((&p_6 != &p_6) , &g_2211)) , (safe_sub_func_int8_t_s_s(0x03L, ((l_4018[8][0] = &l_3936) != (void*)0)))) > p_3) >= 0x893E8AC00D0F3871LL))
                { /* block id: 1691 */
                    int32_t l_4021 = 0L;
                    int32_t l_4060 = (-1L);
                    int32_t l_4062[4];
                    int32_t l_4063 = (-1L);
                    int i;
                    for (i = 0; i < 4; i++)
                        l_4062[i] = 0x3007A07BL;
                    for (g_3748.f2 = 1; (g_3748.f2 <= 4); g_3748.f2 += 1)
                    { /* block id: 1694 */
                        const int32_t *l_4019 = &g_103;
                        int16_t l_4055 = 0xDDAFL;
                        uint8_t l_4056 = 0xBBL;
                        uint8_t *l_4058 = (void*)0;
                        uint8_t *l_4059 = &l_3677;
                        uint64_t *l_4061 = &g_1687;
                        (*g_4020) = l_4019;
                        l_4021 = 0L;
                        l_4063 = (((*g_887)++) != ((safe_rshift_func_int16_t_s_s((&g_1580 != (void*)0), ((l_4062[2] = ((safe_rshift_func_int8_t_s_u(((g_620.f1 = (safe_lshift_func_int8_t_s_s(((((((safe_mod_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((safe_mod_func_int8_t_s_s(((safe_sub_func_int64_t_s_s((((*l_4061) = (255UL == (safe_rshift_func_uint32_t_u_u((0xAE11E7A1L && (safe_div_func_int8_t_s_s((safe_add_func_int64_t_s_s(((l_4060 = ((+(safe_add_func_uint16_t_u_u(p_3, (((((++(*l_4000)) < ((l_3884 = (l_4021 ^= ((p_4 , l_4049) == l_4050[0][0][3]))) , (safe_sub_func_uint8_t_u_u(((*l_4059) = (((((safe_mod_func_uint16_t_u_u(((l_4021 = 0L) != p_3), (-1L))) < l_4055) , l_4056) , l_4057) && l_4003[3][6])), l_3761)))) | l_4003[2][0]) && p_6) >= p_3)))) > 1UL)) <= 0xF4E9L), 0xC2EA628DC83FF992LL)), p_3))), 31)))) & l_4001), l_3888[2])) & 0x165BL), g_1195.f0)), p_5)), p_6)) & 0UL) ^ (-1L)) , l_3876) > p_3) == p_6), g_1538))) , p_4), 6)) , p_4)) <= p_4))) | 1L));
                    }
                    if (p_5)
                        break;
                }
                else
                { /* block id: 1710 */
                    int32_t l_4079 = 0x8D4448DCL;
                    uint32_t *l_4080[7][5] = {{&g_2327.f1,&g_2327.f1,&g_2599.f1,&g_2327.f1,&g_2327.f1},{&g_2327.f1,(void*)0,&g_2327.f1,&g_2327.f1,(void*)0},{&g_2327.f1,&g_3692.f1,&g_3692.f1,&g_2327.f1,&g_3692.f1},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_3692.f1,&g_2327.f1,&g_3692.f1,&g_3692.f1,&g_2327.f1},{(void*)0,&g_2327.f1,&g_2327.f1,(void*)0,&g_2327.f1},{&g_2327.f1,&g_2327.f1,&g_2599.f1,&g_2327.f1,&g_2327.f1}};
                    int i, j;
                    (*g_383) = &l_3699[3][7];
                    l_3879 |= ((safe_lshift_func_uint32_t_u_s((safe_rshift_func_uint8_t_u_s(p_3, 6)), 16)) == ((l_4083 ^= ((safe_mul_func_int32_t_s_s((safe_mul_func_int64_t_s_s(p_4, l_3851)), ((((-9L) ^ ((((l_4079 = ((safe_add_func_int16_t_s_s(g_2301.f0, ((safe_rshift_func_int64_t_s_s(1L, 19)) , (((p_4 > l_4078) || l_4003[2][0]) | l_4079)))) >= 1L)) , p_3) >= l_4081) <= p_5)) , &g_1458) == l_4082))) >= 8L)) > 1UL));
                    return l_4079;
                }
            }
            if (((safe_mul_func_int64_t_s_s((((*g_887) = ((l_3949 , (l_3761 = (((l_3886[6] && l_4078) < ((**g_3986) ^= (safe_mul_func_uint8_t_u_u(l_3851, (((safe_lshift_func_int64_t_s_u(0x3BA96A48860006E0LL, ((void*)0 != l_4090[2][0]))) & (((((l_3879 = (l_4091[3] == (*l_3989))) , l_4092) < p_6) || g_1342.f0) < p_4)) == l_4093[4]))))) , l_3760))) > 0x42E4F15AL)) && p_3), 1L)) & l_4094))
            { /* block id: 1722 */
                int64_t ***l_4097 = &l_3989;
                int64_t ****l_4098 = &g_1228[2][6][3];
                int32_t l_4099[10][10][1] = {{{0xDFE936BEL},{(-1L)},{0L},{0xDA6C2E3AL},{4L},{0x509CB0BEL},{0x3AAF5BFBL},{0x00955205L},{0x3AAF5BFBL},{0x509CB0BEL}},{{4L},{0xDA6C2E3AL},{0L},{(-1L)},{0xDFE936BEL},{1L},{0xB101EB64L},{0x00955205L},{0x8BBD1883L},{0x3086335CL}},{{7L},{5L},{0L},{(-1L)},{5L},{0L},{6L},{0x00955205L},{1L},{(-1L)}},{{0x00CE3D97L},{0xA60813C2L},{0L},{0xA60813C2L},{0x00CE3D97L},{(-1L)},{1L},{0x00955205L},{6L},{0L}},{{5L},{(-1L)},{0L},{5L},{7L},{0x3086335CL},{0x8BBD1883L},{0x00955205L},{0xB101EB64L},{1L}},{{0xDFE936BEL},{(-1L)},{0L},{0xDA6C2E3AL},{4L},{0x509CB0BEL},{0x3AAF5BFBL},{0x00955205L},{0x3AAF5BFBL},{0x509CB0BEL}},{{4L},{0xDA6C2E3AL},{0L},{(-1L)},{0xDFE936BEL},{1L},{0xB101EB64L},{0x00955205L},{0x8BBD1883L},{0x3086335CL}},{{7L},{5L},{0L},{(-1L)},{5L},{0L},{6L},{0x00955205L},{1L},{(-1L)}},{{0x00CE3D97L},{0xA60813C2L},{0L},{0xA60813C2L},{0x00CE3D97L},{(-1L)},{1L},{0x00955205L},{6L},{0L}},{{5L},{(-1L)},{0L},{5L},{7L},{0x3086335CL},{0x8BBD1883L},{0x00955205L},{0xB101EB64L},{1L}}};
                int32_t l_4100 = 0x45487972L;
                uint32_t l_4101 = 0xF402BE2FL;
                int i, j, k;
                l_4100 = (l_4099[4][0][0] = (safe_sub_func_int16_t_s_s(((l_4097 = (void*)0) == ((*l_4098) = (void*)0)), p_6)));
                if (p_5)
                    break;
                ++l_4101;
            }
            else
            { /* block id: 1729 */
                uint16_t *l_4121 = &g_137;
                const int32_t l_4123 = 0x51F4A1ABL;
                int32_t l_4124[3][10][5] = {{{0xC2E3979DL,0xE08A84A0L,0xAF792179L,0xE08A84A0L,0xC2E3979DL},{(-6L),0x6E27DFDEL,0x1000BAF3L,0xDF497A84L,0x6E27DFDEL},{0xC2E3979DL,0x1000BAF3L,0x1000BAF3L,0xC2E3979DL,0xDF497A84L},{0xE08A84A0L,0xC2E3979DL,0xAF792179L,0x6E27DFDEL,0x6E27DFDEL},{(-6L),0xC2E3979DL,(-6L),0xDF497A84L,0xC2E3979DL},{0x6E27DFDEL,0x1000BAF3L,0xDF497A84L,0x6E27DFDEL,0xDF497A84L},{0x6E27DFDEL,0x6E27DFDEL,0xAF792179L,0xC2E3979DL,0xE08A84A0L},{(-6L),0xE08A84A0L,0xDF497A84L,0xDF497A84L,0xE08A84A0L},{0xE08A84A0L,0x1000BAF3L,(-6L),0xE08A84A0L,0xDF497A84L},{0x1000BAF3L,0xDF497A84L,0x6E27DFDEL,0xDF497A84L,0x1000BAF3L}},{{0x0286F3A6L,(-6L),0xAF792179L,0x7338D581L,(-6L)},{0x1000BAF3L,0xAF792179L,0xAF792179L,0x1000BAF3L,0x7338D581L},{0xDF497A84L,0x1000BAF3L,0x6E27DFDEL,(-6L),(-6L)},{0x0286F3A6L,0x1000BAF3L,0x0286F3A6L,0x7338D581L,0x1000BAF3L},{(-6L),0xAF792179L,0x7338D581L,(-6L),0x7338D581L},{(-6L),(-6L),0x6E27DFDEL,0x1000BAF3L,0xDF497A84L},{0x0286F3A6L,0xDF497A84L,0x7338D581L,0x7338D581L,0xDF497A84L},{0xDF497A84L,0xAF792179L,0x0286F3A6L,0xDF497A84L,0x7338D581L},{0x1000BAF3L,0xDF497A84L,0x6E27DFDEL,0xDF497A84L,0x1000BAF3L},{0x0286F3A6L,(-6L),0xAF792179L,0x7338D581L,(-6L)}},{{0x1000BAF3L,0xAF792179L,0xAF792179L,0x1000BAF3L,0x7338D581L},{0xDF497A84L,0x1000BAF3L,0x6E27DFDEL,(-6L),(-6L)},{0x0286F3A6L,0x1000BAF3L,0x0286F3A6L,0x7338D581L,0x1000BAF3L},{(-6L),0xAF792179L,0x7338D581L,(-6L),0x7338D581L},{(-6L),(-6L),0x6E27DFDEL,0x1000BAF3L,0xDF497A84L},{0x0286F3A6L,0xDF497A84L,0x7338D581L,0x7338D581L,0xDF497A84L},{0xDF497A84L,0xAF792179L,0x0286F3A6L,0xDF497A84L,0x7338D581L},{0x1000BAF3L,0xDF497A84L,0x6E27DFDEL,0xDF497A84L,0x1000BAF3L},{0x0286F3A6L,(-6L),0xAF792179L,0x7338D581L,(-6L)},{0x1000BAF3L,0xAF792179L,0xAF792179L,0x1000BAF3L,0x7338D581L}}};
                int8_t l_4144 = (-9L);
                int i, j, k;
                for (g_3207 = 3; (g_3207 >= 0); g_3207 -= 1)
                { /* block id: 1732 */
                    int32_t l_4119[7][6] = {{(-1L),0xFE2CCF58L,0x014EFC71L,0x014EFC71L,0xFE2CCF58L,(-1L)},{0x014EFC71L,0xFE2CCF58L,(-1L),(-7L),0xBA8A7E8BL,2L},{2L,0xB4499C77L,0xBA5493A5L,0xB4499C77L,2L,0xFE2CCF58L},{2L,0x014EFC71L,0xB4499C77L,(-7L),0x911ACA8BL,0x911ACA8BL},{0x014EFC71L,0xBA8A7E8BL,0xBA8A7E8BL,0x014EFC71L,0xBA5493A5L,0x911ACA8BL},{(-1L),0x911ACA8BL,0xB4499C77L,0xFE2CCF58L,(-7L),0xFE2CCF58L},{0xBA5493A5L,3L,0xBA5493A5L,0x460DEEA3L,(-7L),2L}};
                    int32_t l_4127[5][3] = {{(-1L),9L,(-9L)},{9L,(-1L),(-1L)},{(-9L),(-1L),0x17D3E822L},{0L,9L,5L},{(-9L),(-9L),5L}};
                    int i, j;
                    l_4124[1][9][2] |= (safe_mod_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(((l_4078 , ((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(p_4, 6)), ((18446744073709551615UL | 3L) , (safe_mul_func_int8_t_s_s((safe_rshift_func_int8_t_s_s(((p_5 >= ((safe_add_func_uint8_t_u_u((+((l_4119[6][3] > (l_4119[2][4] & (+((void*)0 != l_4121)))) > l_4122[7])), 0x6CL)) ^ l_4119[0][3])) <= p_6), p_6)), l_4123))))) | p_3)) < 0x66C79A83L), l_4123)), l_4123));
                    for (l_3876 = 0; (l_3876 <= 4); l_3876 += 1)
                    { /* block id: 1736 */
                        l_3884 ^= (l_3761 = ((+(l_4127[1][2] ^= (safe_unary_minus_func_int64_t_s(l_4119[1][5])))) == p_5));
                    }
                }
                if (l_4094)
                    break;
                (****g_1242) = &l_3699[1][1];
                for (g_3207 = 0; (g_3207 <= 4); g_3207 += 1)
                { /* block id: 1746 */
                    int32_t l_4143 = 2L;
                    for (g_3217.f1 = 0; (g_3217.f1 <= 4); g_3217.f1 += 1)
                    { /* block id: 1749 */
                        int i, j;
                        l_4124[1][9][2] ^= (((safe_unary_minus_func_int64_t_s(((safe_mul_func_uint8_t_u_u(g_56[g_3207], (safe_lshift_func_int16_t_s_u((g_4133 , (safe_rshift_func_uint64_t_u_s(((void*)0 == &g_361), 51))), (((safe_add_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u((l_3699[g_3207][(g_3217.f1 + 1)] , (((p_5 , p_3) && (safe_rshift_func_uint8_t_u_s((g_4142 > 0x8C6EL), 2))) , p_4)), 14)), 0L)) & l_4143) & l_3761))))) , l_4144))) < 1L) == p_4);
                    }
                    for (g_3033 = 0; (g_3033 <= 4); g_3033 += 1)
                    { /* block id: 1754 */
                        uint16_t l_4168 = 0xED54L;
                        int32_t l_4169 = 6L;
                        int i;
                        l_4169 = (g_4145 , (safe_lshift_func_uint8_t_u_s(0xCFL, (p_4 & (safe_mod_func_uint8_t_u_u((((((p_3 >= ((((void*)0 == (***g_588)) && ((safe_mul_func_int8_t_s_s((((g_56[g_82] = ((safe_mul_func_int64_t_s_s((l_4143 != (safe_sub_func_int16_t_s_s(((safe_sub_func_int32_t_s_s(((((safe_add_func_uint64_t_u_u((safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u((g_2629 , (+(safe_mul_func_uint64_t_u_u(l_4168, l_4168)))))), 65534UL)), l_4168)), l_4143)) && p_3) == p_4) || p_6), 0x85642B86L)) && p_3), 1UL))), 0UL)) | p_3)) & p_4) && p_6), p_3)) < l_3879)) & p_5)) < p_3) != p_4) & g_1690.f2) == l_4122[6]), g_1879.f1))))));
                        return p_5;
                    }
                }
            }
        }
        for (l_3936 = 1; (l_3936 <= 4); l_3936 += 1)
        { /* block id: 1764 */
            uint8_t l_4181 = 253UL;
            int32_t l_4195 = (-6L);
            int32_t l_4214 = 0x5677DB30L;
            int32_t l_4216 = 0x43B8F344L;
            int32_t l_4219 = 2L;
            int32_t l_4221 = 0x9D3C4D2AL;
            int32_t l_4223 = 0xFBCFDD99L;
            int32_t l_4225 = (-7L);
            int32_t l_4226 = (-1L);
            int32_t l_4227[10][1][2];
            int32_t *l_4236 = &g_103;
            int32_t l_4268 = 0x4B1E1DA7L;
            union U2 * volatile l_4273[2][1][2];
            int i, j, k;
            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 2; k++)
                        l_4227[i][j][k] = 0xA821B95DL;
                }
            }
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 2; k++)
                        l_4273[i][j][k] = &g_4274;
                }
            }
            for (g_1059.f2 = 0; (g_1059.f2 <= 4); g_1059.f2 += 1)
            { /* block id: 1767 */
                int32_t *l_4197[9];
                uint32_t l_4231 = 0xF4E3BD7DL;
                union U1 ** volatile *l_4235 = &g_1351;
                union U1 ** volatile **l_4234 = &l_4235;
                int i;
                for (i = 0; i < 9; i++)
                    l_4197[i] = (void*)0;
                for (g_3748.f2 = 0; (g_3748.f2 <= 4); g_3748.f2 += 1)
                { /* block id: 1770 */
                    int8_t l_4180 = 0x25L;
                    int16_t *l_4183 = &g_1253[0][2][6];
                    uint64_t *l_4189 = &g_1687;
                    uint64_t *l_4190 = &g_1538;
                    uint64_t l_4194 = 18446744073709551615UL;
                    struct S0 **l_4196 = &g_1144;
                    uint32_t ***l_4207 = (void*)0;
                    int32_t l_4212 = (-6L);
                    int32_t l_4215[4] = {5L,5L,5L,5L};
                    int32_t l_4228 = 0x6EFC7179L;
                    int i;
                    if (((l_4170 != (void*)0) || ((safe_mul_func_int64_t_s_s(((*g_609) = (safe_mod_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((!((((safe_add_func_uint64_t_u_u(((l_4180 <= l_4181) >= ((*g_887) = (((l_4195 = (((safe_unary_minus_func_int16_t_s(((*l_4183) = ((*l_3804) |= p_6)))) == (g_4184 , p_4)) , ((safe_rshift_func_uint64_t_u_u(((*l_4190) = ((*l_4189) = p_6)), 35)) < ((((safe_mod_func_uint16_t_u_u(((*l_3783) != l_4193), (*g_887))) > p_3) || 0x6CBDL) == l_4194)))) , l_4196) == l_4170))), 5UL)) ^ (*g_805)) & 1UL) < 0xA4L)) , 0xF98C019427022D3BLL), p_5)), (-1L)))), l_4181)) , 9L)))
                    { /* block id: 1778 */
                        (***g_1243) = &l_4195;
                        (*g_383) = l_4197[5];
                        if (p_3)
                            break;
                    }
                    else
                    { /* block id: 1782 */
                        uint64_t l_4198[9] = {0x730D59BCE1111236LL,0xAF5B91466E0B1FDELL,0xAF5B91466E0B1FDELL,0x730D59BCE1111236LL,0xAF5B91466E0B1FDELL,0xAF5B91466E0B1FDELL,0x730D59BCE1111236LL,0xAF5B91466E0B1FDELL,0xAF5B91466E0B1FDELL};
                        int32_t l_4199 = 4L;
                        uint8_t l_4200 = 255UL;
                        int32_t l_4213 = 0L;
                        int32_t l_4217[8];
                        int8_t l_4218 = 0xC7L;
                        int32_t l_4224 = 1L;
                        int i;
                        for (i = 0; i < 8; i++)
                            l_4217[i] = 0L;
                        l_4198[7] = p_5;
                        l_4199 &= l_4198[6];
                        l_4212 &= ((((++l_4200) && ((safe_mod_func_uint16_t_u_u((0xD8L > (((l_4207 == &l_3855) < (((**g_3986) = 0x2B34E314DBE92475LL) > ((0x52L & l_4194) | (((*l_4000) = 0xB2L) & (((*g_887) ^= ((l_4195 ^= (safe_mul_func_int32_t_s_s(((p_5 ^ ((safe_mul_func_uint32_t_u_u(p_6, p_6)) >= (-6L))) && 248UL), p_3))) , p_6)) != l_4194))))) | p_4)), 5UL)) == p_5)) || (*g_2363)) || p_4);
                        ++l_4231;
                    }
                }
                (*l_4234) = &g_1351;
            }
            for (g_1412.f2 = 0; (g_1412.f2 <= 4); g_1412.f2 += 1)
            { /* block id: 1814 */
                int32_t l_4281 = 0x788BE3FEL;
                l_3882 |= (((safe_mul_func_int64_t_s_s((safe_lshift_func_int8_t_s_s(((((((*l_4236) != 0x5EBCC9911B011C77LL) & 8L) , (safe_div_func_uint64_t_u_u(l_4281, ((p_3 , p_5) , ((**l_3989) = (g_4282 , p_3)))))) <= (p_3 != p_4)) ^ l_4281), 4)), 0UL)) , l_4283) ^ p_6);
            }
        }
        l_4293 = ((*l_3989) != (((*g_4248) && (l_4284 & ((((safe_mod_func_uint16_t_u_u(l_4287[4][1][0], p_4)) != (-6L)) == (((*l_3804) = 2L) , (safe_mod_func_int16_t_s_s((g_4290 , (safe_lshift_func_int16_t_s_s((0L == (*g_1101)), p_6))), 1UL)))) , g_917.f3))) , (void*)0));
        for (l_3843 = 0; (l_3843 <= 3); l_3843 += 1)
        { /* block id: 1823 */
            union U1 *l_4294 = &g_3933;
            int32_t l_4300 = 0L;
            uint64_t *l_4301 = &l_4287[4][1][0];
            int32_t l_4308 = 1L;
            int32_t l_4310[3][2];
            int32_t l_4311 = (-1L);
            int8_t l_4322 = 1L;
            uint64_t l_4327 = 0UL;
            uint16_t l_4355 = 65532UL;
            const uint32_t **l_4357 = &g_485;
            int32_t **l_4366 = &g_112[5];
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 2; j++)
                    l_4310[i][j] = 0x9F95C795L;
            }
            if (p_5)
                break;
            (*g_1351) = l_4294;
            l_4311 |= (safe_mod_func_uint8_t_u_u(((((252UL ^ (((*l_4301) = (((((*l_4246) ^= (((g_4297 , p_6) ^ (p_6 > (safe_add_func_int8_t_s_s(p_6, (((*g_887) ^= (l_4300 = 0xF1B2L)) ^ (((l_4301 != ((safe_lshift_func_uint8_t_u_u(0x9EL, (l_4308 = (safe_lshift_func_uint8_t_u_u((safe_mul_func_uint64_t_u_u(4UL, 0xF7ED305FA5C55A6DLL)), l_4308))))) , l_4309)) , 1L) > (*g_4248))))))) & l_4310[0][0])) , 1L) && 0xC845L) | 1L)) <= p_6)) >= 4294967295UL) , 7L) < l_4310[0][0]), p_6));
            for (g_3940.f1 = 0; (g_3940.f1 <= 4); g_3940.f1 += 1)
            { /* block id: 1834 */
                int32_t *l_4312 = &l_3699[0][1];
                int32_t l_4316 = 0x93E56EBDL;
                int32_t l_4317 = 0x9501C377L;
                int32_t l_4318 = 0L;
                int32_t l_4323 = 0x9FE580B1L;
                int32_t l_4324 = 9L;
                for (l_3851 = 0; (l_3851 <= 4); l_3851 += 1)
                { /* block id: 1837 */
                    uint16_t l_4314 = 1UL;
                    int32_t l_4315 = (-6L);
                    int32_t l_4319 = 0x42D73247L;
                    int32_t l_4320 = 6L;
                    int32_t l_4321 = 0x1B0531F4L;
                    int32_t l_4326 = 0xDE669C7BL;
                    (*g_383) = l_4312;
                    l_4314 = (((void*)0 == &l_3706[2][0][2]) && (((*g_2540) = (l_4308 , g_4313)) == (void*)0));
                    for (l_4229 = 0; (l_4229 <= 1); l_4229 += 1)
                    { /* block id: 1843 */
                        int i, j;
                        return l_4310[l_4229][l_4229];
                    }
                    --l_4327;
                }
                l_4310[0][0] = (safe_add_func_uint32_t_u_u(((safe_rshift_func_int8_t_s_u(((safe_rshift_func_int64_t_s_s((safe_mod_func_int64_t_s_s((safe_add_func_uint64_t_u_u((l_4340 && (safe_add_func_int64_t_s_s(0xBA03617F2254E2F4LL, ((((*l_4312) = ((*g_609) ^ ((~(safe_mod_func_uint16_t_u_u(((5L ^ (safe_add_func_int8_t_s_s(4L, (*l_4312)))) | (((p_6 = ((safe_mul_func_uint8_t_u_u(l_4350, (safe_sub_func_uint64_t_u_u(((l_4327 > (safe_sub_func_int16_t_s_s((p_6 < p_5), p_6))) || l_4355), 0x6EB6EA5EBC05423ALL)))) > 0x9FA69316ED792735LL)) , l_4356) != l_4357)), p_5))) ^ p_4))) != l_4310[2][0]) , p_3)))), l_4358[7])), p_5)), p_5)) , (**g_4247)), 6)) && l_4359[7]), p_3));
            }
            for (g_1816.f1 = 1; (g_1816.f1 <= 4); g_1816.f1 += 1)
            { /* block id: 1854 */
                uint64_t l_4373[6][8] = {{0xAACB7B1F47291F4ELL,0xE64C09CA098B23FDLL,0UL,0UL,0xE64C09CA098B23FDLL,0xAACB7B1F47291F4ELL,0x7F3EB5AF86F4B8EALL,0xD49A998834DC64E5LL},{1UL,1UL,9UL,0x7F3EB5AF86F4B8EALL,0xD2ECAC81F49E84E6LL,1UL,18446744073709551615UL,0x68356E7F1324776CLL},{0xCCE724BCA566DC81LL,1UL,0x7F3EB5AF86F4B8EALL,0xF4F49C8ED147287FLL,8UL,0xF4F49C8ED147287FLL,0x7F3EB5AF86F4B8EALL,1UL},{0x68356E7F1324776CLL,8UL,0UL,1UL,9UL,1UL,0xCCE724BCA566DC81LL,0xE96E200CB1E2F852LL},{1UL,0xAACB7B1F47291F4ELL,1UL,0UL,0x68356E7F1324776CLL,0xCCE724BCA566DC81LL,0xCCE724BCA566DC81LL,0x68356E7F1324776CLL},{1UL,0UL,0UL,1UL,1UL,9UL,0x7F3EB5AF86F4B8EALL,0xD2ECAC81F49E84E6LL}};
                int32_t l_4374 = 0xF203C2ECL;
                int32_t l_4375 = 0x5AF5AF13L;
                int i, j;
                l_4375 &= (((*l_4000) = (safe_sub_func_int32_t_s_s(l_4220, (g_1798[0] , (l_4374 = (safe_mod_func_int32_t_s_s(((g_4364 , ((+(l_4366 == &l_3968[6][1][4])) | (safe_mul_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(p_3, p_6)), (safe_mod_func_int32_t_s_s((((p_5 & 0x47C92CC1L) != g_3692.f1) && p_4), l_4373[4][4])))))) && p_6), p_5))))))) == p_3);
            }
        }
        for (g_1459.f1 = 1; (g_1459.f1 <= 4); g_1459.f1 += 1)
        { /* block id: 1862 */
            uint8_t l_4376 = 1UL;
            uint8_t l_4379 = 0x92L;
            int32_t l_4430 = 1L;
            int32_t l_4432[9][8] = {{0x9431AA63L,0xFB2496E7L,0x08B1CBB4L,0x9431AA63L,0x08B1CBB4L,0xFB2496E7L,0x9431AA63L,(-5L)},{0x66DFA885L,0x46B5924FL,0xF75CD230L,0x9431AA63L,0x9431AA63L,0xF75CD230L,0x46B5924FL,0x66DFA885L},{(-5L),0x9431AA63L,0xFB2496E7L,0x08B1CBB4L,0x9431AA63L,0x08B1CBB4L,0xFB2496E7L,0x9431AA63L},{0x66DFA885L,0xFB2496E7L,(-5L),0x66DFA885L,0x08B1CBB4L,0x08B1CBB4L,0x66DFA885L,(-5L)},{0x9431AA63L,0x9431AA63L,0xF75CD230L,0x46B5924FL,0x66DFA885L,0xF75CD230L,0x66DFA885L,0x46B5924FL},{(-5L),0x46B5924FL,(-5L),0x08B1CBB4L,0x46B5924FL,0xFB2496E7L,0xFB2496E7L,0x46B5924FL},{0x46B5924FL,0xFB2496E7L,0xFB2496E7L,0x46B5924FL,0x08B1CBB4L,(-5L),0x46B5924FL,(-5L)},{0x46B5924FL,0x66DFA885L,0xF75CD230L,0x66DFA885L,0x46B5924FL,0xF75CD230L,0x9431AA63L,0x9431AA63L},{(-5L),0x66DFA885L,0x08B1CBB4L,0x08B1CBB4L,0x66DFA885L,(-5L),0xFB2496E7L,0x66DFA885L}};
            const struct S0 *l_4442[3];
            int i, j;
            for (i = 0; i < 3; i++)
                l_4442[i] = &g_3584;
            l_4376--;
            if (l_4379)
                break;
            for (g_4274.f1 = 0; (g_4274.f1 <= 4); g_4274.f1 += 1)
            { /* block id: 1867 */
                uint64_t l_4429[9][6] = {{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL},{0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL,0x3CEE95F5B1743C07LL}};
                const struct S0 *l_4440 = &g_2885;
                int i, j;
                if ((safe_div_func_int8_t_s_s(((l_4379 < 18446744073709551615UL) , (safe_mul_func_int64_t_s_s((safe_add_func_uint16_t_u_u((((*g_887) = 0UL) ^ l_4379), (5UL < ((*l_4000) = (safe_add_func_uint32_t_u_u(((((safe_sub_func_int8_t_s_s((safe_add_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((g_4394 , 0xC2L), 5)), p_6)), (safe_mul_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(((safe_add_func_uint64_t_u_u(p_6, p_5)) == 0x2BECL), p_6)), p_6)))) > p_4) , &g_3408) == &p_3), l_4379)))))), 0x8AC9FAC7718B64A7LL))), 0x05L)))
                { /* block id: 1870 */
                    union U1 **l_4408[4][2][2] = {{{&g_1352,&g_1352},{&g_1352,&g_1352}},{{&g_1352,&g_1352},{&g_1352,&g_1352}},{{&g_1352,&g_1352},{&g_1352,&g_1352}},{{&g_1352,&g_1352},{&g_1352,&g_1352}}};
                    union U1 ***l_4407 = &l_4408[1][0][1];
                    union U1 ****l_4406 = &l_4407;
                    union U1 *****l_4405 = &l_4406;
                    uint64_t *l_4431[5] = {&l_4284,&l_4284,&l_4284,&l_4284,&l_4284};
                    int32_t l_4444 = 0x990B08B0L;
                    int i, j, k;
                    if (((l_3882 &= ((safe_add_func_uint32_t_u_u((((safe_sub_func_uint8_t_u_u((l_4405 != (g_4413 = l_4409)), ((safe_mul_func_uint64_t_u_u((l_4432[8][7] &= (l_4430 = ((safe_lshift_func_int64_t_s_s((p_6 = ((*g_609) = (safe_mod_func_int32_t_s_s((safe_add_func_int64_t_s_s(((((safe_sub_func_int64_t_s_s(p_5, ((18446744073709551615UL > (**g_1100)) ^ (((*l_4049) &= p_5) & ((*l_4261) != (g_2479[4][2] , (*g_4414))))))) , g_4428) , l_4429[7][1]) , 0x6411087EC5F8097BLL), l_4376)), 0xE379746DL)))), p_3)) ^ 0x603BE734L))), p_5)) | (*g_1101)))) <= (**g_4247)) , p_4), l_4376)) || l_4379)) & p_5))
                    { /* block id: 1878 */
                        int32_t *l_4433 = &l_3749;
                        int32_t *l_4441 = &l_4220;
                        (*g_383) = l_4433;
                        l_4430 = (safe_div_func_int16_t_s_s(((l_4429[4][2] , l_4436) ^ ((0L <= p_6) || ((((((((g_4437 , (safe_add_func_uint16_t_u_u(((((*g_2589) = l_4440) == (((*l_4441) ^= p_6) , l_4442[1])) , (g_4443[1] , l_4430)), p_5))) , (*l_4433)) , 9L) || (-1L)) || l_4444) | 0UL) != (*l_4433)) > 1L))), 1UL));
                    }
                    else
                    { /* block id: 1883 */
                        return l_4444;
                    }
                }
                else
                { /* block id: 1886 */
                    (***g_1243) = &l_4430;
                }
            }
        }
    }
    if ((l_3886[0] = (safe_lshift_func_int32_t_s_u(l_4447, (safe_mul_func_uint64_t_u_u(l_4122[1], (~(p_4 ^= (*g_4248)))))))))
    { /* block id: 1894 */
        int32_t l_4453 = (-9L);
        int32_t l_4454[4][9][7] = {{{2L,(-1L),0x6B28A486L,1L,0x38248ECBL,0x26D25772L,0x6FFD2F16L},{0x12AFBD09L,0x0D2264D6L,0x73AEEC9DL,(-3L),0L,(-1L),2L},{0x8CA5EA31L,(-1L),0x26D25772L,0x2C072C97L,0x4826449BL,(-3L),0x6B28A486L},{0x73A1E7BEL,(-8L),0L,(-1L),0xFF20CE95L,(-8L),0x38248ECBL},{(-8L),0xE33C8901L,(-1L),0x26D25772L,(-1L),0L,0L},{8L,8L,(-7L),(-4L),(-7L),0x73AEEC9DL,4L},{(-4L),8L,0x32849392L,0x0D2264D6L,0x198E18C8L,(-8L),8L},{(-3L),0xE33C8901L,0xFF20CE95L,0x2DF31852L,(-1L),0L,(-4L)},{0x12AFBD09L,(-8L),2L,(-2L),2L,(-8L),0x12AFBD09L}},{{1L,(-1L),0xFF2DC474L,0L,0x6D8A54C4L,0x834ACB66L,(-8L)},{8L,0x4826449BL,0x73AEEC9DL,0xB5EB85CDL,(-8L),8L,0x680B1F56L},{0xB27D3302L,0x198E18C8L,0xFF2DC474L,(-7L),0L,0xFF20CE95L,8L},{0x2DF31852L,0x26D25772L,2L,(-7L),0x32F2236DL,0x52E01F92L,0xB27D3302L},{0x38248ECBL,(-8L),0xFF20CE95L,(-1L),0L,(-8L),0x73A1E7BEL},{0xA2468CEDL,(-8L),0x32849392L,0x6B28A486L,0L,0xCB6419F0L,1L},{0x8CA5EA31L,0xD37826F0L,(-7L),0x6B28A486L,(-8L),(-3L),1L},{0L,4L,(-1L),(-1L),8L,0xB5EB85CDL,2L},{(-1L),0xE33C8901L,0L,(-7L),6L,(-7L),0L}},{{0x6D8A54C4L,0x6D8A54C4L,0x26D25772L,(-7L),(-7L),(-8L),(-8L)},{1L,0xFF20CE95L,0x32849392L,0xB5EB85CDL,(-8L),0x12AFBD09L,0xFF20CE95L},{(-3L),(-3L),8L,0L,(-7L),0L,0x680B1F56L},{(-8L),4L,0x83E8A688L,(-2L),6L,0xB27D3302L,0x4826449BL},{(-1L),(-1L),(-7L),0x2DF31852L,8L,0x52E01F92L,(-8L)},{0x6D8A54C4L,0x12AFBD09L,0xB5EB85CDL,0x0D2264D6L,(-8L),0x6D8A54C4L,1L},{(-8L),0xB5EB85CDL,0xFF2DC474L,(-4L),0L,0x6D8A54C4L,0xFF20CE95L},{0x2DF31852L,0L,1L,0x26D25772L,0L,0x52E01F92L,4L},{1L,0x198E18C8L,(-2L),(-1L),0x32F2236DL,0xB27D3302L,0x32F2236DL}},{{0x2C072C97L,(-8L),(-8L),0x2C072C97L,0L,0L,1L},{0x38248ECBL,0xCB6419F0L,0x26D25772L,3L,(-8L),0x12AFBD09L,0xFF20CE95L},{0xB5EB85CDL,(-1L),0x198E18C8L,0x52E01F92L,0x26D25772L,(-8L),0x2DF31852L},{(-7L),1L,0x0D2264D6L,(-1L),0x8CA5EA31L,(-10L),(-8L)},{(-7L),0L,4L,0xD37826F0L,(-1L),(-3L),1L},{(-1L),(-7L),0x2C072C97L,0x32849392L,0x12AFBD09L,3L,(-7L)},{0x6B28A486L,(-7L),(-7L),0x198E18C8L,1L,0xE33C8901L,(-1L)},{0x6B28A486L,(-1L),2L,(-7L),1L,(-4L),0x2C072C97L},{(-1L),0x834ACB66L,0x83E8A688L,0x73AEEC9DL,(-7L),0xFF2DC474L,0xA2468CEDL}}};
        int32_t l_4457 = 0xBEE59BB5L;
        int32_t l_4458 = 0x5EF31B35L;
        int32_t l_4459 = 0x96365170L;
        int32_t l_4460[10] = {1L,0x924959F0L,0x924959F0L,1L,0x924959F0L,0x924959F0L,1L,0x924959F0L,0x924959F0L,1L};
        uint32_t l_4461 = 4294967295UL;
        struct S0 *l_4487 = &g_3970[0];
        union U3 *l_4505 = &g_510;
        const int32_t l_4561 = 0xF6A31634L;
        uint64_t **l_4596 = (void*)0;
        int8_t l_4597 = 3L;
        int32_t *l_4641 = &g_103;
        int32_t *l_4643[4][5][5] = {{{&l_4457,&g_103,&l_4460[7],&l_4454[0][0][6],&l_4460[7]},{&l_4057,&l_4057,&g_2244,&l_4459,&g_103},{&l_4457,&l_4057,&l_3886[5],&l_4454[2][7][3],(void*)0},{&l_4459,(void*)0,&l_4459,&g_281,&l_4459},{&l_3886[5],&l_4057,&l_4457,&g_103,&l_4460[7]}},{{&g_2244,&l_4057,&l_4057,&g_2244,&l_4459},{&l_4460[7],&g_103,&l_4457,&l_4454[2][7][3],&l_3749},{&g_4142,&l_4454[2][7][3],&l_4459,&l_4454[2][7][3],&g_4142},{&l_3882,&g_103,&l_3886[5],&l_4454[2][7][3],&l_4458},{&l_4454[2][7][3],&g_4142,&g_2244,&g_2244,&g_4142}},{{(void*)0,&l_4057,&l_4460[7],&g_103,&l_4458},{&l_4454[2][7][3],&g_2244,&g_4142,&g_281,&g_4142},{&l_4458,&g_2244,&l_3882,&l_4454[2][7][3],&l_3749},{&l_4454[2][7][3],&g_103,&l_4454[2][7][3],&l_4459,&l_4459},{(void*)0,&l_4457,(void*)0,&l_4454[0][0][6],&l_4460[7]}},{{&l_4454[2][7][3],&g_103,&l_4454[2][7][3],&g_4142,&l_4459},{&l_3882,&g_2244,&l_4458,&g_103,(void*)0},{&g_4142,&g_2244,&l_4454[2][7][3],&l_4459,&g_103},{&l_4460[7],&l_4057,(void*)0,&l_4057,&l_4460[7]},{&g_2244,&g_4142,&l_4454[2][7][3],&l_4459,&l_4057}}};
        uint64_t *l_4650 = &g_49;
        const int32_t *l_4695 = &g_2244;
        uint64_t ***l_4701 = &l_4596;
        uint64_t ****l_4700 = &l_4701;
        int64_t l_4713 = 0xCC7C3635BF5A1B18LL;
        uint16_t l_4719 = 0x5D00L;
        struct S0 *l_4724 = &g_4725;
        union U1 **l_4733 = &g_1352;
        uint32_t *****l_4756 = &g_586[0];
        uint32_t l_4783 = 0xB91AD969L;
        int i, j, k;
        l_3886[8] = (safe_lshift_func_uint16_t_u_s(((p_5 , (l_4454[2][7][3] = l_4453)) > (safe_sub_func_int64_t_s_s(((--l_4461) & (l_4468[2] = (safe_lshift_func_uint32_t_u_s((safe_add_func_int32_t_s_s(p_3, p_4)), 24)))), 18446744073709551615UL))), (safe_div_func_uint64_t_u_u(((**g_4247) ^ p_3), p_5))));
        if ((**g_4020))
        { /* block id: 1899 */
            int32_t *l_4471[9];
            uint64_t l_4472[2][9] = {{0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL,0xEE336C1B1146DED3LL},{6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL}};
            struct S0 *l_4489 = &g_789;
            uint16_t ****l_4502 = &g_2542;
            int8_t l_4503 = (-1L);
            uint8_t **l_4544 = &l_4000;
            union U4 ***l_4548 = &l_4517;
            uint8_t l_4560 = 0x17L;
            int i, j;
            for (i = 0; i < 9; i++)
                l_4471[i] = (void*)0;
lbl_4506:
            l_4472[0][1]--;
            for (g_1635.f1 = 0; (g_1635.f1 > 19); g_1635.f1 = safe_add_func_uint8_t_u_u(g_1635.f1, 6))
            { /* block id: 1903 */
                uint16_t l_4492 = 0x9206L;
                union U4 **l_4514 = &l_3845[0][2];
                union U4 **l_4516[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                uint8_t **l_4545 = &g_933;
                union U4 ****l_4549 = &l_4548;
                union U4 ***l_4551[10][2][5] = {{{&l_4514,(void*)0,&l_4516[1],(void*)0,&l_4514},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}},{{(void*)0,&l_4516[0],(void*)0,&l_4516[0],(void*)0},{&l_4517,&l_4514,&l_4517,&l_4514,&l_4517}}};
                union U4 ****l_4550 = &l_4551[4][1][4];
                int32_t l_4562 = 8L;
                int32_t l_4565[8][9] = {{8L,6L,0x88AC7112L,0x97485CFDL,0x7274C8D8L,0x2C871061L,0x2C871061L,0x7274C8D8L,0x97485CFDL},{0xF67D229AL,(-1L),0xF67D229AL,0x831EC180L,0xEAAA2163L,(-4L),6L,6L,(-4L)},{0x88AC7112L,6L,8L,6L,0x88AC7112L,0x97485CFDL,0x7274C8D8L,0x2C871061L,0x2C871061L},{0xCF286B38L,0x593A5679L,(-4L),0x831EC180L,(-4L),0x593A5679L,0xCF286B38L,0xEAAA2163L,1L},{0xFD34D951L,5L,6L,0x97485CFDL,(-1L),0x97485CFDL,6L,5L,0xFD34D951L},{0x593A5679L,0xCFC5964FL,6L,0xEAAA2163L,0xD63285A2L,(-4L),0xD63285A2L,0xEAAA2163L,6L},{0x7274C8D8L,0x7274C8D8L,0xC748E5CCL,8L,5L,0x2C871061L,0xFD34D951L,0x2C871061L,5L},{0x593A5679L,0xD63285A2L,0xD63285A2L,0x593A5679L,0xF67D229AL,1L,0x831EC180L,6L,0x831EC180L}};
                int i, j, k;
                for (g_3940.f1 = (-1); (g_3940.f1 < (-14)); g_3940.f1 = safe_sub_func_int32_t_s_s(g_3940.f1, 2))
                { /* block id: 1906 */
                    uint32_t l_4493 = 0xC8D03129L;
                    uint8_t **l_4497 = (void*)0;
                    int32_t l_4531 = 1L;
                    if ((safe_rshift_func_int8_t_s_u(((**l_4245) = ((((safe_mod_func_int16_t_s_s((safe_mod_func_int64_t_s_s((((p_6 ^ ((((**g_3986) = (-5L)) <= 0L) | (safe_lshift_func_uint32_t_u_u((l_4487 == (g_4488 , l_4489)), l_4458)))) > (g_1652.f1 <= (safe_rshift_func_uint32_t_u_s((g_2769 , p_3), (*g_805))))) & 0x93FE5E98597EDBB1LL), l_4492)), g_1879.f2)) <= l_4493) < p_4) ^ p_4)), 3)))
                    { /* block id: 1909 */
                        l_4503 = (((*l_4246) ^= (~(0UL > ((*g_887)--)))) > (((void*)0 != l_4497) != ((safe_lshift_func_int16_t_s_u(((*l_3804) |= ((safe_mul_func_uint32_t_u_u(0UL, 4294967292UL)) >= l_4460[0])), 2)) , ((((*g_2540) = (*g_2540)) != (g_3692 , l_4502)) >= 4294967286UL))));
                        l_4460[5] = l_4504;
                        (*g_3118) = l_4505;
                        if (g_3207)
                            goto lbl_4506;
                    }
                    else
                    { /* block id: 1918 */
                        int32_t *l_4507 = &l_3886[5];
                        union U4 ***l_4515[9][4] = {{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514},{&l_4514,&l_4514,&l_4514,&l_4514}};
                        int i, j;
                        (*g_4416) = (***g_4414);
                        (*g_383) = l_4507;
                        l_4458 = (safe_sub_func_int8_t_s_s(((((safe_mod_func_uint32_t_u_u((l_4457 ^= (!9UL)), ((*l_4507) |= ((g_4513 , ((l_4514 = l_4514) == (l_4517 = l_4516[4]))) >= p_5)))) , (safe_mod_func_uint16_t_u_u(((safe_mod_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(p_4, (safe_sub_func_int16_t_s_s(((*l_3804) = 0x44F4L), (safe_mul_func_uint16_t_u_u(g_4528, (safe_sub_func_int64_t_s_s(((p_6 > (-1L)) >= 0x8ECF0303L), (**g_3986))))))))), (*l_4507))) >= 0x5E78482419879306LL), 0x2901L))) && p_4) || 0xE9AF762445D952B6LL), (*g_4248)));
                        l_4531 = 0x40FB1418L;
                    }
                }
                l_4565[7][3] = ((((safe_div_func_int16_t_s_s((safe_sub_func_int16_t_s_s(g_776.f0, (safe_div_func_int8_t_s_s((safe_mod_func_int32_t_s_s((safe_div_func_int32_t_s_s(((((safe_rshift_func_int8_t_s_u(0xA1L, (((l_4544 != (p_4 , (l_4545 = (*g_1053)))) && ((((+(+(((*l_4550) = ((*l_4549) = l_4548)) == ((safe_sub_func_int16_t_s_s((((-4L) < (safe_rshift_func_uint8_t_u_s(((l_4562 = (l_4460[7] = (safe_div_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_s(((l_4560 ^ 0x12L) | l_4561), p_3)) | 0x7947BA05L), 1L)))) >= p_5), (**g_4247)))) != (-1L)), 0xB1D5L)) , g_4563)))) & l_4492) && (-4L)) & g_2885.f3)) , 0xCEL))) && l_4492) ^ 0xD0CCL) , 0x3471B744L), 1L)), p_6)), l_4461)))), (-9L))) , (-10L)) | l_4453) && p_6);
            }
            l_4460[7] = (-10L);
            return p_5;
        }
        else
        { /* block id: 1939 */
            int32_t *l_4566[8][7] = {{&g_2244,(void*)0,(void*)0,&l_4458,(void*)0,(void*)0,&g_2244},{(void*)0,&g_2244,(void*)0,&g_4142,(void*)0,&g_2244,(void*)0},{&g_2244,(void*)0,(void*)0,&l_4458,(void*)0,(void*)0,&g_2244},{(void*)0,&g_2244,(void*)0,&g_4142,(void*)0,&g_2244,(void*)0},{&g_2244,(void*)0,(void*)0,&l_4458,(void*)0,(void*)0,&g_2244},{(void*)0,&g_2244,(void*)0,&g_4142,(void*)0,&g_2244,(void*)0},{&g_2244,(void*)0,(void*)0,&l_4458,(void*)0,(void*)0,&g_2244},{(void*)0,&g_2244,(void*)0,&g_4142,(void*)0,&g_2244,(void*)0}};
            uint8_t l_4567 = 1UL;
            int i, j;
            l_4567++;
        }
lbl_4761:
        if (((((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint32_t_u_u((safe_div_func_uint8_t_u_u(l_4453, ((safe_lshift_func_int16_t_s_s(l_4325, 13)) & (safe_sub_func_int64_t_s_s((((*g_887) &= 0UL) & (g_4580[0] , (safe_sub_func_uint16_t_u_u(l_4458, ((safe_mul_func_int64_t_s_s((p_6 < (l_4460[6] & (safe_sub_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((g_4589[0] , (safe_add_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((safe_div_func_int8_t_s_s(((&l_4309 == l_4596) & p_6), 0xA4L)), l_4597)), p_5))), p_4)), 0xB6D9L)))), (**g_1100))) != l_4460[7]))))), 18446744073709551613UL))))), 14)), l_4461)) >= p_3) && 0x400D5EB44682095CLL) != p_3))
        { /* block id: 1943 */
            uint64_t l_4609[3][10][7] = {{{18446744073709551615UL,18446744073709551614UL,1UL,1UL,18446744073709551614UL,18446744073709551615UL,1UL},{1UL,1UL,0x55DF994CBE120C59LL,18446744073709551612UL,5UL,7UL,18446744073709551615UL},{0xE9A2329BF98FB900LL,0x9E00AD0ECE53E0F8LL,0x82378DD73AED9ED0LL,3UL,0x3F89BC4F738E2D4ALL,0xFBD1741CA647AFC7LL,18446744073709551606UL},{0xF38674DA118CC538LL,1UL,5UL,0x8C1F22FE2C018016LL,18446744073709551615UL,18446744073709551615UL,0x8C1F22FE2C018016LL},{0x612AF8CD56BCABF9LL,18446744073709551614UL,0x612AF8CD56BCABF9LL,18446744073709551615UL,0xDAD375EAB18FE55DLL,0x4C9D110461651B2ALL,18446744073709551614UL},{0x8C1F22FE2C018016LL,5UL,0UL,0x89FBE6B9265EC8D8LL,1UL,0x8C1F22FE2C018016LL,18446744073709551607UL},{0x932A6BE0E4C3EF49LL,0x3F89BC4F738E2D4ALL,0xDAD375EAB18FE55DLL,0x612AF8CD56BCABF9LL,0x7AA9D2AA6FFE8300LL,0x4C9D110461651B2ALL,0x82378DD73AED9ED0LL},{5UL,18446744073709551615UL,0xA6204510AD20C6D3LL,1UL,0xA6204510AD20C6D3LL,18446744073709551615UL,5UL},{18446744073709551606UL,0xDAD375EAB18FE55DLL,1UL,0x3F89BC4F738E2D4ALL,0x9E00AD0ECE53E0F8LL,0xFBD1741CA647AFC7LL,18446744073709551610UL},{0x368AC0D095653DDBLL,1UL,18446744073709551612UL,1UL,0x8C1F22FE2C018016LL,7UL,1UL}},{{18446744073709551615UL,0x7AA9D2AA6FFE8300LL,1UL,0x871B461BF9913E33LL,0x40B3492E04414EFELL,18446744073709551615UL,0x40B3492E04414EFELL},{18446744073709551612UL,0xA6204510AD20C6D3LL,0xA6204510AD20C6D3LL,18446744073709551612UL,0x7F23E0E047D31E00LL,1UL,0x55DF994CBE120C59LL},{0x85F250B9BE7E88E1LL,0x9E00AD0ECE53E0F8LL,0xDAD375EAB18FE55DLL,6UL,18446744073709551615UL,0xE9A2329BF98FB900LL,18446744073709551606UL},{0xC116BFF4D91D4A0ELL,0x8C1F22FE2C018016LL,0UL,18446744073709551615UL,18446744073709551615UL,0xF38674DA118CC538LL,0x55DF994CBE120C59LL},{0UL,0x40B3492E04414EFELL,0x612AF8CD56BCABF9LL,18446744073709551610UL,18446744073709551610UL,0x612AF8CD56BCABF9LL,0x40B3492E04414EFELL},{0x8C1F22FE2C018016LL,0x7F23E0E047D31E00LL,5UL,0x9D2A61CEE6C72ABBLL,18446744073709551607UL,0x8C1F22FE2C018016LL,1UL},{0xB2D1E338C87ECE45LL,18446744073709551615UL,0x82378DD73AED9ED0LL,0x612AF8CD56BCABF9LL,3UL,0x932A6BE0E4C3EF49LL,18446744073709551610UL},{0x9039A6F006BF7B63LL,18446744073709551615UL,0x55DF994CBE120C59LL,1UL,1UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,0x612AF8CD56BCABF9LL,18446744073709551614UL,0x612AF8CD56BCABF9LL,18446744073709551615UL,0xDAD375EAB18FE55DLL,0x4C9D110461651B2ALL},{0UL,0xF38674DA118CC538LL,0x89FBE6B9265EC8D8LL,1UL,7UL,5UL,0xF38674DA118CC538LL}},{{0x932A6BE0E4C3EF49LL,0xE9A2329BF98FB900LL,0x40B3492E04414EFELL,0x7AA9D2AA6FFE8300LL,0xFBD1741CA647AFC7LL,0x932A6BE0E4C3EF49LL,0x9E00AD0ECE53E0F8LL},{0UL,1UL,0x368AC0D095653DDBLL,0x89FBE6B9265EC8D8LL,18446744073709551615UL,0x89FBE6B9265EC8D8LL,0x368AC0D095653DDBLL},{18446744073709551615UL,18446744073709551615UL,0x932A6BE0E4C3EF49LL,1UL,0x4C9D110461651B2ALL,18446744073709551610UL,0xDAD375EAB18FE55DLL},{1UL,7UL,0x7F23E0E047D31E00LL,0x64025CFCC5922FD8LL,0x8C1F22FE2C018016LL,0x55DF994CBE120C59LL,1UL},{1UL,0xFBD1741CA647AFC7LL,3UL,0xB2D1E338C87ECE45LL,0x4C9D110461651B2ALL,1UL,0xFBD1741CA647AFC7LL},{0x368AC0D095653DDBLL,18446744073709551615UL,0x3621B940B650884BLL,0x3621B940B650884BLL,18446744073709551615UL,0x368AC0D095653DDBLL,0x9039A6F006BF7B63LL},{1UL,0x4C9D110461651B2ALL,0xB2D1E338C87ECE45LL,3UL,0xFBD1741CA647AFC7LL,1UL,0UL},{0x55DF994CBE120C59LL,0x8C1F22FE2C018016LL,0x64025CFCC5922FD8LL,0x7F23E0E047D31E00LL,7UL,1UL,18446744073709551615UL},{18446744073709551610UL,0x4C9D110461651B2ALL,1UL,0x932A6BE0E4C3EF49LL,18446744073709551615UL,18446744073709551615UL,0x932A6BE0E4C3EF49LL},{0x89FBE6B9265EC8D8LL,18446744073709551615UL,0x89FBE6B9265EC8D8LL,0x368AC0D095653DDBLL,1UL,0UL,18446744073709551615UL}}};
            int32_t l_4626 = 1L;
            int32_t *l_4642 = &g_4142;
            int i, j, k;
            g_4598 = p_5;
            for (l_4453 = 0; (l_4453 < (-10)); l_4453 = safe_sub_func_int64_t_s_s(l_4453, 4))
            { /* block id: 1947 */
                int16_t l_4623 = 0x1E9AL;
                int64_t l_4624 = 0L;
                l_4626 |= ((safe_sub_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((l_4624 = ((*g_887) = (l_4605[3] != ((~((safe_lshift_func_uint64_t_u_u(l_4609[1][5][4], (((((*g_609) = (p_3 && (safe_mod_func_int8_t_s_s((safe_mod_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((((safe_mod_func_uint16_t_u_u((((**g_1100) > 0x7D033CE03A193DEBLL) <= (((*l_4000) = ((~(safe_add_func_int8_t_s_s(((**g_4247) = l_4609[1][3][3]), (l_4459 , (safe_div_func_int32_t_s_s((((((p_5 < l_4609[0][5][2]) | p_6) ^ l_4609[2][8][5]) || p_5) & 249UL), 0x98A98CAFL)))))) >= p_6)) && p_5)), g_1879.f1)) == p_3) , p_4), 0x18L)), 65535UL)), l_4623)))) == 0x893B0BB7EB6F01C8LL) || 0x0496L) != l_4459))) && 0x4FFDL)) , (void*)0)))), l_4623)), 0xD2DDFCDCL)) ^ g_1879.f1);
                return p_4;
            }
            l_4459 ^= (safe_mul_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((*l_4000) = (safe_add_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u(((0x9DB9L || (l_4460[7] <= p_5)) != (l_4626 = l_4458)), ((***g_588) != ((((safe_div_func_uint32_t_u_u((p_4 | (((((*l_3804) = (l_4641 == (l_4643[0][3][4] = l_4642))) <= (safe_div_func_int32_t_s_s((*l_4641), p_6))) , 0x0AC58D3D2AB0B30CLL) == (*l_4642))), p_6)) == (*l_4642)) & (*l_4642)) , l_4642)))) <= p_6), 65532UL))), (*l_4642))), l_4646)), (*l_4642)));
        }
        else
        { /* block id: 1961 */
            uint32_t l_4647 = 0xF5E9C25DL;
            --l_4647;
        }
        if (((++(*l_4650)) ^ p_3))
        { /* block id: 1965 */
            int32_t l_4655[9] = {(-1L),0xF8B5BFB1L,(-1L),0xF8B5BFB1L,(-1L),0xF8B5BFB1L,(-1L),0xF8B5BFB1L,(-1L)};
            int i;
            for (g_1830.f1 = 4; (g_1830.f1 == (-12)); g_1830.f1--)
            { /* block id: 1968 */
                int64_t l_4656 = 0xAD8338B6C80F7BD0LL;
                l_4656 &= ((((p_3 & p_6) <= (*g_4248)) | p_4) & l_4655[8]);
            }
        }
        else
        { /* block id: 1971 */
            uint64_t * const l_4661 = &l_4293;
            int32_t l_4664[6] = {0xE42E2748L,0xE42E2748L,0xE42E2748L,0xE42E2748L,0xE42E2748L,0xE42E2748L};
            uint64_t ****l_4703 = &l_4701;
            struct S0 *l_4786 = (void*)0;
            int i;
lbl_4722:
            for (g_3578.f1 = 0; (g_3578.f1 > 23); g_3578.f1++)
            { /* block id: 1974 */
                int16_t l_4674 = 1L;
                int8_t l_4682[5] = {0xDEL,0xDEL,0xDEL,0xDEL,0xDEL};
                int32_t l_4689 = 1L;
                int32_t l_4706 = 0L;
                int32_t l_4707 = (-3L);
                int32_t l_4708 = 0x8DA939C9L;
                int32_t l_4709 = (-1L);
                int32_t l_4710 = (-3L);
                int32_t l_4711 = 1L;
                int32_t l_4712 = 0x4D2CFC12L;
                int32_t l_4715 = 1L;
                int32_t l_4716 = 1L;
                int32_t l_4717 = 0xFE89FF3FL;
                int32_t l_4718[5][8] = {{0xC889C06EL,0x5A3E977CL,9L,0x91113D0DL,6L,0x91113D0DL,9L,0x5A3E977CL},{0xCF8D73D7L,2L,0xA829ACF9L,0xAD13AD48L,0L,8L,(-8L),9L},{0x5A3E977CL,0x91113D0DL,6L,(-8L),0xCF8D73D7L,0xCF8D73D7L,(-8L),6L},{(-8L),(-8L),0xA829ACF9L,8L,0xAE74EAA6L,0x0E0449EAL,9L,0xC889C06EL},{0xAE74EAA6L,0x0E0449EAL,9L,0xC889C06EL,0xB6A7544FL,6L,0xB6A7544FL,0xC889C06EL}};
                int i, j;
                if ((((*l_4650) = ((*g_3819) == (void*)0)) >= (((l_4650 == l_4661) ^ 0xF8L) < (safe_div_func_int8_t_s_s(l_4664[0], ((+((safe_add_func_int16_t_s_s(g_4244.f2, (safe_lshift_func_int32_t_s_s(p_5, ((safe_add_func_int8_t_s_s(((*g_4248) = (safe_add_func_int64_t_s_s(((**g_3986) ^= l_4674), l_4674))), p_6)) || 7L))))) ^ l_4664[0])) ^ l_4664[4]))))))
                { /* block id: 1978 */
                    int64_t l_4679 = 0xB252B05F5F24B3ACLL;
                    const int32_t *l_4693[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_4693[i] = &g_4694;
                    l_4689 |= (safe_mod_func_int64_t_s_s((((*l_4661) &= (*g_1101)) <= (safe_rshift_func_uint64_t_u_u((l_4679 , (safe_add_func_uint16_t_u_u(0x5D1EL, (l_4682[4] != ((safe_div_func_uint16_t_u_u(((safe_mod_func_int32_t_s_s(((*l_4641) = (((p_5 && (((*g_1390) , ((((**g_588) == (void*)0) || (safe_add_func_uint32_t_u_u(p_6, p_4))) ^ 65528UL)) > l_4682[4])) & p_3) == p_4)), p_5)) , (*l_4641)), (*g_887))) , (-5L)))))), 17))), 5L));
                    for (g_1461.f1 = 0; (g_1461.f1 <= 3); g_1461.f1 += 1)
                    { /* block id: 1984 */
                        const int32_t **l_4692[2][3][2] = {{{(void*)0,&g_2001},{(void*)0,&g_2001},{(void*)0,&g_2001}},{{(void*)0,&g_2001},{(void*)0,&g_2001},{(void*)0,&g_2001}}};
                        int i, j, k;
                        l_3749 &= (safe_lshift_func_int16_t_s_u(0xB97FL, 0));
                        l_4695 = (l_4693[0] = &l_4664[2]);
                        (*l_4641) ^= (safe_add_func_uint8_t_u_u(1UL, (p_4 > (l_4689 ^ (&p_4 != (void*)0)))));
                        if (p_3)
                            goto lbl_4722;
                    }
                }
                else
                { /* block id: 1990 */
                    uint64_t *****l_4702 = &l_4700;
                    union U2 ** const l_4704 = (void*)0;
                    int32_t l_4705 = 0xFFC1F9E2L;
                    l_4664[1] |= ((1L ^ ((safe_add_func_uint64_t_u_u((p_5 && p_5), (-1L))) ^ (l_4689 = (((*l_4702) = l_4700) != l_4703)))) && (0x260D200B6405D4DCLL != ((p_5 < (l_4704 == (void*)0)) && l_4705)));
                }
                l_4719--;
            }
            if (((*l_4641) |= (((l_4726 = (l_4724 = (g_4723 , l_4487))) != l_4487) <= (((((safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_u((0xD4F6L & p_5), (safe_unary_minus_func_uint8_t_u(0xE9L)))), (((p_4 < (p_3 >= 1UL)) < (**g_4247)) | p_5))) != p_6) >= p_5) , l_4733) != (void*)0))))
            { /* block id: 2001 */
                uint64_t *l_4740 = &l_4293;
                const int32_t l_4751 = 0xC32D237CL;
                uint32_t *****l_4755 = &g_586[1];
                const int32_t *l_4758[2][7] = {{&l_4664[0],&l_4664[0],&l_4664[0],&l_4664[0],&l_4664[0],&l_4664[0],&l_4664[0]},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281}};
                uint8_t ** const **l_4771 = (void*)0;
                int i, j;
                for (g_4723.f2 = 29; (g_4723.f2 <= 58); g_4723.f2++)
                { /* block id: 2004 */
                    uint32_t l_4736 = 0xB344E47CL;
                    int32_t l_4737 = (-4L);
                    uint64_t *l_4741 = &g_1538;
                    uint32_t *****l_4754 = &g_586[1];
                    for (g_3578.f1 = 0; (g_3578.f1 <= 1); g_3578.f1 += 1)
                    { /* block id: 2007 */
                        uint32_t l_4744 = 4294967295UL;
                        int32_t l_4757 = 0xC9DA0437L;
                        l_4736 = 0x1248A863L;
                        l_4737 = (((*l_4661) = (**g_1100)) > 0L);
                        l_4757 = ((*l_4641) = (safe_sub_func_int8_t_s_s(((((((l_4740 == l_4741) & ((0xB5L == ((safe_lshift_func_int32_t_s_s(l_4744, 27)) || (safe_mul_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u(((safe_sub_func_int8_t_s_s(l_4751, (((safe_lshift_func_int32_t_s_s(((g_1879.f2 , l_4754) != (l_4756 = l_4755)), 7)) , 0x77965E26D8A0A7F0LL) >= p_3))) | l_4744), p_6)), (*g_1101))))) <= p_4)) == g_1811.f1) ^ g_799.f0) >= p_5) & l_4751), (*g_4248))));
                        l_4758[0][6] = &l_4751;
                    }
                    for (l_4458 = 0; (l_4458 <= 10); l_4458 = safe_add_func_int64_t_s_s(l_4458, 9))
                    { /* block id: 2018 */
                        struct S0 **l_4762 = &l_4487;
                        if (l_4719)
                            goto lbl_4761;
                        (*g_1142) = l_4762;
                    }
                    if (p_4)
                        continue;
                }
                for (g_2418.f1 = 0; (g_2418.f1 > 22); g_2418.f1 = safe_add_func_int16_t_s_s(g_2418.f1, 9))
                { /* block id: 2026 */
                    int8_t l_4774 = (-9L);
                    (*l_4641) |= p_3;
                    for (l_4459 = 0; (l_4459 >= (-15)); --l_4459)
                    { /* block id: 2030 */
                        l_4774 |= ((*l_4641) = ((safe_lshift_func_uint32_t_u_u((safe_div_func_uint16_t_u_u(((((void*)0 == l_4771) && 0x798EL) < (*l_4641)), g_1248.f0)), 14)) && (g_789 , (++(*l_4000)))));
                    }
                }
            }
            else
            { /* block id: 2036 */
                int64_t l_4775 = 0x90A530B50C1724AALL;
                int32_t l_4776 = 3L;
                int32_t l_4777 = 0x392DAFD0L;
                int32_t l_4778 = 0x5E3D99CBL;
                int32_t l_4779[5][4][1] = {{{6L},{6L},{6L},{6L}},{{6L},{6L},{6L},{6L}},{{6L},{6L},{6L},{6L}},{{6L},{6L},{6L},{6L}},{{6L},{6L},{6L},{6L}}};
                int32_t l_4780 = 0x1F992B69L;
                int32_t l_4781 = 1L;
                int32_t l_4782 = (-1L);
                int i, j, k;
                for (g_4274.f0 = 0; (g_4274.f0 <= 7); g_4274.f0 += 1)
                { /* block id: 2039 */
                    for (g_2925.f1 = 0; (g_2925.f1 <= 7); g_2925.f1 += 1)
                    { /* block id: 2042 */
                        return p_3;
                    }
                }
                ++l_4783;
                (**g_2588) = (l_4487 = l_4786);
            }
        }
    }
    else
    { /* block id: 2051 */
        uint64_t l_4787 = 0xFC57CECDC1DA48DELL;
        return l_4787;
    }
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_2418.f0 g_3209 g_776.f0 g_1327 g_887 g_1053 g_932 g_2301.f0 g_2220 g_137 g_3260 g_1242 g_1243 g_1244 g_383 g_103 g_3290 g_212 g_213 g_2244 g_49 g_1687 g_609 g_220 g_1652.f1 g_1343 g_1101 g_82 g_3318 g_1811.f0 g_559 g_853.f3 g_1248.f0 g_58 g_3406 g_3408 g_2797.f0 g_2472 g_55 g_1100 g_1969.f0 g_100 g_101 g_106 g_281 g_3494 g_2599.f0 g_651 g_3209.f0 g_1798.f3 g_223.f1 g_2363 g_789.f1 g_3546 g_3564 g_313.f2 g_3578 g_3584 g_1389 g_1390 g_1261 g_1560.f0 g_1635 g_1798.f0 g_2211 g_3667
 * writes: g_2418.f0 g_106 g_137 g_2244 g_1969.f0 g_1652.f1 g_82 g_281 g_112 g_103 g_49 g_1228 g_220 g_1327 g_1102.f0 g_55 g_1459.f1 g_429.f0 g_651 g_3408 g_1879.f1 g_223.f1 g_1412.f1 g_2660 g_3667
 */
static int32_t  func_8(int16_t  p_9, int8_t  p_10, uint16_t  p_11)
{ /* block id: 1351 */
    uint8_t l_3212 = 250UL;
    union U3 *l_3218 = (void*)0;
    uint8_t * const *l_3231 = &g_933;
    int32_t l_3238 = (-1L);
    int32_t l_3239 = 1L;
    int32_t l_3240 = 0xBC9D3BF8L;
    int32_t l_3241 = (-1L);
    int32_t l_3242 = 1L;
    int32_t l_3243 = 0x8C381CA3L;
    union U2 ****l_3247 = &g_2660[2][0];
    union U4 *l_3311 = &g_3312[1][2][1];
    uint32_t l_3314 = 4294967295UL;
    uint16_t * const **** const l_3347 = (void*)0;
    uint16_t l_3353 = 2UL;
    int32_t l_3478[7];
    uint64_t *l_3502 = &g_1538;
    uint64_t ** const l_3501 = &l_3502;
    const int16_t l_3593[2] = {0xA4C9L,0xA4C9L};
    uint16_t * const *l_3601 = &g_887;
    uint16_t * const **l_3600[2][2] = {{&l_3601,&l_3601},{&l_3601,&l_3601}};
    uint16_t * const ***l_3599 = &l_3600[0][0];
    int16_t l_3620[9][1][4] = {{{1L,1L,1L,1L}},{{1L,1L,1L,1L}},{{1L,1L,1L,1L}},{{1L,1L,1L,1L}},{{1L,1L,1L,1L}},{{1L,1L,1L,1L}},{{1L,1L,1L,1L}},{{1L,1L,1L,1L}},{{1L,1L,1L,1L}}};
    int64_t * const *l_3629 = &g_609;
    int64_t * const **l_3628 = &l_3629;
    int8_t l_3661 = 0L;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_3478[i] = 0x453975A1L;
    for (g_2418.f0 = 0; (g_2418.f0 <= 6); g_2418.f0 += 1)
    { /* block id: 1354 */
        uint8_t *l_3213 = &g_106;
        union U3 *l_3216 = &g_3217;
        union U3 *l_3219 = &g_3220;
        int32_t l_3228 = 0L;
        int32_t *l_3229[1];
        int32_t l_3230 = 0x0C7BECFFL;
        int32_t *l_3232 = &g_2244;
        int32_t *l_3233 = &g_103;
        int32_t *l_3234 = &g_2244;
        int32_t *l_3235 = &g_2244;
        int32_t *l_3236 = &g_281;
        int32_t *l_3237[6][7][6] = {{{&g_2244,&g_2244,&l_3230,&g_2244,&l_3230,&g_2244},{&l_3228,&g_2244,&l_3230,&l_3228,(void*)0,&g_2244},{&g_2244,&l_3228,&g_2244,&g_2244,&l_3228,&g_2244},{&g_2244,&l_3228,&g_2244,&l_3230,(void*)0,&l_3230},{&l_3230,&g_2244,&l_3228,&g_2244,&l_3230,&l_3228},{&l_3230,&g_2244,&g_2244,&l_3230,(void*)0,(void*)0},{&g_2244,(void*)0,(void*)0,&g_2244,&l_3228,(void*)0}},{{&g_2244,(void*)0,&g_2244,&l_3228,&l_3230,&l_3228},{&l_3228,&g_2244,&l_3228,&g_2244,&l_3230,&l_3230},{&g_2244,(void*)0,&g_2244,&l_3228,&l_3228,&g_2244},{(void*)0,(void*)0,&g_2244,&l_3228,(void*)0,&g_2244},{&g_2244,&g_2244,&l_3230,&g_2244,&l_3230,&g_2244},{&l_3228,&g_2244,&l_3230,&l_3228,(void*)0,&g_2244},{&g_2244,&l_3228,&g_2244,&g_2244,&l_3228,&g_2244}},{{&g_2244,&l_3228,&g_2244,&l_3230,(void*)0,&l_3230},{&l_3230,&g_2244,&l_3228,&g_2244,&l_3230,&l_3228},{&l_3230,&g_2244,&g_2244,&l_3230,(void*)0,(void*)0},{&g_2244,(void*)0,(void*)0,&g_2244,&l_3228,(void*)0},{&g_2244,(void*)0,&g_2244,&l_3228,&l_3230,&l_3228},{&l_3228,&g_2244,&l_3228,&g_2244,&l_3230,&l_3230},{&g_2244,(void*)0,&g_2244,&l_3228,&l_3228,&g_2244}},{{(void*)0,(void*)0,&g_2244,&l_3228,(void*)0,&g_2244},{&g_2244,&g_2244,&l_3230,&g_2244,&l_3230,&g_2244},{&l_3228,&g_2244,&l_3230,&l_3228,(void*)0,&g_2244},{&g_2244,&g_2244,(void*)0,(void*)0,&g_2244,&l_3228},{(void*)0,&g_2244,&l_3228,(void*)0,&g_2244,&g_2244},{&g_2244,&g_2244,&l_3228,&g_2244,&g_2244,&g_2244},{&g_2244,(void*)0,&g_2244,(void*)0,&l_3230,&l_3230}},{{(void*)0,&g_2244,&g_2244,(void*)0,&l_3228,&l_3230},{&l_3228,&l_3230,&g_2244,&g_2244,(void*)0,&g_2244},{&l_3228,&l_3230,&l_3228,&g_2244,(void*)0,&g_2244},{&g_2244,&l_3230,&l_3228,&l_3228,&l_3228,&l_3228},{&g_2244,&g_2244,(void*)0,&l_3228,&l_3230,&g_2244},{&g_2244,(void*)0,&g_2244,&g_2244,&g_2244,(void*)0},{&l_3228,&g_2244,&g_2244,&g_2244,&g_2244,&g_2244}},{{&l_3228,&g_2244,(void*)0,(void*)0,&g_2244,&l_3228},{(void*)0,&g_2244,&l_3228,(void*)0,&g_2244,&g_2244},{&g_2244,&g_2244,&l_3228,&g_2244,&g_2244,&g_2244},{&g_2244,(void*)0,&g_2244,(void*)0,&l_3230,&l_3230},{(void*)0,&g_2244,&g_2244,(void*)0,&l_3228,&l_3230},{&l_3228,&l_3230,&g_2244,&g_2244,(void*)0,&g_2244},{&l_3228,&l_3230,&l_3228,&g_2244,(void*)0,&g_2244}}};
        uint64_t l_3244 = 18446744073709551609UL;
        uint64_t **l_3251 = (void*)0;
        uint64_t ***l_3250 = &l_3251;
        int64_t ***l_3305 = &g_608;
        uint16_t *****l_3346 = &g_2541;
        struct S0 * const *l_3379 = &g_1144;
        int64_t **l_3431 = &g_609;
        uint16_t l_3474 = 8UL;
        uint16_t l_3475 = 0x008FL;
        uint16_t l_3480 = 1UL;
        uint8_t l_3539[9] = {0xDAL,0xDAL,0xDBL,0xDAL,0xDAL,0xDBL,0xDAL,0xDAL,0xDBL};
        int32_t l_3637[1][3];
        int32_t l_3639 = 8L;
        int16_t l_3648 = (-10L);
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_3229[i] = &g_1043;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
                l_3637[i][j] = 0x59E91615L;
        }
        (*l_3232) = (~(g_3209 , ((safe_div_func_uint8_t_u_u(((*l_3213) = l_3212), g_776.f0)) > ((safe_mul_func_int8_t_s_s(((((l_3230 &= ((0xC6L & (0xF1D4603DL | (l_3216 == (l_3219 = l_3218)))) & (safe_unary_minus_func_uint16_t_u(((*g_887) = (safe_add_func_uint16_t_u_u(((safe_mod_func_uint16_t_u_u(65535UL, (safe_lshift_func_int32_t_s_s(l_3212, l_3228)))) > p_9), g_1327))))))) , p_11) , l_3231) == (*g_1053)), l_3212)) != p_9))));
        l_3244++;
        for (g_1969.f0 = 0; (g_1969.f0 <= 1); g_1969.f0 += 1)
        { /* block id: 1363 */
            uint64_t ***l_3252 = &l_3251;
            int32_t l_3263[6][2][7] = {{{0x4AD6FC98L,5L,0x97E523B8L,0x4AD6FC98L,(-1L),0x0C365067L,(-1L)},{0x4AD6FC98L,(-1L),(-1L),0x4AD6FC98L,0xD6933D26L,0x1F33DD90L,(-1L)}},{{1L,5L,(-1L),1L,(-1L),0x1F33DD90L,0xD6933D26L},{0x4AD6FC98L,5L,0x97E523B8L,0x4AD6FC98L,(-1L),0x0C365067L,(-1L)}},{{0x4AD6FC98L,(-1L),(-1L),0x4AD6FC98L,0xD6933D26L,0x1F33DD90L,(-1L)},{1L,5L,(-1L),1L,(-1L),0x1F33DD90L,0xD6933D26L}},{{0x4AD6FC98L,5L,0x97E523B8L,0x4AD6FC98L,(-1L),0x0C365067L,(-1L)},{0x4AD6FC98L,(-1L),(-1L),0x4AD6FC98L,0xD6933D26L,0x1F33DD90L,(-1L)}},{{1L,5L,(-1L),1L,(-1L),0x1F33DD90L,0xD6933D26L},{0x4AD6FC98L,5L,0x97E523B8L,0x4AD6FC98L,(-1L),0x0C365067L,(-1L)}},{{0x4AD6FC98L,(-1L),(-1L),0x4AD6FC98L,0xD6933D26L,0x1C0F0D26L,9L},{0x97E523B8L,0x1F33DD90L,0x0C365067L,0x97E523B8L,9L,0x1C0F0D26L,1L}}};
            uint16_t *** const *l_3321 = &g_2542;
            uint32_t l_3327[9][4][7] = {{{0x89E55C8AL,9UL,4294967287UL,0xF7FD67ADL,1UL,4UL,0x8ECC2E94L},{0xF7FD67ADL,4294967295UL,1UL,0x88E4F109L,0xEEBA658CL,0xDA585D77L,0x8ECC2E94L},{0xE4C2940AL,0x185E6AD4L,0UL,0xE4C2940AL,0x8ECC2E94L,1UL,0xA251E991L},{1UL,4294967286UL,0x3C87EF0CL,0x88E4F109L,1UL,6UL,0x82BA10EEL}},{{1UL,0UL,1UL,0xF7FD67ADL,0xF413B7ACL,0x6202A005L,1UL},{0xE4C2940AL,9UL,1UL,0xBCD6D64BL,1UL,1UL,0xEEBA658CL},{0xF7FD67ADL,9UL,4294967295UL,0x88E4F109L,0x8ECC2E94L,1UL,0x8ECC2E94L},{0x89E55C8AL,0UL,0UL,0x89E55C8AL,0xEEBA658CL,1UL,1UL}},{{7UL,4294967286UL,0UL,3UL,1UL,0x6202A005L,0xF413B7ACL},{1UL,0x185E6AD4L,4294967295UL,0xF7FD67ADL,0x82BA10EEL,6UL,1UL},{0x89E55C8AL,4294967295UL,1UL,0xF7FD67ADL,0xA251E991L,1UL,0x8ECC2E94L},{0xBCD6D64BL,9UL,1UL,3UL,0x8ECC2E94L,0xDA585D77L,0xEEBA658CL}},{{0x89E55C8AL,0x185E6AD4L,0x3C87EF0CL,0x89E55C8AL,0x8ECC2E94L,4UL,1UL},{1UL,2UL,0UL,0x88E4F109L,0xA251E991L,0x6202A005L,0x82BA10EEL},{7UL,0x185E6AD4L,1UL,0xBCD6D64BL,0x82BA10EEL,0x6202A005L,0xA251E991L},{0x89E55C8AL,9UL,4294967287UL,0xF7FD67ADL,1UL,4UL,0x8ECC2E94L}},{{0xF7FD67ADL,4294967295UL,1UL,0x88E4F109L,0xEEBA658CL,0xDA585D77L,0x8ECC2E94L},{0xE4C2940AL,0x185E6AD4L,0UL,0xE4C2940AL,0x8ECC2E94L,1UL,0xA251E991L},{1UL,4294967286UL,0x3C87EF0CL,0x88E4F109L,1UL,6UL,0x82BA10EEL},{1UL,0UL,1UL,0xF7FD67ADL,0xF413B7ACL,0x6202A005L,1UL}},{{0xE4C2940AL,9UL,1UL,0xBCD6D64BL,1UL,1UL,0xEEBA658CL},{0xF7FD67ADL,9UL,4294967295UL,0x88E4F109L,0x8ECC2E94L,1UL,0x8ECC2E94L},{0x89E55C8AL,0UL,0UL,0x89E55C8AL,0xEEBA658CL,1UL,1UL},{7UL,4294967286UL,0UL,3UL,1UL,0x6202A005L,0xF413B7ACL}},{{1UL,0x185E6AD4L,4294967295UL,0xF7FD67ADL,0x82BA10EEL,6UL,1UL},{0x89E55C8AL,4294967295UL,1UL,0xF7FD67ADL,0xA251E991L,1UL,0x49F8DAB5L},{4294967287UL,0x6202A005L,4UL,0x73DEB954L,0x49F8DAB5L,1UL,0xD15860B7L},{1UL,1UL,0xB5DC1266L,1UL,0x49F8DAB5L,0UL,0x44AE9B4AL}},{{0UL,1UL,4UL,4294967295UL,4294967294UL,0x5D0EDA30L,0x21C547FBL},{0x3C87EF0CL,1UL,4UL,4294967287UL,0x21C547FBL,0x5D0EDA30L,4294967294UL},{1UL,0x6202A005L,0x8C185969L,1UL,0x44AE9B4AL,0UL,0x49F8DAB5L},{1UL,6UL,4UL,4294967295UL,0xD15860B7L,1UL,0x49F8DAB5L}},{{4294967295UL,1UL,4UL,4294967295UL,0x49F8DAB5L,1UL,4294967294UL},{0UL,0xDA585D77L,0xB5DC1266L,4294967295UL,0x44AE9B4AL,0x0628EF39L,0x21C547FBL},{0UL,4UL,4UL,1UL,4294967295UL,0x5D0EDA30L,0x44AE9B4AL},{4294967295UL,0x6202A005L,4294967288UL,4294967287UL,0x44AE9B4AL,1UL,0xD15860B7L}}};
            int16_t l_3354[2][4] = {{(-3L),(-3L),(-3L),(-3L)},{(-3L),(-3L),(-3L),(-3L)}};
            uint16_t l_3407 = 0UL;
            uint8_t l_3409[2][7][7] = {{{0xA6L,0x83L,0xA6L,0x6AL,3UL,3UL,0x6AL},{0xBFL,0x05L,0xBFL,1UL,0UL,0x13L,0xA0L},{0xA6L,0x83L,0xA6L,0x6AL,3UL,3UL,0x6AL},{0xBFL,0x05L,0xBFL,1UL,0UL,0x13L,0xA0L},{0xA6L,0x83L,0xA6L,0x6AL,3UL,3UL,0x6AL},{0xBFL,0x05L,0xBFL,1UL,0UL,0x13L,0xA0L},{0xA6L,0x83L,0xA6L,0x6AL,3UL,3UL,0x6AL}},{{0xBFL,0x05L,0xBFL,1UL,0UL,0x13L,0xA0L},{0xA6L,0x83L,0xA6L,0x6AL,3UL,3UL,0x6AL},{0xBFL,0x05L,0xBFL,1UL,0UL,0x13L,0xA0L},{0xA6L,0x83L,0xA6L,0x6AL,3UL,3UL,0x6AL},{0xBFL,0x05L,0xBFL,1UL,0UL,0x13L,0xA0L},{0xA6L,0x83L,0xA6L,0x6AL,3UL,3UL,0x6AL},{0xBFL,0x05L,0xBFL,1UL,0UL,0x13L,0xA0L}}};
            int16_t l_3420[9][4] = {{0x3F95L,0xC9C0L,0xC9C0L,0x3F95L},{0xC9C0L,0x3F95L,0xC9C0L,0xC9C0L},{0x3F95L,0x3F95L,(-1L),0x3F95L},{0x3F95L,0xC9C0L,(-1L),0xC9C0L},{(-1L),0xC9C0L,(-1L),(-1L)},{0xC9C0L,0xC9C0L,0x3F95L,0xC9C0L},{0xC9C0L,(-1L),(-1L),0xC9C0L},{(-1L),0xC9C0L,(-1L),(-1L)},{0xC9C0L,0xC9C0L,0x3F95L,0xC9C0L}};
            int64_t l_3452 = 0x86031A28DB320771LL;
            int32_t l_3496 = 0x4B140E59L;
            int i, j, k;
            for (g_1652.f1 = 0; (g_1652.f1 <= 1); g_1652.f1 += 1)
            { /* block id: 1366 */
                uint32_t l_3294 = 1UL;
                int64_t l_3295 = (-9L);
                int32_t l_3313[9][10][2] = {{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)},{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-1L)}},{{(-1L),0x85C64011L},{(-8L),(-8L)},{(-8L),0x85C64011L},{(-1L),(-1L)},{0x85C64011L,(-8L)},{2L,(-1L)},{0x85C64011L,0x85C64011L},{0x85C64011L,(-1L)},{2L,(-8L)},{(-1L),(-8L)}}};
                int32_t l_3324[10][10] = {{1L,(-6L),8L,0L,0L,0x61D6F67AL,1L,0L,0x135BC5DDL,(-4L)},{0L,0x0C99B7B8L,0xF7EFD3D6L,4L,0x401EFEBCL,0x61D6F67AL,0xE61ADDB3L,1L,0x15EEBCF7L,4L},{1L,0x6F2AE932L,0xD5CA09C2L,1L,(-1L),0x0FB28E2CL,(-7L),(-7L),0x0FB28E2CL,(-1L)},{0x0E220483L,0L,0L,0x0E220483L,4L,0x15EEBCF7L,1L,0xE61ADDB3L,0x61D6F67AL,0x401EFEBCL},{8L,(-10L),4L,(-6L),(-4L),0x135BC5DDL,0L,1L,0x61D6F67AL,0L},{(-7L),0L,(-9L),0x0E220483L,0L,0x78822C72L,(-1L),0x0C99B7B8L,0x0FB28E2CL,0x0C99B7B8L},{(-10L),0xF7EFD3D6L,8L,1L,8L,0xF7EFD3D6L,(-10L),(-1L),0x15EEBCF7L,0x401EFEBCL},{(-6L),0x401EFEBCL,0xE61ADDB3L,4L,1L,0xE61ADDB3L,0x15EEBCF7L,(-10L),0x135BC5DDL,(-1L)},{(-7L),0x401EFEBCL,1L,0L,(-1L),0x20E5B019L,(-10L),0x401EFEBCL,0x78822C72L,1L},{(-4L),0xF7EFD3D6L,(-6L),(-1L),0x15EEBCF7L,0x15EEBCF7L,(-1L),(-6L),0xF7EFD3D6L,(-4L)}};
                uint32_t *l_3349 = (void*)0;
                uint32_t *l_3350 = (void*)0;
                uint32_t *l_3351[5] = {&g_620.f2,&g_620.f2,&g_620.f2,&g_620.f2,&g_620.f2};
                int16_t *l_3352 = &g_1327;
                uint32_t l_3415 = 4294967291UL;
                int64_t **l_3429[10][9][2] = {{{&g_609,(void*)0},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{(void*)0,&g_609},{&g_609,(void*)0},{&g_609,&g_609},{&g_609,(void*)0},{&g_609,&g_609}},{{(void*)0,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,(void*)0},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609}},{{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609}},{{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,(void*)0}},{{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{(void*)0,(void*)0},{(void*)0,&g_609},{&g_609,&g_609},{&g_609,&g_609}},{{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{(void*)0,(void*)0},{&g_609,&g_609},{&g_609,&g_609},{&g_609,(void*)0},{(void*)0,&g_609},{&g_609,&g_609}},{{&g_609,&g_609},{(void*)0,&g_609},{(void*)0,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{(void*)0,&g_609}},{{(void*)0,&g_609},{&g_609,&g_609},{&g_609,&g_609},{(void*)0,(void*)0},{&g_609,&g_609},{&g_609,&g_609},{&g_609,(void*)0},{(void*)0,&g_609},{&g_609,&g_609}},{{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609},{(void*)0,(void*)0},{(void*)0,&g_609},{&g_609,&g_609},{&g_609,&g_609},{&g_609,&g_609}},{{&g_609,&g_609},{&g_609,&g_609},{(void*)0,(void*)0},{&g_609,&g_609},{&g_609,&g_609},{&g_609,(void*)0},{(void*)0,&g_609},{&g_609,&g_609},{&g_609,&g_609}}};
                int64_t **l_3430 = &g_609;
                const int64_t l_3451 = 0xDE232CF6BB0EE054LL;
                int8_t l_3473 = 0x17L;
                int i, j, k;
                l_3247 = &g_2660[2][0];
                for (p_9 = 0; (p_9 >= 0); p_9 -= 1)
                { /* block id: 1370 */
                    uint64_t ****l_3253 = &l_3252;
                    int32_t *l_3264[6][8] = {{(void*)0,(void*)0,(void*)0,(void*)0,&l_3263[5][0][4],(void*)0,&l_3241,(void*)0},{&l_3241,&l_3243,&l_3230,&l_3263[5][0][4],&l_3243,(void*)0,&l_3243,&l_3263[5][0][4]},{(void*)0,&l_3243,(void*)0,(void*)0,&l_3241,(void*)0,&l_3263[5][0][4],(void*)0},{&g_103,(void*)0,(void*)0,&l_3241,&g_2244,&g_2244,&l_3241,(void*)0},{&g_103,&g_103,(void*)0,&l_3263[5][0][4],&l_3241,&l_3243,&g_103,&l_3241},{(void*)0,&l_3241,(void*)0,(void*)0,&l_3243,(void*)0,(void*)0,&l_3241}};
                    union U4 * const l_3308[9][6][4] = {{{(void*)0,&g_380,&g_1830,(void*)0},{(void*)0,&g_2479[4][2],&g_1816,&g_2679},{&g_2481[0],(void*)0,&g_2605,&g_1456},{&g_957,&g_1830,(void*)0,&g_1461},{&g_2481[0],&g_1635,&g_1830,(void*)0},{(void*)0,&g_1830,&g_2605,&g_380}},{{&g_1816,&g_380,&g_1456,&g_1456},{(void*)0,&g_2912,&g_1816,&g_1830},{&g_2481[0],&g_957,&g_1459,&g_1816},{&g_2481[0],&g_2479[4][2],&g_1635,&g_957},{&g_957,&g_380,&g_380,&g_2481[0]},{&g_1816,&g_1830,(void*)0,&g_2925}},{{&g_2481[0],&g_2479[4][2],&g_957,&g_957},{(void*)0,(void*)0,(void*)0,&g_2605},{(void*)0,&g_1456,&g_1635,&g_1456},{&g_2481[0],&g_2479[7][1],&g_380,&g_1635},{(void*)0,&g_2479[7][1],&g_1816,&g_1456},{&g_2479[7][1],&g_1456,&g_2481[0],&g_2605}},{{&g_2925,(void*)0,&g_2605,&g_957},{&g_1830,&g_2479[4][2],&g_2479[7][1],&g_2925},{&g_380,&g_1830,(void*)0,&g_2481[0]},{&g_2912,&g_380,&g_1456,&g_957},{(void*)0,&g_2479[4][2],&g_957,(void*)0},{&g_1461,&g_1456,&g_2679,&g_1816}},{{&g_1830,&g_380,(void*)0,&g_1830},{&g_1459,(void*)0,&g_1830,&g_1635},{&g_2479[4][2],&g_1830,&g_957,&g_1816},{&g_1830,&g_957,&g_1456,&g_2912},{&g_1635,&g_2925,&g_1635,(void*)0},{(void*)0,&g_2481[0],&g_1456,(void*)0}},{{&g_1830,&g_957,&g_1461,&g_2481[0]},{(void*)0,&g_1635,&g_1461,&g_380},{&g_1830,&g_2912,&g_1456,&g_1456},{(void*)0,&g_957,&g_1635,&g_2481[1]},{&g_1635,&g_2481[1],&g_1456,&g_957},{&g_1830,(void*)0,&g_957,(void*)0}},{{&g_2479[4][2],&g_957,&g_1830,(void*)0},{&g_1459,&g_1456,(void*)0,(void*)0},{&g_1830,&g_1635,&g_2679,&g_2481[0]},{&g_1461,&g_1830,&g_957,&g_2605},{(void*)0,&g_1461,&g_1456,&g_2925},{&g_2912,&g_2912,(void*)0,&g_1459}},{{&g_380,(void*)0,&g_2479[7][1],&g_380},{&g_1830,&g_2605,&g_2605,&g_1830},{&g_2925,&g_1456,&g_2481[0],&g_2679},{&g_2479[7][1],&g_2479[4][2],&g_1816,&g_1830},{(void*)0,&g_380,&g_380,&g_1830},{&g_2481[0],&g_2479[4][2],&g_1635,&g_2679}},{{(void*)0,&g_1456,(void*)0,&g_1830},{(void*)0,&g_2605,&g_957,&g_380},{&g_2481[0],(void*)0,(void*)0,&g_1459},{&g_1816,&g_2912,&g_380,&g_2925},{&g_957,&g_1461,&g_1635,&g_2605},{&g_380,&g_1830,&g_1816,&g_2481[0]}}};
                    int i, j, k;
                    l_3235 = ((((*l_3235) = (((safe_add_func_uint64_t_u_u(p_10, (l_3250 == ((*l_3253) = l_3252)))) == g_2301.f0) <= 18446744073709551615UL)) || 2UL) , g_2220[(p_9 + 5)]);
                    if ((0xE9B93687C343D3FALL ^ p_9))
                    { /* block id: 1374 */
                        uint32_t l_3256 = 4294967295UL;
                        int32_t l_3257 = 6L;
                        int32_t l_3262 = 0xBD658EE0L;
                        (*l_3236) = (safe_lshift_func_uint32_t_u_s(((l_3257 = (l_3256 &= p_9)) , p_11), (safe_mod_func_int32_t_s_s(0x20865480L, ((1L >= p_10) , (((g_137 , (g_3260 , ((((((safe_unary_minus_func_uint8_t_u(l_3262)) , &g_804[g_2418.f0]) == (void*)0) | 0x61AA4887A31676EFLL) == p_9) && p_9))) || p_9) || l_3263[5][0][4]))))));
                        l_3264[1][6] = ((****g_1242) = &l_3241);
                        (*l_3233) ^= (safe_div_func_int64_t_s_s((!0xBB76L), 1L));
                        if (p_11)
                            break;
                    }
                    else
                    { /* block id: 1382 */
                        int32_t l_3291 = 0x461914B0L;
                        int64_t ****l_3306 = (void*)0;
                        int64_t ****l_3307 = &g_1228[2][8][0];
                        int i, j;
                        l_3238 = ((safe_rshift_func_int16_t_s_s(((safe_lshift_func_int16_t_s_s((safe_div_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s(l_3212, (safe_mul_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(65527UL, (p_11 < (5L >= (safe_rshift_func_uint64_t_u_u((g_49 ^= ((((safe_rshift_func_int8_t_s_u((safe_mul_func_uint16_t_u_u((safe_mul_func_uint64_t_u_u((p_9 ^ (safe_rshift_func_uint32_t_u_u((((((g_3290 , (*g_212)) , l_3291) > (l_3263[1][0][1] = (safe_mul_func_int64_t_s_s((((g_2220[(p_9 + 5)] != (void*)0) & l_3291) != 4294967289UL), 0UL)))) ^ l_3291) , l_3263[5][1][1]), 23))), (*l_3234))), l_3294)), 3)) && 0x6FB39B65D9590747LL) > p_9) >= p_10)), (*l_3232))))))), p_9)))), l_3295)), g_1687)) == 0x0869L), 0)) || (*g_609));
                        (*l_3233) = (l_3243 ^ ((~((l_3263[3][0][4] = ((*l_3213) = ((safe_add_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((safe_add_func_int16_t_s_s(0L, l_3291)), 3)), p_9)) < (safe_sub_func_uint32_t_u_u((l_3238 = l_3263[5][0][4]), ((g_1343[p_9][g_1652.f1] , ((*l_3307) = l_3305)) != (void*)0)))))) , (*g_1101))) > 0x82AFD00BL));
                        if (l_3294)
                            continue;
                    }
                    if ((*l_3235))
                    { /* block id: 1393 */
                        union U4 **l_3310[3][5][2] = {{{(void*)0,&g_1458},{(void*)0,(void*)0},{&g_1458,(void*)0},{(void*)0,&g_1458},{(void*)0,(void*)0}},{{&g_1458,(void*)0},{&g_1458,&g_1458},{&g_1458,&g_1458},{&g_1458,&g_1458},{&g_1458,&g_1458}},{{&g_1458,&g_1458},{&g_1458,&g_1458},{&g_1458,&g_1458},{&g_1458,&g_1458},{&g_1458,&g_1458}}};
                        int i, j, k;
                        l_3311 = l_3308[4][4][3];
                        ++l_3314;
                    }
                    else
                    { /* block id: 1396 */
                        int32_t *l_3317 = &l_3313[0][7][1];
                        int32_t l_3325 = 0x87AAF812L;
                        l_3264[3][2] = l_3317;
                        (*l_3236) = p_10;
                        l_3324[9][8] |= ((g_3318[0] , (safe_mod_func_uint64_t_u_u((((*g_609) = ((((void*)0 == l_3321) && l_3243) | p_9)) | 18446744073709551613UL), (safe_lshift_func_int16_t_s_s(g_776.f0, 0))))) >= (((*l_3317) ^= l_3263[1][0][0]) || (l_3242 , (*l_3234))));
                        l_3327[8][3][3]++;
                    }
                }
                (*l_3236) = ((((*g_887) &= (safe_rshift_func_uint16_t_u_s(0xACB3L, ((safe_mul_func_int32_t_s_s(((+(safe_rshift_func_uint16_t_u_s((safe_div_func_int64_t_s_s(((*l_3235) , (safe_lshift_func_uint32_t_u_s((safe_sub_func_int16_t_s_s((safe_div_func_uint16_t_u_u((+p_10), l_3239)), (0x928A5FB31DE3A08ELL <= (((*l_3352) = (((l_3241 = p_10) || (((l_3346 != l_3347) , (safe_unary_minus_func_uint16_t_u(((l_3243 |= (p_9 == p_10)) > p_11)))) & 0xD124CCAAD76B2A93LL)) < l_3295)) < l_3353)))), p_10))), l_3327[2][3][1])), g_1811.f0))) >= l_3327[8][3][3]), 9L)) == l_3354[1][3])))) > g_559) >= l_3324[2][3]);
                if ((safe_mul_func_uint64_t_u_u(((safe_lshift_func_int64_t_s_s(l_3295, 46)) <= (safe_div_func_int32_t_s_s((p_11 > ((safe_rshift_func_uint16_t_u_s(((safe_mul_func_int16_t_s_s((safe_rshift_func_int32_t_s_u(l_3263[5][0][4], ((*l_3233) = 0x917CE4E6L))), ((safe_mul_func_uint8_t_u_u(251UL, 0x7AL)) , ((((((((l_3238 == ((safe_lshift_func_uint16_t_u_u((0xB82559BCC3403E35LL | (safe_sub_func_int16_t_s_s((l_3263[1][0][6] && l_3263[2][0][1]), 0x7FE4L))), 14)) | l_3263[1][1][4])) ^ p_11) == 18446744073709551607UL) > l_3327[8][3][3]) , l_3313[0][7][1]) | l_3354[1][2]) , p_11) > 0x6783154B022E809DLL)))) < p_11), g_853.f3)) == l_3327[5][3][5])), p_11))), (*l_3232))))
                { /* block id: 1411 */
                    uint32_t l_3378 = 4UL;
                    struct S0 **l_3380 = &g_1144;
                    int32_t ***l_3412[9] = {&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383};
                    int i;
                    if ((safe_add_func_int32_t_s_s(((~(((*g_609) = p_11) && (safe_mod_func_uint16_t_u_u((((((g_1248.f0 <= ((*l_3235) = l_3378)) , l_3379) != l_3380) , ((safe_sub_func_uint32_t_u_u((safe_add_func_uint32_t_u_u((l_3324[6][0] |= p_11), l_3378)), (safe_lshift_func_uint8_t_u_s(((((safe_div_func_int8_t_s_s((l_3263[5][0][4] != (p_10 , 0x363F8FFEL)), p_11)) , 0x1FL) && 255UL) <= l_3238), 6)))) <= 0x50L)) <= (*g_609)), g_58)))) == 0xF881L), p_10)))
                    { /* block id: 1415 */
                        int8_t l_3393[10] = {0xDEL,0xDEL,0xDEL,0xDEL,0xDEL,0xDEL,0xDEL,0xDEL,0xDEL,0xDEL};
                        int i;
                        (*l_3234) |= (p_10 ^ (safe_rshift_func_uint16_t_u_s(l_3378, (safe_sub_func_uint32_t_u_u((l_3393[5] && (safe_div_func_int32_t_s_s(2L, (safe_mod_func_int32_t_s_s((p_10 == ((-8L) >= (safe_div_func_int64_t_s_s(((((l_3313[8][1][0] = ((*l_3213) = (safe_mod_func_int8_t_s_s(((((safe_mul_func_uint64_t_u_u((((p_11 & (((((((p_9 , g_3406[2]) , l_3354[1][3]) < 0x2816L) != 0xD1L) || 0UL) == 0xDFD4L) != p_9)) == p_11) || l_3393[9]), l_3407)) | p_10) , p_9) != (-9L)), g_3408)))) <= l_3409[0][2][1]) > p_9) > p_10), 1L)))), p_9))))), p_9)))));
                        l_3263[5][0][4] = (safe_mod_func_uint32_t_u_u(((g_2797.f0 , &g_804[g_2418.f0]) == (l_3393[3] , l_3412[5])), (((safe_rshift_func_int64_t_s_s(l_3415, (((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u(((*l_3233) <= (l_3420[8][3] != 0x7205L)), 7)), (((0xB4B42594L <= p_11) > g_2472) > (-6L)))) < 0x8F4FL) | 0x12037C8C8BB52236LL))) & 0x8540893AL) & (*l_3232))));
                        (*g_383) = &l_3263[5][0][4];
                    }
                    else
                    { /* block id: 1421 */
                        int64_t ***l_3423 = &g_608;
                        int64_t ***l_3424 = &g_608;
                        int64_t ***l_3425 = &g_608;
                        int64_t ***l_3426 = (void*)0;
                        int64_t ***l_3427 = &g_608;
                        int64_t ***l_3428[1];
                        uint64_t *l_3432 = &g_55;
                        int32_t l_3435 = 0x345134C7L;
                        int8_t *l_3453 = (void*)0;
                        int8_t *l_3454 = &g_1459.f1;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_3428[i] = &g_608;
                        (*l_3234) |= p_10;
                        (*l_3233) ^= ((l_3324[2][8] & p_11) , ((*l_3232) = ((safe_add_func_int8_t_s_s((g_1102.f0 = ((l_3429[8][2][0] = (void*)0) != (l_3431 = l_3430))), p_9)) ^ ((((((*l_3352) &= 0x92A0L) == ((++(*l_3432)) || 5L)) != p_10) | (0x87L == 0L)) & (**g_1100)))));
                        (*l_3233) |= (l_3435 == (((*l_3352) ^= (safe_sub_func_uint8_t_u_u(p_9, ((*l_3454) = (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s(((safe_sub_func_uint16_t_u_u(p_9, l_3263[4][0][3])) || (safe_lshift_func_uint32_t_u_s((safe_div_func_uint16_t_u_u((p_11 &= p_10), (p_10 || l_3435))), 2))), (~(((safe_rshift_func_int64_t_s_u(p_10, (((*l_3236) = (0x0DL | p_10)) == l_3451))) & 7L) < 1UL)))), l_3452)))))) || p_11));
                        if (p_10)
                            break;
                    }
                }
                else
                { /* block id: 1437 */
                    int32_t l_3476[8][7][4] = {{{0x238DBA56L,(-6L),0x45D00231L,0xA87EBFDDL},{0L,(-1L),(-10L),0x50843491L},{0xA9460C90L,0x11EAD066L,0x3B262F1CL,(-7L)},{0x0C46E84AL,(-1L),0x21C1D0BDL,0x21C1D0BDL},{5L,5L,0x936957EDL,(-5L)},{(-10L),0x499E3EE7L,(-1L),0xE42D8840L},{0L,0x78EE15BCL,1L,(-1L)}},{{(-8L),0x78EE15BCL,0xE09E57DEL,0xE42D8840L},{0x78EE15BCL,0x499E3EE7L,0L,(-5L)},{0x4172952EL,5L,0x37787B13L,0x21C1D0BDL},{0L,(-1L),0L,(-7L)},{0x8623BDA8L,0x11EAD066L,0x56910139L,0x50843491L},{(-8L),(-1L),0xB565F307L,0xA87EBFDDL},{0xB1FA6BB9L,(-6L),0x1EA8AA35L,0x9B336050L}},{{0x56910139L,(-10L),(-5L),0xB1ABEEF0L},{(-1L),0L,0xBCAE8C47L,0x499E3EE7L},{(-1L),0x67712C6FL,0xD81C2876L,0xA9460C90L},{(-10L),(-1L),0x13EF272DL,(-6L)},{0x715D0604L,0x2F5EFE42L,0x78344C52L,0x56B34985L},{0xB1ABEEF0L,0xB5F1E210L,5L,0x67712C6FL},{0x56B34985L,0x89DF08E3L,1L,0x8A8C7A9EL}},{{0x0319C8F8L,0x3B262F1CL,0xE3C4BC05L,0xA0AF8A11L},{0x45D00231L,0xCC2EEE50L,0x6C8C2795L,0xBF797063L},{0x4BD17B8DL,1L,0x45100B26L,0x3B262F1CL},{(-1L),0x936957EDL,0x8623BDA8L,1L},{1L,0x8D95481CL,(-8L),0x70999010L},{(-6L),(-8L),0xA0AF8A11L,(-4L)},{1L,0xCE72BB5FL,0x2F5EFE42L,0x13EF272DL}},{{(-2L),(-8L),(-1L),(-1L)},{0x78344C52L,0L,(-1L),(-2L)},{(-4L),0xB565F307L,0x23021CABL,0x85FCAB3EL},{0xCC7E540FL,0x50843491L,0xCC7E540FL,(-1L)},{0x45100B26L,0xBCAE8C47L,0xB1FA6BB9L,0x6D199536L},{0x936957EDL,0x200E6442L,0x67712C6FL,0xBCAE8C47L},{0x70382BBDL,0x23021CABL,0x67712C6FL,0x56910139L}},{{0x936957EDL,(-10L),0xB1FA6BB9L,0L},{0x45100B26L,0x9FFAA137L,0xCC7E540FL,0x4172952EL},{0xCC7E540FL,0x4172952EL,0x23021CABL,0x57C6DD80L},{(-4L),1L,0x238DBA56L,0xB565F307L},{(-7L),0L,1L,0L},{0x3A81B259L,9L,0xA87EBFDDL,(-1L)},{0L,(-5L),(-5L),0x4BD17B8DL}},{{0x764D3500L,(-9L),0xCC7E540FL,0x85FCAB3EL},{0x23021CABL,0x0C46E84AL,0x546D6A2CL,6L},{(-1L),0x24ADC847L,6L,0xD727C1C1L},{0x37AA0864L,0L,0xB5F1E210L,0xBF797063L},{(-10L),(-3L),0x8623BDA8L,0x0319C8F8L},{(-1L),0x200E6442L,0L,0x57C6DD80L},{0L,0xA9460C90L,0x715D0604L,0xCE72BB5FL}},{{0xE3C4BC05L,0xBCAE8C47L,(-7L),0xD81C2876L},{1L,5L,(-1L),0xB5F1E210L},{0xB1FA6BB9L,0x85FCAB3EL,0x78344C52L,1L},{(-10L),(-6L),0x21C1D0BDL,0L},{0x50843491L,6L,(-3L),0x23021CABL},{0xB1ABEEF0L,0x57C6DD80L,0x8A8C7A9EL,0x936957EDL},{(-8L),0L,(-6L),0xD808EE5CL}}};
                    int i, j, k;
                    if ((safe_lshift_func_uint64_t_u_u((p_10 ^ (safe_rshift_func_int64_t_s_s((-3L), (l_3353 == ((g_1343[g_1652.f1][g_1969.f0] , ((safe_mul_func_uint32_t_u_u((safe_add_func_int16_t_s_s((~((safe_add_func_int64_t_s_s((((((~(*g_100)) >= (l_3452 & (l_3263[3][0][3] = (((((safe_mul_func_uint8_t_u_u(((safe_mul_func_int32_t_s_s((safe_rshift_func_uint32_t_u_s((p_10 <= 3UL), 21)), l_3324[9][8])) & l_3409[0][2][1]), g_106)) , 0x1BBBL) ^ p_9) <= 7UL) == 65535UL)))) <= (*l_3233)) || l_3313[2][0][0]) ^ 0L), l_3473)) && 1L)), l_3313[0][7][1])), 0x152A45BDL)) || l_3474)) < l_3475))))), p_9)))
                    { /* block id: 1439 */
                        int16_t l_3477 = 3L;
                        int32_t l_3479 = (-5L);
                        l_3480++;
                        return (*l_3236);
                    }
                    else
                    { /* block id: 1442 */
                        int32_t l_3485 = (-5L);
                        int8_t *l_3495 = &g_429.f0;
                        (*g_383) = &l_3476[4][3][1];
                        (*l_3233) = (l_3496 = (l_3324[9][8] ^ (((safe_mod_func_uint16_t_u_u(l_3485, (safe_mod_func_uint64_t_u_u(((safe_mul_func_int8_t_s_s(p_11, (safe_mod_func_int64_t_s_s((((0UL ^ (((*l_3236) ^= (safe_lshift_func_uint32_t_u_u((l_3263[5][0][6] = (0x3EL ^ (g_3494 , (((*l_3495) = l_3354[1][3]) || 250UL)))), p_9))) & 4L)) || 18446744073709551612UL) || p_11), 0xF330369919BE8BBCLL)))) , l_3478[1]), l_3476[6][6][0])))) == 0x6F28L) ^ l_3313[0][7][1])));
                    }
                }
            }
        }
        if (((*l_3233) | (g_2599.f0 > (0x7156L & ((safe_mul_func_uint64_t_u_u((((((void*)0 != &g_2365) <= (safe_rshift_func_int8_t_s_s(p_10, 6))) , l_3501) == &g_2366), (~(l_3238 = ((safe_mod_func_int16_t_s_s((safe_sub_func_int16_t_s_s(((safe_mod_func_uint16_t_u_u(l_3478[5], 0xCB52L)) , (-1L)), 0x466BL)), 65529UL)) || 18446744073709551615UL))))) >= 18446744073709551609UL)))))
        { /* block id: 1454 */
            (*l_3235) ^= 0xF6E3033BL;
            (*g_383) = &l_3478[2];
            for (g_651 = 0; (g_651 <= 6); g_651 += 1)
            { /* block id: 1459 */
                int i;
                (****g_1242) = &l_3478[g_651];
                return l_3478[g_2418.f0];
            }
        }
        else
        { /* block id: 1463 */
            int32_t l_3510 = 0x5EB64C97L;
            uint32_t ***l_3524 = (void*)0;
            uint32_t ****l_3523 = &l_3524;
            int32_t l_3530 = 0x362081BBL;
            int32_t l_3535 = 1L;
            int32_t l_3536 = 0x83348093L;
            struct S0 ** const * const **l_3614 = (void*)0;
            int64_t ***l_3627[5];
            int32_t l_3640 = 0L;
            int32_t l_3641 = 0x3F881101L;
            int32_t l_3642[5][2] = {{0x7C92BFECL,0x7C92BFECL},{0x7C92BFECL,0x13077122L},{(-1L),0xAA76D7A1L},{0x13077122L,0xAA76D7A1L},{(-1L),0x13077122L}};
            int64_t l_3654 = 1L;
            int64_t l_3660 = (-6L);
            int i, j;
            for (i = 0; i < 5; i++)
                l_3627[i] = (void*)0;
            for (g_3408 = 1; (g_3408 >= 0); g_3408 -= 1)
            { /* block id: 1466 */
                if (((*l_3236) = 0x85C7F737L))
                { /* block id: 1468 */
                    return g_3209.f0;
                }
                else
                { /* block id: 1470 */
                    return l_3510;
                }
            }
            for (g_1879.f1 = 1; (g_1879.f1 <= 7); g_1879.f1 += 1)
            { /* block id: 1476 */
                int32_t l_3527 = 0x4BC1B410L;
                int32_t l_3531 = 0L;
                union U2 ***l_3597 = &g_2661;
                int32_t *l_3613 = &l_3241;
                int32_t l_3644 = (-1L);
                int32_t l_3645 = 0xBF6B7319L;
                int32_t l_3650 = 0x357987FEL;
                int32_t l_3652 = 0x6826B175L;
                int32_t l_3653 = 0xEA8E2BD6L;
                int32_t l_3656 = (-1L);
                int32_t l_3657 = 0L;
                int32_t l_3659 = 1L;
                for (g_223.f1 = 0; (g_223.f1 <= 1); g_223.f1 += 1)
                { /* block id: 1479 */
                    const int8_t l_3517 = (-1L);
                    uint32_t *l_3519 = (void*)0;
                    uint32_t *l_3520 = &l_3314;
                    int16_t l_3525 = (-7L);
                    int32_t l_3528 = 1L;
                    int32_t l_3534 = 0x1BBA8A63L;
                    int32_t l_3538 = (-1L);
                    int32_t l_3553[3];
                    int32_t l_3567 = 1L;
                    uint16_t *****l_3580[2];
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_3553[i] = 0x9961FB5AL;
                    for (i = 0; i < 2; i++)
                        l_3580[i] = &g_2541;
                    if ((safe_add_func_int8_t_s_s((p_10 = g_1798[0].f3), (safe_rshift_func_int16_t_s_s(((p_9 ^ (l_3517 != (**g_1100))) == (((!(++(*l_3520))) && p_11) > ((((((void*)0 == l_3523) , l_3525) > ((((safe_unary_minus_func_uint32_t_u(((g_1343[(g_223.f1 + 1)][g_223.f1] , 0x4D037FD180AC823FLL) || 1UL))) > 0xED4983C0A7A41C0DLL) == l_3478[4]) != 251UL)) <= l_3525) != l_3527))), 0)))))
                    { /* block id: 1482 */
                        uint8_t l_3529 = 0x10L;
                        (*l_3236) = (l_3478[2] & (l_3528 = p_10));
                        (*l_3236) = (8UL >= (((*l_3520) = p_11) != p_10));
                        if (l_3529)
                            continue;
                        if ((*g_2363))
                            continue;
                    }
                    else
                    { /* block id: 1489 */
                        int32_t l_3532 = 0x3D61C8B9L;
                        int32_t l_3533 = (-1L);
                        int32_t l_3537 = 0x7FE57C3DL;
                        int i, j, k;
                        --l_3539[0];
                    }
                    if (p_10)
                    { /* block id: 1492 */
                        int32_t l_3581 = 0x5AC9755BL;
                        (*l_3234) ^= (safe_mul_func_int32_t_s_s((safe_sub_func_int16_t_s_s(g_789.f1, (g_2418.f0 | (g_3546 , (((safe_div_func_uint64_t_u_u((safe_rshift_func_int64_t_s_u((((safe_rshift_func_uint64_t_u_s(p_9, 54)) ^ l_3553[2]) , (safe_add_func_uint16_t_u_u(((safe_add_func_int64_t_s_s(((*g_609) = ((safe_add_func_uint16_t_u_u(p_9, ((safe_add_func_int64_t_s_s((*g_609), (safe_sub_func_int64_t_s_s(l_3239, (-10L))))) != l_3536))) | 0xD106L)), 0x84A59D6D408EECB6LL)) > 4294967295UL), (*l_3236)))), p_11)), p_9)) , g_3564) , g_313.f2))))), 1L));
                        (*l_3234) = l_3538;
                        l_3581 |= ((0xE183L && (safe_mul_func_uint16_t_u_u(65532UL, ((l_3567 >= ((p_11 == (((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u((safe_lshift_func_uint32_t_u_s(((safe_mul_func_int64_t_s_s((safe_rshift_func_int32_t_s_s(((*l_3235) = ((((g_3578 , (0x6497L <= (((safe_unary_minus_func_int64_t_s((0xFAL < (p_10 || (((l_3580[0] == (void*)0) ^ l_3553[2]) <= p_11))))) == p_11) , 65527UL))) , l_3238) != 0UL) , l_3243)), p_11)), p_10)) < 0x38L), l_3531)), 6)) || p_10), p_9)) >= p_10) , l_3238)) >= l_3567)) >= 251UL)))) >= 0xFF0D4CC1L);
                    }
                    else
                    { /* block id: 1498 */
                        int32_t *l_3594[3];
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_3594[i] = &l_3230;
                        (*g_383) = ((l_3528 &= (safe_lshift_func_uint8_t_u_u(((g_3584 , ((safe_lshift_func_int64_t_s_s((p_9 , ((safe_mul_func_int8_t_s_s((safe_sub_func_int64_t_s_s((((safe_div_func_int64_t_s_s(p_9, (-1L))) > ((((**g_1389) , (((((l_3593[1] , l_3553[2]) , l_3510) ^ 0x473B7F31L) >= 0xB8B4E40719D09737LL) | 0x00E948D6L)) > p_11) != l_3531)) >= p_9), l_3510)), p_11)) , (*g_609))), 18)) , (**g_1100))) , p_10), p_10))) , l_3594[2]);
                    }
                    for (g_1412.f1 = 0; (g_1412.f1 <= 0); g_1412.f1 += 1)
                    { /* block id: 1504 */
                        return g_3408;
                    }
                }
                (*l_3233) ^= ((safe_add_func_int16_t_s_s(((l_3238 = (((*l_3247) = l_3597) == (void*)0)) == ((!p_9) >= ((((void*)0 == l_3599) | (safe_mul_func_uint16_t_u_u((safe_sub_func_int32_t_s_s((+p_9), ((safe_div_func_uint64_t_u_u((safe_add_func_uint16_t_u_u((((-4L) && 0L) || (safe_sub_func_int16_t_s_s((l_3535 != 1L), 0xA511L))), p_9)), l_3243)) && 0x1F12F49FL))), 65535UL))) < p_11))), p_10)) < p_11);
                (***g_1243) = &l_3531;
                for (l_3536 = 6; (l_3536 >= 1); l_3536 -= 1)
                { /* block id: 1514 */
                    const uint64_t *l_3619 = &g_1538;
                    int32_t l_3621 = 3L;
                    l_3613 = &l_3527;
                    if (((void*)0 == l_3614))
                    { /* block id: 1516 */
                        (*l_3232) ^= (safe_sub_func_int64_t_s_s((safe_rshift_func_int8_t_s_u(0x80L, 1)), (l_3242 = ((void*)0 != l_3619))));
                    }
                    else
                    { /* block id: 1519 */
                        return g_1560.f0;
                    }
                    if ((l_3620[1][0][1] ^ (l_3621 & (p_11 && ((safe_mod_func_int8_t_s_s(0x1AL, ((65535UL && (g_1635 , (((((1L | ((+(((((*l_3233) &= (safe_rshift_func_uint16_t_u_u((((p_11 = p_9) ^ ((l_3535 = (l_3627[1] == l_3628)) | (*l_3236))) | g_137), l_3530))) && p_9) && g_1798[0].f0) , p_11)) ^ 0x6772L)) > (*l_3234)) | 0xC7L) == l_3620[1][0][1]) | (-9L)))) ^ (*g_1101)))) < 6L)))))
                    { /* block id: 1525 */
                        int8_t *l_3634[2];
                        int32_t l_3635[5][9][5] = {{{(-1L),(-6L),2L,0x768CD6C8L,0x197B1981L},{0x8C081377L,0L,0x5C52DF96L,0x81014D86L,0x81014D86L},{0x1047CE2EL,0xE7D6BDEDL,0x1047CE2EL,0x9937BAD5L,(-4L)},{0x154B7FBDL,0x8C081377L,0xF7655795L,0xABB2AF10L,5L},{(-2L),2L,(-4L),0x40F867A1L,0x450D050CL},{0L,0x5C52DF96L,0xF7655795L,5L,0x0282125AL},{(-10L),(-4L),0x1047CE2EL,0x353CD32EL,0x96469E66L},{(-1L),0xE20A130AL,0x5C52DF96L,0x0D7A1B6CL,0x5C52DF96L},{0x9937BAD5L,0x9937BAD5L,2L,0L,0xA437820FL}},{{(-8L),9L,0L,0x154B7FBDL,0L},{0L,9L,0x353CD32EL,(-4L),1L},{0L,9L,(-10L),0L,0xE0B8459FL},{0x18E93451L,0x9937BAD5L,(-1L),0xD71CB18BL,(-2L)},{(-10L),0xE20A130AL,0x8022FB20L,0x8022FB20L,0xE20A130AL},{0x450D050CL,(-4L),9L,0xC7184FECL,0x353CD32EL},{0xF13CF9BCL,0x5C52DF96L,(-1L),0xE0B8459FL,0x8022FB20L},{0xA437820FL,2L,0x44CC2C7CL,(-1L),0L},{0xF13CF9BCL,0x8C081377L,0x0D7A1B6CL,9L,0L}},{{0x450D050CL,0xE7D6BDEDL,0x197B1981L,(-10L),0xC7184FECL},{(-10L),0L,0xE20A130AL,0L,(-10L)},{0x18E93451L,(-6L),(-10L),1L,0x9937BAD5L},{0L,1L,4L,0xD6A712E6L,0L},{0x197B1981L,2L,0x96469E66L,0x442C3CB0L,1L},{0x154B7FBDL,0xF13CF9BCL,6L,5L,0x0D7A1B6CL},{1L,(-2L),0x18E93451L,0L,(-4L)},{0x5C52DF96L,0x81014D86L,0x81014D86L,0x5C52DF96L,0L},{0x44CC2C7CL,0L,(-10L),(-1L),2L}},{{(-10L),0L,0x0282125AL,(-1L),0x44C5BF76L},{0L,0x197B1981L,(-4L),(-1L),0xA437820FL},{0x81014D86L,0xF7655795L,(-10L),0x5C52DF96L,0xABB2AF10L},{0x40F867A1L,0xA437820FL,9L,0L,0L},{0xD6A712E6L,0x8022FB20L,0xD6A712E6L,5L,0x8C081377L},{(-2L),0x40F867A1L,0x768CD6C8L,0x442C3CB0L,0xC7184FECL},{9L,0x0D7A1B6CL,0x8C081377L,0xF13CF9BCL,0x9B00D86CL},{2L,9L,0x768CD6C8L,0xC7184FECL,0x450D050CL},{4L,0x8C081377L,0xD6A712E6L,0x0282125AL,0x2C1FA3C9L}},{{0x96469E66L,(-6L),9L,0x44CC2C7CL,9L},{5L,5L,(-10L),1L,0L},{(-1L),0L,(-4L),(-2L),0xE7D6BDEDL},{0xE20A130AL,6L,0x0282125AL,0x8C081377L,0L},{0xA437820FL,0L,(-10L),(-4L),0x1047CE2EL},{(-8L),5L,0x81014D86L,0x44C5BF76L,9L},{(-10L),(-6L),0x18E93451L,0x18E93451L,(-6L)},{0x9B00D86CL,0x8C081377L,6L,0xE0B8459FL,0x0282125AL},{2L,9L,0x96469E66L,0x1047CE2EL,0x18E93451L}}};
                        int32_t l_3636 = 1L;
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_3634[i] = (void*)0;
                        (*l_3235) |= (safe_sub_func_uint64_t_u_u(((l_3635[1][3][4] = (0x2F57BDB1A33AA22ELL && p_9)) < (p_9 > (l_3636 < g_2211))), ((*g_609) = p_9)));
                        (*g_383) = &l_3531;
                    }
                    else
                    { /* block id: 1530 */
                        if (p_11)
                            break;
                    }
                    (*l_3232) = 0L;
                }
                for (l_3480 = 0; (l_3480 <= 1); l_3480 += 1)
                { /* block id: 1537 */
                    int32_t l_3638 = (-4L);
                    int32_t l_3643 = 1L;
                    int32_t l_3646 = 0x597A8541L;
                    int32_t l_3647 = (-5L);
                    int32_t l_3649 = 0xBC86C60BL;
                    int32_t l_3651 = 0xF869A775L;
                    int32_t l_3655 = (-2L);
                    int32_t l_3658 = (-1L);
                    int32_t l_3662 = 6L;
                    int32_t l_3663 = 0x15284E3CL;
                    uint64_t l_3664[1];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_3664[i] = 0UL;
                    l_3664[0]++;
                }
            }
            g_3667++;
        }
        for (l_3480 = 0; (l_3480 <= 1); l_3480 += 1)
        { /* block id: 1545 */
            uint16_t l_3670 = 1UL;
            --l_3670;
        }
    }
    return l_3593[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_1412.f1 g_2363 g_281 g_1401 g_1100 g_1101 g_49 g_887 g_137 g_609 g_2540 g_383 g_1242 g_1243 g_1244 g_1511.f0 g_213.f0 g_2586 g_313.f1 g_1253 g_220 g_2599.f3 g_2605 g_2629 g_361 g_362 g_100 g_101 g_103 g_1248 g_2653 g_2659 g_2585 g_1142 g_2679 g_2717 g_1690.f3 g_2211 g_2550 g_2769 g_2775 g_212 g_213 g_2797 g_1690.f0 g_1879.f1 g_429.f0 g_1341.f0 g_774 g_805 g_1635 g_589 g_590 g_1459.f1 g_2885 g_1389 g_1390 g_1261 g_2911 g_2301 g_2912 g_2679.f0 g_374.f0 g_1713 g_1022 g_2925 g_1811.f3 g_1811.f2 g_1690 g_2481 g_3033 g_619.f2
 * writes: g_1412.f1 g_1811.f1 g_620.f2 g_137 g_1830.f1 g_2481.f1 g_220 g_2540 g_112 g_2211 g_1188.f1 g_2550 g_375.f1 g_82 g_2584 g_1253 g_1969.f0 g_1022 g_1458 g_106 g_559 g_1538 g_1142 g_281 g_2704 g_49 g_103 g_1459.f0 g_1244 g_1043 g_429.f0 g_1459.f1 g_1816.f1 g_1188.f0
 */
static int32_t  func_14(int32_t  p_15, int32_t  p_16, uint64_t  p_17, uint32_t  p_18, int8_t  p_19)
{ /* block id: 1048 */
    int8_t l_2475 = 1L;
    int32_t l_2476 = 0x48A3A0DCL;
    union U4 *l_2478[6] = {&g_957,&g_957,&g_957,&g_957,&g_957,&g_957};
    union U4 *l_2480 = &g_2481[0];
    int32_t l_2524 = 0x17210F96L;
    int32_t l_2525 = (-9L);
    int32_t l_2526 = 0x7A495DBEL;
    int32_t l_2527 = 0xD2EC01F3L;
    int32_t l_2528 = 0x20C45AA4L;
    int32_t l_2529[9][4][5] = {{{(-1L),0x2FADD9ADL,9L,0x0FB63536L,0xE4586CE5L},{4L,4L,0xF62A4687L,0x58CAF79BL,0x186CB05AL},{0x2FADD9ADL,(-1L),0xCEC532FDL,3L,0xF62A4687L},{0x844725A1L,(-1L),0L,0x39E4F21EL,0x39E4F21EL}},{{0x64F1D188L,1L,0x64F1D188L,(-6L),0xE6579434L},{(-1L),8L,0x2FADD9ADL,0xB5AB167AL,0x50F36B81L},{0xE426FEC0L,0x50F36B81L,0x186CB05AL,0x5A3B67BFL,(-1L)},{0x3AA410E6L,8L,0x2FADD9ADL,0x50F36B81L,(-1L)}},{{0x58CAF79BL,0x0AA4413BL,0x64F1D188L,0x74DB1BB4L,(-4L)},{0xEAF6B242L,0L,0L,(-7L),0xEBB6E580L},{0xACAF1DAAL,0xE4586CE5L,0xCEC532FDL,0xB0EA905FL,0x22B3ADCDL},{9L,0x39E4F21EL,0xF62A4687L,(-2L),3L}},{{8L,8L,9L,0xD83AAD2DL,1L},{5L,3L,0x74DB1BB4L,8L,0L},{0xD4D990BCL,0xDA77ED37L,0xE69865A0L,7L,0x844725A1L},{0xCEC532FDL,0xDA77ED37L,9L,4L,0x5A3B67BFL}},{{0x2FADD9ADL,0x74773F13L,0L,0L,(-6L)},{(-7L),1L,0xE426FEC0L,8L,9L},{0xE4586CE5L,0x50F36B81L,(-2L),0x64F1D188L,0xF1821C2EL},{(-4L),0x27834784L,1L,8L,0x45113D90L}},{{4L,8L,0xEBB6E580L,0xEBB6E580L,8L},{0x59026B5FL,(-7L),9L,1L,2L},{9L,0L,1L,4L,0L},{0x25068C64L,(-1L),0xDA77ED37L,0L,(-6L)}},{{9L,2L,0x39E4F21EL,0x27834784L,(-1L)},{0x59026B5FL,4L,(-1L),3L,(-1L)},{4L,0xD83AAD2DL,0xFF2C7419L,(-6L),5L},{(-4L),0xEBB6E580L,2L,0x59026B5FL,0xE6D46F17L}},{{0xE4586CE5L,0xD4D990BCL,8L,0xCEC532FDL,0L},{(-7L),0xACAF1DAAL,3L,0xB5AB167AL,7L},{0x2FADD9ADL,3L,0x15BA079EL,(-7L),9L},{0xCEC532FDL,5L,(-1L),3L,9L}},{{0xD4D990BCL,0xD6CF3194L,0x5FAB8D9AL,2L,7L},{0x39E4F21EL,2L,3L,(-1L),0L},{0L,0x3AA410E6L,(-1L),2L,0xE6D46F17L},{8L,7L,(-7L),0L,5L}}};
    uint32_t l_2543[4] = {1UL,1UL,1UL,1UL};
    struct S0 *l_2597 = &g_1798[0];
    int32_t l_2609 = (-9L);
    int64_t l_2617 = 0xB507B07FD7D7B458LL;
    union U4 *l_2625 = (void*)0;
    int8_t l_2689 = 9L;
    const int32_t **l_2878 = &g_805;
    const int32_t ***l_2877 = &l_2878;
    union U3 *l_2920[6];
    uint32_t **l_2931 = &g_591[3][5];
    uint16_t *****l_2935 = &g_2541;
    uint8_t ****l_3000 = &g_1053;
    uint32_t l_3047 = 18446744073709551608UL;
    int8_t *l_3071 = &l_2689;
    int8_t **l_3070 = &l_3071;
    uint8_t l_3092[2];
    uint64_t l_3149 = 0xDE2758AD3C50895CLL;
    int64_t ****l_3205 = &g_1228[3][2][0];
    int64_t *****l_3204 = &l_3205;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_2920[i] = &g_223;
    for (i = 0; i < 2; i++)
        l_3092[i] = 1UL;
    if ((l_2476 = l_2475))
    { /* block id: 1050 */
        uint16_t l_2482 = 0UL;
        int32_t l_2530 = 0x5E7189BFL;
        int32_t l_2532 = 7L;
        int32_t l_2534[6];
        uint64_t l_2535 = 0xE7354F742FC1B85DLL;
        int64_t ***l_2621 = &g_608;
        union U1 **l_2723 = &g_1352;
        union U1 ***l_2722 = &l_2723;
        uint16_t l_2729 = 0xE943L;
        int i;
        for (i = 0; i < 6; i++)
            l_2534[i] = (-9L);
        for (g_1412.f1 = 7; (g_1412.f1 >= 2); g_1412.f1 -= 1)
        { /* block id: 1053 */
            union U4 **l_2477[2][4][2] = {{{(void*)0,(void*)0},{(void*)0,&g_1458},{&g_1458,(void*)0},{&g_1458,(void*)0}},{{&g_1458,&g_1458},{(void*)0,(void*)0},{(void*)0,&g_1458},{&g_1458,(void*)0}}};
            int32_t l_2483 = (-1L);
            int32_t l_2514 = 0x4B9DE196L;
            int32_t l_2517 = 0L;
            int32_t l_2520 = 7L;
            int32_t l_2531 = 0x5EA37452L;
            int32_t l_2533[8][8][4] = {{{0L,0L,0L,(-5L)},{0x4FA88B40L,0L,0x8E06C9E7L,(-1L)},{0x8E06C9E7L,(-1L),0L,0x3678ECB3L},{0x8E06C9E7L,0xAC2C1A54L,0x8E06C9E7L,0x7920A1B4L},{0x4FA88B40L,0x3678ECB3L,0L,0x7920A1B4L},{0L,0xAC2C1A54L,0x0EFC37CBL,0x3678ECB3L},{3L,(-1L),0x0EFC37CBL,(-1L)},{0L,0L,0L,(-5L)}},{{0x4FA88B40L,0L,0x8E06C9E7L,(-1L)},{0x8E06C9E7L,(-1L),0L,0x3678ECB3L},{0x8E06C9E7L,0xAC2C1A54L,0x8E06C9E7L,0x7920A1B4L},{0x4FA88B40L,0x3678ECB3L,0L,0x7920A1B4L},{0L,0xAC2C1A54L,0x0EFC37CBL,0x3678ECB3L},{3L,(-1L),0x0EFC37CBL,(-1L)},{0L,0L,0L,(-5L)},{0x8E06C9E7L,0x3678ECB3L,3L,0L}},{{3L,0L,0xD192981EL,0x7920A1B4L},{3L,0x411E5FBFL,3L,(-5L)},{0x8E06C9E7L,0x7920A1B4L,0x0EFC37CBL,(-5L)},{0xD192981EL,0x411E5FBFL,0L,0x7920A1B4L},{0L,0L,0L,0L},{0xD192981EL,0x3678ECB3L,0x0EFC37CBL,0xAC2C1A54L},{0x8E06C9E7L,0x3678ECB3L,3L,0L},{3L,0L,0xD192981EL,0x7920A1B4L}},{{3L,0x411E5FBFL,3L,(-5L)},{0x8E06C9E7L,0x7920A1B4L,0x0EFC37CBL,(-5L)},{0xD192981EL,0x411E5FBFL,0L,0x7920A1B4L},{0L,0L,0L,0L},{0xD192981EL,0x3678ECB3L,0x0EFC37CBL,0xAC2C1A54L},{0x8E06C9E7L,0x3678ECB3L,3L,0L},{3L,0L,0xD192981EL,0x7920A1B4L},{3L,0x411E5FBFL,3L,(-5L)}},{{0x8E06C9E7L,0x7920A1B4L,0x0EFC37CBL,(-5L)},{0xD192981EL,0x411E5FBFL,0L,0x7920A1B4L},{0L,0L,0L,0L},{0xD192981EL,0x3678ECB3L,0x0EFC37CBL,0xAC2C1A54L},{0x8E06C9E7L,0x3678ECB3L,3L,0L},{3L,0L,0xD192981EL,0x7920A1B4L},{3L,0x411E5FBFL,3L,(-5L)},{0x8E06C9E7L,0x7920A1B4L,0x0EFC37CBL,(-5L)}},{{0xD192981EL,0x411E5FBFL,0L,0x7920A1B4L},{0L,0L,0L,0L},{0xD192981EL,0x3678ECB3L,0x0EFC37CBL,0xAC2C1A54L},{0x8E06C9E7L,0x3678ECB3L,3L,0L},{3L,0L,0xD192981EL,0x7920A1B4L},{3L,0x411E5FBFL,3L,(-5L)},{0x8E06C9E7L,0x7920A1B4L,0x0EFC37CBL,(-5L)},{0xD192981EL,0x411E5FBFL,0L,0x7920A1B4L}},{{0L,0L,0L,0L},{0xD192981EL,0x3678ECB3L,0x0EFC37CBL,0xAC2C1A54L},{0x8E06C9E7L,0x3678ECB3L,3L,0L},{3L,0L,0xD192981EL,0x7920A1B4L},{3L,0x411E5FBFL,3L,(-5L)},{0x8E06C9E7L,0x7920A1B4L,0x0EFC37CBL,(-5L)},{0xD192981EL,0x411E5FBFL,0L,0x7920A1B4L},{0L,0L,0L,0L}},{{0xD192981EL,0x3678ECB3L,0x0EFC37CBL,0xAC2C1A54L},{0x8E06C9E7L,0x3678ECB3L,3L,0L},{3L,0L,0xD192981EL,0x7920A1B4L},{3L,0x411E5FBFL,3L,(-5L)},{0x8E06C9E7L,0x7920A1B4L,0x0EFC37CBL,(-5L)},{0xD192981EL,0x411E5FBFL,0L,0x7920A1B4L},{0L,0L,0xD192981EL,0x3678ECB3L},{0x4FA88B40L,0x7920A1B4L,0L,0x411E5FBFL}}};
            struct S0 *l_2598 = &g_2599;
            uint8_t l_2618 = 0x1BL;
            int i, j, k;
            l_2480 = (l_2478[0] = &g_957);
            for (g_1811.f1 = 0; (g_1811.f1 <= 7); g_1811.f1 += 1)
            { /* block id: 1058 */
                uint64_t l_2488 = 1UL;
                int32_t l_2510 = 7L;
                int32_t l_2511 = (-1L);
                int32_t l_2512 = 1L;
                int32_t l_2516 = 2L;
                int32_t l_2518 = 0L;
                int32_t l_2519 = 0L;
                int32_t l_2522 = 0x4C8BBC05L;
                int32_t l_2523[8] = {9L,6L,9L,9L,6L,9L,9L,6L};
                int i;
                l_2483 = l_2482;
                for (g_620.f2 = 0; (g_620.f2 <= 5); g_620.f2 += 1)
                { /* block id: 1062 */
                    const int32_t l_2497 = 0xBA73491EL;
                    int32_t l_2502 = (-1L);
                    int8_t *l_2503 = &g_1830.f1;
                    int8_t *l_2504 = &g_2481[0].f1;
                    int32_t l_2513 = 0xC415D9A1L;
                    int32_t l_2515[7] = {0xC4299256L,0xC4299256L,0xC4299256L,0xC4299256L,0xC4299256L,0xC4299256L,0xC4299256L};
                    int8_t l_2521 = (-1L);
                    int32_t * const *l_2549 = &g_112[1];
                    int32_t * const **l_2548 = &l_2549;
                    int32_t * const ***l_2547[10][4] = {{&l_2548,(void*)0,&l_2548,&l_2548},{(void*)0,&l_2548,&l_2548,&l_2548},{&l_2548,(void*)0,&l_2548,&l_2548},{&l_2548,&l_2548,&l_2548,&l_2548},{&l_2548,&l_2548,(void*)0,(void*)0},{&l_2548,&l_2548,&l_2548,&l_2548},{&l_2548,&l_2548,&l_2548,&l_2548},{&l_2548,&l_2548,(void*)0,(void*)0},{&l_2548,&l_2548,&l_2548,&l_2548},{&l_2548,&l_2548,&l_2548,&l_2548}};
                    int32_t * const ****l_2546 = &l_2547[9][1];
                    int i, j;
                    if ((*g_2363))
                        break;
                    if ((safe_mod_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(((*g_609) = ((l_2488 > ((g_1401 || (safe_unary_minus_func_uint16_t_u((0x932BB5B332C8177FLL != (**g_1100))))) < p_16)) >= (safe_sub_func_uint32_t_u_u((safe_unary_minus_func_int8_t_s(((*l_2504) = (safe_add_func_uint32_t_u_u(((safe_mod_func_int16_t_s_s(l_2497, (l_2488 || p_17))) & ((*g_887)++)), (safe_div_func_int8_t_s_s(((*l_2503) = (l_2502 | p_16)), p_18))))))), p_17)))), p_15)), (-1L))))
                    { /* block id: 1068 */
                        int32_t *l_2505 = &l_2476;
                        int32_t *l_2506 = &l_2483;
                        int32_t *l_2507 = &g_281;
                        int32_t *l_2508 = &l_2483;
                        int32_t *l_2509[8][5] = {{&l_2476,&l_2476,(void*)0,(void*)0,&g_103},{(void*)0,(void*)0,&l_2476,(void*)0,(void*)0},{&g_103,(void*)0,(void*)0,&l_2476,&l_2476},{(void*)0,(void*)0,(void*)0,&g_2244,(void*)0},{&g_103,&l_2476,(void*)0,(void*)0,&l_2476},{(void*)0,&g_2244,&l_2476,&g_2244,(void*)0},{&l_2476,(void*)0,(void*)0,&l_2476,&g_103},{(void*)0,&g_2244,(void*)0,(void*)0,(void*)0}};
                        int i, j;
                        --l_2535;
                        l_2483 &= l_2524;
                        p_16 = (safe_add_func_int16_t_s_s(p_16, ((g_2540 = g_2540) == (p_18 , &g_1028[(g_620.f2 + 1)][g_620.f2]))));
                        l_2543[0]++;
                    }
                    else
                    { /* block id: 1074 */
                        l_2532 |= ((void*)0 != l_2546);
                    }
                    (*g_383) = &l_2533[6][6][3];
                }
                p_16 ^= ((void*)0 != &g_1075[1]);
            }
            for (g_2211 = 7; (g_2211 >= 0); g_2211 -= 1)
            { /* block id: 1083 */
                int16_t *l_2560[2];
                int32_t l_2561 = 0L;
                uint32_t *l_2562[2][4] = {{&g_140.f1,&g_140.f1,&g_140.f1,&g_140.f1},{&g_140.f1,&g_140.f1,&g_140.f1,&g_140.f1}};
                const uint16_t *l_2574 = (void*)0;
                const uint16_t **l_2573 = &l_2574;
                const uint16_t ***l_2572 = &l_2573;
                const uint16_t ****l_2571 = &l_2572;
                const uint16_t *****l_2570 = &l_2571;
                struct S0 ****l_2583 = &g_1142;
                struct S0 *****l_2582 = &l_2583;
                const struct S0 *****l_2590 = &g_2587[0][0];
                int32_t l_2596 = 0x08AAB3CDL;
                int32_t l_2610 = 0L;
                int32_t l_2612 = 1L;
                int32_t l_2613 = (-8L);
                int32_t l_2614 = 0L;
                int32_t l_2616[3];
                union U3 *l_2623 = &g_375;
                int i, j;
                for (i = 0; i < 2; i++)
                    l_2560[i] = &g_1048;
                for (i = 0; i < 3; i++)
                    l_2616[i] = 8L;
                if (l_2482)
                    break;
                for (g_1188.f1 = 1; (g_1188.f1 <= 5); g_1188.f1 += 1)
                { /* block id: 1087 */
                    g_2550 = ((****g_1242) = &l_2534[4]);
                }
                if (p_19)
                    continue;
                l_2533[7][3][3] = (safe_div_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u((p_18 >= (safe_sub_func_int64_t_s_s(p_16, (p_16 == (+(p_19 & p_16)))))), p_17)) >= ((g_375.f1 = ((safe_add_func_uint64_t_u_u((0x3112L != (l_2561 |= l_2533[6][6][3])), l_2534[4])) || p_16)) , g_1511.f0)), p_18));
                for (g_82 = 1; (g_82 <= 5); g_82 += 1)
                { /* block id: 1097 */
                    uint8_t *l_2591 = (void*)0;
                    uint8_t *l_2592 = (void*)0;
                    int32_t l_2593 = 0L;
                    int32_t l_2594 = 0L;
                    uint32_t *l_2595 = &l_2543[0];
                    uint16_t *l_2607[9][7][3] = {{{&g_2472,&g_559,&g_2472},{&g_2472,&g_559,&l_2482},{&g_2472,&g_2472,&g_2472},{&l_2482,&g_559,&l_2482},{&g_2472,&g_559,&g_559},{(void*)0,&l_2482,&g_559},{&g_559,&g_559,&g_2472}},{{&g_559,&l_2482,(void*)0},{&l_2482,(void*)0,(void*)0},{&l_2482,&g_559,&g_559},{&g_559,(void*)0,(void*)0},{&g_559,&l_2482,&g_2472},{&g_2472,(void*)0,&g_559},{(void*)0,(void*)0,(void*)0}},{{&g_559,&l_2482,&l_2482},{&g_2472,&l_2482,&g_559},{(void*)0,&l_2482,(void*)0},{&g_2472,&l_2482,(void*)0},{(void*)0,(void*)0,&g_559},{&g_2472,(void*)0,(void*)0},{&g_2472,&l_2482,&g_2472}},{{&g_559,(void*)0,(void*)0},{&g_2472,&g_559,(void*)0},{(void*)0,(void*)0,&g_559},{&g_2472,&l_2482,&l_2482},{&g_559,&g_559,&l_2482},{(void*)0,&l_2482,&g_559},{&g_559,&g_559,&g_559}},{{&l_2482,&g_559,&g_559},{&g_2472,&g_2472,&g_559},{&l_2482,&g_2472,(void*)0},{&g_2472,&g_2472,&g_559},{(void*)0,&l_2482,&g_559},{(void*)0,&g_559,&g_559},{(void*)0,&g_559,&g_2472}},{{&g_559,&l_2482,&l_2482},{&g_2472,&g_559,&l_2482},{&g_2472,(void*)0,(void*)0},{&l_2482,(void*)0,&g_559},{&l_2482,&g_2472,&l_2482},{(void*)0,&l_2482,&g_2472},{&l_2482,&g_2472,(void*)0}},{{(void*)0,&g_2472,&g_2472},{&l_2482,&l_2482,&l_2482},{&l_2482,(void*)0,&g_2472},{&l_2482,(void*)0,&g_2472},{&l_2482,&g_2472,&l_2482},{&l_2482,&g_2472,&l_2482},{&l_2482,&l_2482,(void*)0}},{{(void*)0,(void*)0,&g_2472},{&l_2482,&g_559,(void*)0},{(void*)0,&l_2482,(void*)0},{&l_2482,(void*)0,&l_2482},{&l_2482,(void*)0,(void*)0},{&g_2472,&g_2472,&g_2472},{&g_2472,&g_559,&g_559}},{{&g_559,&g_2472,&g_2472},{(void*)0,&g_559,&l_2482},{(void*)0,&l_2482,&l_2482},{(void*)0,&g_2472,&l_2482},{&g_2472,(void*)0,&g_2472},{&l_2482,&g_2472,&g_2472},{&g_2472,&l_2482,&l_2482}}};
                    uint16_t **l_2606[10][1][10] = {{{&l_2607[1][1][2],&g_887,&l_2607[8][0][2],&g_887,&l_2607[1][1][2],&l_2607[0][2][0],&l_2607[8][0][2],&l_2607[0][2][0],&l_2607[1][1][2],&g_887}},{{&l_2607[4][2][2],&g_887,&l_2607[4][2][2],&l_2607[8][5][1],&l_2607[0][2][0],&g_887,&l_2607[0][2][0],&l_2607[8][5][1],&l_2607[4][2][2],&g_887}},{{&l_2607[1][1][2],&l_2607[8][5][1],&l_2607[0][2][0],&l_2607[8][2][0],&l_2607[1][1][2],&l_2607[8][2][0],&l_2607[0][2][0],&l_2607[8][5][1],&l_2607[1][1][2],&l_2607[8][5][1]}},{{&l_2607[0][2][0],&l_2607[8][2][0],&l_2607[4][2][2],&l_2607[0][2][0],&l_2607[4][2][2],&l_2607[8][2][0],&l_2607[0][2][0],&l_2607[0][2][0],&l_2607[0][2][0],&l_2607[8][2][0]}},{{&l_2607[1][1][2],&l_2607[0][2][0],&l_2607[8][0][2],&l_2607[0][2][0],&l_2607[1][1][2],&g_887,&l_2607[8][0][2],&g_887,&l_2607[1][1][2],&l_2607[0][2][0]}},{{&l_2607[4][2][2],&l_2607[0][2][0],&l_2607[4][2][2],&l_2607[8][2][0],&l_2607[0][2][0],&l_2607[0][2][0],&l_2607[0][2][0],&l_2607[8][2][0],&l_2607[4][2][2],&l_2607[0][2][0]}},{{&l_2607[1][1][2],&l_2607[8][2][0],&l_2607[0][2][0],&l_2607[8][5][1],&l_2607[1][1][2],&l_2607[8][5][1],&l_2607[0][2][0],&l_2607[8][2][0],&l_2607[1][1][2],&l_2607[8][2][0]}},{{&l_2607[0][2][0],&l_2607[8][5][1],&l_2607[4][2][2],&g_887,&l_2607[4][2][2],&l_2607[8][5][1],&l_2607[0][2][0],&g_887,&l_2607[0][2][0],&l_2607[8][5][1]}},{{&l_2607[1][1][2],&g_887,&l_2607[8][0][2],&g_887,&l_2607[1][1][2],&l_2607[0][2][0],&l_2607[8][0][2],&l_2607[0][2][0],&l_2607[1][1][2],&g_887}},{{&l_2607[4][2][2],&g_887,&l_2607[4][2][2],&l_2607[8][5][1],&l_2607[0][2][0],&g_887,&l_2607[0][2][0],&l_2607[8][5][1],&l_2607[4][2][2],&g_887}}};
                    int32_t l_2611 = 0xFCB74FB2L;
                    int32_t l_2615[6][8][3] = {{{(-1L),(-1L),0xFFE716FFL},{0x63FF28CFL,1L,0L},{0L,0x4311BA5CL,0x730C32C5L},{(-1L),1L,1L},{1L,(-1L),0x9008CA34L},{(-1L),(-5L),0x7F2A1B3AL},{0L,0x53D2864DL,0x9008CA34L},{0x63FF28CFL,0x1FB75EA5L,1L}},{{(-1L),0x53D2864DL,0x730C32C5L},{0xF832D675L,(-5L),0L},{(-1L),(-1L),0xFFE716FFL},{0x63FF28CFL,1L,0L},{0L,0x4311BA5CL,0x730C32C5L},{(-1L),1L,1L},{1L,(-1L),0x9008CA34L},{(-1L),(-5L),0x7F2A1B3AL}},{{0L,0x53D2864DL,0x9008CA34L},{0x63FF28CFL,0x1FB75EA5L,1L},{(-1L),0x53D2864DL,0x730C32C5L},{0xF832D675L,(-5L),0L},{(-1L),(-1L),0xFFE716FFL},{0x63FF28CFL,1L,0L},{0L,0x4311BA5CL,0x730C32C5L},{(-1L),1L,1L}},{{1L,(-1L),0x9008CA34L},{(-1L),(-5L),0x7F2A1B3AL},{0L,0x53D2864DL,0x9008CA34L},{0x63FF28CFL,0x1FB75EA5L,1L},{(-1L),0x53D2864DL,0x730C32C5L},{0xF832D675L,(-5L),0L},{(-1L),(-1L),0xFFE716FFL},{0x63FF28CFL,1L,0L}},{{0L,0x4311BA5CL,0x730C32C5L},{(-1L),1L,1L},{1L,(-1L),0x9008CA34L},{(-1L),(-5L),0x7F2A1B3AL},{0L,0x53D2864DL,0x9008CA34L},{0x63FF28CFL,0x1FB75EA5L,1L},{(-1L),0x53D2864DL,0x730C32C5L},{0xF832D675L,(-5L),0L}},{{(-1L),(-1L),0xFFE716FFL},{0x63FF28CFL,1L,0L},{0L,0x4311BA5CL,0x730C32C5L},{(-1L),1L,1L},{1L,(-1L),0x9008CA34L},{(-1L),(-5L),0x7F2A1B3AL},{0L,0x53D2864DL,0x9008CA34L},{0x63FF28CFL,0x1FB75EA5L,1L}}};
                    int64_t ***l_2622 = &g_608;
                    struct S0 *l_2626 = &g_2599;
                    int i, j, k;
                    if ((l_2517 == (safe_rshift_func_uint32_t_u_s(((*l_2595) = ((safe_sub_func_uint8_t_u_u(((safe_unary_minus_func_int64_t_s(0xE6E700B07BD41CAFLL)) ^ p_17), (safe_sub_func_uint32_t_u_u((((l_2570 == ((l_2524 = (g_1253[2][4][6] |= (l_2561 = (g_213.f0 < ((safe_mul_func_int64_t_s_s(p_17, (l_2533[6][6][3] ^= (((safe_mul_func_int32_t_s_s((safe_div_func_int16_t_s_s((safe_unary_minus_func_uint16_t_u(((((g_2584[7] = l_2582) == (l_2590 = g_2586[6][2][2])) && (l_2593 = ((void*)0 != &g_1872))) != p_16))), l_2594)), p_19)) , g_313.f1) , l_2594)))) <= 18446744073709551615UL))))) , (void*)0)) , l_2534[4]) & p_16), l_2530)))) || (*g_609))), l_2596))))
                    { /* block id: 1106 */
                        int8_t *l_2603 = (void*)0;
                        int8_t *l_2604 = &g_1969.f0;
                        int32_t *l_2608[3][10][8] = {{{&l_2530,(void*)0,&l_2529[5][1][1],(void*)0,&l_2529[5][1][1],(void*)0,&l_2530,&l_2483},{(void*)0,(void*)0,(void*)0,(void*)0,&l_2530,&l_2528,&l_2483,&g_2244},{&l_2524,(void*)0,&l_2534[0],&g_103,&l_2530,&g_103,&l_2534[0],(void*)0},{(void*)0,(void*)0,&l_2524,&g_2244,&l_2529[5][1][1],&g_103,&l_2529[5][1][1],&l_2534[1]},{&l_2524,&l_2483,&l_2530,(void*)0,&l_2529[5][1][1],(void*)0,&l_2529[5][1][1],(void*)0},{(void*)0,(void*)0,(void*)0,&l_2533[0][3][1],&l_2534[0],&l_2528,(void*)0,(void*)0},{&l_2534[0],&l_2528,(void*)0,(void*)0,&l_2527,&l_2534[1],&l_2534[0],&l_2534[1]},{&l_2534[0],&g_103,&l_2530,&g_103,&l_2534[0],(void*)0,&l_2524,&l_2483},{(void*)0,&g_103,&l_2527,&l_2533[0][3][1],&l_2529[5][1][1],&l_2534[1],(void*)0,&g_103},{&l_2524,&l_2528,&l_2527,&l_2483,&l_2527,&l_2528,&l_2524,&l_2534[1]}},{{&l_2529[5][1][1],(void*)0,&l_2530,&l_2483,&l_2524,(void*)0,&l_2534[0],&g_103},{(void*)0,&l_2483,(void*)0,&l_2533[0][3][1],&l_2524,&l_2533[0][3][1],(void*)0,&l_2483},{&l_2529[5][1][1],&l_2528,(void*)0,&g_103,&l_2527,&l_2533[0][3][1],&l_2529[5][1][1],&l_2534[1]},{&l_2524,&l_2483,&l_2530,(void*)0,&l_2529[5][1][1],(void*)0,&l_2529[5][1][1],(void*)0},{(void*)0,(void*)0,(void*)0,&l_2533[0][3][1],&l_2534[0],&l_2528,(void*)0,(void*)0},{&l_2534[0],&l_2528,(void*)0,(void*)0,&l_2527,&l_2534[1],&l_2534[0],&l_2534[1]},{&l_2534[0],&g_103,&l_2530,&g_103,&l_2534[0],(void*)0,&l_2524,&l_2483},{(void*)0,&g_103,&l_2527,&l_2533[0][3][1],&l_2529[5][1][1],&l_2534[1],(void*)0,&g_103},{&l_2524,&l_2528,&l_2527,&l_2483,&l_2527,&l_2528,&l_2524,&l_2534[1]},{&l_2529[5][1][1],(void*)0,&l_2530,&l_2483,&l_2524,(void*)0,&l_2534[0],&g_103}},{{(void*)0,&l_2483,(void*)0,&l_2533[0][3][1],&l_2524,&l_2533[0][3][1],(void*)0,&l_2483},{&l_2529[5][1][1],&l_2528,(void*)0,&g_103,&l_2527,&l_2533[0][3][1],&l_2529[5][1][1],&l_2534[1]},{&l_2524,&l_2483,&l_2530,(void*)0,&l_2529[5][1][1],(void*)0,&l_2529[5][1][1],(void*)0},{(void*)0,(void*)0,(void*)0,&l_2533[0][3][1],&l_2534[0],&l_2528,(void*)0,(void*)0},{&l_2534[0],&l_2528,(void*)0,(void*)0,&l_2527,&l_2534[1],&l_2534[0],&l_2534[1]},{&l_2534[0],&g_103,&l_2530,&g_103,&l_2534[0],(void*)0,&l_2524,&l_2483},{(void*)0,&g_103,&l_2527,&l_2533[0][3][1],&l_2529[5][1][1],&l_2534[1],(void*)0,&g_103},{&l_2524,&l_2528,&l_2527,&l_2483,&l_2527,(void*)0,(void*)0,&g_2244},{&l_2527,&l_2528,&l_2524,&l_2534[1],(void*)0,&l_2483,(void*)0,&l_2533[0][3][1]},{(void*)0,&l_2534[1],&l_2530,(void*)0,(void*)0,(void*)0,&l_2530,&l_2534[1]}}};
                        int i, j, k;
                        l_2598 = l_2597;
                        l_2483 = (((((*g_887) = (safe_mod_func_uint16_t_u_u(0x499FL, (safe_unary_minus_func_int8_t_s((g_2599.f3 , ((*l_2604) = l_2534[1]))))))) , g_2605) , (void*)0) != (l_2606[8][0][7] = (void*)0));
                        ++l_2618;
                    }
                    else
                    { /* block id: 1113 */
                        union U3 **l_2624 = &g_1022;
                        int32_t l_2630 = 0xEAFC0178L;
                        uint8_t *l_2631 = &g_106;
                        int32_t l_2641 = 0xE0D16FD0L;
                        l_2622 = l_2621;
                        (*l_2624) = l_2623;
                        g_1458 = l_2625;
                        l_2534[1] = (((((void*)0 != l_2626) < (((((safe_sub_func_int64_t_s_s(0x8326D50AE2CDA35ALL, (g_2629 , (((*l_2631) = (l_2630 = 253UL)) == (safe_sub_func_int32_t_s_s(((safe_mod_func_int64_t_s_s(l_2534[1], ((*g_609) = ((!(safe_div_func_uint8_t_u_u((l_2609 && (0x1AL ^ ((((safe_add_func_uint8_t_u_u(p_19, l_2618)) , 1L) , 0x7D82BA7AL) && l_2641))), 2UL))) && (***g_361))))) | p_18), 0L)))))) , g_103) == 0x2C1EL) & (-7L)) , p_18)) && p_15) >= p_17);
                    }
                }
            }
        }
        for (p_19 = 0; (p_19 == (-29)); p_19 = safe_sub_func_uint64_t_u_u(p_19, 7))
        { /* block id: 1127 */
            const int32_t l_2656 = (-9L);
            int32_t l_2686 = 0x5B18D434L;
            union U1 **l_2710 = &g_1352;
            union U1 ***l_2709[9][1][1] = {{{&l_2710}},{{&l_2710}},{{&l_2710}},{{&l_2710}},{{&l_2710}},{{&l_2710}},{{&l_2710}},{{&l_2710}},{{&l_2710}}};
            int32_t *l_2728 = &l_2532;
            int32_t l_2745 = 0x533139F8L;
            int32_t l_2746 = 0xE0B809ADL;
            int32_t l_2747 = 0xFECE67DBL;
            int32_t l_2748 = 7L;
            int32_t l_2749 = 0x8BBB4954L;
            int i, j, k;
            for (g_559 = (-7); (g_559 >= 45); g_559 = safe_add_func_uint32_t_u_u(g_559, 4))
            { /* block id: 1130 */
                uint64_t l_2674 = 0xCD5D7807618E62DFLL;
                struct S0 * const *l_2681 = &l_2597;
                struct S0 * const **l_2680 = &l_2681;
                int32_t l_2684 = 3L;
                if ((safe_mod_func_int16_t_s_s((+((safe_mul_func_int16_t_s_s((safe_lshift_func_int8_t_s_u(((l_2617 > p_19) & (g_1248 , (g_2653 , 0L))), 7)), (l_2476 = p_16))) | p_18)), (safe_rshift_func_int64_t_s_s(l_2656, 51)))))
                { /* block id: 1132 */
                    int32_t l_2672 = 0x286DE5F2L;
                    int32_t l_2691 = 0x9DE9CCA2L;
                    int32_t l_2692 = 0xCE6FDAF3L;
                    uint16_t l_2694[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_2694[i] = 0x2EB2L;
                    for (g_1538 = (-30); (g_1538 > 43); g_1538++)
                    { /* block id: 1135 */
                        uint8_t *l_2671 = (void*)0;
                        uint8_t *l_2673[2];
                        int32_t l_2685[7] = {0x8997BD73L,0xC2D0E14FL,0xC2D0E14FL,0x8997BD73L,0xC2D0E14FL,0xC2D0E14FL,0x8997BD73L};
                        int32_t *l_2687 = &l_2686;
                        int32_t *l_2688[10] = {&l_2529[7][0][2],&l_2529[7][0][2],&l_2529[7][0][2],&l_2526,&l_2526,&l_2529[7][0][2],&l_2529[7][0][2],&l_2529[7][0][2],&l_2526,&l_2526};
                        int16_t l_2690 = (-1L);
                        int32_t l_2693 = 0x9C2FC10DL;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_2673[i] = &g_106;
                        l_2686 &= (l_2534[2] = ((((void*)0 == g_2659[1]) <= (safe_rshift_func_uint16_t_u_s(65535UL, 5))) , (((safe_div_func_int8_t_s_s((safe_sub_func_int64_t_s_s(l_2534[1], 0xD1370BE05505A8B4LL)), ((((safe_mul_func_uint8_t_u_u((l_2674++), (safe_mul_func_uint16_t_u_u((((*g_2585) = (*g_2585)) != (g_2679 , l_2680)), (l_2685[4] &= (safe_mod_func_int64_t_s_s(l_2684, p_16))))))) >= g_1412.f1) == 0xCD70ED98L) , p_19))) || l_2685[4]) <= p_18)));
                        l_2694[0]--;
                    }
                }
                else
                { /* block id: 1143 */
                    int16_t l_2721 = (-1L);
                    for (l_2686 = 0; (l_2686 < (-20)); --l_2686)
                    { /* block id: 1146 */
                        uint32_t *l_2703[7] = {&g_2599.f1,&g_2599.f1,&g_1879.f1,&g_2599.f1,&g_2599.f1,&g_1879.f1,&g_2599.f1};
                        int32_t l_2720 = 0x14251D7FL;
                        uint64_t *l_2724 = &g_49;
                        int16_t *l_2725 = (void*)0;
                        int16_t *l_2726 = (void*)0;
                        int16_t *l_2727[6][9][1] = {{{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]}},{{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0}},{{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]}},{{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0}},{{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]}},{{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0},{&g_1253[1][2][0]},{(void*)0}}};
                        int i, j, k;
                        (*g_2363) = (*g_2363);
                        (*g_2550) = (((l_2684 = ((safe_add_func_uint8_t_u_u((((g_2704 = l_2703[5]) != l_2703[2]) != ((safe_div_func_uint64_t_u_u(((*l_2724) |= (safe_mod_func_uint8_t_u_u((l_2709[8][0][0] == (((safe_rshift_func_int16_t_s_s(((safe_lshift_func_uint64_t_u_u((safe_mul_func_int64_t_s_s((*g_609), (p_18 ^ (g_2717[1][7][1] , ((safe_sub_func_int32_t_s_s(l_2720, (3UL & ((p_17 || l_2721) < 1UL)))) || p_17))))), 27)) < l_2674), 4)) < 0x1C36A85D4C9828EBLL) , l_2722)), p_18))), l_2534[1])) > g_1690.f3)), g_2211)) , 0xE39DL)) < p_18) | 4294967290UL);
                        l_2720 &= 7L;
                        l_2728 = &p_16;
                    }
                }
                for (g_1459.f0 = 0; g_1459.f0 < 2; g_1459.f0 += 1)
                {
                    g_1244[g_1459.f0] = &g_383;
                }
            }
            for (l_2526 = 7; (l_2526 >= 0); l_2526 -= 1)
            { /* block id: 1160 */
                int8_t l_2732 = 0L;
                int32_t *l_2733 = &l_2528;
                int32_t *l_2734 = &l_2534[1];
                int32_t *l_2735 = &l_2524;
                int32_t *l_2736 = &l_2530;
                int32_t *l_2737 = (void*)0;
                int32_t *l_2738 = &l_2686;
                int32_t *l_2739 = &g_103;
                int32_t l_2740 = 0xDEAA2CD9L;
                int32_t *l_2741 = &l_2532;
                int32_t *l_2742 = &g_103;
                int32_t *l_2743 = &g_281;
                int32_t *l_2744[5][10] = {{(void*)0,&l_2528,&l_2525,&l_2529[7][0][2],&l_2525,&l_2530,&l_2525,&l_2528,&l_2528,&l_2525},{&l_2525,&l_2529[7][0][2],&l_2525,&l_2525,&l_2529[7][0][2],&l_2525,&l_2525,(void*)0,&l_2530,&l_2525},{&l_2524,(void*)0,(void*)0,&l_2530,&l_2525,&l_2476,&l_2530,&l_2524,&g_103,&l_2524},{&l_2524,&l_2525,&l_2528,&l_2529[7][0][2],&l_2528,&l_2525,&l_2524,&g_281,&l_2525,(void*)0},{&l_2525,&l_2524,&g_281,&l_2525,(void*)0,&l_2530,&l_2528,(void*)0,&g_281,&g_281}};
                uint32_t l_2750 = 5UL;
                int i, j;
                if (p_16)
                    break;
                ++l_2729;
                l_2750++;
            }
            if (p_16)
                break;
        }
        return p_19;
    }
    else
    { /* block id: 1168 */
        int32_t l_2758 = 0x9136C58AL;
        int32_t *l_2765 = &g_1043;
        uint32_t *l_2766 = (void*)0;
        uint32_t *l_2767 = (void*)0;
        uint32_t *l_2768 = (void*)0;
        int16_t *l_2770 = &g_1253[1][6][0];
        uint64_t l_2771 = 0x272D141EB8390638LL;
        int32_t l_2772 = 1L;
        int32_t **l_2780[6];
        uint32_t l_2817 = 0x0BC48B2BL;
        uint32_t l_2818[9] = {0x224BFFA6L,0x224BFFA6L,0x224BFFA6L,0x224BFFA6L,0x224BFFA6L,0x224BFFA6L,0x224BFFA6L,0x224BFFA6L,0x224BFFA6L};
        int64_t l_2830 = 0x59B6CF593482980CLL;
        uint64_t l_2886 = 0xF0472B4578EA0B56LL;
        struct S0 ****l_2938 = &g_1142;
        int16_t l_3004 = 1L;
        union U2 **l_3019 = (void*)0;
        int8_t l_3046[4][10][3] = {{{0xE7L,0xE7L,0xA1L},{0L,0xA1L,5L},{5L,0xA1L,0L},{0xA1L,0xE7L,0xE7L},{0x68L,5L,0L},{1L,(-4L),5L},{1L,0xE7L,0xA1L},{0x68L,(-1L),0x68L},{0xA1L,0xA1L,0x68L},{(-1L),0L,0x68L}},{{1L,(-1L),0xE7L},{7L,7L,0xE7L},{1L,0xE7L,(-1L)},{(-1L),0xE7L,1L},{0xE7L,7L,7L},{0xE7L,(-1L),1L},{0x68L,0L,(-1L)},{0x68L,0xA1L,0xE7L},{0xE7L,0xC9L,0xE7L},{0xE7L,0xA1L,0x68L}},{{(-1L),0L,0x68L},{1L,(-1L),0xE7L},{7L,7L,0xE7L},{1L,0xE7L,(-1L)},{(-1L),0xE7L,1L},{0xE7L,7L,7L},{0xE7L,(-1L),1L},{0x68L,0L,(-1L)},{0x68L,0xA1L,0xE7L},{0xE7L,0xC9L,0xE7L}},{{0xE7L,0xA1L,0x68L},{(-1L),0L,0x68L},{1L,(-1L),0xE7L},{7L,7L,0xE7L},{1L,0xE7L,(-1L)},{(-1L),0xE7L,1L},{0xE7L,7L,7L},{0xE7L,(-1L),1L},{0x68L,0L,(-1L)},{0x68L,0xA1L,0xE7L}}};
        union U4 *l_3072 = &g_2605;
        union U3 **l_3116[10][10][2] = {{{&l_2920[1],&l_2920[3]},{&g_1022,&l_2920[3]},{&l_2920[1],&g_634},{&l_2920[0],&l_2920[4]},{&l_2920[4],&g_1022},{&g_1022,(void*)0},{&g_634,&g_634},{(void*)0,&l_2920[5]},{&l_2920[4],&g_1022},{&g_634,&l_2920[5]}},{{&g_634,&g_1022},{&g_634,&l_2920[5]},{&l_2920[5],&g_634},{(void*)0,&l_2920[4]},{&l_2920[0],&g_1022},{&l_2920[5],&g_1022},{&g_1022,&g_1022},{(void*)0,&l_2920[2]},{&g_634,&l_2920[4]},{&g_1022,&l_2920[5]}},{{&g_634,&g_634},{&g_634,&g_1022},{&g_1022,&g_1022},{&g_1022,&g_1022},{&l_2920[0],&l_2920[1]},{&g_1022,&l_2920[3]},{&g_634,&l_2920[5]},{&l_2920[1],&l_2920[1]},{(void*)0,&l_2920[4]},{&g_1022,&g_634}},{{&g_1022,&g_1022},{&g_1022,&g_634},{&g_634,&g_634},{&l_2920[4],&l_2920[4]},{&g_1022,&l_2920[5]},{(void*)0,(void*)0},{&g_634,&g_1022},{&l_2920[5],&g_634},{&l_2920[0],&g_1022},{&l_2920[0],&g_634}},{{&l_2920[5],&g_1022},{&g_634,(void*)0},{(void*)0,&l_2920[5]},{&g_1022,&l_2920[4]},{&l_2920[4],&g_634},{&g_634,&g_634},{&g_1022,&g_1022},{&g_1022,&g_634},{&g_634,&g_1022},{&g_1022,&l_2920[5]}},{{&g_1022,&g_1022},{&g_1022,(void*)0},{&l_2920[5],&l_2920[5]},{&g_634,&l_2920[5]},{&g_634,&g_634},{&l_2920[5],&g_1022},{&g_1022,&l_2920[1]},{&g_1022,(void*)0},{&l_2920[5],&g_1022},{&l_2920[2],(void*)0}},{{&l_2920[5],&l_2920[4]},{&g_1022,(void*)0},{&g_1022,&g_1022},{&g_634,&g_1022},{(void*)0,&g_1022},{&g_1022,(void*)0},{&g_1022,&l_2920[4]},{&l_2920[2],&g_1022},{&l_2920[2],&l_2920[5]},{&g_1022,(void*)0}},{{&g_1022,&g_1022},{&g_1022,&g_634},{&g_1022,&g_634},{&g_634,&g_1022},{&g_634,&l_2920[5]},{&g_1022,(void*)0},{&g_1022,(void*)0},{&g_1022,&l_2920[5]},{&g_634,&g_1022},{&g_634,&g_634}},{{&g_1022,&g_634},{&g_1022,&g_1022},{&g_1022,(void*)0},{&g_1022,&l_2920[5]},{&l_2920[2],&g_1022},{&l_2920[2],&l_2920[4]},{&g_1022,(void*)0},{&g_1022,&g_1022},{(void*)0,&g_1022},{&g_634,&g_1022}},{{&g_1022,(void*)0},{&g_1022,&l_2920[4]},{&l_2920[5],(void*)0},{&l_2920[2],&g_1022},{&l_2920[5],(void*)0},{&g_1022,&l_2920[1]},{&g_1022,&g_1022},{&l_2920[5],&g_634},{&g_634,&l_2920[5]},{&g_634,&l_2920[5]}}};
        int64_t ****l_3203 = &g_1229;
        int64_t *****l_3202 = &l_3203;
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_2780[i] = &g_112[1];
        l_2772 |= (((safe_add_func_int64_t_s_s((((safe_sub_func_int8_t_s_s((+(l_2758 != l_2524)), p_17)) , (((l_2758 , (p_15 & (safe_rshift_func_uint64_t_u_s((safe_lshift_func_uint64_t_u_u((((safe_mod_func_uint32_t_u_u((p_18 && ((((*l_2770) = ((((*l_2765) = 0x97318A72L) , p_17) , ((l_2529[7][0][2] = p_16) && g_2769))) & l_2771) > (-5L))), l_2543[0])) < l_2543[0]) , (**g_1100)), l_2771)), l_2689)))) , p_16) == 0xCDEE530FL)) && 0UL), 0xA23EB1035A94589CLL)) & (-1L)) >= p_19);
        if ((safe_mod_func_uint64_t_u_u((((0x37C141E6L & ((g_2775 , 0xDC31A778EED29153LL) < ((((!0x2D5EL) >= (0x573BF78E586370B8LL || ((((~((p_18 = p_16) == p_19)) , (l_2529[7][0][2] , ((safe_rshift_func_int64_t_s_u((0x1BL | l_2772), (**g_1100))) | p_15))) , l_2780[4]) == l_2780[5]))) , (-1L)) , l_2525))) | 0x1470ED73L) || p_19), p_16)))
        { /* block id: 1174 */
            uint64_t *l_2788 = &g_49;
            int32_t l_2810 = 0xC069C75BL;
            const uint16_t l_2854[4][5][7] = {{{65530UL,0xEA41L,5UL,0xD740L,0x8B12L,0xCAC2L,65530UL},{0x1077L,0x763EL,0x61BCL,0xB7D5L,0x6B53L,0x9C1BL,65535UL},{65530UL,0xD740L,0x8645L,1UL,65535UL,0x757FL,0x4CB6L},{0x763EL,0UL,5UL,5UL,0UL,0x763EL,0x9C1BL},{0x4CB6L,65530UL,0x72BFL,65535UL,65532UL,0x8B12L,0x0C92L}},{{65527UL,0x62DAL,0UL,4UL,65535UL,0x6B53L,0x2166L},{65535UL,65530UL,0x7B72L,65533UL,0x72BFL,65535UL,65534UL},{5UL,0UL,0x2EC3L,0xB86BL,0x2EC3L,0UL,5UL},{65534UL,0xD740L,0x4CB6L,0x8B12L,65533UL,65532UL,65530UL},{0x7603L,0x763EL,4UL,0UL,65535UL,65535UL,1UL}},{{65532UL,0xEA41L,0x4CB6L,0x0BEAL,65533UL,0x72BFL,1UL},{1UL,0UL,0x2EC3L,0x7603L,0x7603L,0x2EC3L,0UL},{0xCAC2L,0x0C92L,65533UL,0x0C92L,0xBA68L,0x8B12L,5UL},{0x763EL,1UL,0x1077L,5UL,0xA79CL,0xFF47L,0x7603L},{0xBA68L,0xBD16L,0x4CB6L,0x0C92L,0xEA41L,1UL,0x757FL}},{{65535UL,0x7603L,0xA79CL,65535UL,4UL,65535UL,0xA79CL},{0x8B12L,0x8B12L,0x72BFL,0xBD16L,0xCAC2L,0xBA68L,65530UL},{0x1077L,0UL,1UL,0x6B53L,0x763EL,0xA79CL,1UL},{0x72BFL,0x7B72L,1UL,0xE7C9L,0xCAC2L,0xEA41L,0x8B12L},{0xFF47L,5UL,1UL,0x61BCL,4UL,4UL,0x61BCL}}};
            struct S0 *l_2883[6] = {&g_1811,&g_1811,&g_1811,&g_1811,&g_1811,&g_1811};
            uint16_t l_2890 = 0x90F3L;
            uint16_t *****l_2934[8];
            struct S0 ****l_2937 = &g_1142;
            uint32_t l_2947 = 0xC2D10530L;
            uint8_t l_2950 = 0x0AL;
            const uint32_t l_3002 = 0xB5B47C5FL;
            int8_t l_3003 = 0x32L;
            int32_t l_3026 = 8L;
            int32_t l_3040 = 0L;
            int32_t l_3041 = 0x887B2949L;
            int32_t l_3042[7];
            uint64_t l_3043 = 0x687CE4E81C811A67LL;
            int i, j, k;
            for (i = 0; i < 8; i++)
                l_2934[i] = &g_2541;
            for (i = 0; i < 7; i++)
                l_3042[i] = 0xA4F0E7D8L;
            if ((safe_mul_func_int32_t_s_s((((!((safe_div_func_uint64_t_u_u((((*g_212) , ((safe_rshift_func_uint64_t_u_s(((*l_2788)--), 5)) < (safe_rshift_func_uint64_t_u_u((((safe_mul_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((&l_2780[3] == ((((g_2797 , (safe_mod_func_uint32_t_u_u(((((safe_mul_func_int16_t_s_s(0x9266L, (safe_lshift_func_int64_t_s_u((safe_mod_func_int8_t_s_s(g_1690.f0, (safe_add_func_uint64_t_u_u(((((((safe_mod_func_int8_t_s_s((p_17 <= ((l_2810 >= (safe_sub_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_s(((safe_add_func_int8_t_s_s(((((*g_1243) != (void*)0) , 0x479B50ABL) , p_19), l_2810)) && l_2810), l_2810)), l_2543[2]))) <= p_16)), p_15)) > 8UL) >= p_18) | l_2475) != l_2476) > 1L), p_15)))), p_15)))) , p_16) != l_2817) , p_19), l_2818[8]))) < p_17) >= p_19) , &l_2780[4])), p_17)), g_1879.f1)) > 4L) || 0xD8L), p_18)))) != l_2810), l_2810)) & p_17)) , l_2810) <= 3UL), l_2689)))
            { /* block id: 1176 */
                uint8_t l_2825[8][6][5] = {{{1UL,255UL,0xAFL,255UL,0x65L},{0x41L,255UL,252UL,0x04L,9UL},{0xE4L,0UL,0x95L,252UL,251UL},{0x87L,255UL,0x03L,0xA8L,0x03L},{0x5BL,0x5BL,1UL,1UL,0UL},{0x45L,0x04L,0x95L,253UL,0xA8L}},{{0UL,7UL,0xAFL,0x29L,0x45L},{9UL,0x04L,0xF8L,0x87L,0x5BL},{0UL,0x5BL,0xE4L,0x3CL,4UL},{4UL,255UL,255UL,0x48L,0x3CL},{9UL,0UL,0x91L,0UL,0x29L},{255UL,255UL,0UL,255UL,0x5BL}},{{0x48L,255UL,255UL,4UL,0UL},{0x5BL,0x29L,0x11L,4UL,0x5BL},{0x56L,1UL,255UL,255UL,0x48L},{0x29L,0xAFL,7UL,0UL,6UL},{0x41L,255UL,0x94L,0x48L,0UL},{248UL,1UL,0x3CL,0x3CL,1UL}},{{0xA8L,0x03L,255UL,0x87L,250UL},{255UL,255UL,0x0FL,0x29L,9UL},{255UL,0x5BL,252UL,253UL,0UL},{255UL,0xAFL,255UL,1UL,255UL},{0xA8L,0x29L,247UL,0xA8L,9UL},{248UL,0UL,0xAFL,252UL,0UL}},{{0x41L,252UL,0xAFL,0x04L,0xCEL},{0x29L,0UL,255UL,255UL,251UL},{0x56L,0xE4L,0x60L,0UL,7UL},{250UL,0xFEL,0x60L,0x3CL,1UL},{255UL,0xAFL,255UL,0x65L,8UL},{0xD0L,253UL,1UL,0x98L,255UL}},{{0xE4L,0xF8L,252UL,0x95L,1UL},{255UL,250UL,255UL,250UL,255UL},{0x94L,0xE4L,0xD0L,0xCDL,250UL},{0xE4L,1UL,0x95L,0UL,0x98L},{0UL,0x45L,1UL,0xE4L,250UL},{0xCDL,0UL,247UL,0x94L,255UL}},{{250UL,0x98L,0xFEL,255UL,1UL},{0x95L,0xAFL,1UL,0xE4L,255UL},{0x98L,0x03L,255UL,0xD0L,8UL},{0x65L,0x91L,0xF8L,255UL,1UL},{0x3CL,7UL,251UL,250UL,7UL},{0UL,7UL,247UL,255UL,0xCEL}},{{0x45L,0x91L,1UL,0x9FL,0UL},{0xAFL,0x03L,0x48L,0x65L,6UL},{0x95L,0xAFL,0xD0L,0x11L,0xE4L},{8UL,0x98L,0x98L,8UL,247UL},{0x3CL,0UL,0x5BL,0x45L,6UL},{255UL,0x45L,1UL,0xF8L,255UL}}};
                int32_t l_2874 = 0xCA0535B4L;
                int32_t l_2876 = (-9L);
                struct S0 * const l_2882 = &g_1690;
                int i, j, k;
                if ((p_15 = (safe_lshift_func_int32_t_s_u(((safe_rshift_func_int64_t_s_u((((((void*)0 == (*g_1243)) == (safe_sub_func_uint16_t_u_u(l_2825[3][3][2], ((((((safe_div_func_uint8_t_u_u(p_19, p_17)) < (0x28A8DFB0E68A5B2DLL | p_16)) | (safe_mul_func_uint16_t_u_u((l_2830 < (l_2475 < l_2825[6][5][0])), p_16))) || (-2L)) > l_2529[7][0][2]) && p_15)))) , p_16) || p_16), p_17)) < p_18), p_18))))
                { /* block id: 1178 */
                    const uint32_t l_2875 = 0UL;
                    const int32_t ***l_2879 = &l_2878;
                    struct S0 *l_2884 = &g_2885;
                    for (g_429.f0 = 0; (g_429.f0 != (-14)); g_429.f0 = safe_sub_func_uint32_t_u_u(g_429.f0, 2))
                    { /* block id: 1181 */
                        uint8_t *l_2841 = &l_2825[3][3][2];
                        int32_t l_2871 = 0xE8FC2E56L;
                        (*g_2550) = (safe_mod_func_uint16_t_u_u((safe_sub_func_int32_t_s_s((safe_rshift_func_int64_t_s_u(((safe_rshift_func_uint8_t_u_u((--(*l_2841)), (((safe_add_func_int64_t_s_s(((safe_mul_func_int64_t_s_s((safe_sub_func_int64_t_s_s((safe_lshift_func_int16_t_s_s(((safe_rshift_func_int64_t_s_s((l_2854[3][2][5] == ((***g_361) ^ l_2810)), 21)) && ((safe_lshift_func_int32_t_s_s((safe_div_func_int64_t_s_s(((*g_609) = (safe_mul_func_uint8_t_u_u(p_15, g_1341.f0))), p_17)), 9)) || (safe_mul_func_uint16_t_u_u(0UL, ((safe_mul_func_uint16_t_u_u(((*g_887) ^= ((safe_lshift_func_uint32_t_u_s((safe_lshift_func_uint16_t_u_u(l_2871, (((safe_rshift_func_uint16_t_u_u((((l_2874 |= p_18) && l_2854[2][4][4]) < 0x903391BAC1A7A5CALL), l_2475)) | l_2475) == p_15))), 5)) ^ 5L)), p_17)) != g_1690.f3))))), 2)), l_2875)), p_16)) == p_18), l_2876)) <= p_17) != 0xB7L))) && l_2825[2][0][0]), p_16)), p_19)), g_774));
                        return l_2825[3][3][2];
                    }
                    if ((l_2877 != l_2879))
                    { /* block id: 1189 */
                        l_2886 |= (((safe_rshift_func_int32_t_s_u(((p_16 ^= p_15) <= (l_2882 != (l_2884 = l_2883[0]))), 10)) < (***l_2877)) >= (((l_2854[3][2][1] <= ((g_1635 , (*g_589)) == (void*)0)) <= (p_15 || (*g_2550))) == 6UL));
                    }
                    else
                    { /* block id: 1193 */
                        int16_t l_2889 = 4L;
                        l_2890 ^= (safe_add_func_int16_t_s_s(l_2889, l_2889));
                        return p_15;
                    }
                    for (g_1459.f1 = 0; (g_1459.f1 > (-11)); g_1459.f1 = safe_sub_func_uint8_t_u_u(g_1459.f1, 4))
                    { /* block id: 1199 */
                        l_2876 = ((*g_2550) ^= ((18446744073709551615UL <= (safe_lshift_func_uint64_t_u_u(18446744073709551615UL, 1))) != 0UL));
                        (*g_2550) = p_16;
                        p_16 |= ((g_2885 , &g_1352) == &g_1352);
                        if ((*g_805))
                            continue;
                    }
                }
                else
                { /* block id: 1206 */
                    int64_t l_2895 = 0x14F9BA0D4525F182LL;
                    return l_2895;
                }
            }
            else
            { /* block id: 1209 */
                struct S0 ****l_2936 = &g_1142;
                int32_t l_2946[7][3] = {{0xE950C4D4L,0x9766171FL,0x9766171FL},{(-1L),0x9766171FL,2L},{0x06469E8CL,0x9766171FL,(-2L)},{0xE950C4D4L,0x9766171FL,0x9766171FL},{(-1L),0x9766171FL,2L},{0x06469E8CL,0x9766171FL,(-2L)},{0xE950C4D4L,0x9766171FL,0x9766171FL}};
                const uint64_t l_2975 = 0x08A79BCB8DA1B35BLL;
                uint8_t l_2980 = 1UL;
                int i, j;
                for (g_281 = 0; (g_281 >= 18); g_281 = safe_add_func_int8_t_s_s(g_281, 2))
                { /* block id: 1212 */
                    uint32_t l_2939[6][1] = {{0UL},{0xF1290CB9L},{0UL},{0UL},{0xF1290CB9L},{0UL}};
                    int32_t l_2941 = 0xE8F6342BL;
                    int32_t l_2943 = 0x5D19A5BFL;
                    int32_t l_2945 = (-1L);
                    struct S0 *****l_2965[1][5][10] = {{{(void*)0,(void*)0,&l_2938,(void*)0,(void*)0,(void*)0,(void*)0,&l_2938,(void*)0,(void*)0},{(void*)0,(void*)0,&l_2938,(void*)0,(void*)0,(void*)0,(void*)0,&l_2938,(void*)0,(void*)0},{(void*)0,(void*)0,&l_2938,(void*)0,(void*)0,(void*)0,(void*)0,&l_2938,(void*)0,(void*)0},{(void*)0,(void*)0,&l_2938,(void*)0,(void*)0,(void*)0,(void*)0,&l_2938,(void*)0,(void*)0},{(void*)0,(void*)0,&l_2938,(void*)0,(void*)0,(void*)0,(void*)0,&l_2938,(void*)0,(void*)0}}};
                    int i, j, k;
                    if (((**l_2878) || (((((7UL != (*g_2550)) , (((((safe_mod_func_uint8_t_u_u(((*g_1101) <= p_19), (safe_mod_func_uint64_t_u_u(1UL, p_18)))) & (!(safe_mul_func_uint64_t_u_u(18446744073709551615UL, p_18)))) | l_2810) , (-3L)) , g_2717[4][1][1])) , l_2890) , (void*)0) == (void*)0)))
                    { /* block id: 1213 */
                        int16_t l_2909 = 0xB199L;
                        int64_t * const *l_2918 = (void*)0;
                        int64_t * const **l_2917[10][2][10] = {{{&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918},{&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918}},{{&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918},{&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918}},{{&l_2918,&l_2918,(void*)0,(void*)0,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918},{(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,(void*)0,&l_2918,&l_2918}},{{&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918},{(void*)0,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918}},{{&l_2918,(void*)0,(void*)0,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918},{&l_2918,&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918}},{{&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918},{&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918}},{{(void*)0,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918},{&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918}},{{&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918},{&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918}},{{&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918},{(void*)0,&l_2918,(void*)0,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918}},{{&l_2918,&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918,&l_2918,&l_2918},{&l_2918,&l_2918,&l_2918,&l_2918,(void*)0,&l_2918,(void*)0,&l_2918,&l_2918,&l_2918}}};
                        int64_t * const ***l_2919 = &l_2917[0][0][7];
                        int32_t l_2940 = 0xEBC4270BL;
                        int32_t l_2942 = 0xED624890L;
                        int32_t l_2944[1][9][3] = {{{(-10L),0xCE6AD22CL,0L},{(-10L),9L,6L},{1L,(-4L),1L},{6L,9L,(-10L)},{0L,0xCE6AD22CL,(-10L)},{2L,0L,1L},{0xD329E52AL,0xD329E52AL,6L},{2L,6L,0L},{0L,6L,2L}}};
                        int i, j, k;
                        (*g_2550) ^= ((safe_mul_func_int64_t_s_s(((p_16 |= (***l_2877)) > (((safe_mul_func_int16_t_s_s(p_18, (1UL | (l_2909 = 4294967295UL)))) , (**g_1389)) , (((~((((*l_2919) = (g_2911 , (((g_2301 , ((g_2912 , (((safe_mod_func_uint64_t_u_u(((safe_mod_func_uint64_t_u_u(0xEA5E7CE044743403LL, p_15)) >= 0xC8C3L), p_15)) && g_2679.f0) >= 1L)) < 1L)) || g_374.f0) , l_2917[0][0][7]))) != (void*)0) & p_17)) & p_18) & (***l_2877)))), 0x4560466FEEF7B803LL)) | (***l_2877));
                        p_16 &= ((*g_2550) |= (p_15 = ((l_2920[5] = (*g_1713)) != g_1022)));
                        p_15 |= ((safe_mod_func_int8_t_s_s((safe_lshift_func_uint32_t_u_s((g_2925 , ((safe_unary_minus_func_int16_t_s(0x7876L)) , ((safe_add_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(((l_2931 != ((((safe_lshift_func_uint64_t_u_u((l_2934[3] == l_2935), 2)) >= (((((void*)0 == l_2936) >= ((l_2937 = l_2936) != l_2938)) && 0xB39DFD6B4DE22AC8LL) , l_2939[0][0])) ^ p_18) , (*g_361))) <= p_17), p_19)), (**g_1100))) || l_2909))), l_2810)), l_2854[3][3][2])) || 0x81L);
                        ++l_2947;
                    }
                    else
                    { /* block id: 1225 */
                        --l_2950;
                    }
                    if ((safe_rshift_func_uint32_t_u_s((***l_2877), 3)))
                    { /* block id: 1228 */
                        (***g_1243) = (void*)0;
                        (*g_2550) = p_18;
                    }
                    else
                    { /* block id: 1231 */
                        struct S0 ** const *l_2968 = &g_1143[2][1][1];
                        struct S0 ** const **l_2967 = &l_2968;
                        struct S0 ** const ***l_2966 = &l_2967;
                        int32_t l_2976 = 0x41CBE655L;
                        if (p_17)
                            break;
                        l_2945 = (safe_mul_func_int32_t_s_s(0x0F586590L, (safe_add_func_int64_t_s_s((safe_sub_func_uint16_t_u_u((l_2976 = (p_15 < (safe_lshift_func_int64_t_s_u((safe_div_func_int32_t_s_s(l_2943, (***l_2877))), ((((g_2584[5] = l_2965[0][3][6]) == l_2966) >= ((p_15 < (safe_lshift_func_int32_t_s_u(0x5258B7BAL, (safe_mul_func_uint8_t_u_u((safe_mul_func_uint64_t_u_u((**l_2878), l_2975)), 2L))))) >= p_19)) && p_19))))), (***l_2877))), 0xB437CFD4CA2FB0F6LL))));
                        (*g_2550) ^= p_15;
                    }
                    for (g_1816.f1 = 0; (g_1816.f1 > 7); g_1816.f1 = safe_add_func_uint8_t_u_u(g_1816.f1, 5))
                    { /* block id: 1240 */
                        l_2476 = p_17;
                    }
                }
                if (p_19)
                { /* block id: 1244 */
                    int16_t l_2979[1];
                    int32_t l_3001 = 0x6A6394BBL;
                    uint32_t l_3005 = 6UL;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_2979[i] = (-8L);
                    if (l_2946[6][0])
                    { /* block id: 1245 */
                        l_2980 |= l_2979[0];
                    }
                    else
                    { /* block id: 1247 */
                        (*g_2363) &= (p_16 > (safe_unary_minus_func_int32_t_s((-5L))));
                    }
                    p_15 = p_16;
                    (*g_2550) = (((((safe_rshift_func_int64_t_s_u(((***l_2877) & (((safe_add_func_uint64_t_u_u((g_137 && ((+((~((safe_add_func_int64_t_s_s(p_17, (safe_add_func_uint32_t_u_u(((!(((safe_add_func_int8_t_s_s((safe_add_func_int16_t_s_s(l_2980, (l_2525 = (l_3001 = (((l_2979[0] || (safe_sub_func_int64_t_s_s((((l_2950 | (+p_17)) , ((p_15 < (((void*)0 == l_3000) == l_2946[3][2])) | l_2854[3][2][5])) , l_2979[0]), p_16))) && p_19) ^ 0x358DCDBB83356068LL))))), g_1811.f3)) < p_15) != l_2946[5][2])) || 0UL), (*g_2363))))) >= l_2975)) != l_3002)) & 18446744073709551615UL)), p_18)) > l_3003) & g_1811.f2)), l_2975)) >= l_2979[0]) != p_19) == 246UL) == 0x3ACE6DA1L);
                    l_3005--;
                }
                else
                { /* block id: 1255 */
                    uint32_t l_3016 = 0x08F66AECL;
                    int32_t l_3035 = 1L;
                    int32_t l_3036 = 0L;
                    int32_t l_3037[3][2][3] = {{{(-2L),2L,(-2L)},{(-2L),2L,(-2L)}},{{(-2L),2L,(-2L)},{(-2L),2L,(-2L)}},{{(-2L),2L,(-2L)},{(-2L),2L,(-2L)}}};
                    int i, j, k;
                    (*g_2550) |= (((*g_887) = ((p_16 || (((&g_1019 != &g_1019) ^ (safe_div_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((***l_2877), (g_1188.f0 = ((((safe_add_func_uint16_t_u_u((0x5AA6D811L <= (g_1690 , (***l_2877))), ((safe_mul_func_int16_t_s_s(((***l_2877) > (((***l_2877) < 0xA6L) ^ p_19)), g_1690.f3)) , p_18))) & l_3016) != p_15) , p_18)))) < p_18), p_16))) && p_16)) & p_19)) , 0xA8A80EF7L);
                    if (((((safe_div_func_int32_t_s_s((l_3016 != ((void*)0 != l_3019)), (safe_mod_func_int32_t_s_s((safe_div_func_uint8_t_u_u(((safe_mul_func_int64_t_s_s(((((g_2481[0] , (p_16 , (l_3026 >= ((((safe_div_func_int64_t_s_s(((safe_rshift_func_uint16_t_u_s((7UL | ((***l_2877) , (safe_rshift_func_int8_t_s_u((0x93L >= p_16), l_2946[6][0])))), p_15)) >= (-1L)), 1L)) || p_15) >= 0xD3AD38D17AD2D37CLL) == p_16)))) & 0xEA71DA7C7672B564LL) & l_3016) , p_16), p_18)) & (*g_609)), p_15)), g_3033)))) || (**l_2878)) , (**g_1389)) , 0L))
                    { /* block id: 1259 */
                        int64_t l_3034[3][9] = {{1L,(-3L),1L,1L,(-3L),1L,1L,(-3L),1L},{1L,(-3L),1L,1L,(-3L),1L,1L,(-3L),1L},{1L,(-3L),1L,1L,(-3L),1L,1L,(-3L),1L}};
                        int32_t l_3038 = 0xBCBF492AL;
                        int32_t l_3039[7][6][5] = {{{0L,0xD6A72A04L,(-1L),(-6L),1L},{(-1L),(-1L),4L,0xF6EEEDF6L,0x1EB6FDB2L},{0x0DBA5C28L,0xB831A3A5L,0x84295D98L,0x0C0D92B1L,0x9140CF84L},{1L,9L,0x61B08DD2L,0x4EB82849L,0xC4246FF8L},{1L,0L,0x34CA2AB4L,6L,(-1L)},{6L,0x40547632L,0x34CA2AB4L,0x33B1E100L,0xD47D65E0L}},{{0xE8572913L,(-7L),0x61B08DD2L,(-7L),0L},{(-1L),0x9BF2A992L,0x84295D98L,(-1L),9L},{0x8AB17D3FL,1L,4L,0L,0x34CA2AB4L},{0x9F830810L,0xF6EEEDF6L,(-1L),(-1L),0xF6EEEDF6L},{0x9BF2A992L,0xD9A0D857L,1L,0x61B08DD2L,0x0E6E30F6L},{1L,1L,1L,0xC4246FF8L,(-1L)}},{{(-1L),7L,0xE8572913L,0x92B91E01L,0x40547632L},{1L,(-1L),7L,0L,0x26F07CEDL},{0x9BF2A992L,(-1L),9L,1L,0xB831A3A5L},{0x9F830810L,0x857C6C1BL,(-5L),1L,0xD9A0D857L},{0x8AB17D3FL,7L,0xD9A0D857L,0x557A6AF1L,0x43DC3905L},{(-1L),0x4EB82849L,0xD47D65E0L,0x63BDF969L,0xAADB1D19L}},{{0xE8572913L,0xECA81DB0L,0L,7L,0x8AB17D3FL},{6L,0xB9592142L,0x857C6C1BL,7L,0x17CB7C42L},{1L,0x547F6BDFL,0x43DC3905L,0x63BDF969L,0x5446070CL},{1L,0x92B91E01L,(-6L),0x557A6AF1L,0x9F830810L},{0x0DBA5C28L,0x0BCB7907L,0L,1L,0xB9303EF4L},{0x827AD960L,0xF3E945A7L,6L,0xA147DE4BL,6L}},{{0x40547632L,0x40547632L,0x8AB17D3FL,1L,0x33E18152L},{1L,1L,0L,0x547F6BDFL,0xEE1BA0CAL},{0xD47D65E0L,0x9F830810L,7L,0x857C6C1BL,1L},{0x92B91E01L,1L,(-1L),1L,0x6ED0FB16L},{0x63BDF969L,0x40547632L,0xAADB1D19L,0L,(-1L)},{0x8AB17D3FL,0xF3E945A7L,0x92B91E01L,0x33E18152L,(-1L)}},{{0x34CA2AB4L,(-1L),0L,0x61B08DD2L,0xE8572913L},{0x1EB6FDB2L,0x547F6BDFL,0x63BDF969L,0xB831A3A5L,(-3L)},{0L,(-1L),0xC4246FF8L,(-3L),9L},{0x9140CF84L,0x557A6AF1L,1L,0x6ED0FB16L,9L},{0xB9303EF4L,0L,0x9F830810L,(-5L),(-3L)},{(-7L),(-5L),0xB9303EF4L,0x34CA2AB4L,0xE8572913L}},{{(-5L),1L,0x6ED0FB16L,0x0BCB7907L,(-1L)},{0xDAA4B1E2L,0x17CB7C42L,0x61B08DD2L,(-1L),(-1L)},{0x857C6C1BL,0L,0x857C6C1BL,0x1EB6FDB2L,0x6ED0FB16L},{9L,0xE8572913L,(-1L),0x84295D98L,1L},{0x0BCB7907L,4L,0x26F07CEDL,0x0E6E30F6L,0xEE1BA0CAL},{(-1L),0x33B1E100L,(-1L),1L,0x33E18152L}}};
                        int i, j, k;
                        ++l_3043;
                    }
                    else
                    { /* block id: 1261 */
                        return g_619.f2;
                    }
                }
            }
            --l_3047;
        }
        else
        { /* block id: 1267 */
            int16_t l_3052 = 0L;
            uint32_t ****l_3066 = (void*)0;
            uint32_t ***l_3068 = &l_2931;
            uint32_t ****l_3067 = &l_3068;
            int32_t *l_3074 = &l_2526;
            uint16_t l_3091 = 65535UL;
            uint8_t l_3130[8][2][10] = {{{0xE6L,9UL,0xE6L,246UL,0xD6L,0xE6L,255UL,246UL,246UL,246UL},{246UL,9UL,1UL,0xD6L,0xD6L,1UL,9UL,246UL,0xF2L,0xD6L}},{{246UL,255UL,0xE6L,0xD6L,246UL,0xE6L,9UL,0xE6L,246UL,0xD6L},{0xE6L,9UL,0xE6L,246UL,0xD6L,0xE6L,255UL,246UL,246UL,246UL}},{{246UL,9UL,1UL,0xD6L,0xD6L,1UL,9UL,246UL,0xF2L,0xD6L},{246UL,255UL,0xE6L,0xD6L,246UL,0xE6L,9UL,0xE6L,246UL,0xD6L}},{{0xE6L,9UL,0xE6L,246UL,0xD6L,0xE6L,255UL,246UL,246UL,246UL},{246UL,9UL,1UL,0xD6L,0xD6L,1UL,9UL,246UL,0xF2L,0xD6L}},{{246UL,255UL,0xE6L,0xD6L,246UL,0xE6L,9UL,0xE6L,246UL,0xD6L},{0xE6L,9UL,0xE6L,246UL,0xE6L,255UL,0UL,255UL,1UL,1UL}},{{255UL,0xF6L,0x86L,0xE6L,0xE6L,0x86L,0xF6L,255UL,246UL,0xE6L},{255UL,0UL,255UL,0xE6L,1UL,255UL,0xF6L,255UL,1UL,0xE6L}},{{255UL,0xF6L,255UL,1UL,0xE6L,255UL,0UL,255UL,1UL,1UL},{255UL,0xF6L,0x86L,0xE6L,0xE6L,0x86L,0xF6L,255UL,246UL,0xE6L}},{{255UL,0UL,255UL,0xE6L,1UL,255UL,0xF6L,255UL,1UL,0xE6L},{255UL,0xF6L,255UL,1UL,0xE6L,255UL,0UL,255UL,1UL,1UL}}};
            int32_t l_3132 = 0xB592D2D6L;
            int32_t l_3136 = 0xD01AA585L;
            int32_t l_3138 = (-4L);
            int32_t l_3139 = 0L;
            int32_t l_3140 = 0L;
            int32_t l_3141 = 0xBD83E4A6L;
            int32_t l_3144 = 0xD8708EDFL;
            int32_t l_3145 = 1L;
            int32_t l_3146 = 0xBDB3C3A2L;
            int32_t l_3147 = 0xE4FC2FD5L;
            int32_t l_3148 = 1L;
            uint16_t ****l_3188[7][1] = {{(void*)0},{&g_2542},{(void*)0},{&g_2542},{(void*)0},{&g_2542},{(void*)0}};
            int i, j, k;
            (*g_2550) = p_15;
            for (g_429.f0 = 1; (g_429.f0 >= 0); g_429.f0 -= 1)
            { /* block id: 1271 */
                int32_t l_3060[2][2];
                int32_t l_3075[1];
                uint16_t l_3133 = 3UL;
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_3060[i][j] = 0xEDFC7D92L;
                }
                for (i = 0; i < 1; i++)
                    l_3075[i] = 0x270A63ECL;
            }
        }
    }
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_49 g_54 g_55 g_56 g_82 g_58 g_100 g_106 g_103 g_137 g_140.f1 g_212 g_220 g_281 g_313 g_223.f0 g_223.f1 g_361 g_374 g_375 g_380 g_382 g_429 g_213.f0 g_494 g_429.f0 g_510 g_213 g_483 g_559 g_573 g_586 g_588 g_619 g_620 g_648 g_651 g_362 g_101 g_608 g_609 g_383 g_701 g_726 g_375.f1 g_740 g_776 g_774 g_799 g_429.f1 g_789.f0 g_805 g_853 g_866 g_1248 g_1261 g_1101 g_932 g_933 g_1052 g_1053 g_1217.f0 g_1305 g_1326 g_886 g_887 g_1327 g_1253 g_1341 g_1342 g_1343 g_1149 g_1229 g_799.f0 g_1351 g_957.f0 g_1389 g_1400 g_1401 g_1102.f0 g_1412 g_1425 g_1261.f0 g_1100 g_866.f0 g_776.f0 g_1511 g_1043 g_1195.f0 g_1538 g_1560 g_1566 g_1059.f0 g_1148 g_630.f0 g_1217 g_1635 g_957 g_1652 g_1687 g_1690 g_1021 g_1022 g_1713 g_1243 g_1244 g_1798 g_1242 g_1811 g_1816 g_1830 g_1864 g_1879 g_1969 g_1994 g_1390 g_789.f3 g_2032 g_1459.f1 g_510.f1 g_1969.f0 g_2211 g_2220 g_374.f0 g_1412.f2 g_1566.f0 g_2301 g_2322 g_2363 g_2379 g_589 g_590 g_2401 g_2418 g_2327.f3 g_2456 g_957.f1
 * writes: g_49 g_55 g_58 g_82 g_106 g_112 g_137 g_103 g_140.f1 g_220 g_56 g_281 g_223.f1 g_362 g_429.f1 g_483 g_559 g_586 g_608 g_634 g_727 g_375.f1 g_886 g_651 g_933 g_1048 g_1352 g_1343.f1 g_1458 g_1108.f2 g_1102.f0 g_1687 g_1022 g_1043 g_1872 g_1412.f2 g_1188.f0 g_1102.f1 g_1903 g_1952 g_1253 g_1994 g_2001 g_957.f1 g_1459.f1 g_510.f1 g_1327 g_620.f1 g_1149 g_2244 g_2364 g_2457
 */
static int8_t  func_20(int64_t  p_21)
{ /* block id: 1 */
    int8_t l_24 = 2L;
    int32_t l_25 = 0x876A47CDL;
    uint64_t *l_48 = &g_49;
    uint8_t l_1649 = 0UL;
    union U2 *l_1869 = &g_1425;
    union U2 * const *l_1868 = &l_1869;
    int32_t l_1894 = (-5L);
    uint64_t l_1901 = 0x688E604589C30C92LL;
    uint16_t *l_1956 = &g_559;
    union U1 **l_1989 = (void*)0;
    union U1 ***l_1988[1];
    int32_t l_1993 = (-3L);
    int16_t l_2011 = 0L;
    uint64_t l_2029 = 0UL;
    uint8_t l_2030 = 255UL;
    int32_t l_2044 = 0x0EA8FE55L;
    int32_t l_2053 = 5L;
    int32_t l_2054 = 0x1CAF63E3L;
    int32_t l_2055 = 0L;
    int32_t l_2056 = 0x27FCA12AL;
    int32_t l_2057 = 5L;
    int32_t l_2058 = 1L;
    int32_t l_2059 = 0xAAEAC9B7L;
    int32_t l_2060 = 1L;
    int32_t l_2061 = 2L;
    int32_t l_2062 = 2L;
    int32_t l_2063 = 0x26832EC9L;
    int32_t l_2064 = 0x604D586DL;
    int32_t l_2065[7][7][5] = {{{0x15517715L,7L,7L,0x15517715L,7L},{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L},{7L,0x15517715L,7L,7L,0x15517715L},{0x15517715L,7L,7L,0x15517715L,7L},{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L},{7L,0x15517715L,7L,7L,0x15517715L},{0x15517715L,7L,7L,0x15517715L,7L}},{{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L},{7L,0x15517715L,7L,7L,0x15517715L},{0x15517715L,7L,7L,0x15517715L,7L},{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L},{7L,0x15517715L,7L,7L,0x15517715L},{0x15517715L,7L,7L,0x15517715L,7L},{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L}},{{7L,0x15517715L,7L,7L,0x15517715L},{0x15517715L,7L,7L,0x15517715L,7L},{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L},{7L,0x15517715L,7L,7L,0x15517715L},{0x15517715L,7L,7L,0x15517715L,7L},{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L},{7L,0x15517715L,7L,7L,0x15517715L}},{{0x15517715L,7L,7L,0x15517715L,7L},{0x15517715L,0x15517715L,0x527C0BA4L,0x15517715L,0x15517715L},{7L,0x15517715L,7L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L},{7L,7L,0x15517715L,7L,7L},{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L}},{{7L,7L,0x15517715L,7L,7L},{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L},{7L,7L,0x15517715L,7L,7L},{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L},{7L,7L,0x15517715L,7L,7L}},{{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L},{7L,7L,0x15517715L,7L,7L},{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L},{7L,7L,0x15517715L,7L,7L},{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L}},{{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L},{7L,7L,0x15517715L,7L,7L},{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L},{7L,7L,0x15517715L,7L,7L},{0x527C0BA4L,7L,0x527C0BA4L,0x527C0BA4L,7L},{7L,0x527C0BA4L,0x527C0BA4L,7L,0x527C0BA4L}}};
    int32_t l_2099 = 0x35628877L;
    uint32_t l_2105 = 0x01AB27DBL;
    struct S0 ****l_2117[10] = {&g_1142,&g_1142,&g_1142,&g_1142,&g_1142,&g_1142,&g_1142,&g_1142,&g_1142,&g_1142};
    struct S0 *****l_2116 = &l_2117[3];
    uint16_t l_2130 = 65527UL;
    union U2 **l_2144[1];
    union U2 ***l_2143 = &l_2144[0];
    int32_t l_2242 = 0x284F583EL;
    uint8_t l_2286 = 0xA4L;
    uint16_t l_2311 = 65533UL;
    uint8_t l_2316 = 0x1EL;
    uint32_t l_2319 = 9UL;
    uint64_t * const *l_2336 = &l_48;
    uint32_t l_2343[2][6][10] = {{{0xE782F844L,0xE782F844L,9UL,0UL,0x36CE900BL,4294967288UL,0x5C8286BBL,0x1B5E5F98L,1UL,4294967290UL},{0x1B5E5F98L,0xC1471146L,0x5C8286BBL,6UL,4294967295UL,6UL,0x5C8286BBL,0xC1471146L,0x1B5E5F98L,0xE782F844L},{0xD1AD4BD5L,0xE782F844L,1UL,0x36CE900BL,4294967290UL,0x493033F9L,4294967291UL,4294967295UL,4294967295UL,4294967291UL},{0xC1471146L,0xD1AD4BD5L,0x36CE900BL,0x36CE900BL,0xD1AD4BD5L,0xC1471146L,5UL,0x493033F9L,0x1B5E5F98L,4294967288UL},{4294967288UL,4294967295UL,0xE782F844L,6UL,1UL,9UL,0xC1471146L,9UL,1UL,6UL},{4294967288UL,9UL,4294967288UL,0xD1AD4BD5L,9UL,4294967295UL,0xC1471146L,0x36CE900BL,0x1B5E5F98L,0UL}},{{4294967295UL,0xC1471146L,0x36CE900BL,0x1B5E5F98L,0UL,0UL,0x1B5E5F98L,0x36CE900BL,0xC1471146L,4294967295UL},{1UL,5UL,4294967291UL,0xE782F844L,0x1B5E5F98L,0xC1471146L,0x5C8286BBL,6UL,4294967295UL,6UL},{0x8A08BE86L,4294967291UL,0x1B5E5F98L,5UL,0x1B5E5F98L,4294967291UL,0x8A08BE86L,0UL,0x493033F9L,4294967295UL},{0x1B5E5F98L,0x5C8286BBL,4294967288UL,0x36CE900BL,0UL,9UL,0xE782F844L,0xE782F844L,9UL,0UL},{0x493033F9L,0x5C8286BBL,0x5C8286BBL,0x493033F9L,9UL,0x1B5E5F98L,0x8A08BE86L,4294967295UL,4294967290UL,0xC1471146L},{4294967288UL,4294967291UL,4294967290UL,0x8A08BE86L,0x5C8286BBL,0x36CE900BL,0x5C8286BBL,0x8A08BE86L,4294967290UL,4294967291UL}}};
    int32_t *l_2369 = &l_2242;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1988[i] = &l_1989;
    for (i = 0; i < 1; i++)
        l_2144[i] = &l_1869;
    if (((((l_25 = l_24) | (func_26(p_21, p_21, (safe_div_func_uint16_t_u_u((l_24 >= ((safe_unary_minus_func_uint16_t_u(p_21)) , func_35((safe_lshift_func_int32_t_s_u((safe_div_func_uint8_t_u_u(g_41, func_42(p_21, (p_21 & (((*l_48)--) < ((((func_52(g_54[2]) , p_21) , (void*)0) != (void*)0) > l_24))), g_281))), 13))))), l_24)), l_24, l_1649) , p_21)) ^ 0x7CA60B5B8DB8C683LL) >= 0x75L))
    { /* block id: 784 */
        uint32_t l_1839 = 4294967295UL;
        int32_t l_1841 = 1L;
        int32_t *l_1850[5];
        const uint16_t ***l_1863 = (void*)0;
        const uint16_t ****l_1862 = &l_1863;
        const uint16_t *****l_1861[9] = {&l_1862,&l_1862,&l_1862,&l_1862,&l_1862,&l_1862,&l_1862,&l_1862,&l_1862};
        union U2 *l_1867 = &g_630[1];
        union U2 **l_1866 = &l_1867;
        int32_t ***** const l_1875 = &g_1243;
        uint32_t **l_1884 = &g_591[7][8];
        uint32_t ***l_1883 = &l_1884;
        uint32_t ****l_1882 = &l_1883;
        uint8_t *****l_1951 = (void*)0;
        uint16_t *l_1954 = &g_137;
        int8_t l_1983 = 0x5CL;
        int8_t *l_2031 = &g_1459.f1;
        int64_t l_2035 = 1L;
        int32_t l_2046[5][9] = {{1L,0xF5CF347AL,(-1L),(-1L),(-1L),0xF5CF347AL,1L,0xF5CF347AL,(-1L)},{2L,0xD2D6F5E9L,0xD2D6F5E9L,2L,0xD2D6F5E9L,0xD2D6F5E9L,2L,0xD2D6F5E9L,0xD2D6F5E9L},{1L,0xF5CF347AL,(-1L),(-1L),(-1L),0xF5CF347AL,1L,0xF5CF347AL,(-1L)},{2L,0xD2D6F5E9L,0xD2D6F5E9L,2L,0xD2D6F5E9L,0xD2D6F5E9L,2L,0xD2D6F5E9L,0xD2D6F5E9L},{1L,0xF5CF347AL,(-1L),(-1L),(-1L),0xF5CF347AL,1L,0xF5CF347AL,(-1L)}};
        uint16_t l_2047 = 0xC3C9L;
        uint64_t l_2066 = 0x61C7269561A3958FLL;
        struct S0 ***** const l_2096 = (void*)0;
        uint16_t l_2108 = 0x0014L;
        uint8_t l_2109 = 0xE7L;
        int i, j;
        for (i = 0; i < 5; i++)
            l_1850[i] = (void*)0;
        for (g_375.f1 = 0; (g_375.f1 < 9); g_375.f1 = safe_add_func_uint16_t_u_u(g_375.f1, 7))
        { /* block id: 787 */
            uint64_t l_1823 = 0xDD0D4470AC49EEFFLL;
            int8_t l_1840 = 1L;
            int32_t l_1873 = 0xA6966731L;
            struct S0 * const * const l_1946 = &g_1144;
            struct S0 * const * const *l_1945 = &l_1946;
            struct S0 * const * const **l_1944 = &l_1945;
            struct S0 * const * const ***l_1943[8] = {&l_1944,&l_1944,&l_1944,&l_1944,&l_1944,&l_1944,&l_1944,&l_1944};
            union U3 *l_1961 = &g_375;
            int32_t l_1991 = 0x7ED9ABF7L;
            int32_t l_1992 = 0xDCE63508L;
            int i;
            if ((l_1841 = (safe_div_func_uint32_t_u_u((p_21 > (g_1816 , (safe_mul_func_int32_t_s_s((safe_rshift_func_int32_t_s_u((safe_sub_func_uint64_t_u_u(l_1823, ((safe_mul_func_int16_t_s_s((safe_mul_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(((((g_1830 , ((*g_887) = (safe_div_func_uint32_t_u_u((safe_mod_func_int32_t_s_s(((safe_add_func_int16_t_s_s((8UL >= ((safe_mul_func_int32_t_s_s(l_1839, l_1823)) > 0x09L)), (p_21 && l_1649))) && 4294967286UL), l_1823)), l_1823)))) < p_21) || 0x4DL) | 18446744073709551615UL), g_281)), p_21)), l_1823)) == l_1840))), l_1823)), 0xA76E8C69L)))), p_21))))
            { /* block id: 790 */
                return g_375.f1;
            }
            else
            { /* block id: 792 */
                int32_t **l_1842 = (void*)0;
                int32_t **l_1843 = &g_112[1];
                int32_t **l_1844 = &g_112[1];
                int32_t **l_1845 = &g_112[1];
                int32_t **l_1846 = (void*)0;
                int32_t **l_1847 = &g_112[6];
                int32_t **l_1848 = (void*)0;
                int32_t **l_1849[9];
                int32_t *l_1865 = &g_1043;
                int64_t l_1929[2];
                int i;
                for (i = 0; i < 9; i++)
                    l_1849[i] = &g_112[1];
                for (i = 0; i < 2; i++)
                    l_1929[i] = 0x0B19FDF9E1B74293LL;
                if (((l_1850[1] = &l_25) == (((*l_1865) &= (safe_sub_func_uint64_t_u_u((l_1839 || (l_1839 | l_24)), ((safe_div_func_int32_t_s_s(((safe_mul_func_uint32_t_u_u((safe_mul_func_int8_t_s_s(((l_1861[2] != (void*)0) ^ p_21), ((g_1864 , 0x609CL) , p_21))), l_1841)) == p_21), l_25)) >= 0L)))) , (void*)0)))
                { /* block id: 795 */
                    union U2 * const **l_1870 = (void*)0;
                    union U2 * const **l_1871[3];
                    int64_t l_1874[9];
                    int32_t *****l_1876 = (void*)0;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1871[i] = &l_1868;
                    for (i = 0; i < 9; i++)
                        l_1874[i] = 6L;
                    l_1873 = (l_1866 != (g_1872 = l_1868));
                    l_1874[6] = (p_21 || (***g_361));
                    l_1876 = l_1875;
                    for (g_1412.f2 = (-17); (g_1412.f2 > 38); g_1412.f2 = safe_add_func_uint64_t_u_u(g_1412.f2, 4))
                    { /* block id: 802 */
                        uint32_t *****l_1885 = &g_586[2];
                        int32_t l_1892[2][9];
                        int8_t *l_1893 = &g_1188.f0;
                        int i, j;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 9; j++)
                                l_1892[i][j] = 0x3E9C2B83L;
                        }
                        l_1894 = (g_1879 , ((safe_sub_func_uint32_t_u_u((&g_483 != ((*l_1885) = l_1882)), (safe_lshift_func_uint16_t_u_s(0xF6ADL, (0x28A7L & (0x07L && p_21)))))) && ((safe_rshift_func_uint8_t_u_s(p_21, ((*l_1893) = (safe_lshift_func_int32_t_s_s((l_25 ^= l_1892[0][3]), 3))))) == p_21)));
                    }
                }
                else
                { /* block id: 808 */
                    l_1894 = 0xED80A0B1L;
                }
                for (g_1102.f1 = 5; (g_1102.f1 < (-28)); g_1102.f1--)
                { /* block id: 813 */
                    struct S0 ****l_1902 = &g_1142;
                    int64_t *l_1905[4] = {&g_56[4],&g_56[4],&g_56[4],&g_56[4]};
                    int32_t l_1917[1];
                    int32_t l_1926 = 1L;
                    int32_t l_1934 = 0xF0F756ADL;
                    uint16_t **l_1985 = &l_1956;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1917[i] = 8L;
                    if ((p_21 < (((safe_rshift_func_int64_t_s_s((l_1873 = (l_1894 = ((*g_609) |= (safe_lshift_func_int8_t_s_u((l_25 | (((*l_48) = (**g_1100)) || ((p_21 & l_1901) , ((l_1840 , (g_1811 , (l_1902 = (void*)0))) == (g_1903 = &g_1142))))), p_21))))), 33)) > 250UL) , g_1798[0].f1)))
                    { /* block id: 820 */
                        int8_t *l_1932 = &g_1830.f1;
                        int8_t *l_1933[6] = {&g_630[2].f0,&g_630[2].f0,&g_630[2].f0,&g_630[2].f0,&g_630[2].f0,&g_630[2].f0};
                        int32_t l_1935 = 7L;
                        int16_t *l_1953 = &g_1253[2][4][6];
                        uint16_t **l_1955 = &l_1954;
                        int i;
                        (*l_1847) = ((safe_mul_func_uint16_t_u_u((safe_mod_func_int32_t_s_s((safe_rshift_func_uint64_t_u_s((((((g_1059.f0 > (safe_unary_minus_func_int64_t_s(p_21))) , (safe_mod_func_uint32_t_u_u(0xBD87A529L, (safe_rshift_func_uint16_t_u_u((l_1935 = ((l_1917[0] || (((safe_add_func_uint8_t_u_u((((l_1934 |= (safe_sub_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((safe_add_func_int64_t_s_s(((l_1873 = (g_1879 , (p_21 &= l_1926))) != ((safe_mul_func_int32_t_s_s(l_1929[0], (((((safe_lshift_func_int8_t_s_u(0xC9L, 2)) , (((-6L) && (*g_1101)) <= l_1917[0])) | 7L) || 0x756044D3L) == l_1840))) > l_1823)), (*g_609))), l_1901)) < 0x4BEC607CEB9CB329LL), 0x2F88L))) | l_1901) >= 0x62F0CDE1857476CFLL), l_1840)) && 0x8ED7L) | l_1935)) ^ l_1823)), l_1894))))) , (void*)0) == (void*)0) != (*g_887)), l_1917[0])), l_1917[0])), 0x3951L)) , &l_1935);
                        l_25 = (l_1894 = (safe_mul_func_uint64_t_u_u((safe_lshift_func_int32_t_s_s((((p_21 >= (l_1823 == (((*l_1955) = ((~(safe_rshift_func_uint16_t_u_s((((void*)0 != l_1943[4]) == (p_21 || p_21)), (safe_lshift_func_uint64_t_u_u(((((*l_1953) ^= (&g_1052 == (g_1952 = l_1951))) | (l_1935 == p_21)) , (**g_1100)), 42))))) , l_1954)) != l_1956))) <= l_1894) , l_1934), p_21)), p_21)));
                    }
                    else
                    { /* block id: 831 */
                        union U3 *l_1962 = &g_375;
                        union U1 *l_1981 = (void*)0;
                        union U1 **l_1982 = &g_1352;
                        int32_t l_1984 = 0x43BF7294L;
                        const uint16_t *l_1987 = (void*)0;
                        const uint16_t * const *l_1986 = &l_1987;
                        int32_t l_1990[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1990[i] = 1L;
                        l_1990[1] &= (((safe_mul_func_uint32_t_u_u((safe_sub_func_int32_t_s_s((l_1961 == l_1962), ((safe_sub_func_int32_t_s_s((3UL || ((+(((l_25 &= (((+l_1894) , (safe_sub_func_uint32_t_u_u((g_1969 , ((((l_1873 < ((safe_sub_func_uint8_t_u_u((p_21 < (safe_sub_func_int32_t_s_s((~((safe_lshift_func_uint64_t_u_s((safe_sub_func_int8_t_s_s(((safe_sub_func_int8_t_s_s((((*l_1982) = l_1981) != (void*)0), 251UL)) || l_1873), 6UL)), 41)) ^ (*g_887))), l_1983))), p_21)) == g_1811.f2)) > l_1984) , p_21) != 0x45D65BB8L)), 5UL))) != l_1901)) , l_1985) != l_1986)) != p_21)), p_21)) >= p_21))), l_1984)) , &g_1351) != l_1988[0]);
                    }
                    g_1994--;
                    for (g_1412.f2 = 25; (g_1412.f2 < 27); g_1412.f2++)
                    { /* block id: 839 */
                        return p_21;
                    }
                }
                for (g_1412.f2 = 0; (g_1412.f2 <= 3); g_1412.f2 += 1)
                { /* block id: 845 */
                    const int32_t *l_1999[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_1999[i] = &g_774;
                    g_2001 = l_1999[6];
                    for (g_957.f1 = 0; (g_957.f1 <= 3); g_957.f1 += 1)
                    { /* block id: 849 */
                        if (p_21)
                            break;
                    }
                }
            }
        }
        if ((safe_sub_func_int8_t_s_s((+(safe_div_func_int64_t_s_s((safe_mul_func_int64_t_s_s(((((*l_48)--) | l_2011) , ((*g_1389) != (void*)0)), ((g_1879.f1 || (safe_div_func_int8_t_s_s(((*l_2031) = (safe_rshift_func_int16_t_s_s(g_1811.f3, (safe_unary_minus_func_int16_t_s(((((safe_add_func_uint16_t_u_u(((l_1993 ^= ((((safe_mod_func_uint16_t_u_u(p_21, (safe_rshift_func_int64_t_s_u((8L == ((safe_mul_func_int8_t_s_s(g_1798[0].f1, (((*l_1956) ^= ((*g_887) = (safe_rshift_func_int16_t_s_u((((*g_609) = ((safe_div_func_int64_t_s_s((g_789.f3 | p_21), (-8L))) >= l_2029)) < 0x5DE7708977571ED6LL), 15)))) < p_21))) | (-1L))), 20)))) , 0xD4622B85L) > p_21) == p_21)) < 0L), p_21)) | l_25) >= p_21) <= l_2030)))))), p_21))) , 18446744073709551610UL))), p_21))), p_21)))
        { /* block id: 861 */
            uint32_t l_2045 = 4294967295UL;
            l_1993 = ((g_2032 , ((p_21 | (safe_div_func_int16_t_s_s(g_619.f2, (l_2035 || (safe_mod_func_uint8_t_u_u((p_21 > (safe_sub_func_int32_t_s_s(l_24, ((safe_lshift_func_int64_t_s_s(((*g_609) &= ((safe_mul_func_int64_t_s_s((l_2044 < l_2045), ((l_2046[2][1] , l_2047) || (-1L)))) >= (*g_805))), 37)) <= l_2045)))), l_2045)))))) , g_559)) ^ 0x51L);
        }
        else
        { /* block id: 864 */
            int32_t l_2050[1];
            int32_t l_2051 = (-1L);
            int32_t l_2052[10][10] = {{(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L),0L},{(-1L),(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L)},{(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L),0L},{(-1L),(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L)},{(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L),0L},{(-1L),(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L)},{(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L),0L},{(-1L),(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L)},{(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L),0L},{(-1L),(-1L),0L,0L,(-1L),(-1L),0L,0L,(-1L),(-1L)}};
            int32_t **l_2097 = &g_112[0];
            int i, j;
            for (i = 0; i < 1; i++)
                l_2050[i] = 0xE88F142DL;
            for (g_1459.f1 = (-5); (g_1459.f1 == 8); g_1459.f1 = safe_add_func_int64_t_s_s(g_1459.f1, 1))
            { /* block id: 867 */
                return p_21;
            }
            l_2066--;
            for (l_2066 = 0; (l_2066 > 49); l_2066++)
            { /* block id: 873 */
                uint8_t l_2088 = 0x9FL;
                uint16_t ***l_2095 = &g_886;
                int16_t *l_2098 = &l_2011;
                l_2052[6][3] = ((safe_mul_func_uint64_t_u_u(l_1993, (p_21 = (((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s(((safe_div_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u(((**g_1100) < (safe_mod_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s(((*l_2098) = ((((p_21 ^ (~((safe_mod_func_uint8_t_u_u(l_2088, (safe_div_func_uint16_t_u_u((safe_lshift_func_int64_t_s_s(p_21, 40)), (safe_lshift_func_uint64_t_u_s((l_2088 || g_853.f2), 50)))))) >= p_21))) == (((((((((void*)0 != l_2095) , g_1652.f1) | p_21) , 0UL) || p_21) < p_21) , l_2096) == l_2096)) , (void*)0) == l_2097)), 4)), 0x88BF7C99D03196C5LL))), l_2099)), (-1L))) && p_21), 9)), g_1327)) == l_2088) , 0x160D3F840BC65277LL)))) >= l_1894);
            }
            for (l_2058 = 0; (l_2058 >= (-8)); l_2058--)
            { /* block id: 880 */
                int64_t l_2102 = 0x2FC9516B27D256DALL;
                int32_t l_2103 = 0xF4EF8AACL;
                int32_t l_2104[10] = {(-8L),0x5AF5DF38L,0x5AF5DF38L,(-8L),0x4E9B304CL,(-8L),0x5AF5DF38L,0x5AF5DF38L,(-8L),0x4E9B304CL};
                int i;
                ++l_2105;
                l_2055 = l_2058;
                l_2103 ^= l_2104[8];
            }
        }
        l_2056 = l_2108;
        l_2109 = 0x7D83C731L;
    }
    else
    { /* block id: 888 */
        int8_t l_2110 = 0x61L;
        int32_t *l_2111 = &l_25;
        int32_t *l_2112[9] = {&l_2060,&l_2060,&l_2060,&l_2060,&l_2060,&l_2060,&l_2060,&l_2060,&l_2060};
        uint16_t l_2113[4][2][7] = {{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,65530UL,65530UL,1UL,65530UL,65530UL,1UL}},{{65535UL,1UL,65535UL,65535UL,1UL,65535UL,65535UL},{1UL,1UL,0xBEFBL,1UL,1UL,0xBEFBL,1UL}},{{1UL,65535UL,65535UL,1UL,65535UL,65535UL,1UL},{65530UL,1UL,65530UL,65530UL,1UL,65530UL,65530UL}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,65530UL,65530UL,1UL,65530UL,65530UL,1UL}}};
        uint16_t **l_2141 = &l_1956;
        union U3 *l_2241 = (void*)0;
        uint8_t l_2243 = 0xF5L;
        union U2 *l_2306 = &g_630[1];
        uint16_t l_2310[6][5] = {{1UL,4UL,0UL,4UL,1UL},{0x5A90L,0x02B9L,65528UL,1UL,9UL},{65528UL,0x02B9L,0x5A90L,0x5A90L,0x02B9L},{0UL,4UL,1UL,0x02B9L,9UL},{4UL,0x5A90L,1UL,0xCC3DL,1UL},{9UL,9UL,0x5A90L,0UL,65526UL}};
        int i, j, k;
        ++l_2113[1][0][0];
        if (((*l_2111) = (l_2116 != (void*)0)))
        { /* block id: 891 */
            uint64_t l_2131 = 18446744073709551615UL;
            int32_t *l_2148 = (void*)0;
            int32_t l_2180[6][9] = {{0xD3CE6915L,1L,0xD3CE6915L,1L,0x4BEC71C2L,1L,0xD3CE6915L,1L,0xD3CE6915L},{0x73F14E7DL,0L,0x73F14E7DL,0x73F14E7DL,0L,0x73F14E7DL,0x73F14E7DL,0L,0x73F14E7DL},{0xD3CE6915L,1L,0xD3CE6915L,1L,0x4BEC71C2L,1L,0xD3CE6915L,1L,0xD3CE6915L},{0x73F14E7DL,0L,0x73F14E7DL,0x73F14E7DL,0L,0x73F14E7DL,0x73F14E7DL,0L,0x73F14E7DL},{0xD3CE6915L,1L,0x5F1D595BL,0xFD12B937L,0xD3CE6915L,0xFD12B937L,0x5F1D595BL,1L,0x5F1D595BL},{1L,0x73F14E7DL,1L,1L,0x73F14E7DL,1L,1L,0x73F14E7DL,1L}};
            uint16_t l_2189[10] = {0x6A05L,0UL,0x9D98L,0UL,0x6A05L,0x6A05L,0UL,0x9D98L,0UL,0x6A05L};
            uint8_t *l_2215 = (void*)0;
            uint8_t *l_2216 = (void*)0;
            uint8_t *l_2217 = &g_106;
            int32_t l_2245 = (-2L);
            int i, j;
            for (l_2057 = 0; (l_2057 < (-25)); l_2057--)
            { /* block id: 894 */
                int32_t l_2120 = 1L;
                uint32_t l_2121[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_2121[i] = 7UL;
                l_2121[2]++;
                (*l_2111) = 0xF76959E5L;
            }
            for (l_25 = 0; (l_25 <= 6); l_25 += 1)
            { /* block id: 900 */
                int64_t l_2126 = 0xD93DEBC82FB15A1ALL;
                uint8_t l_2178[10][4] = {{0UL,1UL,250UL,0UL},{1UL,0x0FL,255UL,254UL},{0xB2L,0UL,246UL,254UL},{1UL,0x0FL,0x44L,0UL},{253UL,1UL,253UL,250UL},{246UL,0xEAL,248UL,0x0FL},{254UL,253UL,0UL,0xEAL},{5UL,0x75L,0UL,0UL},{254UL,0xB1L,248UL,248UL},{246UL,246UL,253UL,5UL}};
                int32_t l_2181 = 0x9B35CC78L;
                int i, j;
                for (g_510.f1 = 0; (g_510.f1 <= 6); g_510.f1 += 1)
                { /* block id: 903 */
                    uint32_t l_2129 = 0x95682DD5L;
                    int16_t *l_2138 = &g_1327;
                    uint16_t **l_2142 = &g_887;
                    union U2 ****l_2145 = &l_2143;
                    int32_t l_2146 = (-3L);
                    int32_t ****l_2177 = (void*)0;
                    int i;
                    l_2146 &= (safe_mod_func_uint64_t_u_u(((((*l_48) = l_2126) != (safe_div_func_int32_t_s_s((l_2065[4][3][1] != (l_2129 >= l_2130)), (((&l_1868 != ((*l_2145) = ((((((((l_2131 > p_21) && (((safe_mod_func_uint16_t_u_u(((safe_lshift_func_int32_t_s_s((safe_div_func_uint64_t_u_u(((g_1253[2][5][2] = ((*l_2138) = g_619.f3)) || ((((safe_rshift_func_int16_t_s_u((l_2141 != l_2142), 12)) && p_21) <= 0x4D4B0D6CL) != 0x459CL)), l_2126)), 4)) ^ p_21), g_1879.f1)) == 0xBD2C60D58EC061FDLL) , p_21)) && l_2126) > l_2129) > l_2126) ^ 0x3EL) >= p_21) , l_2143))) == l_2105) , p_21)))) < 0UL), l_2131));
                    for (l_2060 = 6; (l_2060 >= 0); l_2060 -= 1)
                    { /* block id: 911 */
                        int32_t *l_2147 = &l_2099;
                        int32_t l_2169 = 0xCBD4BD64L;
                        uint8_t *l_2176 = &l_1649;
                        uint64_t l_2179 = 18446744073709551615UL;
                        int i;
                        g_112[g_510.f1] = (p_21 , (((*l_2147) |= 1L) , l_2148));
                        l_2179 = (((safe_div_func_int16_t_s_s((((safe_mod_func_uint32_t_u_u((safe_mod_func_int16_t_s_s((((safe_mul_func_int64_t_s_s(((safe_rshift_func_int64_t_s_s((p_21 != (((safe_div_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((*g_609) , ((safe_mul_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u((safe_div_func_int16_t_s_s(l_2126, (l_2169 , p_21))), (((((0x3EL & (safe_mul_func_uint8_t_u_u(p_21, (((safe_rshift_func_uint64_t_u_s(((safe_add_func_int16_t_s_s((((((*l_2176) |= p_21) | (l_2146 = l_2126)) && p_21) & p_21), (-1L))) > (-1L)), 9)) , g_789.f0) & p_21)))) , (*g_1242)) == l_2177) == p_21) && p_21))), 0UL)) == p_21)), 0x2794L)), 0xAEL)) <= p_21) , 0x2FB133B1L)), p_21)) < l_2053), 0x071AF8EA6E9C2079LL)) >= l_2054) ^ l_2178[0][3]), p_21)), p_21)) , p_21) >= p_21), p_21)) || g_1969.f0) , p_21);
                        l_2180[2][6] ^= l_2062;
                        return g_619.f0;
                    }
                    l_2181 = p_21;
                    for (g_375.f1 = 0; (g_375.f1 <= 0); g_375.f1 += 1)
                    { /* block id: 923 */
                        union U3 **l_2182[7][1][5] = {{{(void*)0,&g_634,&g_634,&g_634,(void*)0}},{{(void*)0,&g_634,&g_634,&g_634,(void*)0}},{{(void*)0,&g_634,&g_634,&g_634,(void*)0}},{{(void*)0,&g_634,&g_634,&g_634,(void*)0}},{{(void*)0,&g_634,&g_634,&g_634,(void*)0}},{{(void*)0,&g_634,&g_634,&g_634,(void*)0}},{{(void*)0,&g_634,&g_634,&g_634,(void*)0}}};
                        int i, j, k;
                        (*g_1021) = (void*)0;
                        l_2146 ^= 0x2831713BL;
                        if (p_21)
                            break;
                    }
                }
                for (g_620.f1 = 0; (g_620.f1 <= 0); g_620.f1 += 1)
                { /* block id: 931 */
                    uint32_t l_2204 = 4294967292UL;
                    int32_t l_2210 = 0L;
                    int32_t l_2212 = 0x3CB87840L;
                    l_2189[2] &= (safe_add_func_int8_t_s_s((-3L), ((safe_rshift_func_uint64_t_u_u(0UL, 48)) || (safe_mul_func_int16_t_s_s(g_789.f3, p_21)))));
                    for (g_106 = 0; (g_106 <= 0); g_106 += 1)
                    { /* block id: 935 */
                        uint32_t *l_2205 = (void*)0;
                        uint32_t *l_2206 = &g_1343[0][0].f2;
                        uint32_t *l_2207 = &g_1059.f2;
                        uint32_t *l_2208 = &g_1343[0][0].f2;
                        uint32_t *l_2209[2][9][4] = {{{(void*)0,(void*)0,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0},{&l_2204,(void*)0,&g_82,&l_2204},{(void*)0,(void*)0,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0},{&l_2204,(void*)0,&g_82,&l_2204},{(void*)0,(void*)0,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0},{&l_2204,(void*)0,&g_82,&l_2204}},{{(void*)0,(void*)0,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0},{&l_2204,(void*)0,&g_82,&l_2204},{(void*)0,(void*)0,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0},{&l_2204,(void*)0,&g_82,&l_2204},{(void*)0,(void*)0,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0},{&l_2204,(void*)0,&g_82,&l_2204}}};
                        int i, j, k;
                        (*g_1148) = (*g_1148);
                        l_2212 = (safe_add_func_int32_t_s_s(((safe_mul_func_uint64_t_u_u((0x35L && ((safe_rshift_func_uint32_t_u_u((((((*l_48) = 0x7E9F21C9B6CD04CDLL) , l_2060) && ((--(*l_48)) != (p_21 & p_21))) > (0UL | 0x69376522L)), p_21)) & (safe_lshift_func_int8_t_s_u((((safe_sub_func_uint32_t_u_u((l_2210 |= ((g_55 = ((((p_21 ^ 0x9FF7503AL) <= l_2178[0][3]) || p_21) == l_2204)) , p_21)), p_21)) | 0UL) == g_2211), l_2204)))), (*g_609))) || 0xC5ABL), 6L));
                    }
                }
            }
            (*l_2111) = (safe_add_func_uint8_t_u_u(p_21, ((*l_2217) &= l_2011)));
            l_2245 = (safe_mod_func_int64_t_s_s(((((p_21 = ((l_2180[2][7] = (g_2244 = (((void*)0 != g_2220[0]) && (safe_rshift_func_int32_t_s_s((safe_mod_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u(((safe_rshift_func_int32_t_s_u(((*l_2111) = ((0L | ((((p_21 != (safe_rshift_func_int64_t_s_s(p_21, (safe_mod_func_int16_t_s_s(((safe_lshift_func_int64_t_s_u((*g_609), ((safe_add_func_uint32_t_u_u((((-1L) <= 0UL) ^ (safe_mul_func_int16_t_s_s((safe_add_func_int8_t_s_s((l_2241 == (void*)0), g_55)), p_21))), p_21)) > (-10L)))) < g_374.f0), g_1538))))) && l_2242) || l_2243) >= 0x2FC9DABCL)) ^ p_21)), 15)) < 0xB13CFF85L), 0xC5L)) ^ 0x76A221E1L), 65532UL)), 13))))) & l_1993)) <= l_2242) && p_21) , 0x57C2A8B70F5D9662LL), l_2054));
        }
        else
        { /* block id: 952 */
            uint32_t *l_2266 = (void*)0;
            int32_t l_2269 = 0x33157052L;
            int16_t *l_2309 = &l_2011;
            int16_t *l_2312 = (void*)0;
            int16_t *l_2313 = (void*)0;
            int16_t *l_2314 = &g_1327;
            uint32_t l_2315 = 0xB40BA7A8L;
            for (g_1412.f2 = 0; (g_1412.f2 > 37); g_1412.f2++)
            { /* block id: 955 */
                int64_t l_2268 = 0x9640E1577BE735B5LL;
                int32_t l_2279 = 1L;
                int32_t l_2280 = (-7L);
                int32_t l_2281 = 0x3F79C988L;
                for (l_25 = 27; (l_25 < (-16)); l_25--)
                { /* block id: 958 */
                    int32_t l_2258 = 0x45943CDAL;
                    int32_t l_2267 = 0x62595B8CL;
                    int32_t l_2270 = 0x88D8CC67L;
                    if ((safe_mul_func_uint16_t_u_u((0x0BL & (((safe_div_func_uint8_t_u_u(p_21, p_21)) , (((safe_mul_func_uint64_t_u_u(0x1A1A39BFC11C9306LL, (safe_rshift_func_uint8_t_u_s((l_1894 &= l_2258), 2)))) , (!((*g_887) = (++(**l_2141))))) == g_1566.f0)) == (safe_mul_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u((0x48BB49DA01FE0272LL && ((void*)0 == l_2266)), 2L)) , (**g_1100)), (*g_1101))))), 0xABE0L)))
                    { /* block id: 962 */
                        uint32_t l_2271 = 18446744073709551607UL;
                        l_2271++;
                        return l_2268;
                    }
                    else
                    { /* block id: 965 */
                        uint32_t l_2274 = 18446744073709551611UL;
                        l_2274++;
                        if (p_21)
                            break;
                    }
                    for (l_2110 = 26; (l_2110 >= (-16)); l_2110 = safe_sub_func_int32_t_s_s(l_2110, 8))
                    { /* block id: 971 */
                        uint32_t l_2282 = 0x95261AE0L;
                        --l_2282;
                    }
                }
            }
            l_2062 &= ((~(l_2269 = l_2286)) <= (safe_sub_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u((*g_1101), (safe_mul_func_int16_t_s_s((p_21 | ((((safe_rshift_func_uint32_t_u_u((((safe_add_func_int16_t_s_s(((*l_2314) |= (safe_lshift_func_int16_t_s_u((((safe_add_func_int64_t_s_s((g_2301 , (safe_mod_func_int64_t_s_s(((0L >= ((((p_21 <= ((l_2306 == (void*)0) , (((*l_2309) &= ((safe_add_func_int32_t_s_s((0x9291L && 0xC398L), l_1901)) == p_21)) >= p_21))) , (*l_2111)) < l_2310[0][3]) < p_21)) <= l_2311), p_21))), l_2105)) & 0x414BL) ^ 0x3FE2A04F454AEDB1LL), 2))), 0L)) & l_1993) & p_21), 26)) ^ 0x20EFL) >= p_21) & l_2315)), g_1687)))), 0x31CAL)));
        }
        (****g_1242) = l_2112[5];
        l_2316--;
    }
    if (l_2319)
    { /* block id: 984 */
        uint16_t l_2320 = 1UL;
        return l_2320;
    }
    else
    { /* block id: 986 */
        union U2 *l_2323 = &g_1102;
        int8_t *l_2324[1];
        int32_t l_2325 = 0xE0D5DEA3L;
        struct S0 *l_2326 = &g_2327;
        int32_t l_2330 = 0x0D782557L;
        uint64_t **l_2335[10] = {&l_48,&l_48,&l_48,&l_48,&l_48,&l_48,&l_48,&l_48,&l_48,&l_48};
        int32_t l_2340 = 0L;
        int32_t l_2341 = 8L;
        int32_t l_2342 = (-1L);
        int32_t l_2351 = 1L;
        union U2 *** const l_2358[7][1] = {{&l_2144[0]},{&l_2144[0]},{&l_2144[0]},{&l_2144[0]},{&l_2144[0]},{&l_2144[0]},{&l_2144[0]}};
        const uint8_t l_2359 = 254UL;
        uint16_t **l_2393 = &g_887;
        uint64_t l_2440[2];
        int8_t *l_2449[2];
        int64_t ****l_2451[1][6][5] = {{{&g_1228[2][6][3],&g_1149,&g_1228[2][7][0],&g_1229,&g_1228[5][6][1]},{&g_1228[2][7][0],(void*)0,&g_1149,&g_1149,(void*)0},{(void*)0,&g_1228[5][7][0],&g_1228[2][7][0],&g_1228[5][6][1],&g_1228[3][2][1]},{&g_1228[2][6][3],&g_1228[5][7][0],&g_1228[5][6][1],(void*)0,(void*)0},{&g_1228[3][4][2],(void*)0,(void*)0,&g_1228[3][4][2],(void*)0},{&g_1228[2][6][3],&g_1149,&g_1228[3][2][1],&g_1228[3][5][0],(void*)0}}};
        int64_t *****l_2452 = &l_2451[0][5][2];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_2324[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_2440[i] = 18446744073709551615UL;
        for (i = 0; i < 2; i++)
            l_2449[i] = &g_630[2].f0;
        if (((((((((l_2044 = (!((((l_2325 = ((**l_2143) != (g_2322 , l_2323))) == (((void*)0 != l_2326) || (safe_lshift_func_int64_t_s_u(l_2330, (0x98L == (safe_mod_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u(p_21, 11)), (((*l_1956) ^= (p_21 >= 1UL)) & p_21)))))))) > l_2063) <= l_2330))) > l_2330) , l_2335[6]) != l_2336) ^ 0x77L) > 0x4492BDCA7D1503D4LL) > 0xF1017A0ABA9B552DLL) | p_21))
        { /* block id: 990 */
            int32_t *l_2337 = &l_1894;
            int32_t *l_2338 = &l_2242;
            int32_t *l_2339[2][9][9] = {{{(void*)0,(void*)0,&l_2057,&l_2054,&l_2059,(void*)0,&l_2064,&l_2063,&l_2057},{&l_2063,&l_2059,&l_2057,&l_2063,(void*)0,&l_1894,&l_2044,&l_2062,(void*)0},{&l_2064,(void*)0,&l_2055,&l_2055,(void*)0,&l_2061,&l_2065[4][3][1],(void*)0,&g_2244},{&l_2062,&l_2063,&l_2044,&g_2244,&l_2064,(void*)0,&l_2065[4][3][1],(void*)0,&l_2063},{&l_2057,&l_2044,&l_2325,&l_2053,&l_2053,&l_2325,&l_2044,&l_2057,(void*)0},{&l_2055,&l_2054,&l_1993,&l_2061,&l_2044,&l_2060,&l_2064,&l_2065[4][3][1],(void*)0},{(void*)0,&l_2063,&l_1993,&l_2060,(void*)0,&l_2044,&l_2063,&l_2059,(void*)0},{&l_2063,&l_2057,&l_2064,(void*)0,&l_2059,&l_2062,&l_2053,&l_2330,&l_2063},{&l_1894,&l_1894,&l_2057,&l_2044,&l_2330,&l_2055,(void*)0,&l_2044,&g_2244}},{{&l_2064,&l_1894,&l_2064,(void*)0,(void*)0,&l_2044,&l_2044,(void*)0,(void*)0},{(void*)0,&l_2057,(void*)0,&l_1894,&l_2064,(void*)0,&l_2061,&l_1894,&l_2057},{&l_2063,&l_2063,&l_2061,&l_2053,&l_2057,&l_1993,&l_1894,&l_2063,&l_1993},{&l_2060,&l_2054,&g_2244,&l_1894,&l_2064,(void*)0,&l_2055,&l_2055,(void*)0},{&l_1894,&l_2044,&l_2062,(void*)0,(void*)0,&l_2063,&l_2063,&l_2060,&l_1894},{&l_2330,&l_2063,&l_2060,&l_2044,&l_2059,&l_2063,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&l_2057,(void*)0,&l_2057,(void*)0,(void*)0,&l_2063,&l_2065[4][3][1]},{&l_2064,&l_2059,&l_2053,&l_2060,&l_2062,&l_1993,&g_2244,(void*)0,&l_1894},{&l_1993,(void*)0,(void*)0,&l_2061,&l_2060,(void*)0,&l_2325,&l_2063,&l_2062}}};
            int i, j, k;
            --l_2343[1][0][2];
        }
        else
        { /* block id: 992 */
            int64_t ****l_2348 = (void*)0;
            int32_t l_2357 = 0x0557B0DFL;
            uint16_t **l_2392 = &g_887;
            uint8_t l_2423 = 0x88L;
            int64_t l_2428 = 0L;
            uint32_t *l_2436 = &g_1343[0][0].f2;
            uint32_t *l_2437 = &g_1412.f2;
            uint32_t *l_2438 = &g_1343[0][0].f2;
            uint32_t *l_2439[1][6][10] = {{{&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319},{&l_2343[0][3][6],&l_2343[0][3][6],&l_2319,&l_2343[0][3][6],&l_2343[0][3][6],&l_2319,&l_2343[0][3][6],&l_2343[0][3][6],&l_2319,&l_2343[0][3][6]},{&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6]},{&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319},{&l_2343[0][3][6],&l_2343[0][3][6],&l_2319,&l_2343[0][3][6],&l_2343[0][3][6],&l_2319,&l_2343[0][3][6],&l_2343[0][3][6],&l_2319,&l_2343[0][3][6]},{&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6],&l_2319,&l_2319,&l_2343[0][3][6]}}};
            int8_t **l_2446[10][10][2] = {{{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{(void*)0,&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]}},{{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{(void*)0,(void*)0},{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]}},{{&l_2324[0],&l_2324[0]},{&l_2324[0],(void*)0},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_2324[0]},{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]}},{{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]}},{{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,(void*)0},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]}},{{(void*)0,&l_2324[0]},{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{(void*)0,&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]}},{{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],(void*)0},{(void*)0,&l_2324[0]},{(void*)0,(void*)0},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]}},{{(void*)0,&l_2324[0]},{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{(void*)0,(void*)0},{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{(void*)0,(void*)0},{&l_2324[0],&l_2324[0]}},{{&l_2324[0],&l_2324[0]},{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],(void*)0},{&l_2324[0],&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],(void*)0}},{{&l_2324[0],&l_2324[0]},{&l_2324[0],&l_2324[0]},{&l_2324[0],(void*)0},{(void*)0,&l_2324[0]},{(void*)0,&l_2324[0]},{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{&l_2324[0],(void*)0},{(void*)0,(void*)0},{&l_2324[0],(void*)0}}};
            int16_t *l_2447 = &g_1327;
            int32_t l_2448 = 0L;
            int16_t *l_2450 = &g_1253[2][4][6];
            int i, j, k;
            if (((l_1993 ^= (safe_add_func_uint16_t_u_u((((((void*)0 == l_2348) <= (0L && (((l_2330 > (safe_rshift_func_int8_t_s_s(p_21, l_2351))) , ((*g_887) ^= (((safe_rshift_func_uint32_t_u_u((safe_rshift_func_uint32_t_u_u((+l_2357), 11)), 22)) >= (((l_2358[1][0] != &l_2144[0]) , (**g_362)) > l_2359)) != l_2357))) & l_2065[4][3][1]))) != p_21) != 255UL), g_1969.f0))) | 0x89L))
            { /* block id: 995 */
                uint8_t l_2377 = 252UL;
                int16_t *l_2383 = &l_2011;
                uint8_t *l_2394 = &l_2286;
                int16_t l_2395 = 7L;
                if (p_21)
                { /* block id: 996 */
                    (*g_2363) &= (!(--g_1687));
                }
                else
                { /* block id: 999 */
                    int32_t *l_2370 = &l_2357;
                    g_2364 = &l_2336;
                    l_2059 ^= (g_789.f3 | l_2357);
                    for (l_2330 = 0; (l_2330 <= (-13)); l_2330 = safe_sub_func_int16_t_s_s(l_2330, 9))
                    { /* block id: 1004 */
                        l_2370 = ((*g_383) = l_2369);
                    }
                    return g_1994;
                }
                (*l_2369) = ((safe_add_func_uint64_t_u_u(0x5B2C149B77D7F2AFLL, 0x7F6AC3B5ACFBA1E8LL)) & ((((((safe_sub_func_uint8_t_u_u(((*l_2143) == (*l_2143)), ((*g_212) , 1UL))) && (((*g_609) = (((**g_1389) , 6UL) >= (safe_mul_func_uint16_t_u_u((&g_1903 != &l_2117[3]), p_21)))) && l_2330)) >= l_2357) || l_2377) >= p_21) && l_2357));
                (*l_2369) = (!(g_2379 , (l_2395 = (((!((*g_887) = ((void*)0 != (**g_588)))) == p_21) != ((safe_div_func_uint8_t_u_u(((*l_2394) = (((*l_2383) = 1L) && (((((65529UL > (((safe_rshift_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(0UL, (safe_add_func_int16_t_s_s(p_21, g_1652.f2)))), g_1798[0].f3)) == 0xF3L) != p_21)) <= p_21) | l_2330) , l_2392) == l_2393))), g_2211)) < p_21)))));
                l_2357 = (((((*g_609) = ((safe_unary_minus_func_int64_t_s((((p_21 & p_21) && (safe_sub_func_int16_t_s_s(((*l_2383) = (l_2340 = p_21)), ((safe_rshift_func_int16_t_s_s(((g_2401 , ((*l_2369) = (((((((~(safe_div_func_uint8_t_u_u((safe_add_func_int64_t_s_s(1L, (safe_add_func_int32_t_s_s((!((safe_mul_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(((((safe_div_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((g_2418 , (safe_mod_func_uint16_t_u_u(((&l_2394 == &l_2394) & (safe_mod_func_uint32_t_u_u(l_2423, p_21))), (*l_2369)))), 4)), p_21)) && g_41) < p_21) ^ 0x6175C34AL), p_21)), g_313.f1)) | 0xFFFE23A0L)), 4294967295UL)))), p_21))) && (*g_609)) < 0xC1L) , (void*)0) == &g_1019) && 1UL) == 4294967289UL))) , 0x9304L), 9)) != (-1L))))) , 0L))) && (**g_1100))) && p_21) & l_2286) , 0L);
            }
            else
            { /* block id: 1022 */
                (*l_2369) = (-8L);
            }
            (*l_2369) = (safe_lshift_func_int64_t_s_s(((safe_div_func_uint32_t_u_u(l_2428, (***g_361))) != ((*l_48) = (safe_rshift_func_int64_t_s_s((safe_add_func_int8_t_s_s(((safe_unary_minus_func_int16_t_s(g_56[1])) | (safe_mod_func_uint16_t_u_u((((((p_21 < (++l_2440[1])) , l_2357) && p_21) != l_2357) < ((((((safe_mul_func_int16_t_s_s(((*l_2450) = ((~((l_2324[0] = (void*)0) == (((((l_2448 = ((*l_2447) &= l_2428)) != 1L) > 0x6A3F8C58L) & l_2341) , l_2449[0]))) || l_2357)), p_21)) && 1L) == 0x83L) , &p_21) == (void*)0) && (*l_2369))), p_21))), g_2327.f3)), p_21)))), 10));
        }
        (*l_2452) = l_2451[0][5][2];
        for (g_651 = (-27); (g_651 > 12); ++g_651)
        { /* block id: 1036 */
            const union U2 *l_2455 = &g_429;
            (*g_2456) = l_2455;
        }
    }
    for (g_957.f1 = 0; (g_957.f1 == (-16)); g_957.f1--)
    { /* block id: 1042 */
        (*l_2369) = p_21;
    }
    return g_2327.f3;
}


/* ------------------------------------------ */
/* 
 * reads : g_106 g_1652 g_82 g_1687 g_1690 g_1021 g_1022 g_1713 g_1243 g_1244 g_383 g_281 g_1100 g_1101 g_887 g_137 g_609 g_1798 g_1242 g_1811
 * writes: g_106 g_82 g_1687 g_1022 g_112 g_1102.f0 g_281 g_137 g_220
 */
static struct S0  func_26(int16_t  p_27, int64_t  p_28, int32_t  p_29, uint64_t  p_30, uint32_t  p_31)
{ /* block id: 712 */
    union U1 **l_1653 = &g_1352;
    union U1 **l_1654 = &g_1352;
    union U1 ***l_1655 = (void*)0;
    union U1 ***l_1656 = &l_1654;
    int32_t l_1657 = 0x2249F78EL;
    int32_t l_1679 = 5L;
    int32_t l_1680 = 8L;
    int32_t l_1683 = 9L;
    int32_t l_1684[1][7][10] = {{{0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L},{0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L},{0x8BCCB671L,0x8BCCB671L,0x01214CACL,0x8BCCB671L,0x8BCCB671L,0x01214CACL,0x8BCCB671L,0x8BCCB671L,0x01214CACL,0x8BCCB671L},{0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L},{0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L},{0x8BCCB671L,0x8BCCB671L,0x01214CACL,0x8BCCB671L,0x8BCCB671L,0x01214CACL,0x8BCCB671L,0x8BCCB671L,0x01214CACL,0x8BCCB671L},{0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L,0x7707D581L,0x7707D581L,0x8BCCB671L}}};
    uint32_t l_1710 = 4294967295UL;
    int32_t *l_1718 = &g_281;
    struct S0 ****l_1726[7] = {(void*)0,&g_1142,(void*)0,(void*)0,&g_1142,(void*)0,(void*)0};
    struct S0 *****l_1725 = &l_1726[0];
    uint64_t *l_1749 = &g_49;
    int32_t l_1792[10][4] = {{(-7L),(-7L),0xB8C22289L,(-6L)},{0x21999631L,8L,0x21999631L,0xB8C22289L},{0x21999631L,0xB8C22289L,0xB8C22289L,0x21999631L},{(-7L),0xB8C22289L,(-6L),0xB8C22289L},{0xB8C22289L,8L,(-6L),(-6L)},{(-7L),(-7L),0xB8C22289L,(-6L)},{0x21999631L,8L,0x21999631L,0xB8C22289L},{0x21999631L,0xB8C22289L,0xB8C22289L,0x21999631L},{(-7L),0xB8C22289L,(-6L),0xB8C22289L},{0xB8C22289L,8L,(-6L),(-6L)}};
    int i, j, k;
    for (g_106 = 11; (g_106 >= 46); g_106++)
    { /* block id: 715 */
        return g_1652;
    }
    l_1657 = ((l_1653 = l_1653) != ((*l_1656) = l_1654));
    for (g_82 = 0; (g_82 > 6); g_82++)
    { /* block id: 723 */
        uint64_t l_1662[8] = {18446744073709551613UL,18446744073709551613UL,18446744073709551613UL,18446744073709551613UL,18446744073709551613UL,18446744073709551613UL,18446744073709551613UL,18446744073709551613UL};
        uint32_t *****l_1670 = &g_586[4];
        int32_t l_1678 = 0x5AC43142L;
        int32_t l_1682 = (-7L);
        int32_t l_1685 = (-1L);
        int32_t l_1686[4];
        int16_t l_1791 = 0x2EF0L;
        int64_t l_1793 = 0L;
        int32_t *l_1810 = (void*)0;
        int i;
        for (i = 0; i < 4; i++)
            l_1686[i] = 6L;
        if ((safe_sub_func_uint16_t_u_u(l_1662[6], (p_28 > (p_27 > (0xF08BL > ((((~0x032EL) & (safe_rshift_func_int8_t_s_s((safe_sub_func_int8_t_s_s(((void*)0 != &g_1390), p_29)), 3))) , l_1670) == (void*)0)))))))
        { /* block id: 724 */
            int64_t l_1675 = 0x2D3D74FB37DC1696LL;
            int32_t l_1676[10] = {0L,(-1L),(-1L),0L,0xB18F611CL,0L,(-1L),(-1L),0L,0xB18F611CL};
            int16_t l_1681 = 0x195EL;
            int i;
            for (p_29 = (-16); (p_29 == 13); p_29++)
            { /* block id: 727 */
                int64_t l_1673 = 0x1E54058B48503AD6LL;
                int32_t l_1674 = 0x0DA0A184L;
                int32_t *l_1677[6] = {&l_1657,&l_1674,&l_1674,&l_1657,&l_1674,&l_1674};
                int i;
                l_1674 ^= l_1673;
                --g_1687;
            }
            return g_1690;
        }
        else
        { /* block id: 732 */
            int32_t *l_1691 = &g_281;
            int32_t *l_1692 = &l_1678;
            int32_t *l_1693 = &l_1685;
            int32_t *l_1694 = &l_1686[2];
            int32_t *l_1695 = (void*)0;
            int32_t *l_1696 = &l_1684[0][4][4];
            int32_t *l_1697 = (void*)0;
            int32_t *l_1698 = &l_1686[0];
            int32_t *l_1699 = &g_103;
            int32_t *l_1700 = &g_103;
            int32_t *l_1701 = &l_1683;
            int32_t *l_1702 = &l_1657;
            int32_t *l_1703 = &g_281;
            int32_t *l_1704 = &g_103;
            int32_t *l_1705 = &l_1684[0][4][4];
            int32_t *l_1706 = &l_1657;
            int32_t *l_1707 = &l_1684[0][4][4];
            int32_t *l_1708 = &l_1686[3];
            int32_t *l_1709[1];
            int i;
            for (i = 0; i < 1; i++)
                l_1709[i] = &g_103;
            l_1710--;
            (*g_1713) = (*g_1021);
            (***g_1243) = &l_1684[0][3][8];
        }
        if (p_29)
            break;
        for (g_1102.f0 = (-6); (g_1102.f0 < 17); ++g_1102.f0)
        { /* block id: 740 */
            struct S0 ****l_1724 = &g_1142;
            struct S0 *****l_1723 = &l_1724;
            int32_t l_1770 = (-7L);
            int32_t l_1782 = 0x462C7C60L;
            int32_t l_1783 = 1L;
            int32_t l_1784 = 0x8FC81637L;
            int32_t l_1786 = 0x3FA4E4B2L;
            int32_t l_1789 = 0L;
            int32_t l_1790[6][10][4] = {{{0x3207C7DBL,0x376FB945L,0x576A96E7L,0x576A96E7L},{1L,1L,9L,0xBD6957C6L},{0xA6369900L,1L,(-10L),(-1L)},{0xBD6957C6L,0xB65BF2D7L,0xACFF6A06L,(-10L)},{9L,0xB65BF2D7L,0x018285E7L,(-1L)},{0xB65BF2D7L,1L,0x376FB945L,0xBD6957C6L},{0x54F012E8L,1L,0x36E46255L,0x576A96E7L},{0xACFF6A06L,0x376FB945L,0x5530EF68L,(-1L)},{0x36E46255L,(-1L),(-1L),(-1L)},{(-10L),0xBD6957C6L,(-1L),0xB65BF2D7L}},{{5L,(-1L),1L,0L},{(-1L),0x018285E7L,0xC74E9180L,0x3207C7DBL},{(-1L),4L,1L,9L},{5L,0x3207C7DBL,(-1L),1L},{(-10L),0xA6369900L,(-1L),0x5530EF68L},{0x36E46255L,1L,0x5530EF68L,(-1L)},{0xACFF6A06L,0x36E46255L,0x36E46255L,0xACFF6A06L},{0x54F012E8L,(-1L),0x376FB945L,0x7C4C9580L},{0xB65BF2D7L,0x1B3685A1L,0x018285E7L,0x6842E68FL},{9L,0x5530EF68L,0xACFF6A06L,0x6842E68FL}},{{0xBD6957C6L,0x1B3685A1L,(-10L),0x7C4C9580L},{0xA6369900L,(-1L),9L,0xACFF6A06L},{1L,0x36E46255L,0x576A96E7L,(-1L)},{0x3207C7DBL,1L,(-1L),0x5530EF68L},{7L,0xA6369900L,7L,1L},{(-1L),0x3207C7DBL,0xA6369900L,9L},{0L,4L,(-1L),0x3207C7DBL},{0x376FB945L,0x018285E7L,(-1L),0L},{0L,(-1L),0xA6369900L,0xB65BF2D7L},{(-1L),0xBD6957C6L,7L,(-1L)}},{{7L,(-1L),(-1L),(-1L)},{0x3207C7DBL,0x376FB945L,0x576A96E7L,0x576A96E7L},{1L,1L,9L,0xBD6957C6L},{0xA6369900L,1L,(-10L),(-1L)},{0xBD6957C6L,0xB65BF2D7L,0xACFF6A06L,(-10L)},{9L,0xB65BF2D7L,0x018285E7L,(-1L)},{0xB65BF2D7L,1L,0x376FB945L,0xBD6957C6L},{0x54F012E8L,1L,0x36E46255L,0x576A96E7L},{0xACFF6A06L,0x376FB945L,0x5530EF68L,(-1L)},{0x36E46255L,(-1L),(-1L),(-1L)}},{{(-10L),0xBD6957C6L,(-1L),0xB65BF2D7L},{5L,(-1L),1L,0L},{(-1L),0xA6369900L,0xBD6957C6L,(-1L)},{0x376FB945L,1L,0xB65BF2D7L,1L},{9L,(-1L),0x6842E68FL,0x018285E7L},{1L,0xACFF6A06L,1L,(-1L)},{0x1B3685A1L,0xB65BF2D7L,(-1L),0xC74E9180L},{0x36E46255L,0x1B3685A1L,0x1B3685A1L,0x36E46255L},{(-1L),0x54F012E8L,0x576A96E7L,0x3207C7DBL},{0x5530EF68L,(-1L),0xA6369900L,(-10L)}},{{1L,(-1L),0x36E46255L,(-10L)},{5L,(-1L),1L,0x3207C7DBL},{0xACFF6A06L,0x54F012E8L,1L,0x36E46255L},{1L,0x1B3685A1L,(-1L),0xC74E9180L},{(-1L),0xB65BF2D7L,0x54F012E8L,(-1L)},{0L,0xACFF6A06L,0L,0x018285E7L},{1L,(-1L),0xACFF6A06L,1L},{0x7C4C9580L,1L,0xC74E9180L,(-1L)},{0x576A96E7L,0xA6369900L,0xC74E9180L,0x7C4C9580L},{0x7C4C9580L,0x6842E68FL,0xACFF6A06L,0x5530EF68L}}};
            int8_t l_1794 = 0x47L;
            uint8_t l_1795 = 0x61L;
            int i, j, k;
            for (l_1685 = 0; (l_1685 >= (-14)); l_1685 = safe_sub_func_uint64_t_u_u(l_1685, 4))
            { /* block id: 743 */
                uint64_t *l_1747 = &g_49;
                int32_t l_1763 = (-8L);
                int32_t l_1772 = (-10L);
                int32_t l_1779[8][3][6];
                int16_t l_1806 = 1L;
                int i, j, k;
                for (i = 0; i < 8; i++)
                {
                    for (j = 0; j < 3; j++)
                    {
                        for (k = 0; k < 6; k++)
                            l_1779[i][j][k] = 1L;
                    }
                }
                for (p_28 = 0; (p_28 <= 0); p_28 += 1)
                { /* block id: 746 */
                    (***g_1243) = (l_1718 = &l_1680);
                    (*g_383) = (void*)0;
                }
                for (l_1682 = 0; (l_1682 >= (-10)); l_1682 = safe_sub_func_int64_t_s_s(l_1682, 1))
                { /* block id: 753 */
                    int16_t l_1736 = 0L;
                    int32_t l_1775 = (-1L);
                    int32_t l_1778 = 2L;
                    int32_t l_1780 = (-1L);
                    int32_t l_1781 = 0x0431DB0AL;
                    int32_t l_1785 = (-1L);
                    int32_t l_1787 = 1L;
                    int32_t l_1788[6][8][2] = {{{(-1L),0L},{0x65B7A348L,0x65B7A348L},{0L,(-1L)},{0L,0x2FB9312BL},{0xA277F975L,0x65B7A348L},{(-1L),0xA277F975L},{(-1L),(-1L)},{(-1L),0xA277F975L}},{{(-1L),0x65B7A348L},{0xA277F975L,0x2FB9312BL},{0L,(-1L)},{0L,0x65B7A348L},{0x65B7A348L,0L},{(-1L),0L},{0x2FB9312BL,0xA277F975L},{0x65B7A348L,(-1L)}},{{0xA277F975L,(-1L)},{(-1L),(-1L)},{0xA277F975L,(-1L)},{0x65B7A348L,0xA277F975L},{0x2FB9312BL,0L},{(-1L),0L},{0x65B7A348L,0x65B7A348L},{0L,(-1L)}},{{0L,0x2FB9312BL},{0xA277F975L,0x65B7A348L},{(-1L),0xA277F975L},{(-1L),(-1L)},{(-1L),0xA277F975L},{(-1L),0x65B7A348L},{0xA277F975L,0x2FB9312BL},{0L,(-1L)}},{{0L,0x65B7A348L},{0x65B7A348L,0L},{(-1L),0L},{0x2FB9312BL,0xA277F975L},{0x65B7A348L,(-1L)},{0xA277F975L,(-1L)},{(-1L),(-1L)},{0xA277F975L,(-1L)}},{{0x65B7A348L,0xA277F975L},{0x2FB9312BL,0L},{(-1L),0L},{0x65B7A348L,0x65B7A348L},{0L,(-1L)},{0L,0x2FB9312BL},{0xA277F975L,0x65B7A348L},{(-1L),0xA277F975L}}};
                    int32_t *l_1799 = (void*)0;
                    int32_t *l_1800 = &g_281;
                    int32_t *l_1801 = &l_1786;
                    int32_t *l_1802 = &g_281;
                    int32_t *l_1803 = &g_281;
                    int32_t *l_1804 = &l_1686[0];
                    int32_t *l_1805[1];
                    uint16_t l_1807 = 0x41EBL;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_1805[i] = &l_1779[6][0][4];
                    for (l_1683 = 19; (l_1683 >= (-16)); l_1683 = safe_sub_func_uint8_t_u_u(l_1683, 1))
                    { /* block id: 756 */
                        l_1725 = l_1723;
                    }
                    if (p_29)
                    { /* block id: 759 */
                        uint64_t *l_1729 = (void*)0;
                        uint64_t **l_1748[8] = {&l_1729,&l_1729,&l_1729,&l_1729,&l_1729,&l_1729,&l_1729,&l_1729};
                        int8_t *l_1750 = (void*)0;
                        int8_t *l_1751[6][6][7] = {{{&g_651,&g_1102.f0,(void*)0,&g_1102.f0,&g_630[2].f0,&g_1102.f0,&g_1102.f0},{&g_630[2].f0,&g_1102.f0,&g_630[2].f0,(void*)0,&g_58,&g_651,(void*)0},{&g_651,(void*)0,(void*)0,&g_58,&g_1102.f0,&g_1102.f0,(void*)0},{&g_1188.f0,&g_1425.f0,&g_651,&g_651,&g_1425.f0,&g_1188.f0,(void*)0},{(void*)0,&g_1425.f0,&g_1188.f0,&g_651,&g_651,&g_58,&g_1102.f0},{(void*)0,&g_651,&g_630[2].f0,&g_58,&g_1188.f0,&g_1188.f0,(void*)0}},{{&g_651,&g_1425.f0,&g_1188.f0,&g_630[2].f0,&g_1188.f0,&g_1102.f0,(void*)0},{&g_58,&g_1425.f0,&g_1188.f0,&g_630[2].f0,&g_1188.f0,&g_1425.f0,&g_58},{&g_1425.f0,(void*)0,(void*)0,&g_58,&g_630[2].f0,&g_651,&g_1425.f0},{&g_1425.f0,&g_1188.f0,&g_58,&g_58,&g_630[2].f0,&g_1188.f0,&g_651},{&g_651,&g_1102.f0,(void*)0,&g_651,&g_58,&g_1188.f0,&g_1102.f0},{&g_651,&g_630[2].f0,&g_1188.f0,&g_1425.f0,&g_1425.f0,&g_1188.f0,&g_630[2].f0}},{{&g_630[2].f0,&g_1102.f0,&g_1188.f0,&g_429.f0,&g_1102.f0,&g_630[2].f0,(void*)0},{&g_1102.f0,&g_1188.f0,&g_630[2].f0,&g_630[2].f0,&g_651,&g_630[2].f0,(void*)0},{&g_1102.f0,&g_651,&g_1188.f0,&g_429.f0,&g_1102.f0,&g_58,&g_58},{(void*)0,(void*)0,&g_651,&g_1425.f0,&g_1425.f0,&g_1425.f0,&g_651},{&g_630[2].f0,&g_630[2].f0,(void*)0,&g_651,&g_1102.f0,&g_1102.f0,&g_651},{&g_630[2].f0,(void*)0,&g_651,&g_58,&g_1102.f0,&g_651,&g_58}},{{(void*)0,&g_1102.f0,&g_58,&g_58,&g_1102.f0,&g_1102.f0,&g_630[2].f0},{&g_630[2].f0,&g_1188.f0,&g_1425.f0,&g_630[2].f0,&g_1425.f0,&g_1425.f0,&g_630[2].f0},{&g_1102.f0,(void*)0,&g_1102.f0,&g_630[2].f0,&g_1102.f0,&g_1102.f0,&g_58},{&g_1188.f0,&g_1188.f0,&g_58,&g_58,&g_651,&g_1102.f0,&g_58},{&g_58,&g_58,&g_429.f0,&g_651,&g_1102.f0,&g_1102.f0,&g_651},{(void*)0,(void*)0,(void*)0,&g_651,&g_1425.f0,&g_1425.f0,&g_1425.f0}},{{&g_58,&g_1425.f0,&g_1425.f0,&g_58,&g_58,&g_1102.f0,&g_429.f0},{(void*)0,&g_1188.f0,&g_1425.f0,(void*)0,&g_630[2].f0,&g_651,&g_630[2].f0},{&g_58,&g_651,&g_58,(void*)0,&g_630[2].f0,&g_1102.f0,&g_429.f0},{&g_630[2].f0,&g_58,&g_651,&g_630[2].f0,&g_1188.f0,&g_1425.f0,&g_1425.f0},{&g_1188.f0,&g_1102.f0,&g_1102.f0,&g_1102.f0,&g_1188.f0,&g_58,&g_651},{(void*)0,&g_651,&g_630[2].f0,&g_630[2].f0,&g_1425.f0,&g_1188.f0,&g_1188.f0}},{{&g_630[2].f0,(void*)0,&g_58,&g_58,(void*)0,&g_58,&g_429.f0},{&g_1425.f0,&g_630[2].f0,&g_1188.f0,&g_1188.f0,&g_651,&g_651,&g_651},{(void*)0,(void*)0,&g_1425.f0,&g_1425.f0,(void*)0,(void*)0,&g_58},{&g_651,&g_1188.f0,&g_630[2].f0,(void*)0,&g_1102.f0,&g_1425.f0,&g_651},{&g_1102.f0,&g_630[2].f0,&g_1102.f0,&g_1102.f0,&g_429.f0,(void*)0,&g_1425.f0},{(void*)0,&g_1188.f0,(void*)0,&g_1188.f0,&g_630[2].f0,&g_651,(void*)0}}};
                        int32_t l_1752 = (-1L);
                        int i, j, k;
                        l_1752 &= ((*l_1718) = (((((safe_rshift_func_uint32_t_u_s(1UL, 1)) & p_28) , ((p_30++) <= p_27)) && (-1L)) > (safe_add_func_uint8_t_u_u(p_28, (l_1686[0] = (safe_sub_func_int8_t_s_s(l_1736, (safe_sub_func_uint32_t_u_u((safe_lshift_func_int64_t_s_s(((safe_mul_func_uint32_t_u_u((*l_1718), 0xE3781DEAL)) , (safe_add_func_uint16_t_u_u((safe_div_func_int32_t_s_s(((l_1749 = l_1747) != (*g_1100)), 0x71E15F12L)), 65527UL))), p_28)), 0UL)))))))));
                        (*l_1718) = (safe_div_func_int8_t_s_s(((l_1736 | (p_31 || (safe_add_func_int64_t_s_s((safe_add_func_int64_t_s_s((p_28 , (p_28 = (((safe_rshift_func_int64_t_s_u(0x681223CE300E36E4LL, 47)) != (safe_div_func_uint64_t_u_u(l_1763, ((*g_609) = (((*g_887) ^= (((void*)0 == &g_1028[4][2]) & (0x1DF8L >= ((safe_div_func_int16_t_s_s(l_1763, p_28)) == l_1752)))) || (*l_1718)))))) || p_28))), (-6L))), l_1752)))) > 0xFA5F3B800CF7EF10LL), p_27));
                        l_1763 = (safe_lshift_func_int64_t_s_u(l_1770, 40));
                    }
                    else
                    { /* block id: 770 */
                        int32_t *l_1771 = &l_1684[0][1][0];
                        int32_t *l_1773 = &l_1770;
                        int32_t *l_1774 = &g_103;
                        int32_t *l_1776 = (void*)0;
                        int32_t *l_1777[9] = {&l_1763,&l_1763,&l_1763,&l_1763,&l_1763,&l_1763,&l_1763,&l_1763,&l_1763};
                        int i;
                        l_1795--;
                        return g_1798[0];
                    }
                    l_1807--;
                }
            }
            l_1678 &= p_31;
            l_1810 = (void*)0;
            (*l_1718) ^= 0L;
        }
        (****g_1242) = (void*)0;
    }
    return g_1811;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_56 g_313 g_58 g_223.f0 g_281 g_55 g_220 g_103 g_223.f1 g_361 g_374 g_375 g_380 g_382 g_429 g_213.f0 g_494 g_429.f0 g_510 g_212 g_213 g_483 g_49 g_559 g_573 g_137 g_586 g_588 g_619 g_620 g_648 g_651 g_362 g_100 g_101 g_608 g_609 g_383 g_701 g_726 g_375.f1 g_740 g_776 g_774 g_799 g_429.f1 g_789.f0 g_805 g_140.f1 g_853 g_866 g_1248 g_1261 g_1101 g_932 g_933 g_106 g_1052 g_1053 g_1217.f0 g_1305 g_1326 g_886 g_887 g_1327 g_1253 g_1341 g_1342 g_1343 g_1149 g_1229 g_799.f0 g_1351 g_41 g_957.f0 g_1389 g_1400 g_1401 g_1102.f0 g_1412 g_1425 g_1261.f0 g_1100 g_866.f0 g_776.f0 g_1511 g_1043 g_1195.f0 g_1538 g_1560 g_1566 g_1059.f0 g_1148 g_630.f0 g_1217 g_1635 g_957
 * writes: g_82 g_281 g_223.f1 g_103 g_362 g_49 g_429.f1 g_483 g_56 g_58 g_137 g_559 g_55 g_586 g_608 g_634 g_220 g_112 g_106 g_727 g_375.f1 g_140.f1 g_886 g_651 g_933 g_1048 g_1352 g_1343.f1 g_1458 g_1108.f2 g_1102.f0
 */
static uint16_t  func_35(int64_t  p_36)
{ /* block id: 103 */
    int64_t l_310[10][1] = {{0x80FBD6015E6F5631LL},{0xDB90BB2049C5073ALL},{0x80FBD6015E6F5631LL},{0xDB90BB2049C5073ALL},{0x80FBD6015E6F5631LL},{0xDB90BB2049C5073ALL},{0x80FBD6015E6F5631LL},{0xDB90BB2049C5073ALL},{0x80FBD6015E6F5631LL},{0xDB90BB2049C5073ALL}};
    int32_t l_327 = 2L;
    int32_t *l_333 = &g_281;
    int32_t l_346 = 1L;
    int32_t l_355[9];
    uint32_t l_356 = 0xC8016350L;
    uint16_t *l_376 = (void*)0;
    int16_t l_377 = 0x2E75L;
    int32_t l_397 = 0x920F0F4BL;
    int32_t l_500 = 0xB88AAD5DL;
    uint8_t *l_549 = (void*)0;
    int8_t l_642[4] = {0x29L,0x29L,0x29L,0x29L};
    uint8_t l_676[5][5] = {{0xD2L,0xE3L,0xD2L,0xE3L,0xD2L},{0x54L,0x54L,0x2EL,0x2EL,0x54L},{4UL,0xE3L,4UL,0xE3L,4UL},{0x54L,0x2EL,0x2EL,0x54L,0x54L},{0xD2L,0xE3L,0xD2L,0xE3L,0xD2L}};
    int32_t ***l_717 = &g_383;
    const int32_t *l_773 = &g_774;
    uint64_t *l_781 = &g_55;
    struct S0 *l_788 = &g_789;
    uint32_t *****l_792 = &g_586[4];
    uint64_t *l_794 = &g_49;
    int32_t *l_795 = &l_500;
    uint8_t *l_796 = &l_676[4][1];
    int16_t *l_797 = &l_377;
    int32_t l_798 = 0x927F4BFFL;
    uint32_t l_800 = 4294967295UL;
    uint16_t l_840 = 65529UL;
    uint32_t l_906 = 0x1AA20C2DL;
    uint16_t ****l_924 = (void*)0;
    uint64_t l_1136 = 0x8440B73FF2CF2441LL;
    int64_t *** const l_1147[2][6] = {{&g_608,&g_608,&g_608,&g_608,&g_608,&g_608},{&g_608,&g_608,&g_608,&g_608,&g_608,&g_608}};
    const int32_t l_1156 = 0xA25F2907L;
    int64_t l_1180 = 0x3196AC6C77995075LL;
    union U2 *l_1187 = &g_1188;
    uint64_t l_1234 = 0xD059CD3B41625D9ELL;
    uint16_t l_1255 = 0x00FDL;
    uint32_t l_1274 = 18446744073709551615UL;
    int32_t l_1282 = 0x29FD45F3L;
    uint8_t ****l_1441 = &g_1053;
    uint64_t l_1504 = 0x5245853BD7EEAD2DLL;
    uint8_t l_1581 = 0x0EL;
    uint32_t l_1603 = 0x217E49DFL;
    int i, j;
    for (i = 0; i < 9; i++)
        l_355[i] = 0xD9E9FC14L;
    if (l_310[9][0])
    { /* block id: 104 */
lbl_455:
        for (g_82 = 0; (g_82 <= 4); g_82 += 1)
        { /* block id: 107 */
            int i;
            return g_56[g_82];
        }
    }
    else
    { /* block id: 110 */
        int32_t l_314 = 0x77BE5D1AL;
        int8_t *l_324[8] = {&g_58,&g_58,&g_58,&g_58,&g_58,&g_58,&g_58,&g_58};
        int32_t *l_328 = &g_281;
        int32_t l_329 = 0xE5424190L;
        int32_t *l_330 = &l_314;
        int32_t **l_331[7][7][5] = {{{&l_328,&g_112[1],&l_328,&l_328,&g_112[1]},{&g_112[1],&l_328,&l_328,&g_112[1],&l_328},{&g_112[1],&g_112[1],(void*)0,&g_112[1],&g_112[1]},{&l_328,&g_112[1],&l_328,&l_328,&g_112[1]},{&g_112[1],&l_328,&l_328,&g_112[1],&l_328},{&g_112[1],&g_112[1],(void*)0,&g_112[1],&g_112[1]},{&l_328,&g_112[1],&l_328,&l_328,&g_112[1]}},{{&g_112[1],&l_328,&l_328,&g_112[1],&l_328},{&g_112[1],&g_112[1],(void*)0,&g_112[1],&g_112[1]},{&l_328,&g_112[1],&l_328,&l_328,&g_112[1]},{&g_112[1],&l_328,&l_328,&g_112[1],&l_328},{&g_112[1],&g_112[1],(void*)0,&g_112[1],&g_112[1]},{&l_328,&g_112[1],&l_328,&l_328,&g_112[1]},{&g_112[1],&l_328,&l_328,&g_112[1],&l_328}},{{&g_112[1],&g_112[1],(void*)0,&g_112[1],&g_112[1]},{&l_328,&g_112[1],(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328}},{{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328}},{{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0}},{{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328}},{{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328},{&l_328,(void*)0,(void*)0,&l_328,(void*)0},{&l_328,&l_328,&g_112[1],&l_328,&l_328},{(void*)0,&l_328,(void*)0,(void*)0,&l_328}}};
        int32_t *l_332[9][5][5] = {{{&l_314,(void*)0,&l_329,(void*)0,&l_329},{&g_281,&g_281,&l_327,&l_314,&l_314},{&l_314,&l_329,&l_329,(void*)0,&l_327},{&l_314,&g_281,&g_103,&g_281,(void*)0},{&l_314,&l_329,&g_103,&l_329,&l_327}},{{&l_329,&l_314,&l_314,&l_314,&l_314},{&l_314,&l_327,(void*)0,&g_103,&g_103},{(void*)0,&g_281,&l_314,&l_314,(void*)0},{&l_314,&l_329,(void*)0,&l_314,&l_314},{&g_281,&g_281,&l_314,(void*)0,&l_329}},{{&g_103,&l_314,(void*)0,&g_103,(void*)0},{&l_327,&g_103,&g_103,(void*)0,&g_103},{&l_329,(void*)0,(void*)0,&g_281,&l_327},{&l_327,(void*)0,(void*)0,&l_327,&l_314},{&g_103,&g_281,&g_103,&l_314,&g_281}},{{&g_281,&g_103,(void*)0,&g_281,&l_327},{&l_314,&l_327,&l_314,(void*)0,&l_329},{&g_281,&l_314,(void*)0,&l_329,(void*)0},{&g_103,&l_314,&l_314,&l_329,&g_103},{&g_281,&l_314,(void*)0,&l_327,&g_103}},{{&l_327,&l_314,&l_314,&l_327,&g_103},{&l_329,(void*)0,&g_103,&g_103,&l_329},{(void*)0,(void*)0,&l_327,&g_103,&l_314},{&l_329,&l_314,&l_329,&g_103,&l_314},{&l_327,(void*)0,(void*)0,&l_327,&l_314}},{{&g_281,&l_329,&g_103,&l_327,(void*)0},{&l_329,(void*)0,&l_329,&l_329,&l_327},{(void*)0,&g_281,&l_327,&l_329,&l_329},{&g_103,&l_329,&l_329,(void*)0,(void*)0},{(void*)0,(void*)0,&l_314,&g_281,&g_281}},{{&g_281,&g_103,&l_314,&l_314,&l_327},{&g_103,&l_327,&g_281,&l_327,&g_281},{&l_327,&g_103,&l_314,&g_281,&g_281},{(void*)0,&l_329,&g_103,(void*)0,&l_327},{&g_281,(void*)0,&g_281,&g_103,&g_281}},{{(void*)0,&l_314,&l_327,(void*)0,(void*)0},{&l_327,&g_281,&l_327,&l_314,&l_329},{(void*)0,&l_329,&l_327,&l_314,&l_327},{&l_329,&l_314,&g_103,&g_103,(void*)0},{&l_327,&l_314,&l_314,&l_314,&l_314}},{{&l_327,&g_103,&g_281,&l_329,&l_314},{(void*)0,&g_103,&g_103,&l_327,&l_314},{&l_314,&l_314,&g_281,(void*)0,&g_103},{(void*)0,&l_314,&g_103,&g_103,&l_327},{&g_281,&g_103,&g_281,(void*)0,&l_327}}};
        uint32_t *l_396 = &g_82;
        uint32_t **l_395[4][5] = {{&l_396,&l_396,&l_396,&l_396,&l_396},{&l_396,&l_396,&l_396,&l_396,&l_396},{&l_396,&l_396,&l_396,&l_396,&l_396},{&l_396,&l_396,&l_396,&l_396,&l_396}};
        uint32_t ***l_394 = &l_395[3][0];
        int32_t l_447 = (-8L);
        int32_t l_672 = 0L;
        int32_t l_720 = 1L;
        uint64_t l_737 = 18446744073709551615UL;
        struct S0 * const * const l_749 = (void*)0;
        int i, j, k;
        (*l_330) = (safe_rshift_func_int32_t_s_s((g_313 , (l_329 &= ((*l_328) &= (l_314 > (((safe_mod_func_int16_t_s_s((safe_unary_minus_func_int8_t_s((l_327 &= (safe_mod_func_int64_t_s_s((safe_add_func_uint64_t_u_u((l_310[3][0] || (((((p_36 < l_314) | (safe_mod_func_uint16_t_u_u(((void*)0 == l_324[3]), p_36))) <= ((safe_mul_func_int8_t_s_s((l_310[9][0] && l_314), l_310[9][0])) || g_58)) < 0x2BA3C33D08F65F2ELL) & 0UL)), 3UL)), l_314))))), l_310[9][0])) != p_36) != g_223.f0))))), l_310[9][0]));
lbl_406:
        l_333 = (l_332[7][0][2] = &l_327);
        if (((((*l_333) != (g_313.f3 || g_55)) || (safe_div_func_uint8_t_u_u((safe_unary_minus_func_uint64_t_u(0x8501D7723F37C98ALL)), (safe_mul_func_int16_t_s_s(((l_346 = ((+((safe_rshift_func_int8_t_s_s(p_36, 7)) != (safe_rshift_func_int16_t_s_u((safe_lshift_func_uint16_t_u_s(65535UL, 11)), ((l_333 = &l_327) != (void*)0))))) , ((*l_333) &= 0xABL))) >= 0L), p_36))))) | g_220))
        { /* block id: 120 */
            int32_t l_348 = 0xCFA0DC48L;
            int32_t l_349 = 0x445449C2L;
            for (l_346 = 4; (l_346 >= 0); l_346 -= 1)
            { /* block id: 123 */
                int32_t *l_347[2];
                uint64_t l_350 = 18446744073709551614UL;
                int i;
                for (i = 0; i < 2; i++)
                    l_347[i] = &l_346;
                l_333 = l_347[1];
                (*l_330) = p_36;
                for (g_223.f1 = 0; (g_223.f1 <= 4); g_223.f1 += 1)
                { /* block id: 128 */
                    int64_t l_354 = 0x561D4531A8197230LL;
                    ++l_350;
                    for (g_103 = 0; (g_103 <= 4); g_103 += 1)
                    { /* block id: 132 */
                        int32_t l_353 = 0xDAAF6DE8L;
                        int i, j, k;
                        --l_356;
                    }
                    for (l_329 = 4; (l_329 >= 0); l_329 -= 1)
                    { /* block id: 137 */
                        int i, j, k;
                        if (g_56[l_346])
                            break;
                        l_348 |= l_349;
                    }
                    return p_36;
                }
            }
        }
        else
        { /* block id: 144 */
            uint32_t *l_393 = &g_82;
            uint32_t **l_392[4];
            uint32_t ***l_391 = &l_392[0];
            int32_t l_398[9] = {0x8AF6F204L,0x8AF6F204L,0x8AF6F204L,0x8AF6F204L,0x8AF6F204L,0x8AF6F204L,0x8AF6F204L,0x8AF6F204L,0x8AF6F204L};
            int32_t l_451 = 0x4080C71EL;
            const uint32_t **l_481 = (void*)0;
            const uint32_t ***l_480 = &l_481;
            uint8_t *l_548 = &g_106;
            int32_t *l_560 = &l_447;
            uint8_t l_604 = 0x68L;
            int64_t *l_607[3];
            int64_t **l_606 = &l_607[0];
            union U2 *l_629 = &g_630[2];
            int64_t l_712 = 0L;
            int64_t l_750 = 0x0B0BD74CB85C280FLL;
            union U3 *l_769 = &g_223;
            int i;
            for (i = 0; i < 4; i++)
                l_392[i] = &l_393;
            for (i = 0; i < 3; i++)
                l_607[i] = &l_310[9][0];
            for (g_103 = 0; (g_103 > (-16)); g_103 = safe_sub_func_int8_t_s_s(g_103, 8))
            { /* block id: 147 */
                (*g_361) = &g_100;
            }
            for (g_223.f1 = 0; (g_223.f1 == 2); ++g_223.f1)
            { /* block id: 152 */
                l_333 = &g_103;
            }
            (*l_328) |= (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s((((+(*l_330)) | (safe_rshift_func_int64_t_s_u((((*l_330) > p_36) && ((safe_mul_func_uint8_t_u_u(((g_374 , (&g_137 == ((((*l_333) |= (g_375 , p_36)) <= l_310[1][0]) , l_376))) , 0UL), g_220)) & l_377)), 19))) >= g_82), p_36)), l_310[9][0]));
            if (p_36)
            { /* block id: 157 */
                int32_t ***l_381 = &l_331[6][1][1];
                uint32_t *l_386 = &l_356;
                int16_t *l_387 = &l_377;
                uint32_t **l_390[7];
                uint32_t ***l_389 = &l_390[2];
                uint32_t ****l_388[8] = {&l_389,&l_389,&l_389,&l_389,&l_389,&l_389,&l_389,&l_389};
                int32_t l_400 = 0x47BFFF46L;
                int32_t l_402 = 0x0C246EA5L;
                int i;
                for (i = 0; i < 7; i++)
                    l_390[i] = &l_386;
                for (l_327 = (-27); (l_327 <= (-10)); l_327 = safe_add_func_uint16_t_u_u(l_327, 6))
                { /* block id: 160 */
                    l_346 = (255UL >= ((g_380 , l_381) == g_382[3][2][2]));
                    if (p_36)
                        break;
                }
                if ((((((((g_281 | (safe_sub_func_int8_t_s_s(((void*)0 == &g_49), (p_36 & ((((*l_386) ^= 4294967291UL) , (*l_330)) != ((((*l_387) &= p_36) , (void*)0) != (((l_391 = (void*)0) == l_394) , &l_327))))))) || 8UL) == 0x9E5A16D031D48FA4LL) >= 0x6912CB5BL) == p_36) > g_313.f0) >= (*l_333)))
                { /* block id: 167 */
                    int8_t l_399[3];
                    int32_t l_401 = 7L;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_399[i] = 0xEFL;
                    if ((*l_333))
                    { /* block id: 168 */
                        uint64_t l_403 = 0xB57C875128752698LL;
                        --l_403;
                    }
                    else
                    { /* block id: 170 */
                        (*l_389) = &l_393;
                    }
                    if (g_55)
                        goto lbl_406;
                    for (l_329 = 0; (l_329 != 17); ++l_329)
                    { /* block id: 176 */
                        uint64_t *l_439 = &g_49;
                        uint8_t *l_448 = (void*)0;
                        uint8_t *l_449[5];
                        int32_t l_450 = 0xFB78D9F6L;
                        int i;
                        for (i = 0; i < 5; i++)
                            l_449[i] = &g_106;
                        (*l_330) &= (safe_sub_func_int8_t_s_s((((safe_div_func_int16_t_s_s((&g_137 != &g_137), p_36)) | (safe_sub_func_uint16_t_u_u((safe_rshift_func_int64_t_s_u(p_36, 45)), g_56[3]))) , (safe_lshift_func_int64_t_s_u(0x956BABEFB3E06F4BLL, 55))), (safe_mod_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u((safe_sub_func_int8_t_s_s(((((*l_333) > 0x08DDFDF7DC65B0CBLL) >= (((6L <= 0x024B0C67L) > p_36) < 0x509B8D44L)) , 1L), p_36)), l_399[1])), g_58))));
                        l_451 ^= (((safe_mul_func_uint8_t_u_u((l_450 = (safe_mod_func_uint16_t_u_u(1UL, ((g_429 , (safe_add_func_uint64_t_u_u(2UL, (+((((safe_add_func_uint16_t_u_u(((safe_lshift_func_uint64_t_u_s(((*l_439) = (safe_mul_func_uint32_t_u_u(0x93592F90L, p_36))), 19)) != (*l_333)), (safe_add_func_int8_t_s_s(g_82, (((safe_div_func_uint16_t_u_u((safe_mod_func_int8_t_s_s(((safe_unary_minus_func_int32_t_s((l_355[8] &= l_447))) && (g_429.f1 = g_313.f2)), l_401)), (-1L))) != p_36) | (*l_333)))))) || p_36) , 0x2A722A5BL) , 7UL))))) ^ l_398[1])))), 0x89L)) && 0x9718CF2BL) == p_36);
                    }
                    for (l_327 = 0; (l_327 >= 6); l_327 = safe_add_func_uint16_t_u_u(l_327, 4))
                    { /* block id: 186 */
                        int32_t *l_454 = (void*)0;
                        (*l_328) &= ((void*)0 == l_454);
                    }
                }
                else
                { /* block id: 189 */
                    if (g_223.f1)
                        goto lbl_455;
                }
            }
            else
            { /* block id: 192 */
                int32_t l_476 = (-1L);
                uint16_t **l_496 = &l_376;
                uint64_t *l_583 = &g_55;
                uint32_t l_605 = 5UL;
                int32_t l_635 = (-7L);
                uint32_t l_639 = 0x2A220369L;
                uint16_t l_733[7] = {65528UL,65528UL,65528UL,65528UL,65528UL,65528UL,65528UL};
                int8_t l_766 = (-2L);
                const int32_t *l_775 = &l_355[3];
                int i;
                if (l_398[8])
                { /* block id: 193 */
                    int64_t *l_458 = &l_310[6][0];
                    const uint32_t ****l_482[3];
                    int64_t *l_486 = &g_56[0];
                    int32_t l_487[1];
                    int32_t l_508[10][8];
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_482[i] = (void*)0;
                    for (i = 0; i < 1; i++)
                        l_487[i] = 6L;
                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j < 8; j++)
                            l_508[i][j] = 8L;
                    }
                    if (((safe_mod_func_uint64_t_u_u(p_36, ((*l_458) &= 0x5FBD55933D4CAE00LL))) > ((safe_rshift_func_uint8_t_u_u(((-1L) > (g_313.f2 < ((((safe_sub_func_uint64_t_u_u((((~g_213.f0) >= (4294967287UL | ((l_398[4] = (((safe_add_func_int32_t_s_s((((*l_486) = (((safe_add_func_int32_t_s_s(((*l_328) = (safe_mod_func_int8_t_s_s((safe_rshift_func_int64_t_s_u((safe_sub_func_int8_t_s_s(((safe_unary_minus_func_uint64_t_u(((safe_unary_minus_func_uint64_t_u(l_476)) , (!(safe_mul_func_int32_t_s_s(((g_483 = l_480) != &g_484[4][1]), p_36)))))) == p_36), (-4L))), 1)), l_476))), 8L)) ^ l_398[4]) >= g_313.f3)) || p_36), p_36)) ^ 4294967293UL) > p_36)) | l_476))) , l_487[0]), g_82)) == (*l_333)) && p_36) == 4UL))), (*l_333))) <= 0xC75B3C2FL)))
                    { /* block id: 199 */
                        (*l_333) |= p_36;
                    }
                    else
                    { /* block id: 201 */
                        uint64_t *l_507 = &g_49;
                        int32_t l_509[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_509[i] = 0L;
                        (*l_330) = (safe_rshift_func_int32_t_s_s(((((safe_div_func_int32_t_s_s((safe_mod_func_int8_t_s_s((g_494[4] == l_496), ((-1L) | (safe_sub_func_int64_t_s_s(((!(g_374 , l_500)) > (safe_div_func_int8_t_s_s((g_58 = (*l_333)), (*l_333)))), ((((l_487[0] &= ((safe_lshift_func_int8_t_s_s((((safe_lshift_func_uint64_t_u_u(l_476, ((*l_507) = (2L || l_476)))) , p_36) | l_476), 7)) != p_36)) == l_508[8][3]) , l_476) & l_509[0])))))), p_36)) != 0x8BA2L) || 65535UL) >= g_429.f0), 16));
                        (*l_333) = p_36;
                        (*l_328) &= (g_510 , ((p_36 == ((safe_sub_func_int64_t_s_s((0x6EF7D80EL & (p_36 <= (l_508[0][4] ^ p_36))), (0xB6L || (safe_lshift_func_uint16_t_u_u(((*g_212) , p_36), 9))))) | p_36)) && 18446744073709551609UL));
                        (*l_328) = (safe_add_func_uint16_t_u_u((l_476 = ((*g_483) == (void*)0)), (*l_333)));
                    }
                    for (l_346 = (-20); (l_346 <= (-4)); ++l_346)
                    { /* block id: 213 */
                        uint64_t *l_539 = &g_49;
                        uint8_t *l_546[6] = {&g_106,&g_106,&g_106,&g_106,&g_106,&g_106};
                        uint8_t **l_547[10][8][3] = {{{(void*)0,(void*)0,(void*)0},{&l_546[2],&l_546[5],&l_546[3]},{(void*)0,&l_546[3],(void*)0},{&l_546[3],(void*)0,(void*)0},{&l_546[0],&l_546[0],&l_546[3]},{&l_546[0],(void*)0,(void*)0},{&l_546[0],&l_546[0],(void*)0},{&l_546[5],&l_546[2],&l_546[3]}},{{(void*)0,&l_546[0],(void*)0},{(void*)0,(void*)0,(void*)0},{&l_546[2],&l_546[5],&l_546[3]},{(void*)0,&l_546[3],(void*)0},{&l_546[3],(void*)0,(void*)0},{&l_546[0],&l_546[0],&l_546[3]},{&l_546[0],(void*)0,(void*)0},{&l_546[0],&l_546[0],(void*)0}},{{&l_546[5],&l_546[2],&l_546[3]},{(void*)0,&l_546[0],(void*)0},{(void*)0,(void*)0,(void*)0},{&l_546[2],&l_546[5],&l_546[3]},{(void*)0,&l_546[3],(void*)0},{&l_546[3],(void*)0,(void*)0},{&l_546[0],&l_546[0],&l_546[3]},{&l_546[0],(void*)0,(void*)0}},{{&l_546[0],&l_546[0],(void*)0},{&l_546[5],&l_546[2],&l_546[3]},{(void*)0,&l_546[0],(void*)0},{(void*)0,(void*)0,(void*)0},{&l_546[2],&l_546[5],&l_546[3]},{(void*)0,&l_546[3],(void*)0},{&l_546[3],(void*)0,(void*)0},{&l_546[0],&l_546[0],&l_546[3]}},{{&l_546[0],(void*)0,(void*)0},{&l_546[0],&l_546[0],(void*)0},{&l_546[5],&l_546[2],&l_546[3]},{(void*)0,&l_546[0],(void*)0},{(void*)0,(void*)0,(void*)0},{&l_546[2],&l_546[5],&l_546[3]},{(void*)0,&l_546[3],(void*)0},{&l_546[3],(void*)0,(void*)0}},{{&l_546[0],&l_546[0],&l_546[3]},{&l_546[0],(void*)0,(void*)0},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[3],&l_546[0],&l_546[2]},{&l_546[2],&l_546[0],&l_546[5]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[3],&l_546[2]},{&l_546[0],&l_546[0],&l_546[5]}},{{&l_546[0],&l_546[2],&l_546[5]},{&l_546[0],&l_546[0],&l_546[2]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[3],&l_546[0],&l_546[2]},{&l_546[2],&l_546[0],&l_546[5]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[3],&l_546[2]}},{{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[2],&l_546[5]},{&l_546[0],&l_546[0],&l_546[2]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[3],&l_546[0],&l_546[2]},{&l_546[2],&l_546[0],&l_546[5]},{&l_546[0],&l_546[0],&l_546[5]}},{{&l_546[0],&l_546[3],&l_546[2]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[2],&l_546[5]},{&l_546[0],&l_546[0],&l_546[2]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[3],&l_546[0],&l_546[2]},{&l_546[2],&l_546[0],&l_546[5]}},{{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[3],&l_546[2]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[2],&l_546[5]},{&l_546[0],&l_546[0],&l_546[2]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[0],&l_546[0],&l_546[5]},{&l_546[3],&l_546[0],&l_546[2]}}};
                        uint16_t *l_556 = &g_137;
                        uint16_t *l_557 = (void*)0;
                        uint16_t *l_558 = &g_559;
                        int i, j, k;
                        l_398[0] |= ((safe_mod_func_uint8_t_u_u((safe_mul_func_int64_t_s_s(((safe_add_func_int32_t_s_s(((*l_328) = ((g_313 , (*l_333)) ^ (((safe_mul_func_uint8_t_u_u(((safe_sub_func_int32_t_s_s((safe_div_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((safe_mul_func_int64_t_s_s(((((safe_lshift_func_uint16_t_u_u(((*l_558) ^= ((((*l_539)--) && ((((safe_rshift_func_uint8_t_u_s(((l_548 = l_546[0]) != l_549), g_103)) <= (&g_112[5] != &g_112[2])) != (safe_lshift_func_int32_t_s_u(((((safe_mul_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(g_281, ((*l_556) = l_451))), g_223.f1)) & (-5L)) == (*l_333)) == g_49), p_36))) ^ 0xF233DC06L)) ^ g_82)), 10)) != p_36) & l_476) > l_476), 1L)), 0x3C7140B2L)), g_313.f2)), (*l_333))) & p_36), 4L)) , 9UL) || 18446744073709551607UL))), p_36)) >= (-1L)), 0x12DFE6042345C7C0LL)), p_36)) && p_36);
                    }
                }
                else
                { /* block id: 221 */
                    l_560 = &l_355[1];
                }
                if ((p_36 , ((((0x7ED8L || (p_36 & (((p_36 || ((*l_583) = (safe_lshift_func_int8_t_s_s(((g_559--) & (safe_rshift_func_int8_t_s_u((((g_82 = (((safe_lshift_func_int16_t_s_u((((safe_add_func_uint16_t_u_u((((safe_div_func_int64_t_s_s((*l_333), ((g_573 != (((safe_rshift_func_int32_t_s_s(8L, 21)) , (safe_mod_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u(((safe_rshift_func_uint32_t_u_s(p_36, ((*l_330) ^= p_36))) & 0x8D020466BECA7DCALL), (*l_560))) || (*l_560)), p_36))) , &l_549)) & (*l_560)))) ^ p_36) , 65535UL), (*l_333))) >= 0x2D90L) | p_36), 10)) == p_36) || g_313.f1)) <= (*l_333)) , (*l_560)), p_36))), g_137)))) , (*l_560)) > 0xB5F1L))) <= 5L) && 1L) , p_36)))
                { /* block id: 228 */
                    uint32_t *****l_587[2];
                    uint64_t l_631[8] = {0x194D208ACACA9C1DLL,0x194D208ACACA9C1DLL,0x25938FD534636745LL,0x194D208ACACA9C1DLL,0x194D208ACACA9C1DLL,0x25938FD534636745LL,0x194D208ACACA9C1DLL,0x194D208ACACA9C1DLL};
                    int i;
                    for (i = 0; i < 2; i++)
                        l_587[i] = &g_586[4];
                    if ((((safe_add_func_int64_t_s_s(((((((g_586[3] = g_586[1]) != g_588) > (l_476 = (p_36 | (safe_add_func_uint8_t_u_u((*l_333), ((((safe_sub_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((safe_lshift_func_uint32_t_u_s((safe_rshift_func_int32_t_s_u((safe_mul_func_int32_t_s_s(1L, (l_604 ^ (((0x01AE7FF2L || (l_605 > ((g_313.f2 & 0x5623B028E6E5782ELL) , (*l_560)))) == g_559) != 1L)))), (*l_560))), 21)), 0xDBE19D02020B95B9LL)), 1UL)) | l_476) , 4UL) && 8UL)))))) & p_36) >= 0x407A61CFL) >= 0x7BF0L), 0UL)) | (*l_333)) | p_36))
                    { /* block id: 231 */
                        (*l_328) &= 0x03177594L;
                        g_608 = l_606;
                        return p_36;
                    }
                    else
                    { /* block id: 235 */
                        uint32_t l_610 = 4294967295UL;
                        const uint32_t l_627 = 4294967295UL;
                        uint16_t *l_628 = &g_137;
                        l_610--;
                        (*l_560) = (safe_unary_minus_func_uint32_t_u((safe_mod_func_uint64_t_u_u((p_36 <= ((l_476 = ((*l_628) = ((safe_unary_minus_func_uint8_t_u((safe_mul_func_uint8_t_u_u(((*l_333) = (g_619 , (p_36 >= (p_36 == (g_620 , 0xD9FAL))))), ((safe_lshift_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(p_36, ((safe_sub_func_uint64_t_u_u(p_36, (0xC9L != p_36))) & g_137))), 12)) || l_610))))) & l_627))) & g_82)), p_36))));
                        l_629 = &g_429;
                        l_631[4]++;
                    }
                    g_634 = &g_510;
                }
                else
                { /* block id: 245 */
                    int16_t l_636[10] = {0x65D6L,0xD0FAL,5L,5L,0xD0FAL,0x65D6L,0xD0FAL,5L,5L,0xD0FAL};
                    int32_t l_637 = (-5L);
                    int32_t l_638 = (-2L);
                    int i;
                    --l_639;
                }
                if (l_642[2])
                { /* block id: 248 */
                    uint16_t l_647 = 0xFB90L;
                    int32_t l_653 = 0xEC1540AEL;
                    uint32_t ** const *l_671 = (void*)0;
                    uint32_t ** const **l_670 = &l_671;
                    int32_t l_673 = 0xF7AD8C42L;
                    int8_t l_692[4] = {(-3L),(-3L),(-3L),(-3L)};
                    int i;
                    for (l_605 = 0; (l_605 > 23); l_605 = safe_add_func_int8_t_s_s(l_605, 9))
                    { /* block id: 251 */
                        const uint8_t *l_649 = &g_106;
                        int32_t l_650 = (-1L);
                        (*l_560) = (safe_sub_func_int32_t_s_s(0x0A22C4DCL, (l_647 <= (g_648 , ((l_649 == (void*)0) ^ l_650)))));
                        return g_651;
                    }
                    for (g_58 = 0; (g_58 <= 2); g_58 += 1)
                    { /* block id: 257 */
                        int i;
                        return l_642[g_58];
                    }
                    if (((l_673 &= ((**l_606) = (((l_653 |= ((*l_330) = ((~p_36) <= l_647))) | p_36) , ((**g_608) = (safe_mod_func_int32_t_s_s(((*l_333) ^= l_653), (safe_add_func_uint32_t_u_u((p_36 , (***g_361)), ((safe_div_func_int32_t_s_s((safe_div_func_int32_t_s_s(p_36, (safe_div_func_int32_t_s_s(((((safe_div_func_int8_t_s_s((safe_mul_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u(((g_137 &= (p_36 && (((void*)0 != l_670) & 0x86E9L))) & 1L), p_36)), 0xD18D440549101421LL)), g_313.f3)) ^ l_672) || p_36) || 0UL), p_36)))), 1UL)) | p_36))))))))) != p_36))
                    { /* block id: 267 */
                        uint16_t *l_697 = &g_137;
                        int32_t l_698 = 4L;
                        (*g_383) = &l_451;
                        (*l_328) |= (p_36 ^ (l_676[4][1] >= (safe_mul_func_uint16_t_u_u((~((safe_mul_func_uint32_t_u_u(((safe_sub_func_int32_t_s_s((((safe_mul_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(((*l_583) ^= ((safe_add_func_int32_t_s_s((((void*)0 == &l_481) , (safe_lshift_func_int32_t_s_s((g_619 , (((l_692[3] && (((*l_697) &= (g_374 , (safe_mod_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u((*l_333), (*l_560))), (-1L))))) <= p_36)) , 65526UL) == 0xE81EL)), 7))), 0x5672462EL)) | (*l_560))), 0xDAE0E481B70C0268LL)), g_82)) && p_36) > g_429.f0), p_36)) <= p_36), p_36)) || 0x63L)), (-1L)))));
                        (*g_383) = ((l_698 = 0x4C45BEEEL) , &l_673);
                    }
                    else
                    { /* block id: 274 */
                        int64_t l_702 = (-1L);
                        int32_t l_703 = (-1L);
                        (*l_333) = (((-3L) >= (l_703 = ((g_619 , l_476) , (safe_mul_func_int64_t_s_s((-2L), (g_701 , l_702)))))) , (((**g_608) && p_36) , l_702));
                        (*l_330) = (l_398[4] ^= (*l_560));
                        return l_605;
                    }
                }
                else
                { /* block id: 281 */
                    int8_t l_706 = 0xCCL;
                    for (l_500 = 2; (l_500 <= 8); l_500 += 1)
                    { /* block id: 284 */
                        l_560 = (void*)0;
                    }
                    for (l_605 = 22; (l_605 < 16); l_605--)
                    { /* block id: 289 */
                        uint16_t l_707 = 0x4FD4L;
                        (*l_333) ^= ((*l_330) = (p_36 < l_476));
                        (*l_330) |= ((*l_328) = (l_706 > (l_707 >= ((safe_div_func_int64_t_s_s((safe_rshift_func_int32_t_s_u(l_712, (*l_328))), ((safe_lshift_func_uint8_t_u_s(((*l_548) = ((((safe_sub_func_int64_t_s_s(((l_717 = (void*)0) == (void*)0), ((safe_rshift_func_uint64_t_u_u((((l_720 == l_707) <= 0x908E6E4A5829A2C2LL) == p_36), p_36)) == p_36))) && 4294967286UL) & p_36) > 0x3010DD1FL)), 0)) | 4294967293UL))) > 0x0D70L))));
                        (*l_328) = ((*g_609) > (safe_lshift_func_int64_t_s_u((**g_608), (~((safe_add_func_int32_t_s_s(p_36, 0xE3E702DCL)) > 4UL)))));
                    }
                    (*g_726) = &g_313;
                }
                for (g_375.f1 = 0; (g_375.f1 <= 3); g_375.f1 += 1)
                { /* block id: 302 */
                    int8_t l_751[3];
                    int32_t l_752[6];
                    uint64_t l_757 = 0xD5F9E93F1F0EF24BLL;
                    const int32_t **l_765 = (void*)0;
                    const int32_t ***l_764 = &l_765;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_751[i] = 0xF5L;
                    for (i = 0; i < 6; i++)
                        l_752[i] = (-1L);
                    for (g_103 = 3; (g_103 >= 0); g_103 -= 1)
                    { /* block id: 305 */
                        int32_t l_753 = 0x663A5436L;
                        int32_t l_754 = 0x9E1EBCE4L;
                        int32_t l_755 = 0xE4083E20L;
                        int32_t l_756 = 0xA6F8C414L;
                        union U3 **l_770 = &g_634;
                        int i, j;
                        l_398[(g_375.f1 + 4)] ^= (safe_lshift_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_s((~(l_733[3] = p_36)), 2)) < (-7L)), (!g_101)));
                        (*l_328) &= (((safe_unary_minus_func_uint16_t_u(((safe_unary_minus_func_uint32_t_u((((*l_333) & l_737) , p_36))) == (((*l_330) < (safe_sub_func_int32_t_s_s((((g_740 , ((l_398[(g_375.f1 + 4)] < ((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint64_t_u_u(p_36, (safe_sub_func_int8_t_s_s(((g_380 , &g_727[8][0][1]) != l_749), g_559)))), 12)) <= 0x10352F98L)) | g_137)) ^ p_36) , (*l_330)), 0x316EE01BL))) || p_36)))) && l_750) || l_733[1]);
                        l_757--;
                        (*l_328) = ((safe_div_func_uint32_t_u_u(l_755, (safe_add_func_int8_t_s_s((l_764 == (void*)0), (((l_766 <= (safe_add_func_uint16_t_u_u(((p_36 < p_36) <= ((p_36 && ((((((((*l_770) = l_769) != ((safe_mod_func_uint8_t_u_u((*l_330), l_754)) , (void*)0)) & 8L) || p_36) , p_36) >= p_36) && l_755)) | p_36)), p_36))) <= 1UL) | p_36))))) <= (*g_100));
                    }
                    for (l_447 = 0; (l_447 <= 3); l_447 += 1)
                    { /* block id: 315 */
                        if (p_36)
                            break;
                        l_775 = (l_773 = (void*)0);
                        return p_36;
                    }
                }
            }
        }
    }
    l_355[8] &= (((g_776 , (((safe_lshift_func_int16_t_s_s(((*l_797) = (((*l_333) != ((safe_sub_func_int16_t_s_s(((++(*l_781)) && (((p_36 & ((safe_mul_func_int16_t_s_s((p_36 , ((((*l_796) = (((safe_sub_func_int32_t_s_s(((*l_795) |= ((l_788 == l_788) >= (safe_mod_func_int8_t_s_s((((*l_794) = (g_55 |= (((void*)0 != l_792) || (!(*l_773))))) >= p_36), g_213.f0)))), (*l_773))) <= 0x66L) , (*l_795))) >= 0x3FL) & (*l_773))), p_36)) , p_36)) <= g_58) , (*l_795))), p_36)) >= 0x57DFA250E069E50FLL)) >= p_36)), l_798)) , g_799) , 0x60CEL)) >= l_800) != (*l_333));
    for (g_429.f1 = 0; (g_429.f1 > 23); g_429.f1 = safe_add_func_uint16_t_u_u(g_429.f1, 2))
    { /* block id: 334 */
        const int32_t *l_803 = (void*)0;
        const int32_t **l_807 = (void*)0;
        int32_t l_829 = 0x2B650D2EL;
        int16_t l_872 = 0x7B29L;
        uint8_t **l_874 = &l_549;
        const uint16_t l_880 = 65535UL;
        uint64_t l_888 = 0xF5E72ACA0EC2AE6CLL;
        int32_t l_897 = 0xA17F318FL;
        int32_t l_898[6][3] = {{1L,0x572423B7L,0x572423B7L},{(-1L),7L,7L},{1L,0x572423B7L,0x572423B7L},{(-1L),7L,7L},{1L,0x572423B7L,0x572423B7L},{(-1L),7L,7L}};
        int16_t l_904[1][7];
        uint16_t ***l_923 = (void*)0;
        uint16_t ****l_922 = &l_923;
        union U3 *l_925 = (void*)0;
        uint32_t l_948[7][7] = {{0x7AFDB0A6L,6UL,0xCD5C1501L,0x6EAB15AEL,0x1071ED7FL,4294967291UL,5UL},{0x1071ED7FL,0x6EAB15AEL,0xCD5C1501L,6UL,0x7AFDB0A6L,4294967291UL,4294967291UL},{0x7AFDB0A6L,0x6EAB15AEL,4UL,0x6EAB15AEL,0x7AFDB0A6L,0x12788118L,5UL},{0x7AFDB0A6L,6UL,0xCD5C1501L,0x6EAB15AEL,0x1071ED7FL,4294967291UL,5UL},{0x1071ED7FL,0x6EAB15AEL,0xCD5C1501L,6UL,0x7AFDB0A6L,4294967291UL,4294967291UL},{0x7AFDB0A6L,0x6EAB15AEL,4UL,0x6EAB15AEL,4294967291UL,0UL,0xCD5C1501L},{4294967291UL,1UL,4294967295UL,0xD3D71D33L,0x12788118L,4UL,0xCD5C1501L}};
        uint8_t l_988 = 0x75L;
        uint64_t l_997 = 1UL;
        int64_t l_1049 = 6L;
        const uint64_t **l_1099 = (void*)0;
        int32_t *l_1114 = &l_346;
        struct S0 **l_1140 = (void*)0;
        struct S0 ***l_1139[9][9][3] = {{{(void*)0,&l_1140,&l_1140},{&l_1140,(void*)0,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,(void*)0},{&l_1140,&l_1140,&l_1140},{&l_1140,(void*)0,(void*)0},{&l_1140,&l_1140,&l_1140}},{{(void*)0,&l_1140,(void*)0},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{(void*)0,(void*)0,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,(void*)0}},{{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,(void*)0,(void*)0},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,(void*)0},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140}},{{(void*)0,&l_1140,&l_1140},{&l_1140,&l_1140,(void*)0},{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,(void*)0,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140}},{{&l_1140,&l_1140,(void*)0},{&l_1140,&l_1140,&l_1140},{&l_1140,(void*)0,(void*)0},{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,(void*)0},{&l_1140,&l_1140,&l_1140},{&l_1140,(void*)0,&l_1140},{(void*)0,(void*)0,&l_1140},{&l_1140,&l_1140,&l_1140}},{{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,(void*)0,&l_1140},{&l_1140,(void*)0,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140}},{{&l_1140,&l_1140,(void*)0},{(void*)0,(void*)0,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140}},{{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140},{&l_1140,&l_1140,(void*)0},{(void*)0,&l_1140,&l_1140},{&l_1140,(void*)0,&l_1140},{&l_1140,&l_1140,(void*)0},{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140}},{{&l_1140,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{&l_1140,(void*)0,(void*)0},{(void*)0,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140},{(void*)0,&l_1140,&l_1140},{&l_1140,&l_1140,&l_1140}}};
        uint16_t **l_1145[6] = {&g_887,&g_887,&g_887,&g_887,&g_887,&g_887};
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 7; j++)
                l_904[i][j] = 0x0956L;
        }
        if (p_36)
            break;
        l_773 = l_803;
        for (g_281 = (-10); (g_281 != (-1)); g_281 = safe_add_func_uint32_t_u_u(g_281, 9))
        { /* block id: 339 */
            int64_t l_822 = 7L;
            int32_t *l_831 = &l_397;
            int32_t l_899 = 0L;
            int32_t l_900 = 0xDA654D88L;
            int32_t l_901 = 0x39893A89L;
            int32_t l_902 = 4L;
            int32_t l_903[7] = {0x3219AF1BL,9L,0x3219AF1BL,0x3219AF1BL,9L,0x3219AF1BL,0x3219AF1BL};
            int32_t l_905[10][3][8] = {{{0xEF536183L,1L,0xB87DEA5EL,2L,0x9A64AB41L,0xC4583486L,0x3967F055L,0x3967F055L},{0x3967F055L,0x6FE200B3L,0xB39AF4A5L,0xB39AF4A5L,0x6FE200B3L,0x3967F055L,0x9A64AB41L,0L},{0x447C894EL,0x1CF17BFFL,(-9L),0L,0L,7L,0x17124053L,0xB3E2F848L}},{{0x09C0237FL,0x8EA88FF9L,7L,0L,(-7L),0xE2D3CA48L,0xB41AE400L,0L},{0L,(-7L),4L,0xB39AF4A5L,0xB87DEA5EL,0x0756A138L,0xE2D3CA48L,0x3967F055L},{(-9L),0xEDB0697CL,0x3A912961L,2L,0xC99F0D40L,0x824D3F58L,0x8EA88FF9L,0L}},{{0x3A912961L,(-1L),0x66400F95L,0x70C9F9E4L,0x1CF17BFFL,0x70C0BE16L,0x9A64AB41L,0x66400F95L},{0x3AAA0B12L,1L,0x824D3F58L,0xB87DEA5EL,0x70C0BE16L,2L,0x3710346FL,2L},{0x0CEDA1FEL,0x8EA88FF9L,5L,0x8EA88FF9L,0x0CEDA1FEL,9L,4L,0x4667EFD5L}},{{0x5C48A514L,0x0756A138L,0x3967F055L,5L,0xB87DEA5EL,(-6L),0x0756A138L,0x8EA88FF9L},{0x824D3F58L,0L,0x3967F055L,0x4BEC1533L,1L,0xC4583486L,4L,0L},{0xB87DEA5EL,(-1L),5L,0x4667EFD5L,0x9A64AB41L,0x3A912961L,0x3710346FL,1L}},{{0x447C894EL,0x6FE200B3L,0x824D3F58L,0xEDB0697CL,0L,0x447C894EL,0x9A64AB41L,0x3AAA0B12L},{(-6L),0x70C0BE16L,0x66400F95L,0L,0x10AFD51AL,9L,0x8EA88FF9L,0xE2C9FA5CL},{0x09C0237FL,0x5C48A514L,0x447C894EL,(-1L),2L,0x8EA88FF9L,0x8EA88FF9L,2L}},{{0L,2L,2L,0L,9L,7L,(-9L),0xEF536183L},{0xB10539F7L,(-7L),0x3710346FL,0x17124053L,(-6L),0x3AAA0B12L,(-1L),0x1CF17BFFL},{1L,(-7L),8L,0xB3E2F848L,0xC4583486L,7L,0x0756A138L,8L}},{{0xB41AE400L,2L,1L,7L,0x3A912961L,0x8EA88FF9L,0xEF536183L,0x17124053L},{0x3967F055L,1L,7L,(-1L),0x447C894EL,0xEDB0697CL,0xB41AE400L,(-9L)},{8L,0xC4583486L,0xEF536183L,0x2F8FD743L,9L,5L,0xC4583486L,0xB10539F7L}},{{0x3AAA0B12L,0L,0L,0x1CF17BFFL,0xE2D3CA48L,0x447C894EL,0xE2D3CA48L,0x1CF17BFFL},{0x2F8FD743L,0x10AFD51AL,0x2F8FD743L,(-9L),0xB3E2F848L,1L,0x09C0237FL,5L},{0xB87DEA5EL,0x824D3F58L,1L,0x3AAA0B12L,0xEDB0697CL,0xB87DEA5EL,0xB3E2F848L,(-1L)}},{{0xB87DEA5EL,0x3A912961L,0xB10539F7L,(-1L),0xB3E2F848L,0xEDB0697CL,1L,0xC4583486L},{0x2F8FD743L,0xB10539F7L,0x447C894EL,0xB39AF4A5L,0xE2D3CA48L,0x66400F95L,(-9L),2L},{0x3AAA0B12L,0xE2D3CA48L,(-1L),1L,9L,0xC4583486L,0x5C48A514L,0L}},{{8L,(-7L),1L,(-9L),0x447C894EL,0L,(-1L),0xE2C9FA5CL},{0x3967F055L,0x3AAA0B12L,(-1L),0xB3E2F848L,0x3A912961L,0x3A912961L,0xB3E2F848L,(-1L)},{0xB41AE400L,0xB41AE400L,0x3AAA0B12L,0x6FE200B3L,0xC4583486L,0x8EA88FF9L,0xB87DEA5EL,(-9L)}}};
            int i, j, k;
            for (g_137 = 0; (g_137 != 5); ++g_137)
            { /* block id: 342 */
                for (l_346 = (-22); (l_346 == (-19)); l_346 = safe_add_func_uint16_t_u_u(l_346, 3))
                { /* block id: 345 */
                    uint32_t l_827 = 0x7D646BF4L;
                    int32_t l_828 = (-3L);
                    if (p_36)
                        break;
                    for (g_103 = (-22); (g_103 <= (-30)); g_103 = safe_sub_func_uint32_t_u_u(g_103, 2))
                    { /* block id: 349 */
                        uint32_t *l_816 = &g_82;
                        int32_t l_830 = 0xA734B4D4L;
                        l_829 |= (((*l_816)++) & (p_36 >= (p_36 || (l_828 |= (((safe_mod_func_uint16_t_u_u(((!l_822) | p_36), (p_36 & g_49))) , ((252UL >= ((safe_div_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(p_36, l_827)), (*g_609))) || l_822)) != p_36)) > l_827)))));
                        (*l_795) = (-1L);
                        return l_830;
                    }
                }
                (*g_383) = l_831;
            }
            if (p_36)
                continue;
            if (((-2L) == (g_619 , ((((safe_lshift_func_uint32_t_u_u((safe_sub_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((safe_lshift_func_int64_t_s_u((*l_831), ((*l_794) = l_840))), ((safe_div_func_int32_t_s_s((((*l_797) |= (-1L)) ^ p_36), (safe_div_func_int8_t_s_s(0xC9L, ((safe_rshift_func_int32_t_s_s((g_789.f0 , p_36), (*g_805))) & 0x8FL))))) ^ 0xC787L))), 8L)), (*l_795))) ^ 0x59L) , 0x891B487DL) >= 1UL))))
            { /* block id: 362 */
                uint8_t l_875 = 0x44L;
                for (p_36 = 6; (p_36 >= 1); p_36 -= 1)
                { /* block id: 365 */
                    const int32_t l_851 = 1L;
                    uint16_t **l_885 = &l_376;
                    uint16_t ***l_890 = &l_885;
                    uint16_t ****l_889 = &l_890;
                    for (g_140.f1 = 0; (g_140.f1 <= 0); g_140.f1 += 1)
                    { /* block id: 368 */
                        const uint16_t l_873 = 0x8D82L;
                        int i, j;
                        (*l_831) = (18446744073709551615UL & ((*g_609) = ((safe_div_func_int16_t_s_s(l_642[(g_140.f1 + 1)], ((l_829 = (l_310[(p_36 + 3)][g_140.f1] ^ l_851)) | (!(g_853 , (safe_mod_func_int32_t_s_s(((safe_sub_func_uint64_t_u_u((safe_div_func_uint8_t_u_u(((safe_add_func_uint64_t_u_u((safe_mul_func_int32_t_s_s((safe_mod_func_uint8_t_u_u(((g_866 , p_36) | ((((((safe_rshift_func_uint16_t_u_u(((+0x59L) , (safe_sub_func_uint32_t_u_u(((((**g_608) , (**g_608)) != l_872) < 0x9B95989C5BC2C316LL), (*l_831)))), 0)) >= l_873) , l_874) == &g_574) , p_36) > g_651)), l_875)), p_36)), 4UL)) == l_873), 2L)), p_36)) , (-9L)), l_310[(p_36 + 3)][g_140.f1]))))))) > p_36)));
                        return p_36;
                    }
                    (*l_795) = ((*l_831) = ((safe_div_func_int32_t_s_s((safe_add_func_int64_t_s_s((**g_608), l_875)), p_36)) , (p_36 != (l_880 >= ((0x0475L >= (safe_mod_func_uint64_t_u_u((p_36 >= ((safe_rshift_func_int64_t_s_s(5L, ((g_886 = l_885) == &l_376))) < l_888)), (*g_609)))) == p_36)))));
                    (*l_889) = &g_886;
                }
                return p_36;
            }
            else
            { /* block id: 380 */
                int32_t *l_895 = (void*)0;
                int32_t *l_896[5][7][7] = {{{&l_397,(void*)0,(void*)0,&l_355[1],&g_281,&l_829,&l_829},{(void*)0,&l_397,&l_355[2],&l_355[2],&l_397,(void*)0,(void*)0},{&l_397,(void*)0,(void*)0,&l_355[1],&g_281,&l_829,&l_829},{(void*)0,&l_397,&l_355[2],&l_355[2],&l_397,(void*)0,(void*)0},{&l_397,(void*)0,(void*)0,&l_355[1],&g_281,&l_829,&l_829},{(void*)0,&l_397,&l_355[2],&l_355[2],&l_397,(void*)0,(void*)0},{&l_397,(void*)0,(void*)0,&l_355[1],&g_281,&l_829,&l_829}},{{(void*)0,&l_397,&l_355[2],&l_355[2],&l_397,(void*)0,(void*)0},{&l_397,(void*)0,(void*)0,&l_355[1],&g_281,&l_829,&l_829},{(void*)0,&l_397,(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829}},{{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]}},{{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829}},{{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]},{&g_281,&l_355[2],(void*)0,(void*)0,&l_355[2],&g_281,&l_829},{(void*)0,&l_355[1],&l_829,&l_397,(void*)0,(void*)0,&l_355[3]}}};
                int i, j, k;
                for (l_377 = (-30); (l_377 > 12); l_377 = safe_add_func_int64_t_s_s(l_377, 8))
                { /* block id: 383 */
                    for (g_220 = 9; (g_220 != (-23)); --g_220)
                    { /* block id: 386 */
                        return p_36;
                    }
                }
                ++l_906;
                for (l_900 = 0; (l_900 >= (-5)); --l_900)
                { /* block id: 393 */
                    for (l_872 = (-9); (l_872 == (-22)); l_872 = safe_sub_func_int32_t_s_s(l_872, 1))
                    { /* block id: 396 */
                        return p_36;
                    }
                }
            }
        }
        for (g_559 = 0; (g_559 == 7); g_559 = safe_add_func_int8_t_s_s(g_559, 1))
        { /* block id: 404 */
            int8_t l_928 = 0L;
            int32_t l_971[1];
            int32_t *l_983 = &l_355[8];
            union U3 *l_1044 = &g_510;
            const uint8_t **l_1046 = (void*)0;
            int32_t l_1131 = (-7L);
            int64_t ***l_1226 = &g_608;
            int i;
            for (i = 0; i < 1; i++)
                l_971[i] = 0L;
        }
    }
    for (g_651 = 0; (g_651 < (-30)); --g_651)
    { /* block id: 566 */
        int32_t l_1249 = 0x83D3B5DBL;
        int32_t l_1251[6][2][6] = {{{0L,0L,0xAC3E4B77L,0L,0L,0xAC3E4B77L},{0L,0L,0xAC3E4B77L,0xAC3E4B77L,0L,0x37DBC85EL}},{{0x37DBC85EL,0xAC3E4B77L,0x029A87C5L,0x37DBC85EL,0L,0x029A87C5L},{0x37DBC85EL,0L,0x029A87C5L,0x029A87C5L,0L,0x37DBC85EL}},{{0x37DBC85EL,0xAC3E4B77L,0x029A87C5L,0x37DBC85EL,0L,0x029A87C5L},{0x37DBC85EL,0L,0x029A87C5L,0x029A87C5L,0L,0x37DBC85EL}},{{0x37DBC85EL,0xAC3E4B77L,0x029A87C5L,0x37DBC85EL,0L,0x029A87C5L},{0x37DBC85EL,0L,0x029A87C5L,0x029A87C5L,0L,0x37DBC85EL}},{{0x37DBC85EL,0xAC3E4B77L,0x029A87C5L,0x37DBC85EL,0L,0x029A87C5L},{0x37DBC85EL,0L,0x029A87C5L,0x029A87C5L,0L,0x37DBC85EL}},{{0x37DBC85EL,0xAC3E4B77L,0x029A87C5L,0x37DBC85EL,0L,0x029A87C5L},{0x37DBC85EL,0L,0x029A87C5L,0x029A87C5L,0L,0x37DBC85EL}}};
        union U4 *l_1262 = &g_957;
        uint8_t *l_1321 = &l_676[4][2];
        const int16_t l_1328 = 1L;
        int32_t l_1384[6];
        const uint32_t l_1462 = 4UL;
        uint16_t *l_1564[6][1];
        uint64_t *l_1571 = (void*)0;
        int32_t *l_1577 = &l_500;
        int32_t *l_1578 = &l_1251[5][1][4];
        int32_t *l_1579[1][7][3] = {{{&l_1384[4],&l_1384[4],&l_1384[4]},{&l_1384[4],&l_1384[4],&l_1384[4]},{&l_1384[4],&l_346,&g_281},{&l_1384[4],&l_346,&l_1384[4]},{&l_1384[4],&l_1384[4],&g_281},{&l_1384[4],&l_1384[4],&l_1384[4]},{&l_1384[4],&l_1384[4],&l_1384[4]}}};
        int64_t ***l_1590 = &g_608;
        union U3 **l_1597 = &g_1022;
        int32_t l_1622 = 6L;
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_1384[i] = (-2L);
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 1; j++)
                l_1564[i][j] = &g_137;
        }
        if ((*g_805))
        { /* block id: 567 */
            uint32_t *l_1250[6] = {(void*)0,&l_800,(void*)0,(void*)0,&l_800,(void*)0};
            int32_t l_1252 = 0L;
            int32_t l_1254 = 0x79AD0731L;
            uint8_t l_1260 = 0xF6L;
            const struct S0 **l_1268 = &g_727[5][3][0];
            const struct S0 ***l_1267 = &l_1268;
            uint16_t l_1269 = 0UL;
            int32_t l_1271 = 0L;
            int32_t l_1272 = (-1L);
            int32_t l_1273[9];
            uint8_t l_1297 = 0x41L;
            int32_t l_1298 = 0L;
            uint16_t l_1383 = 65535UL;
            int64_t l_1421[1];
            const uint8_t *l_1445 = &l_1260;
            const uint8_t **l_1444 = &l_1445;
            const uint8_t ** const *l_1443[5];
            const uint8_t ** const **l_1442[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            uint16_t * const *l_1540 = &g_887;
            uint16_t * const **l_1539 = &l_1540;
            uint32_t l_1567 = 2UL;
            int i;
            for (i = 0; i < 9; i++)
                l_1273[i] = 2L;
            for (i = 0; i < 1; i++)
                l_1421[i] = 0xD768E5DBFF55C531LL;
            for (i = 0; i < 5; i++)
                l_1443[i] = &l_1444;
            if (((((g_1248 , ((l_1269 |= ((p_36 >= (--l_1255)) < (((safe_lshift_func_uint32_t_u_s(((l_1260 != ((g_1261[5][0] , p_36) , ((void*)0 != l_1262))) >= (safe_mod_func_int16_t_s_s((safe_mod_func_uint64_t_u_u(((void*)0 == l_1267), (*g_1101))), 0x6CB7L))), 15)) < p_36) <= l_1252))) , p_36)) >= l_1249) >= l_1254) <= 0xE46A057BF8FB17ABLL))
            { /* block id: 570 */
                int32_t *l_1270[3];
                int16_t *l_1281 = (void*)0;
                uint8_t ***l_1296 = &g_932;
                uint16_t * const *l_1336 = &g_887;
                uint16_t * const * const *l_1335 = &l_1336;
                uint16_t * const * const **l_1334 = &l_1335;
                uint16_t l_1422[1];
                union U4 *l_1455 = &g_1456;
                union U4 *l_1460 = &g_1461;
                int i;
                for (i = 0; i < 3; i++)
                    l_1270[i] = &l_346;
                for (i = 0; i < 1; i++)
                    l_1422[i] = 0x7942L;
                --l_1274;
                l_1251[0][0][0] = ((((((*l_794) = (safe_add_func_uint32_t_u_u(l_1260, ((*l_333) = (((**g_932) &= p_36) && (((safe_lshift_func_int64_t_s_s(((l_1281 == &g_1253[2][4][6]) != (((((l_1282 , ((***g_1053) |= (safe_div_func_int64_t_s_s((((safe_lshift_func_uint16_t_u_s((safe_div_func_int16_t_s_s((safe_div_func_uint8_t_u_u(p_36, (safe_mul_func_uint64_t_u_u(9UL, (((((safe_add_func_uint32_t_u_u((~65535UL), (p_36 & l_1249))) || l_1251[5][1][4]) , l_1296) != (*g_1052)) && p_36))))), 0xCA68L)), l_1249)) < 18446744073709551615UL) && g_1217[6][0].f0), 18446744073709551611UL)))) >= 0L) <= p_36) , l_1297) & l_1251[5][1][4])), (**g_608))) == 4UL) == p_36)))))) <= l_1269) , (*l_795)) >= 0x84CDB8052B4FC9B7LL) > l_1298);
                if (((safe_mul_func_int64_t_s_s((((safe_rshift_func_uint16_t_u_s(((safe_rshift_func_uint64_t_u_s(((void*)0 != g_1305[2]), 36)) != (l_1252 >= (safe_rshift_func_uint32_t_u_s((safe_sub_func_int16_t_s_s(((((safe_unary_minus_func_int8_t_s((safe_add_func_uint32_t_u_u((safe_mod_func_int16_t_s_s((l_1254 ^= (((**g_886) = ((safe_rshift_func_int32_t_s_u((safe_lshift_func_int16_t_s_s(p_36, 5)), ((safe_rshift_func_int16_t_s_u((((**l_1296) = l_1321) == &l_1297), 13)) , 4294967289UL))) < (safe_mod_func_int64_t_s_s(l_1273[2], (safe_mul_func_int32_t_s_s(((((g_1048 = ((l_1272 = ((**g_608) = (((0xC2E2D927L == l_1251[5][1][4]) <= g_1326) && 0x3990L))) > p_36)) && (-3L)) > 0UL) && (-9L)), p_36)))))) , p_36)), g_1327)), p_36)))) >= g_49) | 0xE434CEB5L) && p_36), g_1253[0][5][0])), 31)))), p_36)) && l_1328) || l_1273[1]), p_36)) ^ 0xB94CL))
                { /* block id: 583 */
                    int32_t *l_1329 = (void*)0;
                    uint16_t l_1353[4];
                    int32_t l_1409[6][1][3] = {{{0L,(-7L),0L}},{{1L,1L,1L}},{{0L,(-7L),0L}},{{1L,1L,1L}},{{0L,(-7L),0L}},{{1L,1L,1L}}};
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                        l_1353[i] = 0x1C16L;
                    l_1329 = l_1270[0];
                    for (g_106 = (-6); (g_106 == 38); ++g_106)
                    { /* block id: 587 */
                        return (*g_887);
                    }
                    if ((safe_sub_func_int8_t_s_s(((void*)0 != l_1334), (safe_add_func_int16_t_s_s(p_36, ((*l_797) = ((safe_lshift_func_int8_t_s_u((((g_1341 , ((g_1342 , ((g_1343[0][0] , ((((((!l_1273[1]) & 0x19BA98A932DC96DALL) , ((safe_mul_func_int32_t_s_s((safe_rshift_func_uint16_t_u_s((((***g_1149) = 0x51B3521199321211LL) || (***g_1229)), 12)), 0xB605D315L)) < p_36)) && p_36) > p_36) & p_36)) , 0L)) && g_799.f0)) == p_36) || 0x2273EB1BB17EC678LL), 1)) == p_36)))))))
                    { /* block id: 592 */
                        int32_t l_1349[3];
                        union U1 *l_1350[2];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1349[i] = 0L;
                        for (i = 0; i < 2; i++)
                            l_1350[i] = &g_1343[2][0];
                        l_1349[1] &= (l_1329 != (void*)0);
                        (*g_1351) = l_1350[1];
                        --l_1353[3];
                        (*l_1329) = ((safe_lshift_func_int32_t_s_s((-7L), 16)) >= (safe_sub_func_int32_t_s_s(p_36, ((l_1254 & ((((safe_lshift_func_int32_t_s_s((((65535UL & g_106) > 18446744073709551611UL) , (safe_mod_func_uint8_t_u_u((((safe_mul_func_int8_t_s_s((g_41 || (l_1251[5][1][4] = ((safe_lshift_func_uint32_t_u_s((~(safe_add_func_int8_t_s_s(g_957.f0, ((*l_795) == p_36)))), 7)) < l_1349[1]))), g_313.f2)) > (*l_1329)) && p_36), 0x80L))), 21)) < 0x75F617A2L) <= p_36) && p_36)) >= p_36))));
                    }
                    else
                    { /* block id: 598 */
                        int8_t *l_1381 = (void*)0;
                        int8_t *l_1382[5][8][4] = {{{&g_58,&g_630[2].f0,&l_642[2],&l_642[3]},{(void*)0,&g_1102.f0,&g_58,&g_630[2].f0},{&g_651,&g_58,&g_1102.f0,&g_1188.f0},{&g_651,&g_58,&g_58,&g_1188.f0},{(void*)0,&g_1188.f0,&l_642[2],&g_630[2].f0},{&g_58,&g_58,&g_58,&g_630[2].f0},{(void*)0,(void*)0,&g_1188.f0,&l_642[2]},{&g_1188.f0,&g_630[2].f0,(void*)0,&l_642[2]}},{{&g_651,&g_651,&g_651,&g_1102.f0},{&l_642[2],&g_1188.f0,&g_1102.f0,&g_1102.f0},{&g_1188.f0,&g_1102.f0,(void*)0,&g_1102.f0},{&g_651,&g_630[2].f0,(void*)0,&g_58},{&g_630[2].f0,&g_651,(void*)0,&g_58},{&g_58,&g_630[2].f0,&g_630[2].f0,&g_651},{&g_1102.f0,&g_1102.f0,&g_1188.f0,&g_651},{(void*)0,&l_642[2],&g_651,&g_58}},{{&g_630[2].f0,&g_58,&g_58,&g_630[2].f0},{&g_651,(void*)0,&g_651,&g_1102.f0},{&g_1102.f0,&g_630[2].f0,&g_630[2].f0,&g_630[2].f0},{&g_630[2].f0,(void*)0,&l_642[2],&g_630[2].f0},{&g_651,&g_651,(void*)0,(void*)0},{&g_630[2].f0,&g_1102.f0,&g_1102.f0,&g_1188.f0},{(void*)0,&g_630[2].f0,&g_1102.f0,&g_58},{&g_651,&g_651,&g_1188.f0,&g_1102.f0}},{{&g_58,&g_1188.f0,(void*)0,&l_642[3]},{&g_1188.f0,&l_642[3],&g_58,(void*)0},{&g_651,&g_630[2].f0,&g_58,&g_630[2].f0},{&l_642[3],&g_58,&l_642[3],&g_1188.f0},{&g_1188.f0,&g_630[2].f0,&g_630[2].f0,&l_642[2]},{&g_651,&g_630[2].f0,&g_651,&g_651},{&g_58,&g_58,&g_651,&g_58},{&g_1188.f0,&g_651,(void*)0,&l_642[3]}},{{&g_58,&l_642[2],&l_642[2],&g_651},{&g_1102.f0,(void*)0,&g_1102.f0,(void*)0},{&g_58,&g_630[2].f0,&g_630[2].f0,&g_630[2].f0},{(void*)0,&g_58,&g_651,&g_630[2].f0},{&l_642[2],&g_1188.f0,&g_651,(void*)0},{(void*)0,&g_1188.f0,&g_630[2].f0,(void*)0},{&g_58,&g_1188.f0,&g_1102.f0,&l_642[2]},{&g_1102.f0,&l_642[2],&l_642[2],&g_58}}};
                        uint64_t l_1408[9][6][4] = {{{18446744073709551615UL,0xEA459891861374F6LL,18446744073709551615UL,0x3BB714FD47A19762LL},{0xFC351E8524B116D9LL,0x4B77A2BDD244ADBBLL,0xB0C74F0CA8F93CB5LL,0xC174548DCDE082B3LL},{0xD40756C6D0FEFADCLL,0xD647B3F9055B0948LL,1UL,0xEBB2D9BE22A7453FLL},{0x4725747D204F9BEBLL,18446744073709551606UL,0x3BB714FD47A19762LL,1UL},{0xD647B3F9055B0948LL,0xF085DAB8CA459CEALL,18446744073709551611UL,0x63E147449A66244FLL},{0x5E8BB84C209906C7LL,18446744073709551615UL,0x37988793C4B6A410LL,0xE3C910410D0881D3LL}},{{0xB2CAD2034FDBD20BLL,0x4B77A2BDD244ADBBLL,0xB2CAD2034FDBD20BLL,18446744073709551615UL},{0xEBB2D9BE22A7453FLL,0xC174548DCDE082B3LL,18446744073709551615UL,1UL},{0x4725747D204F9BEBLL,0x37988793C4B6A410LL,18446744073709551615UL,0xC174548DCDE082B3LL},{0xC174548DCDE082B3LL,18446744073709551615UL,18446744073709551615UL,0x63E147449A66244FLL},{0x4725747D204F9BEBLL,0x5E8BB84C209906C7LL,18446744073709551615UL,18446744073709551615UL},{0xEBB2D9BE22A7453FLL,0xF085DAB8CA459CEALL,0xB2CAD2034FDBD20BLL,0xD647B3F9055B0948LL}},{{0xB2CAD2034FDBD20BLL,0xD647B3F9055B0948LL,0x37988793C4B6A410LL,0xD40756C6D0FEFADCLL},{0x5E8BB84C209906C7LL,0x37988793C4B6A410LL,18446744073709551611UL,18446744073709551615UL},{0xD647B3F9055B0948LL,0x5582ABD90D3CD11DLL,0x3BB714FD47A19762LL,0x3BB714FD47A19762LL},{0x4725747D204F9BEBLL,0x4725747D204F9BEBLL,1UL,0xE3C910410D0881D3LL},{0xD40756C6D0FEFADCLL,18446744073709551615UL,0xB0C74F0CA8F93CB5LL,0xD647B3F9055B0948LL},{0xFC351E8524B116D9LL,18446744073709551606UL,18446744073709551615UL,0xB0C74F0CA8F93CB5LL}},{{18446744073709551615UL,18446744073709551606UL,18446744073709551611UL,0xD647B3F9055B0948LL},{18446744073709551606UL,18446744073709551615UL,0x238A23ED55AB29C2LL,0xE3C910410D0881D3LL},{0x5E8BB84C209906C7LL,0x4725747D204F9BEBLL,18446744073709551606UL,0x3BB714FD47A19762LL},{0xEBB2D9BE22A7453FLL,0x5582ABD90D3CD11DLL,1UL,18446744073709551615UL},{0xFC351E8524B116D9LL,0x37988793C4B6A410LL,1UL,0xD40756C6D0FEFADCLL},{0xEA459891861374F6LL,0xD647B3F9055B0948LL,18446744073709551615UL,0xD647B3F9055B0948LL}},{{0x37988793C4B6A410LL,0xF085DAB8CA459CEALL,0x3BB714FD47A19762LL,18446744073709551615UL},{18446744073709551615UL,0x5E8BB84C209906C7LL,18446744073709551606UL,0x63E147449A66244FLL},{0xE3C910410D0881D3LL,0x5E8BB84C209906C7LL,18446744073709551614UL,1UL},{0xE3C910410D0881D3LL,0x1D761B475B9CF7D6LL,0xD40756C6D0FEFADCLL,18446744073709551615UL},{18446744073709551606UL,1UL,0x4EC7591068A9E70ALL,0xB0C74F0CA8F93CB5LL},{0x1D761B475B9CF7D6LL,18446744073709551613UL,0x4B77A2BDD244ADBBLL,0xFDA8613829AA7785LL}},{{18446744073709551615UL,18446744073709551606UL,0xFC351E8524B116D9LL,0xF085DAB8CA459CEALL},{18446744073709551614UL,0xEA459891861374F6LL,18446744073709551615UL,0xFC351E8524B116D9LL},{18446744073709551611UL,0xD40756C6D0FEFADCLL,0xD40756C6D0FEFADCLL,18446744073709551611UL},{0xC174548DCDE082B3LL,0xB2CAD2034FDBD20BLL,0x490A201F10DA3370LL,1UL},{0xD40756C6D0FEFADCLL,18446744073709551613UL,0x5582ABD90D3CD11DLL,0x4EC7591068A9E70ALL},{18446744073709551606UL,18446744073709551615UL,0xB0C74F0CA8F93CB5LL,0x4EC7591068A9E70ALL}},{{18446744073709551614UL,18446744073709551613UL,0x238A23ED55AB29C2LL,1UL},{0x3BB714FD47A19762LL,0xB2CAD2034FDBD20BLL,0xFC351E8524B116D9LL,18446744073709551611UL},{18446744073709551615UL,0xD40756C6D0FEFADCLL,0x4EC7591068A9E70ALL,0xFC351E8524B116D9LL},{0xB2CAD2034FDBD20BLL,0xEA459891861374F6LL,0x5582ABD90D3CD11DLL,0xF085DAB8CA459CEALL},{0xC174548DCDE082B3LL,18446744073709551606UL,0x1D761B475B9CF7D6LL,0xFDA8613829AA7785LL},{0xE3C910410D0881D3LL,18446744073709551613UL,0xE3C910410D0881D3LL,0xB0C74F0CA8F93CB5LL}},{{18446744073709551611UL,1UL,0xB0C74F0CA8F93CB5LL,18446744073709551615UL},{18446744073709551615UL,0x1D761B475B9CF7D6LL,0x4B77A2BDD244ADBBLL,1UL},{1UL,0x5E8BB84C209906C7LL,0x4B77A2BDD244ADBBLL,0xF085DAB8CA459CEALL},{18446744073709551615UL,0xC174548DCDE082B3LL,0xB0C74F0CA8F93CB5LL,0x4B77A2BDD244ADBBLL},{18446744073709551611UL,0xEA459891861374F6LL,0xE3C910410D0881D3LL,0xB2CAD2034FDBD20BLL},{0xE3C910410D0881D3LL,0xB2CAD2034FDBD20BLL,0x1D761B475B9CF7D6LL,0x3BB714FD47A19762LL}},{{0xC174548DCDE082B3LL,0x1D761B475B9CF7D6LL,0x5582ABD90D3CD11DLL,0xB0C74F0CA8F93CB5LL},{0xB2CAD2034FDBD20BLL,1UL,0x4EC7591068A9E70ALL,0x4EC7591068A9E70ALL},{18446744073709551615UL,18446744073709551615UL,0xFC351E8524B116D9LL,0xFDA8613829AA7785LL},{0x3BB714FD47A19762LL,0x5E8BB84C209906C7LL,0x238A23ED55AB29C2LL,0xB2CAD2034FDBD20BLL},{18446744073709551614UL,0xD40756C6D0FEFADCLL,0xB0C74F0CA8F93CB5LL,0x238A23ED55AB29C2LL},{18446744073709551606UL,0xD40756C6D0FEFADCLL,0x5582ABD90D3CD11DLL,0xB2CAD2034FDBD20BLL}}};
                        int i, j, k;
                        l_1384[4] |= (safe_div_func_int32_t_s_s((safe_div_func_uint8_t_u_u(254UL, l_1273[7])), (safe_div_func_int8_t_s_s((*l_795), (safe_div_func_int16_t_s_s(((*l_797) = (((***l_1296)--) & (l_1251[4][0][4] = 0x6DL))), l_1383))))));
                        if (p_36)
                            break;
                        l_1409[1][0][2] &= (safe_sub_func_int32_t_s_s(((*l_1329) = ((*l_795) = (l_1273[7] = (safe_lshift_func_int8_t_s_u(((void*)0 == g_1389), 3))))), ((safe_mod_func_uint8_t_u_u(((***l_1296) = (safe_add_func_int16_t_s_s(0x4F68L, p_36))), (l_1254 = (((safe_sub_func_uint16_t_u_u((+p_36), (l_1251[3][1][3] ^= p_36))) & (safe_mod_func_int16_t_s_s(((g_1400 , g_1401) >= (safe_lshift_func_int8_t_s_u((g_1343[0][0].f1 = (safe_lshift_func_uint8_t_u_s((((safe_mod_func_uint16_t_u_u(((p_36 > 255UL) , l_1408[3][3][3]), p_36)) >= (**g_886)) != l_1408[7][1][2]), p_36))), 2))), g_1102.f0))) | (*g_1101))))) && 0xE47B833EBD2D7063LL)));
                    }
                    (*l_795) |= (g_619 , (safe_rshift_func_uint64_t_u_s((g_1412 , (!(safe_unary_minus_func_uint64_t_u((safe_sub_func_int64_t_s_s(((((safe_unary_minus_func_int64_t_s(((safe_unary_minus_func_uint16_t_u(0x5023L)) , (g_49 == p_36)))) , &g_1243) != &g_1019) ^ ((1L < p_36) | (*g_805))), 4L)))))), 26)));
                }
                else
                { /* block id: 614 */
                    int32_t *l_1419 = &l_1298;
                    int32_t l_1420 = 0x31BE2492L;
                    uint16_t *l_1426 = &l_1383;
                    const uint16_t *l_1428 = &g_1429;
                    const uint16_t **l_1427 = &l_1428;
                    uint8_t *l_1440 = (void*)0;
                    int32_t *l_1489[3][4][5] = {{{&l_1298,&l_1298,&l_1298,&l_1298,&l_1298},{&l_1271,&l_1271,&l_1271,&l_1271,&l_1271},{&l_1298,&l_1298,&l_1298,&l_1298,&l_1298},{&l_1271,&l_1271,&l_1271,&l_1271,&l_1271}},{{&l_1298,&l_1298,&l_1298,&l_1298,&l_1298},{&l_1271,&l_1271,&l_1271,&l_1271,&l_1271},{&l_1298,&l_1298,&l_1298,&l_1298,&l_1298},{&l_1271,&l_1271,&l_1271,&l_1271,&l_1271}},{{&l_1298,&l_1298,&l_1298,&l_1298,&l_1298},{&l_1271,&l_1271,&l_1271,&l_1271,&l_1271},{&l_1298,&l_1298,&l_1298,&l_1298,&l_1298},{&l_1271,&l_1271,&l_1271,&l_1271,&l_1271}}};
                    int i, j, k;
                    (*g_383) = l_1419;
                    ++l_1422[0];
                    if ((g_1425 , ((((l_1426 != ((*l_1427) = &l_1383)) != ((((((&g_1228[2][6][3] != &g_1229) | (g_1261[5][0].f0 >= ((((safe_sub_func_int16_t_s_s((~((*l_795) = (((~((safe_unary_minus_func_uint32_t_u((((l_1270[1] != (((((*l_1321) = (((safe_add_func_int64_t_s_s((safe_mul_func_uint8_t_u_u(((safe_unary_minus_func_uint32_t_u(((0xF3L | ((*l_333) ^= (*g_933))) || p_36))) <= 0x1DL), p_36)), (*l_795))) > 18446744073709551613UL) < l_1273[1])) && 0xA2L) != 18446744073709551615UL) , (void*)0)) , (*g_1101)) , l_1328))) <= 18446744073709551608UL)) || l_1384[4]) <= l_1251[5][1][4]))), g_137)) | p_36) | l_1251[5][0][4]) > p_36))) || p_36) ^ (*g_609)) <= p_36) == (**g_1100))) != 0x4E90L) , (*g_805))))
                    { /* block id: 621 */
                        union U4 **l_1457 = (void*)0;
                        (*l_333) = ((l_1441 == l_1442[1]) , ((~0x96CFL) & (g_866.f0 <= ((l_1249 , (safe_sub_func_uint32_t_u_u(((1UL == ((((l_1273[3] &= (safe_div_func_uint8_t_u_u((*l_333), (((safe_div_func_int32_t_s_s((safe_mod_func_uint32_t_u_u(((g_1458 = l_1455) != l_1460), (*l_1419))), p_36)) <= l_1462) , 0x3DL)))) || l_1298) != p_36) , p_36)) && p_36), l_1254))) ^ 65535UL))));
                    }
                    else
                    { /* block id: 625 */
                        uint32_t l_1473 = 6UL;
                        int8_t *l_1487 = &g_1343[0][0].f1;
                        int32_t l_1488[7][5];
                        int i, j;
                        for (i = 0; i < 7; i++)
                        {
                            for (j = 0; j < 5; j++)
                                l_1488[i][j] = 0x2F46B12AL;
                        }
                        if (l_1384[3])
                            break;
                        (*l_1419) = (safe_rshift_func_uint8_t_u_s((safe_add_func_int16_t_s_s((safe_mod_func_uint64_t_u_u((((**g_608) = (safe_lshift_func_uint64_t_u_u((0xABDFL > (((p_36 != (safe_sub_func_uint32_t_u_u((l_1473--), (-2L)))) != (safe_add_func_int64_t_s_s((safe_mod_func_int64_t_s_s((((safe_div_func_int32_t_s_s((((safe_div_func_int8_t_s_s(((*l_1487) = ((safe_div_func_uint8_t_u_u(((***l_1296) = (p_36 , (((0xFEL == p_36) || 65530UL) < (!g_313.f3)))), ((***g_361) , p_36))) | (*l_1419))), l_1488[4][1])) , g_776.f0) , p_36), 4294967295UL)) ^ p_36) ^ p_36), l_1249)), p_36))) , 0UL)), 35))) & 0xC7C1E8F2B0A4B119LL), p_36)), p_36)), 0));
                        if (p_36)
                            break;
                    }
                    l_1489[1][1][4] = &l_1251[2][0][1];
                }
            }
            else
            { /* block id: 636 */
                int16_t l_1490[5][10][5] = {{{0x6A05L,0xE329L,6L,0L,0xE429L},{6L,1L,0x93D9L,8L,(-1L)},{1L,5L,0xC4FBL,0L,0x27A7L},{1L,0x8AABL,(-3L),0L,(-2L)},{0x6A05L,0x89D8L,0L,0L,3L},{(-4L),(-8L),0xE429L,3L,2L},{1L,0xA9BEL,(-8L),0xB380L,(-1L)},{0xE276L,0xE146L,(-4L),0L,(-3L)},{4L,0x4D6FL,(-1L),0x9C4DL,3L},{(-3L),0x4D6FL,(-1L),0L,0x6A05L}},{{0xDD85L,0xE146L,(-3L),(-1L),1L},{0xE329L,0xA9BEL,0x489BL,1L,0x27A7L},{0xCCA2L,(-8L),0L,0xC996L,1L},{0x93D9L,0x89D8L,0L,0x89D8L,0x93D9L},{0L,0x9A78L,0L,1L,0xE429L},{0x9C4DL,4L,0x89D8L,0x27A7L,0x1B5DL},{6L,0x1B5DL,0xA9BEL,0x9A78L,0xE429L},{0L,0x27A7L,1L,0xE329L,0x93D9L},{0xE429L,0x8AABL,0x1C5BL,(-8L),1L},{3L,0x61B5L,1L,(-2L),0x27A7L}},{{0L,0xE329L,(-4L),0xCCA2L,1L},{1L,2L,1L,1L,0x6A05L},{0x7E57L,1L,3L,6L,3L},{6L,0xC996L,3L,0L,(-3L)},{0x89D8L,0L,1L,0x98DBL,(-1L)},{0xB9EAL,0L,(-4L),1L,2L},{0x4D6FL,0L,1L,(-1L),3L},{0L,(-2L),0x1C5BL,0x1C5BL,(-2L)},{0L,0x489BL,1L,1L,(-8L)},{0x1B5DL,1L,0xA9BEL,0x6A05L,0x61B5L}},{{0x1C5BL,0L,0x89D8L,8L,0xC996L},{0x1B5DL,0xB9EAL,0L,(-1L),(-1L)},{0L,0x1C5BL,0L,0x1B5DL,0xE329L},{0L,(-1L),0L,0x7E57L,0x489BL},{0x4D6FL,0L,0x489BL,4L,(-4L)},{0xB9EAL,1L,(-3L),6L,0x9A78L},{0x89D8L,1L,(-1L),0L,0x4D6FL},{6L,5L,(-1L),0L,0xB380L},{0x7E57L,0xC4FBL,(-4L),6L,2L},{1L,8L,(-8L),4L,0L}},{{0L,0x420EL,0xE429L,0x7E57L,4L},{3L,(-4L),0L,0x1B5DL,6L},{0xC996L,0xC996L,0x4D6FL,0xA9BEL,0x0A63L},{0L,1L,1L,0xC4FBL,(-3L)},{(-3L),0L,0L,(-1L),0x1B5DL},{8L,1L,0x1C5BL,0x7E57L,0x0C12L},{6L,0xC996L,0x9A78L,(-1L),3L},{0x4D6FL,0xE146L,8L,0x0A63L,1L},{3L,0xB9EAL,0xE429L,1L,0x89D8L},{0x27A7L,0xC4FBL,6L,0xE329L,0xE276L}}};
                int i, j, k;
                for (g_1108.f2 = 0; g_1108.f2 < 6; g_1108.f2 += 1)
                {
                    l_1384[g_1108.f2] = 0x5115357EL;
                }
                l_1252 |= l_1490[1][3][4];
                return l_1490[1][3][4];
            }
            if (p_36)
                continue;
            for (p_36 = 0; (p_36 > (-22)); p_36 = safe_sub_func_int64_t_s_s(p_36, 9))
            { /* block id: 644 */
                uint32_t l_1493 = 4294967295UL;
                int32_t l_1500[7][9] = {{0L,0x98F8BF4DL,0x90A71173L,0x6C406BB8L,6L,0x6D7E935CL,0xB6AFB7CDL,6L,0xABF6ADA9L},{0L,6L,0xFA1AFE49L,0x6C406BB8L,0x46C19D3FL,0xB6AFB7CDL,0xB6AFB7CDL,0x46C19D3FL,0x6C406BB8L},{0L,0x46C19D3FL,0L,0x6C406BB8L,0x98F8BF4DL,0x277BE6CAL,0xB6AFB7CDL,0x98F8BF4DL,(-1L)},{0L,0x98F8BF4DL,0x90A71173L,0x6C406BB8L,6L,0x6D7E935CL,0xB6AFB7CDL,6L,0xABF6ADA9L},{0L,6L,0xFA1AFE49L,0x6C406BB8L,0x46C19D3FL,0xB6AFB7CDL,0xB6AFB7CDL,0x46C19D3FL,0x6C406BB8L},{0L,0x46C19D3FL,0L,0x6C406BB8L,0x98F8BF4DL,0x277BE6CAL,0xB6AFB7CDL,0x98F8BF4DL,(-1L)},{0L,0x98F8BF4DL,0x90A71173L,0x6C406BB8L,6L,0x6D7E935CL,0xB6AFB7CDL,6L,0xABF6ADA9L}};
                uint32_t * const *l_1520 = &l_1250[1];
                int32_t l_1537 = 0x0E7E440CL;
                uint16_t ***l_1541 = &g_886;
                uint64_t *l_1572[9][1][7] = {{{&l_1234,(void*)0,&l_1234,&l_1504,&l_1234,&l_1234,(void*)0}},{{&l_1504,&l_1136,&g_55,&g_49,&l_1136,&l_1504,&g_1538}},{{&l_1136,&g_55,&l_1234,&l_1234,&g_1538,&l_1234,&l_1504}},{{(void*)0,&l_1136,&g_49,&l_1234,&g_49,&l_1136,(void*)0}},{{(void*)0,&l_1234,&l_1234,&g_55,&l_1136,&g_49,&g_49}},{{&l_1136,&l_1136,&l_1234,&l_1504,&l_1504,&g_55,&l_1136}},{{&l_1504,&g_1538,&l_1234,(void*)0,&g_55,&l_1504,&g_55}},{{&l_1234,&g_49,&g_49,&l_1234,&g_55,&l_1136,&g_55}},{{&l_1504,&l_1136,&l_1234,&g_55,&l_1504,&l_1136,(void*)0}}};
                int i, j, k;
                for (l_1272 = 5; (l_1272 >= 1); l_1272 -= 1)
                { /* block id: 647 */
                    int32_t l_1503[1][10];
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 10; j++)
                            l_1503[i][j] = (-7L);
                    }
                    if (l_1384[l_1272])
                    { /* block id: 648 */
                        int i;
                        return l_1384[l_1272];
                    }
                    else
                    { /* block id: 650 */
                        int32_t *l_1496 = (void*)0;
                        int32_t *l_1497 = &g_281;
                        int32_t *l_1498 = &l_355[2];
                        int32_t *l_1499 = &g_103;
                        int32_t *l_1501 = &l_355[8];
                        int32_t *l_1502[10] = {&l_1282,&l_1384[l_1272],&l_1282,&l_1384[l_1272],&l_1282,&l_1384[l_1272],&l_1282,&l_1384[l_1272],&l_1282,&l_1384[l_1272]};
                        int i;
                        l_1493--;
                        (*l_333) = ((*l_795) = l_1384[l_1272]);
                        ++l_1504;
                    }
                }
                if ((((*l_795) == (!((g_1102.f0 ^= ((!(((safe_add_func_int8_t_s_s(((g_1511 , ((safe_add_func_uint8_t_u_u(((((safe_div_func_int16_t_s_s((safe_mod_func_int64_t_s_s((safe_sub_func_int8_t_s_s(((void*)0 != l_1520), (safe_mul_func_uint16_t_u_u(((**g_886)--), l_1500[6][2])))), (safe_rshift_func_uint8_t_u_s(((safe_rshift_func_int32_t_s_u((safe_rshift_func_int32_t_s_s((safe_div_func_uint16_t_u_u(((((*l_333) = p_36) <= (safe_mod_func_uint16_t_u_u(0x6D9FL, ((l_1537 &= ((*g_933) &= (((+(l_1298 = ((***g_1149) = (((*l_781) = l_1249) | (safe_unary_minus_func_uint32_t_u(((l_1272 = (p_36 != l_1328)) & 1UL))))))) >= 65534UL) && g_1043))) , p_36)))) != 6L), 0x0F84L)), p_36)), 9)) ^ 0xB8L), p_36)))), l_1500[4][1])) | 255UL) && g_1195.f0) , p_36), g_1538)) , l_1539)) == l_1541), 0xBAL)) , (void*)0) == &l_1282)) | l_1384[4])) & p_36))) , 0xF1BED5ADL))
                { /* block id: 666 */
                    uint16_t * const **l_1542 = &l_1540;
                    if (p_36)
                    { /* block id: 667 */
                        return l_1273[1];
                    }
                    else
                    { /* block id: 669 */
                        uint16_t * const ***l_1543 = &l_1539;
                        (*l_795) = (((((*l_1543) = l_1542) == (void*)0) == 0x0452L) | ((***g_1229) ^= (safe_lshift_func_uint32_t_u_s(0x5F787B10L, 8))));
                    }
                }
                else
                { /* block id: 674 */
                    const uint16_t l_1557 = 1UL;
                    uint16_t *l_1565[7][7][5] = {{{&g_137,&g_137,(void*)0,&l_1383,&l_1269},{&l_1383,&l_1383,&g_137,&l_840,&l_1383},{&g_137,&g_137,&g_137,&l_1383,&g_137},{&g_559,&g_137,(void*)0,&l_1255,&g_137},{&g_137,&l_840,&l_1269,&g_137,&l_1383},{&g_137,&l_1255,&l_1255,&l_840,&l_1255},{&g_137,&g_559,&l_1269,&g_137,(void*)0}},{{&g_137,&l_1383,&g_137,(void*)0,(void*)0},{&g_137,&l_1383,&g_137,&l_1255,&l_1269},{&g_559,&l_1383,&g_559,&g_137,(void*)0},{&l_1269,&g_559,&g_137,&g_137,&l_1255},{&l_1255,(void*)0,&g_559,(void*)0,&l_1383},{&l_1269,&l_840,&g_137,&l_840,&l_1269},{&l_1255,&g_137,&g_137,&g_559,&l_1383}},{{&l_840,&g_137,&l_1269,&g_137,&g_137},{(void*)0,&g_559,&l_1255,&g_137,&l_1383},{&l_840,&g_137,&l_1269,&l_1255,&l_1269},{&l_1383,&l_1383,(void*)0,(void*)0,&l_1383},{&g_559,&l_1269,&l_840,&g_137,&l_1255},{(void*)0,&l_840,(void*)0,&l_1383,(void*)0},{&l_1269,&l_1269,&l_840,&g_137,&l_1269}},{{&l_1255,&l_1383,&l_1383,(void*)0,(void*)0},{&g_137,&g_137,&g_559,(void*)0,(void*)0},{&l_1255,&g_559,(void*)0,&g_137,&l_1255},{(void*)0,&g_137,&l_1269,(void*)0,&l_1383},{&g_559,&g_137,(void*)0,(void*)0,&g_137},{&l_1255,&l_840,&g_137,&g_137,&g_137},{&g_137,(void*)0,&l_1255,&l_1383,&l_1255}},{{&l_1383,&g_559,(void*)0,&g_137,&g_137},{&g_137,&l_1383,&g_137,(void*)0,(void*)0},{&l_1255,&l_1383,&l_1255,&l_1255,&g_137},{&g_559,&l_1383,&g_559,&g_137,(void*)0},{(void*)0,&g_559,&l_1383,&g_137,&g_137},{&l_1255,&l_1255,&g_559,&g_559,&l_1383},{&g_137,&l_840,&l_1255,&l_840,&g_137}},{{&l_1255,&g_137,&g_137,(void*)0,&l_1383},{&l_1269,&g_137,(void*)0,&g_137,&l_1269},{(void*)0,&g_137,&l_1255,&g_137,&l_1383},{&g_559,&g_137,&g_137,&l_1255,&g_137},{&l_1383,&l_1383,(void*)0,(void*)0,&l_1383},{&l_840,&l_1269,&l_1269,&g_137,&l_1269},{&g_137,(void*)0,&g_137,&g_559,&l_1383}},{{&l_1255,&g_137,&g_137,&g_137,(void*)0},{&l_1383,&l_840,&l_840,&l_1383,&g_137},{&l_1269,&g_559,&g_137,&l_1269,&l_1269},{&g_559,&l_1269,&g_137,&l_840,&g_559},{&g_137,&g_137,&l_1255,&l_1269,&l_1269},{(void*)0,(void*)0,&l_1383,&l_1383,&l_1255},{&l_1269,&l_1383,&l_1269,&g_137,(void*)0}}};
                    int i, j, k;
                    l_1500[6][2] = (safe_add_func_uint16_t_u_u(((*l_795) ^= (safe_div_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((((safe_lshift_func_int16_t_s_u(p_36, 5)) < (((~l_1384[4]) , (((((*g_933) || (safe_rshift_func_int8_t_s_u(p_36, 5))) | l_1557) ^ (safe_lshift_func_uint32_t_u_s((((g_1560 , (safe_unary_minus_func_uint32_t_u((safe_mul_func_int32_t_s_s(p_36, ((**l_1539) == (l_1565[6][3][0] = l_1564[5][0]))))))) , g_1566) , 1UL), 17))) <= 0x35L)) || 0x78D54D3CL)) < g_1538), p_36)), p_36))), l_1567));
                    for (l_1252 = 0; (l_1252 <= 4); l_1252 += 1)
                    { /* block id: 680 */
                        int32_t l_1573[2];
                        int i, j;
                        for (i = 0; i < 2; i++)
                            l_1573[i] = 0L;
                        l_1573[1] |= (l_1500[l_1252][(l_1252 + 3)] = ((safe_mul_func_int16_t_s_s((((l_676[l_1252][l_1252] != (!l_676[l_1252][l_1252])) && (l_1500[(l_1252 + 2)][(l_1252 + 1)] != p_36)) && 0x1AL), (((p_36 , ((*l_797) = l_1500[5][6])) <= ((l_1571 != l_1572[5][0][2]) == p_36)) >= g_1059.f0))) <= p_36));
                    }
                }
                l_1254 = ((*g_887) >= ((**g_1100) >= (!0x1A02L)));
            }
        }
        else
        { /* block id: 688 */
            return p_36;
        }
        ++l_1581;
        l_795 = &l_1282;
        if (((safe_add_func_int8_t_s_s((*l_1578), ((*l_1578) > (safe_sub_func_uint64_t_u_u(((*l_794) = (safe_lshift_func_uint8_t_u_s(((*g_1148) == l_1590), 4))), (((***g_1229) >= ((((safe_rshift_func_uint32_t_u_s((((safe_mod_func_uint32_t_u_u(((0x626AL & 0UL) && ((safe_add_func_uint64_t_u_u((((((*l_1578) >= (0x1AL != 0x45L)) , 0x66C1A057L) , p_36) >= 0UL), p_36)) == 0xBE34L)), p_36)) , 18446744073709551615UL) <= 18446744073709551606UL), 22)) , p_36) , &g_634) != l_1597)) | g_220)))))) <= g_630[2].f0))
        { /* block id: 694 */
            uint64_t l_1598 = 0x2BE1B35D7D4ADFE8LL;
            uint32_t *l_1620 = (void*)0;
            uint32_t *l_1621[7];
            int32_t l_1623 = 1L;
            int64_t l_1630 = 0x28269A882ABC7B87LL;
            int32_t l_1648 = 7L;
            int i;
            for (i = 0; i < 7; i++)
                l_1621[i] = (void*)0;
            (*l_1578) |= l_1598;
            (*l_795) = (safe_mod_func_uint32_t_u_u(l_1598, (safe_sub_func_uint64_t_u_u((((l_1598 , 0xD8L) ^ (l_1603 || (((safe_div_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_u((safe_lshift_func_uint32_t_u_u((l_1623 |= (l_1622 = ((((((p_36 , p_36) == (((*l_1578) ^= (safe_add_func_uint16_t_u_u((((safe_lshift_func_uint64_t_u_s((safe_div_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(p_36, p_36)), (safe_rshift_func_int8_t_s_u(l_1598, p_36)))), 57)) == (*l_333)) > p_36), p_36))) | (*l_333))) > 0x2FL) > p_36) == 0x8187F8F7L) & p_36))), 24)), 56)), (-1L))) , g_1217[6][0]) , 0x49L))) >= (***g_1229)), 0xAD375D30FFEDBEFFLL))));
            if (l_1623)
                continue;
            (*l_795) = ((((safe_add_func_uint8_t_u_u((((*l_781) = ((0L == (safe_sub_func_uint64_t_u_u((safe_div_func_uint16_t_u_u((++(*g_887)), (safe_rshift_func_uint16_t_u_u((((l_1648 = (g_1635 , ((g_957 , (((l_1623 = (safe_mod_func_int32_t_s_s((safe_div_func_uint64_t_u_u((safe_rshift_func_int8_t_s_u(((0UL >= (safe_add_func_uint8_t_u_u((*l_1577), g_619.f3))) >= p_36), 7)), (safe_lshift_func_uint64_t_u_u(((safe_mul_func_int16_t_s_s(((*l_797) = p_36), 0UL)) < (*l_1577)), 7)))), (*l_795)))) && p_36) & l_1630)) , l_1630))) || l_1598) || p_36), p_36)))), (*g_609)))) < 0x22L)) | 0x413A11B3B26FA2DBLL), l_1598)) , p_36) != p_36) & 0xDEA07D1107B9CEE1LL);
        }
        else
        { /* block id: 707 */
            return p_36;
        }
    }
    return p_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_137 g_106 g_49 g_58
 * writes: g_106 g_112
 */
static uint8_t  func_42(uint16_t  p_43, uint8_t  p_44, uint32_t  p_45)
{ /* block id: 90 */
    union U3 *l_293 = (void*)0;
    int32_t l_294[1][5];
    int32_t l_297[5][10][2] = {{{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L}},{{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL}},{{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L}},{{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L}},{{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL},{0xAD021357L,0xAD021357L},{0x5DCC4CECL,0xAD021357L},{0xAD021357L,0x5DCC4CECL}}};
    int32_t l_298 = (-8L);
    int32_t **l_301[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t *l_302[9] = {&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103};
    int8_t l_307 = 0x1CL;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
            l_294[i][j] = 0xC0611843L;
    }
    l_298 |= (!(((void*)0 == l_293) > ((((l_297[1][0][0] |= (((l_294[0][0] , p_45) || (safe_mod_func_uint32_t_u_u((l_294[0][2] <= (l_294[0][0] ^ ((((p_44 <= l_294[0][0]) != p_44) <= g_137) ^ l_294[0][4]))), g_106))) , l_294[0][3])) <= l_294[0][0]) < 65527UL) | l_294[0][3])));
    l_307 ^= (safe_sub_func_uint16_t_u_u((((l_302[2] = &l_297[1][0][0]) != (void*)0) | (~(0x18BF9BF2L && (((((g_49 > (g_106 = 248UL)) | (~(safe_rshift_func_int8_t_s_s(0x30L, 3)))) , (g_49 , (p_45 >= 0x0FL))) , p_45) || 1UL)))), p_45));
    g_112[3] = &g_103;
    for (l_307 = (-21); (l_307 <= 9); l_307 = safe_add_func_uint8_t_u_u(l_307, 9))
    { /* block id: 99 */
        if (p_45)
            break;
    }
    return g_58;
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_56 g_82 g_58 g_100 g_106 g_103 g_137 g_140.f1 g_212 g_220
 * writes: g_55 g_58 g_82 g_106 g_112 g_137 g_103 g_140.f1 g_220 g_56
 */
static uint32_t  func_52(const uint64_t * const  p_53)
{ /* block id: 4 */
    uint32_t l_63 = 1UL;
    int32_t l_83[9][5][5] = {{{0x0716CFB3L,(-1L),1L,0x548DC091L,0x55878DFEL},{1L,1L,(-2L),(-8L),0x7FAAB159L},{3L,(-8L),0x28F68172L,1L,(-1L)},{(-2L),(-5L),0x55878DFEL,0L,0xE67F5904L},{0L,0x31782E4DL,4L,(-10L),(-1L)}},{{0x2E8F9889L,(-10L),0xF8526697L,8L,(-1L)},{0x98D42F46L,3L,(-1L),0xA004931BL,0xA004931BL},{0x9D328171L,(-5L),0x9D328171L,0xF6A0F30BL,0x28F68172L},{8L,8L,0x28F68172L,0x8FA0D634L,(-7L)},{0x02726712L,0x63CC5DB0L,0xE67F5904L,1L,0xDE7E8591L}},{{0xDE7E8591L,0L,0x28F68172L,(-7L),0xD34D3BE1L},{0xBDF0D7C7L,8L,0x9D328171L,0x0716CFB3L,0xE1BD6F38L},{3L,0xA27C819AL,(-1L),0x303F68C3L,0x8F5644FEL},{(-5L),1L,(-2L),(-5L),(-7L)},{0L,(-5L),0x89F16C48L,0x55878DFEL,(-2L)}},{{0L,0x31782E4DL,(-7L),0x3EC6B4E2L,0L},{0x75C26FF5L,0x8FA0D634L,1L,(-1L),0xDE7E8591L},{0xE4714FE2L,1L,(-2L),0x8F5644FEL,0x33FE686BL},{0x3EC6B4E2L,0xD66C2530L,0x7FAAB159L,0xD54FCFB0L,0L},{0x3EC6B4E2L,0L,(-1L),0x2BED38BCL,1L}},{{0xE4714FE2L,1L,(-1L),0xAA6F331AL,0x28F68172L},{0x75C26FF5L,0xE67F5904L,0x02726712L,0xF6A0F30BL,(-1L)},{0L,0x63CC5DB0L,0xA004931BL,8L,0xA27C819AL},{0L,1L,0L,(-7L),1L},{(-5L),0L,(-1L),0x8F5644FEL,0x212E26E4L}},{{3L,0L,0L,3L,1L},{0xBDF0D7C7L,1L,(-2L),5L,0x8F5644FEL},{0xDE7E8591L,1L,0L,0x28F68172L,(-2L)},{0x02726712L,0L,0x50E7A764L,5L,0x19957B09L},{8L,0x8FA0D634L,(-7L),3L,0xA27C819AL}},{{0x9D328171L,0x0716CFB3L,0xE1BD6F38L,0x8F5644FEL,0xE4714FE2L},{0x79A1AFFFL,0xC1AAD5EAL,0x19957B09L,(-7L),(-10L)},{0x3EC6B4E2L,0x02726712L,0L,8L,0xE67F5904L},{0xD54FCFB0L,0x548DC091L,(-1L),0xF6A0F30BL,0L},{0x678D1974L,1L,0x55878DFEL,0xAA6F331AL,(-1L)}},{{0x02726712L,0xDE7E8591L,1L,0x2BED38BCL,0L},{0xA27C819AL,1L,0x28F68172L,0xD54FCFB0L,0L},{1L,1L,0xE4714FE2L,0x8F5644FEL,0xE1BD6F38L},{0x5AE7BE98L,0xDE7E8591L,0L,(-1L),1L},{0xBDF0D7C7L,1L,0x7FAAB159L,0x3EC6B4E2L,1L}},{{0x63CC5DB0L,0x548DC091L,0L,0x55878DFEL,0L},{0L,0x02726712L,(-3L),(-5L),0x19957B09L},{0x75C26FF5L,0xC1AAD5EAL,0x50E7A764L,0x303F68C3L,0L},{(-7L),0x0716CFB3L,(-2L),0x0716CFB3L,(-7L)},{(-10L),0x8FA0D634L,0x212E26E4L,0x2BED38BCL,1L}}};
    int8_t *l_110 = (void*)0;
    int32_t *l_164 = &l_83[7][1][4];
    uint32_t l_199 = 0x9E1138FAL;
    uint32_t l_243 = 0x4407F4ECL;
    int8_t l_263 = 7L;
    int16_t l_282 = 2L;
    uint16_t l_288 = 1UL;
    int32_t l_291 = 0x9B31CC3BL;
    int i, j, k;
    for (g_55 = 0; (g_55 <= 4); g_55 += 1)
    { /* block id: 7 */
        int8_t *l_57[2][6] = {{&g_58,&g_58,&g_58,&g_58,&g_58,&g_58},{&g_58,&g_58,&g_58,&g_58,&g_58,&g_58}};
        int32_t l_64 = (-1L);
        int32_t l_65 = 6L;
        uint32_t *l_81[6];
        int32_t l_84 = (-3L);
        uint32_t **l_98 = (void*)0;
        uint32_t **l_99 = &l_81[2];
        int32_t *l_109 = (void*)0;
        union U3 *l_139[7];
        int32_t l_177 = 1L;
        int32_t l_180 = 0x3A04F61BL;
        int32_t l_181 = 0L;
        int16_t l_191 = (-1L);
        union U3 *l_222 = &g_223;
        uint16_t l_251[1][9][5] = {{{65527UL,0x78C3L,0x684CL,0UL,0xF6E4L},{0x4C7AL,0UL,0x6C61L,0x7655L,0x7655L},{65527UL,0x0BC0L,65527UL,0x6C61L,0UL},{65535UL,0x0BC0L,0x55A1L,0x4C7AL,0x78C3L},{0x5312L,0UL,0x7655L,0x684CL,65535UL},{65529UL,0x78C3L,0x55A1L,0x78C3L,65529UL},{0UL,0x4C7AL,65527UL,0x78C3L,0x684CL},{0xA448L,0UL,0x6C61L,0x684CL,0xF8E8L},{0x55A1L,65527UL,0x684CL,0x4C7AL,0x684CL}}};
        int32_t l_283 = 0x6A3583BDL;
        int32_t l_284 = 0xDFC62B8DL;
        int32_t l_285 = 0x829D7283L;
        int32_t l_286 = 0x4B601889L;
        int32_t l_287[2];
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_81[i] = &g_82;
        for (i = 0; i < 7; i++)
            l_139[i] = &g_140;
        for (i = 0; i < 2; i++)
            l_287[i] = (-6L);
        l_65 |= ((((g_55 ^ (g_58 = 1L)) , (safe_sub_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u(l_63, l_64)), ((((g_56[3] , 0L) , p_53) == (void*)0) ^ (((l_63 != g_56[2]) >= (*p_53)) == (*p_53)))))) >= 0xC7C747CAL) > 0L);
        l_83[1][3][3] = ((safe_mod_func_int16_t_s_s(func_68(((((((!0UL) < (l_64 = (g_55 , l_63))) ^ (safe_lshift_func_uint32_t_u_s((l_83[0][3][4] = ((l_63 ^ (safe_mul_func_int32_t_s_s((((safe_mul_func_int32_t_s_s(((safe_lshift_func_uint64_t_u_u(((0xE059L >= (safe_mod_func_int32_t_s_s(((g_82++) >= (safe_unary_minus_func_uint16_t_u(g_58))), l_65))) <= (((safe_add_func_int16_t_s_s((safe_div_func_int16_t_s_s((safe_mul_func_int64_t_s_s((((((l_83[5][3][3] & (((*l_99) = l_81[2]) == g_100)) == 0x0A97L) > l_84) || g_56[3]) , (-6L)), (*p_53))), g_56[1])), 0xDF1EL)) ^ 0UL) != l_84)), 21)) || 0xAFD11FF246F76720LL), 0xB336EB9BL)) && l_83[5][3][4]) , 0L), g_55))) || (-1L))), l_63))) , l_63) < l_84) < g_56[1])), g_55)) > 0x35A0L);
        for (l_64 = 0; (l_64 <= 4); l_64 += 1)
        { /* block id: 20 */
            int64_t l_113[3];
            uint16_t *l_153 = &g_137;
            int32_t *l_162 = &l_83[5][3][4];
            int32_t l_171 = 9L;
            int32_t l_176 = 0xEFD3BFD2L;
            int32_t l_209 = 0x9FEF01F0L;
            int i;
            for (i = 0; i < 3; i++)
                l_113[i] = 0x59B8C56EC938AAB9LL;
            if ((l_110 != l_57[1][1]))
            { /* block id: 21 */
                const uint32_t l_119 = 0xECF97261L;
                for (l_84 = 4; (l_84 >= 0); l_84 -= 1)
                { /* block id: 24 */
                    int32_t **l_111[6][6][7] = {{{&l_109,(void*)0,&l_109,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{(void*)0,(void*)0,&l_109,&l_109,&l_109,&l_109,(void*)0},{(void*)0,&l_109,&l_109,&l_109,(void*)0,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,(void*)0,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109}},{{&l_109,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_109,&l_109,&l_109,&l_109,(void*)0,&l_109,(void*)0},{&l_109,(void*)0,&l_109,(void*)0,&l_109,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,&l_109,(void*)0,&l_109,&l_109,&l_109},{(void*)0,&l_109,(void*)0,&l_109,&l_109,&l_109,(void*)0}},{{(void*)0,&l_109,&l_109,&l_109,&l_109,(void*)0,(void*)0},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,(void*)0,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,(void*)0,&l_109,(void*)0,&l_109,(void*)0},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109}},{{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,(void*)0},{&l_109,&l_109,(void*)0,&l_109,(void*)0,&l_109,&l_109},{(void*)0,&l_109,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,(void*)0,&l_109,&l_109,(void*)0,&l_109},{&l_109,&l_109,(void*)0,&l_109,&l_109,&l_109,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,&l_109,(void*)0,&l_109},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{(void*)0,&l_109,(void*)0,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,(void*)0,&l_109,&l_109,&l_109,(void*)0},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109}},{{(void*)0,(void*)0,(void*)0,&l_109,(void*)0,&l_109,(void*)0},{&l_109,&l_109,&l_109,&l_109,(void*)0,&l_109,&l_109},{&l_109,&l_109,(void*)0,(void*)0,&l_109,&l_109,&l_109},{&l_109,&l_109,&l_109,&l_109,&l_109,&l_109,&l_109},{(void*)0,&l_109,(void*)0,&l_109,&l_109,&l_109,&l_109},{&l_109,&l_109,(void*)0,&l_109,&l_109,&l_109,(void*)0}}};
                    int16_t l_138 = 0x2826L;
                    int i, j, k;
                    g_112[1] = &l_83[5][3][4];
                    if (l_113[2])
                    { /* block id: 26 */
                        uint8_t *l_122 = (void*)0;
                        uint8_t *l_123 = &g_106;
                        uint16_t *l_136 = &g_137;
                        g_112[5] = ((safe_mul_func_uint32_t_u_u((((~((++(**l_99)) >= ((l_119 | l_119) == ((((((safe_rshift_func_uint8_t_u_u(((*l_123) = 247UL), 3)) >= (safe_add_func_int32_t_s_s((safe_mul_func_uint8_t_u_u((((safe_mul_func_int64_t_s_s(((safe_mul_func_int16_t_s_s(g_103, (0L || ((safe_mul_func_int8_t_s_s((safe_lshift_func_int32_t_s_u(((((*l_136) ^= (4294967295UL < 0xD89ECE45L)) && g_103) , 0xF82621F0L), g_58)), g_56[2])) , 0xD4CD45573AC2B988LL)))) | l_138), g_58)) || l_119) ^ 0xC45EL), l_119)), 8L))) <= g_103) <= g_58) & 0x9048L) == 1L)))) || l_113[2]) , l_119), 4294967288UL)) , &g_103);
                        return g_103;
                    }
                    else
                    { /* block id: 32 */
                        return g_82;
                    }
                }
            }
            else
            { /* block id: 36 */
                union U3 *l_141 = (void*)0;
                l_141 = l_139[0];
            }
            for (g_103 = 0; (g_103 <= 4); g_103 += 1)
            { /* block id: 41 */
                uint64_t l_142[7][3] = {{18446744073709551608UL,0x0E7FB8437FCE8780LL,18446744073709551613UL},{0UL,0x701CCAA109753663LL,0x3D7F4DA6B924B8A1LL},{18446744073709551608UL,18446744073709551608UL,0x3D7F4DA6B924B8A1LL},{0x701CCAA109753663LL,0UL,18446744073709551613UL},{0x0E7FB8437FCE8780LL,18446744073709551608UL,0x0E7FB8437FCE8780LL},{0x0E7FB8437FCE8780LL,0x701CCAA109753663LL,18446744073709551608UL},{0x701CCAA109753663LL,0x0E7FB8437FCE8780LL,0x0E7FB8437FCE8780LL}};
                int32_t *l_143 = &l_83[5][3][4];
                uint16_t *l_155[8] = {&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137};
                int32_t l_165 = (-1L);
                int32_t l_170 = (-1L);
                int32_t l_172 = (-7L);
                int32_t l_173 = 0x08B9188FL;
                int32_t l_174 = 0xFB4F793AL;
                int32_t l_175 = 0xAD7C1073L;
                int32_t l_178[2][5][8] = {{{0x325BED0AL,0xEB74D902L,0x325BED0AL,0L,0xEB74D902L,0xD22E32B8L,0xD22E32B8L,0xEB74D902L},{0xEB74D902L,0xD22E32B8L,0xD22E32B8L,0xEB74D902L,0L,0x325BED0AL,0xEB74D902L,0x325BED0AL},{0xEB74D902L,0x1841307EL,(-7L),0x1841307EL,0xEB74D902L,(-7L),0x3EB68F5BL,0x3EB68F5BL},{0x325BED0AL,0x1841307EL,0L,0L,0x1841307EL,0x325BED0AL,0xD22E32B8L,0x1841307EL},{0x3EB68F5BL,0xD22E32B8L,0L,0x3EB68F5BL,0L,0xD22E32B8L,0x3EB68F5BL,0x325BED0AL}},{{0L,0xD22E32B8L,0x3EB68F5BL,0x325BED0AL,0x325BED0AL,0x3EB68F5BL,0xD22E32B8L,0L},{(-10L),0x325BED0AL,(-7L),0x1C6C081EL,0x325BED0AL,0x1C6C081EL,(-7L),0x325BED0AL},{0L,(-7L),(-10L),0L,0x1C6C081EL,0x1C6C081EL,0L,(-10L)},{0x325BED0AL,0x325BED0AL,0x3EB68F5BL,0xD22E32B8L,0L,0x3EB68F5BL,0L,0xD22E32B8L},{(-10L),0xD22E32B8L,(-10L),0x1C6C081EL,0xD22E32B8L,(-7L),(-7L),0xD22E32B8L}}};
                int i, j, k;
                (*l_143) = l_142[0][1];
                for (g_140.f1 = 0; (g_140.f1 <= 4); g_140.f1 += 1)
                { /* block id: 45 */
                    uint64_t *l_144[4][10][6] = {{{&l_142[0][1],&l_142[5][0],&g_55,&g_55,&l_142[0][1],&l_142[0][1]},{&l_142[1][0],&l_142[0][1],&l_142[0][1],&g_55,&g_55,&l_142[0][1]},{&g_55,&g_55,&g_55,&l_142[0][1],&l_142[0][2],&l_142[5][1]},{(void*)0,&g_55,(void*)0,&g_55,&l_142[1][1],&g_55},{&l_142[0][1],(void*)0,(void*)0,&l_142[6][0],&g_55,&l_142[5][1]},{&g_55,&l_142[6][0],&g_55,&g_55,&g_55,&l_142[0][1]},{&g_55,&g_55,&l_142[0][1],&l_142[3][2],&l_142[3][1],&l_142[0][1]},{&l_142[0][1],&l_142[0][1],&g_55,&g_55,&g_55,&l_142[3][1]},{&g_55,&g_55,&l_142[0][1],&l_142[0][1],&l_142[2][0],(void*)0},{&l_142[3][1],&l_142[1][1],&g_55,&l_142[0][1],&l_142[4][1],&l_142[4][2]}},{{&l_142[0][1],(void*)0,&g_55,(void*)0,&g_55,&g_55},{&l_142[0][1],(void*)0,&l_142[6][2],&l_142[1][0],&l_142[0][1],&g_55},{&l_142[5][0],&g_55,&l_142[1][1],&l_142[0][1],(void*)0,&g_55},{&g_55,&l_142[5][2],&l_142[0][1],(void*)0,&g_55,&l_142[1][1]},{&l_142[0][1],&g_55,&l_142[0][1],&l_142[4][1],&l_142[0][1],&l_142[4][1]},{&g_55,&l_142[0][1],&g_55,&l_142[2][2],&l_142[6][1],&l_142[5][0]},{(void*)0,&g_55,&l_142[0][1],&l_142[4][2],&l_142[0][1],&l_142[6][0]},{&g_55,&g_55,&l_142[1][0],&l_142[4][2],&l_142[0][2],&l_142[2][2]},{(void*)0,(void*)0,&l_142[6][0],&l_142[2][2],&l_142[1][1],&l_142[3][2]},{&g_55,&l_142[0][1],&l_142[5][1],&l_142[4][1],(void*)0,&l_142[6][0]}},{{&l_142[0][1],&l_142[0][2],&g_55,(void*)0,&g_55,&g_55},{&g_55,&l_142[0][1],&l_142[3][2],&l_142[0][1],&g_55,&l_142[1][1]},{&l_142[5][0],&l_142[1][0],&g_55,&l_142[1][0],&g_55,&g_55},{&l_142[0][1],&l_142[6][0],&l_142[0][2],(void*)0,&g_55,&l_142[2][0]},{&l_142[0][1],(void*)0,&g_55,&l_142[0][1],&g_55,(void*)0},{&l_142[3][1],&l_142[6][1],&l_142[0][1],&l_142[3][1],&g_55,&l_142[0][1]},{&g_55,&g_55,&g_55,&l_142[6][0],&l_142[3][1],&l_142[0][1]},{&g_55,&l_142[0][1],&g_55,&l_142[1][1],&l_142[1][0],&l_142[1][0]},{&l_142[0][1],(void*)0,(void*)0,&l_142[0][1],&l_142[1][0],&l_142[0][1]},{&l_142[4][2],&g_55,&l_142[6][0],&l_142[0][1],&l_142[0][1],&g_55}},{{&l_142[0][2],&l_142[6][0],&g_55,&g_55,&l_142[0][1],&l_142[1][1]},{&l_142[0][1],&g_55,(void*)0,(void*)0,&l_142[1][0],&l_142[5][1]},{&l_142[2][2],(void*)0,&g_55,&l_142[4][1],&l_142[1][0],&l_142[6][2]},{&l_142[6][1],&l_142[0][1],&g_55,&l_142[0][0],&l_142[3][1],&l_142[6][0]},{&g_55,&g_55,&l_142[0][2],&l_142[0][1],&g_55,&l_142[3][1]},{&l_142[0][1],&l_142[6][1],&g_55,&l_142[5][0],&l_142[6][0],&g_55},{&l_142[3][1],&l_142[5][1],&g_55,&g_55,&l_142[0][2],&l_142[5][0]},{&l_142[1][1],&l_142[5][2],&l_142[0][1],&g_55,&l_142[5][1],&l_142[0][1]},{&l_142[0][1],&l_142[0][1],(void*)0,(void*)0,&l_142[0][1],&l_142[0][1]},{&g_55,(void*)0,&l_142[5][1],&g_55,&g_55,&g_55}}};
                    int8_t l_148 = 0xDEL;
                    uint16_t *l_150 = &g_137;
                    uint16_t *l_152[10] = {&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137};
                    int32_t l_179 = (-8L);
                    int32_t l_182 = 0x3133B8B3L;
                    int32_t l_183 = 0x94038E51L;
                    uint64_t l_184[8][7] = {{0UL,0UL,0UL,18446744073709551609UL,0x54238F0D61F2928FLL,18446744073709551609UL,0UL},{18446744073709551612UL,1UL,0xF839FAA199BFBAFDLL,18446744073709551612UL,18446744073709551612UL,0xF839FAA199BFBAFDLL,1UL},{0UL,18446744073709551609UL,5UL,0UL,5UL,18446744073709551609UL,0UL},{0x5DF4781F1820D9AELL,18446744073709551612UL,0xB750C1D09C81770CLL,0xB750C1D09C81770CLL,18446744073709551612UL,0x5DF4781F1820D9AELL,0xB750C1D09C81770CLL},{0x54238F0D61F2928FLL,0UL,0UL,0UL,0x54238F0D61F2928FLL,0xA7E3DBFE5E5E1387LL,0x54238F0D61F2928FLL},{18446744073709551612UL,0xB750C1D09C81770CLL,0xB750C1D09C81770CLL,18446744073709551612UL,0x5DF4781F1820D9AELL,0xB750C1D09C81770CLL,1UL},{5UL,0UL,5UL,18446744073709551609UL,0UL,18446744073709551609UL,5UL},{18446744073709551612UL,18446744073709551612UL,0xF839FAA199BFBAFDLL,1UL,18446744073709551612UL,3UL,1UL}};
                    int32_t **l_188 = (void*)0;
                    int8_t l_218 = 0x54L;
                    int i, j, k;
                    for (g_58 = 4; (g_58 >= 0); g_58 -= 1)
                    { /* block id: 48 */
                        uint64_t l_147 = 0x823590D9D044D412LL;
                        uint16_t **l_151 = &l_150;
                        uint16_t **l_154[3][5][3] = {{{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153}},{{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153},{&l_153,&l_153,&l_153}},{{&l_153,&l_153,&l_153},{&l_153,&l_153,(void*)0},{&l_153,(void*)0,(void*)0},{&l_153,(void*)0,(void*)0},{&l_153,(void*)0,(void*)0}}};
                        int32_t **l_163 = (void*)0;
                        int32_t l_166[3][9] = {{(-1L),0xDD24A243L,0x6AE4A769L,0x6AE4A769L,0xDD24A243L,(-1L),(-10L),9L,0x6F5A32C3L},{0x3CAD433CL,0xC4722C89L,(-1L),(-1L),(-1L),(-1L),0xC4722C89L,0x3CAD433CL,0xDD24A243L},{0x6F5A32C3L,0x6AE4A769L,0x3CAD433CL,(-10L),0xC4722C89L,0xC4722C89L,(-10L),0x3CAD433CL,0x6AE4A769L}};
                        int32_t *l_167 = (void*)0;
                        int32_t *l_168 = &l_65;
                        int32_t *l_169[8];
                        int32_t ***l_187[3];
                        int i, j, k;
                        for (i = 0; i < 8; i++)
                            l_169[i] = &l_166[1][8];
                        for (i = 0; i < 3; i++)
                            l_187[i] = &l_163;
                        (*l_143) = ((l_144[1][3][5] != ((((safe_rshift_func_int64_t_s_u(l_147, l_148)) | (~((l_152[4] = ((*l_151) = l_150)) == (l_155[4] = l_153)))) | ((safe_add_func_int8_t_s_s((l_113[2] & ((*p_53) ^ (safe_div_func_int8_t_s_s((((safe_lshift_func_uint8_t_u_u((4294967295UL > l_63), g_140.f1)) && 0x7754CE76L) , 0xB8L), g_137)))), (*l_143))) > 0x96L)) , (void*)0)) , (*l_143));
                        l_164 = l_162;
                        --l_184[0][4];
                        l_188 = &l_109;
                    }
                    if ((*l_143))
                        break;
                    if ((safe_sub_func_uint32_t_u_u(((void*)0 == (*l_99)), ((l_191 , (~(((safe_rshift_func_uint16_t_u_u(((g_58 = g_56[4]) && ((*l_164) , ((safe_sub_func_int32_t_s_s(((*l_162) = ((g_103 & 1L) && (g_58 ^ (safe_sub_func_uint8_t_u_u((g_103 <= 249UL), g_137))))), 1UL)) == l_199))), g_82)) , &l_176) == &l_176))) == 0x070E6CD8E07C21F1LL))))
                    { /* block id: 60 */
                        int32_t l_219 = 1L;
                        int32_t *l_221[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        if ((*l_162))
                            break;
                        l_172 |= ((*l_162) = (safe_sub_func_int16_t_s_s(((void*)0 == &g_55), (safe_mul_func_uint32_t_u_u(((*p_53) == (g_220 &= (safe_lshift_func_int8_t_s_u(((safe_rshift_func_uint8_t_u_s((+((0xA2A9L != l_209) <= ((safe_sub_func_int16_t_s_s(((void*)0 != g_212), ((*l_162) , ((safe_mod_func_uint8_t_u_u(((safe_add_func_int16_t_s_s((*l_143), g_56[0])) | g_56[2]), (*l_164))) <= (*l_143))))) , g_58))), l_218)) >= l_219), g_140.f1)))), (*l_143))))));
                    }
                    else
                    { /* block id: 65 */
                        union U3 **l_224 = (void*)0;
                        union U3 **l_225 = &l_222;
                        int32_t l_226 = (-5L);
                        int32_t l_244 = 1L;
                        int32_t *l_245 = &l_176;
                        (*l_162) ^= (((*l_225) = l_222) == g_212);
                        (*l_162) |= l_226;
                        (*l_245) |= (safe_mul_func_uint8_t_u_u((0x8659274A4447EB15LL != (safe_add_func_uint32_t_u_u(l_226, (l_244 ^= (l_243 &= ((((safe_div_func_int64_t_s_s((safe_sub_func_int64_t_s_s(((0x1B8BEBA228102D8ELL <= (*p_53)) < (safe_mul_func_int32_t_s_s(3L, (*l_162)))), (safe_sub_func_int8_t_s_s(((l_139[6] != g_212) ^ (safe_rshift_func_int16_t_s_u(((safe_lshift_func_int8_t_s_u(((l_226 | l_226) > g_220), 4)) , g_82), (*l_164)))), (*l_164))))), l_181)) ^ (*l_164)) >= l_226) || 0x3DL)))))), g_140.f1));
                    }
                }
            }
        }
        for (l_243 = 0; (l_243 <= 4); l_243 += 1)
        { /* block id: 78 */
            int64_t *l_249 = (void*)0;
            int64_t *l_250 = &g_56[l_243];
            uint16_t *l_254 = (void*)0;
            uint16_t *l_255 = &g_137;
            int32_t l_256[1];
            int32_t l_264 = 0x53CD6AE3L;
            int32_t **l_265 = (void*)0;
            int32_t **l_266 = &l_164;
            int32_t *l_267 = (void*)0;
            int32_t *l_268 = (void*)0;
            int32_t *l_269 = (void*)0;
            int32_t *l_270 = &l_256[0];
            int32_t *l_271 = &l_180;
            int32_t *l_272 = (void*)0;
            int32_t *l_273 = &l_264;
            int32_t *l_274 = &l_181;
            int32_t *l_275 = (void*)0;
            int32_t *l_276 = &l_64;
            int32_t *l_277 = &g_103;
            int32_t *l_278 = &g_103;
            int32_t *l_279 = &l_181;
            int32_t *l_280[8] = {&l_83[5][3][4],&l_83[5][3][4],&l_83[5][3][4],&l_83[5][3][4],&l_83[5][3][4],&l_83[5][3][4],&l_83[5][3][4],&l_83[5][3][4]};
            int i;
            for (i = 0; i < 1; i++)
                l_256[i] = (-1L);
            l_264 ^= (l_181 >= ((((safe_sub_func_int64_t_s_s((((g_56[l_243] &= (*l_164)) && (((*l_255) = (safe_unary_minus_func_uint32_t_u(((((*l_250) &= 0L) , ((*l_164) = (++l_251[0][0][3]))) <= 0UL)))) && 0x2C0FL)) | l_256[0]), (safe_sub_func_int32_t_s_s((-10L), ((safe_mod_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u(g_106, 4L)), 0x2DC4E463L)) <= l_256[0]))))) <= l_256[0]) | l_263) , g_56[l_243]));
            (*l_266) = &l_83[5][3][4];
            --l_288;
        }
    }
    return l_291;
}


/* ------------------------------------------ */
/* 
 * reads : g_106
 * writes: g_106
 */
static int16_t  func_68(const uint16_t  p_69)
{ /* block id: 14 */
    int32_t *l_102 = &g_103;
    int32_t *l_104 = &g_103;
    int32_t *l_105[7][7][5] = {{{&g_103,(void*)0,(void*)0,&g_103,&g_103},{(void*)0,&g_103,&g_103,(void*)0,(void*)0},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,(void*)0,(void*)0,&g_103,(void*)0},{(void*)0,(void*)0,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,(void*)0,&g_103,&g_103}},{{(void*)0,(void*)0,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,(void*)0,(void*)0,&g_103,&g_103},{(void*)0,&g_103,&g_103,(void*)0,(void*)0},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,(void*)0,(void*)0,&g_103,(void*)0},{(void*)0,(void*)0,&g_103,(void*)0,&g_103}},{{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,(void*)0,&g_103,&g_103},{(void*)0,(void*)0,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,(void*)0,(void*)0,&g_103,&g_103},{(void*)0,&g_103,&g_103,(void*)0,(void*)0},{&g_103,&g_103,&g_103,&g_103,&g_103}},{{&g_103,(void*)0,(void*)0,&g_103,(void*)0},{(void*)0,(void*)0,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,(void*)0,&g_103,&g_103},{(void*)0,(void*)0,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,(void*)0,&g_103,&g_103,&g_103}},{{&g_103,(void*)0,&g_103,&g_103,&g_103},{(void*)0,&g_103,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,(void*)0,&g_103,(void*)0,(void*)0},{&g_103,(void*)0,&g_103,&g_103,(void*)0}},{{&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,(void*)0,&g_103,&g_103,&g_103},{&g_103,(void*)0,&g_103,&g_103,&g_103},{(void*)0,&g_103,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103}},{{&g_103,(void*)0,&g_103,(void*)0,(void*)0},{&g_103,(void*)0,&g_103,&g_103,(void*)0},{&g_103,&g_103,&g_103,&g_103,&g_103},{(void*)0,(void*)0,&g_103,&g_103,&g_103},{&g_103,(void*)0,&g_103,&g_103,&g_103},{(void*)0,&g_103,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103}}};
    int i, j, k;
    g_106++;
    return p_69;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_56[i], "g_56[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_213.f0, "g_213.f0", print_hash_value);
    transparent_crc(g_220, "g_220", print_hash_value);
    transparent_crc(g_281, "g_281", print_hash_value);
    transparent_crc(g_313.f0, "g_313.f0", print_hash_value);
    transparent_crc(g_313.f1, "g_313.f1", print_hash_value);
    transparent_crc(g_313.f2, "g_313.f2", print_hash_value);
    transparent_crc(g_313.f3, "g_313.f3", print_hash_value);
    transparent_crc(g_374.f0, "g_374.f0", print_hash_value);
    transparent_crc(g_559, "g_559", print_hash_value);
    transparent_crc(g_619.f0, "g_619.f0", print_hash_value);
    transparent_crc(g_619.f1, "g_619.f1", print_hash_value);
    transparent_crc(g_619.f2, "g_619.f2", print_hash_value);
    transparent_crc(g_619.f3, "g_619.f3", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_630[i].f0, "g_630[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_648.f0, "g_648.f0", print_hash_value);
    transparent_crc(g_651, "g_651", print_hash_value);
    transparent_crc(g_701.f0, "g_701.f0", print_hash_value);
    transparent_crc(g_740.f0, "g_740.f0", print_hash_value);
    transparent_crc(g_774, "g_774", print_hash_value);
    transparent_crc(g_776.f0, "g_776.f0", print_hash_value);
    transparent_crc(g_789.f0, "g_789.f0", print_hash_value);
    transparent_crc(g_789.f1, "g_789.f1", print_hash_value);
    transparent_crc(g_789.f2, "g_789.f2", print_hash_value);
    transparent_crc(g_789.f3, "g_789.f3", print_hash_value);
    transparent_crc(g_799.f0, "g_799.f0", print_hash_value);
    transparent_crc(g_853.f0, "g_853.f0", print_hash_value);
    transparent_crc(g_853.f1, "g_853.f1", print_hash_value);
    transparent_crc(g_853.f2, "g_853.f2", print_hash_value);
    transparent_crc(g_853.f3, "g_853.f3", print_hash_value);
    transparent_crc(g_866.f0, "g_866.f0", print_hash_value);
    transparent_crc(g_917.f0, "g_917.f0", print_hash_value);
    transparent_crc(g_917.f1, "g_917.f1", print_hash_value);
    transparent_crc(g_917.f2, "g_917.f2", print_hash_value);
    transparent_crc(g_917.f3, "g_917.f3", print_hash_value);
    transparent_crc(g_1043, "g_1043", print_hash_value);
    transparent_crc(g_1048, "g_1048", print_hash_value);
    transparent_crc(g_1086.f0, "g_1086.f0", print_hash_value);
    transparent_crc(g_1108.f0, "g_1108.f0", print_hash_value);
    transparent_crc(g_1117.f0, "g_1117.f0", print_hash_value);
    transparent_crc(g_1195.f0, "g_1195.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1217[i][j].f0, "g_1217[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1248.f0, "g_1248.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_1253[i][j][k], "g_1253[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1261[i][j].f0, "g_1261[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1326, "g_1326", print_hash_value);
    transparent_crc(g_1327, "g_1327", print_hash_value);
    transparent_crc(g_1341.f0, "g_1341.f0", print_hash_value);
    transparent_crc(g_1342.f0, "g_1342.f0", print_hash_value);
    transparent_crc(g_1400.f0, "g_1400.f0", print_hash_value);
    transparent_crc(g_1401, "g_1401", print_hash_value);
    transparent_crc(g_1425.f0, "g_1425.f0", print_hash_value);
    transparent_crc(g_1429, "g_1429", print_hash_value);
    transparent_crc(g_1456.f0, "g_1456.f0", print_hash_value);
    transparent_crc(g_1511.f0, "g_1511.f0", print_hash_value);
    transparent_crc(g_1538, "g_1538", print_hash_value);
    transparent_crc(g_1560.f0, "g_1560.f0", print_hash_value);
    transparent_crc(g_1566.f0, "g_1566.f0", print_hash_value);
    transparent_crc(g_1580, "g_1580", print_hash_value);
    transparent_crc(g_1652.f0, "g_1652.f0", print_hash_value);
    transparent_crc(g_1652.f1, "g_1652.f1", print_hash_value);
    transparent_crc(g_1652.f2, "g_1652.f2", print_hash_value);
    transparent_crc(g_1652.f3, "g_1652.f3", print_hash_value);
    transparent_crc(g_1687, "g_1687", print_hash_value);
    transparent_crc(g_1690.f0, "g_1690.f0", print_hash_value);
    transparent_crc(g_1690.f1, "g_1690.f1", print_hash_value);
    transparent_crc(g_1690.f2, "g_1690.f2", print_hash_value);
    transparent_crc(g_1690.f3, "g_1690.f3", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1798[i].f0, "g_1798[i].f0", print_hash_value);
        transparent_crc(g_1798[i].f1, "g_1798[i].f1", print_hash_value);
        transparent_crc(g_1798[i].f2, "g_1798[i].f2", print_hash_value);
        transparent_crc(g_1798[i].f3, "g_1798[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1811.f0, "g_1811.f0", print_hash_value);
    transparent_crc(g_1811.f1, "g_1811.f1", print_hash_value);
    transparent_crc(g_1811.f2, "g_1811.f2", print_hash_value);
    transparent_crc(g_1811.f3, "g_1811.f3", print_hash_value);
    transparent_crc(g_1864.f0, "g_1864.f0", print_hash_value);
    transparent_crc(g_1879.f0, "g_1879.f0", print_hash_value);
    transparent_crc(g_1879.f1, "g_1879.f1", print_hash_value);
    transparent_crc(g_1879.f2, "g_1879.f2", print_hash_value);
    transparent_crc(g_1879.f3, "g_1879.f3", print_hash_value);
    transparent_crc(g_1969.f0, "g_1969.f0", print_hash_value);
    transparent_crc(g_1994, "g_1994", print_hash_value);
    transparent_crc(g_2032.f0, "g_2032.f0", print_hash_value);
    transparent_crc(g_2211, "g_2211", print_hash_value);
    transparent_crc(g_2244, "g_2244", print_hash_value);
    transparent_crc(g_2301.f0, "g_2301.f0", print_hash_value);
    transparent_crc(g_2322.f0, "g_2322.f0", print_hash_value);
    transparent_crc(g_2327.f0, "g_2327.f0", print_hash_value);
    transparent_crc(g_2327.f1, "g_2327.f1", print_hash_value);
    transparent_crc(g_2327.f2, "g_2327.f2", print_hash_value);
    transparent_crc(g_2327.f3, "g_2327.f3", print_hash_value);
    transparent_crc(g_2379.f0, "g_2379.f0", print_hash_value);
    transparent_crc(g_2401.f0, "g_2401.f0", print_hash_value);
    transparent_crc(g_2472, "g_2472", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_2479[i][j].f0, "g_2479[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2599.f0, "g_2599.f0", print_hash_value);
    transparent_crc(g_2599.f1, "g_2599.f1", print_hash_value);
    transparent_crc(g_2599.f2, "g_2599.f2", print_hash_value);
    transparent_crc(g_2599.f3, "g_2599.f3", print_hash_value);
    transparent_crc(g_2629.f0, "g_2629.f0", print_hash_value);
    transparent_crc(g_2653.f0, "g_2653.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_2717[i][j][k].f0, "g_2717[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2769, "g_2769", print_hash_value);
    transparent_crc(g_2775.f0, "g_2775.f0", print_hash_value);
    transparent_crc(g_2797.f0, "g_2797.f0", print_hash_value);
    transparent_crc(g_2885.f0, "g_2885.f0", print_hash_value);
    transparent_crc(g_2885.f1, "g_2885.f1", print_hash_value);
    transparent_crc(g_2885.f2, "g_2885.f2", print_hash_value);
    transparent_crc(g_2885.f3, "g_2885.f3", print_hash_value);
    transparent_crc(g_2912.f0, "g_2912.f0", print_hash_value);
    transparent_crc(g_3033, "g_3033", print_hash_value);
    transparent_crc(g_3162.f0, "g_3162.f0", print_hash_value);
    transparent_crc(g_3162.f1, "g_3162.f1", print_hash_value);
    transparent_crc(g_3162.f2, "g_3162.f2", print_hash_value);
    transparent_crc(g_3162.f3, "g_3162.f3", print_hash_value);
    transparent_crc(g_3199.f0, "g_3199.f0", print_hash_value);
    transparent_crc(g_3207, "g_3207", print_hash_value);
    transparent_crc(g_3209.f0, "g_3209.f0", print_hash_value);
    transparent_crc(g_3220.f0, "g_3220.f0", print_hash_value);
    transparent_crc(g_3260.f0, "g_3260.f0", print_hash_value);
    transparent_crc(g_3290.f0, "g_3290.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_3312[i][j][k].f0, "g_3312[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_3318[i].f0, "g_3318[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3326[i], "g_3326[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_3406[i].f0, "g_3406[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3408, "g_3408", print_hash_value);
    transparent_crc(g_3494.f0, "g_3494.f0", print_hash_value);
    transparent_crc(g_3546.f0, "g_3546.f0", print_hash_value);
    transparent_crc(g_3564.f0, "g_3564.f0", print_hash_value);
    transparent_crc(g_3584.f0, "g_3584.f0", print_hash_value);
    transparent_crc(g_3584.f1, "g_3584.f1", print_hash_value);
    transparent_crc(g_3584.f2, "g_3584.f2", print_hash_value);
    transparent_crc(g_3584.f3, "g_3584.f3", print_hash_value);
    transparent_crc(g_3667, "g_3667", print_hash_value);
    transparent_crc(g_3674, "g_3674", print_hash_value);
    transparent_crc(g_3692.f0, "g_3692.f0", print_hash_value);
    transparent_crc(g_3692.f1, "g_3692.f1", print_hash_value);
    transparent_crc(g_3692.f2, "g_3692.f2", print_hash_value);
    transparent_crc(g_3692.f3, "g_3692.f3", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_3697[i][j].f0, "g_3697[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3747.f0, "g_3747.f0", print_hash_value);
    transparent_crc(g_3787, "g_3787", print_hash_value);
    transparent_crc(g_3807.f0, "g_3807.f0", print_hash_value);
    transparent_crc(g_3837.f0, "g_3837.f0", print_hash_value);
    transparent_crc(g_3933.f0, "g_3933.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_3970[i].f0, "g_3970[i].f0", print_hash_value);
        transparent_crc(g_3970[i].f1, "g_3970[i].f1", print_hash_value);
        transparent_crc(g_3970[i].f2, "g_3970[i].f2", print_hash_value);
        transparent_crc(g_3970[i].f3, "g_3970[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3974.f0, "g_3974.f0", print_hash_value);
    transparent_crc(g_4008.f0, "g_4008.f0", print_hash_value);
    transparent_crc(g_4133.f0, "g_4133.f0", print_hash_value);
    transparent_crc(g_4142, "g_4142", print_hash_value);
    transparent_crc(g_4145.f0, "g_4145.f0", print_hash_value);
    transparent_crc(g_4184.f0, "g_4184.f0", print_hash_value);
    transparent_crc(g_4244.f0, "g_4244.f0", print_hash_value);
    transparent_crc(g_4244.f1, "g_4244.f1", print_hash_value);
    transparent_crc(g_4244.f2, "g_4244.f2", print_hash_value);
    transparent_crc(g_4244.f3, "g_4244.f3", print_hash_value);
    transparent_crc(g_4265.f0, "g_4265.f0", print_hash_value);
    transparent_crc(g_4282.f0, "g_4282.f0", print_hash_value);
    transparent_crc(g_4290.f0, "g_4290.f0", print_hash_value);
    transparent_crc(g_4290.f1, "g_4290.f1", print_hash_value);
    transparent_crc(g_4290.f2, "g_4290.f2", print_hash_value);
    transparent_crc(g_4290.f3, "g_4290.f3", print_hash_value);
    transparent_crc(g_4297.f0, "g_4297.f0", print_hash_value);
    transparent_crc(g_4364.f0, "g_4364.f0", print_hash_value);
    transparent_crc(g_4394.f0, "g_4394.f0", print_hash_value);
    transparent_crc(g_4428.f0, "g_4428.f0", print_hash_value);
    transparent_crc(g_4437.f0, "g_4437.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_4443[i].f0, "g_4443[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4488.f0, "g_4488.f0", print_hash_value);
    transparent_crc(g_4513.f0, "g_4513.f0", print_hash_value);
    transparent_crc(g_4528, "g_4528", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_4580[i].f0, "g_4580[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_4589[i].f0, "g_4589[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4598, "g_4598", print_hash_value);
    transparent_crc(g_4694, "g_4694", print_hash_value);
    transparent_crc(g_4725.f0, "g_4725.f0", print_hash_value);
    transparent_crc(g_4725.f1, "g_4725.f1", print_hash_value);
    transparent_crc(g_4725.f2, "g_4725.f2", print_hash_value);
    transparent_crc(g_4725.f3, "g_4725.f3", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_4727[i][j].f0, "g_4727[i][j].f0", print_hash_value);
            transparent_crc(g_4727[i][j].f1, "g_4727[i][j].f1", print_hash_value);
            transparent_crc(g_4727[i][j].f2, "g_4727[i][j].f2", print_hash_value);
            transparent_crc(g_4727[i][j].f3, "g_4727[i][j].f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 1348
   depth: 1, occurrence: 15
XXX total union variables: 85

XXX non-zero bitfields defined in structs: 3
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 60
breakdown:
   indirect level: 0, occurrence: 15
   indirect level: 1, occurrence: 16
   indirect level: 2, occurrence: 6
   indirect level: 3, occurrence: 3
   indirect level: 4, occurrence: 7
   indirect level: 5, occurrence: 13
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 50
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 28
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 61

XXX max expression depth: 53
breakdown:
   depth: 1, occurrence: 709
   depth: 2, occurrence: 177
   depth: 3, occurrence: 14
   depth: 4, occurrence: 6
   depth: 5, occurrence: 11
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 3
   depth: 10, occurrence: 2
   depth: 11, occurrence: 2
   depth: 12, occurrence: 4
   depth: 13, occurrence: 3
   depth: 14, occurrence: 5
   depth: 15, occurrence: 6
   depth: 16, occurrence: 3
   depth: 17, occurrence: 11
   depth: 18, occurrence: 6
   depth: 19, occurrence: 6
   depth: 20, occurrence: 16
   depth: 21, occurrence: 12
   depth: 22, occurrence: 9
   depth: 23, occurrence: 10
   depth: 24, occurrence: 3
   depth: 25, occurrence: 4
   depth: 26, occurrence: 11
   depth: 27, occurrence: 6
   depth: 28, occurrence: 3
   depth: 29, occurrence: 4
   depth: 30, occurrence: 6
   depth: 31, occurrence: 3
   depth: 32, occurrence: 3
   depth: 33, occurrence: 2
   depth: 34, occurrence: 5
   depth: 35, occurrence: 4
   depth: 36, occurrence: 2
   depth: 37, occurrence: 2
   depth: 38, occurrence: 3
   depth: 39, occurrence: 3
   depth: 40, occurrence: 1
   depth: 41, occurrence: 1
   depth: 43, occurrence: 1
   depth: 45, occurrence: 1
   depth: 53, occurrence: 1

XXX total number of pointers: 898

XXX times a variable address is taken: 2635
XXX times a pointer is dereferenced on RHS: 370
breakdown:
   depth: 1, occurrence: 270
   depth: 2, occurrence: 67
   depth: 3, occurrence: 33
XXX times a pointer is dereferenced on LHS: 482
breakdown:
   depth: 1, occurrence: 437
   depth: 2, occurrence: 23
   depth: 3, occurrence: 14
   depth: 4, occurrence: 8
XXX times a pointer is compared with null: 81
XXX times a pointer is compared with address of another variable: 13
XXX times a pointer is compared with another pointer: 27
XXX times a pointer is qualified to be dereferenced: 18613

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1904
   level: 2, occurrence: 509
   level: 3, occurrence: 289
   level: 4, occurrence: 317
   level: 5, occurrence: 199
XXX number of pointers point to pointers: 415
XXX number of pointers point to scalars: 410
XXX number of pointers point to structs: 18
XXX percent of pointers has null in alias set: 30.6
XXX average alias set size: 1.55

XXX times a non-volatile is read: 3467
XXX times a non-volatile is write: 1720
XXX times a volatile is read: 205
XXX    times read thru a pointer: 40
XXX times a volatile is write: 25
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1.39e+04
XXX percentage of non-volatile access: 95.8

XXX forward jumps: 1
XXX backward jumps: 4

XXX stmts: 711
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 61
   depth: 2, occurrence: 91
   depth: 3, occurrence: 119
   depth: 4, occurrence: 154
   depth: 5, occurrence: 255

XXX percentage a fresh-made variable is used: 16.9
XXX percentage an existing variable is used: 83.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

