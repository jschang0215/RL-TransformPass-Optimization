/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: deddca6
 * Options:   (none)
 * Seed:      3850334260
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const volatile uint32_t  f0;
   const uint32_t  f1;
   uint32_t  f2;
   int16_t  f3;
   unsigned f4 : 7;
   uint64_t  f5;
   const uint8_t  f6;
   const int32_t  f7;
   int32_t  f8;
};

union U1 {
   uint32_t  f0;
   volatile int16_t  f1;
   int16_t  f2;
   int16_t  f3;
   const volatile uint32_t  f4;
};

union U2 {
   uint32_t  f0;
   volatile uint16_t  f1;
   int32_t  f2;
   int32_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_4 = 0xB844A754L;/* VOLATILE GLOBAL g_4 */
static int16_t g_10[6] = {6L,(-1L),6L,6L,(-1L),6L};
static uint32_t g_41 = 3UL;
static int8_t g_51[5][4][3] = {{{0x20L,0x97L,0x2EL},{(-8L),(-8L),0x0BL},{0x97L,0x20L,0x68L},{0x45L,(-8L),0x45L}},{{0xC1L,0x97L,0xF2L},{3L,0x45L,0x45L},{0xF2L,0xC1L,0x68L},{9L,3L,0x0BL}},{{0xF2L,0xF2L,0x2EL},{3L,9L,1L},{0xC1L,0xF2L,0xC1L},{0x45L,3L,(-8L)}},{{0x97L,0xC1L,0xC1L},{(-8L),9L,0x0BL},{0x68L,0xC1L,0xF2L},{0xEDL,0xEDL,(-8L)}},{{0xC1L,0x68L,0x2EL},{9L,0xEDL,9L},{0x20L,0xC1L,(-1L)},{0x45L,9L,9L}}};
static int32_t g_54 = 0x8FF05C8AL;
static int32_t g_81 = 0x36CCC853L;
static int32_t g_90 = 0xE5FA5B82L;
static int32_t *g_89 = &g_90;
static int16_t g_98 = (-5L);
static uint8_t g_110 = 255UL;
static uint32_t g_117 = 0x40573921L;
static int64_t g_176 = 2L;
static uint64_t g_184 = 0x460E39E102BB1848LL;
static uint32_t g_211 = 18446744073709551615UL;
static uint16_t g_244[9][8] = {{1UL,1UL,0x33CCL,0UL,0x33CCL,1UL,1UL,0UL},{0x33CCL,1UL,1UL,0UL,65535UL,65535UL,0UL,1UL},{0x4189L,0x4189L,1UL,0UL,65535UL,0UL,1UL,0UL},{0x33CCL,1UL,0UL,1UL,0x33CCL,0x4E2FL,0x4189L,0UL},{1UL,65535UL,1UL,0UL,0UL,1UL,65535UL,1UL},{1UL,0x4E2FL,1UL,0UL,0x4189L,0x33CCL,0x4189L,0UL},{0UL,0xB7CAL,0UL,0UL,0UL,0x33CCL,1UL,1UL},{1UL,0x4E2FL,1UL,1UL,0x4E2FL,1UL,0UL,0x4189L},{1UL,65535UL,1UL,0x4E2FL,0UL,0x4E2FL,1UL,65535UL}};
static int64_t *g_249 = &g_176;
static int64_t **g_248 = &g_249;
static int32_t g_336 = (-9L);
static uint32_t *g_351 = (void*)0;
static uint32_t * volatile *g_350 = &g_351;
static int64_t * const  volatile *g_402 = (void*)0;
static int64_t * const  volatile * const *g_401 = &g_402;
static int64_t * const  volatile * const * const  volatile *g_400[10] = {&g_401,&g_401,&g_401,&g_401,&g_401,&g_401,&g_401,&g_401,&g_401,&g_401};
static union U2 g_406[9] = {{0x7D4696B2L},{0x7D4696B2L},{0x7D4696B2L},{0x7D4696B2L},{0x7D4696B2L},{0x7D4696B2L},{0x7D4696B2L},{0x7D4696B2L},{0x7D4696B2L}};
static int32_t ** volatile *g_420 = (void*)0;
static uint32_t g_421 = 1UL;
static union U2 g_458 = {0x86CFF65FL};/* VOLATILE GLOBAL g_458 */
static union U2 *g_457 = &g_458;
static uint16_t g_550 = 0x6D86L;
static uint64_t g_573 = 0x26746A294085524DLL;
static union U1 g_589 = {0x6C2B119FL};/* VOLATILE GLOBAL g_589 */
static union U1 g_602 = {1UL};/* VOLATILE GLOBAL g_602 */
static union U1 g_607 = {0UL};/* VOLATILE GLOBAL g_607 */
static const int32_t *g_633 = &g_406[4].f3;
static union U1 g_668 = {0UL};/* VOLATILE GLOBAL g_668 */
static union U1 *g_667 = &g_668;
static int32_t g_679 = (-1L);
static union U2 g_721 = {0xFD3616AAL};/* VOLATILE GLOBAL g_721 */
static union U2 g_723 = {18446744073709551610UL};/* VOLATILE GLOBAL g_723 */
static int64_t g_744 = 0xA6BCD6A68277E5F1LL;
static int64_t g_748 = 0xA3F1592AE5972768LL;
static int8_t g_749 = 8L;
static uint8_t g_750[4] = {4UL,4UL,4UL,4UL};
static int8_t *g_768 = &g_51[0][3][2];
static int8_t *g_771 = &g_51[4][2][2];
static union U2 g_792 = {1UL};/* VOLATILE GLOBAL g_792 */
static uint64_t g_849[7][5] = {{0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL},{0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL},{0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL},{0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL},{0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL},{0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL,0xF1F4670E7DD362DFLL},{0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL,0x553DBC876727ADD6LL,0x23CF179122E78E29LL}};
static int32_t g_900 = 0L;
static uint16_t g_901 = 0xA492L;
static uint64_t *g_914 = &g_573;
static int64_t ***g_929 = &g_248;
static int64_t ****g_928 = &g_929;
static int64_t *****g_927 = &g_928;
static union U2 g_945 = {18446744073709551607UL};/* VOLATILE GLOBAL g_945 */
static union U2 g_946[6][6] = {{{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L}},{{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L}},{{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L}},{{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L}},{{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L}},{{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L},{0xE85F33B6L}}};
static union U2 g_947 = {0UL};/* VOLATILE GLOBAL g_947 */
static union U2 g_948 = {0UL};/* VOLATILE GLOBAL g_948 */
static union U2 g_949[10] = {{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L},{0xB4ACA3E0L}};
static union U2 g_950 = {0x7F2B74A2L};/* VOLATILE GLOBAL g_950 */
static union U2 g_951 = {18446744073709551606UL};/* VOLATILE GLOBAL g_951 */
static union U2 g_952 = {0UL};/* VOLATILE GLOBAL g_952 */
static union U2 g_953 = {1UL};/* VOLATILE GLOBAL g_953 */
static union U2 g_954 = {0x1AB3A7C1L};/* VOLATILE GLOBAL g_954 */
static union U2 g_955[8][5][6] = {{{{0x8B1848CBL},{18446744073709551606UL},{9UL},{0xB2A3D5EBL},{9UL},{18446744073709551606UL}},{{18446744073709551608UL},{0x8B1848CBL},{1UL},{0xB18C28E5L},{0x027F49AAL},{1UL}},{{1UL},{4UL},{0xDE40384BL},{0xA3DF6D8EL},{0x47206F6DL},{0xEAFDBAA0L}},{{0x736783D7L},{4UL},{0x020D6521L},{18446744073709551608UL},{0x027F49AAL},{18446744073709551613UL}},{{0x649E683EL},{0x8B1848CBL},{1UL},{8UL},{9UL},{0x105419D4L}}},{{{18446744073709551615UL},{18446744073709551606UL},{0x9F90B98DL},{0x67B8023EL},{1UL},{0x0935EAD8L}},{{18446744073709551606UL},{3UL},{0UL},{18446744073709551609UL},{0UL},{4UL}},{{0x020D6521L},{4UL},{0x2F4C90BAL},{0x105419D4L},{0x1D17CA8DL},{0xADE3933EL}},{{18446744073709551608UL},{0x04F6356CL},{18446744073709551615UL},{0UL},{18446744073709551609UL},{1UL}},{{0x2F4C90BAL},{0x85B50152L},{0xF50D7FD3L},{0UL},{0x59D61266L},{0xEAFDBAA0L}}},{{{0x2338958DL},{0xFB11DAD7L},{0x736783D7L},{18446744073709551615UL},{18446744073709551606UL},{0UL}},{{8UL},{0x736783D7L},{0xBBAE28F4L},{0xFFA28598L},{9UL},{0xA3DF6D8EL}},{{0UL},{8UL},{18446744073709551613UL},{0xADE3933EL},{3UL},{1UL}},{{5UL},{0x105419D4L},{18446744073709551609UL},{18446744073709551609UL},{0x105419D4L},{5UL}},{{0x736783D7L},{0xADE3933EL},{1UL},{0x27422A64L},{0xFB11DAD7L},{0x649E683EL}}},{{{9UL},{0x8B1848CBL},{18446744073709551615UL},{0x9F90B98DL},{18446744073709551613UL},{0x061910BFL}},{{9UL},{0x8B951A19L},{0x9F90B98DL},{0x27422A64L},{0x2B395181L},{1UL}},{{0x736783D7L},{0xFB11DAD7L},{0x2338958DL},{18446744073709551609UL},{18446744073709551615UL},{18446744073709551606UL}},{{5UL},{0x8A4CF7A6L},{0x8B1848CBL},{0xADE3933EL},{0x1D17CA8DL},{0x105419D4L}},{{0UL},{0x00E18C75L},{18446744073709551615UL},{0xFFA28598L},{0x27422A64L},{1UL}}},{{{8UL},{1UL},{0xF0A7A9BAL},{18446744073709551615UL},{0UL},{5UL}},{{0x2338958DL},{0x3EEA6112L},{0x8B951A19L},{0UL},{0x85B50152L},{0xFFA28598L}},{{0x2F4C90BAL},{0x736783D7L},{1UL},{0UL},{18446744073709551613UL},{18446744073709551609UL}},{{18446744073709551608UL},{0x2F4C90BAL},{18446744073709551613UL},{0x105419D4L},{0x7EE3B43DL},{0xB2A3D5EBL}},{{0x020D6521L},{4UL},{0x736783D7L},{18446744073709551609UL},{0xB18C28E5L},{0xF50D7FD3L}}},{{{18446744073709551606UL},{0xC586312CL},{0x020D6521L},{0x67B8023EL},{0xFB11DAD7L},{18446744073709551615UL}},{{18446744073709551615UL},{8UL},{18446744073709551615UL},{8UL},{18446744073709551615UL},{0x061910BFL}},{{0x649E683EL},{0xA3DF6D8EL},{18446744073709551613UL},{18446744073709551608UL},{1UL},{4UL}},{{0x736783D7L},{0x3EEA6112L},{0xFB11DAD7L},{0xA3DF6D8EL},{18446744073709551608UL},{4UL}},{{1UL},{0x8A4CF7A6L},{18446744073709551613UL},{0xB18C28E5L},{18446744073709551609UL},{0x061910BFL}}},{{{18446744073709551608UL},{1UL},{18446744073709551615UL},{0xB2A3D5EBL},{18446744073709551615UL},{0xF0A7A9BAL}},{{1UL},{0x55F2C2DAL},{0UL},{0xB18C28E5L},{4UL},{18446744073709551608UL}},{{0x11C729ADL},{0xB2A3D5EBL},{3UL},{0xC586312CL},{0x55F2C2DAL},{18446744073709551613UL}},{{18446744073709551609UL},{0x2338958DL},{1UL},{0x8B1848CBL},{0xF0A7A9BAL},{0x027F49AAL}},{{0xC586312CL},{18446744073709551609UL},{0xF50D7FD3L},{0xDE40384BL},{1UL},{0x8B1848CBL}}},{{{0UL},{0x736783D7L},{0x7EE3B43DL},{0UL},{2UL},{1UL}},{{0x7EE3B43DL},{0xA3DF6D8EL},{18446744073709551615UL},{0x85B50152L},{0xF16E1511L},{0xF50D7FD3L}},{{1UL},{7UL},{4UL},{18446744073709551609UL},{5UL},{18446744073709551609UL}},{{0xEAFDBAA0L},{0x7EE3B43DL},{1UL},{18446744073709551606UL},{9UL},{9UL}},{{0x2338958DL},{0xB2A3D5EBL},{0xB2A3D5EBL},{0x2338958DL},{0x47206F6DL},{1UL}}}};
static union U2 g_956[1] = {{18446744073709551611UL}};
static union U2 g_957[9][3] = {{{0xCF2952B0L},{0UL},{0x1B74EC44L}},{{0xCF2952B0L},{0x4E7FB273L},{0xCF2952B0L}},{{0xCF2952B0L},{0xD3770DFFL},{1UL}},{{0xCF2952B0L},{0UL},{0x1B74EC44L}},{{0xCF2952B0L},{0x4E7FB273L},{0xCF2952B0L}},{{0xCF2952B0L},{0xD3770DFFL},{1UL}},{{0xCF2952B0L},{0UL},{0x1B74EC44L}},{{0xCF2952B0L},{0x4E7FB273L},{0xCF2952B0L}},{{0xCF2952B0L},{0xD3770DFFL},{1UL}}};
static union U2 g_958[5][2][4] = {{{{0x405B2AD9L},{0xC62A748DL},{0x29845AC0L},{0x29845AC0L}},{{8UL},{8UL},{0xB710BA66L},{0x2777F713L}}},{{{8UL},{2UL},{0x29845AC0L},{8UL}},{{0x405B2AD9L},{0x2777F713L},{0x405B2AD9L},{0x29845AC0L}}},{{{0xC62A748DL},{0x2777F713L},{0xB710BA66L},{8UL}},{{0x2777F713L},{2UL},{2UL},{0x2777F713L}}},{{{0x405B2AD9L},{8UL},{2UL},{0x29845AC0L}},{{0x2777F713L},{0xC62A748DL},{0xB710BA66L},{0xC62A748DL}}},{{{0xC62A748DL},{2UL},{0x405B2AD9L},{0xC62A748DL}},{{0x405B2AD9L},{0xC62A748DL},{0x29845AC0L},{0x29845AC0L}}}};
static union U2 g_959[3] = {{1UL},{1UL},{1UL}};
static union U2 g_960 = {2UL};/* VOLATILE GLOBAL g_960 */
static union U2 g_961 = {0x229DFCE3L};/* VOLATILE GLOBAL g_961 */
static union U2 g_962 = {18446744073709551615UL};/* VOLATILE GLOBAL g_962 */
static union U2 g_963 = {0x2313A89AL};/* VOLATILE GLOBAL g_963 */
static union U2 g_964[2] = {{0x5AA28D95L},{0x5AA28D95L}};
static union U2 g_965 = {0xF602D7DAL};/* VOLATILE GLOBAL g_965 */
static union U2 g_966 = {0x82AA8A1EL};/* VOLATILE GLOBAL g_966 */
static union U2 g_967[9] = {{1UL},{1UL},{1UL},{1UL},{1UL},{1UL},{1UL},{1UL},{1UL}};
static union U2 g_968 = {0UL};/* VOLATILE GLOBAL g_968 */
static union U2 g_969 = {18446744073709551615UL};/* VOLATILE GLOBAL g_969 */
static union U2 g_970[8] = {{5UL},{5UL},{5UL},{5UL},{5UL},{5UL},{5UL},{5UL}};
static union U2 g_971[5] = {{18446744073709551607UL},{18446744073709551607UL},{18446744073709551607UL},{18446744073709551607UL},{18446744073709551607UL}};
static union U2 g_972 = {0UL};/* VOLATILE GLOBAL g_972 */
static union U2 g_973 = {0UL};/* VOLATILE GLOBAL g_973 */
static union U2 g_974 = {18446744073709551610UL};/* VOLATILE GLOBAL g_974 */
static union U2 g_975[4][3] = {{{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL}}};
static union U2 g_976 = {0x56AB04D4L};/* VOLATILE GLOBAL g_976 */
static union U2 g_977 = {0x1B1E3D08L};/* VOLATILE GLOBAL g_977 */
static union U2 g_978 = {0xDFFCF834L};/* VOLATILE GLOBAL g_978 */
static union U2 g_979 = {0xBF2ADDB7L};/* VOLATILE GLOBAL g_979 */
static union U2 g_980 = {0UL};/* VOLATILE GLOBAL g_980 */
static union U2 g_981 = {0UL};/* VOLATILE GLOBAL g_981 */
static union U2 g_982 = {0x359B9672L};/* VOLATILE GLOBAL g_982 */
static union U2 g_983 = {1UL};/* VOLATILE GLOBAL g_983 */
static union U2 g_984[6] = {{0x9D390AB1L},{0x9D390AB1L},{0x9D390AB1L},{0x9D390AB1L},{0x9D390AB1L},{0x9D390AB1L}};
static union U2 g_985 = {18446744073709551610UL};/* VOLATILE GLOBAL g_985 */
static union U2 g_986 = {1UL};/* VOLATILE GLOBAL g_986 */
static union U2 g_987 = {0xC734645EL};/* VOLATILE GLOBAL g_987 */
static union U2 g_988 = {0xE5CB6719L};/* VOLATILE GLOBAL g_988 */
static union U2 g_989[1][4][2] = {{{{18446744073709551606UL},{18446744073709551615UL}},{{18446744073709551606UL},{18446744073709551615UL}},{{18446744073709551606UL},{18446744073709551615UL}},{{18446744073709551606UL},{18446744073709551615UL}}}};
static union U2 g_990 = {18446744073709551608UL};/* VOLATILE GLOBAL g_990 */
static union U2 g_991 = {5UL};/* VOLATILE GLOBAL g_991 */
static union U2 g_992 = {0x5DFB6D1AL};/* VOLATILE GLOBAL g_992 */
static volatile union U2 g_998 = {2UL};/* VOLATILE GLOBAL g_998 */
static volatile union U2 *g_997 = &g_998;
static uint32_t * volatile **g_1037 = &g_350;
static uint32_t * volatile ***g_1036 = &g_1037;
static union U2 g_1039[8] = {{0xF64FA929L},{1UL},{0xF64FA929L},{1UL},{0xF64FA929L},{1UL},{0xF64FA929L},{1UL}};
static union U2 g_1042 = {0x3AA768B1L};/* VOLATILE GLOBAL g_1042 */
static volatile uint64_t *g_1056 = (void*)0;
static volatile uint64_t **g_1055 = &g_1056;
static volatile uint64_t ***g_1054 = &g_1055;
static int32_t g_1070 = 0xEC12FCA9L;
static union U2 g_1111 = {0UL};/* VOLATILE GLOBAL g_1111 */
static int32_t *g_1122 = &g_90;
static uint16_t *g_1237 = &g_244[0][4];
static uint16_t **g_1236 = &g_1237;
static int16_t g_1282 = (-4L);
static int32_t g_1342 = 5L;
static int32_t * const g_1341 = &g_1342;
static int32_t * const *g_1340[2][10] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static uint32_t g_1361 = 1UL;
static union U1 g_1365 = {0xB8D48FE8L};/* VOLATILE GLOBAL g_1365 */
static int32_t *g_1465[7][7] = {{&g_81,&g_90,&g_81,&g_81,&g_54,&g_90,&g_81},{&g_81,&g_54,&g_90,&g_81,&g_90,&g_54,&g_81},{&g_54,&g_90,&g_81,&g_54,(void*)0,&g_90,(void*)0},{&g_54,(void*)0,(void*)0,&g_54,&g_81,(void*)0,&g_81},{&g_81,(void*)0,&g_81,&g_81,&g_81,&g_81,(void*)0},{&g_81,&g_81,&g_90,&g_90,(void*)0,&g_81,&g_81},{&g_90,&g_81,&g_81,&g_81,&g_90,&g_90,(void*)0}};
static volatile union U1 g_1591 = {4294967292UL};/* VOLATILE GLOBAL g_1591 */
static volatile union U1 *g_1590 = &g_1591;
static union U2 g_1639 = {0x316C6669L};/* VOLATILE GLOBAL g_1639 */
static int16_t *g_1721[3] = {&g_1282,&g_1282,&g_1282};
static int16_t **g_1720[10][8][3] = {{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[1],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[2]},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[0],&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[1],&g_1721[2]},{&g_1721[2],(void*)0,&g_1721[0]},{&g_1721[0],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[1],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[2]},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[0],&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[1],&g_1721[2]},{&g_1721[2],(void*)0,&g_1721[0]},{&g_1721[0],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[1],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[2]},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[0],&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[1],&g_1721[2]},{&g_1721[2],(void*)0,&g_1721[0]},{&g_1721[0],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[1],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[2]},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[0],&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[1],&g_1721[2]},{&g_1721[2],(void*)0,&g_1721[0]},{&g_1721[0],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[1],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[2]},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[0],&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[0],&g_1721[2]}},{{&g_1721[2],&g_1721[2],(void*)0},{(void*)0,(void*)0,&g_1721[2]},{&g_1721[2],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[2],&g_1721[0]},{&g_1721[2],&g_1721[1],&g_1721[2]},{&g_1721[2],(void*)0,&g_1721[0]},{&g_1721[0],&g_1721[2],&g_1721[0]},{(void*)0,&g_1721[0],&g_1721[2]}}};
static uint8_t *g_1768[10][6][4] = {{{(void*)0,&g_750[3],&g_750[1],&g_750[1]},{&g_110,(void*)0,&g_750[1],&g_750[0]},{&g_750[1],&g_750[1],(void*)0,&g_110},{&g_750[1],&g_750[1],&g_110,&g_110},{&g_110,&g_110,&g_750[3],&g_750[1]},{(void*)0,&g_750[1],&g_110,(void*)0}},{{(void*)0,&g_110,(void*)0,&g_750[1]},{&g_750[1],&g_110,&g_750[1],&g_750[0]},{&g_110,&g_750[3],(void*)0,&g_110},{&g_750[1],&g_750[1],&g_750[1],&g_110},{&g_750[1],&g_750[1],&g_750[1],&g_750[3]},{(void*)0,&g_750[1],&g_750[1],&g_110}},{{&g_110,(void*)0,&g_750[1],&g_750[1]},{&g_110,&g_750[1],(void*)0,&g_110},{&g_750[1],&g_750[1],(void*)0,(void*)0},{&g_750[2],&g_750[2],(void*)0,&g_750[2]},{&g_750[2],(void*)0,&g_110,&g_750[1]},{&g_110,&g_750[3],&g_750[1],&g_750[1]}},{{&g_750[1],&g_750[3],(void*)0,&g_110},{&g_750[1],&g_110,&g_750[2],&g_750[0]},{(void*)0,&g_110,&g_110,&g_750[2]},{(void*)0,&g_750[1],&g_750[3],&g_110},{&g_750[1],&g_750[1],&g_750[0],&g_110},{(void*)0,&g_750[0],&g_110,&g_750[0]}},{{&g_110,&g_750[1],&g_750[0],&g_110},{&g_750[1],&g_110,(void*)0,&g_750[1]},{&g_110,(void*)0,&g_750[1],&g_110},{&g_750[1],&g_750[1],&g_750[1],&g_110},{&g_750[0],(void*)0,&g_110,&g_110},{&g_110,&g_750[1],&g_750[1],(void*)0}},{{&g_750[1],&g_750[1],&g_750[1],&g_750[1]},{&g_110,&g_750[2],&g_110,&g_750[1]},{&g_110,(void*)0,&g_110,(void*)0},{&g_110,&g_110,&g_750[1],&g_750[1]},{&g_750[1],&g_110,&g_750[1],&g_750[1]},{&g_110,&g_110,&g_750[1],&g_110}},{{(void*)0,(void*)0,&g_750[1],(void*)0},{&g_750[1],&g_110,&g_110,&g_750[0]},{&g_750[1],&g_750[1],&g_750[1],&g_750[1]},{&g_110,&g_750[1],&g_750[1],&g_110},{(void*)0,&g_750[1],&g_750[3],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_110,&g_750[3],&g_750[1],&g_750[0]},{&g_110,&g_110,&g_750[2],&g_750[0]},{&g_750[1],&g_750[1],(void*)0,&g_750[0]},{&g_750[1],&g_110,(void*)0,&g_750[0]},{&g_110,&g_750[3],(void*)0,(void*)0},{&g_110,(void*)0,&g_750[1],(void*)0}},{{&g_110,&g_750[1],&g_750[0],&g_110},{&g_110,&g_750[1],&g_750[0],&g_750[1]},{&g_750[3],&g_750[1],&g_750[1],&g_750[0]},{&g_110,&g_110,&g_110,(void*)0},{(void*)0,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_750[0],&g_750[1]}},{{&g_750[3],&g_110,&g_110,&g_750[1]},{&g_750[0],&g_110,&g_750[1],(void*)0},{&g_110,(void*)0,&g_110,&g_750[1]},{&g_750[1],&g_750[2],&g_110,&g_750[1]},{&g_750[1],&g_750[1],(void*)0,(void*)0},{&g_750[1],&g_750[1],&g_750[3],&g_110}}};
static uint8_t **g_1767 = &g_1768[0][5][2];
static const volatile struct S0 *g_1853 = (void*)0;
static union U2 g_1895 = {18446744073709551606UL};/* VOLATILE GLOBAL g_1895 */
static int32_t * const **g_1913 = &g_1340[1][7];
static int32_t **g_1915 = (void*)0;
static int32_t ***g_1914[4][2] = {{&g_1915,&g_1915},{&g_1915,&g_1915},{&g_1915,&g_1915},{&g_1915,&g_1915}};
static volatile uint32_t g_1938 = 0xE2765C03L;/* VOLATILE GLOBAL g_1938 */
static volatile uint32_t g_1939 = 0xE88B16A8L;/* VOLATILE GLOBAL g_1939 */
static volatile uint32_t g_1940 = 18446744073709551610UL;/* VOLATILE GLOBAL g_1940 */
static volatile uint32_t g_1941 = 18446744073709551615UL;/* VOLATILE GLOBAL g_1941 */
static volatile uint32_t g_1942[2][9] = {{0xEA3562AFL,0xEA3562AFL,0x0A3DE9E0L,18446744073709551610UL,1UL,18446744073709551610UL,0x0A3DE9E0L,0xEA3562AFL,0xEA3562AFL},{18446744073709551613UL,0x3BA7898AL,0xEA3562AFL,18446744073709551610UL,0xEA3562AFL,0x3BA7898AL,18446744073709551613UL,18446744073709551613UL,0x3BA7898AL}};
static volatile uint32_t *g_1937[7][4][1] = {{{&g_1940},{&g_1941},{&g_1942[0][1]},{&g_1941}},{{&g_1940},{&g_1941},{&g_1942[0][1]},{&g_1941}},{{&g_1940},{&g_1941},{&g_1942[0][1]},{&g_1941}},{{&g_1940},{&g_1941},{&g_1942[0][1]},{&g_1941}},{{&g_1940},{&g_1941},{&g_1942[0][1]},{&g_1941}},{{&g_1940},{&g_1941},{&g_1942[0][1]},{&g_1941}},{{&g_1940},{&g_1941},{&g_1942[0][1]},{&g_1941}}};
static volatile uint32_t * volatile *g_1936 = &g_1937[5][2][0];
static struct S0 g_2017 = {1UL,4294967287UL,0xE753631BL,0xAF06L,1,18446744073709551611UL,249UL,0L,1L};/* VOLATILE GLOBAL g_2017 */
static union U1 g_2033 = {0xFDB226B7L};/* VOLATILE GLOBAL g_2033 */
static union U1 **g_2054[9] = {&g_667,&g_667,&g_667,&g_667,&g_667,&g_667,&g_667,&g_667,&g_667};
static union U1 ***g_2053 = &g_2054[6];
static struct S0 g_2120 = {0xCA0D417AL,0x09E051ECL,0xCC62691FL,0L,0,0xAE9654B5232E27DBLL,5UL,0xE8530783L,0x024235EAL};/* VOLATILE GLOBAL g_2120 */
static struct S0 g_2121 = {0xCA340963L,4294967294UL,1UL,0xB470L,9,18446744073709551608UL,2UL,0L,1L};/* VOLATILE GLOBAL g_2121 */
static const struct S0 *g_2119[6] = {(void*)0,&g_2121,&g_2121,(void*)0,&g_2121,&g_2121};
static const struct S0 **g_2118 = &g_2119[3];
static const struct S0 ***g_2117[7] = {&g_2118,&g_2118,&g_2118,&g_2118,&g_2118,&g_2118,&g_2118};
static uint32_t g_2132 = 18446744073709551615UL;
static const union U1 g_2204 = {4294967295UL};/* VOLATILE GLOBAL g_2204 */
static union U1 g_2220 = {0x9FFB663EL};/* VOLATILE GLOBAL g_2220 */
static const int64_t ** const *g_2292 = (void*)0;
static const int64_t ** const **g_2291 = &g_2292;
static int32_t g_2305 = 0x6643D845L;
static uint32_t *g_2314[1][7] = {{&g_41,&g_41,&g_41,&g_41,&g_41,&g_41,&g_41}};
static uint32_t **g_2313 = &g_2314[0][2];
static uint32_t ***g_2312 = &g_2313;
static union U2 * volatile *g_2398 = &g_457;
static union U2 * volatile * volatile * const  volatile g_2397 = &g_2398;/* VOLATILE GLOBAL g_2397 */
static union U2 * volatile * volatile * const  volatile * const g_2396 = &g_2397;
static const int16_t g_2430 = 1L;
static const union U1 g_2434 = {0x6BB2F144L};/* VOLATILE GLOBAL g_2434 */
static const uint8_t g_2451[4][1][4] = {{{7UL,1UL,0x99L,1UL}},{{1UL,0UL,0x99L,0x99L}},{{7UL,7UL,1UL,0x99L}},{{0x41L,0UL,0x41L,1UL}}};
static uint32_t g_2584 = 0x63821AD0L;
static int16_t ***g_2594 = &g_1720[1][3][1];
static int8_t g_2606 = 2L;
static uint32_t *****g_2636 = (void*)0;
static uint32_t **g_2640 = &g_351;
static uint32_t ***g_2639 = &g_2640;
static uint32_t ****g_2638 = &g_2639;
static uint32_t **** const *g_2637 = &g_2638;
static uint32_t **** const *g_2641 = (void*)0;
static int32_t *g_2687 = &g_971[3].f2;
static uint16_t g_2745 = 65534UL;
static const uint16_t **g_2750 = (void*)0;
static const uint16_t *** volatile g_2749 = &g_2750;/* VOLATILE GLOBAL g_2749 */
static const uint16_t *** volatile *g_2748 = &g_2749;
static struct S0 g_2851 = {0x4F41BFA5L,0x9062279AL,0x976EF1ADL,0x55BEL,5,1UL,252UL,8L,0x4D946A25L};/* VOLATILE GLOBAL g_2851 */
static uint32_t g_2936[2][6][9] = {{{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L},{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L},{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L},{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L},{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L,0xC8E64971L,0xD3A352D6L}}};
static int64_t * const ****g_2996[3] = {(void*)0,(void*)0,(void*)0};
static union U2 * volatile **g_3163 = &g_2398;
static int32_t g_3175[4] = {(-1L),(-1L),(-1L),(-1L)};
static uint16_t ***g_3298[1][6] = {{&g_1236,&g_1236,&g_1236,&g_1236,&g_1236,&g_1236}};
static uint16_t *** const *g_3297 = &g_3298[0][5];
static uint16_t *** const **g_3296[10][6] = {{&g_3297,&g_3297,(void*)0,&g_3297,&g_3297,(void*)0},{(void*)0,&g_3297,&g_3297,&g_3297,&g_3297,&g_3297},{&g_3297,&g_3297,&g_3297,(void*)0,&g_3297,&g_3297},{&g_3297,(void*)0,&g_3297,&g_3297,(void*)0,&g_3297},{(void*)0,&g_3297,(void*)0,&g_3297,&g_3297,(void*)0},{&g_3297,&g_3297,(void*)0,(void*)0,&g_3297,&g_3297},{&g_3297,(void*)0,&g_3297,&g_3297,(void*)0,&g_3297},{(void*)0,&g_3297,&g_3297,&g_3297,&g_3297,&g_3297},{&g_3297,&g_3297,&g_3297,(void*)0,&g_3297,(void*)0},{&g_3297,&g_3297,(void*)0,&g_3297,&g_3297,(void*)0}};
static uint64_t ***g_3326[2][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static uint64_t ****g_3325 = &g_3326[0][3];
static int8_t ** volatile *g_3374 = (void*)0;
static int16_t g_3379 = 1L;
static int32_t *g_3423 = &g_2851.f8;
static union U2 ***g_3439 = (void*)0;
static struct S0 g_3480 = {0x12EBA083L,0x47AD5F97L,18446744073709551607UL,0L,3,1UL,0xC5L,0x3AC414A0L,-1L};/* VOLATILE GLOBAL g_3480 */
static volatile int32_t g_3497 = (-1L);/* VOLATILE GLOBAL g_3497 */
static volatile int32_t g_3499 = 1L;/* VOLATILE GLOBAL g_3499 */
static uint32_t g_3518[5][10] = {{0x92344C2BL,0x19A02443L,0UL,1UL,0UL,0x19A02443L,0x92344C2BL,0x92344C2BL,0x19A02443L,0UL},{0x19A02443L,0x92344C2BL,0x92344C2BL,0x19A02443L,0UL,1UL,0UL,0x19A02443L,0x92344C2BL,0x92344C2BL},{0UL,0x92344C2BL,0UL,2UL,2UL,0UL,0x92344C2BL,0UL,0x92344C2BL,0UL},{1UL,0x19A02443L,2UL,0x19A02443L,1UL,0UL,0UL,1UL,0x19A02443L,2UL},{0UL,0UL,2UL,1UL,1UL,1UL,2UL,0UL,0UL,2UL}};
static uint16_t g_3556 = 0xAEADL;
static struct S0 g_3586[9][1] = {{{0x2636D01CL,1UL,0xA66A8695L,0L,4,0x850005426A6A4B64LL,6UL,0x06DD4798L,1L}},{{18446744073709551615UL,0xE17ACF44L,0xE55730E2L,0x90A9L,0,0x4A36468555495B59LL,0x2EL,-1L,0x5406C007L}},{{0x2636D01CL,1UL,0xA66A8695L,0L,4,0x850005426A6A4B64LL,6UL,0x06DD4798L,1L}},{{18446744073709551615UL,0xE17ACF44L,0xE55730E2L,0x90A9L,0,0x4A36468555495B59LL,0x2EL,-1L,0x5406C007L}},{{0x2636D01CL,1UL,0xA66A8695L,0L,4,0x850005426A6A4B64LL,6UL,0x06DD4798L,1L}},{{18446744073709551615UL,0xE17ACF44L,0xE55730E2L,0x90A9L,0,0x4A36468555495B59LL,0x2EL,-1L,0x5406C007L}},{{0x2636D01CL,1UL,0xA66A8695L,0L,4,0x850005426A6A4B64LL,6UL,0x06DD4798L,1L}},{{18446744073709551615UL,0xE17ACF44L,0xE55730E2L,0x90A9L,0,0x4A36468555495B59LL,0x2EL,-1L,0x5406C007L}},{{0x2636D01CL,1UL,0xA66A8695L,0L,4,0x850005426A6A4B64LL,6UL,0x06DD4798L,1L}}};
static struct S0 g_3588 = {0UL,0x75CB4D34L,18446744073709551610UL,0L,2,9UL,0UL,-4L,0xF77697BFL};/* VOLATILE GLOBAL g_3588 */
static struct S0 g_3620 = {0x366B8F19L,4294967295UL,18446744073709551615UL,0xE184L,9,1UL,255UL,0xD318E2D1L,0L};/* VOLATILE GLOBAL g_3620 */
static int64_t * const ***g_3686[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U2 g_3756 = {0xBE53631DL};/* VOLATILE GLOBAL g_3756 */
static int8_t g_3781 = (-5L);
static int64_t ****g_3830 = &g_929;
static int32_t g_3879[2][7] = {{1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L}};
static int16_t g_3963 = 0L;
static union U1 g_3994 = {4294967289UL};/* VOLATILE GLOBAL g_3994 */
static union U1 g_3996 = {0x84A758EBL};/* VOLATILE GLOBAL g_3996 */
static union U2 g_4104 = {18446744073709551615UL};/* VOLATILE GLOBAL g_4104 */
static const uint64_t *g_4121 = &g_3620.f5;
static const uint64_t **g_4120 = &g_4121;
static volatile uint64_t * volatile *g_4123 = &g_1056;
static int32_t g_4161[1][10] = {{0xC2A6E4E6L,7L,0xC2A6E4E6L,0xC2A6E4E6L,7L,0xC2A6E4E6L,0xC2A6E4E6L,7L,0xC2A6E4E6L,0xC2A6E4E6L}};
static int8_t ****g_4182 = (void*)0;
static int16_t g_4207[10] = {(-2L),(-2L),1L,(-2L),(-2L),1L,(-2L),(-2L),1L,(-2L)};
static volatile int32_t *g_4251 = (void*)0;
static union U1 g_4305[7][7][5] = {{{{1UL},{4294967295UL},{9UL},{0xD8B88B95L},{1UL}},{{4294967288UL},{0x369CE671L},{0xF2C97B3EL},{8UL},{4294967295UL}},{{0x3F427590L},{0UL},{0x04A1E63DL},{0x69093B6BL},{0xD76940F4L}},{{4294967295UL},{2UL},{0x6309D374L},{0x369CE671L},{0xC7D95F7AL}},{{0x080290FAL},{0UL},{9UL},{0x9E1E0C49L},{4294967295UL}},{{0x9864ED77L},{0UL},{0x1FC728B7L},{0x0ECADD57L},{4294967286UL}},{{0x050F60FEL},{0x5D4896D8L},{9UL},{0x9E1E0C49L},{0x3F427590L}}},{{{0x6E8F3364L},{2UL},{0x0ECADD57L},{4294967288UL},{0xFC75E844L}},{{1UL},{4294967295UL},{0UL},{0UL},{0UL}},{{0xC7D95F7AL},{0xC7D95F7AL},{0xF2C97B3EL},{1UL},{4294967295UL}},{{0x5940575CL},{0x69093B6BL},{9UL},{2UL},{0xD76940F4L}},{{4294967292UL},{1UL},{4294967293UL},{2UL},{0x6E8F3364L}},{{0UL},{0x69093B6BL},{9UL},{1UL},{4294967290UL}},{{0xE8DE716EL},{0xC7D95F7AL},{8UL},{0x1FC728B7L},{4294967286UL}}},{{{0x917ABD51L},{4294967295UL},{0xEB8FC56DL},{4294967295UL},{0x917ABD51L}},{{0UL},{2UL},{0x204587B5L},{0x6E8F3364L},{0x9864ED77L}},{{0UL},{0x5D4896D8L},{4294967290UL},{0UL},{5UL}},{{4294967288UL},{0UL},{0x9147F0DAL},{2UL},{0x9864ED77L}},{{0x5940575CL},{0UL},{0x04A1E63DL},{4294967295UL},{0x917ABD51L}},{{0x9864ED77L},{8UL},{4294967293UL},{4294967286UL},{4294967286UL}},{{1UL},{7UL},{1UL},{0x9E1E0C49L},{4294967290UL}}},{{{0xFC75E844L},{4294967288UL},{0x0ECADD57L},{2UL},{0x6E8F3364L}},{{0x050F60FEL},{4294967295UL},{0UL},{0UL},{0xD76940F4L}},{{0xC7D95F7AL},{0x204587B5L},{0x0ECADD57L},{0x6E8F3364L},{4294967295UL}},{{0x080290FAL},{0xF9149281L},{1UL},{2UL},{0UL}},{{4294967288UL},{0x6E8F3364L},{4294967293UL},{0x1FC728B7L},{0xFC75E844L}},{{0xD76940F4L},{0x69093B6BL},{0x04A1E63DL},{0UL},{0x3F427590L}},{{0xE8DE716EL},{0x204587B5L},{0x9147F0DAL},{2UL},{4294967286UL}}},{{{4294967295UL},{2UL},{4294967290UL},{4294967295UL},{4294967295UL}},{{0xE8DE716EL},{4294967288UL},{0x204587B5L},{1UL},{0xC7D95F7AL}},{{0xD76940F4L},{0x5D4896D8L},{0xEB8FC56DL},{0UL},{0UL}},{{4294967288UL},{8UL},{8UL},{4294967288UL},{0x9864ED77L}},{{0x080290FAL},{0UL},{9UL},{4294967295UL},{4294967295UL}},{{0xC7D95F7AL},{0UL},{4294967293UL},{0x0ECADD57L},{4294967295UL}},{{0x050F60FEL},{7UL},{9UL},{4294967295UL},{0x3F427590L}}},{{{0xFC75E844L},{2UL},{0xF2C97B3EL},{4294967288UL},{0x6E8F3364L}},{{1UL},{2UL},{0UL},{0UL},{0UL}},{{0x9864ED77L},{0xC7D95F7AL},{0x0ECADD57L},{1UL},{0x369CE671L}},{{0x5940575CL},{0xF9149281L},{9UL},{4294967295UL},{0xD76940F4L}},{{4294967288UL},{1UL},{0x1FC728B7L},{2UL},{0xFC75E844L}},{{0UL},{0xF9149281L},{9UL},{0UL},{4294967290UL}},{{0UL},{0xC7D95F7AL},{0x9147F0DAL},{0x1FC728B7L},{0x9864ED77L}}},{{{4294967291UL},{0x69093B6BL},{0UL},{0x69093B6BL},{4294967291UL}},{{0xFC75E844L},{8UL},{0x7BE878D6L},{2UL},{0x369CE671L}},{{5UL},{0xD8B88B95L},{0UL},{0x9E1E0C49L},{0x080290FAL}},{{0xE8DE716EL},{0x6E8F3364L},{1UL},{8UL},{0x369CE671L}},{{0x050F60FEL},{0x9E1E0C49L},{0xEB8FC56DL},{1UL},{4294967291UL}},{{0x369CE671L},{1UL},{0x0ECADD57L},{0xC7D95F7AL},{0x9864ED77L}},{{4294967295UL},{4294967295UL},{4294967295UL},{0UL},{0UL}}}};
static const uint8_t *g_4407 = &g_3480.f6;
static const uint8_t **g_4406[9][10] = {{&g_4407,&g_4407,&g_4407,(void*)0,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407},{&g_4407,&g_4407,&g_4407,(void*)0,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407},{(void*)0,&g_4407,(void*)0,&g_4407,&g_4407,&g_4407,(void*)0,&g_4407,(void*)0,&g_4407},{&g_4407,(void*)0,&g_4407,&g_4407,&g_4407,(void*)0,&g_4407,&g_4407,(void*)0,(void*)0},{&g_4407,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407,(void*)0,(void*)0},{(void*)0,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407,(void*)0,&g_4407,&g_4407,&g_4407},{&g_4407,&g_4407,&g_4407,(void*)0,(void*)0,&g_4407,&g_4407,&g_4407,&g_4407,&g_4407},{&g_4407,&g_4407,&g_4407,(void*)0,(void*)0,(void*)0,&g_4407,(void*)0,&g_4407,(void*)0},{&g_4407,&g_4407,&g_4407,(void*)0,(void*)0,(void*)0,&g_4407,&g_4407,(void*)0,&g_4407}};
static union U1 g_4409 = {0xA2C6EB81L};/* VOLATILE GLOBAL g_4409 */
static union U1 g_4415 = {0x461302D9L};/* VOLATILE GLOBAL g_4415 */
static int64_t g_4447 = 0x7C819A8027267125LL;
static union U2 g_4522 = {0x25155AEEL};/* VOLATILE GLOBAL g_4522 */
static union U2 g_4525 = {0xDC8AE0DAL};/* VOLATILE GLOBAL g_4525 */
static struct S0 g_4677 = {1UL,0xA85AC758L,0xC46ECEB4L,0x8A2EL,3,18446744073709551612UL,248UL,-1L,0L};/* VOLATILE GLOBAL g_4677 */
static struct S0 *g_4676[5] = {&g_4677,&g_4677,&g_4677,&g_4677,&g_4677};
static struct S0 **g_4675[5][9] = {{&g_4676[2],&g_4676[0],&g_4676[0],&g_4676[0],&g_4676[0],&g_4676[0],&g_4676[0],&g_4676[2],&g_4676[0]},{&g_4676[1],(void*)0,&g_4676[0],&g_4676[0],(void*)0,&g_4676[1],&g_4676[0],&g_4676[1],(void*)0},{&g_4676[1],&g_4676[0],&g_4676[0],&g_4676[1],&g_4676[2],(void*)0,&g_4676[2],&g_4676[1],&g_4676[0]},{&g_4676[2],&g_4676[2],&g_4676[0],(void*)0,(void*)0,(void*)0,&g_4676[0],&g_4676[2],&g_4676[2]},{&g_4676[0],&g_4676[1],&g_4676[2],(void*)0,&g_4676[2],&g_4676[1],&g_4676[0],&g_4676[0],&g_4676[1]}};
static struct S0 ***g_4674[4][5][5] = {{{&g_4675[0][8],&g_4675[4][1],&g_4675[0][8],&g_4675[0][8],(void*)0},{&g_4675[0][8],&g_4675[2][3],&g_4675[3][8],(void*)0,&g_4675[0][8]},{&g_4675[0][8],&g_4675[0][8],&g_4675[0][8],&g_4675[2][5],&g_4675[0][8]},{&g_4675[0][8],(void*)0,(void*)0,&g_4675[0][8],&g_4675[0][8]},{&g_4675[2][5],&g_4675[0][6],&g_4675[2][3],&g_4675[0][8],&g_4675[0][8]}},{{(void*)0,&g_4675[0][8],(void*)0,&g_4675[0][8],&g_4675[0][8]},{&g_4675[1][6],(void*)0,&g_4675[2][3],&g_4675[1][7],(void*)0},{(void*)0,(void*)0,(void*)0,&g_4675[0][8],&g_4675[0][8]},{&g_4675[0][8],&g_4675[0][8],&g_4675[2][3],(void*)0,&g_4675[0][8]},{&g_4675[3][1],&g_4675[0][8],(void*)0,&g_4675[3][8],&g_4675[3][8]}},{{&g_4675[2][3],&g_4675[0][8],&g_4675[2][3],&g_4675[0][8],&g_4675[1][7]},{&g_4675[2][5],&g_4675[0][8],(void*)0,&g_4675[0][8],&g_4675[0][8]},{&g_4675[0][8],&g_4675[4][7],&g_4675[2][3],&g_4675[0][8],&g_4675[0][8]},{&g_4675[0][8],(void*)0,(void*)0,&g_4675[0][8],&g_4675[0][8]},{&g_4675[2][5],&g_4675[0][6],&g_4675[2][3],&g_4675[0][8],&g_4675[0][8]}},{{(void*)0,&g_4675[0][8],(void*)0,&g_4675[0][8],&g_4675[0][8]},{&g_4675[1][6],(void*)0,&g_4675[2][3],&g_4675[1][7],(void*)0},{(void*)0,(void*)0,(void*)0,&g_4675[0][8],&g_4675[0][8]},{&g_4675[0][8],&g_4675[0][8],&g_4675[2][3],(void*)0,&g_4675[0][8]},{&g_4675[3][1],&g_4675[0][8],(void*)0,&g_4675[3][8],&g_4675[3][8]}}};
static struct S0 ****g_4673 = &g_4674[3][4][2];
static uint8_t g_4686 = 0xE7L;
static const int8_t g_4795[8][3] = {{2L,0x0CL,2L},{2L,0x2BL,0x0CL},{0x2BL,2L,2L},{0x0CL,2L,0x00L},{(-1L),0x2BL,0xA0L},{0x0CL,0x0CL,0xA0L},{0x2BL,(-1L),0x00L},{2L,0x0CL,2L}};
static struct S0 g_4906 = {0x9718CF2BL,4294967294UL,0xE679BF90L,-10L,3,0xA2C4080C71EADB60LL,0xCCL,0x1607398AL,0x3DFD3F34L};/* VOLATILE GLOBAL g_4906 */
static struct S0 g_4907 = {18446744073709551607UL,0x3E5B7865L,0x4F05FBD5L,0x933DL,0,0UL,0x06L,0x0C445E68L,-8L};/* VOLATILE GLOBAL g_4907 */
static struct S0 g_4908 = {18446744073709551606UL,0x1CF0CE16L,0x15A83215L,-9L,4,0xA17D46919615D346LL,0x60L,-1L,0x2A24AD87L};/* VOLATILE GLOBAL g_4908 */
static struct S0 g_4967 = {18446744073709551615UL,0x83F6FC0EL,0x7B1F233DL,-4L,5,0x8C529AEE8B2E4D22LL,0UL,0xFAF5A83CL,0x457DF6DCL};/* VOLATILE GLOBAL g_4967 */
static struct S0 g_4968 = {0xBD197740L,4294967289UL,9UL,0x14A7L,5,0UL,0x23L,-1L,2L};/* VOLATILE GLOBAL g_4968 */
static struct S0 g_4969 = {0x4FF685C3L,0xEAC612FAL,0x46A33E30L,-2L,9,0x3C5E00063A5CB010LL,0x06L,0xE6873A04L,0x9377ED88L};/* VOLATILE GLOBAL g_4969 */
static struct S0 g_5003 = {0x2A8B6683L,0x6484A8CBL,3UL,0xDFFCL,1,0xE9801AE7FF2DF5F4LL,0x49L,0x13B83681L,0L};/* VOLATILE GLOBAL g_5003 */
static union U1 g_5073[10][6] = {{{0UL},{0UL},{1UL},{1UL},{0UL},{0UL}},{{0UL},{1UL},{1UL},{0UL},{0UL},{1UL}},{{0UL},{0UL},{1UL},{1UL},{0UL},{0UL}},{{0UL},{1UL},{1UL},{0UL},{0UL},{1UL}},{{0UL},{0UL},{1UL},{1UL},{0UL},{0UL}},{{0UL},{1UL},{1UL},{0UL},{0UL},{1UL}},{{0UL},{0UL},{1UL},{1UL},{0UL},{0UL}},{{0UL},{1UL},{1UL},{0UL},{0UL},{1UL}},{{0UL},{0UL},{1UL},{1UL},{0UL},{0UL}},{{0UL},{1UL},{1UL},{0UL},{0UL},{1UL}}};
static union U1 g_5075[5] = {{0xCF9D9EFBL},{0xCF9D9EFBL},{0xCF9D9EFBL},{0xCF9D9EFBL},{0xCF9D9EFBL}};
static uint8_t ***g_5077 = &g_1767;
static uint8_t ****g_5076 = &g_5077;
static volatile uint32_t **g_5106[10][3] = {{&g_1937[4][1][0],&g_1937[0][2][0],&g_1937[4][1][0]},{(void*)0,(void*)0,&g_1937[4][0][0]},{(void*)0,&g_1937[0][2][0],(void*)0},{(void*)0,&g_1937[4][0][0],&g_1937[4][0][0]},{&g_1937[4][1][0],&g_1937[0][2][0],&g_1937[4][1][0]},{(void*)0,(void*)0,&g_1937[4][0][0]},{(void*)0,&g_1937[0][2][0],(void*)0},{(void*)0,&g_1937[4][0][0],&g_1937[4][0][0]},{&g_1937[4][1][0],&g_1937[0][2][0],&g_1937[4][1][0]},{(void*)0,(void*)0,&g_1937[4][0][0]}};
static volatile uint32_t ***g_5105 = &g_5106[4][2];
static volatile uint32_t **** volatile g_5104 = &g_5105;/* VOLATILE GLOBAL g_5104 */
static volatile uint32_t **** volatile *g_5103 = &g_5104;
static int64_t g_5122 = 0xA2FE151346DD6E85LL;
static union U1 g_5203 = {0x9ED7816EL};/* VOLATILE GLOBAL g_5203 */
static const int16_t *g_5215 = &g_3963;
static volatile union U2 * volatile * volatile *g_5222 = (void*)0;
static const uint32_t g_5265 = 18446744073709551615UL;
static int8_t g_5314[3][3] = {{(-1L),1L,(-1L)},{0x8DL,0x8DL,0x8DL},{(-1L),1L,(-1L)}};
static union U2 g_5334[7][2] = {{{0xC867A3E0L},{0xCEC66982L}},{{3UL},{0x4AEC05F1L}},{{0xCEC66982L},{0x4AEC05F1L}},{{3UL},{0xCEC66982L}},{{0xC867A3E0L},{0xC867A3E0L}},{{0xC867A3E0L},{0xCEC66982L}},{{3UL},{0x4AEC05F1L}}};
static uint16_t g_5351 = 0x844EL;
static const uint8_t g_5360 = 253UL;
static union U1 g_5395 = {0xAD61B68AL};/* VOLATILE GLOBAL g_5395 */
static union U1 g_5414 = {5UL};/* VOLATILE GLOBAL g_5414 */
static int8_t g_5437 = 0x2BL;
static int16_t g_5534 = 0xE781L;
static int16_t * volatile * volatile g_5602 = &g_1721[2];/* VOLATILE GLOBAL g_5602 */
static int16_t * volatile * volatile *g_5601 = &g_5602;
static int16_t * volatile * volatile ** const  volatile g_5600 = &g_5601;/* VOLATILE GLOBAL g_5600 */
static int16_t * volatile * volatile ** const  volatile *g_5599 = &g_5600;
static int32_t g_5616 = (-8L);
static uint32_t g_5667 = 4294967295UL;
static int16_t ****g_5718 = &g_2594;
static union U2 **g_5753 = &g_457;
static union U2 ***g_5752[6] = {&g_5753,&g_5753,&g_5753,&g_5753,&g_5753,&g_5753};
static const union U2 g_5873 = {0x5B8EEAD5L};/* VOLATILE GLOBAL g_5873 */
static union U2 g_5876 = {0xFE4B9A21L};/* VOLATILE GLOBAL g_5876 */
static union U1 g_5977 = {4294967295UL};/* VOLATILE GLOBAL g_5977 */
static union U1 g_5978 = {0x1EF7EA62L};/* VOLATILE GLOBAL g_5978 */
static uint32_t g_6046 = 0UL;
static union U2 g_6230 = {4UL};/* VOLATILE GLOBAL g_6230 */
static uint8_t g_6316 = 0xD4L;
static union U2 g_6333 = {3UL};/* VOLATILE GLOBAL g_6333 */
static union U2 g_6335 = {18446744073709551615UL};/* VOLATILE GLOBAL g_6335 */
static union U2 g_6375 = {0x2D6F5E9AL};/* VOLATILE GLOBAL g_6375 */
static uint32_t g_6389[9][6][3] = {{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,18446744073709551611UL,18446744073709551615UL},{0x7B71C291L,7UL,0xF18E22FCL},{2UL,18446744073709551611UL,18446744073709551611UL},{0x7D7E0610L,7UL,4UL},{18446744073709551609UL,18446744073709551611UL,0x49229D77L}},{{0UL,7UL,7UL},{0x516B27D2L,0UL,0x71C27B32L},{4UL,0x68A4E355L,0UL},{18446744073709551611UL,0UL,0UL},{0xF18E22FCL,0x68A4E355L,0x6DA2ED96L},{18446744073709551615UL,0UL,1UL}}};
static union U2 g_6468 = {18446744073709551609UL};/* VOLATILE GLOBAL g_6468 */
static int32_t *g_6591 = &g_4969.f8;
static volatile int8_t g_6640 = (-7L);/* VOLATILE GLOBAL g_6640 */
static struct S0 g_6683 = {0x00BEA9BBL,0UL,9UL,0L,8,0xE00D0B8E6FE173B4LL,0xE1L,1L,0x69BC1C91L};/* VOLATILE GLOBAL g_6683 */
static struct S0 g_6688 = {9UL,0x01D3DC7AL,18446744073709551615UL,0xA0BFL,10,0x92AB72F02FFE034FLL,0x26L,0x9E2A9A63L,0x7B2EA050L};/* VOLATILE GLOBAL g_6688 */
static uint32_t g_6714 = 7UL;
static volatile union U2 g_6720[2][7] = {{{0x36CE900BL},{0x36CE900BL},{0x36CE900BL},{0x36CE900BL},{0x36CE900BL},{0x36CE900BL},{0x36CE900BL}},{{0x85B64D1AL},{0x85B64D1AL},{0x85B64D1AL},{0x85B64D1AL},{0x85B64D1AL},{0x85B64D1AL},{0x85B64D1AL}}};
static volatile union U2 g_6728 = {0x5D806430L};/* VOLATILE GLOBAL g_6728 */
static struct S0 g_6752 = {18446744073709551615UL,8UL,0x89F95F82L,-5L,2,0xCDD1C907DCE9F13ELL,0x1FL,1L,0xB5A73DFFL};/* VOLATILE GLOBAL g_6752 */
static const int32_t g_6755 = 0x6F2F6BA6L;
static union U1 g_6757[6][8] = {{{0UL},{0x859E8151L},{0x0B8CB3F8L},{0x40931955L},{0x40931955L},{0x0B8CB3F8L},{0x859E8151L},{0UL}},{{0x89F976EBL},{4294967295UL},{0UL},{4294967295UL},{0UL},{0x15A1C812L},{0x89F976EBL},{0x859E8151L}},{{4294967295UL},{4294967295UL},{0xD5FE2A32L},{0UL},{4294967295UL},{0x15A1C812L},{0x40931955L},{0x15A1C812L}},{{0x1F7B4FACL},{4294967295UL},{0x869AB182L},{4294967295UL},{0x1F7B4FACL},{0x0B8CB3F8L},{0UL},{0x1F7B4FACL}},{{0x15A1C812L},{0x859E8151L},{0x89F976EBL},{0x15A1C812L},{0UL},{4294967295UL},{0UL},{4294967295UL}},{{0x859E8151L},{0UL},{0x89F976EBL},{0UL},{0x3621C67AL},{0x3621C67AL},{0UL},{0x89F976EBL}}};
static uint32_t g_6772 = 0xA669B678L;
static int32_t * const g_6777 = (void*)0;
static int32_t ** volatile g_6796 = (void*)0;/* VOLATILE GLOBAL g_6796 */
static struct S0 g_6813[7] = {{0UL,0x54450C69L,9UL,0x84BBL,2,0UL,0x56L,0L,0x431727D5L},{0UL,0x54450C69L,9UL,0x84BBL,2,0UL,0x56L,0L,0x431727D5L},{0UL,0x54450C69L,9UL,0x84BBL,2,0UL,0x56L,0L,0x431727D5L},{0UL,0x54450C69L,9UL,0x84BBL,2,0UL,0x56L,0L,0x431727D5L},{0UL,0x54450C69L,9UL,0x84BBL,2,0UL,0x56L,0L,0x431727D5L},{0UL,0x54450C69L,9UL,0x84BBL,2,0UL,0x56L,0L,0x431727D5L},{0UL,0x54450C69L,9UL,0x84BBL,2,0UL,0x56L,0L,0x431727D5L}};
static volatile int64_t *g_6824 = (void*)0;
static volatile union U2 g_6856 = {9UL};/* VOLATILE GLOBAL g_6856 */
static int32_t *g_6961 = &g_721.f2;
static volatile struct S0 g_6970 = {0x00C95C72L,0xE6E700B0L,0xBD41CAFEL,-1L,9,1UL,1UL,1L,-3L};/* VOLATILE GLOBAL g_6970 */
static union U1 g_7070[1] = {{0x0ABCD382L}};


/* --- FORWARD DECLARATIONS --- */
static union U1  func_1(void);
static int16_t  func_11(uint64_t  p_12, int16_t  p_13, int32_t  p_14, uint8_t  p_15);
static uint64_t  func_16(int32_t  p_17, const int8_t  p_18);
static uint64_t  func_22(uint32_t  p_23, int32_t  p_24, uint8_t  p_25, uint64_t  p_26, const int16_t  p_27);
static uint8_t  func_28(int64_t  p_29, uint32_t  p_30, int64_t  p_31, int32_t  p_32, const uint64_t  p_33);
static const uint8_t  func_36(int32_t  p_37, int8_t  p_38, int16_t  p_39, uint32_t  p_40);
static uint16_t  func_49(int8_t  p_50);
static int32_t * func_58(uint32_t  p_59, const uint32_t  p_60, uint8_t  p_61, int16_t  p_62, uint64_t  p_63);
static uint16_t  func_64(uint32_t  p_65);
static int32_t * func_69(int32_t  p_70, uint32_t  p_71, int32_t * p_72, int32_t * p_73, int32_t * p_74);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_41 g_51 g_1042.f0 g_54 g_914 g_573 g_89 g_98 g_849 g_2312 g_2313 g_2314 g_2118 g_90 g_768 g_929 g_248 g_249 g_176 g_1341 g_1236 g_1237 g_244 g_927 g_928 g_771 g_2053 g_2054 g_1122 g_1342 g_2936 g_2637 g_2638 g_1054 g_1055 g_1037 g_350 g_607.f0 g_3163 g_1111.f3 g_973.f3 g_3175 g_997 g_749 g_550 g_969.f0 g_978.f0 g_1937 g_3423 g_3297 g_3298 g_3518 g_3556 g_2851.f8 g_2687 g_457 g_117 g_81 g_110 g_184 g_211 g_400 g_420 g_421 g_2017.f3 g_1913 g_1340 g_3620.f8 g_3756.f2 g_3879 g_1042.f2 g_750 g_602.f0 g_962.f0 g_3963 g_3830 g_589.f3 g_4120 g_4123 g_3620.f3 g_1282 g_985.f2 g_4161 g_4182 g_3586.f3 g_2594 g_1720 g_2639 g_4251 g_966.f0 g_2121.f8 g_3326 g_3586.f8 g_3586.f5 g_4121 g_3620.f5 g_723.f2 g_2640 g_4447 g_1895.f2 g_4407 g_3480.f6 g_2745 g_458.f0 g_2851.f3 g_3325 g_4673 g_4686 g_1365.f2 g_965.f3 g_973.f2 g_458.f3 g_5360 g_2120.f8 g_5351 g_4968.f2 g_952.f2 g_668.f0 g_973.f0 g_5437 g_945.f2 g_5534 g_1639.f0 g_5599 g_5203.f0 g_5616 g_981.f2 g_668.f3 g_744 g_4207 g_5215 g_4906.f2 g_5076 g_6591 g_4969.f8 g_4415.f0 g_960.f0 g_1768 g_4525.f2 g_6640 g_988.f0 g_7070
 * writes: g_54 g_1042.f0 g_90 g_98 g_2119 g_2220.f0 g_901 g_849 g_51 g_987.f0 g_1342 g_2606 g_573 g_176 g_244 g_2054 g_981.f0 g_2996 g_1465 g_977.f2 g_2220.f3 g_589.f3 g_607.f0 g_248 g_3163 g_1111.f3 g_2220.f2 g_973.f3 g_997 g_976.f2 g_982.f3 g_607.f3 g_749 g_550 g_969.f0 g_978.f0 g_3480.f3 g_721.f3 g_2851.f8 g_2936 g_966.f2 g_984.f3 g_963.f2 g_3325 g_3686 g_971.f2 g_81 g_89 g_110 g_117 g_184 g_211 g_336 g_400 g_421 g_2017.f3 g_744 g_748 g_952.f3 g_928 g_3830 g_41 g_3518 g_3620.f8 g_3756.f2 g_1042.f2 g_2121.f3 g_589.f0 g_750 g_914 g_980.f2 g_602.f0 g_962.f0 g_1767 g_2312 g_3620.f3 g_1282 g_985.f2 g_3586.f3 g_2639 g_4251 g_987.f3 g_966.f0 g_2121.f8 g_2314 g_4406 g_3586.f5 g_723.f2 g_351 g_1895.f2 g_457 g_2745 g_458.f0 g_3620.f5 g_2851.f3 g_4686 g_1365.f2 g_965.f3 g_2120.f5 g_3963 g_3423 g_979.f3 g_973.f2 g_458.f3 g_969.f2 g_4677.f2 g_668.f3 g_947.f3 g_4906.f8 g_2313 g_3588.f5 g_5351 g_4968.f2 g_952.f2 g_668.f0 g_973.f0 g_945.f2 g_5203.f0 g_961.f0 g_964.f3 g_633 g_1639.f0 g_5616 g_981.f2 g_4906.f2 g_5077 g_4969.f8 g_4415.f0 g_960.f0 g_1340 g_4525.f2 g_988.f0 g_3588.f8
 */
static union U1  func_1(void)
{ /* block id: 0 */
    int32_t l_9[2];
    int32_t l_5359 = 0x1CAF0097L;
    int32_t l_6606 = 1L;
    int64_t **l_6638 = &g_249;
    int32_t l_6639 = (-8L);
    int32_t l_6641 = 0L;
    const uint32_t l_6679 = 1UL;
    int8_t l_6680 = 0x55L;
    uint32_t l_6697 = 0xDB9FBB92L;
    uint32_t ***l_6703 = &g_2313;
    uint16_t l_6715 = 5UL;
    union U1 *l_6751 = &g_5978;
    int64_t **** const l_6756 = &g_929;
    int64_t l_6805 = (-1L);
    uint8_t l_6807 = 0xDDL;
    struct S0 *l_6810 = &g_3588;
    uint64_t l_6815[5][3][7] = {{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL}},{{0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL}},{{0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL,0x4CC9D79BECE96C51LL,0UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL}}};
    int8_t l_6919[4][10][6] = {{{0L,5L,(-8L),(-9L),0L,0xA2L},{1L,(-1L),(-1L),0x47L,0x32L,9L},{0x98L,0xC1L,0x5DL,0x47L,0x98L,(-9L)},{1L,0x9CL,0x68L,(-9L),0x68L,0x9CL},{(-8L),5L,0x38L,0L,0x98L,(-9L)},{(-1L),0L,0x45L,0x9CL,0x83L,9L},{0x5DL,0L,0L,0L,0x98L,0xA2L},{0x68L,5L,0x32L,5L,0x68L,0L},{0x38L,0x9CL,(-1L),0L,0x98L,(-1L)},{0x45L,0xC1L,1L,0x9CL,0x32L,(-1L)}},{{0L,(-1L),(-1L),0L,0L,0L},{0x32L,0L,0x32L,(-9L),(-1L),0xA2L},{(-1L),(-1L),0L,0x47L,(-8L),9L},{1L,0xC1L,0x45L,0x47L,0x5BL,(-9L)},{(-1L),0x9CL,0x38L,(-9L),0x38L,0x9CL},{0x32L,5L,0x68L,0L,1L,(-9L)},{0L,0L,0x5DL,0x9CL,(-1L),9L},{0x45L,0L,(-1L),0L,1L,0xA2L},{0x38L,5L,(-8L),5L,0x38L,0L},{0x68L,0x9CL,1L,0L,0x5BL,(-1L)}},{{0x5DL,0xC1L,0x98L,0x9CL,(-8L),(-1L)},{(-1L),(-1L),1L,0L,(-1L),0L},{(-8L),0L,(-8L),(-9L),0L,0xA2L},{1L,(-1L),(-1L),0x47L,0x32L,9L},{0x98L,0xC1L,0x5DL,0x47L,0x98L,(-9L)},{1L,0x9CL,0x68L,(-9L),0x68L,0x9CL},{(-8L),5L,0x38L,0L,0x98L,(-9L)},{(-1L),0L,0x45L,0x9CL,0x83L,9L},{0x5DL,0L,0L,0L,0x98L,0xA2L},{0x68L,5L,0x32L,5L,0x68L,0L}},{{0x38L,0x9CL,(-1L),0L,0x98L,(-1L)},{0x45L,0xC1L,1L,0x9CL,0x32L,(-1L)},{0L,0xA2L,0x27L,0x9CL,0x98L,0x9CL},{0x83L,0L,0x83L,5L,0x5BL,9L},{0x27L,0xA2L,(-8L),0L,(-1L),0x47L},{0x50L,(-9L),1L,0L,0x68L,5L},{0x27L,0xC1L,0L,5L,0L,0xC1L},{0x83L,0L,(-1L),0x9CL,0x50L,5L},{(-8L),0x9CL,0x98L,0xC1L,0x5DL,0x47L},{1L,0x9CL,0x32L,(-1L),0x50L,9L}}};
    int32_t l_7062 = 0xA5933924L;
    int16_t l_7066 = 0x94A5L;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_9[i] = (-1L);
    l_6606 ^= ((safe_sub_func_uint8_t_u_u(g_4, (0x5D7249AAED6B6572LL ^ (safe_div_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(l_9[0], g_10[3])), func_11((g_10[3] , (((g_10[3] < g_10[0]) ^ func_16((safe_unary_minus_func_uint64_t_u((l_5359 = (safe_add_func_uint64_t_u_u(func_22(l_9[0], ((((g_10[3] != l_9[0]) < g_10[2]) ^ l_9[0]) && 7L), g_10[2], g_10[2], g_10[5]), 0xA3185FCB23242DD4LL))))), g_5360)) , 0x0045041CFF1BBB58LL)), l_9[1], g_2120.f8, l_9[1])))))) && 1L);
    l_5359 = ((0x9EL == (*g_768)) >= (**g_1236));
    for (g_4525.f2 = 7; (g_4525.f2 == 21); g_4525.f2 = safe_add_func_int32_t_s_s(g_4525.f2, 9))
    { /* block id: 2879 */
        uint32_t l_6619 = 18446744073709551615UL;
        int64_t **l_6637[9][8] = {{(void*)0,&g_249,&g_249,&g_249,(void*)0,&g_249,&g_249,&g_249},{(void*)0,&g_249,&g_249,&g_249,(void*)0,&g_249,&g_249,&g_249},{(void*)0,&g_249,(void*)0,&g_249,&g_249,&g_249,&g_249,&g_249},{(void*)0,&g_249,(void*)0,&g_249,&g_249,(void*)0,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,(void*)0,&g_249,&g_249,(void*)0,&g_249},{(void*)0,&g_249,&g_249,&g_249,&g_249,&g_249,(void*)0,&g_249},{(void*)0,&g_249,&g_249,&g_249,(void*)0,&g_249,&g_249,&g_249},{(void*)0,&g_249,&g_249,&g_249,(void*)0,&g_249,&g_249,&g_249}};
        int16_t l_6642 = (-1L);
        int32_t l_6643 = 0L;
        int i, j;
        (*g_1341) = ((l_6643 ^= (safe_sub_func_int16_t_s_s((safe_rshift_func_uint32_t_u_s((safe_mod_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s((safe_div_func_int32_t_s_s(l_6619, ((safe_rshift_func_int64_t_s_s(((((safe_mod_func_int64_t_s_s((-1L), (((((safe_rshift_func_uint8_t_u_u((+1L), 7)) & 247UL) & l_9[0]) > 1L) || ((l_6619 ^ ((((safe_rshift_func_int8_t_s_u((safe_sub_func_uint64_t_u_u(((safe_add_func_uint32_t_u_u((safe_mod_func_int64_t_s_s((((safe_div_func_uint64_t_u_u((l_6637[5][5] != (l_6638 = l_6637[5][5])), l_6639)) && 0xE15FL) ^ (**g_4120)), l_6619)), 0xAC100996L)) || g_6640), l_6619)), 5)) || 8L) < 0xB08BL) > 8L)) | l_6641)))) >= l_6619) , (-4L)) >= 1UL), 19)) || l_6606))), l_6619)), l_6641)), l_6619)), l_6642))) || (*g_4407));
    }
    for (g_988.f0 = 0; (g_988.f0 < 22); g_988.f0 = safe_add_func_int64_t_s_s(g_988.f0, 1))
    { /* block id: 2886 */
        uint64_t l_6675 = 1UL;
        int16_t *l_6677[5][6][6] = {{{&g_3620.f3,&g_2121.f3,(void*)0,&g_3620.f3,&g_2851.f3,&g_4968.f3},{&g_3379,&g_10[3],&g_5003.f3,&g_5003.f3,&g_10[3],&g_3379},{&g_5534,(void*)0,&g_4207[0],&g_4967.f3,&g_4907.f3,(void*)0},{&g_3963,&g_3588.f3,&g_3620.f3,&g_4677.f3,&g_4968.f3,(void*)0},{&g_3963,&g_10[3],&g_4677.f3,&g_4967.f3,(void*)0,&g_2017.f3},{&g_5534,&g_4907.f3,&g_98,&g_5003.f3,&g_10[5],&g_5003.f3}},{{&g_3379,&g_3963,(void*)0,&g_3620.f3,&g_2017.f3,&g_4207[0]},{&g_3620.f3,&g_4906.f3,&g_10[3],&g_4969.f3,&g_589.f2,&g_10[5]},{&g_4969.f3,(void*)0,&g_5534,&g_98,(void*)0,&g_4207[9]},{(void*)0,&g_4967.f3,(void*)0,&g_3588.f3,&g_3620.f3,&g_2017.f3},{&g_10[3],&g_3963,&g_2851.f3,&g_3379,&g_4677.f3,&g_589.f2},{(void*)0,&g_3620.f3,&g_4969.f3,&g_2017.f3,(void*)0,&g_5003.f3}},{{&g_4969.f3,&g_5003.f3,(void*)0,&g_4207[3],(void*)0,&g_5003.f3},{&g_2121.f3,&g_4677.f3,&g_2120.f3,(void*)0,&g_3588.f3,&g_2851.f3},{&g_2851.f3,&g_10[5],(void*)0,&g_10[3],(void*)0,&g_4207[0]},{&g_4967.f3,&g_10[5],&g_10[3],&g_4967.f3,&g_3588.f3,(void*)0},{&g_98,&g_4677.f3,(void*)0,(void*)0,(void*)0,&g_3620.f3},{&g_3588.f3,&g_5003.f3,&g_4207[0],&g_3379,(void*)0,&g_589.f2}},{{&g_3588.f3,&g_10[3],&g_4207[0],&g_3588.f3,&g_4906.f3,&g_10[3]},{&g_3379,&g_10[3],&g_3620.f3,(void*)0,&g_3588.f3,&g_10[1]},{&g_5003.f3,&g_3586[8][0].f3,&g_2017.f3,&g_2017.f3,&g_2121.f3,&g_4907.f3},{&g_4207[3],&g_5003.f3,(void*)0,&g_4969.f3,(void*)0,(void*)0},{&g_10[3],(void*)0,&g_2851.f3,&g_4207[1],&g_4969.f3,&g_5534},{&g_2017.f3,&g_4677.f3,&g_5003.f3,&g_98,&g_98,&g_5003.f3}},{{&g_4968.f3,&g_4968.f3,&g_3588.f3,&g_4906.f3,&g_3620.f3,&g_4967.f3},{&g_4969.f3,&g_4207[3],&g_4968.f3,&g_3379,&g_10[5],&g_3588.f3},{&g_5003.f3,&g_4969.f3,&g_4968.f3,(void*)0,&g_4968.f3,&g_4967.f3},{&g_10[3],(void*)0,&g_3588.f3,&g_4677.f3,&g_2851.f3,&g_5003.f3},{&g_4677.f3,&g_2851.f3,&g_5003.f3,&g_3379,(void*)0,&g_5534},{&g_3620.f3,&g_5003.f3,&g_2851.f3,&g_589.f2,&g_4207[0],(void*)0}}};
        int32_t l_6678 = 0x0D91B73BL;
        struct S0 *l_6682 = &g_6683;
        int32_t l_6694 = 0xA4509C40L;
        int32_t *l_6700 = (void*)0;
        uint32_t ***l_6704 = &g_2313;
        const uint32_t l_6753 = 0x139966ABL;
        int16_t l_6787 = 9L;
        int32_t l_6806 = 0L;
        uint16_t l_6848 = 65535UL;
        int32_t l_6864 = 0L;
        int64_t l_6867[10][5][5] = {{{(-2L),0xD945113D903F62A4LL,0xCB05A659026B5F2BLL,0xCB05A659026B5F2BLL,0xD945113D903F62A4LL},{(-1L),0x068C64CD6CF3194BLL,0x33AEBE81074C56C3LL,0xFD312C2651EEC722LL,0xE426FEC0ABAA88EELL},{(-3L),0xB0CD92A08017210FLL,0xADE9764C4BB2D5A2LL,0x257DA44CE65BD11BLL,0xE238F7E52FAC2CC3LL},{0xE426FEC0ABAA88EELL,(-5L),(-1L),1L,(-7L)},{(-3L),2L,(-2L),7L,1L}},{{(-1L),0xAA4533AE2E07E76BLL,0xFBD3918BE23AFDFALL,0xE5DB9CF8A40078ADLL,8L},{(-2L),0x6B81FDEC48675474LL,0xF3718A5675856F49LL,(-1L),0xD2EC01F32B7D9B0CLL},{0x77FF2C741952FADDLL,0xE426FEC0ABAA88EELL,0xE426FEC0ABAA88EELL,0x77FF2C741952FADDLL,1L},{0xE238F7E52FAC2CC3LL,0xB0CD92A08017210FLL,(-4L),0xD2EC01F32B7D9B0CLL,0x6B81FDEC48675474LL},{0x33AEBE81074C56C3LL,0x62EF9F7F214D37D3LL,1L,0x068C64CD6CF3194BLL,0xAB167A158CAF79BCLL}},{{0xB0CD92A08017210FLL,(-1L),(-2L),0xD2EC01F32B7D9B0CLL,0x2FCA541B02758D01LL},{0xAF709B0A2F69BEAALL,0xFD312C2651EEC722LL,0xFDB39CC4C8BBC05DLL,0x77FF2C741952FADDLL,0xFD312C2651EEC722LL},{1L,(-3L),0L,(-1L),0xE6303CE84F3E4586LL},{0x62EF9F7F214D37D3LL,(-1L),0x33AEBE81074C56C3LL,0xE5DB9CF8A40078ADLL,0x33AEBE81074C56C3LL},{0xE6303CE84F3E4586LL,0xE6303CE84F3E4586LL,1L,7L,0x6B81FDEC48675474LL}},{{0x068C64CD6CF3194BLL,(-7L),6L,1L,(-1L)},{7L,0x79E25A3B67BFCB1BLL,8L,0xF3718A5675856F49LL,5L},{1L,0x33AEBE81074C56C3LL,0xAA4533AE2E07E76BLL,(-1L),0L},{1L,(-2L),0x495DBE789DB62849LL,1L,(-1L)},{6L,8L,0x4CEAF6B242FF6518LL,0L,3L}},{{(-2L),0x79E25A3B67BFCB1BLL,0xD945113D903F62A4LL,0x79E25A3B67BFCB1BLL,(-2L)},{8L,(-1L),0xFBD3918BE23AFDFALL,(-7L),1L},{1L,1L,1L,0x2FCA541B02758D01LL,1L},{0L,0L,0xAF709B0A2F69BEAALL,(-1L),1L},{0x42DE7DCEC49A6F7DLL,0x2FCA541B02758D01LL,1L,(-4L),(-2L)}},{{1L,(-10L),8L,0L,3L},{0x79E25A3B67BFCB1BLL,0L,7L,(-1L),(-1L)},{(-1L),1L,(-1L),0xCA394C79800D979ELL,0L},{1L,0xADE9764C4BB2D5A2LL,0x42DE7DCEC49A6F7DLL,0xCB05A659026B5F2BLL,5L},{0xE426FEC0ABAA88EELL,1L,0xE5DB9CF8A40078ADLL,0xE426FEC0ABAA88EELL,0L}},{{1L,0x2FCA541B02758D01LL,0x42DE7DCEC49A6F7DLL,5L,0L},{6L,0x4CEAF6B242FF6518LL,(-1L),0L,0xE5DCEC532FDA15BALL},{0x2FCA541B02758D01LL,0xCB05A659026B5F2BLL,7L,2L,(-2L)},{0xFBD3918BE23AFDFALL,(-1L),8L,8L,(-1L)},{(-1L),0x42DE7DCEC49A6F7DLL,1L,0xCB05A659026B5F2BLL,0x495DBE789DB62849LL}},{{0L,0xE426FEC0ABAA88EELL,0xAF709B0A2F69BEAALL,0x068C64CD6CF3194BLL,6L},{0x495DBE789DB62849LL,(-2L),1L,8L,0L},{0L,3L,0xFBD3918BE23AFDFALL,0L,(-1L)},{(-1L),0x4422F709D5F96E83LL,0xD945113D903F62A4LL,0xF3718A5675856F49LL,2L},{0xFBD3918BE23AFDFALL,0x33AEBE81074C56C3LL,0x4CEAF6B242FF6518LL,0xFDB39CC4C8BBC05DLL,0L}},{{0x2FCA541B02758D01LL,0x495DBE789DB62849LL,0x495DBE789DB62849LL,0x2FCA541B02758D01LL,8L},{6L,0xE426FEC0ABAA88EELL,0xAA4533AE2E07E76BLL,0L,0x33AEBE81074C56C3LL},{1L,0x79E25A3B67BFCB1BLL,8L,0x42DE7DCEC49A6F7DLL,(-2L)},{0xE426FEC0ABAA88EELL,0xFDB39CC4C8BBC05DLL,0xFBD3918BE23AFDFALL,0L,(-10L)},{1L,0xCB05A659026B5F2BLL,0xE6303CE84F3E4586LL,0x2FCA541B02758D01LL,0xCB05A659026B5F2BLL}},{{(-1L),0L,0xE5DCEC532FDA15BALL,0xFDB39CC4C8BBC05DLL,1L},{0x79E25A3B67BFCB1BLL,1L,1L,0xF3718A5675856F49LL,1L},{1L,1L,(-5L),0L,0x33AEBE81074C56C3LL},{0x42DE7DCEC49A6F7DLL,0L,8L,8L,(-1L)},{0L,0xAE19585110C4B264LL,(-1L),0x068C64CD6CF3194BLL,(-7L)}}};
        uint64_t l_6872 = 0x6DD34601BA04E9CBLL;
        int8_t l_6873 = 0xAAL;
        int32_t *l_6888 = &g_4907.f8;
        uint64_t l_6937[6] = {0xD9073EF57F196D99LL,0xD9073EF57F196D99LL,18446744073709551606UL,0xD9073EF57F196D99LL,0xD9073EF57F196D99LL,18446744073709551606UL};
        int64_t *l_6974 = &g_176;
        int64_t ** const l_6973 = &l_6974;
        int64_t ** const *l_6972 = &l_6973;
        uint32_t l_7067 = 0xCA74D3DAL;
        int i, j, k;
        for (g_3588.f8 = (-27); (g_3588.f8 >= 18); g_3588.f8++)
        { /* block id: 2889 */
            uint32_t l_6648 = 0xA04F454AL;
            if (l_6648)
                break;
        }
    }
    return g_7070[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_5351 g_4968.f2 g_1237 g_244 g_1122 g_90 g_1341 g_952.f2 g_668.f0 g_973.f0 g_5437 g_3297 g_3298 g_1236 g_4121 g_3620.f5 g_945.f2 g_249 g_4120 g_176 g_2312 g_2313 g_2314 g_41 g_768 g_51 g_5534 g_771 g_2638 g_2639 g_2640 g_1342 g_110 g_2118 g_1639.f0 g_5599 g_5203.f0 g_2851.f3 g_5616 g_54 g_981.f2 g_668.f3 g_927 g_928 g_914 g_3586.f5 g_573 g_744 g_4207 g_5215 g_3963 g_4906.f2 g_2936 g_750 g_5076 g_6591 g_4969.f8 g_4415.f0 g_960.f0 g_1768 g_1913
 * writes: g_5351 g_4968.f2 g_90 g_1342 g_952.f2 g_668.f0 g_973.f0 g_3423 g_945.f2 g_176 g_5203.f0 g_961.f0 g_964.f3 g_458.f0 g_51 g_3325 g_351 g_110 g_2119 g_633 g_1639.f0 g_2851.f3 g_5616 g_54 g_981.f2 g_668.f3 g_928 g_3586.f5 g_573 g_1365.f2 g_744 g_244 g_4906.f2 g_750 g_5077 g_4969.f8 g_4415.f0 g_960.f0 g_1340
 */
static int16_t  func_11(uint64_t  p_12, int16_t  p_13, int32_t  p_14, uint8_t  p_15)
{ /* block id: 2342 */
    int8_t l_5377[5] = {0xA3L,0xA3L,0xA3L,0xA3L,0xA3L};
    int32_t l_5383 = 0xA3CFFA99L;
    int32_t l_5391[2];
    union U1 *l_5394 = &g_5395;
    int32_t l_5408 = 1L;
    int32_t l_5415[6] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
    const uint32_t *l_5426 = &g_988.f0;
    const uint32_t **l_5425[8] = {&l_5426,&l_5426,&l_5426,&l_5426,&l_5426,&l_5426,&l_5426,&l_5426};
    const uint32_t ** const * const l_5424 = &l_5425[4];
    const uint8_t ***l_5440 = &g_4406[2][7];
    int32_t *l_5481 = &g_3879[0][4];
    int32_t *l_5482[10][5][5] = {{{&g_900,(void*)0,(void*)0,&g_900,&l_5415[4]},{&g_3879[0][4],&g_1070,&g_945.f2,&g_945.f2,&g_1070},{&l_5415[4],(void*)0,(void*)0,&g_3175[1],&g_3175[1]},{(void*)0,&g_945.f2,(void*)0,&g_945.f2,(void*)0},{&g_3879[0][4],&g_900,&g_3175[1],&g_900,&g_3879[0][4]}},{{(void*)0,&g_3879[0][4],&g_945.f2,&g_1070,&g_945.f2},{&l_5415[4],&l_5415[4],&g_3175[1],&g_3879[0][4],&g_1070},{&g_3879[0][4],(void*)0,(void*)0,&g_3879[0][4],&g_945.f2},{&g_900,&g_3879[0][4],(void*)0,(void*)0,&g_3879[0][4]},{&g_945.f2,(void*)0,&g_945.f2,(void*)0,(void*)0}},{{(void*)0,&l_5415[4],(void*)0,(void*)0,&g_3175[1]},{&g_1070,&g_3879[0][4],(void*)0,&g_3879[0][4],&g_1070},{(void*)0,&g_900,&l_5415[4],&g_3879[0][4],&l_5415[4]},{&g_945.f2,&g_945.f2,(void*)0,&g_1070,&g_1070},{&g_900,(void*)0,(void*)0,&g_900,&l_5415[4]}},{{&g_3879[0][4],&g_1070,&g_945.f2,&g_945.f2,&g_1070},{&l_5415[4],(void*)0,(void*)0,&g_3175[1],&g_3175[1]},{(void*)0,&g_945.f2,(void*)0,&g_945.f2,(void*)0},{&g_3879[0][4],&g_900,&g_3175[1],&g_900,&g_3879[0][4]},{(void*)0,&g_3879[0][4],&g_945.f2,&g_1070,&g_945.f2}},{{&l_5415[4],&l_5415[4],&g_3175[1],&g_3879[0][4],&g_1070},{&g_3879[0][4],(void*)0,(void*)0,&g_3879[0][4],&g_945.f2},{&g_900,&g_3879[0][4],(void*)0,(void*)0,&g_3879[0][4]},{&g_945.f2,(void*)0,&g_945.f2,(void*)0,(void*)0},{(void*)0,&l_5415[4],(void*)0,(void*)0,&g_3175[1]}},{{&g_1070,&g_3879[0][4],(void*)0,&g_3879[0][4],&g_1070},{(void*)0,&g_900,&l_5415[4],&g_3879[0][4],&l_5415[4]},{&g_945.f2,&g_945.f2,(void*)0,&g_1070,&g_1070},{&g_900,(void*)0,(void*)0,&g_900,&l_5415[4]},{&g_3879[0][4],&g_1070,&g_945.f2,&g_945.f2,&g_1070}},{{&l_5415[4],(void*)0,(void*)0,&g_3175[1],&g_3175[1]},{(void*)0,&g_945.f2,(void*)0,&g_945.f2,(void*)0},{&g_3879[0][4],&g_900,&g_3175[1],&g_900,&g_3879[0][4]},{(void*)0,&g_3879[0][4],&g_945.f2,&g_1070,&g_945.f2},{&l_5415[4],&l_5415[4],&g_3175[1],&g_3879[0][4],&g_1070}},{{&g_3879[0][4],(void*)0,(void*)0,&g_3879[0][4],&g_945.f2},{&g_900,&g_3879[0][4],(void*)0,(void*)0,&g_3879[0][4]},{&g_945.f2,(void*)0,&g_945.f2,(void*)0,&g_945.f2},{&g_3879[0][4],&g_1070,&g_3879[0][4],&g_3175[1],&l_5415[4]},{&g_945.f2,(void*)0,&g_945.f2,(void*)0,&g_945.f2}},{{&g_3879[0][4],(void*)0,&g_1070,(void*)0,&g_1070},{&g_1070,&g_1070,&g_945.f2,&g_945.f2,&g_3879[0][4]},{(void*)0,&g_3879[0][4],&g_3879[0][4],(void*)0,&g_1070},{(void*)0,&g_945.f2,(void*)0,(void*)0,&g_945.f2},{&g_1070,&g_3879[0][4],&g_3175[1],&l_5415[4],&l_5415[4]}},{{&g_1070,&g_1070,&g_1070,(void*)0,&g_945.f2},{(void*)0,(void*)0,&l_5415[4],(void*)0,(void*)0},{&g_1070,(void*)0,&g_1070,&g_945.f2,&g_1070},{&g_1070,&g_1070,&l_5415[4],(void*)0,&g_900},{(void*)0,&g_1070,&g_1070,(void*)0,&g_1070}}};
    int32_t l_5486 = 0xD3F8FFFBL;
    uint32_t ****l_5496 = (void*)0;
    int16_t *** const *l_5604 = &g_2594;
    int16_t *** const **l_5603 = &l_5604;
    uint64_t l_5609 = 0x5EBF88C03A66645ALL;
    int8_t l_5625 = 1L;
    uint32_t ****l_5646 = &g_2312;
    uint32_t *****l_5645 = &l_5646;
    const uint16_t ***l_5665 = &g_2750;
    const uint16_t ****l_5664 = &l_5665;
    uint32_t l_5972 = 4294967290UL;
    uint64_t l_5979[7][5][7] = {{{18446744073709551615UL,0x24C4B310F696E76ALL,1UL,18446744073709551613UL,0xB49DA27A0938C0B2LL,18446744073709551611UL,4UL},{0x283E2BDB81916751LL,5UL,0x3332356428269A88LL,0x4A50418F3498BD9FLL,0UL,0xCB0FD0C0ABCD742DLL,0UL},{0xE5B9719D4FEEC309LL,18446744073709551615UL,18446744073709551615UL,0xE5B9719D4FEEC309LL,0x68499598F795E03BLL,4UL,0x4A50418F3498BD9FLL},{4UL,0UL,18446744073709551613UL,0x3FA0765BD1F5ED2CLL,18446744073709551615UL,0x68499598F795E03BLL,0x895E1C4D3BA7B182LL},{0x4A50418F3498BD9FLL,5UL,2UL,0x24C4B310F696E76ALL,0xD3D95992AB6AD375LL,0x8A754934714BCA0DLL,0x4A50418F3498BD9FLL}},{{0xB49DA27A0938C0B2LL,0x4AFDEC3049AA5A73LL,0x1D8A0D4F2C93916DLL,18446744073709551615UL,4UL,3UL,0UL},{0x2580C525C1D03F9BLL,0xEFDE7CCCDB198C38LL,0x3FA0765BD1F5ED2CLL,4UL,18446744073709551615UL,18446744073709551615UL,4UL},{5UL,1UL,0x8A754934714BCA0DLL,5UL,18446744073709551615UL,0x30FFEDBEFFBF74BFLL,0xEFDE7CCCDB198C38LL},{5UL,0x895E1C4D3BA7B182LL,4UL,0xEFDE7CCCDB198C38LL,18446744073709551615UL,1UL,18446744073709551615UL},{0x2580C525C1D03F9BLL,0xB49DA27A0938C0B2LL,18446744073709551613UL,18446744073709551613UL,0xB49DA27A0938C0B2LL,0x2580C525C1D03F9BLL,18446744073709551613UL}},{{0xB49DA27A0938C0B2LL,0xD3D95992AB6AD375LL,0x3217E49DF8D88A55LL,0x283E2BDB81916751LL,0UL,0xC8C3869F1F661367LL,18446744073709551615UL},{0x4A50418F3498BD9FLL,0x2580C525C1D03F9BLL,0x55B67F0B3B51A7E4LL,0xEFDE7CCCDB198C38LL,0x895E1C4D3BA7B182LL,3UL,0x168573986551BD3FLL},{4UL,0xD3D95992AB6AD375LL,1UL,18446744073709551611UL,0x283E2BDB81916751LL,0x1D8A0D4F2C93916DLL,0x55B67F0B3B51A7E4LL},{0xE5B9719D4FEEC309LL,0xB49DA27A0938C0B2LL,0x34D136CDA8187F8FLL,0xD3D95992AB6AD375LL,0x168573986551BD3FLL,0x3EE7971619E2519BLL,18446744073709551615UL},{0x283E2BDB81916751LL,0x895E1C4D3BA7B182LL,1UL,18446744073709551615UL,18446744073709551613UL,4UL,0xE5B9719D4FEEC309LL}},{{18446744073709551615UL,1UL,1UL,0x4AFDEC3049AA5A73LL,18446744073709551615UL,0x3FA0765BD1F5ED2CLL,0x2580C525C1D03F9BLL},{0x24C4B310F696E76ALL,0xEFDE7CCCDB198C38LL,0x34D136CDA8187F8FLL,0UL,0UL,0x34D136CDA8187F8FLL,0xEFDE7CCCDB198C38LL},{18446744073709551615UL,0x4AFDEC3049AA5A73LL,1UL,0xE5B9719D4FEEC309LL,1UL,18446744073709551611UL,0xD3D95992AB6AD375LL},{18446744073709551613UL,5UL,0x55B67F0B3B51A7E4LL,18446744073709551615UL,0x55B67F0B3B51A7E4LL,0UL,0x3332356428269A88LL},{18446744073709551615UL,0x55B67F0B3B51A7E4LL,0x168573986551BD3FLL,18446744073709551615UL,1UL,0x4A50418F3498BD9FLL,0x4AFDEC3049AA5A73LL}},{{1UL,0x3332356428269A88LL,0x8A754934714BCA0DLL,18446744073709551613UL,0x34D136CDA8187F8FLL,0xB48B4D7B8A871BB6LL,4UL},{18446744073709551615UL,0x68499598F795E03BLL,1UL,18446744073709551606UL,1UL,0x3EE7971619E2519BLL,18446744073709551615UL},{18446744073709551615UL,18446744073709551613UL,18446744073709551615UL,4UL,1UL,18446744073709551615UL,0x55B67F0B3B51A7E4LL},{0x895E1C4D3BA7B182LL,0x30FFEDBEFFBF74BFLL,0UL,1UL,0x34D136CDA8187F8FLL,0x34D136CDA8187F8FLL,1UL},{0x3EE7971619E2519BLL,3UL,0x3EE7971619E2519BLL,0x6B8AFBE4A6E71B53LL,1UL,5UL,0x30FFEDBEFFBF74BFLL}},{{0x68499598F795E03BLL,4UL,0x4A50418F3498BD9FLL,0x2580C525C1D03F9BLL,0x55B67F0B3B51A7E4LL,0xEFDE7CCCDB198C38LL,0x895E1C4D3BA7B182LL},{0x895E1C4D3BA7B182LL,0x3217E49DF8D88A55LL,0x8A754934714BCA0DLL,0x1D8A0D4F2C93916DLL,0x3217E49DF8D88A55LL,5UL,18446744073709551615UL},{0x3217E49DF8D88A55LL,1UL,0x3332356428269A88LL,0x8A754934714BCA0DLL,18446744073709551613UL,0x34D136CDA8187F8FLL,0xB48B4D7B8A871BB6LL},{0x4AFDEC3049AA5A73LL,0x895E1C4D3BA7B182LL,0UL,0x2580C525C1D03F9BLL,4UL,18446744073709551615UL,0x3FA0765BD1F5ED2CLL},{1UL,1UL,1UL,1UL,0x8A754934714BCA0DLL,0x3EE7971619E2519BLL,0x3FA0765BD1F5ED2CLL}},{{0xC8C3869F1F661367LL,18446744073709551615UL,0x6B8AFBE4A6E71B53LL,1UL,0x3FA0765BD1F5ED2CLL,0xB48B4D7B8A871BB6LL,0xB48B4D7B8A871BB6LL},{0x1D8A0D4F2C93916DLL,4UL,0x24C4B310F696E76ALL,4UL,0x1D8A0D4F2C93916DLL,0x4A50418F3498BD9FLL,18446744073709551615UL},{18446744073709551611UL,1UL,18446744073709551615UL,18446744073709551613UL,2UL,0UL,0x895E1C4D3BA7B182LL},{18446744073709551606UL,0x2580C525C1D03F9BLL,0x6B8AFBE4A6E71B53LL,0UL,18446744073709551613UL,0x6B8AFBE4A6E71B53LL,0x30FFEDBEFFBF74BFLL},{18446744073709551611UL,18446744073709551613UL,0xEFDE7CCCDB198C38LL,18446744073709551615UL,18446744073709551615UL,0xB49DA27A0938C0B2LL,1UL}}};
    int8_t **l_6047[1][4][4] = {{{&g_771,(void*)0,(void*)0,&g_771},{(void*)0,&g_771,(void*)0,(void*)0},{&g_771,&g_771,&g_768,&g_771},{&g_771,(void*)0,(void*)0,&g_771}}};
    uint16_t l_6104 = 0UL;
    int32_t l_6191 = (-4L);
    uint8_t l_6202[9] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
    uint16_t l_6241[1][9] = {{0x84D7L,0x84D7L,0x84D7L,0x84D7L,0x84D7L,0x84D7L,0x84D7L,0x84D7L,0x84D7L}};
    uint32_t l_6246 = 0x2C00004DL;
    union U2 *l_6334 = &g_6335;
    int16_t l_6378 = 0L;
    int32_t l_6384 = (-9L);
    uint64_t l_6439 = 0UL;
    uint64_t l_6504 = 18446744073709551615UL;
    int64_t l_6577 = 0x83EA6DE45221BA82LL;
    int32_t l_6602[7][3][4] = {{{(-5L),0x05481B40L,0L,0xF66FFE49L},{0x84AAFB9AL,0L,0x94E54854L,0x7BE735B5L},{0x84AAFB9AL,(-1L),0L,0x70527DF6L}},{{(-5L),0x7BE735B5L,0x7BE735B5L,(-5L)},{(-1L),0x59640E15L,(-5L),1L},{0x94E54854L,0x70527DF6L,0x23711835L,0x62595B8CL}},{{0x08F1A9DBL,0xF66FFE49L,(-1L),0x62595B8CL},{0x59640E15L,0x70527DF6L,(-1L),1L},{(-1L),0x59640E15L,(-1L),(-5L)}},{{(-1L),0x7BE735B5L,0x84AAFB9AL,0x70527DF6L},{0x62595B8CL,(-1L),0x84AAFB9AL,(-1L)},{0x7BE735B5L,0x62595B8CL,0x84AAFB9AL,0x23711835L}},{{1L,0xF66FFE49L,(-5L),(-5L)},{0x08F1A9DBL,0x08F1A9DBL,(-1L),0x7BE735B5L},{(-1L),0x7BE735B5L,0x94E54854L,0L}},{{0L,0x00E1E3E4L,0x08F1A9DBL,0x94E54854L},{0xA02F9331L,0x00E1E3E4L,0x59640E15L,0L},{0x00E1E3E4L,0x7BE735B5L,(-1L),0x7BE735B5L}},{{0x70527DF6L,0x08F1A9DBL,(-1L),(-5L)},{(-1L),0xF66FFE49L,0x62595B8CL,0x23711835L},{(-5L),0x62595B8CL,0x00E1E3E4L,(-1L)}}};
    int32_t **l_6603[5];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_5391[i] = 0L;
    for (i = 0; i < 5; i++)
        l_6603[i] = (void*)0;
lbl_5905:
    if ((safe_add_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((safe_rshift_func_int32_t_s_u(p_15, 30)), ((void*)0 != &g_2054[6]))), (~l_5377[1]))))
    { /* block id: 2343 */
        uint32_t l_5380 = 0x47A7B839L;
        for (g_5351 = 0; (g_5351 <= 27); ++g_5351)
        { /* block id: 2346 */
            return l_5380;
        }
    }
    else
    { /* block id: 2349 */
        int64_t l_5384 = 0xF798BAEC04170B67LL;
        int32_t l_5416 = (-1L);
        for (g_4968.f2 = 0; (g_4968.f2 <= 7); g_4968.f2 += 1)
        { /* block id: 2352 */
            union U1 **l_5396[9] = {&g_667,&g_667,&g_667,&g_667,&g_667,&g_667,&g_667,&g_667,&g_667};
            int8_t l_5411 = 0xC2L;
            uint32_t l_5412 = 4294967291UL;
            union U1 * const l_5413 = &g_5414;
            int i;
            l_5391[0] = (safe_add_func_uint64_t_u_u(((l_5383 ^= 0x5DA2BDF99E54F7D0LL) > l_5384), (safe_div_func_uint8_t_u_u((p_12 > (*g_1237)), (safe_mod_func_uint64_t_u_u((safe_add_func_int32_t_s_s(((*g_1122) |= l_5384), 0x135500A0L)), p_13))))));
            if ((((((safe_div_func_int32_t_s_s((((l_5394 = l_5394) != ((l_5391[0] > (safe_mod_func_uint64_t_u_u(((((*g_1341) = (safe_div_func_int8_t_s_s((l_5383 <= ((safe_div_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s((safe_sub_func_uint32_t_u_u((~l_5384), ((p_12 > l_5384) != (l_5408 = l_5384)))), 10)), (safe_mul_func_int8_t_s_s((0UL <= (l_5384 != p_13)), l_5411)))) , l_5412)), p_15))) <= (-1L)) < 0x751D9FD8920C979CLL), p_12))) , l_5413)) >= l_5415[4]), 0x49B0AC7FL)) >= l_5411) > p_13) & l_5412) , l_5412))
            { /* block id: 2359 */
                l_5416 = ((*g_1341) = l_5415[2]);
            }
            else
            { /* block id: 2362 */
                uint8_t l_5417 = 0x35L;
                l_5417--;
                if (l_5417)
                    continue;
                for (g_952.f2 = 0; (g_952.f2 <= 7); g_952.f2 += 1)
                { /* block id: 2367 */
                    int i, j;
                    (*g_1122) = ((~g_244[(g_4968.f2 + 1)][g_4968.f2]) , p_12);
                }
            }
            for (g_668.f0 = 0; (g_668.f0 <= 7); g_668.f0 += 1)
            { /* block id: 2373 */
                for (g_973.f0 = 0; (g_973.f0 <= 7); g_973.f0 += 1)
                { /* block id: 2376 */
                    uint32_t ***l_5423[9];
                    int i;
                    for (i = 0; i < 9; i++)
                        l_5423[i] = &g_2313;
                    if ((0UL < ((l_5423[6] == l_5424) , 0UL)))
                    { /* block id: 2377 */
                        if (l_5412)
                            break;
                        return p_12;
                    }
                    else
                    { /* block id: 2380 */
                        return p_12;
                    }
                }
            }
        }
    }
    if ((safe_lshift_func_uint16_t_u_s(p_12, (((safe_add_func_uint32_t_u_u((p_13 == ((safe_mul_func_uint8_t_u_u(l_5383, (((safe_lshift_func_int32_t_s_u(((*g_1341) = (safe_add_func_int32_t_s_s(g_5437, l_5377[1]))), 15)) && (p_13 >= (l_5391[1] |= (l_5408 &= 0x8D041CB5C6C42548LL)))) != (((l_5383 ^ (safe_add_func_uint16_t_u_u(((((l_5440 != l_5440) , l_5377[0]) >= 18446744073709551608UL) , 0x2770L), (****g_3297)))) && l_5415[4]) || l_5377[4])))) > l_5383)), l_5415[2])) <= (*g_4121)) ^ l_5415[4]))))
    { /* block id: 2390 */
        uint16_t l_5443[1][3];
        int32_t l_5450 = 0L;
        int32_t l_5451[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
        int32_t l_5483 = 0xBBA2C32DL;
        int8_t l_5497 = 0x78L;
        uint64_t ** const **l_5525 = (void*)0;
        uint32_t * const l_5550 = &g_4305[5][0][1].f0;
        int64_t *l_5644 = &g_5122;
        const uint32_t * const *l_5650[2];
        const uint32_t * const **l_5649[7][4][9] = {{{(void*)0,&l_5650[1],(void*)0,&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],(void*)0,&l_5650[1]},{&l_5650[1],&l_5650[0],&l_5650[1],(void*)0,&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],(void*)0},{(void*)0,&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[0],&l_5650[1]},{&l_5650[1],(void*)0,(void*)0,&l_5650[1],&l_5650[1],(void*)0,&l_5650[1],(void*)0,&l_5650[1]}},{{&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1]},{&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],(void*)0,&l_5650[1],&l_5650[0],&l_5650[1]},{&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[0]},{&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[0],&l_5650[1]}},{{&l_5650[1],(void*)0,&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],(void*)0,&l_5650[1],(void*)0},{&l_5650[1],&l_5650[1],&l_5650[1],(void*)0,&l_5650[1],&l_5650[0],&l_5650[0],&l_5650[1],&l_5650[1]},{&l_5650[0],&l_5650[0],(void*)0,&l_5650[0],&l_5650[1],(void*)0,&l_5650[1],&l_5650[1],(void*)0},{(void*)0,&l_5650[1],&l_5650[1],(void*)0,&l_5650[0],&l_5650[1],(void*)0,&l_5650[0],&l_5650[1]}},{{(void*)0,&l_5650[1],&l_5650[1],(void*)0,(void*)0,&l_5650[1],&l_5650[0],(void*)0,&l_5650[0]},{&l_5650[1],(void*)0,&l_5650[0],&l_5650[1],(void*)0,&l_5650[1],&l_5650[1],(void*)0,&l_5650[1]},{&l_5650[0],&l_5650[1],&l_5650[0],&l_5650[0],&l_5650[1],(void*)0,&l_5650[1],&l_5650[1],&l_5650[0]},{&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[1]}},{{&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],(void*)0,&l_5650[0],&l_5650[0],&l_5650[1]},{&l_5650[0],(void*)0,&l_5650[1],&l_5650[0],&l_5650[0],(void*)0,&l_5650[0],&l_5650[1],&l_5650[1]},{&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],(void*)0,(void*)0,(void*)0},{&l_5650[1],&l_5650[0],&l_5650[0],&l_5650[1],&l_5650[0],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1]}},{{&l_5650[1],(void*)0,&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[0]},{&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1]},{(void*)0,&l_5650[1],&l_5650[1],&l_5650[1],(void*)0,&l_5650[1],(void*)0,(void*)0,&l_5650[1]},{(void*)0,&l_5650[1],(void*)0,(void*)0,(void*)0,&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1]}},{{(void*)0,&l_5650[1],&l_5650[0],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[0]},{&l_5650[0],&l_5650[0],&l_5650[0],(void*)0,&l_5650[0],(void*)0,&l_5650[1],&l_5650[0],&l_5650[0]},{(void*)0,(void*)0,&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[0],&l_5650[1],&l_5650[0]},{&l_5650[1],&l_5650[1],&l_5650[0],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],&l_5650[1],(void*)0}}};
        const uint32_t * const ***l_5648 = &l_5649[1][2][1];
        const uint32_t * const *** const *l_5647 = &l_5648;
        uint16_t ****l_5663 = &g_3298[0][2];
        union U1 **l_5681 = &g_667;
        int64_t l_5743[3][6][6] = {{{0L,0x15E0D75C1533E3D6LL,0L,0xFEDCBF187DC4FF78LL,0xB166817E2077923FLL,0xFEDCBF187DC4FF78LL},{0x33FA0C341B3CBBEBLL,0x15E0D75C1533E3D6LL,0x33FA0C341B3CBBEBLL,0xFEDCBF187DC4FF78LL,0x70C29FD45F3C9464LL,0xFEDCBF187DC4FF78LL},{0L,0x15E0D75C1533E3D6LL,0L,0xFEDCBF187DC4FF78LL,0xB166817E2077923FLL,0xFEDCBF187DC4FF78LL},{0x33FA0C341B3CBBEBLL,0x15E0D75C1533E3D6LL,0x33FA0C341B3CBBEBLL,0xFEDCBF187DC4FF78LL,0x70C29FD45F3C9464LL,0xFEDCBF187DC4FF78LL},{0L,0x15E0D75C1533E3D6LL,0L,0xFEDCBF187DC4FF78LL,0xB166817E2077923FLL,0xFEDCBF187DC4FF78LL},{0x33FA0C341B3CBBEBLL,0x15E0D75C1533E3D6LL,0x33FA0C341B3CBBEBLL,0xFEDCBF187DC4FF78LL,0x70C29FD45F3C9464LL,0xFEDCBF187DC4FF78LL}},{{0L,0x15E0D75C1533E3D6LL,0L,0xFEDCBF187DC4FF78LL,0xB166817E2077923FLL,0xFEDCBF187DC4FF78LL},{0x33FA0C341B3CBBEBLL,0x15E0D75C1533E3D6LL,0x33FA0C341B3CBBEBLL,0xFEDCBF187DC4FF78LL,0x70C29FD45F3C9464LL,0xFEDCBF187DC4FF78LL},{0L,0x15E0D75C1533E3D6LL,0L,0xFEDCBF187DC4FF78LL,0xB166817E2077923FLL,0xFEDCBF187DC4FF78LL},{0x33FA0C341B3CBBEBLL,0x15E0D75C1533E3D6LL,0x33FA0C341B3CBBEBLL,0xFEDCBF187DC4FF78LL,0x70C29FD45F3C9464LL,0xFEDCBF187DC4FF78LL},{0L,0x15E0D75C1533E3D6LL,0L,0xFEDCBF187DC4FF78LL,0xB166817E2077923FLL,0xFEDCBF187DC4FF78LL},{0x33FA0C341B3CBBEBLL,0x15E0D75C1533E3D6LL,0x68C27D6222C7C0FBLL,2L,0x33FA0C341B3CBBEBLL,2L}},{{0L,0xFEDCBF187DC4FF78LL,0L,2L,0L,2L},{0x68C27D6222C7C0FBLL,0xFEDCBF187DC4FF78LL,0x68C27D6222C7C0FBLL,2L,0x33FA0C341B3CBBEBLL,2L},{0L,0xFEDCBF187DC4FF78LL,0L,2L,0L,2L},{0x68C27D6222C7C0FBLL,0xFEDCBF187DC4FF78LL,0x68C27D6222C7C0FBLL,2L,0x33FA0C341B3CBBEBLL,2L},{0L,0xFEDCBF187DC4FF78LL,0L,2L,0L,2L},{0x68C27D6222C7C0FBLL,0xFEDCBF187DC4FF78LL,0x68C27D6222C7C0FBLL,2L,0x33FA0C341B3CBBEBLL,2L}}};
        struct S0 ***l_5750 = &g_4675[1][1];
        uint32_t l_5821 = 0UL;
        const uint32_t l_5841 = 0xCF7D6F23L;
        int32_t **l_5887 = &l_5482[6][1][1];
        uint32_t l_5897 = 0x228BB147L;
        int16_t ***l_5906 = &g_1720[2][7][1];
        uint8_t l_5921 = 253UL;
        int8_t l_5924[9][5][5] = {{{(-9L),(-1L),0xFBL,2L,0x66L},{(-10L),3L,0xEAL,0xF4L,(-1L)},{(-1L),0x21L,(-1L),2L,(-1L)},{0L,0x7FL,4L,0xEAL,0xCCL},{(-4L),(-1L),0x3AL,0xD8L,0xE3L}},{{1L,(-1L),(-1L),(-1L),1L},{0x66L,0x3AL,0xF4L,0x14L,7L},{0x0BL,4L,0x1BL,(-1L),0L},{2L,0x53L,1L,0x3AL,7L},{0xAFL,(-1L),(-1L),8L,1L}},{{7L,0x4DL,0xF9L,0x0BL,0xE3L},{(-1L),0xCCL,0L,0L,0xCCL},{0L,0x11L,0xD8L,0x53L,(-1L)},{3L,0xDBL,0L,0xA7L,(-1L)},{0xF4L,1L,0x0BL,(-10L),0x66L}},{{3L,8L,0xCCL,(-10L),0L},{0L,0xFBL,(-9L),1L,0x7CL},{(-1L),0xD7L,0x7FL,0xCCL,0x7FL},{7L,7L,2L,0x11L,1L},{0xAFL,(-1L),0xD7L,0x0BL,0xF4L}},{{2L,1L,(-1L),0xE3L,0x14L},{0x0BL,(-1L),0L,3L,0xAFL},{0x66L,7L,0x4DL,0xF9L,0x0BL},{1L,0xD7L,0xCCL,0x1BL,0x1BL},{(-4L),0xFBL,(-4L),(-1L),(-1L)}},{{0L,8L,0xF4L,0x7FL,0L},{(-1L),1L,0x7CL,(-1L),0L},{(-10L),0xDBL,0xF4L,0L,0xCCL},{(-9L),0x11L,(-4L),(-1L),0x3AL},{0xEAL,0xCCL,0xCCL,(-1L),0xABL}},{{(-1L),(-1L),(-1L),0x4DL,0xFBL},{0xD7L,(-1L),0xEAL,0xB2L,(-1L)},{(-1L),1L,0x4DL,(-2L),0xF4L},{0xCCL,8L,3L,0xB2L,(-1L)},{(-1L),0x66L,7L,0x4DL,0xF9L}},{{0x0BL,0xCCL,0L,0xA7L,0xF4L},{(-1L),0xF4L,(-1L),0xF4L,(-1L)},{(-1L),0L,0L,(-1L),(-1L)},{0x14L,(-1L),0x7CL,(-1L),0x21L},{0xB2L,0xCCL,0L,0L,(-1L)}},{{2L,(-1L),0xE3L,1L,(-1L)},{(-1L),0xDBL,0x7FL,0xABL,0xF4L},{(-1L),0xF9L,0x3AL,0x3AL,0xF9L},{0L,0xAFL,0xA7L,0xCCL,(-1L)},{1L,(-9L),0xFBL,0L,0xF4L}}};
        uint16_t l_5925[3][1][7] = {{{0x03DAL,0x03DAL,0x03DAL,0x03DAL,0x03DAL,0x03DAL,0x03DAL}},{{0x7649L,65527UL,0x7649L,65527UL,0x7649L,65527UL,0x7649L}},{{0x03DAL,0x03DAL,0x03DAL,0x03DAL,0x03DAL,0x03DAL,0x03DAL}}};
        uint32_t l_5964 = 0x252CA40DL;
        int8_t l_5967 = 1L;
        uint64_t l_5975 = 0x5EF50B307D52BE1BLL;
        uint32_t l_6079[8][2][10] = {{{0x3B800CF7L,0xB77823B5L,1UL,0x06044354L,0UL,0xF963F398L,4294967295UL,4294967286UL,0x06044354L,1UL},{0x7FBBD6A5L,4294967286UL,4294967286UL,0x3B800CF7L,0xD852A571L,0xF963F398L,0x1961E201L,4294967295UL,0xCA509A94L,4294967295UL}},{{0x3B800CF7L,1UL,0xD549C9B6L,0xF963F398L,0x2436802CL,0UL,0x1961E201L,0x1961E201L,0UL,0x2436802CL},{1UL,4294967286UL,4294967286UL,1UL,4294967295UL,0xCA509A94L,4294967295UL,0x1961E201L,0xF963F398L,0xD852A571L}},{{0UL,0xB77823B5L,0xD549C9B6L,2UL,1UL,0x06044354L,4294967286UL,4294967295UL,0xF963F398L,0UL},{4294967295UL,2UL,4294967286UL,1UL,0UL,4294967295UL,0x3C260444L,4294967286UL,0UL,0UL}},{{2UL,4294967286UL,1UL,0xF963F398L,1UL,1UL,0xB77823B5L,0x3C260444L,0xCA509A94L,0xD852A571L},{2UL,0x7CF8B7DCL,0x1961E201L,0x3B800CF7L,4294967295UL,4294967295UL,0x7CF8B7DCL,0xB77823B5L,0x06044354L,0x2436802CL}},{{4294967295UL,0x7CF8B7DCL,0xB77823B5L,0x06044354L,0x2436802CL,0x06044354L,0xB77823B5L,0x7CF8B7DCL,4294967295UL,4294967295UL},{0UL,4294967286UL,0xB77823B5L,1UL,0xD852A571L,0xCA509A94L,0xCA509A94L,0xA78922F7L,1UL,1UL}},{{1UL,1UL,0x3B800CF7L,3UL,0x99A94B97L,0x4DA864F0L,0xF963F398L,0xCA509A94L,0x23D75A30L,0x0DD08CEFL},{4294967295UL,0xA78922F7L,4294967295UL,1UL,0x99A94B97L,0x266FAC67L,2UL,0xF963F398L,1UL,1UL}},{{0xAE9FE5A5L,0xF963F398L,0x7FBBD6A5L,4294967295UL,4294967286UL,0x266FAC67L,0x3B800CF7L,2UL,2UL,4294967295UL},{4294967295UL,1UL,0x06044354L,0x266FAC67L,0x4B49F724L,0x4DA864F0L,0x3B800CF7L,0x3B800CF7L,0x4DA864F0L,0x4B49F724L}},{{1UL,0xF963F398L,0xF963F398L,1UL,4294967295UL,2UL,2UL,0x3B800CF7L,0x266FAC67L,4294967286UL},{0x4DA864F0L,0xA78922F7L,0x06044354L,4294967295UL,1UL,1UL,0xF963F398L,2UL,0x266FAC67L,0x99A94B97L}}};
        int64_t l_6088 = 0x543CA07867A91BADLL;
        int32_t l_6093 = 0x58D9C24BL;
        int64_t l_6103 = 0x4FEA1BFF32140F2ELL;
        uint16_t l_6117 = 0x7E1DL;
        uint32_t l_6190 = 0UL;
        int32_t l_6267 = 0x8F08032DL;
        union U2 ****l_6273 = &g_5752[5];
        union U2 *****l_6272[6] = {&l_6273,&l_6273,&l_6273,&l_6273,&l_6273,&l_6273};
        int8_t l_6293 = (-8L);
        uint8_t l_6294 = 6UL;
        uint8_t * const *l_6297 = &g_1768[1][1][2];
        uint8_t * const **l_6296[2];
        int32_t *l_6299 = &g_3480.f8;
        int32_t l_6319[10];
        uint64_t **l_6417 = &g_914;
        uint32_t l_6454 = 18446744073709551615UL;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
                l_5443[i][j] = 2UL;
        }
        for (i = 0; i < 2; i++)
            l_5650[i] = &l_5426;
        for (i = 0; i < 2; i++)
            l_6296[i] = &l_6297;
        for (i = 0; i < 10; i++)
            l_6319[i] = 4L;
        for (p_14 = 0; (p_14 > (-22)); p_14--)
        { /* block id: 2393 */
            int32_t * const l_5446[3] = {&g_2305,&g_2305,&g_2305};
            int32_t **l_5447[5][10] = {{(void*)0,(void*)0,&g_1122,&g_89,&g_1122,&g_89,&g_1122,(void*)0,(void*)0,(void*)0},{&g_89,&g_1122,(void*)0,(void*)0,(void*)0,&g_1465[5][2],&g_3423,&g_1465[4][0],&g_3423,&g_1465[2][2]},{&g_3423,&g_1122,&g_3423,(void*)0,&g_3423,&g_1465[0][4],&g_1465[0][4],&g_3423,(void*)0,&g_3423},{&g_1465[4][0],&g_1465[4][0],(void*)0,&g_89,&g_1122,&g_1465[4][0],(void*)0,&g_89,&g_3423,&g_1465[4][0]},{&g_1122,&g_89,&g_3423,&g_3423,&g_1465[0][4],&g_3423,(void*)0,&g_89,(void*)0,&g_3423}};
            int32_t **l_5448[3][1][9] = {{{&g_1465[4][0],&g_1465[1][3],&g_3423,&g_1465[1][3],&g_1465[4][0],&g_1465[4][0],&g_1465[1][3],&g_3423,&g_1465[1][3]}},{{&g_1465[1][3],&g_1122,&g_3423,&g_3423,&g_1122,&g_1465[1][3],&g_1122,&g_3423,&g_3423}},{{&g_1465[4][0],&g_1465[4][0],&g_1465[1][3],&g_3423,&g_1465[1][3],&g_1465[4][0],&g_1465[4][0],&g_1465[1][3],&g_3423}}};
            int32_t **l_5449 = &g_3423;
            int i, j, k;
            l_5443[0][2]--;
            if (p_15)
                continue;
            (*l_5449) = l_5446[0];
        }
        for (g_945.f2 = 0; (g_945.f2 <= 5); g_945.f2 += 1)
        { /* block id: 2400 */
            uint32_t l_5463 = 0UL;
            int32_t **l_5480[7][7][5] = {{{&g_2687,(void*)0,&g_2687,&g_2687,&g_2687},{&g_2687,(void*)0,(void*)0,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,(void*)0},{(void*)0,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,(void*)0},{(void*)0,&g_2687,&g_2687,&g_2687,&g_2687}},{{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,(void*)0,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,(void*)0,(void*)0,&g_2687,&g_2687}},{{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,(void*)0,&g_2687},{&g_2687,&g_2687,(void*)0,&g_2687,&g_2687},{&g_2687,(void*)0,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{(void*)0,&g_2687,&g_2687,&g_2687,&g_2687},{(void*)0,&g_2687,&g_2687,&g_2687,&g_2687}},{{(void*)0,(void*)0,&g_2687,&g_2687,(void*)0},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,(void*)0,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,(void*)0,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{(void*)0,&g_2687,&g_2687,&g_2687,&g_2687}},{{(void*)0,&g_2687,&g_2687,&g_2687,(void*)0},{(void*)0,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,(void*)0},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,(void*)0,&g_2687}},{{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,(void*)0,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,(void*)0,(void*)0,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,(void*)0},{&g_2687,&g_2687,&g_2687,(void*)0,&g_2687},{&g_2687,&g_2687,(void*)0,&g_2687,&g_2687}},{{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,(void*)0,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687},{&g_2687,&g_2687,(void*)0,&g_2687,&g_2687},{&g_2687,&g_2687,&g_2687,&g_2687,&g_2687}}};
            int16_t l_5484 = 0L;
            uint32_t *l_5485 = &g_5203.f0;
            int32_t *l_5487 = &g_964[1].f3;
            int32_t *l_5488 = &g_960.f3;
            int32_t *l_5489 = &g_980.f3;
            int32_t *l_5490 = (void*)0;
            int32_t *l_5491[9][7] = {{&g_3586[8][0].f8,&g_3586[8][0].f8,(void*)0,(void*)0,&g_3586[8][0].f8,&g_3586[8][0].f8,&g_2120.f8},{&g_3756.f3,&g_3586[8][0].f8,&g_81,(void*)0,&g_3480.f8,&g_4161[0][8],&l_5451[8]},{(void*)0,(void*)0,&g_3480.f8,(void*)0,&g_4906.f8,&g_2305,&g_2305},{&l_5451[8],&g_3586[8][0].f8,(void*)0,&g_2305,&g_4161[0][8],&g_3586[8][0].f8,(void*)0},{&g_3480.f8,&g_3586[8][0].f8,(void*)0,(void*)0,&g_4677.f8,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_2121.f8,(void*)0,(void*)0,&g_2305},{&l_5383,(void*)0,&g_2305,&g_3586[8][0].f8,(void*)0,&g_3756.f3,&l_5451[8]},{&g_2121.f8,(void*)0,&g_2851.f8,&g_4906.f8,(void*)0,(void*)0,&g_2120.f8},{&g_2851.f8,&g_81,&g_3756.f3,(void*)0,&g_4677.f8,&g_2121.f8,&g_2121.f8}};
            uint32_t * const *l_5500[1];
            uint32_t * const **l_5499 = &l_5500[0];
            uint32_t * const ***l_5498 = &l_5499;
            const int64_t **l_5563 = (void*)0;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_5500[i] = &g_351;
            if ((p_12 | ((*g_249) = 8L)))
            { /* block id: 2402 */
                int32_t *l_5452 = &g_2305;
                int32_t *l_5453 = (void*)0;
                int32_t *l_5454 = &g_957[2][2].f3;
                int32_t *l_5455 = &g_4969.f8;
                int32_t *l_5456 = &g_4525.f3;
                int32_t *l_5457 = &g_90;
                int32_t *l_5458 = &g_5334[6][1].f3;
                int32_t *l_5459 = &g_981.f3;
                int32_t *l_5460 = (void*)0;
                int32_t *l_5461 = &g_1639.f3;
                int32_t *l_5462[9] = {&g_991.f3,&g_2121.f8,&g_2121.f8,&g_991.f3,&g_2121.f8,&g_2121.f8,&g_991.f3,&g_2121.f8,&g_2121.f8};
                int i;
                --l_5463;
            }
            else
            { /* block id: 2404 */
                uint32_t l_5466 = 4294967295UL;
                l_5466 = ((*g_1122) = (l_5377[3] && ((*g_1341) = 0L)));
            }
            l_5391[0] ^= ((*g_1122) = (l_5486 = (+(((7L <= p_12) & ((*l_5485) = ((((*g_1341) = ((safe_div_func_int64_t_s_s((safe_rshift_func_int8_t_s_s((((safe_mod_func_uint8_t_u_u(p_14, (safe_lshift_func_int32_t_s_s(0x5038926DL, 23)))) < (((safe_rshift_func_uint32_t_u_s(p_15, 16)) <= (l_5451[8] ^ ((((safe_div_func_int64_t_s_s((((l_5481 = &p_14) != l_5482[6][1][1]) == (((l_5377[1] || l_5408) != (**g_4120)) || 1UL)), l_5483)) , 0xBDB0L) | p_14) != p_15))) , 0xFE67L)) < 0x19L), l_5484)), (*g_249))) >= 1L)) && (-1L)) && p_12))) & l_5443[0][1]))));
            for (g_961.f0 = 0; (g_961.f0 <= 2); g_961.f0 += 1)
            { /* block id: 2417 */
                const int8_t l_5508 = 1L;
                int32_t l_5527 = 0xAE7B8B81L;
                uint32_t *l_5549 = &g_5203.f0;
                struct S0 *l_5580 = (void*)0;
                (*l_5487) = (l_5391[0] = (safe_rshift_func_int32_t_s_s(((0xDFL != (safe_rshift_func_uint8_t_u_u(((((p_13 &= 0L) == (l_5383 = (((l_5496 == (l_5497 , l_5498)) == (0x2DL | 0x2BL)) == ((0xEB6AL & ((safe_lshift_func_int64_t_s_u(((safe_add_func_int64_t_s_s(((safe_sub_func_uint32_t_u_u((!((((-7L) == 0xF7L) <= 0xE1B4549CL) , l_5508)), l_5508)) , p_14), 0x83C89E6B8192519FLL)) <= p_12), l_5508)) > 0x857A656FL)) , l_5391[0])))) >= p_12) , 0x22L), 6))) ^ p_12), 31)));
                for (g_458.f0 = 0; (g_458.f0 <= 2); g_458.f0 += 1)
                { /* block id: 2424 */
                    struct S0 **l_5512[10] = {&g_4676[0],&g_4676[4],&g_4676[0],&g_4676[0],&g_4676[4],&g_4676[0],&g_4676[4],&g_4676[0],&g_4676[0],&g_4676[4]};
                    uint8_t *l_5552 = &g_110;
                    int32_t l_5553[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_5553[i] = (-6L);
                    if ((&g_3374 == &g_3374))
                    { /* block id: 2425 */
                        uint64_t *****l_5523 = (void*)0;
                        uint64_t *****l_5524 = &g_3325;
                        int16_t *l_5526[3][6][3] = {{{&g_4907.f3,&g_4907.f3,&g_4677.f3},{&g_4907.f3,&g_4907.f3,&g_4907.f3},{&g_4677.f3,&g_4907.f3,&g_98},{&g_2120.f3,&g_4907.f3,&g_4969.f3},{&g_4677.f3,&g_4677.f3,&g_4969.f3},{&g_4907.f3,&g_2120.f3,&g_98}},{{&g_4907.f3,&g_4677.f3,&g_4907.f3},{&g_4907.f3,&g_4907.f3,&g_4677.f3},{&g_4907.f3,&g_4907.f3,&g_4907.f3},{&g_4677.f3,&g_4907.f3,&g_98},{&g_2120.f3,&g_4907.f3,&g_4969.f3},{&g_4677.f3,&g_4677.f3,&g_4969.f3}},{{&g_4907.f3,&g_2120.f3,&g_98},{&g_4907.f3,&g_4677.f3,&g_4907.f3},{&g_4907.f3,&g_4907.f3,&g_4677.f3},{&g_4907.f3,&g_4907.f3,&g_4907.f3},{&g_4677.f3,&g_4907.f3,&g_98},{&g_2120.f3,&g_4907.f3,&g_4969.f3}}};
                        int32_t l_5551 = (-10L);
                        int i, j, k;
                        (*g_1122) = (safe_rshift_func_uint16_t_u_s(p_14, ((~(l_5512[7] == (void*)0)) | (p_13 || ((l_5527 &= (((*l_5524) = ((safe_rshift_func_int8_t_s_s(((*g_768) ^= (((18446744073709551606UL <= (safe_lshift_func_uint16_t_u_s((1L > ((safe_div_func_int32_t_s_s(((safe_lshift_func_uint32_t_u_s(p_15, ((((*g_249) = (safe_sub_func_int8_t_s_s(p_14, (0L && 0x5DL)))) , (***g_2312)) , l_5408))) <= 0xA732111BAFE837D2LL), 0xAD59CF39L)) == p_12)), 6))) == p_12) < 0x8025L)), l_5383)) , (void*)0)) != l_5525)) | 0x8776L)))));
                        (*g_1122) |= (safe_add_func_uint64_t_u_u((safe_sub_func_int64_t_s_s((safe_mul_func_uint64_t_u_u((g_5534 != ((safe_rshift_func_int8_t_s_s((l_5451[8] ^= (((*g_771) | (safe_sub_func_int64_t_s_s(((void*)0 != &g_3325), (safe_mul_func_int64_t_s_s(0x15D04D609123B8BELL, (((((safe_mod_func_int16_t_s_s((safe_div_func_uint64_t_u_u(p_12, 3L)), (safe_div_func_int8_t_s_s((p_14 , ((safe_lshift_func_int32_t_s_s((((***g_2638) = l_5549) != l_5550), (*g_1341))) && 0x730B93BCL)), l_5483)))) < l_5551) , p_13) , &p_15) != l_5552)))))) ^ 0x6E9B0606L)), l_5553[1])) , l_5377[1])), l_5415[4])), 0UL)), l_5415[4]));
                        if (l_5551)
                            continue;
                        l_5451[8] |= (safe_rshift_func_uint32_t_u_s(p_15, 10));
                    }
                    else
                    { /* block id: 2436 */
                        uint16_t l_5556 = 0x61B8L;
                        int32_t **l_5557 = (void*)0;
                        int32_t **l_5558 = &l_5489;
                        l_5556 ^= l_5450;
                        (*l_5558) = &l_5553[1];
                    }
                    if ((safe_sub_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_u(8UL, 5)) , ((void*)0 != l_5563)), (((**g_1236) | (((*g_1237) < ((safe_lshift_func_uint8_t_u_s(((*l_5552)++), 1)) , (((0xCE2E3DA8L != (safe_rshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_lshift_func_int32_t_s_u(0x5CE9937FL, l_5443[0][2])), (safe_unary_minus_func_int16_t_s(((safe_add_func_int64_t_s_s((safe_lshift_func_int8_t_s_s((safe_unary_minus_func_int16_t_s((-1L))), p_13)), l_5486)) && (-5L)))))), l_5415[4]))) == l_5451[2]) && 0x9FE85D69FCF483F2LL))) & l_5486)) & l_5391[0]))))
                    { /* block id: 2441 */
                        const int32_t *l_5581 = &l_5391[0];
                        const int32_t **l_5582[9][10][1] = {{{&l_5581},{(void*)0},{&l_5581},{&l_5581},{&l_5581},{&l_5581},{(void*)0},{&l_5581},{&l_5581},{&l_5581}},{{&l_5581},{(void*)0},{&l_5581},{&l_5581},{&g_633},{&l_5581},{&g_633},{&g_633},{&l_5581},{&g_633}},{{&l_5581},{(void*)0},{&g_633},{&g_633},{&l_5581},{&l_5581},{&l_5581},{&l_5581},{&g_633},{&g_633}},{{&l_5581},{&l_5581},{&l_5581},{&l_5581},{&g_633},{&g_633},{(void*)0},{&l_5581},{&g_633},{&l_5581}},{{(void*)0},{&l_5581},{&l_5581},{(void*)0},{&g_633},{&l_5581},{&l_5581},{&l_5581},{&l_5581},{&g_633}},{{(void*)0},{&l_5581},{(void*)0},{&g_633},{&l_5581},{&l_5581},{&l_5581},{&l_5581},{&g_633},{(void*)0}},{{&l_5581},{&l_5581},{(void*)0},{&l_5581},{(void*)0},{&l_5581},{&l_5581},{(void*)0},{(void*)0},{&l_5581}},{{(void*)0},{&l_5581},{&l_5581},{(void*)0},{(void*)0},{&l_5581},{&l_5581},{(void*)0},{&l_5581},{(void*)0}},{{(void*)0},{&l_5581},{&l_5581},{(void*)0},{&l_5581},{(void*)0},{&l_5581},{&l_5581},{(void*)0},{&g_633}}};
                        int i, j, k;
                        (*g_2118) = l_5580;
                        g_633 = l_5581;
                        (*g_1341) = p_13;
                    }
                    else
                    { /* block id: 2445 */
                        uint32_t l_5583 = 1UL;
                        --l_5583;
                        return p_12;
                    }
                }
            }
            for (g_1639.f0 = 0; (g_1639.f0 <= 1); g_1639.f0 += 1)
            { /* block id: 2453 */
                uint8_t *l_5594[9] = {&g_110,&g_110,&g_110,&g_110,&g_110,&g_110,&g_110,&g_110,&g_110};
                int32_t l_5614[3];
                int16_t *l_5615 = &g_2851.f3;
                uint16_t l_5617 = 65535UL;
                int i;
                for (i = 0; i < 3; i++)
                    l_5614[i] = 0x93345236L;
                (*g_1122) = (g_5616 |= (safe_sub_func_int32_t_s_s((((*g_771) = (((safe_add_func_uint8_t_u_u((l_5391[1] = ((l_5391[g_1639.f0] == (safe_lshift_func_uint16_t_u_s((safe_rshift_func_int32_t_s_s(p_14, 9)), 3))) <= p_15)), ((safe_sub_func_int16_t_s_s(((*l_5615) ^= (safe_add_func_uint8_t_u_u(((g_5599 != l_5603) == ((((0UL == (safe_add_func_uint32_t_u_u(((*l_5485)++), (l_5609 &= l_5377[1])))) ^ (safe_add_func_int32_t_s_s((safe_mod_func_uint8_t_u_u(0x9FL, (l_5614[1] = 255UL))), 1L))) >= 0x4D9DL) | p_13)), 0x44L))), 0xC01BL)) == 0xBD1D53A1L))) , 65535UL) && p_13)) ^ p_14), p_15)));
                l_5617++;
                for (g_54 = 0; (g_54 <= 2); g_54 += 1)
                { /* block id: 2465 */
                    uint32_t l_5620 = 0x0B60C782L;
                    if ((l_5620 > (l_5383 , (safe_mod_func_int64_t_s_s(l_5614[0], (safe_sub_func_uint16_t_u_u(p_13, l_5625)))))))
                    { /* block id: 2466 */
                        return p_13;
                    }
                    else
                    { /* block id: 2468 */
                        if (l_5620)
                            break;
                        (*g_1341) &= p_15;
                    }
                    (*g_1122) ^= (l_5443[0][2] >= l_5391[g_1639.f0]);
                    return l_5620;
                }
            }
        }
        for (g_981.f2 = 2; (g_981.f2 >= 0); g_981.f2 -= 1)
        { /* block id: 2479 */
            uint8_t *l_5632 = &g_4686;
            uint16_t **l_5637 = &g_1237;
            int64_t *l_5643 = (void*)0;
            int32_t l_5651 = 0x6A601643L;
            union U1 ****l_5672 = (void*)0;
            int32_t l_5694 = (-1L);
            int32_t l_5695 = 0xC6A9CA42L;
            const uint32_t l_5807 = 4294967292UL;
            int32_t l_6089 = (-1L);
            int32_t l_6091 = 0L;
            int32_t l_6092 = (-8L);
            int32_t l_6097[4];
            uint32_t l_6193[4][9][1] = {{{0xEEB60C6CL},{1UL},{0x7FEE9CF6L},{1UL},{0xEEB60C6CL},{0xDEEABB9FL},{1UL},{0x8789983BL},{1UL}},{{0xDEEABB9FL},{0xEEB60C6CL},{1UL},{0x7FEE9CF6L},{1UL},{0xEEB60C6CL},{0xDEEABB9FL},{1UL},{0x8789983BL}},{{1UL},{0xDEEABB9FL},{0xEEB60C6CL},{1UL},{0x7FEE9CF6L},{1UL},{0xEEB60C6CL},{0xDEEABB9FL},{1UL}},{{0x8789983BL},{1UL},{0xDEEABB9FL},{0xEEB60C6CL},{1UL},{0x7FEE9CF6L},{1UL},{0xEEB60C6CL},{0xDEEABB9FL}}};
            int32_t l_6199 = 0x2D0FE58DL;
            uint32_t **l_6224[1];
            union U2 * const *l_6227 = &g_457;
            int32_t l_6245 = 0x355D5C22L;
            uint16_t l_6329[3];
            uint8_t l_6418 = 0x6EL;
            uint16_t *** const *l_6483 = &g_3298[0][0];
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_6097[i] = 1L;
            for (i = 0; i < 1; i++)
                l_6224[i] = &g_2314[0][5];
            for (i = 0; i < 3; i++)
                l_6329[i] = 65535UL;
        }
    }
    else
    { /* block id: 2817 */
        int32_t l_6511[6];
        uint8_t * const *l_6588 = &g_1768[0][5][2];
        uint8_t * const **l_6587 = &l_6588;
        uint32_t * const ****l_6601 = (void*)0;
        int32_t *l_6605 = &l_5383;
        int i;
        for (i = 0; i < 6; i++)
            l_6511[i] = 0x3EAB8EDAL;
lbl_6604:
        for (g_668.f3 = 1; (g_668.f3 >= 0); g_668.f3 -= 1)
        { /* block id: 2820 */
            int64_t **l_6518[6] = {&g_249,&g_249,&g_249,&g_249,&g_249,&g_249};
            int32_t l_6522 = 2L;
            int16_t *l_6523 = &g_1365.f2;
            uint64_t l_6580 = 0UL;
            int32_t *l_6593 = (void*)0;
            int i;
            (*g_1122) |= (65535UL <= ((safe_div_func_int16_t_s_s((((*g_927) = (*g_927)) != (void*)0), ((*l_6523) = ((safe_mod_func_int64_t_s_s((l_6511[5] & p_14), (safe_lshift_func_uint32_t_u_u((safe_mul_func_uint64_t_u_u((((*g_914) |= (((((l_5391[0] = (safe_rshift_func_int32_t_s_s((((void*)0 != l_6518[4]) , l_6104), ((+((l_6522 >= p_15) && 0L)) , l_6511[2])))) < 0xD3C0L) | 0xFCFF20AA4E0E2665LL) , p_15) & 0L)) , l_6522), l_6511[2])), 22)))) , p_13)))) , p_14));
            for (g_744 = 7; (g_744 >= 0); g_744 -= 1)
            { /* block id: 2828 */
                int16_t l_6549 = 0L;
                int8_t * const ***l_6565 = (void*)0;
                int8_t * const ****l_6564 = &l_6565;
                int32_t l_6568[3][5][8] = {{{0x76522452L,4L,0L,0L,4L,0x76522452L,4L,0L},{0x2C7A2E42L,4L,0x2C7A2E42L,0x76522452L,0x76522452L,0x2C7A2E42L,4L,0x2C7A2E42L},{1L,0x76522452L,0L,0x76522452L,1L,1L,0x76522452L,0L},{1L,1L,0x76522452L,0L,0x76522452L,1L,1L,0x76522452L},{0x2C7A2E42L,0x76522452L,0x76522452L,0x2C7A2E42L,4L,0x2C7A2E42L,0x76522452L,0x76522452L}},{{0x76522452L,4L,0L,0L,4L,0x76522452L,4L,0L},{0x2C7A2E42L,4L,0x2C7A2E42L,0x76522452L,0x76522452L,0x2C7A2E42L,4L,0x2C7A2E42L},{1L,0x76522452L,0L,0x76522452L,1L,1L,0x76522452L,0L},{1L,1L,0x76522452L,0L,0x76522452L,1L,1L,0x76522452L},{0x2C7A2E42L,0x76522452L,0x76522452L,0x2C7A2E42L,4L,0x2C7A2E42L,0x76522452L,0x76522452L}},{{0x76522452L,4L,0L,0L,4L,0x76522452L,4L,0L},{0x2C7A2E42L,4L,0L,0x2C7A2E42L,0x2C7A2E42L,0L,1L,0L},{0x76522452L,0x2C7A2E42L,4L,0x2C7A2E42L,0x76522452L,0x76522452L,0x2C7A2E42L,4L},{0x76522452L,0x76522452L,0x2C7A2E42L,4L,0x2C7A2E42L,0x76522452L,0x76522452L,0x2C7A2E42L},{0L,0x2C7A2E42L,0x2C7A2E42L,0L,1L,0L,0x2C7A2E42L,0x2C7A2E42L}}};
                uint8_t ***l_6573 = &g_1767;
                int32_t **l_6584 = &l_5481;
                int32_t ***l_6583 = &l_6584;
                int32_t **l_6592[4][3][10] = {{{&g_3423,&g_89,&g_6591,&g_1465[4][0],&g_3423,&g_1465[5][1],&g_1465[1][1],&g_6591,&g_1465[3][4],&g_1465[1][1]},{&g_1465[5][3],&g_89,&g_1122,&g_3423,&g_89,&g_1122,(void*)0,&g_1465[4][4],&g_1465[5][1],&g_3423},{&g_1465[4][4],&g_1465[4][3],(void*)0,&g_1465[5][3],&g_1465[4][0],&g_1122,&g_3423,&g_6591,(void*)0,&g_1465[4][0]}},{{(void*)0,&g_6591,&g_3423,&g_1465[3][4],&g_1465[4][4],&g_89,&g_1122,&g_6591,&g_89,(void*)0},{&g_1465[5][3],&g_1465[4][0],(void*)0,&g_6591,&g_1465[1][5],&g_6591,&g_89,&g_89,&g_6591,&g_1465[1][5]},{&g_1465[2][5],&g_89,&g_89,&g_1465[2][5],(void*)0,&g_1465[4][3],&g_1465[1][5],&g_89,&g_1465[4][0],&g_1465[4][0]}},{{&g_89,&g_1465[4][4],&g_3423,&g_1465[5][1],(void*)0,(void*)0,&g_89,&g_1465[1][5],&g_1465[4][0],&g_1465[5][1]},{&g_1465[4][0],(void*)0,&g_1465[1][0],&g_1465[2][5],&g_89,&g_1465[4][0],(void*)0,&g_3423,&g_6591,&g_3423},{&g_3423,&g_6591,(void*)0,&g_6591,(void*)0,(void*)0,&g_1465[1][5],(void*)0,&g_89,&g_1465[4][4]}},{{&g_3423,&g_3423,&g_1122,&g_1465[3][4],&g_3423,&g_89,&g_89,&g_1465[1][5],(void*)0,&g_1465[4][3]},{&g_1465[1][5],(void*)0,&g_1465[5][1],&g_1465[5][3],&g_6591,&g_1465[4][0],&g_6591,&g_1465[5][3],&g_1465[5][1],(void*)0},{&g_3423,&g_3423,&g_89,&g_3423,&g_1465[4][3],&g_3423,&g_1465[1][5],&g_3423,&g_1465[3][4],&g_1465[1][5]}}};
                int i, j, k;
                (*g_1341) = (((*g_1237) = (g_4207[(g_744 + 2)] < ((safe_sub_func_uint8_t_u_u((p_15 , p_14), ((((((l_6511[5] != ((safe_lshift_func_uint64_t_u_s((safe_add_func_int16_t_s_s((safe_div_func_int8_t_s_s(l_6511[5], (safe_mod_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u(((safe_lshift_func_uint32_t_u_u((((safe_mod_func_uint64_t_u_u(((safe_mul_func_int16_t_s_s((safe_unary_minus_func_int16_t_s(l_6522)), (safe_sub_func_uint64_t_u_u(18446744073709551612UL, (safe_lshift_func_int8_t_s_u(((p_13 != ((((((((safe_sub_func_int32_t_s_s((p_14 & (*g_768)), g_4207[(g_744 + 2)])) >= p_14) && l_6549) ^ l_6378) <= l_6511[5]) ^ p_12) && 0x4A89A9C018F2CCCCLL) , p_12)) >= 0xBAD662C6L), 6)))))) ^ 18446744073709551615UL), l_6549)) == 0xC6AB2831L) >= p_12), l_6511[5])) , 3UL), l_5486)), p_14)))), l_6522)), l_6522)) > l_6511[4])) < 7L) < l_6549) > 0x4215E1ABE8F21009LL) < 0x678DC2A8L) | p_13))) , 255UL))) == (*g_5215));
                for (g_4906.f2 = 0; (g_4906.f2 <= 1); g_4906.f2 += 1)
                { /* block id: 2833 */
                    uint32_t *l_6569 = &l_5972;
                    uint8_t *l_6572 = &g_750[0];
                    int32_t l_6575 = (-1L);
                    int32_t l_6576 = (-1L);
                    int32_t l_6578 = 0xEC334572L;
                    int32_t l_6579 = 0x14AC9FD4L;
                    int i, j, k;
                    if (((safe_div_func_uint32_t_u_u((safe_lshift_func_uint64_t_u_s(((safe_rshift_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_u(g_2936[g_4906.f2][(g_668.f3 + 2)][(g_668.f3 + 2)], 0)) < (((((safe_div_func_int64_t_s_s((((p_15--) | 0x94L) || (((**g_1236) = (safe_lshift_func_uint32_t_u_s((((l_5391[0] = (&g_4182 != l_6564)) ^ g_2936[g_668.f3][(g_4906.f2 + 2)][g_4906.f2]) == (safe_mod_func_uint32_t_u_u(g_2936[g_668.f3][g_668.f3][g_744], (++(*l_6569))))), g_2936[g_668.f3][g_668.f3][(g_4906.f2 + 6)]))) , (((*l_6572) ^= p_14) , (l_6511[1] ^ l_6568[2][2][7])))), p_13)) & p_14) && p_12) > l_6568[0][2][3]) > l_6522)) , 0x80D7L), l_5609)) != l_6568[0][2][1]), 4)), l_6522)) > l_6549))
                    { /* block id: 2839 */
                        int32_t *l_6574[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_6574[i] = (void*)0;
                        (*g_5076) = l_6573;
                        if (g_176)
                            goto lbl_5905;
                        l_6580--;
                    }
                    else
                    { /* block id: 2843 */
                        (*g_1122) ^= (l_6104 || (l_5391[0] = l_6568[0][3][6]));
                    }
                }
                (*l_6583) = &g_2687;
                l_6593 = &l_6522;
            }
            (*g_6591) |= l_6511[5];
            for (g_4415.f0 = 0; (g_4415.f0 <= 1); g_4415.f0 += 1)
            { /* block id: 2856 */
                (*g_1341) = p_14;
                return l_5979[0][4][0];
            }
        }
        for (g_960.f0 = (-9); (g_960.f0 > 53); g_960.f0++)
        { /* block id: 2863 */
            if (((((void*)0 != &g_2748) <= (*g_1341)) ^ (((safe_mul_func_uint16_t_u_u(((void*)0 != (**l_6587)), ((((((safe_unary_minus_func_uint16_t_u((p_14 ^ l_6246))) , ((safe_mod_func_uint64_t_u_u((&p_15 != (void*)0), p_15)) != p_14)) && l_6511[5]) , l_6601) != &l_5646) , l_6602[3][2][1]))) ^ 5L) <= p_12)))
            { /* block id: 2864 */
                (*g_1913) = l_6603[3];
            }
            else
            { /* block id: 2866 */
                if (g_4968.f2)
                    goto lbl_6604;
                (*g_6591) = 1L;
                return p_14;
            }
        }
        l_6605 = &l_6511[3];
    }
    return (*g_5215);
}


/* ------------------------------------------ */
/* 
 * reads : g_1122 g_90 g_1341 g_914 g_3586.f5 g_573
 * writes: g_90 g_1342
 */
static uint64_t  func_16(int32_t  p_17, const int8_t  p_18)
{ /* block id: 2336 */
    uint32_t l_5361 = 1UL;
    uint32_t *****l_5364 = &g_2638;
    int32_t l_5369 = 0x4C5AC0CFL;
    l_5369 = (((l_5361 <= 0x28698FB82667EE02LL) , 0x4533L) , ((p_17 = (safe_mod_func_int16_t_s_s((((l_5364 != &g_1036) , (safe_sub_func_int32_t_s_s(0x23008FFDL, p_17))) & (l_5361 , (safe_mod_func_int32_t_s_s(((*g_1341) = ((*g_1122) ^= (((l_5361 , 0x958AC76FL) , 0xDDD6L) , p_17))), l_5361)))), p_17))) >= l_5361));
    return (*g_914);
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_51 g_1042.f0 g_54 g_914 g_573 g_89 g_98 g_849 g_2312 g_2313 g_2314 g_2118 g_90 g_768 g_929 g_248 g_249 g_176 g_1341 g_1236 g_1237 g_244 g_927 g_928 g_771 g_2053 g_2054 g_1122 g_1342 g_2936 g_2637 g_2638 g_1054 g_1055 g_1037 g_350 g_607.f0 g_3163 g_1111.f3 g_973.f3 g_3175 g_997 g_749 g_550 g_969.f0 g_978.f0 g_1937 g_3423 g_3297 g_3298 g_3518 g_3556 g_2851.f8 g_2687 g_457 g_117 g_81 g_110 g_184 g_211 g_10 g_400 g_420 g_421 g_2017.f3 g_1913 g_1340 g_3620.f8 g_3756.f2 g_3879 g_1042.f2 g_750 g_602.f0 g_962.f0 g_3963 g_3830 g_589.f3 g_4120 g_4123 g_3620.f3 g_1282 g_985.f2 g_4161 g_4182 g_3586.f3 g_2594 g_1720 g_2639 g_4251 g_966.f0 g_2121.f8 g_3326 g_3586.f8 g_3586.f5 g_4121 g_3620.f5 g_723.f2 g_2640 g_4447 g_1895.f2 g_4407 g_3480.f6 g_2745 g_458.f0 g_2851.f3 g_3325 g_4673 g_4686 g_1365.f2 g_965.f3 g_973.f2 g_458.f3
 * writes: g_54 g_1042.f0 g_90 g_98 g_2119 g_2220.f0 g_901 g_849 g_51 g_987.f0 g_1342 g_2606 g_573 g_176 g_244 g_2054 g_981.f0 g_2996 g_1465 g_977.f2 g_2220.f3 g_589.f3 g_607.f0 g_248 g_3163 g_1111.f3 g_2220.f2 g_973.f3 g_997 g_976.f2 g_982.f3 g_607.f3 g_749 g_550 g_969.f0 g_978.f0 g_3480.f3 g_721.f3 g_2851.f8 g_2936 g_966.f2 g_984.f3 g_963.f2 g_3325 g_3686 g_971.f2 g_81 g_89 g_110 g_117 g_184 g_211 g_336 g_400 g_421 g_2017.f3 g_744 g_748 g_952.f3 g_928 g_3830 g_41 g_3518 g_3620.f8 g_3756.f2 g_1042.f2 g_2121.f3 g_589.f0 g_750 g_914 g_980.f2 g_602.f0 g_962.f0 g_1767 g_2312 g_3620.f3 g_1282 g_985.f2 g_3586.f3 g_2639 g_4251 g_987.f3 g_966.f0 g_2121.f8 g_2314 g_4406 g_3586.f5 g_723.f2 g_351 g_1895.f2 g_457 g_2745 g_458.f0 g_3620.f5 g_2851.f3 g_4686 g_1365.f2 g_965.f3 g_2120.f5 g_3963 g_3423 g_979.f3 g_973.f2 g_458.f3 g_969.f2 g_4677.f2 g_668.f3 g_947.f3 g_4906.f8 g_2313 g_3588.f5
 */
static uint64_t  func_22(uint32_t  p_23, int32_t  p_24, uint8_t  p_25, uint64_t  p_26, const int16_t  p_27)
{ /* block id: 1 */
    uint32_t l_42[8] = {1UL,0x0A3418EBL,1UL,1UL,0x0A3418EBL,1UL,1UL,0x0A3418EBL};
    struct S0 *l_3479 = &g_3480;
    struct S0 **l_3478[5][3][5] = {{{&l_3479,(void*)0,(void*)0,&l_3479,(void*)0},{&l_3479,&l_3479,&l_3479,&l_3479,&l_3479},{(void*)0,&l_3479,(void*)0,(void*)0,&l_3479}},{{&l_3479,(void*)0,(void*)0,&l_3479,(void*)0},{&l_3479,&l_3479,&l_3479,&l_3479,&l_3479},{(void*)0,&l_3479,(void*)0,(void*)0,&l_3479}},{{&l_3479,(void*)0,(void*)0,(void*)0,&l_3479},{(void*)0,(void*)0,&l_3479,(void*)0,(void*)0},{&l_3479,(void*)0,&l_3479,&l_3479,(void*)0}},{{(void*)0,&l_3479,&l_3479,(void*)0,&l_3479},{(void*)0,(void*)0,&l_3479,(void*)0,(void*)0},{&l_3479,(void*)0,&l_3479,&l_3479,(void*)0}},{{(void*)0,&l_3479,&l_3479,(void*)0,&l_3479},{(void*)0,(void*)0,&l_3479,(void*)0,(void*)0},{&l_3479,(void*)0,&l_3479,&l_3479,(void*)0}}};
    uint16_t *l_3481 = &g_550;
    int32_t *l_5357[7] = {(void*)0,&g_3480.f8,&g_3480.f8,(void*)0,&g_3480.f8,&g_3480.f8,(void*)0};
    uint8_t l_5358 = 0UL;
    int i, j, k;
    l_5358 ^= (func_28((safe_div_func_uint8_t_u_u(func_36(g_41, l_42[5], p_26, ((p_25--) <= (((*l_3481) &= (((l_42[5] > (safe_div_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u(func_49(g_51[4][2][2]), 4)), (safe_mod_func_uint64_t_u_u(p_26, (safe_lshift_func_uint16_t_u_u(((safe_mod_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u(65527UL, 7)), (safe_add_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((safe_mul_func_int16_t_s_s(((((l_3478[0][2][3] != (void*)0) > p_24) >= p_24) | l_42[4]), l_42[5])), 18446744073709551607UL)), p_27)))) , l_42[5]), 13))))))) || p_24) >= 0xCA28L)) == p_23))), 0x04L)), l_42[5], l_42[5], l_42[6], p_26) < p_24);
    return p_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_914 g_3586.f5 g_573 g_3297 g_3298 g_1236 g_1237 g_244 g_2745 g_768 g_3423 g_2851.f8 g_1341 g_4120 g_4121 g_3620.f5 g_771 g_51 g_3325 g_3326 g_249 g_4673 g_1122 g_4686 g_1365.f2 g_849 g_90 g_965.f3 g_3963 g_2312 g_2313 g_2314 g_41 g_176 g_81 g_1342 g_750 g_184 g_4407 g_3480.f6 g_1054 g_1055 g_973.f2 g_2118 g_3586.f8 g_458.f0 g_2851.f3 g_458.f3
 * writes: g_244 g_2745 g_51 g_2851.f8 g_458.f0 g_1342 g_3586.f5 g_573 g_3620.f5 g_2851.f3 g_176 g_90 g_4686 g_1365.f2 g_965.f3 g_2120.f5 g_3963 g_81 g_1767 g_750 g_3423 g_1465 g_184 g_744 g_748 g_979.f3 g_973.f2 g_458.f3 g_969.f2 g_4677.f2 g_668.f3 g_947.f3 g_4906.f8 g_2119 g_2313 g_3588.f5
 */
static uint8_t  func_28(int64_t  p_29, uint32_t  p_30, int64_t  p_31, int32_t  p_32, const uint64_t  p_33)
{ /* block id: 1970 */
    uint16_t *l_4544 = &g_2745;
    struct S0 ***l_4550 = (void*)0;
    struct S0 ****l_4549 = &l_4550;
    struct S0 *****l_4548 = &l_4549;
    int32_t l_4553 = (-1L);
    uint8_t l_4554 = 8UL;
    uint64_t l_4555 = 0xE932EB66CF8E74D0LL;
    uint64_t *l_4568 = &g_3620.f5;
    uint64_t **l_4573[2][1];
    uint64_t *l_4574 = &g_184;
    int16_t ***l_4579 = &g_1720[2][7][1];
    int8_t **l_4587 = &g_771;
    int8_t ***l_4586 = &l_4587;
    int8_t ****l_4585 = &l_4586;
    int32_t l_4607 = 0L;
    uint32_t l_4609 = 0x4DCEBE09L;
    int32_t l_4638[9][7][4] = {{{0L,1L,(-1L),0x17F13B58L},{7L,0x3CF8E821L,0x88A8A095L,(-1L)},{0xA1878C3CL,0xD4011D43L,0xA1878C3CL,0x8A2B4C7AL},{1L,(-1L),0x9EA8A35CL,0L},{0x9A12CBEFL,3L,(-8L),(-1L)},{(-4L),2L,(-8L),1L},{0x9A12CBEFL,(-6L),0x9EA8A35CL,(-4L)}},{{1L,0xA31894FCL,0xA1878C3CL,4L},{0xA1878C3CL,4L,0x88A8A095L,0L},{7L,(-3L),(-1L),0x0C1D5E80L},{0L,0x641D896CL,6L,1L},{0xE463A389L,7L,(-1L),7L},{0xC0FE8FB8L,4L,0L,3L},{0xB8DB3185L,(-1L),3L,0x6C4407F4L}},{{7L,0x933C14A6L,0xD8EACDA7L,3L},{0x0C1D5E80L,0xD4011D43L,(-4L),0x17F13B58L},{0x3CF8E821L,(-1L),0x9EA8A35CL,9L},{0L,4L,0x1C23FD81L,(-1L)},{0x53325B8EL,(-3L),(-3L),0x53325B8EL},{0x9A12CBEFL,0x8A2B4C7AL,(-1L),0x0C1D5E80L},{0x933C14A6L,0xA31894FCL,(-4L),6L}},{{0x2EB24400L,0x1A1CE282L,0x88A8A095L,6L},{0x1C23FD81L,0xA31894FCL,0xC0FE8FB8L,0x0C1D5E80L},{0xB8DB3185L,0x8A2B4C7AL,4L,0x53325B8EL},{0xE463A389L,(-3L),7L,(-1L)},{3L,4L,6L,9L},{0x28897AFAL,(-1L),3L,0x17F13B58L},{0x1C23FD81L,0xD4011D43L,0x2EE27637L,3L}},{{0xA1878C3CL,0x933C14A6L,0x0C1D5E80L,0x6C4407F4L},{0x3CF8E821L,(-1L),(-1L),3L},{3L,4L,(-8L),7L},{0x6187655EL,7L,(-3L),1L},{0L,0x641D896CL,1L,0x0C1D5E80L},{1L,(-3L),0x0C1D5E80L,0L},{0x2EB24400L,4L,0xD8EACDA7L,4L}},{{(-3L),(-1L),0x0B6CEE07L,1L},{0x0C1D5E80L,(-3L),1L,4L},{6L,0x6187655EL,(-8L),0x1C23FD81L},{6L,0L,1L,0x17F13B58L},{0x0C1D5E80L,0x1C23FD81L,0x0B6CEE07L,0xE5FC1339L},{0x53325B8EL,0x9A12CBEFL,1L,0x0B6CEE07L},{(-1L),3L,4L,0xA31894FCL}},{{9L,7L,0xD8EACDA7L,0x6C4407F4L},{0x17F13B58L,0L,0x53325B8EL,(-8L)},{3L,0x53325B8EL,(-1L),0xC0FE8FB8L},{0x6C4407F4L,0xFD56B3A4L,0x63957BBCL,1L},{3L,0x9EA8A35CL,4L,0xD4011D43L},{7L,0x3CF8E821L,0xC55312F0L,1L},{1L,1L,0L,7L}},{{0x0C1D5E80L,0xE5FC1339L,0xD4011D43L,0xC0FE8FB8L},{0L,0x6187655EL,2L,2L},{4L,4L,1L,0x641D896CL},{(-4L),7L,6L,0xE5FC1339L},{1L,0L,0xB8DB3185L,6L},{(-1L),0L,1L,0xE5FC1339L},{0L,7L,0x63957BBCL,0x641D896CL}},{{0x8A2B4C7AL,4L,0x53325B8EL,2L},{(-1L),0x6187655EL,1L,0xC0FE8FB8L},{0x17F13B58L,0xE5FC1339L,0x2EE27637L,7L},{3L,1L,1L,1L},{4L,0x3CF8E821L,1L,0xD4011D43L},{(-4L),0x9EA8A35CL,0L,1L},{(-4L),0xFD56B3A4L,0L,0xC0FE8FB8L}}};
    const uint8_t l_4730 = 0UL;
    int8_t l_4742 = 0xA6L;
    uint8_t **l_4754 = (void*)0;
    int32_t *l_4830 = (void*)0;
    int16_t *l_4837 = &g_1365.f2;
    uint16_t l_4887 = 65526UL;
    int64_t ***l_4956[5][7];
    uint32_t * const *l_4982 = &g_2314[0][2];
    int32_t l_5013 = 0x937227D9L;
    uint32_t *****l_5017 = &g_2638;
    const uint32_t l_5102 = 0x1433A52CL;
    int16_t l_5124[4];
    union U1 *l_5202 = &g_5203;
    int32_t l_5246 = 0xD365C0F8L;
    const uint32_t *l_5264 = &g_5265;
    int32_t l_5306 = 0xA5CFABE2L;
    uint16_t l_5354 = 1UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_4573[i][j] = (void*)0;
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
            l_4956[i][j] = (void*)0;
    }
    for (i = 0; i < 4; i++)
        l_5124[i] = (-3L);
    (*g_3423) &= (((safe_rshift_func_uint64_t_u_u((((*g_768) = ((((*g_914) == 1L) <= ((****g_3297) = (****g_3297))) < (safe_mod_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s((safe_mul_func_int32_t_s_s(((((*l_4544) |= (p_33 | p_29)) && (safe_mul_func_uint64_t_u_u((+((((void*)0 == l_4548) , (safe_lshift_func_uint16_t_u_s((l_4553 || (0x4A769E6FL < l_4553)), 13))) <= l_4554)), (-7L)))) | 0x2EL), l_4555)), 14)), 5)), 0xF3B3L)))) > p_30), 29)) , l_4554) == 0x63L);
lbl_4965:
    for (g_458.f0 = 0; (g_458.f0 == 7); ++g_458.f0)
    { /* block id: 1977 */
        (*g_1341) = p_30;
    }
    if ((safe_mod_func_int64_t_s_s((safe_mul_func_int16_t_s_s((safe_add_func_uint16_t_u_u(((--(*g_914)) ^ (safe_div_func_uint64_t_u_u(18446744073709551607UL, (l_4554 && (((((*l_4568) = (**g_4120)) , (safe_sub_func_uint32_t_u_u((((safe_add_func_int64_t_s_s(((l_4574 = &l_4555) != &p_33), (safe_lshift_func_uint64_t_u_s(((safe_lshift_func_uint8_t_u_s((l_4579 == &g_1720[2][7][1]), (((0L && (safe_lshift_func_uint16_t_u_u((l_4553 ^ 1UL), 2))) || l_4554) || l_4555))) > 0x06E5L), 40)))) && 18446744073709551606UL) == l_4555), 0xF4B4B49CL))) != l_4553) <= (-8L)))))), l_4554)), 0L)), l_4555)))
    { /* block id: 1983 */
        int8_t ***l_4583 = (void*)0;
        int8_t ****l_4582[7] = {&l_4583,&l_4583,&l_4583,&l_4583,&l_4583,&l_4583,&l_4583};
        uint8_t l_4596 = 1UL;
        uint16_t l_4597[10][3] = {{65528UL,0xCA0AL,0x1B00L},{1UL,1UL,0x1B00L},{0xCA0AL,65528UL,0x1B00L},{65528UL,0xCA0AL,0x1B00L},{1UL,1UL,0x1B00L},{0xCA0AL,65528UL,0x1B00L},{65528UL,0xCA0AL,0x1B00L},{1UL,1UL,0x1B00L},{0xCA0AL,65528UL,0x1B00L},{65528UL,0xCA0AL,0x1B00L}};
        int32_t l_4598 = 8L;
        int32_t l_4606 = 0x6F94ADABL;
        uint32_t l_4680[6] = {18446744073709551607UL,18446744073709551607UL,18446744073709551614UL,18446744073709551607UL,18446744073709551607UL,18446744073709551614UL};
        int32_t l_4684 = (-10L);
        int32_t l_4685 = 0x02D36866L;
        int64_t **l_4720 = &g_249;
        uint32_t *****l_4764 = &g_2638;
        const int8_t l_4829 = 0L;
        int64_t l_4853 = 9L;
        int8_t l_4864 = 0x57L;
        int32_t l_4880 = (-1L);
        int32_t l_4882 = 7L;
        int32_t l_4883[1];
        int32_t l_4884 = 1L;
        int64_t l_4886 = (-1L);
        struct S0 *l_4905[10] = {&g_4908,&g_4908,&g_4906,&g_4908,&g_4908,&g_4906,&g_4908,&g_4908,&g_4906,&g_4908};
        uint16_t ****l_4921 = (void*)0;
        uint16_t *****l_4920 = &l_4921;
        uint64_t **l_4936 = &l_4574;
        int i, j;
        for (i = 0; i < 1; i++)
            l_4883[i] = 1L;
lbl_4749:
        for (g_2851.f3 = 0; (g_2851.f3 <= 0); g_2851.f3 += 1)
        { /* block id: 1986 */
            int8_t *****l_4584 = &l_4582[5];
            int32_t l_4599 = (-5L);
            int32_t l_4608[2];
            union U1 **l_4657 = &g_667;
            struct S0 ****l_4678 = &l_4550;
            int32_t *l_4681 = &l_4638[1][1][2];
            int32_t *l_4682 = (void*)0;
            int32_t *l_4683[4][4][2] = {{{&l_4607,(void*)0},{&l_4607,&l_4638[1][1][2]},{&g_4161[0][5],&g_3588.f8},{&l_4638[1][1][2],(void*)0}},{{&l_4608[0],&l_4606},{&l_4599,&l_4638[1][1][2]},{&l_4638[1][1][2],&g_4161[0][5]},{&g_4677.f8,&g_4161[0][5]}},{{&l_4638[1][1][2],&l_4638[1][1][2]},{&l_4599,&l_4606},{&l_4608[0],(void*)0},{&l_4638[1][1][2],&g_3588.f8}},{{&g_4161[0][5],&l_4638[1][1][2]},{&l_4607,&l_4638[1][1][2]},{(void*)0,&l_4599},{&g_4677.f8,&g_2120.f8}}};
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_4608[i] = 0x3D060EDEL;
            if (((((((*l_4584) = l_4582[5]) != l_4585) & (((safe_sub_func_uint16_t_u_u(1UL, 1L)) == (safe_mul_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u((((*g_249) = ((((***l_4586) |= l_4554) , ((*g_3325) == (*g_3325))) , (((safe_rshift_func_int32_t_s_u((l_4555 <= (-1L)), p_32)) == p_30) , l_4554))) , l_4596), l_4553)) || p_29), l_4597[7][2]))) | l_4554)) ^ 65527UL) , l_4597[7][2]))
            { /* block id: 1990 */
                int32_t l_4600[8];
                int32_t *l_4601 = &l_4553;
                int32_t *l_4602 = &g_1342;
                int32_t *l_4603 = &g_978.f3;
                int32_t *l_4604 = (void*)0;
                int32_t *l_4605[3][4][2] = {{{&g_90,&g_90},{&g_90,(void*)0},{&g_90,&g_90},{&g_90,(void*)0}},{{&g_90,&g_90},{&g_90,(void*)0},{&g_90,&g_90},{&g_90,(void*)0}},{{&g_90,&g_90},{&g_90,(void*)0},{&g_90,&g_90},{&g_90,(void*)0}}};
                int i, j, k;
                for (i = 0; i < 8; i++)
                    l_4600[i] = (-5L);
                if (p_29)
                    break;
                l_4609++;
            }
            else
            { /* block id: 1993 */
                int32_t l_4637 = (-4L);
                union U1 **l_4658 = &g_667;
                uint8_t *l_4679 = &l_4554;
                l_4638[1][1][2] &= ((safe_mod_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(l_4596, (safe_lshift_func_uint32_t_u_u((safe_lshift_func_uint32_t_u_u(p_33, 31)), ((((((*g_771) >= ((!((safe_mod_func_int32_t_s_s((l_4607 = ((safe_sub_func_int64_t_s_s(((safe_mod_func_int8_t_s_s((safe_add_func_uint64_t_u_u((safe_add_func_uint32_t_u_u(4294967294UL, ((safe_mul_func_int32_t_s_s((safe_mod_func_int16_t_s_s((((l_4553 = (((void*)0 != &g_2054[6]) ^ ((safe_add_func_uint64_t_u_u((*g_4121), (0xA228102D8EADAD00LL >= (1L < 0xDCE3L)))) && l_4599))) , p_31) ^ l_4637), p_33)), 0xF3B63973L)) != l_4608[0]))), (*g_914))), p_33)) , p_32), (**g_4120))) >= p_31)), 0xBE3C6850L)) , l_4608[1])) != (-4L))) || l_4554) && 5L) || p_33) && l_4609))))), p_30)) <= 1L);
                (*g_1122) = (~(p_32 , (safe_mul_func_uint64_t_u_u(((safe_mod_func_uint32_t_u_u(3UL, l_4597[0][2])) & ((safe_mod_func_int8_t_s_s((+((*g_1341) = ((safe_mul_func_uint16_t_u_u(((((safe_rshift_func_uint64_t_u_s((safe_mul_func_int16_t_s_s((l_4608[0] = (((safe_sub_func_uint8_t_u_u(((*l_4679) |= ((safe_add_func_uint64_t_u_u(((((l_4657 = (void*)0) != l_4658) < ((*l_4544) = (p_33 ^ ((safe_div_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((safe_rshift_func_int64_t_s_u((safe_lshift_func_int8_t_s_s(((safe_rshift_func_int64_t_s_s(p_32, 47)) == (safe_div_func_uint64_t_u_u((safe_lshift_func_int16_t_s_u(((l_4678 = g_4673) != (void*)0), l_4597[3][0])), l_4597[0][0]))), l_4606)), p_31)), 15)), l_4596)) <= p_30)))) != 1UL), (**g_4120))) , 9UL)), l_4680[2])) >= l_4553) == l_4608[0])), l_4609)), p_33)) || l_4608[1]) || p_29) >= p_31), p_29)) & (-7L)))), 0x2EL)) , l_4555)), l_4599))));
            }
            g_4686++;
            for (g_1365.f2 = 0; (g_1365.f2 <= 4); g_1365.f2 += 1)
            { /* block id: 2008 */
                int64_t ** const *l_4696 = &g_248;
                int64_t ** const **l_4695 = &l_4696;
                int64_t ** const ***l_4697 = (void*)0;
                int64_t ** const ***l_4698 = &l_4695;
                int i, j;
                (*g_1122) &= (safe_add_func_int32_t_s_s((g_849[g_1365.f2][g_1365.f2] == ((0x807B8FDB146E2101LL || l_4597[7][2]) ^ ((****l_4585) |= (safe_sub_func_int16_t_s_s(((safe_add_func_uint64_t_u_u(p_30, ((((*l_4698) = l_4695) == (void*)0) >= (((l_4598 &= (safe_add_func_uint8_t_u_u(((safe_lshift_func_uint64_t_u_u(l_4638[2][2][0], p_30)) && (p_30 || 1UL)), 0x3BL))) == l_4554) , p_30)))) == l_4638[2][3][2]), p_32))))), 7L));
                p_32 = (p_32 < l_4554);
            }
        }
        for (g_965.f3 = 5; (g_965.f3 >= 0); g_965.f3 -= 1)
        { /* block id: 2018 */
            uint16_t l_4736[3];
            int32_t l_4741 = 0xE7AA22D6L;
            const int32_t l_4743[2] = {0xC0994689L,0xC0994689L};
            uint8_t ***l_4755 = (void*)0;
            uint8_t ***l_4756 = &g_1767;
            uint8_t *l_4760 = &g_750[2];
            uint32_t *****l_4763 = &g_2638;
            uint8_t l_4790 = 1UL;
            const int8_t ***l_4796 = (void*)0;
            uint64_t **l_4812 = &l_4568;
            const int16_t *l_4836[5] = {&g_4207[0],&g_4207[0],&g_4207[0],&g_4207[0],&g_4207[0]};
            int16_t l_4844 = 0xC034L;
            int32_t l_4862 = 0x001DE70AL;
            uint16_t l_4869 = 0xD6CDL;
            int32_t l_4879 = 0x33969445L;
            int32_t l_4881[3][8][9] = {{{0L,(-1L),0x33032BE8L,0xA207B63AL,0x33032BE8L,(-1L),0L,0x3A6DAAF6L,(-1L)},{0x981995CFL,1L,0x031D7558L,0xEA9184F1L,1L,(-1L),5L,(-4L),0x031D7558L},{0xA207B63AL,0x031D7558L,0xEFF37A09L,0xB1CD3BD6L,(-1L),1L,0x09B70637L,0x3A6DAAF6L,(-1L)},{0xA207B63AL,0x7A7FA0BEL,1L,(-2L),0x7A7FA0BEL,0x031D7558L,0xB1CD3BD6L,0x33032BE8L,0L},{0x981995CFL,(-4L),0xEFF37A09L,0x02AAAF23L,0x7A7FA0BEL,0x7A7FA0BEL,0x02AAAF23L,0xEFF37A09L,(-4L)},{0L,(-9L),0x031D7558L,5L,(-1L),(-4L),0xB1CD3BD6L,1L,(-4L)},{5L,0xEFF37A09L,0x33032BE8L,3L,1L,(-9L),0x09B70637L,0x031D7558L,0L},{0x09B70637L,(-9L),1L,3L,0x33032BE8L,0xEFF37A09L,5L,(-9L),(-1L)}},{{0xB1CD3BD6L,(-4L),(-1L),5L,0x031D7558L,(-9L),0L,(-9L),0x031D7558L},{0x02AAAF23L,0x7A7FA0BEL,0x7A7FA0BEL,0x02AAAF23L,0xEFF37A09L,(-4L),0x981995CFL,0x031D7558L,(-1L)},{0xB1CD3BD6L,0x031D7558L,0x7A7FA0BEL,(-2L),1L,0x7A7FA0BEL,0xA207B63AL,1L,0x33032BE8L},{0x09B70637L,1L,(-1L),0xB1CD3BD6L,0xEFF37A09L,0x031D7558L,0xA207B63AL,0xEFF37A09L,1L},{5L,(-1L),1L,0xEA9184F1L,0x031D7558L,1L,0x981995CFL,0x33032BE8L,0x33032BE8L},{0L,(-1L),0x33032BE8L,0xA207B63AL,0x33032BE8L,(-1L),0L,0x3A6DAAF6L,(-1L)},{0x981995CFL,1L,0x031D7558L,0xEA9184F1L,1L,(-1L),5L,(-4L),0x031D7558L},{0xA207B63AL,0x031D7558L,0xEFF37A09L,0xB1CD3BD6L,(-1L),1L,0x09B70637L,0x3A6DAAF6L,(-1L)}},{{0xA207B63AL,0x7A7FA0BEL,1L,(-2L),0x7A7FA0BEL,0x031D7558L,0xB1CD3BD6L,0x33032BE8L,0L},{0x981995CFL,(-4L),0x82599842L,0x031D7558L,(-1L),(-1L),0x031D7558L,0x82599842L,5L},{0L,5L,7L,1L,0xA28AB1C0L,5L,(-4L),0x0574AFD1L,5L},{1L,0x82599842L,(-3L),(-1L),(-9L),5L,1L,7L,0xE7EE68A2L},{1L,5L,(-9L),(-1L),(-3L),0x82599842L,1L,5L,4L},{(-4L),5L,0xA28AB1C0L,1L,7L,5L,0L,5L,7L},{0x031D7558L,(-1L),(-1L),0x031D7558L,0x82599842L,5L,1L,7L,0xA28AB1C0L},{(-4L),7L,(-1L),0x7A7FA0BEL,1L,(-1L),0xEFF37A09L,0x0574AFD1L,(-3L)}}};
            int8_t l_4885 = 0x5CL;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_4736[i] = 2UL;
            for (g_2120.f5 = 1; (g_2120.f5 <= 5); g_2120.f5 += 1)
            { /* block id: 2021 */
                int16_t *l_4707 = (void*)0;
                int16_t *l_4708 = (void*)0;
                int16_t *l_4709 = &g_2220.f3;
                int16_t *l_4710 = &g_2220.f3;
                int16_t *l_4711 = &g_4305[5][0][1].f3;
                int16_t *l_4712 = &g_607.f2;
                int16_t *l_4713 = &g_4305[5][0][1].f3;
                int16_t *l_4714 = (void*)0;
                int16_t *l_4715 = &g_3963;
                int64_t ***l_4721 = &g_248;
                int64_t ***l_4722 = (void*)0;
                int64_t ***l_4723 = &l_4720;
                uint8_t *l_4735[10][3] = {{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554},{&l_4554,&l_4554,&l_4554}};
                int32_t l_4745 = 0x96777C8EL;
                int i, j;
                (*g_1341) = (((((safe_div_func_int64_t_s_s(((*g_249) |= ((safe_div_func_uint16_t_u_u(0x6B99L, ((*l_4715) |= l_4680[g_965.f3]))) && (safe_div_func_uint8_t_u_u((l_4609 & p_32), (safe_lshift_func_int16_t_s_u(((((*l_4723) = l_4720) == (void*)0) || (safe_add_func_uint32_t_u_u((0x2FL == (l_4741 = (safe_lshift_func_int8_t_s_u((safe_add_func_uint64_t_u_u(l_4730, ((safe_rshift_func_int32_t_s_s((safe_rshift_func_uint8_t_u_s((++l_4736[1]), (((((safe_mul_func_int16_t_s_s((((***g_2312) , 0x9EL) & p_31), 9UL)) , p_30) != 4L) , l_4741) , 0L))), 27)) && p_30))), 5)))), p_33))), l_4742)))))), l_4743[0])) > (-3L)) >= p_33) , 0L) , l_4680[g_965.f3]);
                if ((*g_3423))
                { /* block id: 2028 */
                    uint16_t l_4744[8] = {7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL};
                    int i;
                    (*g_3423) = (*g_1122);
                    return l_4744[3];
                }
                else
                { /* block id: 2031 */
                    uint8_t l_4746 = 9UL;
                    l_4746--;
                }
                if (l_4553)
                    goto lbl_4749;
            }
            (*g_1341) = (l_4736[1] ^ ((safe_add_func_int16_t_s_s((-4L), ((safe_div_func_uint32_t_u_u((0L > (((*l_4756) = l_4754) != (void*)0)), p_33)) >= p_31))) ^ (~((l_4742 , ((safe_add_func_uint8_t_u_u((((((((++(*l_4760)) , l_4763) != l_4764) > 0x1E16L) > l_4743[0]) , l_4607) ^ p_32), p_33)) , 0L)) | l_4553))));
            if (p_31)
            { /* block id: 2039 */
                int32_t l_4767 = (-2L);
                const int8_t *l_4794 = &g_4795[7][2];
                const int8_t **l_4793 = &l_4794;
                const int8_t ***l_4792[4][5][8] = {{{&l_4793,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0,&l_4793},{(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0,(void*)0},{&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793},{&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793},{&l_4793,(void*)0,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793}},{{(void*)0,&l_4793,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0},{&l_4793,&l_4793,&l_4793,&l_4793,(void*)0,&l_4793,&l_4793,&l_4793},{&l_4793,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0,&l_4793},{(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0,(void*)0},{&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793}},{{&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793},{&l_4793,(void*)0,(void*)0,(void*)0,(void*)0,&l_4793,(void*)0,(void*)0},{&l_4793,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793},{(void*)0,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0},{(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0}},{{&l_4793,(void*)0,(void*)0,&l_4793,(void*)0,(void*)0,&l_4793,&l_4793},{(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,(void*)0,&l_4793,(void*)0},{&l_4793,(void*)0,&l_4793,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793},{(void*)0,&l_4793,&l_4793,(void*)0,(void*)0,&l_4793,(void*)0,(void*)0},{&l_4793,(void*)0,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793,&l_4793}}};
                const int8_t ****l_4791[4][1][5] = {{{&l_4792[1][2][7],(void*)0,(void*)0,&l_4792[1][2][7],&l_4792[3][0][0]}},{{&l_4792[1][2][7],(void*)0,(void*)0,&l_4792[1][2][7],&l_4792[3][0][0]}},{{&l_4792[1][2][7],(void*)0,(void*)0,&l_4792[1][2][7],&l_4792[3][0][0]}},{{&l_4792[1][2][7],(void*)0,(void*)0,&l_4792[1][2][7],&l_4792[3][0][0]}}};
                int16_t *l_4797 = &g_2033.f2;
                int16_t *l_4798[10] = {(void*)0,(void*)0,(void*)0,(void*)0,&g_2017.f3,(void*)0,(void*)0,(void*)0,(void*)0,&g_2017.f3};
                int32_t *l_4799 = (void*)0;
                int32_t **l_4800 = (void*)0;
                int32_t **l_4801 = &g_3423;
                uint64_t **l_4813[5][2][3];
                int i, j, k;
                for (i = 0; i < 5; i++)
                {
                    for (j = 0; j < 2; j++)
                    {
                        for (k = 0; k < 3; k++)
                            l_4813[i][j][k] = &l_4574;
                    }
                }
                for (l_4553 = 0; (l_4553 <= 2); l_4553 += 1)
                { /* block id: 2042 */
                    int32_t **l_4765 = &g_3423;
                    int32_t **l_4766 = &g_1465[4][0];
                    (*l_4766) = ((*l_4765) = &l_4606);
                    return l_4767;
                }
                (*l_4801) = &p_32;
                l_4830 = ((*l_4801) = func_58((safe_sub_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((safe_add_func_int16_t_s_s((p_32 && p_31), ((((l_4684 &= (safe_div_func_uint16_t_u_u((****g_3297), (**l_4801)))) >= (((*l_4574) ^= l_4736[2]) >= (l_4597[7][1] ^ ((l_4812 == l_4813[4][1][0]) > ((safe_sub_func_uint8_t_u_u((((((safe_add_func_int32_t_s_s((safe_mod_func_int16_t_s_s((safe_lshift_func_uint32_t_u_s(((safe_rshift_func_uint32_t_u_s((((*g_1341) = (safe_unary_minus_func_int16_t_s((safe_mul_func_int64_t_s_s((safe_sub_func_int64_t_s_s(((-6L) | (-2L)), p_32)), 18446744073709551611UL))))) , l_4596), p_30)) && 1UL), (*g_1122))), l_4829)), (-2L))) , 0L) <= l_4685) != l_4607) || (*g_4407)), l_4741)) , 0x12L))))) && l_4606) || 0x35749F27L))), 0x16FB4D76L)), (*g_4407))), l_4638[1][1][2])), l_4680[2], l_4553, p_31, l_4742));
            }
            else
            { /* block id: 2057 */
                int32_t ** const l_4831 = &g_1122;
                int64_t ** const l_4858 = &g_249;
                int32_t l_4863 = 8L;
                int32_t l_4865 = 3L;
                if ((((((p_33 , (l_4831 == &l_4830)) , l_4790) == 0x3A9B49C1L) , (**l_4831)) <= ((((safe_mul_func_uint32_t_u_u(l_4596, ((((safe_sub_func_int8_t_s_s(p_29, 0xC9L)) | 6L) || p_29) , p_29))) | (**g_4120)) , (void*)0) != (void*)0)))
                { /* block id: 2058 */
                    (*g_3423) &= (((l_4836[0] != (l_4837 = (void*)0)) > (((safe_rshift_func_int16_t_s_s((safe_add_func_uint8_t_u_u((l_4598 , l_4685), (l_4844 <= ((**g_4120) == (((safe_add_func_uint8_t_u_u((0x21EE6433L & (--p_30)), ((**l_4831) , (safe_div_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s((--(*l_4760)), ((safe_sub_func_uint32_t_u_u((**l_4831), p_31)) , (*g_768)))), p_31))))) & 0x1377L) < p_32))))), p_29)) <= 0L) , (*g_768))) ^ 0x444DL);
                }
                else
                { /* block id: 2063 */
                    uint32_t l_4866 = 4294967289UL;
                    for (g_979.f3 = 0; (g_979.f3 <= 8); g_979.f3 += 1)
                    { /* block id: 2066 */
                        int64_t ***l_4859 = &l_4720;
                        int32_t l_4860 = (-1L);
                        int32_t *l_4861[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_4861[i] = &g_945.f3;
                        (*l_4859) = l_4858;
                        (*g_1341) = (l_4860 = l_4790);
                        l_4866--;
                    }
                    return l_4869;
                }
                if (l_4790)
                    break;
            }
            for (g_973.f2 = 0; (g_973.f2 <= 8); g_973.f2 += 1)
            { /* block id: 2078 */
                int32_t *l_4870 = (void*)0;
                int32_t *l_4871 = &g_960.f3;
                int32_t *l_4872 = &g_987.f3;
                int32_t *l_4873 = &g_986.f3;
                int32_t *l_4874 = &g_4522.f3;
                int32_t *l_4875 = &l_4741;
                int32_t *l_4876 = &g_721.f3;
                int32_t *l_4877 = &g_956[0].f3;
                int32_t *l_4878[6] = {&g_3480.f8,&g_3480.f8,&g_3480.f8,&g_3480.f8,&g_3480.f8,&g_3480.f8};
                int i;
                l_4887++;
            }
        }
        for (g_458.f3 = 0; (g_458.f3 < (-14)); g_458.f3--)
        { /* block id: 2084 */
            int64_t l_4896 = 7L;
            int32_t l_4917 = 0x311E614BL;
            uint64_t **l_4939 = &l_4574;
            int32_t l_4945 = 4L;
            for (g_969.f2 = 0; (g_969.f2 < (-21)); g_969.f2 = safe_sub_func_uint64_t_u_u(g_969.f2, 6))
            { /* block id: 2087 */
                (*g_1341) |= (*g_1122);
                if (p_30)
                    continue;
            }
            if (((safe_rshift_func_int64_t_s_u(p_30, (((((l_4896 | (safe_mod_func_uint8_t_u_u(((safe_add_func_int64_t_s_s(p_31, ((safe_add_func_int32_t_s_s(((safe_rshift_func_uint64_t_u_s(((void*)0 != l_4905[4]), 15)) < (*g_768)), (((safe_div_func_int16_t_s_s((+((safe_mod_func_uint32_t_u_u(((safe_add_func_int8_t_s_s(l_4896, (!l_4917))) != (safe_mod_func_uint32_t_u_u((l_4553 = (&g_2748 == l_4920)), p_29))), l_4598)) <= l_4917)), l_4638[1][1][2])) >= p_30) , l_4597[8][1]))) != (*g_3423)))) , p_32), p_29))) , p_29) , l_4880) ^ 3UL) ^ l_4829))) < 0x30272312L))
            { /* block id: 2092 */
                int32_t *l_4922 = &g_81;
                for (p_32 = 0; (p_32 <= 0); p_32 += 1)
                { /* block id: 2095 */
                    for (g_4677.f2 = 0; (g_4677.f2 <= 0); g_4677.f2 += 1)
                    { /* block id: 2098 */
                        int i;
                        l_4922 = &l_4883[g_4677.f2];
                    }
                }
            }
            else
            { /* block id: 2102 */
                uint64_t **l_4937 = (void*)0;
                uint64_t ***l_4938[8][9][3] = {{{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],(void*)0,&l_4573[0][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],(void*)0,&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[0][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{(void*)0,&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],(void*)0},{&l_4573[1][0],(void*)0,(void*)0}},{{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],&l_4573[1][0],&l_4573[1][0]},{(void*)0,(void*)0,&l_4573[1][0]},{(void*)0,(void*)0,(void*)0},{(void*)0,&l_4573[1][0],(void*)0},{&l_4573[0][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]}},{{&l_4573[1][0],(void*)0,&l_4573[0][0]},{&l_4573[1][0],&l_4573[1][0],(void*)0},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{(void*)0,&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],&l_4573[1][0],(void*)0},{&l_4573[1][0],&l_4573[1][0],(void*)0}},{{&l_4573[1][0],(void*)0,(void*)0},{&l_4573[1][0],(void*)0,&l_4573[1][0]},{(void*)0,&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[0][0]},{&l_4573[1][0],(void*)0,&l_4573[1][0]},{&l_4573[1][0],(void*)0,&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],&l_4573[1][0],&l_4573[0][0]}},{{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],&l_4573[1][0],&l_4573[0][0]},{(void*)0,(void*)0,&l_4573[1][0]},{(void*)0,&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{(void*)0,(void*)0,&l_4573[1][0]},{&l_4573[0][0],&l_4573[0][0],(void*)0},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]}},{{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{(void*)0,&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],(void*)0,&l_4573[1][0]},{&l_4573[0][0],&l_4573[1][0],(void*)0},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],(void*)0,&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],(void*)0,&l_4573[0][0]}},{{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[0][0]},{&l_4573[0][0],(void*)0,&l_4573[1][0]},{&l_4573[1][0],&l_4573[0][0],&l_4573[1][0]},{&l_4573[0][0],(void*)0,&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[0][0],&l_4573[0][0]},{&l_4573[0][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],&l_4573[1][0],&l_4573[1][0]}},{{&l_4573[1][0],(void*)0,(void*)0},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[0][0],&l_4573[1][0],(void*)0},{&l_4573[1][0],(void*)0,(void*)0},{&l_4573[0][0],&l_4573[1][0],(void*)0},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],(void*)0,&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]},{&l_4573[1][0],&l_4573[1][0],&l_4573[1][0]}}};
                int32_t l_4944 = (-8L);
                int16_t *l_4946 = (void*)0;
                int16_t *l_4947 = &g_668.f3;
                uint32_t l_4948 = 18446744073709551607UL;
                int i, j, k;
                if ((+((((((safe_sub_func_uint16_t_u_u((((*l_4947) = (safe_mul_func_int32_t_s_s(((*g_1341) = ((safe_add_func_uint32_t_u_u((18446744073709551607UL ^ ((*g_249) = (((safe_mul_func_int32_t_s_s(l_4917, l_4896)) , (safe_lshift_func_int64_t_s_s(((safe_mod_func_int64_t_s_s(((l_4939 = (l_4936 = (l_4937 = l_4936))) == (((safe_div_func_int64_t_s_s((l_4896 | (&l_4720 != (void*)0)), (safe_mod_func_uint32_t_u_u(p_32, 0xDC010C32L)))) | p_30) , (*g_1054))), l_4944)) <= l_4945), 39))) , 0xCDC9808F2C1774CFLL))), (*g_1122))) | (**g_1236))), 0xFC703863L))) , 0x0A7EL), p_30)) == 0x1AB3BE6CL) == l_4917) , 1L) & 0x20L) <= l_4948)))
                { /* block id: 2109 */
                    for (g_947.f3 = 24; (g_947.f3 > 16); g_947.f3--)
                    { /* block id: 2112 */
                        return l_4944;
                    }
                    for (g_4906.f8 = 0; (g_4906.f8 <= (-3)); --g_4906.f8)
                    { /* block id: 2117 */
                        return p_31;
                    }
                }
                else
                { /* block id: 2120 */
                    int16_t *l_4953[2][10] = {{(void*)0,&g_3588.f3,&g_3588.f3,(void*)0,(void*)0,&g_2851.f3,(void*)0,&g_2851.f3,(void*)0,(void*)0},{&g_2851.f3,(void*)0,&g_2851.f3,(void*)0,(void*)0,&g_3588.f3,&g_3588.f3,(void*)0,(void*)0,&g_2851.f3}};
                    int64_t ***l_4957[5][6] = {{&g_248,&g_248,&g_248,&g_248,&g_248,&g_248},{&g_248,&g_248,&g_248,&g_248,&g_248,&g_248},{&g_248,&g_248,&g_248,&g_248,&g_248,&g_248},{&g_248,&g_248,&g_248,&g_248,&g_248,&g_248},{&g_248,&g_248,&g_248,&g_248,&g_248,&g_248}};
                    int32_t l_4960 = 0xD3D88085L;
                    int32_t l_4963 = (-1L);
                    int32_t **l_4964 = &g_1465[4][0];
                    int i, j;
                    for (g_973.f2 = 2; (g_973.f2 >= 0); g_973.f2 -= 1)
                    { /* block id: 2123 */
                        int i, j;
                        p_32 = (6UL == ((l_4953[1][4] != (void*)0) <= ((safe_rshift_func_uint16_t_u_u((l_4956[0][0] == l_4957[4][5]), 6)) < ((l_4960 = (safe_mod_func_int32_t_s_s((-8L), 3UL))) <= ((g_849[(g_973.f2 + 4)][g_973.f2] , (safe_lshift_func_int64_t_s_u((l_4963 && (**g_1236)), 5))) , l_4948)))));
                        if ((*g_3423))
                            break;
                    }
                    if (p_33)
                        break;
                    (*l_4964) = &p_32;
                }
                if (l_4684)
                    goto lbl_4965;
                if ((*g_1341))
                    continue;
            }
        }
    }
    else
    { /* block id: 2135 */
        struct S0 *l_4966[8] = {&g_4969,(void*)0,&g_4969,(void*)0,&g_4969,(void*)0,&g_4969,(void*)0};
        struct S0 **l_4970 = &l_4966[5];
        int32_t *l_4971 = &g_3586[8][0].f8;
        struct S0 *l_5002 = &g_5003;
        const uint16_t l_5030 = 0x3DD1L;
        int32_t l_5046 = 1L;
        int32_t l_5050 = (-1L);
        int32_t l_5053 = (-7L);
        int32_t l_5057[5][2] = {{1L,0x88AE51D7L},{0x88AE51D7L,0x88AE51D7L},{0x88AE51D7L,1L},{1L,0x9112A09CL},{1L,0x9112A09CL}};
        uint32_t l_5063 = 18446744073709551615UL;
        int16_t l_5125 = 2L;
        int32_t l_5204 = 0xE74D7175L;
        int32_t *l_5205 = &l_4553;
        const uint32_t l_5221 = 0x83CAB8D3L;
        const union U2 * const l_5331 = (void*)0;
        int i, j;
        (*g_2118) = ((*l_4970) = l_4966[7]);
        l_4971 = l_4971;
        if ((&l_4568 != &l_4568))
        { /* block id: 2139 */
            uint32_t **l_4981 = &g_2314[0][5];
            uint32_t * const **l_4983 = &l_4982;
            int32_t l_4998 = (-3L);
            uint32_t l_4999 = 0x1051A7F4L;
            p_32 = ((safe_sub_func_uint16_t_u_u((p_32 != ((+((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(((p_32 >= (safe_rshift_func_uint64_t_u_s(0xF5B34B88D020466BLL, (((((*g_2312) = l_4981) != ((*l_4983) = l_4982)) , p_33) , (((safe_add_func_int8_t_s_s(((p_33 , (l_4998 = ((safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s((safe_div_func_int8_t_s_s(0L, ((safe_mul_func_int64_t_s_s(((*g_249) = ((((safe_rshift_func_int32_t_s_u(((((*g_1237) = (safe_rshift_func_int64_t_s_u(((*l_4971) <= 0x2B5DC7144C31AAA1LL), 4))) && p_32) , 0xD375C357L), 8)) , (void*)0) != &g_771) , (*g_249))), (*l_4971))) ^ 0x7216F831ADC6A83ALL))), p_29)), (*l_4971))) , 247UL))) , 0xEFL), 0xCBL)) , 0xF5CCL) || 0x2DBFL))))) < p_30), l_4999)), p_31)) <= p_29)) > l_4999)), 0x3BF0L)) && l_4999);
            for (g_3588.f5 = 0; (g_3588.f5 > 11); ++g_3588.f5)
            { /* block id: 2148 */
                l_5002 = (*l_4970);
            }
        }
        else
        { /* block id: 2151 */
            uint32_t l_5004 = 1UL;
            int32_t l_5014 = 1L;
            const int16_t *l_5016 = &g_4207[9];
            const int16_t **l_5015 = &l_5016;
            int32_t l_5032 = 0L;
            int32_t l_5047 = 0x94F927CCL;
            int32_t l_5051 = (-1L);
            int32_t l_5054[1];
            union U1 *l_5201 = (void*)0;
            int32_t *l_5208 = &g_971[3].f3;
            uint64_t ***l_5238 = &l_4573[1][0];
            uint16_t ** const l_5266 = &l_4544;
            uint64_t l_5289 = 18446744073709551607UL;
            uint8_t l_5311 = 1UL;
            uint32_t l_5330 = 1UL;
            int i;
            for (i = 0; i < 1; i++)
                l_5054[i] = 0L;
            (*g_3423) = l_5004;
        }
    }
    l_5354++;
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_768 g_51 g_969.f0 g_849 g_1341 g_1342 g_978.f0 g_1937 g_3423 g_3297 g_3298 g_1236 g_1237 g_244 g_2936 g_3518 g_1122 g_90 g_3556 g_771 g_2851.f8 g_914 g_573 g_249 g_176 g_997 g_2687 g_457 g_41 g_54 g_98 g_117 g_81 g_110 g_184 g_211 g_10 g_248 g_350 g_400 g_420 g_421 g_89 g_2017.f3 g_1913 g_1340 g_607.f0 g_927 g_3620.f8 g_2312 g_2313 g_2314 g_3756.f2 g_3879 g_1042.f2 g_750 g_602.f0 g_962.f0 g_3963 g_3830 g_929 g_2118 g_589.f3 g_4120 g_4123 g_3620.f3 g_1282 g_985.f2 g_4161 g_4182 g_3586.f3 g_2594 g_1720 g_2637 g_2638 g_2639 g_4251 g_928 g_966.f0 g_2121.f8 g_3326 g_3586.f8 g_3586.f5 g_4121 g_3620.f5 g_723.f2 g_2640 g_4447 g_1895.f2 g_4407 g_3480.f6
 * writes: g_969.f0 g_978.f0 g_3480.f3 g_721.f3 g_2851.f8 g_1465 g_2936 g_966.f2 g_984.f3 g_963.f2 g_51 g_1342 g_3325 g_90 g_976.f2 g_3686 g_244 g_971.f2 g_81 g_89 g_110 g_117 g_176 g_98 g_184 g_211 g_248 g_336 g_400 g_421 g_2017.f3 g_744 g_748 g_607.f0 g_952.f3 g_928 g_3830 g_41 g_3518 g_3620.f8 g_3756.f2 g_1042.f2 g_2121.f3 g_589.f0 g_750 g_914 g_980.f2 g_602.f0 g_962.f0 g_573 g_2119 g_589.f3 g_1767 g_2312 g_3620.f3 g_1282 g_985.f2 g_3586.f3 g_2639 g_4251 g_987.f3 g_966.f0 g_2121.f8 g_2314 g_997 g_4406 g_3586.f5 g_723.f2 g_351 g_1895.f2 g_457
 */
static const uint8_t  func_36(int32_t  p_37, int8_t  p_38, int16_t  p_39, uint32_t  p_40)
{ /* block id: 1516 */
    int16_t ****l_3485 = &g_2594;
    int32_t l_3489 = 0xE9E85A15L;
    uint32_t ****l_3505 = (void*)0;
    int32_t l_3573 = 7L;
    struct S0 *l_3585 = &g_3586[8][0];
    uint64_t ****l_3594 = &g_3326[0][3];
    uint16_t l_3622 = 0x0A79L;
    uint16_t l_3658 = 0UL;
    uint16_t l_3695 = 65527UL;
    int64_t **l_3731[5][3] = {{&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249}};
    uint32_t l_3772 = 0xA273B919L;
    int32_t *l_3777[8];
    uint32_t l_3783 = 0UL;
    int32_t *l_3809 = &g_3620.f8;
    int64_t ****l_3829 = &g_929;
    uint64_t *l_3911[7][6][6] = {{{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5}},{{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5}},{{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5}},{{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5}},{{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5}},{{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5}},{{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5},{&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5,&g_2120.f5}}};
    union U2 *l_4103 = &g_4104;
    const uint64_t **l_4122 = (void*)0;
    struct S0 ****l_4144 = (void*)0;
    int8_t **l_4189[7][9] = {{&g_768,&g_768,&g_771,&g_768,&g_771,&g_768,&g_768,&g_771,&g_768},{(void*)0,(void*)0,(void*)0,&g_771,&g_771,(void*)0,(void*)0,(void*)0,&g_771},{(void*)0,&g_771,&g_771,(void*)0,(void*)0,(void*)0,&g_771,&g_771,(void*)0},{&g_768,&g_771,&g_768,&g_771,&g_768,&g_768,&g_771,&g_768,&g_771},{&g_771,(void*)0,&g_768,&g_768,(void*)0,&g_771,(void*)0,&g_768,&g_768},{&g_768,&g_768,&g_771,&g_768,&g_771,&g_768,&g_768,&g_771,&g_768},{(void*)0,(void*)0,(void*)0,&g_771,&g_771,(void*)0,(void*)0,(void*)0,&g_771}};
    int8_t *** const l_4188[8] = {&l_4189[1][1],&l_4189[1][1],&l_4189[1][1],&l_4189[1][1],&l_4189[1][1],&l_4189[1][1],&l_4189[1][1],&l_4189[1][1]};
    int8_t *** const * const l_4187 = &l_4188[2];
    int32_t l_4247 = 0xF362389BL;
    int16_t l_4285 = 0x86D0L;
    int8_t l_4294 = 0x86L;
    union U1 *l_4304 = &g_4305[5][0][1];
    uint8_t l_4319 = 0x37L;
    uint32_t l_4346[9] = {0xEC9F56DBL,0x204AF9ECL,0xEC9F56DBL,0x204AF9ECL,0xEC9F56DBL,0x204AF9ECL,0xEC9F56DBL,0x204AF9ECL,0xEC9F56DBL};
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_3777[i] = &g_964[1].f3;
    if ((+(((void*)0 != &g_771) == ((((l_3485 == &g_2594) | p_40) | (+0xD6AFA082L)) <= ((safe_sub_func_uint8_t_u_u(l_3489, (*g_768))) < ((safe_rshift_func_uint8_t_u_u(5UL, 0)) && p_40))))))
    { /* block id: 1517 */
        uint8_t l_3502 = 255UL;
        uint32_t ****l_3515 = &g_2639;
        int16_t l_3517 = 0xE4ACL;
        int32_t l_3532 = 7L;
        int32_t l_3535 = 0x040C297EL;
        int32_t l_3538 = (-1L);
        int32_t l_3539 = 6L;
        struct S0 *l_3587 = &g_3588;
        union U1 ***l_3606 = &g_2054[7];
        const uint32_t l_3621 = 0xD86B1063L;
        int32_t *l_3653 = &g_963.f2;
        int64_t * const *l_3684 = &g_249;
        int64_t * const **l_3683[9][3][3] = {{{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684},{&l_3684,(void*)0,&l_3684}},{{&l_3684,(void*)0,&l_3684},{&l_3684,&l_3684,(void*)0},{&l_3684,&l_3684,&l_3684}},{{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684}},{{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684}},{{&l_3684,&l_3684,&l_3684},{(void*)0,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684}},{{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,(void*)0},{&l_3684,&l_3684,&l_3684}},{{(void*)0,&l_3684,(void*)0},{&l_3684,(void*)0,&l_3684},{&l_3684,(void*)0,&l_3684}},{{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684}},{{&l_3684,&l_3684,&l_3684},{&l_3684,&l_3684,&l_3684},{(void*)0,&l_3684,&l_3684}}};
        int64_t * const ***l_3682 = &l_3683[5][0][1];
        int16_t ***l_3699 = &g_1720[2][7][1];
        int32_t l_3720[7][2] = {{0x9C85DEC1L,(-7L)},{(-7L),0x9C85DEC1L},{(-7L),(-7L)},{0x9C85DEC1L,(-7L)},{(-7L),0x9C85DEC1L},{(-7L),(-7L)},{0x9C85DEC1L,(-7L)}};
        uint8_t l_3722[1][5];
        union U2 *l_3755 = &g_3756;
        uint16_t ****l_3762 = &g_3298[0][4];
        const uint8_t *l_3780 = (void*)0;
        const uint8_t **l_3779 = &l_3780;
        const uint8_t ** const *l_3778[9][3];
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 5; j++)
                l_3722[i][j] = 0x9EL;
        }
        for (i = 0; i < 9; i++)
        {
            for (j = 0; j < 3; j++)
                l_3778[i][j] = &l_3779;
        }
        for (g_969.f0 = 0; (g_969.f0 <= 0); g_969.f0 += 1)
        { /* block id: 1520 */
            uint32_t l_3492 = 18446744073709551608UL;
            volatile int32_t *l_3498 = &g_3499;
            uint32_t ****l_3514 = &g_2639;
            int32_t l_3530 = 0xE584720FL;
            int32_t l_3531 = 0x4D423E1EL;
            int32_t l_3540 = 0x60516116L;
            int32_t l_3542 = 0xBFC60563L;
            int32_t l_3543 = (-1L);
            uint32_t l_3544 = 0xCE4D2950L;
            struct S0 * const l_3619 = &g_3620;
            int8_t **l_3656 = (void*)0;
            int8_t ***l_3655[4][6] = {{&l_3656,&l_3656,&l_3656,&l_3656,&l_3656,&l_3656},{&l_3656,&l_3656,&l_3656,&l_3656,&l_3656,&l_3656},{&l_3656,&l_3656,&l_3656,&l_3656,&l_3656,&l_3656},{&l_3656,&l_3656,&l_3656,&l_3656,&l_3656,&l_3656}};
            int8_t ****l_3654 = &l_3655[1][3];
            union U1 ***l_3693[5];
            uint64_t l_3729 = 0x090FEFAA094A3B64LL;
            int i, j;
            for (i = 0; i < 5; i++)
                l_3693[i] = &g_2054[7];
            for (g_978.f0 = 0; (g_978.f0 <= 4); g_978.f0 += 1)
            { /* block id: 1523 */
                int16_t l_3493 = (-6L);
                int8_t l_3519 = (-1L);
                int32_t l_3536 = (-8L);
                int32_t l_3541 = 0L;
                for (g_3480.f3 = 2; (g_3480.f3 >= 0); g_3480.f3 -= 1)
                { /* block id: 1526 */
                    int i, j;
                    return g_849[(g_969.f0 + 3)][(g_969.f0 + 4)];
                }
                if (l_3492)
                    continue;
                if ((*g_1341))
                    break;
                for (g_721.f3 = 0; (g_721.f3 <= 2); g_721.f3 += 1)
                { /* block id: 1533 */
                    uint32_t l_3500[9][8] = {{3UL,0xC37D242DL,1UL,4294967293UL,1UL,0xC37D242DL,3UL,3UL},{0xC37D242DL,4294967293UL,1UL,1UL,4294967293UL,0xC37D242DL,4294967286UL,0xC37D242DL},{4294967293UL,0xC37D242DL,4294967286UL,0xC37D242DL,4294967293UL,1UL,1UL,4294967293UL},{0xC37D242DL,3UL,3UL,0xC37D242DL,1UL,4294967293UL,1UL,0xC37D242DL},{3UL,1UL,3UL,1UL,4294967286UL,4294967286UL,1UL,3UL},{1UL,1UL,4294967286UL,4294967293UL,0x962D556CL,4294967293UL,4294967286UL,1UL},{1UL,3UL,1UL,4294967286UL,4294967286UL,1UL,3UL,1UL},{3UL,0xC37D242DL,1UL,4294967293UL,1UL,0xC37D242DL,3UL,3UL},{0xC37D242DL,4294967293UL,1UL,1UL,4294967293UL,0xC37D242DL,4294967286UL,0xC37D242DL}};
                    uint32_t *l_3516 = &g_2936[1][1][3];
                    int32_t l_3520 = 0x4FB1A83CL;
                    int8_t l_3521 = (-8L);
                    int32_t l_3537[3][8] = {{0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL},{0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL},{0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL,0xC905404FL,0x6F15A74CL}};
                    int i, j;
                    if (l_3493)
                    { /* block id: 1534 */
                        return p_38;
                    }
                    else
                    { /* block id: 1536 */
                        volatile int32_t **l_3494 = (void*)0;
                        volatile int32_t *l_3496 = &g_3497;
                        volatile int32_t **l_3495[4] = {&l_3496,&l_3496,&l_3496,&l_3496};
                        int32_t **l_3501 = &g_1465[6][1];
                        int i, j, k;
                        if (l_3492)
                            break;
                        l_3498 = g_1937[(g_978.f0 + 2)][g_969.f0][g_969.f0];
                        l_3500[8][4] &= ((*g_3423) = p_39);
                        (*l_3501) = &p_37;
                    }
                    p_37 = (l_3502 < ((((safe_div_func_int64_t_s_s(((p_39 & (((l_3505 != &g_2312) >= ((safe_lshift_func_uint32_t_u_u(l_3489, 12)) <= (*g_768))) , (safe_lshift_func_uint16_t_u_s((((safe_add_func_uint32_t_u_u(p_39, ((((****g_3297) && (((((safe_div_func_int16_t_s_s((((*l_3516) |= ((l_3514 = l_3514) != l_3515)) ^ l_3517), 2UL)) <= g_3518[3][3]) == 1UL) > 6UL) , l_3519)) == p_38) , l_3489))) || l_3500[3][7]) == 3L), p_39)))) > p_39), (-1L))) , p_38) == 65535UL) & p_40));
                    for (g_966.f2 = 2; (g_966.f2 >= 0); g_966.f2 -= 1)
                    { /* block id: 1548 */
                        int32_t *l_3522 = &g_406[4].f3;
                        int32_t *l_3523 = &g_81;
                        int32_t *l_3524 = &g_959[1].f3;
                        int32_t *l_3525 = &g_991.f3;
                        int32_t *l_3526 = &g_984[0].f3;
                        int32_t *l_3527 = &g_953.f3;
                        int32_t *l_3528 = &g_979.f3;
                        int32_t *l_3529 = &g_970[7].f3;
                        int32_t *l_3533 = &g_985.f3;
                        int32_t *l_3534[6] = {&l_3531,&g_952.f3,&l_3531,&l_3531,&g_952.f3,&l_3531};
                        int32_t **l_3547 = (void*)0;
                        int32_t **l_3548 = (void*)0;
                        int32_t **l_3549 = &l_3533;
                        int32_t **l_3550 = &l_3523;
                        const uint32_t *l_3567[3];
                        const uint32_t **l_3566 = &l_3567[1];
                        const uint32_t ***l_3565 = &l_3566;
                        const uint32_t ****l_3564 = &l_3565;
                        const uint32_t *****l_3563 = &l_3564;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_3567[i] = (void*)0;
                        l_3544++;
                        l_3536 ^= (*g_1122);
                        (*l_3550) = ((*l_3549) = &p_37);
                        (*l_3526) = ((*l_3533) = (safe_unary_minus_func_uint32_t_u(((safe_sub_func_uint64_t_u_u((safe_mul_func_uint32_t_u_u(p_39, (&g_2312 == &g_2312))), g_3556)) || (safe_mul_func_uint32_t_u_u(((safe_add_func_int64_t_s_s((l_3489 ^= 7L), (0x8AL & p_39))) ^ (l_3563 != &l_3505)), p_40))))));
                    }
                }
            }
            for (g_963.f2 = 2; (g_963.f2 >= 0); g_963.f2 -= 1)
            { /* block id: 1561 */
                uint8_t *l_3568[7] = {(void*)0,&g_750[1],(void*)0,(void*)0,&g_750[1],(void*)0,(void*)0};
                int32_t l_3584 = 0L;
                int64_t l_3591 = (-3L);
                uint64_t ****l_3595 = &g_3326[1][1];
                union U1 ***l_3624[10] = {&g_2054[5],&g_2054[5],&g_2054[5],&g_2054[5],&g_2054[5],&g_2054[5],&g_2054[5],&g_2054[5],&g_2054[5],&g_2054[5]};
                int32_t **l_3649 = &g_3423;
                const int16_t *l_3698 = (void*)0;
                const int16_t **l_3697 = &l_3698;
                const int16_t *** const l_3696 = &l_3697;
                uint32_t l_3700 = 0UL;
                int64_t **l_3730 = &g_249;
                int i;
                (*g_3423) &= ((l_3489 = 0x08L) | ((*g_771) = (l_3532 ^= (safe_div_func_int8_t_s_s(((safe_sub_func_uint64_t_u_u((p_39 != ((((((void*)0 == l_3485) , l_3573) >= 65526UL) == (safe_mul_func_int8_t_s_s(p_37, (((((safe_lshift_func_uint16_t_u_u(p_38, 7)) , (((((safe_add_func_int32_t_s_s(((safe_rshift_func_uint64_t_u_u((safe_add_func_uint64_t_u_u(l_3584, 6UL)), 30)) < (-1L)), l_3517)) ^ (*g_768)) , l_3585) == l_3587) < 0x4D5E3E8F421ECFEALL)) ^ 0x05F1L) | 65532UL) & 0x73C5L)))) != l_3544)), p_37)) , l_3573), l_3584)))));
                if (((*g_1341) = ((safe_rshift_func_int64_t_s_u(0x29FC099F4C813CC6LL, 10)) | l_3591)))
                { /* block id: 1567 */
                    uint64_t *****l_3596 = &g_3325;
                    (*l_3596) = (l_3595 = ((safe_mod_func_uint8_t_u_u(l_3584, (*g_771))) , l_3594));
                }
                else
                { /* block id: 1570 */
                    int32_t l_3603[1][7][1] = {{{0x04F92577L},{0x9DF21C2EL},{0x04F92577L},{0x04F92577L},{0x9DF21C2EL},{0x04F92577L},{0x04F92577L}}};
                    int32_t l_3623 = 0x15B4FA90L;
                    int32_t **l_3650[4] = {&g_1122,&g_1122,&g_1122,&g_1122};
                    int i, j, k;
                    (*g_1341) = ((safe_mod_func_int32_t_s_s((safe_sub_func_int16_t_s_s((((*g_1122) = l_3584) | (((((safe_add_func_uint32_t_u_u(((l_3603[0][6][0] |= l_3573) == (safe_mul_func_int32_t_s_s((l_3606 == ((l_3623 &= ((safe_add_func_int16_t_s_s(p_39, (safe_div_func_uint32_t_u_u((0xDC94L | (safe_lshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((safe_add_func_int64_t_s_s((p_37 <= (safe_mul_func_uint64_t_u_u(((void*)0 != l_3619), 0xC850FAF356D8730DLL))), l_3621)), l_3622)), 6))), 4294967293UL)))) && 0x71B73CCA24B7A3C4LL)) , l_3624[1])), 4294967295UL))), (*g_1341))) & (*g_771)) & (*g_1237)) >= l_3573) <= (****g_3297))), 0xB7ABL)), l_3539)) >= p_38);
                    if (p_40)
                        continue;
                    if (((safe_lshift_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s((safe_lshift_func_int16_t_s_u((((((safe_mod_func_int16_t_s_s(((*g_914) & ((safe_mod_func_int64_t_s_s((((safe_add_func_int16_t_s_s(p_37, ((safe_lshift_func_uint32_t_u_s((safe_mod_func_uint64_t_u_u(((p_38 == (((safe_div_func_int16_t_s_s((l_3535 = 0L), l_3623)) < (l_3649 == l_3650[3])) != (safe_add_func_uint16_t_u_u(((&g_3175[1] == ((2L != 0xAA1B9101L) , l_3653)) | p_37), 1L)))) && (**l_3649)), 0xA662ACD4171C23A7LL)), l_3531)) || 4294967288UL))) , 7UL) , 0x37DCB1823BBC85B9LL), 0xC01F8988E8727713LL)) , p_37)), p_39)) & (*g_768)) == p_39) , (void*)0) != (void*)0), 15)), (**l_3649))), p_37)), (**l_3649))), l_3543)), 25)) ^ 0x9C84L))
                    { /* block id: 1577 */
                        int8_t *****l_3657 = &l_3654;
                        (*l_3657) = l_3654;
                        l_3658++;
                    }
                    else
                    { /* block id: 1580 */
                        int8_t *l_3666 = (void*)0;
                        int8_t ** const l_3665 = &l_3666;
                        int8_t ** const *l_3664 = &l_3665;
                        int8_t ** const **l_3663 = &l_3664;
                        (**l_3649) = (safe_div_func_int32_t_s_s(((*g_1341) = (((*l_3663) = (void*)0) != (void*)0)), (*g_1122)));
                    }
                }
                for (g_976.f2 = 0; (g_976.f2 <= 0); g_976.f2 += 1)
                { /* block id: 1588 */
                    int64_t * const ****l_3685[6][1];
                    int32_t l_3694 = 0xFC5F52D0L;
                    int32_t l_3721 = (-4L);
                    int i, j;
                    for (i = 0; i < 6; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_3685[i][j] = &l_3682;
                    }
                    (*g_1341) = ((*g_3423) = (((**g_1236) = (safe_add_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_s((safe_mul_func_int8_t_s_s(((((((p_38 && ((+(((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint32_t_u_u((l_3694 = ((safe_mod_func_uint16_t_u_u((((((*g_768) = ((p_39 = (l_3538 > (l_3532 , ((g_3686[4] = l_3682) == &l_3683[5][0][1])))) != ((l_3538 , 0x7527C3E3745646DFLL) , (((safe_mul_func_int16_t_s_s(((safe_add_func_uint8_t_u_u((l_3573 = 250UL), (safe_mul_func_uint64_t_u_u((l_3693[1] == &g_2054[8]), 0xE41006A737C4C8C7LL)))) == p_37), l_3694)) && 18446744073709551608UL) && l_3695)))) == l_3694) < l_3658) <= 0xCC7FABEBL), p_38)) ^ l_3538)), 30)), l_3532)) , l_3696) != l_3699)) || 0UL)) != p_37) , (**l_3649)) < 0x44F1L) , (void*)0) == &g_2312), l_3543)), l_3700)), p_37))) >= p_40));
                    (*g_1341) = (safe_unary_minus_func_int8_t_s((((safe_sub_func_int64_t_s_s(((safe_rshift_func_uint32_t_u_s(((safe_sub_func_int16_t_s_s(((*g_249) | (safe_mod_func_int16_t_s_s(0x4717L, ((l_3540 ^= ((((safe_add_func_int8_t_s_s(((safe_add_func_int32_t_s_s(((p_38 , (safe_lshift_func_int32_t_s_s((((p_39 , p_39) , (safe_add_func_uint32_t_u_u((((safe_sub_func_uint8_t_u_u((l_3722[0][1]--), (-1L))) >= ((safe_add_func_int32_t_s_s((safe_div_func_int16_t_s_s((l_3729 && (l_3730 != l_3731[1][0])), l_3720[1][1])), p_37)) ^ (**l_3649))) > 0L), (**l_3649)))) >= 0xC84DL), 10))) > 3UL), p_37)) & 0x11L), p_37)) ^ p_37) != l_3531) , l_3489)) & 0xB8150957L)))), l_3694)) || 0xF3B6L), 3)) , 0x9C0EE3F53C7491BFLL), 1UL)) , g_997) != g_997)));
                }
            }
        }
        (*g_1122) = (((safe_mul_func_uint8_t_u_u(((((((*g_3423) = (safe_unary_minus_func_int16_t_s((safe_rshift_func_uint8_t_u_s((((safe_mul_func_uint8_t_u_u((((*g_2687) = (safe_mod_func_int32_t_s_s(((l_3573 >= (safe_rshift_func_uint16_t_u_u(p_37, (l_3489 & 0xB028D3348D7B51D2LL)))) , ((l_3535 == (safe_lshift_func_int32_t_s_u(0x54FC76BCL, (safe_add_func_uint64_t_u_u((((*g_1341) = (((safe_lshift_func_uint16_t_u_s((safe_mod_func_uint32_t_u_u((safe_add_func_int64_t_s_s(((safe_mod_func_int16_t_s_s(l_3573, ((l_3532 , ((l_3573 , p_39) <= 1L)) || 0xE253L))) && 1L), 4L)), 4294967293UL)), p_37)) >= 0x58CFA20A5584A6B8LL) || (-1L))) ^ l_3539), 1L))))) == p_40)), 6UL))) , l_3622), 0UL)) == p_38) , 0x30L), 4))))) , &g_2748) != &g_3297) , l_3755) == g_457), 0xE5L)) | p_38) > 0x6770L);
        if (((safe_mod_func_int16_t_s_s(p_39, l_3502)) | 0x07L))
        { /* block id: 1607 */
            int32_t l_3761[8] = {0L,0x99BD8154L,0L,0x99BD8154L,0L,0x99BD8154L,0L,0x99BD8154L};
            int32_t l_3775[10][3][4] = {{{0x29308F75L,3L,(-6L),0xE042C1D4L},{0xB5EA9B7FL,0L,0x548E9598L,0L},{0xB5EA9B7FL,0xE042C1D4L,(-6L),3L}},{{0x29308F75L,0L,(-6L),0xD6F6BBD7L},{0xB5EA9B7FL,3L,0x548E9598L,3L},{0xB5EA9B7FL,0xD6F6BBD7L,(-6L),0L}},{{0x29308F75L,3L,(-6L),0xE042C1D4L},{0xB5EA9B7FL,0L,0x548E9598L,0L},{0xB5EA9B7FL,0xE042C1D4L,(-6L),3L}},{{0x29308F75L,0L,(-6L),0xD6F6BBD7L},{0xB5EA9B7FL,3L,0x548E9598L,3L},{0xB5EA9B7FL,0xD6F6BBD7L,(-6L),0L}},{{0x29308F75L,3L,(-6L),0xE042C1D4L},{0xB5EA9B7FL,0L,0x548E9598L,0L},{0xB5EA9B7FL,0xE042C1D4L,(-6L),3L}},{{0x29308F75L,0L,(-6L),0xD6F6BBD7L},{0xB5EA9B7FL,3L,0x548E9598L,3L},{0xB5EA9B7FL,0xD6F6BBD7L,(-6L),0L}},{{0x29308F75L,3L,(-6L),0xE042C1D4L},{0xB5EA9B7FL,0L,0x548E9598L,0L},{0xB5EA9B7FL,0xE042C1D4L,(-6L),3L}},{{0x29308F75L,0L,(-6L),0xD6F6BBD7L},{0xB5EA9B7FL,3L,0x548E9598L,3L},{0xB5EA9B7FL,0xD6F6BBD7L,(-6L),0L}},{{0x29308F75L,3L,(-6L),0xE042C1D4L},{0xB5EA9B7FL,0L,0x548E9598L,0L},{0xB5EA9B7FL,0xE042C1D4L,(-6L),3L}},{{0x29308F75L,0L,(-6L),0xD6F6BBD7L},{0xB5EA9B7FL,3L,0x548E9598L,3L},{0xB5EA9B7FL,0xD6F6BBD7L,(-6L),0L}}};
            int32_t *l_3776 = &g_90;
            int64_t l_3782 = 1L;
            int i, j, k;
            l_3777[7] = func_69(((l_3539 = (l_3775[8][1][2] = (65535UL | (((safe_add_func_uint16_t_u_u(((((p_38 = l_3761[4]) , (void*)0) != (l_3762 = l_3762)) >= ((l_3622 & (safe_mul_func_uint16_t_u_u((safe_add_func_int8_t_s_s((*g_771), l_3695)), (!(((safe_sub_func_int8_t_s_s(((safe_sub_func_int16_t_s_s(l_3772, (safe_mul_func_int64_t_s_s(0x685BA2D66684D2D6LL, p_40)))) && 1UL), (*g_768))) | l_3720[3][0]) == p_39))))) == l_3489)), l_3573)) != l_3720[1][1]) < 1UL)))) > l_3532), p_39, &l_3489, &l_3720[1][1], l_3776);
            (*g_3423) = (&g_1767 != l_3778[4][1]);
            l_3783--;
        }
        else
        { /* block id: 1615 */
            (*g_1122) ^= 0xBC9752DAL;
            return p_39;
        }
        for (g_2017.f3 = 0; (g_2017.f3 > (-18)); --g_2017.f3)
        { /* block id: 1621 */
            int64_t l_3790[7][6][3] = {{{0xA3B8EC25FE45FF4BLL,0x07F787CD3F45CBFFLL,0xA3B8EC25FE45FF4BLL},{0x2C0E07CACADAC72BLL,0x5F51069B8757119DLL,0x2C0E07CACADAC72BLL},{0xA3B8EC25FE45FF4BLL,0x07F787CD3F45CBFFLL,0xA3B8EC25FE45FF4BLL},{0x2C0E07CACADAC72BLL,0x5F51069B8757119DLL,0x2C0E07CACADAC72BLL},{0xA3B8EC25FE45FF4BLL,0x07F787CD3F45CBFFLL,0xA3B8EC25FE45FF4BLL},{0x2C0E07CACADAC72BLL,0x5F51069B8757119DLL,0x2C0E07CACADAC72BLL}},{{0xA3B8EC25FE45FF4BLL,0x07F787CD3F45CBFFLL,0xA3B8EC25FE45FF4BLL},{0x2C0E07CACADAC72BLL,0x5F51069B8757119DLL,0x2C0E07CACADAC72BLL},{0xA3B8EC25FE45FF4BLL,0x07F787CD3F45CBFFLL,0xA3B8EC25FE45FF4BLL},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL}},{{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL}},{{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL}},{{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL}},{{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL}},{{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL},{0L,0x9315876C1B515BCCLL,0L},{0x30E92D8C369773FELL,0x2C0E07CACADAC72BLL,0x30E92D8C369773FELL}}};
            int i, j, k;
            (*g_3423) ^= (safe_rshift_func_uint32_t_u_u(l_3790[1][0][0], 23));
        }
    }
    else
    { /* block id: 1624 */
        int16_t l_3791[7] = {0x8FAAL,0x000DL,0x8FAAL,0x8FAAL,0x000DL,0x8FAAL,0x8FAAL};
        uint32_t l_3801 = 0xFB098941L;
        int32_t **l_3802 = &g_1465[2][4];
        int32_t l_3854[6][1];
        union U2 * volatile * volatile *l_3860 = (void*)0;
        union U2 * volatile * volatile * const  volatile * const l_3859 = &l_3860;
        union U2 * volatile * volatile * const  volatile * const *l_3858 = &l_3859;
        int32_t l_3883 = 0x1949FA55L;
        uint32_t ** const *l_3892 = &g_2313;
        uint32_t ** const **l_3891[3];
        int32_t l_3964 = (-8L);
        int32_t l_4101 = 0x7E4FD1CCL;
        uint8_t l_4102[7][4][6] = {{{0xCEL,0x19L,0x19L,0xCEL,0UL,9UL},{0UL,0xCEL,0x19L,0x19L,0xCEL,0UL},{0UL,0x19L,9UL,0xCEL,0xCEL,9UL},{0xCEL,0xCEL,9UL,0x19L,0UL,0UL}},{{0xCEL,0x19L,0x19L,0xCEL,0UL,9UL},{0UL,0xCEL,0x19L,0x19L,0xCEL,0UL},{0UL,0x19L,9UL,0xCEL,0xCEL,9UL},{0xCEL,0xCEL,9UL,0x19L,0UL,0UL}},{{0xCEL,0x19L,0x19L,0xCEL,0UL,9UL},{0UL,0xCEL,0x19L,0x19L,0xCEL,0UL},{0UL,0x19L,9UL,0xCEL,0xCEL,9UL},{0xCEL,0xCEL,9UL,0x19L,0UL,0UL}},{{0xCEL,0x19L,0x19L,0xCEL,0UL,9UL},{0UL,0xCEL,0x19L,0x19L,0xCEL,0UL},{0UL,0x19L,9UL,0xCEL,0xCEL,9UL},{0xCEL,0xCEL,9UL,0x19L,0UL,0UL}},{{0xCEL,0x19L,0x19L,0xCEL,0UL,9UL},{0UL,0xCEL,0x19L,0x19L,0xCEL,0UL},{0UL,0x19L,9UL,0xCEL,0xCEL,9UL},{0xCEL,0xCEL,9UL,0x19L,0UL,0UL}},{{0xCEL,0x19L,0x19L,0xCEL,0UL,9UL},{0UL,0xCEL,0x19L,0x19L,0xCEL,0UL},{0UL,0x19L,9UL,0xCEL,0xCEL,9UL},{0xCEL,0xCEL,9UL,0x19L,0UL,0UL}},{{0xCEL,0x19L,0x19L,0xCEL,0UL,9UL},{0UL,0xCEL,0x19L,0x19L,0xCEL,0UL},{0UL,0x19L,9UL,0xCEL,0xCEL,9UL},{0xCEL,0xCEL,9UL,0x19L,0UL,0UL}}};
        int32_t l_4171 = 4L;
        int8_t **l_4186[6][7] = {{&g_768,&g_771,&g_771,&g_768,&g_771,&g_771,&g_771},{&g_768,&g_771,&g_771,&g_768,(void*)0,&g_768,&g_771},{&g_771,&g_771,&g_771,&g_771,&g_771,&g_768,(void*)0},{&g_768,&g_771,&g_771,&g_768,&g_771,&g_771,&g_771},{&g_768,&g_771,&g_771,&g_768,(void*)0,&g_768,&g_771},{&g_771,&g_771,&g_771,&g_771,&g_771,&g_768,(void*)0}};
        int8_t ***l_4185 = &l_4186[4][6];
        int8_t ****l_4184 = &l_4185;
        int32_t l_4290 = (-6L);
        int32_t *l_4292 = &l_4101;
        uint16_t **l_4456 = &g_1237;
        uint32_t l_4498 = 1UL;
        int32_t ***l_4501 = &l_3802;
        uint8_t ***l_4508 = &g_1767;
        uint32_t l_4529 = 0x1CA89C16L;
        int i, j, k;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 1; j++)
                l_3854[i][j] = 0xB6C1389EL;
        }
        for (i = 0; i < 3; i++)
            l_3891[i] = &l_3892;
lbl_4037:
        (*l_3802) = func_58(l_3791[3], l_3791[3], ((safe_add_func_uint32_t_u_u(p_38, ((~p_39) | 0x927CL))) && (safe_div_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(l_3791[3], ((safe_sub_func_uint8_t_u_u((0UL != l_3801), (&l_3777[7] != (*g_1913)))) , (*g_768)))), p_38))), p_38, (*g_914));
        (*l_3802) = &l_3489;
        if (p_37)
        { /* block id: 1627 */
            uint64_t l_3805 = 0x8A75556E30299C6DLL;
            for (g_607.f0 = 0; (g_607.f0 == 26); g_607.f0 = safe_add_func_uint8_t_u_u(g_607.f0, 1))
            { /* block id: 1630 */
                if (l_3805)
                    break;
            }
            for (g_2851.f8 = (-24); (g_2851.f8 >= 28); g_2851.f8 = safe_add_func_uint32_t_u_u(g_2851.f8, 3))
            { /* block id: 1635 */
                int8_t l_3808 = 0x1BL;
                int32_t *l_3810 = &g_964[1].f3;
                int8_t **l_3842 = &g_771;
                int8_t ***l_3841 = &l_3842;
                int8_t ****l_3840 = &l_3841;
                if (l_3808)
                { /* block id: 1636 */
                    l_3810 = l_3809;
                    (*g_1122) = l_3805;
                    if (p_40)
                        break;
                    for (g_952.f3 = (-24); (g_952.f3 <= (-17)); ++g_952.f3)
                    { /* block id: 1642 */
                        int64_t ****l_3828 = &g_929;
                        int32_t l_3831 = 0xFD1E5182L;
                        int32_t l_3832 = (-1L);
                        uint8_t *l_3833 = &g_110;
                        (*g_89) &= p_38;
                        l_3777[7] = func_58(p_37, (safe_add_func_uint32_t_u_u((safe_add_func_uint8_t_u_u(((*l_3833) = ((p_40 != (((((!(safe_add_func_int32_t_s_s((l_3831 = (safe_add_func_int32_t_s_s((safe_mod_func_uint64_t_u_u((safe_add_func_uint16_t_u_u((((((safe_lshift_func_int8_t_s_s((*g_771), 4)) != (p_39 < (((*g_927) = l_3828) == (g_3830 = l_3829)))) && p_40) >= 0xFCDF2B3487214756LL) ^ 0xB3L), 0xE7ECL)), 0xC5C768F86AFC9DB9LL)), (*g_3423)))), l_3832))) , p_38) , (*g_768)) && 0xB6L) > l_3805)) > p_37)), l_3805)), (-1L))), p_38, l_3832, (*l_3810));
                        if (p_39)
                            continue;
                    }
                }
                else
                { /* block id: 1651 */
                    uint16_t l_3836[9][2][9] = {{{0x2525L,0x27B9L,2UL,0x52A4L,0x4734L,65526UL,0x27B9L,0x2BAFL,65535UL},{0UL,0UL,0xA49EL,65535UL,0xF3E4L,65535UL,0xA49EL,0UL,0UL}},{{0xAD35L,65535UL,0xBA63L,0xC49EL,0x7370L,65534UL,5UL,0xBA63L,0x4734L},{0xA49EL,0UL,1UL,0UL,0x1456L,0xA49EL,0xF3E4L,1UL,1UL}},{{0xAD35L,0x7370L,5UL,0x66ABL,5UL,0x7370L,0xAD35L,0x52A4L,0x66ABL},{0UL,65531UL,65535UL,0UL,65534UL,65535UL,65531UL,0xD4A3L,0xA49EL}},{{0x2525L,0xC49EL,65535UL,2UL,1UL,0UL,0x52A4L,0x52A4L,0UL},{2UL,0x92B5L,0xF3E4L,65535UL,0xA49EL,0UL,0UL,0xF3E4L,0xD4A3L}},{{0x2525L,65534UL,1UL,1UL,1UL,0x2525L,0x09ABL,0x27B9L,2UL},{0UL,0xA49EL,0x0964L,0UL,0xD4A3L,0UL,0UL,0xD4A3L,0UL}},{{0UL,0x7370L,0UL,0x2525L,0x2BAFL,0UL,0x7370L,0xBA63L,2UL},{1UL,65535UL,0UL,1UL,0x6FC1L,65534UL,65535UL,0x0964L,0UL}},{{5UL,0UL,2UL,0x2525L,0x4734L,0x4734L,0x2525L,2UL,0UL},{65535UL,0x4109L,0x1456L,0UL,5UL,65535UL,0x6FC1L,0xDE2CL,65531UL}},{{0xC49EL,0x4734L,0UL,1UL,65526UL,0x52A4L,65535UL,0x2525L,1UL},{0x6CD2L,0x4109L,1UL,65535UL,65535UL,1UL,0x4109L,0x6CD2L,0x0964L}},{{0xBA63L,0UL,65526UL,0UL,65534UL,0x66ABL,0x2BAFL,2UL,0UL},{65534UL,65535UL,65531UL,0xD4A3L,0xA49EL,0x92B5L,0x0964L,65531UL,0x0964L}}};
                    uint32_t *l_3837 = &g_3518[0][6];
                    int8_t ****l_3844[6] = {&l_3841,&l_3841,&l_3841,&l_3841,&l_3841,&l_3841};
                    int8_t *****l_3843 = &l_3844[3];
                    int i, j, k;
                    (*g_89) &= (safe_mul_func_uint16_t_u_u((****g_3297), ((((-7L) != (((((*l_3837) = ((***g_2312) &= l_3836[8][0][8])) , (void*)0) == &p_37) || 0xA5E9DACC6D03B160LL)) < (safe_mul_func_int16_t_s_s(((*l_3809) & (l_3840 == ((*l_3843) = (void*)0))), l_3805))) && 0L)));
                }
            }
        }
        else
        { /* block id: 1658 */
            uint32_t l_3848 = 0xF08E6627L;
            const uint64_t *l_3882 = (void*)0;
            uint16_t ****l_3884 = &g_3298[0][5];
            int32_t l_3899[3][2] = {{6L,6L},{0x1B378B29L,6L},{6L,0x1B378B29L}};
            int64_t *l_3925 = &g_744;
            int32_t l_4000 = 0xB5E95AB9L;
            int32_t *l_4001 = &g_1342;
            int32_t l_4036 = 0x92119572L;
            const int16_t l_4041 = 0xED3CL;
            uint64_t **l_4079 = &l_3911[0][4][3];
            uint64_t **l_4081 = (void*)0;
            struct S0 **l_4096 = &l_3585;
            union U1 ***l_4128 = &g_2054[4];
            uint32_t l_4173 = 0xD28C2CB2L;
            uint16_t l_4242 = 0xCB7CL;
            const uint16_t l_4243 = 0xAD54L;
            int8_t l_4248[9] = {8L,8L,4L,8L,8L,4L,8L,8L,4L};
            union U2 ***l_4293 = (void*)0;
            uint32_t ****l_4311 = &g_2312;
            uint64_t l_4324 = 0x867C77429F66F24DLL;
            int32_t l_4335 = (-8L);
            uint8_t l_4382 = 1UL;
            uint8_t l_4424 = 247UL;
            int i, j;
            if ((*l_3809))
            { /* block id: 1659 */
                uint8_t ** const l_3851 = &g_1768[9][0][1];
                int32_t l_3852 = 1L;
                int32_t l_3885[7][8] = {{0x81F1C222L,0x9B8863D8L,3L,1L,1L,3L,0x9B8863D8L,0x81F1C222L},{0x81F1C222L,0x493480E0L,0xDFBA48ABL,(-9L),0x9B8863D8L,(-8L),3L,(-8L)},{(-9L),7L,1L,7L,(-9L),(-8L),0x44BFB096L,0x9B8863D8L},{(-3L),0x493480E0L,7L,(-1L),3L,3L,(-1L),7L},{0x9B8863D8L,0x9B8863D8L,7L,0x81F1C222L,0xDFBA48ABL,1L,0x44BFB096L,(-3L)},{3L,0x44BFB096L,1L,0x9B8863D8L,1L,0x44BFB096L,3L,(-3L)},{0x44BFB096L,1L,0xDFBA48ABL,0x81F1C222L,7L,0x9B8863D8L,0x9B8863D8L,7L}};
                uint32_t **l_3910 = &g_351;
                const int64_t *l_3926 = &g_176;
                uint32_t * const *l_3962[8] = {(void*)0,&g_2314[0][2],(void*)0,&g_2314[0][2],(void*)0,&g_2314[0][2],(void*)0,&g_2314[0][2]};
                uint32_t * const **l_3961 = &l_3962[6];
                int i, j;
                (*l_3809) = (-1L);
                for (g_3756.f2 = 1; (g_3756.f2 <= 5); g_3756.f2 += 1)
                { /* block id: 1663 */
                    int16_t l_3853 = 0xE1E0L;
                    uint16_t l_3855[3];
                    const struct S0 ****l_3865 = &g_2117[0];
                    const struct S0 *****l_3866 = &l_3865;
                    int16_t *l_3881 = &l_3791[0];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_3855[i] = 0xE002L;
                    if (((safe_unary_minus_func_uint64_t_u(((safe_lshift_func_int16_t_s_s((l_3848 , (safe_add_func_uint16_t_u_u(((l_3851 != (void*)0) , (p_39 & (l_3848 > l_3852))), p_37))), l_3852)) , 18446744073709551615UL))) != p_37))
                    { /* block id: 1664 */
                        l_3855[2]--;
                    }
                    else
                    { /* block id: 1666 */
                        l_3858 = &g_2396;
                    }
                    l_3885[0][4] &= (((safe_mul_func_int32_t_s_s(l_3855[0], ((*g_89) = ((safe_mul_func_uint16_t_u_u((0xA5L == p_38), (((*l_3866) = l_3865) != (void*)0))) < (0xA9L && ((((safe_lshift_func_uint64_t_u_s(((l_3854[4][0] = (((safe_sub_func_uint16_t_u_u((((((*g_768) = (*g_768)) == (((safe_sub_func_uint8_t_u_u((((((safe_mod_func_int64_t_s_s((((safe_sub_func_int64_t_s_s((((*l_3881) = ((safe_sub_func_uint8_t_u_u(((g_3879[0][4] , ((!(l_3852 | (*g_1122))) <= 0x7FC75796L)) , l_3852), l_3848)) <= p_39)) ^ (*l_3809)), (*l_3809))) , l_3882) != (void*)0), p_39)) <= (-1L)) , 4294967294UL) | l_3852) <= l_3848), p_37)) == 18446744073709551612UL) , l_3883)) , (void*)0) == l_3884), l_3852)) , p_39) ^ l_3848)) < (**g_1236)), 3)) > p_40) < p_39) || p_39)))))) != p_39) & p_37);
                    return p_38;
                }
                for (g_1042.f2 = (-9); (g_1042.f2 > (-30)); g_1042.f2--)
                { /* block id: 1679 */
                    uint8_t l_3896[6][9][4] = {{{0x8EL,1UL,2UL,0UL},{0xC6L,0UL,255UL,0x61L},{0xC4L,0xC6L,2UL,0xC4L},{0xAAL,3UL,3UL,0xAAL},{0UL,255UL,0UL,3UL},{3UL,1UL,0x0EL,5UL},{247UL,1UL,0UL,5UL},{0x22L,1UL,0x02L,3UL},{255UL,255UL,0xC4L,0xAAL}},{{0xD8L,3UL,5UL,0xC4L},{255UL,0xC6L,0x0EL,1UL},{0UL,247UL,255UL,0x82L},{0UL,1UL,0UL,0UL},{0xAAL,3UL,0UL,2UL},{0xD8L,255UL,1UL,3UL},{3UL,253UL,1UL,1UL},{0xD8L,0UL,0UL,1UL},{0xAAL,0xC6L,0UL,255UL}},{{0UL,255UL,255UL,255UL},{0UL,255UL,0x0EL,0UL},{255UL,252UL,5UL,5UL},{0xD8L,0xD8L,0xC4L,0x82L},{255UL,253UL,0x02L,255UL},{0x22L,3UL,0UL,0x02L},{247UL,3UL,0x0EL,255UL},{3UL,253UL,0UL,0x82L},{0UL,0xD8L,3UL,5UL}},{{0xAAL,252UL,2UL,0UL},{0x22L,255UL,0xC4L,255UL},{1UL,255UL,1UL,255UL},{255UL,0xC6L,5UL,1UL},{247UL,0UL,3UL,1UL},{0UL,253UL,0x22L,3UL},{0UL,255UL,3UL,2UL},{247UL,3UL,5UL,0UL},{255UL,1UL,1UL,0x82L}},{{1UL,247UL,0xC4L,1UL},{0x22L,0xC6L,2UL,0xC4L},{0xAAL,3UL,3UL,0xAAL},{0UL,255UL,0UL,3UL},{3UL,1UL,0x0EL,5UL},{247UL,1UL,0UL,5UL},{0x22L,1UL,0x02L,3UL},{255UL,255UL,0xC4L,0xAAL},{0xD8L,3UL,5UL,0xC4L}},{{255UL,0xC6L,0x0EL,1UL},{0UL,247UL,255UL,0x82L},{0UL,1UL,0UL,0UL},{0xAAL,3UL,0UL,2UL},{0xD8L,255UL,1UL,2UL},{2UL,0UL,1UL,0xC6L},{248UL,3UL,0x02L,1UL},{0x0EL,1UL,0x82L,0UL},{0x82L,0UL,0x61L,5UL}}};
                    int i, j, k;
                    for (g_2121.f3 = 4; (g_2121.f3 >= 0); g_2121.f3 -= 1)
                    { /* block id: 1682 */
                        int16_t l_3893 = 0x2DE8L;
                        l_3893 |= ((!(0UL ^ (safe_sub_func_uint8_t_u_u(p_37, l_3848)))) != ((void*)0 != l_3891[1]));
                    }
                    for (g_589.f0 = 0; (g_589.f0 != 16); g_589.f0 = safe_add_func_int8_t_s_s(g_589.f0, 8))
                    { /* block id: 1687 */
                        uint8_t *l_3900 = &g_750[1];
                        uint64_t *l_3906 = &g_3586[8][0].f5;
                        uint64_t **l_3907 = &g_914;
                        int32_t l_3914 = 0L;
                        if (l_3896[3][3][0])
                            break;
                        p_37 = (*g_1122);
                        (*l_3809) |= ((safe_mul_func_uint8_t_u_u((l_3899[0][0] = ((*l_3900)++)), (!(((safe_rshift_func_uint8_t_u_u((p_39 >= p_39), ((((*g_249) ^ (((((*l_3907) = l_3906) == ((safe_lshift_func_int8_t_s_u((((void*)0 != l_3910) , 0x15L), 4)) , l_3911[6][5][3])) | ((((*g_1341) = (safe_mul_func_uint16_t_u_u(65535UL, l_3852))) , (*g_1122)) >= p_37)) < p_39)) != p_40) ^ p_40))) < p_40) == l_3914)))) <= l_3914);
                        (*g_1341) &= ((*g_89) = (0xC31F8B8EL >= (*l_3809)));
                    }
                    for (g_980.f2 = 0; (g_980.f2 != 26); ++g_980.f2)
                    { /* block id: 1700 */
                        if (p_40)
                            break;
                    }
                }
                if ((safe_mul_func_uint8_t_u_u(0xFFL, ((((((((p_38 , ((*l_3809) = (((safe_sub_func_int8_t_s_s(l_3885[0][0], (l_3885[4][3] <= (safe_div_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s((*g_768), ((l_3925 = (void*)0) == l_3926))) && ((1UL == ((void*)0 == &l_3882)) & p_39)), 0xA6331AA5L))))) <= 251UL) == l_3899[0][0]))) & (*g_1341)) , (*g_768)) , 0UL) < p_37) | p_40) , p_38) <= p_39))))
                { /* block id: 1706 */
                    int16_t l_3933 = 1L;
                    uint16_t * const l_3934 = &g_901;
                    (*g_89) = (!(safe_add_func_uint16_t_u_u((**g_1236), (p_37 , (p_39 |= (safe_lshift_func_uint64_t_u_s((((*l_3809) > ((safe_unary_minus_func_uint16_t_u(65534UL)) && 0x2C186AAFL)) , l_3933), ((l_3934 != (((++g_602.f0) , (safe_div_func_uint8_t_u_u((safe_unary_minus_func_uint64_t_u((safe_lshift_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(0L, l_3933)), 6)))), 255UL))) , (***l_3884))) && 0x9BBE1DAFL))))))));
                }
                else
                { /* block id: 1710 */
                    int64_t l_3944 = (-3L);
                    int32_t l_3945 = 0x496EBB0FL;
                    int32_t l_3946 = 0xE37776B7L;
                    uint16_t l_3965 = 0xB515L;
                    for (g_962.f0 = 0; (g_962.f0 <= 1); g_962.f0 += 1)
                    { /* block id: 1713 */
                        uint64_t l_3947 = 0x2AB54A7A394F9192LL;
                        l_3947--;
                        (*l_3809) = p_39;
                        return p_39;
                    }
                    l_3809 = func_69((safe_mod_func_int32_t_s_s((safe_mod_func_int64_t_s_s((((safe_sub_func_uint16_t_u_u((safe_div_func_uint16_t_u_u((p_37 ^ ((((((safe_unary_minus_func_int8_t_s((~(~p_37)))) , 0x3FCA8C1356108AE9LL) < (l_3848 , ((&l_3622 != (void*)0) | (((l_3961 == (void*)0) & g_3963) ^ l_3945)))) , l_3852) | 0x75B1964AL) && l_3964)), p_39)), 0xE526L)) && p_39) , l_3848), p_40)), (-5L))), p_37, &l_3489, &l_3852, &l_3946);
                    l_3965--;
                }
            }
            else
            { /* block id: 1721 */
                union U1 *l_3995 = &g_3996;
                int32_t l_3997[1];
                int16_t l_4006[3][2] = {{0xD83DL,0xD83DL},{0xD83DL,0xD83DL},{0xD83DL,0xD83DL}};
                uint16_t l_4031 = 65530UL;
                uint8_t l_4034[3][3] = {{0x8EL,0xC1L,0x8EL},{0x1DL,0x1DL,0x1DL},{0x8EL,0xC1L,0x8EL}};
                uint32_t ** const **l_4042 = &l_3892;
                uint8_t **l_4053 = &g_1768[6][5][1];
                uint32_t l_4099 = 18446744073709551610UL;
                int32_t l_4100 = 1L;
                const int8_t l_4133 = 0xEFL;
                int i, j;
                for (i = 0; i < 1; i++)
                    l_3997[i] = 0L;
                if (((0x81L >= p_37) , 9L))
                { /* block id: 1722 */
                    return l_3899[1][0];
                }
                else
                { /* block id: 1724 */
                    int16_t l_3984[9][6] = {{2L,0xE4B8L,5L,0xE4B8L,2L,2L},{(-1L),0xE4B8L,0xE4B8L,(-1L),0xB8A3L,(-1L)},{(-1L),0xB8A3L,(-1L),0xE4B8L,0xE4B8L,(-1L)},{2L,2L,0xE4B8L,5L,0xE4B8L,2L},{0xE4B8L,0xB8A3L,5L,5L,0xB8A3L,0xE4B8L},{2L,0xE4B8L,5L,0xE4B8L,2L,2L},{(-1L),0xE4B8L,0xE4B8L,(-1L),0xB8A3L,(-1L)},{(-1L),0xB8A3L,(-1L),0xE4B8L,0xE4B8L,(-1L)},{2L,2L,0xE4B8L,5L,0xE4B8L,2L}};
                    union U1 *l_3993 = &g_3994;
                    int32_t l_4002 = 0xD1C13664L;
                    uint32_t ****l_4038 = &g_2312;
                    struct S0 *l_4045 = (void*)0;
                    uint8_t **l_4058 = &g_1768[0][5][2];
                    uint64_t **l_4078 = &l_3911[6][3][5];
                    int i, j;
                    if (p_37)
                    { /* block id: 1725 */
                        uint32_t *l_3989 = &l_3801;
                        int32_t l_3998 = (-3L);
                        int16_t *l_3999[5][6] = {{&g_3963,&g_3588.f3,&g_3588.f3,&g_3963,(void*)0,&g_10[3]},{&g_10[3],&g_3963,(void*)0,&g_3963,&g_10[3],(void*)0},{&g_3963,&g_10[3],(void*)0,(void*)0,&g_10[3],&g_3963},{&g_3588.f3,&g_3963,(void*)0,&g_10[3],(void*)0,&g_3963},{(void*)0,&g_3588.f3,(void*)0,(void*)0,(void*)0,(void*)0}};
                        int i, j;
                        (*l_3802) = func_69(((*g_89) = ((safe_add_func_uint64_t_u_u(p_37, (safe_sub_func_int64_t_s_s(p_39, (safe_sub_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s((((l_4000 = (safe_div_func_int64_t_s_s((safe_mul_func_uint32_t_u_u((((*g_3423) = (l_3899[1][0] = (((safe_rshift_func_int64_t_s_s(l_3984[4][5], ((l_3998 = ((p_37 < ((((safe_rshift_func_int32_t_s_u((safe_rshift_func_uint8_t_u_s((((((*l_3989) = l_3899[0][1]) < (safe_lshift_func_uint64_t_u_u(p_40, 49))) || p_39) | 0xE6L), 5)), 31)) ^ ((((((~(l_3993 == l_3995)) , p_37) == 1UL) <= l_3848) > l_3997[0]) ^ p_37)) > l_3998) < p_38)) , p_38)) , l_3998))) , 0xF2D18840L) , (*l_3809)))) & p_38), 4294967295UL)), (-6L)))) | l_3848) && l_3984[1][5]), 0UL)) > (****g_3830)), 0x4A36L)), p_39)))))) , l_3998)), p_40, &l_3997[0], l_3989, l_4001);
                        l_3997[0] = (((l_4002 = 0xC0L) , (**g_1236)) , ((*g_1341) = ((--(*g_914)) || 1L)));
                        l_4006[0][0] = ((!(&g_3297 == (void*)0)) && (-9L));
                        p_37 = (-9L);
                    }
                    else
                    { /* block id: 1739 */
                        uint16_t *l_4032 = (void*)0;
                        uint16_t *l_4033 = &l_3658;
                        int32_t l_4035 = 0L;
                        p_37 ^= ((*g_89) |= (safe_div_func_int32_t_s_s(((safe_mul_func_int64_t_s_s(p_40, ((*g_249) |= (-1L)))) <= ((safe_mul_func_int16_t_s_s((0x0E66C2F6L && (*l_4001)), (((safe_lshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u(((((--(*g_1237)) & (safe_rshift_func_uint16_t_u_s((safe_add_func_uint16_t_u_u(0x1E24L, (safe_rshift_func_uint32_t_u_s((safe_mod_func_uint8_t_u_u(((p_38 = (*l_4001)) | (safe_lshift_func_uint8_t_u_u(l_3997[0], ((((*l_4033) ^= (l_3984[6][3] , (safe_div_func_int64_t_s_s((((18446744073709551615UL | p_39) , l_4031) < (*g_1341)), 1L)))) & (-2L)) ^ (-8L))))), (*l_3809))), l_4034[1][2])))), l_4002))) & 0L) | l_4035), p_39)), p_40)) && 0L) & l_4036))) <= p_39)), l_3883)));
                        if (g_3556)
                            goto lbl_4037;
                        p_37 &= (l_4038 != ((safe_sub_func_uint8_t_u_u((p_39 && (*l_3809)), l_4041)) , l_4042));
                        l_3993 = ((0x080F0503L ^ 0x8596EA56L) , l_3993);
                    }
                    for (l_3658 = 19; (l_3658 == 29); l_3658++)
                    { /* block id: 1752 */
                        int64_t l_4046 = 9L;
                        int32_t l_4047 = 7L;
                        uint32_t l_4048[8] = {18446744073709551607UL,18446744073709551610UL,18446744073709551610UL,18446744073709551607UL,18446744073709551610UL,18446744073709551610UL,18446744073709551607UL,18446744073709551610UL};
                        int i;
                        (*g_2118) = l_4045;
                        l_4048[2]--;
                        (*g_3423) &= p_40;
                        (*g_1122) |= l_3984[4][5];
                    }
                    for (g_589.f3 = 5; (g_589.f3 >= 2); g_589.f3 -= 1)
                    { /* block id: 1760 */
                        uint8_t ***l_4054 = (void*)0;
                        uint8_t ***l_4055 = (void*)0;
                        uint8_t ***l_4056 = (void*)0;
                        uint8_t ***l_4057 = &g_1767;
                        int32_t l_4061 = 0L;
                        uint16_t l_4062 = 0x46B8L;
                        uint32_t *l_4063[3];
                        uint64_t **l_4080 = &g_914;
                        uint64_t ***l_4082 = &l_4080;
                        uint8_t *l_4124 = &g_750[1];
                        int8_t *l_4125[7][5][7] = {{{&g_2606,&g_2606,&g_2606,(void*)0,(void*)0,&g_2606,&g_2606},{&g_51[4][2][2],&g_3781,&g_2606,&g_2606,&g_2606,&g_2606,&g_2606},{&g_51[4][2][2],&g_2606,&g_3781,&g_3781,(void*)0,&g_3781,(void*)0},{&g_51[4][2][2],&g_2606,(void*)0,&g_2606,&g_2606,(void*)0,&g_2606},{&g_2606,(void*)0,&g_3781,(void*)0,&g_3781,&g_3781,&g_2606}},{{&g_3781,&g_2606,&g_2606,&g_2606,&g_2606,&g_2606,&g_3781},{&g_2606,&g_2606,&g_2606,(void*)0,(void*)0,&g_2606,&g_2606},{&g_51[4][2][2],&g_3781,&g_2606,&g_2606,&g_2606,&g_2606,&g_2606},{&g_51[4][2][2],&g_2606,&g_3781,&g_3781,(void*)0,&g_3781,(void*)0},{&g_51[4][2][2],&g_2606,(void*)0,&g_2606,&g_3781,&g_2606,&g_749}},{{&g_51[4][2][2],&g_51[4][1][0],&g_2606,&g_51[4][2][2],&g_3781,&g_2606,&g_51[3][1][2]},{&g_2606,&g_749,&g_749,&g_51[4][1][1],&g_3781,&g_749,&g_2606},{&g_51[4][2][2],&g_51[3][1][2],(void*)0,&g_51[4][2][2],&g_51[4][2][2],(void*)0,&g_51[3][1][2]},{&g_51[4][2][2],&g_2606,&g_749,&g_3781,&g_51[4][1][1],&g_749,&g_749},{&g_2606,&g_51[3][1][2],&g_2606,&g_3781,&g_51[4][2][2],&g_2606,&g_51[4][1][0]}},{{&g_51[4][2][2],&g_749,&g_2606,&g_3781,&g_3781,&g_2606,&g_749},{&g_51[4][2][2],&g_51[4][1][0],&g_2606,&g_51[4][2][2],&g_3781,&g_2606,&g_51[3][1][2]},{&g_2606,&g_749,&g_749,&g_51[4][1][1],&g_3781,&g_749,&g_2606},{&g_51[4][2][2],&g_51[3][1][2],(void*)0,&g_51[4][2][2],&g_51[4][2][2],(void*)0,&g_51[3][1][2]},{&g_51[4][2][2],&g_2606,&g_749,&g_3781,&g_51[4][1][1],&g_749,&g_749}},{{&g_2606,&g_51[3][1][2],&g_2606,&g_3781,&g_51[4][2][2],&g_2606,&g_51[4][1][0]},{&g_51[4][2][2],&g_749,&g_2606,&g_3781,&g_3781,&g_2606,&g_749},{&g_51[4][2][2],&g_51[4][1][0],&g_2606,&g_51[4][2][2],&g_3781,&g_2606,&g_51[3][1][2]},{&g_2606,&g_749,&g_749,&g_51[4][1][1],&g_3781,&g_749,&g_2606},{&g_51[4][2][2],&g_51[3][1][2],(void*)0,&g_51[4][2][2],&g_51[4][2][2],(void*)0,&g_51[3][1][2]}},{{&g_51[4][2][2],&g_2606,&g_749,&g_3781,&g_51[4][1][1],&g_749,&g_749},{&g_2606,&g_51[3][1][2],&g_2606,&g_3781,&g_51[4][2][2],&g_2606,&g_51[4][1][0]},{&g_51[4][2][2],&g_749,&g_2606,&g_3781,&g_3781,&g_2606,&g_749},{&g_51[4][2][2],&g_51[4][1][0],&g_2606,&g_51[4][2][2],&g_3781,&g_2606,&g_51[3][1][2]},{&g_2606,&g_749,&g_749,&g_51[4][1][1],&g_3781,&g_749,&g_2606}},{{&g_51[4][2][2],&g_51[3][1][2],(void*)0,&g_51[4][2][2],&g_51[4][2][2],(void*)0,&g_51[3][1][2]},{&g_51[4][2][2],&g_2606,&g_749,&g_3781,&g_51[4][1][1],&g_749,&g_749},{&g_2606,&g_51[3][1][2],&g_2606,&g_3781,&g_51[4][2][2],&g_2606,&g_51[4][1][0]},{&g_51[4][2][2],&g_749,&g_2606,&g_3781,&g_3781,&g_2606,&g_749},{&g_51[4][2][2],&g_51[4][1][0],&g_2606,&g_51[4][2][2],&g_3781,&g_2606,&g_51[3][1][2]}}};
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_4063[i] = &l_3783;
                        (*g_1122) = ((*l_3809) |= ((safe_lshift_func_int16_t_s_u(p_37, ((l_3854[5][0] = ((((*l_4057) = l_4053) == ((((*l_4038) = (*l_4038)) == (*l_4042)) , l_4058)) ^ (((*l_4001) & (safe_add_func_int64_t_s_s(((((*l_4001) , 0xF3A3B9BCL) < p_40) <= l_4061), l_4062))) || p_38))) || 0x9632D361L))) > 255UL));
                        p_37 |= 1L;
                        l_4103 = ((safe_add_func_uint16_t_u_u(((p_40 , (((safe_lshift_func_int32_t_s_s((((safe_mul_func_uint16_t_u_u((safe_div_func_uint16_t_u_u((l_4002 | (((safe_add_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((g_117 = (((safe_div_func_int8_t_s_s(((((0xE63FB9A2847D79A0LL > ((l_4079 = l_4078) != ((*l_4082) = (l_4081 = l_4080)))) < ((((safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s((-6L), ((~((safe_lshift_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(((safe_mul_func_uint64_t_u_u((l_4100 = (((safe_rshift_func_uint16_t_u_s(((l_4099 = ((((void*)0 != l_4096) ^ (safe_div_func_uint8_t_u_u(((*l_3809) |= 246UL), p_39))) , 0xEDB4L)) & (*l_4001)), 2)) > p_37) | 0xD73BL)), (-8L))) , (-1L)), (*g_768))), (*l_4001))) != p_40)) | 0x0FL))), l_4101)) == p_40) < p_38) | p_39)) || p_38) , (*g_768)), l_4102[3][0][4])) <= p_40) < p_37)), (*l_4001))), p_38)) && l_4061) && p_39)), 8UL)), (**g_1236))) , l_3984[4][5]) && 4294967295UL), 23)) && (*l_4001)) == (-5L))) , 7UL), p_39)) , (void*)0);
                        (*g_1122) ^= (safe_mul_func_int16_t_s_s((((**g_1236) = (!(safe_sub_func_uint64_t_u_u(((safe_mod_func_int8_t_s_s((safe_rshift_func_int16_t_s_u((safe_lshift_func_int64_t_s_s(((*g_249) = ((safe_add_func_int8_t_s_s((safe_mul_func_int32_t_s_s(((l_4122 = g_4120) == g_4123), (((((p_38 |= (p_39 <= ((*g_768) && ((*l_4124) ^= 255UL)))) == (safe_add_func_uint64_t_u_u((((l_4002 || (0xF6C40B6FL != (((l_4061 != (((*l_4001) = p_39) <= p_40)) < l_4062) || p_40))) , 1UL) && l_3997[0]), p_39))) , &g_2054[3]) != l_4128) , p_40))), 3UL)) , (*l_4001))), 18)), p_40)), p_40)) , p_40), l_4100)))) | 0x4011L), p_39));
                    }
                }
                for (g_3620.f3 = 0; (g_3620.f3 != (-14)); --g_3620.f3)
                { /* block id: 1786 */
                    for (g_1282 = 0; (g_1282 <= 1); g_1282 += 1)
                    { /* block id: 1789 */
                        (*l_4001) = (safe_add_func_int8_t_s_s(((p_38 <= l_4133) || (safe_sub_func_int16_t_s_s(0xC5BEL, (((safe_add_func_int16_t_s_s(0x1A66L, (p_39 <= p_40))) >= (safe_lshift_func_int64_t_s_u((*l_3809), p_40))) & ((safe_lshift_func_int32_t_s_s((*l_4001), 6)) >= 0x5A7493F7AE669056LL))))), 0UL));
                    }
                    (*l_3809) = (0x17F9L ^ 5UL);
                }
                return p_37;
            }
            if (((*g_3423) = p_39))
            { /* block id: 1797 */
                struct S0 *****l_4145 = &l_4144;
                (*l_4145) = l_4144;
            }
            else
            { /* block id: 1799 */
                return p_39;
            }
            for (g_985.f2 = 0; (g_985.f2 <= 28); ++g_985.f2)
            { /* block id: 1804 */
                uint64_t l_4168[9][7] = {{18446744073709551615UL,0x337332AD1EDBD22ALL,18446744073709551615UL,0x69165F81890BED34LL,0x69165F81890BED34LL,18446744073709551615UL,0x337332AD1EDBD22ALL},{0x4B2B550ACF445893LL,0xDC34BFC3260B337FLL,18446744073709551615UL,18446744073709551615UL,0xDC34BFC3260B337FLL,0UL,0UL},{0x1E6714080AC4017ELL,18446744073709551615UL,18446744073709551615UL,0x1E6714080AC4017ELL,18446744073709551615UL,0x1E6714080AC4017ELL,18446744073709551615UL},{0x4B2B550ACF445893LL,0x4B2B550ACF445893LL,0UL,0xDC34BFC3260B337FLL,0UL,0x4B2B550ACF445893LL,0x4B2B550ACF445893LL},{0x69165F81890BED34LL,18446744073709551615UL,0x337332AD1EDBD22ALL,18446744073709551615UL,0x69165F81890BED34LL,0x69165F81890BED34LL,18446744073709551615UL},{18446744073709551615UL,0UL,18446744073709551615UL,0UL,0UL,18446744073709551615UL,0UL},{18446744073709551615UL,18446744073709551615UL,0x337332AD1EDBD22ALL,0x337332AD1EDBD22ALL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,0UL,0UL,18446744073709551615UL,0UL,18446744073709551615UL,0UL},{0x69165F81890BED34LL,0x69165F81890BED34LL,18446744073709551615UL,0x337332AD1EDBD22ALL,18446744073709551615UL,0x69165F81890BED34LL,0x69165F81890BED34LL}};
                int32_t l_4210 = (-1L);
                int32_t l_4223 = 4L;
                int32_t l_4225 = 2L;
                int32_t l_4226 = 0x0709698FL;
                int32_t l_4229 = 0x84559D2EL;
                uint64_t l_4230 = 0xE489D95BC7E12E7DLL;
                int32_t * const **l_4245[5];
                int i, j;
                for (i = 0; i < 5; i++)
                    l_4245[i] = &g_1340[1][5];
                if ((safe_lshift_func_uint16_t_u_s((&g_2748 == (void*)0), 11)))
                { /* block id: 1805 */
                    int32_t l_4154 = 0L;
                    uint8_t *l_4169 = &g_750[1];
                    int32_t l_4172 = 8L;
                    int32_t *l_4192 = &g_987.f3;
                    uint64_t ** const l_4199[4][8][4] = {{{&g_914,(void*)0,&g_914,&g_914},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_3911[5][3][2],&g_914,&g_914,(void*)0},{&l_3911[6][5][3],(void*)0,&l_3911[6][5][3],&g_914},{&l_3911[6][5][3],(void*)0,&l_3911[4][4][2],&l_3911[6][5][3]},{&l_3911[5][3][2],&g_914,&g_914,(void*)0},{&g_914,(void*)0,&g_914,&g_914},{&l_3911[5][3][2],&l_3911[5][3][2],&l_3911[4][4][2],(void*)0}},{{&l_3911[6][5][3],&l_3911[5][0][0],&l_3911[6][5][3],(void*)0},{&l_3911[6][5][3],(void*)0,&g_914,&l_3911[6][5][3]},{&l_3911[5][3][2],(void*)0,(void*)0,(void*)0},{(void*)0,&l_3911[5][0][0],&g_914,(void*)0},{&g_914,&l_3911[5][3][2],&g_914,&g_914},{&l_3911[6][5][3],(void*)0,&l_3911[6][3][3],(void*)0},{&l_3911[6][5][3],&g_914,&g_914,&l_3911[6][5][3]},{&g_914,(void*)0,&g_914,&g_914}},{{(void*)0,(void*)0,(void*)0,(void*)0},{&l_3911[5][3][2],&g_914,&g_914,(void*)0},{&l_3911[6][5][3],(void*)0,&l_3911[6][5][3],&g_914},{&l_3911[6][5][3],(void*)0,&l_3911[4][4][2],&l_3911[6][5][3]},{&l_3911[5][3][2],&g_914,&g_914,(void*)0},{&g_914,(void*)0,&g_914,&g_914},{&l_3911[5][3][2],&l_3911[5][3][2],&l_3911[4][4][2],(void*)0},{&l_3911[6][5][3],&l_3911[5][0][0],&l_3911[6][5][3],(void*)0}},{{&l_3911[6][5][3],(void*)0,&g_914,&l_3911[6][5][3]},{&l_3911[5][3][2],(void*)0,(void*)0,(void*)0},{(void*)0,&l_3911[5][0][0],&g_914,(void*)0},{&g_914,&l_3911[5][3][2],&g_914,&g_914},{&l_3911[6][5][3],(void*)0,&l_3911[6][3][3],(void*)0},{&l_3911[6][5][3],&g_914,&g_914,&l_3911[6][5][3]},{&g_914,(void*)0,&g_914,&g_914},{(void*)0,(void*)0,(void*)0,(void*)0}}};
                    int32_t ***l_4244[4][4] = {{&l_3802,&l_3802,&l_3802,(void*)0},{&l_3802,(void*)0,&l_3802,&l_3802},{&l_3802,&l_3802,&l_3802,&l_3802},{&l_3802,&l_3802,(void*)0,&l_3802}};
                    int8_t *****l_4246 = &l_4184;
                    int i, j, k;
                    if (p_37)
                        break;
                    if (((safe_add_func_uint32_t_u_u((((safe_div_func_uint64_t_u_u(p_40, 0xA5B8E80F71CFF6A1LL)) || (l_4154 & (((safe_div_func_int32_t_s_s((safe_rshift_func_uint32_t_u_s(((safe_div_func_uint16_t_u_u((p_39 && ((g_4161[0][8] <= ((l_4154 ^ (l_4172 |= ((((((safe_sub_func_int16_t_s_s((p_40 > (safe_mod_func_uint8_t_u_u((safe_add_func_uint8_t_u_u(((*l_4169) |= l_4168[2][1]), ((!p_40) >= 1L))), (-5L)))), l_4171)) | (****g_3297)) > p_38) , (****g_3297)) ^ p_37) != p_37))) , l_4173)) , p_37)), p_39)) > p_40), 13)), 0x5C82418AL)) & p_40) && 0xA3L))) , l_4168[2][1]), p_37)) || 8L))
                    { /* block id: 1809 */
                        int8_t *****l_4183[7][10][3] = {{{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,(void*)0,&g_4182},{&g_4182,&g_4182,&g_4182}},{{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,(void*)0,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0}},{{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,(void*)0,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,(void*)0,&g_4182}},{{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182}},{{&g_4182,&g_4182,(void*)0},{&g_4182,(void*)0,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,(void*)0,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182}},{{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,(void*)0,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182}},{{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,(void*)0},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,(void*)0,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182},{&g_4182,&g_4182,&g_4182}}};
                        int32_t l_4190 = (-5L);
                        int16_t *l_4191 = &g_3586[8][0].f3;
                        int i, j, k;
                        l_4192 = func_58(p_40, (safe_rshift_func_uint32_t_u_u(p_40, 25)), (p_39 && (safe_mod_func_int32_t_s_s((*g_1341), (l_4168[7][5] & p_38)))), ((*l_4191) ^= (safe_lshift_func_uint32_t_u_s(((safe_lshift_func_int64_t_s_u(((*g_249) = ((*l_4001) && ((((p_40 , (l_4184 = g_4182)) == l_4187) & 0xC90AB32E5AA0B3DBLL) < l_4190))), 21)) ^ 4L), l_4172))), l_4154);
                    }
                    else
                    { /* block id: 1814 */
                        int16_t * const l_4206 = &g_4207[0];
                        int16_t * const *l_4205 = &l_4206;
                        int16_t * const **l_4204 = &l_4205;
                        l_3964 ^= (safe_mod_func_uint32_t_u_u(p_39, (safe_lshift_func_uint64_t_u_s(((*l_4001) == (((safe_div_func_uint64_t_u_u(((l_4199[3][6][3] == (void*)0) | (safe_add_func_int64_t_s_s((((((safe_div_func_int32_t_s_s(((**l_3485) == ((*l_4204) = (*g_2594))), (-6L))) | (((safe_div_func_uint16_t_u_u(((****g_3297) = p_37), p_40)) < (-3L)) < p_40)) | p_37) < p_40) , 1L), l_4168[2][1]))), 1UL)) , l_4168[8][5]) == p_40)), 31))));
                    }
                    if (((*g_3423) = l_4210))
                    { /* block id: 1820 */
                        return l_4210;
                    }
                    else
                    { /* block id: 1822 */
                        uint16_t *l_4215 = &l_3622;
                        int32_t l_4218 = 6L;
                        int64_t ***l_4221 = &g_248;
                        uint32_t *l_4222 = &g_421;
                        uint8_t *l_4224 = &g_110;
                        int32_t l_4227 = 0L;
                        int32_t l_4228 = 0x88B49845L;
                        int8_t *****l_4235 = (void*)0;
                        (*g_3423) ^= (safe_rshift_func_int64_t_s_u((5L & (safe_sub_func_uint16_t_u_u((****g_3297), ((*l_4215) = (*g_1237))))), ((safe_mul_func_int8_t_s_s(l_4218, (safe_sub_func_int64_t_s_s(((((p_37 & ((*l_4224) = (((*l_4169) = ((void*)0 != l_4221)) , (((((((((*g_771) = 0x80L) && ((((((*l_4222) |= ((18446744073709551611UL || p_39) < l_4168[2][1])) && p_37) & 0xD538A46A870AE305LL) ^ l_4223) || 0x0969L)) < p_39) , p_37) ^ 0x02EBEC86CE7F5DC2LL) || 255UL) , p_37) | 0xE8EAL)))) , p_38) == 65535UL) | p_39), 0x573FE0C08AA98FF5LL)))) , p_40)));
                        l_4230++;
                        l_4247 = ((p_39 == (((((0x60C0L || (((*l_4215) = ((safe_add_func_uint8_t_u_u(1UL, ((l_4235 = &g_4182) == ((safe_mul_func_uint32_t_u_u(4294967295UL, ((((((((safe_rshift_func_uint16_t_u_s((safe_sub_func_int32_t_s_s((p_37 &= l_4242), ((p_38 , p_39) <= l_4243))), p_40)) == 0x4D9305CF06C40E26LL) & 4294967294UL) , l_4244[1][3]) == l_4245[0]) ^ 0x8063L) != p_38) , (*l_4001)))) , l_4246)))) , p_37)) & 65535UL)) < 0x8CL) ^ p_39) && 0x4E14L) && p_40)) ^ p_38);
                    }
                    if ((l_4248[7] ^ (safe_rshift_func_int32_t_s_u(p_37, 21))))
                    { /* block id: 1835 */
                        volatile int32_t **l_4252 = &g_4251;
                        (*g_2638) = (**g_2637);
                        (*l_4252) = g_4251;
                        p_37 = (&l_4199[3][6][3] != (void*)0);
                    }
                    else
                    { /* block id: 1839 */
                        uint16_t l_4253 = 65534UL;
                        (*g_927) = (*g_927);
                        (*l_4192) = (*g_3423);
                        l_4253--;
                        if ((*l_4001))
                            break;
                    }
                }
                else
                { /* block id: 1845 */
                    (*l_3802) = &p_37;
                }
                l_3777[7] = &l_3573;
                for (g_966.f0 = (-11); (g_966.f0 <= 8); g_966.f0 = safe_add_func_uint32_t_u_u(g_966.f0, 7))
                { /* block id: 1851 */
                    uint8_t l_4260 = 1UL;
                    int16_t **l_4283 = &g_1721[2];
                    int32_t l_4288 = 0x7697A927L;
                    int32_t l_4291 = 0x0C54DB74L;
                    for (g_2121.f8 = (-28); (g_2121.f8 <= (-29)); g_2121.f8--)
                    { /* block id: 1854 */
                        int16_t **l_4284 = &g_1721[2];
                        uint64_t l_4286 = 0x412E84361B3F0C8BLL;
                        uint8_t *l_4287 = &l_4260;
                        int32_t l_4289 = 1L;
                        l_4260 |= p_37;
                        (*g_1341) = ((-2L) > p_39);
                        (*l_3802) = &p_37;
                    }
                }
            }
            if (((*g_3423) = ((void*)0 != l_4293)))
            { /* block id: 1869 */
                uint32_t l_4295[4] = {1UL,1UL,1UL,1UL};
                uint8_t *l_4317 = &g_750[1];
                int16_t l_4318 = 1L;
                uint32_t *l_4325 = &g_1361;
                union U1 *l_4414 = &g_4415;
                int32_t l_4423[2][6][6] = {{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}},{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}}};
                int i, j, k;
                (*l_4001) = ((l_4294 != (((void*)0 == &g_3686[2]) & (((l_4295[0] = 0xCD1E989591799A64LL) < ((safe_sub_func_int8_t_s_s((((safe_div_func_uint8_t_u_u((((-1L) == (safe_sub_func_uint16_t_u_u(p_37, ((l_4304 = l_4304) == (void*)0)))) && (safe_unary_minus_func_uint64_t_u(p_38))), 0x47L)) & p_37) ^ 0UL), 0L)) ^ 0L)) , (*l_4292)))) == 0xEAD855A3L);
                if (((((safe_add_func_int64_t_s_s(0xE83A5A78E38FB75DLL, ((l_3505 != ((0xF3AEL & (safe_mul_func_int64_t_s_s((*l_4001), 0x4517AAA13B8EEA7DLL))) , l_4311)) && (~(safe_mul_func_uint64_t_u_u(p_38, (l_4318 &= (((*l_4317) ^= (((safe_add_func_uint8_t_u_u(p_40, (l_4295[3] , (*l_4001)))) != 0x29B5L) < p_38)) > 0xEFL)))))))) , (*l_3594)) != (void*)0) | l_4295[1]))
                { /* block id: 1875 */
                    uint8_t *l_4322 = (void*)0;
                    uint8_t *l_4323 = &l_4102[3][0][4];
                    int32_t *l_4329 = &g_3586[8][0].f8;
                    (*l_3802) = func_58(l_4319, (p_39 >= ((((*l_4001) ^= (p_37 &= (((0xBAL ^ ((*l_4323) = (safe_div_func_uint8_t_u_u(p_39, ((*l_4317) = (*l_4292)))))) < l_4324) > ((&l_3783 == l_4325) && (((**g_2312) = (**g_2312)) != (void*)0))))) || (*l_4292)) , (-2L))), (*l_4329), (*l_4329), p_39);
                }
                else
                { /* block id: 1882 */
                    uint8_t l_4330[1][4] = {{0x72L,0x72L,0x72L,0x72L}};
                    struct S0 ***l_4333 = &l_4096;
                    int i, j;
                    for (g_41 = 0; (g_41 <= 1); g_41 += 1)
                    { /* block id: 1885 */
                        struct S0 ****l_4334[4] = {&l_4333,&l_4333,&l_4333,&l_4333};
                        int i;
                        l_4330[0][2]--;
                        (*g_3423) ^= (-1L);
                        p_37 |= (*g_1122);
                        l_4333 = l_4333;
                    }
                }
                if (((((&l_4295[0] != &p_40) , l_4335) >= (safe_mul_func_uint32_t_u_u(p_37, p_37))) ^ (safe_sub_func_uint8_t_u_u((((l_4346[1] = ((safe_sub_func_int16_t_s_s(p_38, (safe_lshift_func_int64_t_s_u(((p_40 , (safe_sub_func_uint32_t_u_u(p_39, 0xD701C982L))) & p_37), (*g_914))))) < p_40)) ^ 5UL) ^ p_38), (*l_4292)))))
                { /* block id: 1893 */
                    const uint16_t l_4349[5] = {1UL,1UL,1UL,1UL,1UL};
                    struct S0 **l_4374[4] = {&l_3585,&l_3585,&l_3585,&l_3585};
                    uint64_t l_4375[10] = {0xEBC635D5844272BDLL,0x166D9184B34FE085LL,0xEBC635D5844272BDLL,0xEBC635D5844272BDLL,0x166D9184B34FE085LL,0xEBC635D5844272BDLL,0xEBC635D5844272BDLL,0x166D9184B34FE085LL,0xEBC635D5844272BDLL,0xEBC635D5844272BDLL};
                    int64_t l_4387[3];
                    union U1 * const l_4408 = &g_4409;
                    int32_t l_4422 = (-1L);
                    int i;
                    for (i = 0; i < 3; i++)
                        l_4387[i] = 0x714F98CAFA32FD2DLL;
                    for (g_110 = 0; (g_110 < 57); g_110 = safe_add_func_uint64_t_u_u(g_110, 6))
                    { /* block id: 1896 */
                        volatile union U2 **l_4350 = &g_997;
                        if (l_4349[3])
                            break;
                        (*g_1341) = (*l_4292);
                        (*l_4350) = g_997;
                        (*g_1122) ^= ((safe_add_func_int32_t_s_s(((safe_mul_func_int32_t_s_s((safe_mul_func_int32_t_s_s(p_37, l_4349[3])), ((safe_unary_minus_func_uint16_t_u((safe_mul_func_uint32_t_u_u((((!((safe_sub_func_uint64_t_u_u((3UL != (*l_4292)), ((safe_unary_minus_func_uint16_t_u(((**g_1236)++))) | (safe_lshift_func_uint8_t_u_s((safe_mul_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(((*l_4317)++), (((void*)0 == l_4374[0]) >= ((void*)0 != &g_3439)))), (p_39 >= 6L))), 7))))) , 8L)) , 246UL) && p_38), l_4295[2])))) , p_39))) > l_4295[0]), l_4375[2])) & (*g_4121));
                    }
                    if (((*l_4001) &= (safe_div_func_int64_t_s_s((safe_sub_func_int16_t_s_s((p_40 <= p_37), ((((safe_mul_func_int8_t_s_s(l_4382, 0x60L)) != ((**g_1236) &= (&l_4325 != ((l_4318 >= l_4295[0]) , &l_4325)))) >= (safe_sub_func_uint8_t_u_u(p_40, 1L))) , p_37))), p_39))))
                    { /* block id: 1906 */
                        int16_t *l_4388 = &g_3620.f3;
                        int32_t l_4389[5][1];
                        int i, j;
                        for (i = 0; i < 5; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_4389[i][j] = (-1L);
                        }
                        p_37 &= (((safe_rshift_func_int16_t_s_s((l_4389[1][0] &= ((*l_4388) ^= l_4387[1])), 14)) , 0x4D3EL) || l_4389[2][0]);
                        (*l_4001) |= (safe_div_func_uint64_t_u_u(0x8CD5467356A0B349LL, l_4295[0]));
                    }
                    else
                    { /* block id: 1911 */
                        uint8_t l_4400 = 0UL;
                        const uint8_t **l_4403 = (void*)0;
                        const uint8_t ***l_4404 = &l_4403;
                        const uint8_t ***l_4405 = (void*)0;
                        int16_t **l_4421 = &g_1721[1];
                        p_37 = ((*l_4292) = (safe_mod_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((*g_4121), (l_4422 &= ((((l_4400 == (((g_4406[2][7] = ((*l_4404) = l_4403)) == &g_4407) & (l_4408 == ((safe_div_func_int32_t_s_s((safe_rshift_func_int32_t_s_u((*g_3423), 3)), p_37)) , l_4414)))) == (((!((*g_914) = (safe_lshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s((((*g_1341) && p_40) , (*g_771)), (*l_4292))), (****g_3297))))) , l_4421) == (void*)0)) , (*g_1122)) ^ p_37)))), 0x9DDA4ADCL)), 0xADF561F6604C38DBLL)), l_4295[0])));
                    }
                }
                else
                { /* block id: 1919 */
                    uint64_t l_4427[5][1][5] = {{{0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL}},{{0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL}},{{0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL}},{{0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL,0x7B1BDA2DD44351D5LL}},{{0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL,0x92E414E4A47BFE1ALL}}};
                    int i, j, k;
                    l_4424--;
                    --l_4427[1][0][1];
                }
            }
            else
            { /* block id: 1923 */
                uint64_t l_4448 = 0x5050E7A76403EC6BLL;
                int32_t l_4461 = 0x246F7672L;
                int32_t l_4464[2];
                uint64_t **** const l_4466 = &g_3326[0][3];
                int32_t l_4467 = 0x54EC59EAL;
                union U2 * const l_4524[4] = {&g_4525,&g_4525,&g_4525,&g_4525};
                int i;
                for (i = 0; i < 2; i++)
                    l_4464[i] = 0x9E91ECAEL;
                for (g_723.f2 = 22; (g_723.f2 > (-28)); g_723.f2 = safe_sub_func_uint64_t_u_u(g_723.f2, 2))
                { /* block id: 1926 */
                    int64_t l_4432 = 0x80AA4B6D8D46D8DALL;
                    int32_t l_4435[10][5] = {{0xDA1A75C2L,0x37B75AE7L,0xC484D54FL,0xDA1A75C2L,(-4L)},{0xFB0F81A6L,0xC484D54FL,0xC484D54FL,0xFB0F81A6L,(-2L)},{0xFB0F81A6L,0x37B75AE7L,0x6F6A0F30L,0xFB0F81A6L,(-4L)},{0xDA1A75C2L,0x37B75AE7L,0xC484D54FL,0xDA1A75C2L,(-4L)},{0xFB0F81A6L,0xC484D54FL,0xC484D54FL,0xFB0F81A6L,(-2L)},{0xFB0F81A6L,0x37B75AE7L,0x6F6A0F30L,0xFB0F81A6L,(-4L)},{0xDA1A75C2L,0x37B75AE7L,0xC484D54FL,0xDA1A75C2L,(-4L)},{0xB872472FL,(-1L),(-1L),0xB872472FL,0x697289F1L},{0xB872472FL,0xDA1A75C2L,0xFB0F81A6L,0xB872472FL,1L},{0x66C5D899L,0xDA1A75C2L,(-1L),0x66C5D899L,1L}};
                    uint8_t *l_4436 = &l_4382;
                    uint32_t *l_4443[10] = {(void*)0,&g_2936[1][0][0],&g_2936[1][0][0],(void*)0,&g_2936[1][0][0],&g_2936[1][0][0],(void*)0,&g_2936[1][0][0],&g_2936[1][0][0],(void*)0};
                    int i, j;
                    l_3777[7] = func_58(l_4432, ((((safe_lshift_func_uint32_t_u_u((((*l_4436)++) | (-2L)), ((*l_4001) &= 0xC43CAE23L))) && 0xDBL) , (safe_mul_func_int16_t_s_s((safe_add_func_uint64_t_u_u((((*g_4121) , l_4443[3]) == ((****g_2637) = (void*)0)), l_4432)), ((!(safe_sub_func_uint8_t_u_u(p_38, p_37))) & 0UL)))) , 4294967295UL), g_4447, p_37, (*g_914));
                }
                (*l_4001) = l_4448;
                if ((2UL == 0UL))
                { /* block id: 1933 */
                    uint16_t **l_4455 = &g_1237;
                    int32_t l_4462 = 1L;
                    uint8_t *l_4463[10] = {&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4],&l_4102[3][0][4]};
                    uint64_t l_4465 = 0x6A6819D97827EA9CLL;
                    int32_t *l_4468[5][5] = {{&g_3620.f8,&g_3480.f8,&g_3480.f8,&g_3620.f8,&g_2851.f8},{&l_4467,&l_4467,&l_4467,&l_4467,&g_3620.f8},{&g_3620.f8,&g_3480.f8,&g_3480.f8,&g_3620.f8,&g_2851.f8},{&l_4467,&l_4467,&l_4467,&l_4467,&g_3620.f8},{&g_3620.f8,&g_3480.f8,&g_3480.f8,&g_3620.f8,&g_2851.f8}};
                    int i, j;
                    (*l_3802) = &p_37;
                    for (g_1895.f2 = 0; (g_1895.f2 == 7); g_1895.f2 = safe_add_func_int16_t_s_s(g_1895.f2, 7))
                    { /* block id: 1945 */
                        uint32_t *l_4483 = &l_3772;
                        int32_t l_4497 = 0x50F5FFFDL;
                        int32_t ***l_4499 = &g_1915;
                        int32_t ****l_4500[9];
                        int i;
                        for (i = 0; i < 9; i++)
                            l_4500[i] = &g_1914[2][0];
                        (*g_3423) ^= (+((*l_4001) = 0xEB9145ECL));
                        l_4501 = ((safe_mod_func_int8_t_s_s((safe_div_func_int16_t_s_s(p_37, p_38)), (safe_sub_func_int8_t_s_s((p_39 , ((safe_mod_func_uint64_t_u_u((safe_unary_minus_func_uint32_t_u((((0xB3CAL && (l_4498 = (safe_div_func_uint16_t_u_u(((--(*l_4483)) >= ((~(p_38 > ((l_4467 , (safe_add_func_int8_t_s_s((safe_rshift_func_int16_t_s_u(l_4448, 6)), (safe_rshift_func_uint8_t_u_s(((safe_div_func_uint64_t_u_u(p_38, ((safe_div_func_uint32_t_u_u(p_39, l_4497)) , (*l_4292)))) || l_4497), p_37))))) ^ l_4497))) , p_40)), 65535UL)))) < 65528UL) | p_38))), 0x55EFA8D4CD45573ALL)) , (*g_771))), 0x82L)))) , l_4499);
                    }
                    return (*l_4001);
                }
                else
                { /* block id: 1953 */
                    const int32_t l_4526 = 1L;
                    uint64_t * const l_4533 = (void*)0;
                    for (l_4382 = (-19); (l_4382 < 25); l_4382 = safe_add_func_uint64_t_u_u(l_4382, 9))
                    { /* block id: 1956 */
                        uint8_t ***l_4507 = (void*)0;
                        uint8_t ****l_4506[5][10][5] = {{{&l_4507,&l_4507,&l_4507,&l_4507,(void*)0},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,(void*)0,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{(void*)0,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,(void*)0,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507}},{{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,(void*)0},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,(void*)0,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507}},{{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,(void*)0,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507}},{{(void*)0,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,(void*)0,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{(void*)0,(void*)0,&l_4507,&l_4507,&l_4507}},{{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,(void*)0,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,&l_4507,&l_4507,&l_4507},{&l_4507,&l_4507,(void*)0,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507},{(void*)0,&l_4507,(void*)0,&l_4507,&l_4507},{&l_4507,(void*)0,&l_4507,&l_4507,&l_4507}}};
                        union U2 *l_4521 = &g_4522;
                        union U2 **l_4523 = &g_457;
                        int32_t l_4530 = 0x482281F5L;
                        int i, j, k;
                        p_37 = (safe_lshift_func_uint8_t_u_u(((l_4508 = &g_1767) == ((~((safe_add_func_int64_t_s_s((safe_mul_func_int32_t_s_s((safe_sub_func_uint8_t_u_u(((((p_38 , ((((safe_lshift_func_int16_t_s_u((safe_unary_minus_func_uint16_t_u(((((((*l_4523) = l_4521) == l_4524[3]) && ((p_39 = (p_37 > ((((*g_4407) ^ (p_39 != l_4526)) , ((safe_rshift_func_uint8_t_u_u((l_4467 = ((l_4464[0] , (void*)0) == &g_2117[2])), 0)) , &p_40)) != &p_40))) != p_38)) >= p_38) ^ 0L))), p_38)) || p_40) & p_37) != 0xCAL)) , (*l_4292)) , l_4464[1]) && p_37), p_37)), l_4526)), p_40)) <= l_4529)) , (void*)0)), l_4530));
                        return (*l_4001);
                    }
                    (*g_3423) = (safe_lshift_func_uint16_t_u_u((l_4533 != (void*)0), 1));
                }
            }
        }
    }
    return p_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_1042.f0 g_54 g_914 g_573 g_89 g_98 g_849 g_2312 g_2313 g_2314 g_2118 g_90 g_768 g_929 g_248 g_249 g_176 g_1341 g_51 g_1236 g_1237 g_244 g_927 g_928 g_771 g_41 g_2053 g_2054 g_1122 g_1342 g_2936 g_2637 g_2638 g_1054 g_1055 g_1037 g_350 g_607.f0 g_3163 g_1111.f3 g_973.f3 g_3175 g_997 g_749
 * writes: g_54 g_1042.f0 g_90 g_98 g_2119 g_2220.f0 g_901 g_849 g_51 g_987.f0 g_1342 g_2606 g_573 g_176 g_244 g_2054 g_981.f0 g_2996 g_1465 g_977.f2 g_2220.f3 g_589.f3 g_607.f0 g_248 g_3163 g_1111.f3 g_2220.f2 g_973.f3 g_997 g_976.f2 g_982.f3 g_607.f3 g_749
 */
static uint16_t  func_49(int8_t  p_50)
{ /* block id: 3 */
    const int64_t l_57 = 0x53B72B46FAC5ADF6LL;
    const int32_t *l_68 = &g_54;
    int32_t *l_82 = &g_54;
    int64_t ** const l_1508[5][9][5] = {{{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,&g_249,&g_249},{&g_249,(void*)0,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,(void*)0},{(void*)0,&g_249,&g_249,&g_249,&g_249}},{{&g_249,&g_249,&g_249,(void*)0,&g_249},{&g_249,(void*)0,&g_249,&g_249,(void*)0},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{(void*)0,&g_249,(void*)0,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,(void*)0}},{{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,(void*)0},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,&g_249,&g_249}},{{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,(void*)0},{(void*)0,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,(void*)0,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,(void*)0,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249}},{{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{(void*)0,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,&g_249,&g_249,&g_249},{&g_249,&g_249,(void*)0,&g_249,&g_249}}};
    int16_t l_1519[7][9] = {{0xED7DL,1L,0xB5A9L,0x648FL,0xED05L,0xED05L,0x648FL,0xB5A9L,1L},{0L,0x587CL,0xA6CDL,0L,5L,0x0CE3L,0x0CE3L,5L,0L},{(-4L),(-9L),(-4L),0x6B71L,0x648FL,0xED7DL,(-5L),(-5L),0xED7DL},{0xA6CDL,0x587CL,0L,0x587CL,0xA6CDL,0L,5L,0x0CE3L,0x0CE3L},{0xB5A9L,3L,(-5L),0xB5A9L,(-5L),3L,(-9L),0xED05L,0xED7DL},{0L,0xA6CDL,8L,0xF60CL,1L,0xF60CL,8L,0xA6CDL,0L},{3L,1L,(-4L),0xED05L,0x6B71L,(-5L),0x6B71L,0xED05L,(-4L)}};
    uint16_t **l_1538[3];
    uint32_t **l_1574 = &g_351;
    uint32_t ***l_1573 = &l_1574;
    int32_t l_1607 = (-4L);
    int32_t l_1609 = 0x307A4ABCL;
    union U2 *l_1638 = &g_1639;
    int16_t *l_1719 = &l_1519[3][8];
    int16_t **l_1718 = &l_1719;
    uint32_t **l_1835 = &g_351;
    uint8_t l_1845 = 0x6BL;
    int32_t ***l_1918 = (void*)0;
    int32_t l_1952 = 0xECDC6423L;
    int32_t l_1954[5][9][2] = {{{(-6L),0L},{0L,(-6L)},{0x4BEEEDEBL,0x4BEEEDEBL},{0xB5E98B3AL,0xAF3882B3L},{0L,0x27A9C02CL},{0xAF3882B3L,0L},{0x2A2C91D1L,0xAF3882B3L},{0x4BEEEDEBL,0xB5E98B3AL},{0x4BEEEDEBL,0xAF3882B3L}},{{0x2A2C91D1L,0L},{0xAF3882B3L,0x27A9C02CL},{0L,0xAF3882B3L},{0xB5E98B3AL,0x4BEEEDEBL},{0x4BEEEDEBL,(-6L)},{0L,0L},{(-6L),0L},{0L,(-6L)},{0x4BEEEDEBL,0x4BEEEDEBL}},{{0xB5E98B3AL,0xAF3882B3L},{0L,0x27A9C02CL},{0xAF3882B3L,0L},{0x2A2C91D1L,0xAF3882B3L},{0x4BEEEDEBL,0xB5E98B3AL},{0x4BEEEDEBL,0xAF3882B3L},{0x2A2C91D1L,0L},{0xAF3882B3L,0x27A9C02CL},{0L,0xAF3882B3L}},{{0xB5E98B3AL,0x4BEEEDEBL},{0x4BEEEDEBL,(-6L)},{0L,0L},{(-6L),0L},{0L,(-6L)},{0x4BEEEDEBL,0x4BEEEDEBL},{0xB5E98B3AL,0xAF3882B3L},{0L,0x27A9C02CL},{0xAF3882B3L,0L}},{{0x2A2C91D1L,0xAF3882B3L},{0x4BEEEDEBL,0xB5E98B3AL},{0x4BEEEDEBL,0xAF3882B3L},{0x2A2C91D1L,0L},{0xAF3882B3L,0x27A9C02CL},{0L,0xAF3882B3L},{0xB5E98B3AL,0x4BEEEDEBL},{0x4BEEEDEBL,(-6L)},{0L,0L}}};
    uint64_t l_1963[9];
    uint16_t l_1990 = 65535UL;
    union U1 *l_2032 = &g_2033;
    int32_t l_2063 = 0xE9F6F781L;
    uint32_t ***l_2083[5];
    uint32_t l_2084[2];
    int32_t l_2113 = 0xC0CB2ECCL;
    int64_t l_2114 = 0xE478D55CD1668241LL;
    uint32_t *l_2162 = (void*)0;
    uint32_t ** const l_2161 = &l_2162;
    uint32_t ** const *l_2160 = &l_2161;
    uint8_t **l_2168[3];
    uint64_t l_2189[8];
    int32_t l_2234 = 1L;
    int32_t l_2277 = 8L;
    int8_t **l_2332 = (void*)0;
    int8_t *** const l_2331 = &l_2332;
    int8_t ***l_2333[4][1];
    uint16_t l_2395 = 65527UL;
    int64_t ****l_2427 = &g_929;
    uint64_t l_2443 = 0xFD083AED21B86E86LL;
    uint32_t l_2492 = 0x9DA6AA3DL;
    int16_t ****l_2531 = (void*)0;
    int64_t l_2570 = 0x84E49481A19C31AALL;
    int64_t l_2605 = 8L;
    const uint64_t *l_2663 = &g_849[4][1];
    const uint64_t **l_2662 = &l_2663;
    const uint64_t ***l_2661 = &l_2662;
    const uint64_t ****l_2660 = &l_2661;
    const uint16_t ***l_2807 = (void*)0;
    const uint16_t ****l_2806[2];
    uint16_t l_2845 = 65535UL;
    int8_t l_2847 = 0x23L;
    uint16_t l_2848 = 0UL;
    struct S0 *l_2850 = &g_2851;
    uint32_t l_2868 = 0xDD52F3ADL;
    int32_t **l_2889 = (void*)0;
    uint64_t l_3023[7] = {0xDCAF75FC4D86B7A9LL,0UL,0xDCAF75FC4D86B7A9LL,0xDCAF75FC4D86B7A9LL,0UL,0xDCAF75FC4D86B7A9LL,0xDCAF75FC4D86B7A9LL};
    uint16_t l_3074 = 0x9660L;
    uint8_t l_3105 = 0x3FL;
    uint16_t l_3106 = 0xE2D9L;
    uint64_t l_3107 = 18446744073709551610UL;
    int8_t l_3108 = 0x2FL;
    int64_t l_3109 = 0x250CE45F1D73BE04LL;
    uint32_t l_3121 = 18446744073709551615UL;
    uint32_t l_3141 = 0x5B17A831L;
    int64_t l_3255 = 0x4DEBD464A066D890LL;
    uint8_t l_3259 = 0xE1L;
    const struct S0 ***l_3262 = &g_2118;
    const int32_t l_3318 = 6L;
    uint16_t l_3376 = 65535UL;
    union U2 **l_3459 = &g_457;
    union U2 ***l_3458 = &l_3459;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1538[i] = &g_1237;
    for (i = 0; i < 9; i++)
        l_1963[i] = 0x10A387090DEAF0ADLL;
    for (i = 0; i < 5; i++)
        l_2083[i] = &l_1835;
    for (i = 0; i < 2; i++)
        l_2084[i] = 0UL;
    for (i = 0; i < 3; i++)
        l_2168[i] = &g_1768[6][2][1];
    for (i = 0; i < 8; i++)
        l_2189[i] = 18446744073709551606UL;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
            l_2333[i][j] = &l_2332;
    }
    for (i = 0; i < 2; i++)
        l_2806[i] = &l_2807;
    for (p_50 = 0; (p_50 == (-13)); --p_50)
    { /* block id: 6 */
        uint32_t l_1091 = 4294967289UL;
        int32_t * const **l_1378 = &g_1340[0][1];
        int32_t *l_1466[7][3] = {{&g_954.f3,&g_954.f3,&g_954.f3},{&g_81,&g_81,&g_81},{&g_954.f3,&g_954.f3,&g_954.f3},{&g_81,&g_81,&g_81},{&g_954.f3,&g_954.f3,&g_954.f3},{&g_81,&g_81,&g_81},{&g_954.f3,&g_954.f3,&g_954.f3}};
        int64_t **l_1509 = &g_249;
        uint16_t **l_1536[4] = {&g_1237,&g_1237,&g_1237,&g_1237};
        uint16_t l_1564 = 0xF96BL;
        uint64_t **l_1569 = &g_914;
        uint8_t *l_1651 = (void*)0;
        uint8_t * const *l_1650[1][2][10] = {{{&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651},{&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651,&l_1651}}};
        uint32_t l_1668 = 0xDB7BCB37L;
        union U2 **l_1678 = &l_1638;
        uint32_t l_1686 = 0xBA870A91L;
        uint16_t l_1688[10][8][2] = {{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL},{1UL,1UL}}};
        int16_t l_1697 = 0xDCDBL;
        uint16_t l_1740 = 4UL;
        int32_t l_1772 = 0xC54203B0L;
        uint32_t **l_1834 = &g_351;
        int16_t * const *l_1874 = &l_1719;
        int32_t ***l_2013 = (void*)0;
        const uint32_t l_2019 = 0x95C2C9A3L;
        uint8_t l_2037 = 0x14L;
        uint64_t l_2073 = 0x6E8668D18D6DDA19LL;
        uint32_t l_2098 = 0x905B0D5EL;
        int16_t l_2152[8] = {1L,0x06F7L,1L,0x06F7L,1L,0x06F7L,1L,0x06F7L};
        uint32_t *l_2159 = &g_981.f0;
        uint32_t **l_2158 = &l_2159;
        uint32_t ***l_2157 = &l_2158;
        uint32_t *l_2165 = &g_971[3].f0;
        uint32_t ** const l_2164 = &l_2165;
        uint32_t ** const *l_2163 = &l_2164;
        int32_t l_2227 = 0xD457AD44L;
        uint64_t l_2235[6][6] = {{0UL,0UL,0x95C83397C2A3E7A2LL,18446744073709551615UL,0x03A59415DD34AA20LL,0x58B8A2211F80043FLL},{0x95C83397C2A3E7A2LL,18446744073709551613UL,1UL,0xA8EDB7143257D5B6LL,0x03A59415DD34AA20LL,0xA8EDB7143257D5B6LL},{0x864A19BBC606D5E2LL,0UL,0x864A19BBC606D5E2LL,0xCEA875564B44DAB5LL,18446744073709551615UL,18446744073709551613UL},{0x70E9AE4D23604B10LL,0xBA7D436177FE5EB1LL,9UL,0x58B8A2211F80043FLL,0UL,18446744073709551615UL},{18446744073709551615UL,0xA8EDB7143257D5B6LL,0xCEA875564B44DAB5LL,0x58B8A2211F80043FLL,0x58B8A2211F80043FLL,0xCEA875564B44DAB5LL},{0x70E9AE4D23604B10LL,0x70E9AE4D23604B10LL,0UL,0xCEA875564B44DAB5LL,9UL,0x864A19BBC606D5E2LL}};
        int32_t **l_2317[4][1][8] = {{{(void*)0,&g_1465[4][0],(void*)0,&g_1465[4][0],(void*)0,(void*)0,&g_1465[1][6],&g_1465[1][6]}},{{&g_1122,&g_1122,(void*)0,(void*)0,&g_1122,&l_1466[1][0],(void*)0,&g_1122}},{{&g_1122,(void*)0,(void*)0,&g_1122,(void*)0,(void*)0,&g_1122,&l_1466[1][0]}},{{&g_1122,(void*)0,&g_1465[1][6],&g_1122,&g_1122,&g_1465[1][6],(void*)0,&g_1122}}};
        uint64_t l_2517[1][3];
        uint8_t l_2539 = 0x50L;
        uint64_t l_2557[8][7] = {{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL},{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL},{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL},{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL},{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL},{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL},{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL},{0xBABF78FD94E12587LL,0xBABF78FD94E12587LL,18446744073709551606UL,0x556C38A9EEA6B039LL,1UL,0x556C38A9EEA6B039LL,18446744073709551606UL}};
        int64_t l_2566 = (-4L);
        int32_t *l_2590[2];
        int8_t l_2604 = 0L;
        int16_t l_2607[3][1];
        int32_t l_2621 = 0x2AF59A86L;
        int16_t *****l_2622 = &l_2531;
        uint16_t l_2645 = 0x0273L;
        int8_t **l_2658 = &g_768;
        const int8_t l_2684 = 0xCFL;
        uint32_t l_2688[2];
        uint16_t l_2739[10] = {5UL,4UL,4UL,5UL,4UL,4UL,5UL,4UL,4UL,5UL};
        const uint16_t *** volatile *l_2751 = (void*)0;
        int32_t **l_2814 = &g_2687;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
                l_2517[i][j] = 18446744073709551613UL;
        }
        for (i = 0; i < 2; i++)
            l_2590[i] = &g_2305;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_2607[i][j] = (-1L);
        }
        for (i = 0; i < 2; i++)
            l_2688[i] = 18446744073709551615UL;
        for (g_54 = (-13); (g_54 < 9); ++g_54)
        { /* block id: 9 */
            uint32_t l_77 = 7UL;
            uint8_t l_425 = 252UL;
            union U1 **l_1387 = (void*)0;
            union U1 ** const *l_1386 = &l_1387;
            const int16_t l_1396 = 0x5294L;
            int32_t l_1415[4];
            int64_t ***l_1530 = (void*)0;
            int8_t l_1531 = 0xE6L;
            int32_t l_1687 = 0x85108560L;
            int16_t l_1732 = 1L;
            int16_t **l_1873 = &g_1721[2];
            uint32_t l_1957 = 18446744073709551612UL;
            uint32_t ****l_1996 = (void*)0;
            int32_t ***l_2015 = &g_1915;
            struct S0 *l_2016[4][10];
            const struct S0 ***l_2116 = (void*)0;
            uint32_t l_2149 = 0x302C390BL;
            int i, j;
            for (i = 0; i < 4; i++)
                l_1415[i] = 0L;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 10; j++)
                    l_2016[i][j] = &g_2017;
            }
        }
    }
    for (g_1042.f0 = 0; (g_1042.f0 <= 9); ++g_1042.f0)
    { /* block id: 1171 */
        int32_t l_2830[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
        uint32_t ****l_2835 = &l_2083[4];
        int32_t l_2836 = 0x04EE4FC4L;
        uint64_t *** const *l_2846 = (void*)0;
        int16_t l_2859 = (-9L);
        uint8_t l_2874 = 0xE2L;
        union U1 * const *l_2908[9][8][3] = {{{&l_2032,&g_667,(void*)0},{&g_667,&g_667,(void*)0},{&g_667,&g_667,&g_667},{&g_667,&g_667,&l_2032},{(void*)0,&g_667,&g_667},{&g_667,&g_667,&g_667},{&g_667,(void*)0,(void*)0},{&l_2032,&l_2032,&l_2032}},{{&g_667,&l_2032,&g_667},{&g_667,&g_667,&l_2032},{&g_667,&g_667,&g_667},{(void*)0,&g_667,&l_2032},{&g_667,&g_667,&g_667},{&l_2032,&l_2032,&l_2032},{(void*)0,&g_667,(void*)0},{&g_667,&g_667,&g_667}},{{&g_667,&g_667,&g_667},{(void*)0,&g_667,&l_2032},{&l_2032,(void*)0,&g_667},{&g_667,&l_2032,(void*)0},{&g_667,(void*)0,(void*)0},{&l_2032,&l_2032,(void*)0},{(void*)0,&g_667,&l_2032},{&g_667,&l_2032,&g_667}},{{&g_667,&g_667,&g_667},{(void*)0,&l_2032,&l_2032},{&l_2032,&g_667,&g_667},{&g_667,&g_667,&l_2032},{(void*)0,(void*)0,&g_667},{&g_667,&g_667,&l_2032},{&g_667,&g_667,&g_667},{&g_667,&l_2032,&l_2032}},{{&l_2032,&l_2032,&g_667},{&l_2032,&g_667,&g_667},{(void*)0,&l_2032,&g_667},{&g_667,&l_2032,&l_2032},{&g_667,&g_667,&g_667},{&g_667,&l_2032,&g_667},{&g_667,(void*)0,&l_2032},{&g_667,&l_2032,&g_667}},{{&l_2032,(void*)0,&g_667},{&g_667,&g_667,&g_667},{&l_2032,(void*)0,&l_2032},{(void*)0,(void*)0,&g_667},{(void*)0,&g_667,&g_667},{(void*)0,&g_667,(void*)0},{&g_667,&g_667,&g_667},{(void*)0,&l_2032,&g_667}},{{(void*)0,&g_667,(void*)0},{(void*)0,&l_2032,&l_2032},{&l_2032,&g_667,(void*)0},{&g_667,&g_667,&l_2032},{&l_2032,&g_667,(void*)0},{&g_667,(void*)0,(void*)0},{&g_667,(void*)0,&g_667},{&g_667,(void*)0,&l_2032}},{{&g_667,(void*)0,&l_2032},{&g_667,&g_667,&l_2032},{(void*)0,&g_667,&l_2032},{&l_2032,&g_667,&g_667},{&l_2032,&l_2032,&g_667},{&g_667,&g_667,&l_2032},{&g_667,&l_2032,&g_667},{&l_2032,&g_667,&l_2032}},{{&g_667,&g_667,&g_667},{&g_667,&g_667,&l_2032},{&l_2032,(void*)0,&g_667},{&g_667,(void*)0,&g_667},{(void*)0,&g_667,&l_2032},{&l_2032,(void*)0,&l_2032},{(void*)0,&l_2032,&l_2032},{&g_667,(void*)0,&l_2032}}};
        int32_t l_2909 = (-1L);
        int32_t l_2910 = 0x4B3C425EL;
        int8_t l_2911 = 0xBBL;
        const uint32_t l_2988 = 0x1FAE925EL;
        const int8_t l_3026 = (-1L);
        int i, j, k;
        (*l_82) = 0L;
        (*g_89) = (safe_lshift_func_int16_t_s_s((safe_add_func_uint16_t_u_u((&g_2750 == &g_1236), 0UL)), (safe_add_func_int64_t_s_s((safe_div_func_uint8_t_u_u((l_2830[3] = (safe_lshift_func_int32_t_s_s((l_2063 = ((*l_82) &= l_2830[1])), (safe_lshift_func_int32_t_s_u(l_2830[1], 15))))), (safe_add_func_int8_t_s_s((p_50 , ((void*)0 != l_2835)), (l_2836 &= (p_50 | (*g_914))))))), (*g_914)))));
        for (g_98 = 4; (g_98 >= 0); g_98 -= 1)
        { /* block id: 1180 */
            int32_t l_2856 = 0x6C858E9CL;
            int32_t l_2860 = 0xE5BE8FA4L;
            int32_t l_2862 = 0x06ADBAD5L;
            int8_t *l_2871 = &g_2606;
            int32_t l_2879[5];
            union U1 **l_2974 = (void*)0;
            int64_t l_2987 = 0xEE5613D47C27996DLL;
            int i, j;
            for (i = 0; i < 5; i++)
                l_2879[i] = 0L;
            if (g_849[(g_98 + 2)][g_98])
            { /* block id: 1181 */
                uint32_t l_2849 = 0x60CF277DL;
                int i, j;
                l_2849 |= ((safe_div_func_uint32_t_u_u((safe_div_func_int64_t_s_s((safe_lshift_func_uint16_t_u_s(((0x70L != ((**l_2160) == (**g_2312))) ^ ((-1L) <= (safe_rshift_func_int32_t_s_u((0x208EL < (((g_849[(g_98 + 1)][g_98] , (void*)0) != ((l_2845 ^ ((((((-2L) ^ p_50) , p_50) >= l_2830[0]) >= p_50) ^ 0x6407CDB8D2A2A7FFLL)) , l_2846)) < 18446744073709551611UL)), l_2830[3])))), l_2847)), g_849[(g_98 + 2)][g_98])), l_2848)) && 4L);
                (*g_2118) = l_2850;
                for (g_2220.f0 = 0; (g_2220.f0 <= 4); g_2220.f0 += 1)
                { /* block id: 1186 */
                    if (p_50)
                        break;
                    if ((*g_89))
                        break;
                }
            }
            else
            { /* block id: 1190 */
                return p_50;
            }
            for (g_901 = 1; (g_901 <= 4); g_901 += 1)
            { /* block id: 1195 */
                int32_t l_2861 = (-6L);
                int32_t l_2863 = 0xD46CE1A6L;
                int32_t l_2864 = (-7L);
                int32_t l_2865 = 0xF64BDDC8L;
                int32_t l_2866 = 0x57A65639L;
                int32_t l_2867 = 0L;
                int32_t ** const l_2875[3][9][5] = {{{&g_1122,&g_89,&g_89,&g_1465[4][3],&g_1465[3][1]},{&l_82,&g_1465[4][0],&g_1122,&g_1465[3][1],&g_1465[6][2]},{&g_89,&g_1465[4][0],(void*)0,&g_1465[3][1],&l_82},{&g_1465[4][0],(void*)0,&g_1465[4][0],&g_1465[4][3],&l_82},{&g_1122,&g_1465[4][0],&l_82,&g_1465[2][6],(void*)0},{&g_1465[4][0],&g_1465[0][4],&g_1465[6][2],&g_1465[3][6],&g_1465[3][6]},{(void*)0,&g_89,(void*)0,&g_1465[4][0],&l_82},{&g_89,&g_1465[4][0],&g_89,&g_1465[4][2],(void*)0},{(void*)0,&g_1465[4][2],&g_1465[3][4],&l_82,&g_1465[4][0]}},{{&g_1122,&g_1465[4][0],&g_89,(void*)0,&g_89},{&g_89,&g_1465[4][0],(void*)0,&g_89,&g_1465[6][2]},{&g_1122,&g_1465[3][1],&g_1465[6][2],&g_89,&l_82},{&g_1122,(void*)0,&l_82,&g_89,&g_1465[3][6]},{&g_1465[0][4],&g_1122,(void*)0,&g_1465[4][0],&l_82},{&g_1465[4][0],&g_1465[4][0],&l_82,(void*)0,&l_82},{&l_82,&g_1465[4][0],&g_1465[0][5],&g_1465[4][0],&g_1122},{&g_1465[0][0],&g_89,&l_82,&l_82,&g_89},{(void*)0,&g_1122,&g_89,&g_1465[4][0],&g_89}},{{&l_82,&g_1465[4][0],&g_89,&g_89,&g_1465[4][0]},{&g_89,(void*)0,&g_89,&g_1465[6][2],&l_82},{&g_1465[4][0],&g_89,&g_89,&g_89,&g_1122},{&l_82,(void*)0,&g_1465[3][4],&g_89,&l_82},{&g_1465[4][0],&g_1122,&g_89,&l_82,&g_1122},{&g_89,&g_1122,&l_82,&l_82,&g_1465[4][0]},{&l_82,&g_1465[4][0],&l_82,&g_89,&g_1122},{(void*)0,&g_1465[6][2],&g_89,&g_1122,&g_1465[4][0]},{&g_1465[0][0],&g_1122,&g_1465[3][6],&g_1122,&g_1465[6][2]}}};
                int32_t **l_2876 = &g_89;
                int8_t l_2883 = (-5L);
                uint16_t l_2939 = 0x6E1FL;
                uint64_t **l_2951 = &g_914;
                uint64_t ***l_2950 = &l_2951;
                uint64_t ****l_2949[6];
                uint64_t *****l_2948 = &l_2949[5];
                uint64_t l_2958 = 0x562EE43921DC7B67LL;
                int16_t *** const l_2986 = &l_1718;
                int i, j, k;
                for (i = 0; i < 6; i++)
                    l_2949[i] = &l_2950;
                if (((((safe_sub_func_uint64_t_u_u(((l_2862 |= ((((safe_mul_func_int64_t_s_s(p_50, 0x6ABB4C0F4D1A4BC5LL)) , (l_2856 == (g_849[(g_98 + 2)][g_98] = (safe_mod_func_uint16_t_u_u((0x1C48EF22L > p_50), l_2830[1]))))) > ((((l_2868++) <= ((*g_768) = (l_2871 == (void*)0))) || (safe_div_func_int32_t_s_s(l_2874, p_50))) == (*g_89))) , p_50)) , 1UL), (***g_929))) & (*g_914)) , l_2867) || p_50))
                { /* block id: 1200 */
                    l_2876 = l_2875[2][1][2];
                    for (g_987.f0 = 0; (g_987.f0 != 42); g_987.f0 = safe_add_func_int16_t_s_s(g_987.f0, 7))
                    { /* block id: 1204 */
                        uint32_t l_2880 = 18446744073709551615UL;
                        (*g_1341) = (-2L);
                        (*l_82) = (-1L);
                        --l_2880;
                    }
                }
                else
                { /* block id: 1209 */
                    int32_t **l_2890[1][1];
                    const int32_t **l_2891 = &g_633;
                    int32_t l_2892 = 9L;
                    union U2 **l_2927[9][1] = {{(void*)0},{&l_1638},{(void*)0},{&l_1638},{(void*)0},{&l_1638},{(void*)0},{&l_1638},{(void*)0}};
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_2890[i][j] = &g_1122;
                    }
                    (**l_2876) &= (l_2883 == (safe_div_func_uint8_t_u_u(p_50, ((*g_768) , (safe_add_func_uint8_t_u_u((+(((((**g_1236) & (255UL == (l_2892 |= (p_50 < (((l_2890[0][0] = l_2889) == l_2891) > ((l_2830[1] >= (*****g_927)) > p_50)))))) == p_50) && 18446744073709551615UL) , p_50)), (*g_771)))))));
                    if ((safe_add_func_int32_t_s_s(((safe_sub_func_uint8_t_u_u((l_2836 = (l_2830[2] <= p_50)), (safe_div_func_int8_t_s_s(((*g_768) = ((l_2879[3] & (((safe_sub_func_uint64_t_u_u(((*g_914) &= ((safe_unary_minus_func_uint64_t_u((safe_rshift_func_int8_t_s_u((p_50 <= p_50), (l_2909 ^= ((((safe_mul_func_uint64_t_u_u((((safe_lshift_func_int64_t_s_s((((*l_2871) = (*g_771)) && ((**g_2313) , (*g_768))), 55)) , l_2879[3]) & l_2879[4]), p_50)) < l_2874) , l_2908[4][6][2]) != (*g_2053))))))) && l_2910)), p_50)) & (*g_771)) == p_50)) >= 0x9DL)), p_50)))) && l_2879[3]), l_2911)))
                    { /* block id: 1218 */
                        uint32_t l_2912 = 0UL;
                        --l_2912;
                    }
                    else
                    { /* block id: 1220 */
                        uint32_t **l_2915 = (void*)0;
                        int32_t l_2918 = 1L;
                        union U2 ***l_2928 = &l_2927[3][0];
                        (*g_1341) &= ((*g_1122) = (p_50 < (((l_2915 = (*g_2312)) == (void*)0) , (((p_50 < 1UL) < (safe_sub_func_int64_t_s_s(((****l_2427) = l_2918), (safe_mul_func_int16_t_s_s(((**l_1718) = l_2910), (((safe_mul_func_int8_t_s_s((**l_2876), p_50)) != l_2918) < p_50)))))) >= 0xDC91L))));
                        (**l_2876) = l_2918;
                        l_2918 = (l_2830[7] ^= ((safe_mod_func_uint64_t_u_u(((safe_sub_func_int8_t_s_s((&l_1638 != ((*l_2928) = l_2927[3][0])), ((safe_add_func_int32_t_s_s((!(0x35FE9BD21BEB54CFLL && (safe_sub_func_uint32_t_u_u(((safe_mod_func_int16_t_s_s(p_50, l_2918)) == (((*l_82) < g_2936[1][0][0]) <= 4294967288UL)), p_50)))), (*g_1341))) , 6UL))) || l_2856), (*****g_927))) != 0x0571L));
                        if (p_50)
                            continue;
                    }
                }
                for (l_2867 = 0; (l_2867 <= 1); l_2867 = safe_add_func_int8_t_s_s(l_2867, 1))
                { /* block id: 1235 */
                    uint64_t l_2942 = 0xF199D9DCA9F3EB7DLL;
                    int32_t *l_2943 = &g_973.f3;
                    l_2939--;
                    if (l_2942)
                        break;
                    l_2943 = (void*)0;
                    return (**g_1236);
                }
                if (l_2879[3])
                    continue;
                if (((safe_rshift_func_int16_t_s_s((((*g_768) >= p_50) || (((((*l_2948) = (((*l_82) = (safe_mul_func_int32_t_s_s(l_2856, 0x4DDEA2D3L))) , (void*)0)) != (void*)0) && 0xEC223EBBB7D5FF30LL) <= (safe_sub_func_uint8_t_u_u((((safe_rshift_func_uint32_t_u_s(((((*l_2871) = (0x8FL < p_50)) , 4294967295UL) ^ (-7L)), p_50)) < 1UL) && 0L), 254UL)))), p_50)) & p_50))
                { /* block id: 1245 */
                    int16_t l_2971[8] = {(-10L),0x15B3L,(-10L),(-10L),0x15B3L,(-10L),(-10L),0x15B3L};
                    int16_t *l_2973 = &l_2859;
                    int i;
                    l_2958++;
                    (*l_82) = ((p_50 , (((**g_1236)--) >= l_2836)) , ((safe_mod_func_uint8_t_u_u(((((safe_sub_func_int16_t_s_s(((*g_927) == (*g_927)), (((*g_2053) = (l_2974 = ((safe_lshift_func_int64_t_s_s(((safe_mul_func_int16_t_s_s(l_2971[3], ((*l_2973) = ((*l_1719) = (safe_unary_minus_func_int32_t_s(l_2971[3])))))) , ((void*)0 != (*g_2637))), 48)) , (void*)0))) == (void*)0))) > 1UL) , l_2879[0]) , p_50), (*g_768))) && 0x6BDFL));
                    if (l_2971[1])
                        break;
                }
                else
                { /* block id: 1254 */
                    const int8_t *l_2981 = &g_51[4][3][1];
                    int32_t l_2982[6] = {0L,0L,0L,0L,0L,0L};
                    uint32_t l_2999 = 0UL;
                    int i;
                    for (g_981.f0 = 21; (g_981.f0 <= 36); g_981.f0++)
                    { /* block id: 1257 */
                        int8_t **l_2983[9][5] = {{&g_771,&g_771,&g_771,&g_771,&g_771},{&g_768,&g_768,&g_768,&g_768,&g_768},{&g_771,&g_771,&g_771,&g_771,&g_771},{&g_768,&g_768,&g_768,&g_768,&g_768},{&g_771,&g_771,&g_771,&g_771,&g_771},{&g_768,&g_768,&g_768,&g_768,&g_768},{&g_771,&g_771,&g_771,&g_771,&g_771},{&g_768,&g_768,&g_768,&g_768,&g_768},{&g_771,&g_771,&g_771,&g_771,&g_771}};
                        int32_t l_2989 = 1L;
                        int64_t * const *l_2995 = &g_249;
                        int64_t * const **l_2994[7][7] = {{(void*)0,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,(void*)0},{&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995},{(void*)0,&l_2995,&l_2995,&l_2995,(void*)0,&l_2995,(void*)0},{&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995},{&l_2995,&l_2995,&l_2995,&l_2995,(void*)0,&l_2995,&l_2995},{&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995},{(void*)0,&l_2995,&l_2995,&l_2995,&l_2995,&l_2995,(void*)0}};
                        int64_t * const ***l_2993 = &l_2994[3][6];
                        int64_t * const ****l_2992 = &l_2993;
                        int i, j;
                        (*g_1341) |= ((safe_mod_func_uint32_t_u_u((safe_lshift_func_uint64_t_u_u(((((**l_1718) = ((((l_2981 == (l_2982[3] , &p_50)) || ((l_2983[6][4] == ((*l_2331) = ((safe_rshift_func_uint8_t_u_u((&g_1720[1][4][0] != l_2986), 1)) , l_2983[6][4]))) & (0x7CL > ((l_2987 , p_50) <= (**g_1236))))) >= p_50) ^ l_2982[3])) , 0x851AL) <= 0x0D7FL), 3)), l_2988)) == l_2989);
                        g_2996[1] = ((safe_mul_func_uint64_t_u_u(l_2879[0], (*g_914))) , l_2992);
                        if ((*g_1122))
                            continue;
                        l_2856 |= ((l_2989 >= (safe_sub_func_uint32_t_u_u(p_50, 0L))) == (*g_914));
                    }
                    return l_2999;
                }
            }
            (*l_82) = p_50;
        }
        if ((((safe_lshift_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u(p_50, 15)), 30)) , (p_50 , (0xE255L ^ (safe_div_func_int16_t_s_s((((((*l_1719) = (*l_68)) & l_2909) , ((*l_68) <= ((9UL ^ (safe_rshift_func_int32_t_s_s(((*g_89) = (p_50 || (safe_rshift_func_uint32_t_u_u(l_2859, l_2874)))), p_50))) != p_50))) & l_2874), p_50))))) <= (-1L)))
        { /* block id: 1272 */
            int64_t l_3015 = 0x7606F7CF5BCAB963LL;
            uint8_t l_3016[1];
            int32_t l_3029 = 8L;
            int32_t **l_3030 = &g_1465[2][0];
            int32_t l_3068 = 0x3BC7D2C6L;
            int32_t *l_3069 = &g_1342;
            int32_t *l_3070 = (void*)0;
            int32_t *l_3071 = &g_968.f3;
            int32_t *l_3072 = &l_1954[1][7][1];
            int32_t *l_3073[6][3] = {{&g_953.f3,&g_953.f3,&g_953.f3},{&l_3068,&l_2830[3],&l_3068},{&g_953.f3,&g_953.f3,&g_953.f3},{&l_3068,&l_2830[3],&l_3068},{&g_953.f3,&g_953.f3,&g_953.f3},{&l_3068,&l_2830[3],&l_3068}};
            int i, j;
            for (i = 0; i < 1; i++)
                l_3016[i] = 0xA5L;
            for (l_2395 = 0; (l_2395 <= 3); l_2395 = safe_add_func_uint16_t_u_u(l_2395, 6))
            { /* block id: 1275 */
                int32_t *l_3012 = &g_792.f3;
                int32_t *l_3013 = &g_984[0].f3;
                int32_t *l_3014[8][5] = {{&l_2277,&g_1342,&l_1952,&l_1952,&g_1342},{&g_1342,&g_2305,&l_2277,&g_1342,&l_1952},{&l_1954[1][7][1],&g_1342,&l_2063,&g_1342,&l_1954[1][7][1]},{&l_2277,&g_406[4].f3,&g_2305,&l_1952,&g_406[4].f3},{&l_1954[1][7][1],&g_2305,&g_2305,&l_1954[1][7][1],&l_1952},{&g_1342,&l_1954[1][7][1],&l_2063,&g_406[4].f3,&g_406[4].f3},{&l_2277,&l_1954[1][7][1],&l_2277,&l_1952,&l_1954[1][7][1]},{&g_406[4].f3,&g_2305,&l_1952,&g_406[4].f3,&l_1952}};
                int i, j;
                l_3016[0]--;
            }
            (*l_3030) = (((l_3029 |= (((*g_1122) = p_50) <= ((*g_1341) ^= ((safe_add_func_int32_t_s_s(((void*)0 == &l_2660), (((safe_add_func_int32_t_s_s(l_3023[2], (((p_50 <= (safe_mul_func_uint8_t_u_u(l_3026, (safe_rshift_func_int32_t_s_s(((-1L) > (((*g_1054) != (void*)0) != 4UL)), p_50))))) || 1L) , 0xE7C7BA8EL))) ^ p_50) || (*g_914)))) | 1L)))) & l_3015) , (void*)0);
            for (g_977.f2 = 0; (g_977.f2 == (-5)); g_977.f2 = safe_sub_func_uint8_t_u_u(g_977.f2, 5))
            { /* block id: 1284 */
                uint8_t l_3065[7] = {0x1FL,0x1FL,0x83L,0x1FL,0x1FL,0x83L,0x1FL};
                int i;
                if (p_50)
                    break;
                for (g_2220.f3 = (-12); (g_2220.f3 <= (-17)); g_2220.f3 = safe_sub_func_int8_t_s_s(g_2220.f3, 2))
                { /* block id: 1288 */
                    uint64_t l_3057 = 0x5ACBBD88447DD23DLL;
                    const uint32_t *l_3062 = &g_2584;
                    const uint32_t **l_3061[10] = {&l_3062,&l_3062,&l_3062,&l_3062,&l_3062,&l_3062,&l_3062,&l_3062,&l_3062,&l_3062};
                    int i;
                    for (g_589.f3 = (-11); (g_589.f3 != 27); ++g_589.f3)
                    { /* block id: 1291 */
                        int16_t l_3048 = 0xD08AL;
                        (*l_82) |= (safe_mod_func_uint64_t_u_u(((safe_mul_func_uint64_t_u_u((((safe_add_func_int32_t_s_s(0x84B3DACCL, (~(((safe_mul_func_uint32_t_u_u((safe_sub_func_int8_t_s_s(l_3048, (safe_add_func_uint32_t_u_u(0UL, (((safe_rshift_func_int16_t_s_u(((safe_add_func_int16_t_s_s((p_50 && (safe_div_func_uint8_t_u_u(p_50, ((0xE2L | l_3057) || ((*g_914) = ((p_50 , (safe_mul_func_uint64_t_u_u(((!(l_2836 | (***g_929))) > p_50), p_50))) || l_3048)))))), (-1L))) , 0xB1E2L), (*g_1237))) , l_3061[7]) == (*g_1037)))))), 0xC9C9FC15L)) , p_50) > p_50)))) , p_50) || 248UL), l_2836)) >= 0xE545L), p_50));
                        if ((*g_89))
                            break;
                    }
                    for (g_607.f0 = 0; (g_607.f0 > 52); g_607.f0 = safe_add_func_uint8_t_u_u(g_607.f0, 5))
                    { /* block id: 1298 */
                        l_3065[5]++;
                    }
                }
            }
            l_3074++;
        }
        else
        { /* block id: 1304 */
            int32_t *l_3077 = (void*)0;
            int32_t *l_3078 = (void*)0;
            int32_t *l_3079[1][4][1];
            uint16_t l_3080 = 0UL;
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_3079[i][j][k] = &g_957[2][2].f3;
                }
            }
            l_3080--;
        }
    }
    if (((*l_82) ^ ((((safe_add_func_int64_t_s_s((((*g_1237) = (((void*)0 == &l_1719) ^ ((*l_82) < (*l_68)))) , (safe_mod_func_int64_t_s_s(((***g_929) = (*l_68)), (safe_lshift_func_int8_t_s_s((((safe_div_func_int16_t_s_s((safe_mod_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(((safe_rshift_func_uint64_t_u_u((((*g_768) = ((safe_rshift_func_int32_t_s_s((p_50 < (safe_lshift_func_uint64_t_u_u((((p_50 == (l_3106 = ((((safe_lshift_func_uint32_t_u_s((l_1609 = ((safe_sub_func_uint8_t_u_u((65532UL || 8UL), 0xE2L)) ^ 0xBD5EL)), 29)) , l_3105) ^ 1UL) > p_50))) , (*g_768)) >= p_50), 54))), p_50)) != (*l_68))) <= l_3107), 30)) == p_50), (*l_82))), 0x1FED7BB226321F4DLL)), 0xA83BL)) > p_50) < p_50), l_3108))))), (*l_82))) || (-9L)) , l_3109) > (*l_68))))
    { /* block id: 1313 */
        uint8_t l_3110 = 0xDDL;
        int32_t *l_3113 = &g_961.f3;
        int32_t *l_3114 = (void*)0;
        int32_t *l_3115 = &g_987.f3;
        int32_t l_3116 = 0xA5431333L;
        int32_t *l_3117 = &g_946[3][2].f3;
        int32_t l_3118[5];
        int32_t *l_3119 = &g_1111.f3;
        int32_t *l_3120[1];
        int i;
        for (i = 0; i < 5; i++)
            l_3118[i] = 6L;
        for (i = 0; i < 1; i++)
            l_3120[i] = &l_1952;
        ++l_3110;
        --l_3121;
    }
    else
    { /* block id: 1316 */
        int64_t **l_3126 = &g_249;
        int32_t l_3129 = (-1L);
        int32_t l_3149 = 0xBE7C732EL;
        int32_t l_3151[1];
        int64_t *****l_3161 = &l_2427;
        int32_t l_3162[6];
        int16_t ****l_3178[9] = {(void*)0,&g_2594,(void*)0,&g_2594,(void*)0,&g_2594,(void*)0,&g_2594,(void*)0};
        uint64_t **l_3180 = &g_914;
        uint64_t **l_3182[4][6] = {{&g_914,(void*)0,&g_914,&g_914,(void*)0,&g_914},{&g_914,(void*)0,&g_914,&g_914,(void*)0,&g_914},{&g_914,(void*)0,&g_914,&g_914,(void*)0,&g_914},{&g_914,(void*)0,&g_914,&g_914,(void*)0,&g_914}};
        int32_t **l_3197 = &g_1465[4][0];
        uint16_t **l_3202[8][3][6] = {{{&g_1237,&g_1237,&g_1237,&g_1237,(void*)0,&g_1237},{(void*)0,&g_1237,&g_1237,&g_1237,&g_1237,&g_1237},{(void*)0,&g_1237,&g_1237,&g_1237,&g_1237,&g_1237}},{{&g_1237,(void*)0,&g_1237,&g_1237,(void*)0,&g_1237},{&g_1237,&g_1237,&g_1237,(void*)0,(void*)0,&g_1237},{(void*)0,(void*)0,&g_1237,&g_1237,&g_1237,&g_1237}},{{&g_1237,&g_1237,&g_1237,(void*)0,&g_1237,&g_1237},{&g_1237,&g_1237,&g_1237,&g_1237,(void*)0,&g_1237},{(void*)0,&g_1237,&g_1237,&g_1237,&g_1237,&g_1237}},{{&g_1237,&g_1237,&g_1237,&g_1237,&g_1237,&g_1237},{&g_1237,&g_1237,&g_1237,&g_1237,(void*)0,&g_1237},{(void*)0,(void*)0,&g_1237,&g_1237,&g_1237,&g_1237}},{{&g_1237,&g_1237,&g_1237,(void*)0,&g_1237,&g_1237},{&g_1237,(void*)0,&g_1237,&g_1237,(void*)0,&g_1237},{(void*)0,&g_1237,&g_1237,(void*)0,&g_1237,&g_1237}},{{&g_1237,&g_1237,&g_1237,&g_1237,&g_1237,&g_1237},{&g_1237,&g_1237,&g_1237,&g_1237,(void*)0,&g_1237},{(void*)0,&g_1237,&g_1237,&g_1237,&g_1237,&g_1237}},{{(void*)0,&g_1237,&g_1237,&g_1237,&g_1237,&g_1237},{&g_1237,(void*)0,&g_1237,&g_1237,(void*)0,&g_1237},{&g_1237,&g_1237,&g_1237,(void*)0,(void*)0,&g_1237}},{{(void*)0,(void*)0,&g_1237,&g_1237,&g_1237,&g_1237},{&g_1237,&g_1237,&g_1237,(void*)0,&g_1237,&g_1237},{&g_1237,&g_1237,&g_1237,&g_1237,(void*)0,&g_1237}}};
        uint64_t l_3206 = 0x50FFEE819A9C51D5LL;
        int16_t l_3235 = 0xE93FL;
        uint64_t l_3256[8] = {0UL,0xEEA48316F7F2FA60LL,0UL,0UL,0xEEA48316F7F2FA60LL,0UL,0UL,0xEEA48316F7F2FA60LL};
        const struct S0 ***l_3264 = (void*)0;
        uint32_t ***l_3266 = &g_2313;
        int16_t ** const *l_3291 = &g_1720[1][7][0];
        int16_t ** const **l_3290 = &l_3291;
        const uint64_t l_3295[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
        int8_t ***l_3356 = &l_2332;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_3151[i] = (-8L);
        for (i = 0; i < 6; i++)
            l_3162[i] = 0x0B03BD5DL;
        for (g_54 = 0; (g_54 <= 6); g_54 += 1)
        { /* block id: 1319 */
            int64_t ***l_3127 = (void*)0;
            int64_t **l_3128 = &g_249;
            int32_t l_3130 = 5L;
            int32_t l_3133 = 0xDEE072EFL;
            int16_t l_3144 = 0x9F37L;
            int32_t l_3145 = 0x9A56F8C6L;
            int32_t l_3146 = 0x1C34EB73L;
            int32_t l_3147 = 0xF67D3AA8L;
            int32_t l_3148 = (-2L);
            int32_t l_3150 = 1L;
            uint64_t l_3152 = 0x64D82E064EDAA073LL;
            int16_t *** const *l_3156 = &g_2594;
            int16_t *** const **l_3155 = &l_3156;
            (*g_1122) = (safe_div_func_int8_t_s_s(p_50, p_50));
            (*g_1122) = (((***g_927) = (**g_928)) != (l_3128 = l_3126));
            l_3130 = l_3129;
            if ((p_50 < (((l_3130 = p_50) ^ (safe_sub_func_int32_t_s_s(l_3133, (((~(((safe_div_func_uint32_t_u_u(((safe_rshift_func_int64_t_s_u((safe_add_func_uint32_t_u_u((l_3141 < ((p_50 , (safe_add_func_uint8_t_u_u((++l_3152), ((l_3150 = ((((void*)0 != l_3155) , ((safe_mod_func_uint16_t_u_u(((safe_mul_func_uint64_t_u_u(((void*)0 != l_3161), (*g_914))) < 0x2B02L), p_50)) < 0x67FAL)) , p_50)) < p_50)))) & l_3162[2])), p_50)), 29)) < l_3151[0]), 6L)) ^ (*g_768)) >= 0x07L)) && 0xF5C5BDB535F4AF71LL) ^ p_50)))) < p_50)))
            { /* block id: 1328 */
                union U2 * volatile ***l_3164[6][9] = {{&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,(void*)0,&g_3163,&g_3163,(void*)0},{&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163},{&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163},{&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,&g_3163},{&g_3163,&g_3163,&g_3163,&g_3163,&g_3163,(void*)0,&g_3163,&g_3163,&g_3163},{&g_3163,&g_3163,(void*)0,&g_3163,(void*)0,&g_3163,&g_3163,&g_3163,&g_3163}};
                int i, j;
                g_3163 = g_3163;
            }
            else
            { /* block id: 1330 */
                return p_50;
            }
        }
        for (g_1111.f3 = (-30); (g_1111.f3 <= (-23)); g_1111.f3++)
        { /* block id: 1336 */
            const int32_t l_3177 = 0xF8EC5C83L;
            uint64_t **l_3183[2];
            int32_t *l_3184 = &l_3149;
            int i;
            for (i = 0; i < 2; i++)
                l_3183[i] = (void*)0;
            if (p_50)
            { /* block id: 1337 */
                uint16_t l_3179 = 0x03C0L;
                for (g_2220.f2 = 8; (g_2220.f2 >= 2); g_2220.f2 -= 1)
                { /* block id: 1340 */
                    int64_t l_3176 = 0x0DBA41B7A2F30CD1LL;
                    for (g_973.f3 = 6; (g_973.f3 >= 0); g_973.f3 -= 1)
                    { /* block id: 1343 */
                        uint64_t ***l_3181 = &l_3180;
                        int i;
                        (*g_1341) |= (((l_3182[3][4] = ((*l_3181) = ((safe_mod_func_int16_t_s_s((safe_mul_func_int64_t_s_s(((l_1963[(g_973.f3 + 1)] , (++(*g_914))) , ((*g_914) && l_3149)), (((((**l_1718) = p_50) || ((p_50 > (safe_mul_func_uint64_t_u_u((g_3175[1] > (((l_3176 <= (((&g_2594 == ((l_3177 < p_50) , l_3178[8])) > p_50) , p_50)) || l_3162[4]) & l_3179)), p_50))) ^ 254UL)) < p_50) > l_3129))), 0x2265L)) , l_3180))) == l_3183[0]) ^ p_50);
                    }
                    for (g_98 = 0; (g_98 <= 6); g_98 += 1)
                    { /* block id: 1352 */
                        int32_t *l_3185 = &g_976.f3;
                        l_3185 = l_3184;
                    }
                }
                for (l_3179 = 0; (l_3179 <= 3); l_3179 += 1)
                { /* block id: 1358 */
                    volatile union U2 **l_3186 = &g_997;
                    (*l_3186) = g_997;
                }
                for (g_976.f2 = (-25); (g_976.f2 < (-28)); g_976.f2 = safe_sub_func_uint8_t_u_u(g_976.f2, 9))
                { /* block id: 1363 */
                    for (g_982.f3 = 0; (g_982.f3 >= (-7)); g_982.f3 = safe_sub_func_uint16_t_u_u(g_982.f3, 7))
                    { /* block id: 1366 */
                        (*l_3184) = 1L;
                        if ((*l_82))
                            continue;
                        (*l_3184) = ((**g_248) , l_3151[0]);
                    }
                }
            }
            else
            { /* block id: 1372 */
                uint32_t *****l_3193 = (void*)0;
                uint32_t ****l_3195 = &g_2312;
                uint32_t *****l_3194 = &l_3195;
                int32_t l_3196 = (-7L);
                for (g_607.f3 = (-29); (g_607.f3 < 8); g_607.f3++)
                { /* block id: 1375 */
                    return p_50;
                }
                l_3196 = (((*l_3194) = (void*)0) != &l_2160);
            }
            (*l_82) &= p_50;
        }
        (*l_3197) = &l_3129;
        for (l_3149 = 8; (l_3149 >= (-16)); l_3149 = safe_sub_func_int64_t_s_s(l_3149, 5))
        { /* block id: 1386 */
            uint16_t ***l_3203 = &l_1538[0];
            int32_t l_3211 = 0xD5CE9E83L;
            int32_t l_3216[10] = {7L,0xDFDBDC6EL,7L,0xA5203BF9L,0xA5203BF9L,7L,0xDFDBDC6EL,7L,0xA5203BF9L,0xA5203BF9L};
            uint8_t l_3234 = 0x16L;
            int32_t *l_3240[9];
            int8_t l_3254 = (-7L);
            uint32_t *** const l_3267 = &g_2313;
            int16_t ** const **l_3292 = &l_3291;
            int i;
            for (i = 0; i < 9; i++)
                l_3240[i] = &g_978.f3;
        }
    }
    for (g_749 = 25; (g_749 <= (-29)); g_749--)
    { /* block id: 1474 */
        uint32_t l_3398 = 0x3E686D03L;
        const uint16_t *** const l_3413 = &g_2750;
        int32_t l_3428 = 1L;
        int32_t l_3456[7][1] = {{1L},{0x8E3FE587L},{1L},{1L},{0x8E3FE587L},{1L},{1L}};
        uint32_t l_3457 = 4UL;
        int i, j;
    }
    return (*g_1237);
}


/* ------------------------------------------ */
/* 
 * reads : g_744 g_748
 * writes: g_744 g_748
 */
static int32_t * func_58(uint32_t  p_59, const uint32_t  p_60, uint8_t  p_61, int16_t  p_62, uint64_t  p_63)
{ /* block id: 434 */
    uint64_t l_1096 = 18446744073709551612UL;
    int64_t ****l_1107[9] = {&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929};
    int32_t l_1117 = 0xE51B89FFL;
    int32_t **l_1156 = &g_89;
    int32_t ***l_1155 = &l_1156;
    int8_t l_1204[4];
    uint16_t **l_1239 = &g_1237;
    int32_t l_1251 = 1L;
    int32_t l_1252 = 0x4664CB41L;
    uint32_t l_1296 = 8UL;
    uint32_t l_1309 = 0xC6F1A316L;
    int32_t l_1325 = 0L;
    uint32_t l_1329 = 0x634E319EL;
    int32_t l_1359 = 5L;
    int32_t l_1360 = 0xF905FF6EL;
    int32_t l_1372[7][1][9] = {{{0x202CED09L,(-2L),0xAD0FC5DAL,1L,2L,0x202CED09L,0x202CED09L,2L,1L}},{{(-1L),1L,(-1L),0xAD0FC5DAL,2L,(-1L),0x3DE13794L,0xEBC9D988L,0xAD0FC5DAL}},{{(-1L),2L,0xAD0FC5DAL,(-1L),1L,(-1L),0xAD0FC5DAL,2L,(-1L)}},{{0x202CED09L,2L,1L,0xAD0FC5DAL,(-2L),0x202CED09L,0xAD0FC5DAL,(-10L),0xAD0FC5DAL}},{{0xAD0FC5DAL,1L,1L,1L,0x202CED09L,0xD9D1D444L,0x44B935F0L,0x3DE13794L,1L}},{{2L,0xAD0FC5DAL,0xD9D1D444L,1L,(-1L),2L,2L,(-1L),1L}},{{8L,0x202CED09L,8L,0xD9D1D444L,(-1L),8L,0x44B935F0L,1L,0xD9D1D444L}}};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1204[i] = 0x8BL;
    for (g_744 = 8; (g_744 >= 0); g_744 -= 1)
    { /* block id: 437 */
        int64_t * const l_1098[2][3][8] = {{{&g_748,&g_744,&g_748,&g_748,&g_744,&g_748,&g_748,&g_744},{&g_744,&g_748,&g_748,&g_744,&g_748,&g_748,&g_744,&g_748},{&g_744,&g_744,&g_744,&g_744,&g_744,&g_744,&g_744,&g_744}},{{&g_748,&g_744,&g_748,&g_748,&g_744,&g_748,&g_748,&g_744},{&g_744,&g_748,&g_748,&g_744,&g_748,&g_748,&g_744,&g_748},{&g_744,&g_744,&g_744,&g_744,&g_744,&g_744,&g_744,&g_744}}};
        int8_t l_1108 = 0L;
        int8_t l_1109[4];
        union U2 *l_1110 = &g_1111;
        int32_t l_1112 = 0x31B87059L;
        int32_t l_1114 = (-1L);
        int32_t *l_1123[2];
        uint32_t l_1179 = 7UL;
        int16_t *l_1242 = &g_10[3];
        int32_t l_1247 = (-1L);
        uint8_t l_1254 = 0xE9L;
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_1109[i] = 0x4EL;
        for (i = 0; i < 2; i++)
            l_1123[i] = &g_976.f3;
    }
    for (g_748 = 0; (g_748 != (-23)); g_748--)
    { /* block id: 558 */
        int32_t l_1368 = 0x573E4FB5L;
        int32_t l_1369 = 1L;
        int32_t *l_1370 = (void*)0;
        int32_t *l_1371[10][8] = {{&l_1117,&l_1252,&g_1342,&g_90,&g_90,&g_1342,&l_1252,&l_1117},{&l_1252,&l_1252,&l_1117,(void*)0,&l_1117,&l_1252,&l_1252,&l_1252},{&l_1252,(void*)0,&g_1342,&g_1342,(void*)0,&l_1252,&g_90,&l_1252},{(void*)0,&l_1252,&g_90,&l_1252,(void*)0,&g_1342,&g_1342,(void*)0},{&l_1252,&l_1252,&l_1252,&l_1252,&l_1117,(void*)0,&l_1117,&l_1252},{&l_1252,&l_1117,&l_1252,&g_1342,&g_90,&g_90,&g_1342,&l_1252},{&l_1117,&l_1117,&g_90,(void*)0,&l_1251,(void*)0,&g_90,&l_1117},{&l_1117,&l_1252,&g_1342,&g_90,&g_90,&g_1342,&l_1252,&l_1117},{&l_1252,&l_1252,&l_1117,(void*)0,&l_1117,&l_1252,&l_1252,&l_1252},{&l_1252,(void*)0,&g_1342,&g_1342,(void*)0,&l_1252,&g_90,&l_1252}};
        int64_t l_1373 = (-1L);
        uint16_t l_1374 = 1UL;
        int i, j;
        ++l_1374;
        return &g_1342;
    }
    return &g_81;
}


/* ------------------------------------------ */
/* 
 * reads : g_89 g_98 g_211 g_41 g_176 g_249 g_457 g_54 g_10 g_406.f0 g_51 g_336 g_184 g_81 g_117 g_421 g_90 g_633 g_589.f0 g_667 g_668.f3 g_458.f0 g_550 g_679 g_750 g_721.f0 g_749 g_748 g_244 g_110 g_723.f3 g_849 g_744 g_901 g_997 g_977.f0 g_952.f0 g_971.f0 g_946.f0 g_1036 g_961.f3 g_986.f0 g_1054 g_768 g_1070 g_964.f0 g_602.f0 g_974.f0 g_955.f0 g_966.f0
 * writes: g_89 g_110 g_98 g_176 g_457 g_573 g_117 g_81 g_184 g_633 g_667 g_668.f3 g_679 g_602.f0 g_90 g_607.f2 g_750 g_721.f0 g_748 g_768 g_771 g_723.f3 g_458.f2 g_406.f3 g_589.f2 g_51 g_749 g_244 g_421 g_458.f3 g_849 g_901 g_914 g_744 g_927 g_957.f3 g_961.f3 g_1039.f0
 */
static uint16_t  func_64(uint32_t  p_65)
{ /* block id: 158 */
    int32_t l_426 = (-3L);
    uint64_t **l_504 = (void*)0;
    union U2 **l_514 = &g_457;
    int32_t l_551 = 0x9760EF43L;
    uint8_t *l_571 = &g_110;
    int16_t *l_575[9][2][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}}};
    int16_t **l_574 = &l_575[0][1][0];
    int32_t *l_584[4];
    uint32_t l_593 = 0x454D5774L;
    int64_t ***l_597[9];
    int64_t ****l_596 = &l_597[2];
    const union U1 *l_601 = &g_602;
    const union U1 **l_600 = &l_601;
    int8_t l_628 = 0x39L;
    uint8_t l_652 = 0x0AL;
    const int32_t *l_753 = (void*)0;
    int32_t l_755 = 0x1731D43FL;
    uint32_t **l_784 = &g_351;
    uint32_t ***l_783 = &l_784;
    uint32_t ****l_782 = &l_783;
    uint32_t *****l_781 = &l_782;
    int64_t l_847 = 0L;
    uint32_t l_924[8] = {4294967295UL,0xBC1B6CD8L,4294967295UL,0xBC1B6CD8L,4294967295UL,0xBC1B6CD8L,4294967295UL,0xBC1B6CD8L};
    int32_t l_935 = 5L;
    int32_t ** const l_1046 = (void*)0;
    int32_t ** const *l_1045[10] = {&l_1046,&l_1046,(void*)0,(void*)0,(void*)0,&l_1046,&l_1046,(void*)0,(void*)0,(void*)0};
    int8_t l_1069 = (-3L);
    int16_t l_1073 = 1L;
    uint64_t l_1074 = 0xDB86D47DD26F7BA7LL;
    uint8_t l_1079[9];
    uint64_t l_1085 = 0x7FE75DFC2179EAAFLL;
    int16_t l_1086 = 0x5B99L;
    uint16_t *l_1087[1][3][6] = {{{&g_901,&g_550,&g_550,&g_901,&g_550,&g_550},{&g_901,&g_550,&g_550,&g_901,&g_550,&g_550},{&g_901,&g_550,&g_550,&g_901,&g_550,&g_550}}};
    int8_t l_1088 = 0x72L;
    uint32_t l_1089 = 18446744073709551606UL;
    uint32_t l_1090 = 3UL;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_584[i] = &l_551;
    for (i = 0; i < 9; i++)
        l_597[i] = &g_248;
    for (i = 0; i < 9; i++)
        l_1079[i] = 0x94L;
    if (l_426)
    { /* block id: 159 */
        int32_t **l_427 = &g_89;
        uint64_t *l_439 = &g_184;
        uint64_t **l_438 = &l_439;
        uint8_t *l_440 = &g_110;
        int64_t **l_442 = &g_249;
        int32_t l_455 = 0L;
        const uint16_t *l_501 = &g_244[2][0];
        uint16_t l_552 = 1UL;
        uint32_t ****l_591 = (void*)0;
        (*l_427) = &l_426;
        if ((safe_div_func_uint8_t_u_u(((*l_440) = (safe_lshift_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(((*g_89) ^ (0x67L == (safe_div_func_uint8_t_u_u((((0xAE435E4FL || (p_65 , ((((l_426 , &g_184) != ((safe_div_func_uint64_t_u_u(g_98, l_426)) , ((*l_438) = &g_184))) > 0UL) >= g_211))) == (**l_427)) & l_426), p_65)))), 3)), 1))), p_65)))
        { /* block id: 163 */
            int64_t **l_443 = &g_249;
            int32_t l_454 = 0x19399761L;
            int16_t *l_456 = &g_98;
            union U2 **l_459 = &g_457;
            uint32_t l_466 = 0x36BB1C12L;
            int16_t *l_509 = &g_10[0];
            uint64_t **l_531 = (void*)0;
            int32_t *l_553 = &g_90;
            (*l_459) = ((((((!0xBEB1L) >= (**l_427)) && ((p_65 , l_442) != l_443)) == g_41) >= ((**l_443) = (safe_div_func_uint32_t_u_u((safe_mod_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(((*l_456) = (65535UL || (safe_rshift_func_uint32_t_u_u((safe_sub_func_uint8_t_u_u(((-1L) && (l_454 , l_455)), g_176)), 3)))), p_65)), p_65)), l_454)))) , g_457);
            if ((((safe_sub_func_int64_t_s_s(((safe_lshift_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(((l_466 || (((-1L) <= (safe_mul_func_int16_t_s_s(((safe_add_func_int32_t_s_s((**l_427), ((safe_mod_func_int8_t_s_s(p_65, g_54)) >= (65528UL == (((g_98 = 0xDBFDL) , &g_184) == &g_184))))) & 0L), g_10[3]))) == l_466)) == g_176), p_65)), 2)) == 0x06L), 0xE586B9E0CDC916C7LL)) <= (**l_427)) , 0x4E21D802L))
            { /* block id: 168 */
                uint32_t *l_490 = &g_421;
                int32_t l_496 = 3L;
                const uint64_t l_497 = 0x201B3478E54A3581LL;
                uint32_t *l_498 = &g_117;
                uint16_t *l_500 = &g_244[0][4];
                uint16_t **l_499 = &l_500;
                const int64_t *l_502 = &g_176;
                int32_t *l_503 = &g_406[4].f3;
                l_503 = ((*l_427) = &l_426);
            }
            else
            { /* block id: 175 */
                int16_t **l_508 = &l_456;
                int32_t *l_536 = &l_454;
                if ((((((void*)0 == &l_454) , l_504) != ((!((safe_mod_func_int64_t_s_s((((((*l_508) = &g_10[3]) == (g_98 , l_509)) , g_406[4].f0) != 0x66BC25593DA98930LL), (safe_sub_func_uint32_t_u_u(g_51[4][2][2], p_65)))) ^ l_426)) , &l_439)) != p_65))
                { /* block id: 177 */
                    uint32_t *l_519 = &g_421;
                    int32_t l_526 = 1L;
                    uint64_t **l_530 = &l_439;
                    uint32_t **l_534 = &l_519;
                    uint32_t ***l_533 = &l_534;
                    uint16_t *l_535 = &g_244[0][4];
                    (**l_427) = (((g_51[3][3][2] , l_514) != (void*)0) & ((safe_sub_func_int32_t_s_s((((void*)0 != &l_454) || 6UL), 4294967295UL)) != g_336));
                    (*l_427) = l_536;
                    return l_526;
                }
                else
                { /* block id: 185 */
                    uint64_t * const *l_543 = &l_439;
                    int32_t l_549 = 0L;
                    int32_t *l_554 = &g_90;
                    l_554 = (l_466 , &l_549);
                    return l_426;
                }
            }
        }
        else
        { /* block id: 193 */
            int8_t l_555 = (-1L);
            int16_t *l_556[5][1] = {{&g_10[2]},{&g_98},{&g_10[2]},{&g_98},{&g_10[2]}};
            int32_t l_561 = 0x70705768L;
            int32_t *l_562[7][8] = {{&l_551,&l_455,&l_455,&l_551,&g_90,&l_551,&l_455,&l_455},{&l_455,&g_90,&l_551,&l_551,&g_90,&l_455,&g_90,&l_551},{&l_551,&g_90,&l_551,&l_455,&l_455,&l_551,&g_90,&l_551},{&g_81,&l_455,&l_551,&l_455,&g_81,&g_81,&l_455,&l_551},{&g_81,&g_81,&l_455,&l_551,&l_455,&g_81,&g_81,&l_455},{&l_551,&l_455,&l_455,&l_551,&g_90,&l_551,&l_455,&l_455},{&l_455,&g_90,&l_551,&l_551,&g_90,&l_455,&g_90,&l_551}};
            uint64_t *l_572 = &g_573;
            int i, j;
            (*l_427) = &g_81;
lbl_585:
            if (((*g_89) = (p_65 > (g_184 >= ((l_426 = (((((((g_406[4].f0 , 1UL) <= p_65) != (g_117 &= (safe_add_func_uint8_t_u_u(((*l_571) = (((safe_mod_func_int64_t_s_s(((l_426 != ((*l_572) = (((safe_mod_func_uint64_t_u_u((g_10[1] ^ l_551), p_65)) , (void*)0) != l_571))) >= (*g_249)), l_426)) | (**l_427)) && (**l_427))), l_426)))) , (void*)0) == l_574) < l_426) | 8UL)) < 0xE297C8DE38532F8FLL)))))
            { /* block id: 204 */
                return p_65;
            }
            else
            { /* block id: 206 */
                int32_t l_583 = 0xA1E8B5FAL;
                g_89 = (((5UL != p_65) , (safe_mod_func_uint16_t_u_u((+((safe_add_func_uint64_t_u_u((((*l_572) = p_65) || (g_10[0] > g_10[5])), ((safe_mod_func_uint64_t_u_u((p_65 && ((*l_439) = (((**l_427) != (g_421 , (((l_583 >= p_65) , l_426) ^ (**l_427)))) , 0x171E36E5A27F58D0LL))), l_583)) | p_65))) <= 1UL)), g_54))) , l_584[1]);
                if (l_426)
                    goto lbl_585;
            }
            for (l_552 = 20; (l_552 < 23); l_552 = safe_add_func_uint32_t_u_u(l_552, 3))
            { /* block id: 214 */
                union U1 *l_588 = &g_589;
                union U1 **l_590 = &l_588;
                (*l_590) = l_588;
                if (p_65)
                { /* block id: 216 */
                    uint32_t *****l_592 = &l_591;
                    (*l_592) = l_591;
                }
                else
                { /* block id: 218 */
                    return p_65;
                }
            }
        }
    }
    else
    { /* block id: 223 */
        int64_t ***l_595 = &g_248;
        int64_t ****l_594 = &l_595;
        const union U1 **l_603 = (void*)0;
        union U1 *l_606 = &g_607;
        union U1 **l_605 = &l_606;
        union U1 ***l_604 = &l_605;
        union U1 **l_608 = &l_606;
        uint64_t * const l_610[4][2][5] = {{{&g_184,&g_184,&g_184,&g_184,&g_184},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_184,&g_184,&g_184,&g_184,&g_184},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_184,&g_184,&g_184,&g_184,&g_184},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_184,&g_184,&g_184,&g_184,&g_184},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
        uint64_t * const *l_609 = &l_610[1][1][0];
        uint64_t * const **l_611 = &l_609;
        const int32_t l_616 = 0L;
        int32_t l_626 = 0x65F03F7DL;
        int32_t l_627 = 0xD7F12601L;
        int32_t l_629 = (-8L);
        int32_t l_745 = 0xE16673D4L;
        int i, j, k;
        l_593 = (((p_65 ^ 0x66L) , &g_89) != (void*)0);
        l_596 = l_594;
        l_629 = (safe_mod_func_int16_t_s_s(((l_603 = l_600) != (l_608 = ((*l_604) = (void*)0))), ((((*l_611) = l_609) != ((+(+(safe_sub_func_int8_t_s_s(p_65, (l_616 <= 0x92DBL))))) , l_504)) || (safe_mul_func_uint64_t_u_u((g_184 = ((safe_unary_minus_func_uint16_t_u((safe_rshift_func_int16_t_s_s(((((l_627 = (safe_div_func_int32_t_s_s((l_626 = (safe_lshift_func_uint32_t_u_s(p_65, l_616))), l_616))) <= l_616) > 1L) , 0x928EL), p_65)))) && l_628)), l_616)))));
        for (l_629 = 2; (l_629 >= 0); l_629 -= 1)
        { /* block id: 236 */
            const int32_t **l_630 = (void*)0;
            const int32_t *l_632[5][4][9] = {{{&l_629,(void*)0,&g_81,&l_626,&l_629,(void*)0,&g_90,&l_629,&l_629},{(void*)0,&l_551,&l_551,&l_551,(void*)0,(void*)0,(void*)0,&l_629,&l_616},{&l_629,&l_629,&g_90,&g_54,&l_627,&l_627,&g_54,&g_90,&l_629},{(void*)0,&l_627,(void*)0,&g_54,&g_81,(void*)0,&g_90,&g_90,&g_90}},{{&l_629,&l_616,&g_54,&l_627,&l_626,(void*)0,&l_616,&l_629,&l_626},{&l_616,&l_627,&g_54,&l_551,&l_426,&l_629,&l_426,&l_551,&g_54},{&l_629,&l_629,&g_81,&g_54,&l_629,&l_627,&g_81,&l_626,(void*)0},{&l_629,&l_627,&l_626,(void*)0,&l_626,&l_627,&l_629,&l_629,&g_90}},{{&l_627,&g_90,&g_81,&l_629,&l_627,&l_616,&l_616,&l_627,&l_629},{(void*)0,&l_616,(void*)0,&g_54,&l_426,&g_90,&l_551,&l_629,&l_426},{(void*)0,&l_626,&l_616,&g_81,&l_629,&l_627,&l_616,&l_626,&l_626},{&g_90,(void*)0,&g_81,&g_54,(void*)0,&l_627,(void*)0,&l_627,(void*)0}},{{&l_629,&l_616,&l_616,&l_629,(void*)0,&g_54,&l_626,&l_629,&l_626},{&l_426,&l_616,&l_426,(void*)0,&l_616,(void*)0,&l_426,&l_616,&l_426},{&l_626,&l_629,&l_626,&g_54,(void*)0,&l_629,&l_616,&l_616,&l_629},{(void*)0,&l_627,(void*)0,&l_627,(void*)0,&g_54,&g_81,(void*)0,&g_90}},{{&l_626,&l_626,&l_616,&l_627,&l_629,&g_81,&l_616,&l_626,(void*)0},{&l_426,&l_629,&l_551,&g_90,&l_426,&g_54,(void*)0,&l_616,(void*)0},{&l_629,&l_627,&l_616,&l_616,&l_627,&l_629,&g_81,&g_90,&l_627},{&g_90,&l_629,&l_629,&l_627,&l_626,(void*)0,&l_626,&l_627,&l_629}}};
            const int32_t **l_631[2][10] = {{&l_632[0][2][0],&l_632[4][1][1],&l_632[0][2][0],&l_632[0][0][1],&l_632[0][0][1],&l_632[0][2][0],&l_632[4][1][1],&l_632[0][2][0],&l_632[0][0][1],&l_632[0][0][1]},{&l_632[0][2][0],&l_632[4][1][1],&l_632[0][2][0],&l_632[0][0][1],&l_632[0][0][1],&l_632[0][2][0],&l_632[4][1][1],&l_632[0][2][0],&l_632[0][0][1],&l_632[0][0][1]}};
            uint64_t l_634 = 0xDD32B8167B3243C5LL;
            int32_t l_651 = (-7L);
            int8_t l_664 = 0x96L;
            int32_t l_685 = 0xFA5667CAL;
            union U2 *l_722 = &g_723;
            int32_t l_742 = (-1L);
            int i, j, k;
            g_633 = &l_616;
            if ((p_65 ^ (((g_90 == l_634) < (!(+(safe_rshift_func_uint16_t_u_u(p_65, ((safe_lshift_func_uint8_t_u_u(((l_626 = (safe_mod_func_int32_t_s_s((safe_mul_func_int32_t_s_s(((g_90 ^ ((g_81 ^= ((*g_633) , (safe_lshift_func_uint16_t_u_u(l_629, (safe_mul_func_int64_t_s_s((l_651 = (safe_sub_func_int16_t_s_s(p_65, 9L))), 0UL)))))) <= 4294967295UL)) > 0x22F5F7F1L), l_626)), l_652))) , p_65), p_65)) > 18446744073709551607UL)))))) ^ p_65)))
            { /* block id: 241 */
                if (p_65)
                    break;
            }
            else
            { /* block id: 243 */
                uint16_t l_653 = 1UL;
                ++l_653;
            }
            l_627 ^= ((safe_mul_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s(((65530UL <= (g_589.f0 && (((((safe_mod_func_uint8_t_u_u(((((safe_mul_func_int64_t_s_s(p_65, l_664)) != ((g_90 , (((safe_mul_func_int64_t_s_s(0x9C11E29855776FC0LL, p_65)) , (*l_600)) == (g_667 = (g_10[3] , g_667)))) != (*g_633))) | 18446744073709551614UL) || p_65), 7L)) , p_65) && p_65) , 5UL) ^ p_65))) && l_626), l_626)) | p_65), 1UL)) <= (*g_633));
            for (l_426 = 8; (l_426 >= 2); l_426 -= 1)
            { /* block id: 250 */
                int8_t l_684 = 0xE6L;
                uint32_t l_686 = 0xC1E4A8EBL;
                int32_t l_701 = 0x0B8747EBL;
                int32_t l_704 = (-10L);
                int32_t l_739 = (-1L);
                int32_t l_743[10][8][3] = {{{0x70D33606L,(-1L),(-1L)},{0x6F0F9B32L,0x5AFC43BAL,4L},{0x1F17BB37L,(-1L),0x6FD633E2L},{0x6F0F9B32L,1L,0x3E6EBE94L},{0x70D33606L,0xA739BD94L,0xA739BD94L},{0L,4L,1L},{0xAFE9ADDFL,0x1F17BB37L,0x775543B0L},{0x5CA092ADL,0x96D0B85EL,4L}},{{1L,(-10L),0xC76C5F78L},{0xB3362CA9L,0x96D0B85EL,0xC01DC3EDL},{(-5L),0x1F17BB37L,0x70D33606L},{4L,4L,0x96D0B85EL},{0xC76C5F78L,0xA739BD94L,(-1L)},{0x5AFC43BAL,1L,5L},{(-1L),(-1L),(-5L)},{9L,0L,0x6F0F9B32L}},{{0x6FD633E2L,(-10L),0x70D33606L},{0L,0xC01DC3EDL,0L},{5L,(-1L),0xAFE9ADDFL},{0x96D0B85EL,1L,0x5CA092ADL},{(-1L),0x1F17BB37L,1L},{1L,0x5CA092ADL,0xB3362CA9L},{(-1L),0x775543B0L,(-5L)},{0x96D0B85EL,4L,4L}},{{5L,1L,0xC76C5F78L},{0L,1L,0x5AFC43BAL},{0x6FD633E2L,6L,(-1L)},{(-5L),5L,9L},{0x70D33606L,6L,(-1L)},{0L,1L,0x96D0B85EL},{1L,1L,6L},{9L,4L,0xD671444BL}},{{0x1F17BB37L,0x775543B0L,0x2F0E1443L},{0xD671444BL,0x5CA092ADL,0L},{1L,0x1F17BB37L,0x2F0E1443L},{4L,1L,0xD671444BL},{6L,(-1L),6L},{1L,0xC01DC3EDL,0x96D0B85EL},{0xAFE9ADDFL,(-10L),(-1L)},{0xC01DC3EDL,0L,9L}},{{0xA739BD94L,(-1L),(-1L)},{0xC01DC3EDL,0x3E6EBE94L,0x5AFC43BAL},{0xAFE9ADDFL,0xC76C5F78L,0xC76C5F78L},{1L,9L,4L},{6L,0xA739BD94L,(-5L)},{4L,0L,0xB3362CA9L},{1L,0L,1L},{0xD671444BL,0L,0x5CA092ADL}},{{0x1F17BB37L,0xA739BD94L,0xAFE9ADDFL},{9L,9L,0L},{1L,0xC76C5F78L,0x70D33606L},{0L,0x3E6EBE94L,0x6F0F9B32L},{0x70D33606L,(-1L),0x1F17BB37L},{(-5L),0L,0x6F0F9B32L},{0x6FD633E2L,(-10L),0x70D33606L},{0L,0xC01DC3EDL,0L}},{{5L,(-1L),0xAFE9ADDFL},{0x96D0B85EL,1L,0x5CA092ADL},{(-1L),0x1F17BB37L,1L},{1L,0x5CA092ADL,0xB3362CA9L},{(-1L),0x775543B0L,(-5L)},{0x96D0B85EL,4L,4L},{5L,1L,0xC76C5F78L},{0L,1L,0x5AFC43BAL}},{{0x6FD633E2L,6L,(-1L)},{(-5L),5L,9L},{0x70D33606L,6L,(-1L)},{0L,1L,0x96D0B85EL},{1L,1L,6L},{9L,4L,0xD671444BL},{0x1F17BB37L,0x775543B0L,0x2F0E1443L},{0xD671444BL,0x5CA092ADL,0L}},{{1L,0x1F17BB37L,0x2F0E1443L},{4L,1L,0xD671444BL},{6L,(-1L),6L},{1L,0xC01DC3EDL,0x96D0B85EL},{0xAFE9ADDFL,(-10L),(-1L)},{0xC01DC3EDL,0L,9L},{0xA739BD94L,(-1L),(-1L)},{0x5CA092ADL,0x5AFC43BAL,0L}}};
                int i, j, k;
                for (g_668.f3 = 0; (g_668.f3 <= 2); g_668.f3 += 1)
                { /* block id: 253 */
                    int8_t *l_677 = (void*)0;
                    int8_t *l_678[3];
                    int16_t * const l_680 = &g_10[3];
                    int16_t l_681 = 0xE402L;
                    uint32_t *l_682 = &g_602.f0;
                    int32_t l_683 = 0L;
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_678[i] = &l_628;
                    l_683 |= ((g_51[g_668.f3][(g_668.f3 + 1)][l_629] & (safe_add_func_uint16_t_u_u((((safe_add_func_int16_t_s_s((((~65530UL) <= ((*l_682) = ((1L & ((+(0x82C62C3FL >= (g_10[1] <= ((((((safe_mod_func_int16_t_s_s(p_65, ((((((((*l_574) = ((g_679 = p_65) , &g_10[2])) != l_680) , p_65) != l_681) , g_90) <= 0x084AL) | g_51[g_668.f3][(g_668.f3 + 1)][l_629]))) ^ p_65) | p_65) < p_65) || (-1L)) == (*g_249))))) == l_681)) > 0x50L))) || g_668.f3), 0x15AEL)) , 0xBA73AD7BL) >= g_51[g_668.f3][(g_668.f3 + 1)][l_629]), g_117))) != p_65);
                }
                ++l_686;
                for (g_90 = 8; (g_90 >= 0); g_90 -= 1)
                { /* block id: 262 */
                    int32_t l_695 = 3L;
                    int32_t l_705 = 0x64B7174BL;
                    union U2 *l_720[3];
                    int32_t l_746 = 3L;
                    int32_t l_747 = 0x55C0A2BBL;
                    uint8_t l_754 = 0UL;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_720[i] = &g_721;
                    for (l_664 = 0; (l_664 <= 8); l_664 += 1)
                    { /* block id: 265 */
                        l_626 |= l_627;
                        l_685 = 0x93ADAFA2L;
                        g_633 = &l_629;
                    }
                    for (g_607.f2 = 0; (g_607.f2 <= 7); g_607.f2 += 1)
                    { /* block id: 272 */
                        int8_t *l_700[7];
                        uint8_t *l_706[9][3] = {{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652},{&l_652,&l_652,&l_652}};
                        int32_t l_707 = 0x3C792F5CL;
                        int i, j;
                        for (i = 0; i < 7; i++)
                            l_700[i] = (void*)0;
                        l_626 = (safe_div_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((((l_685 = ((safe_mod_func_uint8_t_u_u((l_707 &= (((0xF6L < ((((((*l_571) = (l_695 = 0x4DL)) >= (l_701 &= (safe_rshift_func_uint32_t_u_s((safe_add_func_int32_t_s_s((*g_633), p_65)), 29)))) , (p_65 != (7UL != (-1L)))) || (safe_div_func_int8_t_s_s(l_704, 0x2CL))) <= l_626)) < l_705) ^ p_65)), p_65)) , (*g_249))) , g_336) , 0x785CL) <= 1UL), g_176)), g_41));
                        if (l_695)
                            continue;
                        l_722 = ((safe_mod_func_int16_t_s_s(((~((p_65 > ((safe_add_func_int16_t_s_s(((safe_mod_func_int64_t_s_s(((((0x4AL <= (l_705 != l_695)) <= ((~(0x2AB03BAFL > ((safe_mul_func_int32_t_s_s((safe_add_func_int16_t_s_s(g_54, 65535UL)), ((&l_664 == &g_51[4][2][2]) == 1UL))) != 18446744073709551615UL))) || g_10[4])) ^ p_65) || l_705), 0x5EF36D9DB50208D7LL)) & l_627), 0xB197L)) , p_65)) >= g_10[3])) , g_458.f0), 0x94F0L)) , l_720[1]);
                    }
                    for (l_634 = 0; (l_634 <= 8); l_634 += 1)
                    { /* block id: 284 */
                        int32_t l_740 = (-9L);
                        int32_t l_741[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_741[i] = 0xDFE3CAA0L;
                        l_626 = ((safe_lshift_func_int32_t_s_u((((p_65 , &l_601) != (l_701 , (*l_604))) ^ (-8L)), (safe_add_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((l_739 ^= ((safe_add_func_uint16_t_u_u(((safe_div_func_uint8_t_u_u((safe_unary_minus_func_int8_t_s((((void*)0 == (*l_604)) <= (safe_div_func_uint32_t_u_u(0xA4B35B72L, (safe_sub_func_int8_t_s_s((0x565954E45C702DA0LL < 0L), l_627))))))), 0x4AL)) == p_65), 65534UL)) & g_550)), p_65)), g_679)))) ^ 0x73320118A972BF6CLL);
                        --g_750[1];
                        l_753 = (p_65 , &l_616);
                        if (l_754)
                            break;
                    }
                }
            }
        }
    }
    if ((p_65 > p_65))
    { /* block id: 295 */
        uint8_t l_756 = 3UL;
        int8_t *l_769 = &g_51[4][2][2];
        uint32_t l_773[3][7][10] = {{{0x82A2C522L,1UL,18446744073709551615UL,0UL,1UL,0xD6D420E6L,18446744073709551615UL,0xAF15A877L,0x82A2C522L,0xAF15A877L},{0x2AEC7EE5L,0xD6D420E6L,18446744073709551614UL,18446744073709551609UL,18446744073709551614UL,0xD6D420E6L,0x2AEC7EE5L,18446744073709551607UL,6UL,0xD6D420E6L},{0x82A2C522L,18446744073709551609UL,0x432AE540L,18446744073709551607UL,0x82A2C522L,0x034DEAB7L,9UL,0x034DEAB7L,0x82A2C522L,18446744073709551607UL},{0xD57A820FL,18446744073709551609UL,0xD57A820FL,0xD6D420E6L,6UL,18446744073709551607UL,0x2AEC7EE5L,0xD6D420E6L,18446744073709551614UL,18446744073709551609UL},{1UL,0xD6D420E6L,18446744073709551615UL,0xAF15A877L,0x82A2C522L,0xAF15A877L,18446744073709551615UL,0xD6D420E6L,1UL,0UL},{0x2AEC7EE5L,1UL,0xD57A820FL,6UL,18446744073709551614UL,1UL,6UL,0x034DEAB7L,6UL,1UL},{1UL,6UL,0x432AE540L,6UL,1UL,18446744073709551609UL,9UL,18446744073709551607UL,1UL,0x034DEAB7L}},{{0xD57A820FL,0x034DEAB7L,18446744073709551614UL,0xAF15A877L,6UL,6UL,6UL,0xAF15A877L,18446744073709551614UL,0x034DEAB7L},{0x82A2C522L,0xAF15A877L,18446744073709551615UL,0xD6D420E6L,1UL,0UL,18446744073709551615UL,1UL,0x82A2C522L,1UL},{0x2AEC7EE5L,0UL,18446744073709551614UL,18446744073709551607UL,18446744073709551614UL,0UL,0x2AEC7EE5L,18446744073709551609UL,6UL,0UL},{0x82A2C522L,18446744073709551607UL,0x432AE540L,18446744073709551609UL,0x82A2C522L,6UL,9UL,6UL,0x82A2C522L,18446744073709551609UL},{0xD57A820FL,18446744073709551607UL,0xD57A820FL,0UL,6UL,18446744073709551609UL,0x2AEC7EE5L,0UL,18446744073709551614UL,18446744073709551607UL},{1UL,0UL,18446744073709551615UL,1UL,0x82A2C522L,1UL,18446744073709551615UL,0UL,1UL,0xD6D420E6L},{0x2AEC7EE5L,0xAF15A877L,0xD57A820FL,0x034DEAB7L,18446744073709551614UL,0xAF15A877L,6UL,6UL,6UL,0xAF15A877L}},{{1UL,0x034DEAB7L,0x432AE540L,0x034DEAB7L,1UL,18446744073709551607UL,9UL,18446744073709551609UL,1UL,6UL},{0xD57A820FL,6UL,18446744073709551614UL,1UL,6UL,0x034DEAB7L,6UL,1UL,18446744073709551614UL,6UL},{0x82A2C522L,1UL,18446744073709551615UL,0UL,1UL,0xD6D420E6L,18446744073709551615UL,0xAF15A877L,0x82A2C522L,0xAF15A877L},{0x2AEC7EE5L,0xD6D420E6L,18446744073709551614UL,18446744073709551609UL,18446744073709551614UL,0xD6D420E6L,0x2AEC7EE5L,18446744073709551607UL,6UL,0xD6D420E6L},{0x82A2C522L,18446744073709551609UL,0x432AE540L,18446744073709551607UL,0x82A2C522L,0x034DEAB7L,9UL,0x034DEAB7L,0x82A2C522L,18446744073709551607UL},{0xD57A820FL,18446744073709551609UL,0xD57A820FL,0xD6D420E6L,6UL,18446744073709551607UL,0x2AEC7EE5L,0xD6D420E6L,18446744073709551614UL,18446744073709551609UL},{1UL,0xD6D420E6L,18446744073709551615UL,0xAF15A877L,0x82A2C522L,0xAF15A877L,18446744073709551615UL,0xD6D420E6L,1UL,0UL}}};
        const int64_t l_774 = 0L;
        uint32_t *l_778 = &g_421;
        int32_t l_805[8][1];
        int64_t *l_864 = &g_744;
        int32_t l_892 = 0xDFFACA28L;
        int8_t l_897 = 9L;
        uint16_t l_1006 = 0xDB31L;
        uint64_t l_1011 = 0x9D6D07DF82E8E49ELL;
        int32_t l_1030 = 0x486C4A94L;
        union U2 *l_1041 = &g_1042;
        int i, j, k;
        for (i = 0; i < 8; i++)
        {
            for (j = 0; j < 1; j++)
                l_805[i][j] = 5L;
        }
        l_755 |= 1L;
        for (g_721.f0 = 0; (g_721.f0 <= 7); g_721.f0 += 1)
        { /* block id: 299 */
            int32_t l_765 = 9L;
            int8_t *l_766 = (void*)0;
            int32_t l_775[7] = {8L,(-6L),8L,8L,(-6L),8L,8L};
            int64_t *l_865[8] = {&g_744,&g_744,&g_744,&g_744,&g_744,&g_744,&g_744,&g_744};
            uint8_t l_904 = 0x3AL;
            uint64_t *l_917[8][4][1] = {{{(void*)0},{&g_573},{&g_573},{&g_573}},{{&g_573},{&g_573},{(void*)0},{&g_573}},{{&g_849[4][1]},{&g_849[6][4]},{&g_849[4][1]},{&g_849[6][4]}},{{&g_849[4][1]},{&g_573},{(void*)0},{&g_573}},{{&g_573},{&g_573},{&g_573},{&g_573}},{{(void*)0},{&g_573},{&g_849[4][1]},{&g_849[6][4]}},{{&g_849[4][1]},{&g_849[6][4]},{&g_849[4][1]},{&g_573}},{{(void*)0},{&g_573},{&g_573},{&g_573}}};
            int32_t *l_1001 = &g_957[2][2].f3;
            int i, j, k;
            l_756--;
            for (g_748 = 7; (g_748 >= 0); g_748 -= 1)
            { /* block id: 303 */
                int8_t **l_767[3][1];
                int8_t *l_770 = (void*)0;
                int32_t l_772 = 0x766960DCL;
                int32_t l_844[6][9][4] = {{{0x8B3D2B25L,0L,0xD532B725L,0x7D0B3BC5L},{0x34C738A0L,1L,(-5L),0x8F6F11E1L},{(-9L),1L,0L,1L},{0x2CC65643L,0x4D2BBC7FL,(-1L),0x3AF8E1B9L},{0x4DE36BD6L,8L,(-1L),(-4L)},{8L,0x45E7AEBAL,1L,1L},{8L,(-1L),0L,(-1L)},{0x9086FAC8L,(-9L),(-9L),0x9086FAC8L},{0L,1L,0xB9E7E803L,0x525D3850L}},{{0xD532B725L,(-5L),(-1L),(-4L)},{0x84C9155DL,0L,1L,(-4L)},{0x4DE36BD6L,(-5L),1L,0x525D3850L},{0x7F0856D2L,1L,0xC0AF981DL,0x9086FAC8L},{1L,(-9L),0x46E384BFL,(-1L)},{0x2CC65643L,(-1L),0xD532B725L,1L},{(-1L),0x45E7AEBAL,(-7L),(-4L)},{0x9F179C3CL,8L,(-1L),0x3AF8E1B9L},{0x45E7AEBAL,0x4D2BBC7FL,0L,1L}},{{(-5L),1L,3L,0x8F6F11E1L},{0x8F6F11E1L,1L,0L,0x7D0B3BC5L},{8L,0L,0x0189EB3BL,0L},{0x84C9155DL,0xF94C7072L,0x9F179C3CL,0x8D0BE911L},{(-1L),0x9086FAC8L,8L,0x525D3850L},{0x34C738A0L,(-1L),1L,3L},{0xB7389B77L,(-4L),3L,(-1L)},{1L,(-1L),8L,0x46E384BFL},{0L,0xF94C7072L,(-1L),0xF94C7072L}},{{0x08AEA7CAL,0L,0L,(-5L)},{0xF94C7072L,0x23D24B65L,8L,(-3L)},{1L,0xB7389B77L,3L,(-1L)},{1L,1L,8L,0L},{0xF94C7072L,(-1L),0L,1L},{0x08AEA7CAL,0xF4701C68L,(-1L),(-1L)},{0L,(-9L),8L,(-1L)},{1L,0x8F6F11E1L,3L,1L},{0xB7389B77L,5L,1L,(-3L)}},{{8L,(-1L),(-9L),0x46E384BFL},{0x7F0856D2L,(-9L),0L,0x7992603BL},{(-3L),(-4L),0L,0xC0AF981DL},{(-9L),(-1L),(-7L),0x3AF8E1B9L},{(-1L),0xB7389B77L,0L,(-9L)},{0x8C8EDBC9L,0x8F6F11E1L,(-1L),1L},{0xF94C7072L,1L,0x7F0856D2L,0xD532B725L},{0L,0x3B461CBCL,0x08AEA7CAL,(-1L)},{0x7F0856D2L,0x8C8EDBC9L,0L,0L}},{{0x9F179C3CL,0x46E384BFL,3L,3L},{3L,3L,1L,0x3AF8E1B9L},{1L,(-1L),8L,0L},{0x671F5F07L,0L,(-1L),8L},{(-3L),0L,0x7F0856D2L,0L},{0L,(-1L),1L,0x3AF8E1B9L},{1L,3L,5L,3L},{(-9L),0x46E384BFL,(-1L),0L},{(-9L),0x8C8EDBC9L,0xB9E7E803L,(-1L)}}};
                uint64_t l_910 = 0x520B533FE9AEC93BLL;
                const uint8_t l_922[7] = {0x8AL,0x8AL,0x8AL,0x8AL,0x8AL,0x8AL,0x8AL};
                uint32_t l_923 = 4294967295UL;
                int32_t **l_930 = &l_584[1];
                int i, j, k;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_767[i][j] = (void*)0;
                }
                l_775[0] ^= (0x5DABE4646880525FLL == (((((*l_571) = ((safe_add_func_int64_t_s_s((safe_rshift_func_int32_t_s_s(((((((l_772 = ((((void*)0 != &g_244[g_748][g_721.f0]) | (g_749 | (safe_sub_func_int8_t_s_s((0x06F8F1E1L <= l_765), (((l_769 = (g_768 = l_766)) == (g_771 = l_770)) > ((p_65 <= p_65) && p_65)))))) && g_244[g_748][g_721.f0])) >= 0x5D0D2263L) <= p_65) , (void*)0) != &l_575[0][1][0]) ^ p_65), g_244[g_748][g_721.f0])), p_65)) <= l_773[1][3][3])) <= g_211) , l_774) ^ l_773[1][3][3]));
                if ((safe_rshift_func_uint8_t_u_u(((&l_774 != (void*)0) >= (l_778 == &g_117)), 3)))
                { /* block id: 310 */
                    g_723.f3 = (p_65 || ((void*)0 == l_781));
                    for (g_458.f2 = 0; (g_458.f2 == 13); g_458.f2 = safe_add_func_int16_t_s_s(g_458.f2, 1))
                    { /* block id: 314 */
                        union U2 *l_791 = &g_792;
                        uint64_t ***l_793 = &l_504;
                        uint32_t *l_796 = (void*)0;
                        int8_t *l_797 = &g_51[2][1][2];
                        g_406[4].f3 = p_65;
                        l_772 = ((((safe_sub_func_int16_t_s_s((g_589.f2 = g_244[0][4]), ((!g_110) ^ l_775[0]))) & (((safe_unary_minus_func_int64_t_s(((void*)0 == l_791))) , (void*)0) != l_793)) != (0xCCE772B2773B9D18LL | 0UL)) & 0x5BBF5ABBL);
                        g_723.f3 |= (safe_div_func_int64_t_s_s((((((void*)0 != l_796) | (g_110 == 0xFB7FL)) , &g_51[4][2][2]) == l_797), (safe_mod_func_int8_t_s_s((g_749 = (safe_mod_func_int16_t_s_s((((0xB1L <= ((((*l_797) |= (safe_mod_func_int8_t_s_s((1UL <= (+((0xDAL & 0x20L) , (-1L)))), 1UL))) > 250UL) == g_244[g_748][g_721.f0])) & 0L) | 4UL), p_65))), g_41))));
                    }
                }
                else
                { /* block id: 322 */
                    uint64_t l_807 = 1UL;
                    int16_t * const *l_812 = &l_575[0][1][0];
                    int32_t l_845 = (-5L);
                    int32_t l_846 = (-1L);
                    int32_t l_848 = 0L;
                    int64_t *l_863[5] = {&l_847,&l_847,&l_847,&l_847,&l_847};
                    int i;
                    l_805[1][0] = (g_90 ^= 0x8375E350L);
                    if ((~l_807))
                    { /* block id: 325 */
                        return p_65;
                    }
                    else
                    { /* block id: 327 */
                        int16_t * const *l_808 = &l_575[2][0][1];
                        int16_t * const **l_809 = (void*)0;
                        int16_t * const **l_810 = (void*)0;
                        int16_t * const **l_811 = &l_808;
                        uint16_t *l_815 = (void*)0;
                        uint16_t *l_816 = &g_244[g_748][g_721.f0];
                        int32_t l_843 = 0L;
                        l_812 = ((*l_811) = l_808);
                        g_458.f3 = (safe_mod_func_uint16_t_u_u(((*l_816)--), ((safe_sub_func_uint16_t_u_u((safe_add_func_int32_t_s_s(l_775[0], p_65)), (safe_mul_func_int64_t_s_s((safe_rshift_func_int64_t_s_u(p_65, 28)), ((*g_249) = (safe_lshift_func_uint8_t_u_s((((safe_lshift_func_int32_t_s_u((safe_add_func_uint32_t_u_u((safe_mod_func_int64_t_s_s((*g_249), ((safe_add_func_uint16_t_u_u((safe_rshift_func_uint32_t_u_s(((*l_778) = (l_774 && (safe_lshift_func_int8_t_s_u(((l_843 |= ((l_772 = l_772) && ((l_772 | 0xE9L) > (safe_add_func_uint8_t_u_u(0x7EL, p_65))))) > l_807), p_65)))), 22)), g_184)) & l_844[3][3][1]))), g_81)), 4)) | p_65) , g_421), 3))))))) & p_65)));
                        l_765 |= 0x992F8204L;
                    }
                    g_849[4][1]++;
                    if (((l_805[1][0] <= l_773[1][3][3]) , 0x3E912BB9L))
                    { /* block id: 339 */
                        int32_t l_870 = 0x5C6F17E9L;
                        if (p_65)
                            break;
                        l_870 = (safe_mul_func_int16_t_s_s((safe_sub_func_int32_t_s_s((safe_lshift_func_uint64_t_u_s(((((g_117 || g_744) , ((0x52L & (+((safe_lshift_func_int64_t_s_u(l_772, (safe_div_func_uint16_t_u_u((((l_863[3] != (l_865[1] = l_864)) == ((safe_mul_func_int16_t_s_s(l_775[0], (safe_mod_func_uint64_t_u_u((l_870 ^ ((safe_sub_func_int32_t_s_s(l_774, g_244[g_748][g_721.f0])) , p_65)), 0xBDD196683691E9CALL)))) , 1L)) , g_90), l_773[1][4][9])))) , g_550))) > l_775[0])) , p_65) | 18446744073709551615UL), p_65)), p_65)), g_749));
                        l_775[2] &= (((safe_lshift_func_int64_t_s_s((((*l_778) = l_765) & (safe_lshift_func_uint64_t_u_u((safe_mod_func_int16_t_s_s(((safe_rshift_func_int64_t_s_u((safe_mod_func_uint16_t_u_u(g_51[4][2][2], (safe_lshift_func_uint64_t_u_u((p_65 >= (safe_mod_func_int16_t_s_s((g_54 || (safe_lshift_func_int16_t_s_u((safe_add_func_uint64_t_u_u((0x0DL | ((l_805[1][0] = p_65) >= p_65)), l_846)), 3))), g_51[3][0][0]))), g_679)))), g_550)) | 0xDFF4L), 0x4F2AL)), 11))), 48)) || l_805[1][0]) , l_774);
                    }
                    else
                    { /* block id: 346 */
                        int32_t **l_891 = &g_89;
                        (*l_891) = (void*)0;
                    }
                }
                if ((l_892 != (g_749 = ((safe_rshift_func_int8_t_s_s((~p_65), 4)) < 0xBD077CC9B73A939ELL))))
                { /* block id: 351 */
                    int16_t l_896 = 0x6336L;
                    int32_t l_898 = 0xFEC92BFFL;
                    int32_t l_899 = 0x37962E31L;
                    int32_t **l_907 = &l_584[1];
                    g_901++;
                    ++l_904;
                    (*l_907) = &g_90;
                }
                else
                { /* block id: 355 */
                    uint8_t l_908 = 0UL;
                    uint64_t **l_913 = (void*)0;
                    uint64_t *l_916[1][6][9] = {{{(void*)0,&l_910,&g_573,&l_910,(void*)0,&g_849[4][1],&g_573,&g_849[4][0],&l_910},{(void*)0,&g_573,&g_849[2][0],&g_849[4][1],&g_184,&g_573,(void*)0,&g_849[4][1],(void*)0},{&g_849[4][1],&g_573,&l_910,&l_910,&g_573,&g_849[4][1],&l_910,(void*)0,&g_573},{&g_573,&g_573,&g_849[4][1],&g_184,(void*)0,&g_849[4][1],&l_910,&l_910,&l_910},{&l_910,&g_573,&g_849[4][1],&g_849[4][0],&g_849[4][1],&g_573,&l_910,&l_910,&g_849[4][1]},{&g_573,&l_910,&g_849[4][1],&l_910,&g_849[4][0],&g_849[2][0],(void*)0,&g_573,&g_849[4][1]}}};
                    uint64_t **l_915[7][7][1] = {{{&l_916[0][5][2]},{(void*)0},{(void*)0},{&l_916[0][4][4]},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]}},{{(void*)0},{&l_916[0][4][4]},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]}},{{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{&l_916[0][4][4]},{(void*)0}},{{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{(void*)0}},{{&l_916[0][4][4]},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{&l_916[0][4][4]}},{{(void*)0},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]}},{{(void*)0},{&l_916[0][4][4]},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]},{(void*)0},{&l_916[0][4][4]}}};
                    int32_t l_925 = 7L;
                    int64_t ***** const l_926 = &l_596;
                    int i, j, k;
                    for (g_458.f3 = 0; (g_458.f3 <= 1); g_458.f3 += 1)
                    { /* block id: 358 */
                        l_908 = 8L;
                        l_765 |= p_65;
                    }
                    l_925 = (+(((l_772 = l_910) == (((0x2C4773CFB02DFF38LL <= (l_908 == ((l_844[2][8][1] , ((g_914 = &l_910) != (l_917[4][2][0] = &l_910))) < 0UL))) != (safe_sub_func_int8_t_s_s(((safe_add_func_int64_t_s_s((l_805[6][0] , ((*l_864) = (l_765 && l_922[3]))), 0xC07A7F2851536A25LL)) < p_65), l_923))) <= l_924[0])) != p_65));
                    g_927 = l_926;
                }
                (*l_930) = &l_805[1][0];
            }
            if ((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint32_t_u_s((&l_904 != &l_904), l_935)), 8)))
            { /* block id: 371 */
                uint64_t l_936 = 18446744073709551615UL;
                union U2 *l_944[9][8][3] = {{{&g_960,&g_967[7],&g_946[3][2]},{&g_990,&g_982,&g_946[3][2]},{(void*)0,&g_950,&g_945},{&g_959[1],&g_965,&g_991},{(void*)0,&g_977,(void*)0},{&g_971[3],&g_990,&g_986},{&g_950,&g_957[2][2],&g_982},{&g_976,&g_968,&g_976}},{{&g_958[0][1][3],&g_976,(void*)0},{&g_982,&g_987,&g_966},{&g_961,&g_948,&g_959[1]},{&g_984[0],&g_958[0][1][3],&g_950},{&g_961,&g_964[1],&g_988},{&g_982,&g_972,&g_978},{&g_958[0][1][3],(void*)0,&g_970[7]},{&g_976,&g_980,(void*)0}},{{&g_950,(void*)0,&g_992},{&g_971[3],(void*)0,&g_979},{(void*)0,&g_989[0][2][1],&g_967[7]},{&g_959[1],&g_991,&g_952},{(void*)0,&g_992,&g_984[0]},{&g_990,&g_992,&g_969},{&g_960,&g_991,&g_951},{(void*)0,&g_989[0][2][1],&g_980}},{{&g_987,(void*)0,(void*)0},{&g_953,(void*)0,&g_989[0][2][1]},{&g_965,&g_980,&g_972},{(void*)0,(void*)0,&g_949[2]},{&g_986,&g_972,(void*)0},{&g_948,&g_964[1],&g_953},{(void*)0,&g_958[0][1][3],&g_975[1][2]},{&g_966,&g_948,&g_953}},{{(void*)0,&g_987,(void*)0},{&g_978,&g_976,&g_949[2]},{(void*)0,&g_968,&g_972},{(void*)0,&g_957[2][2],&g_989[0][2][1]},{&g_945,&g_990,(void*)0},{&g_949[2],&g_977,&g_980},{&g_952,&g_965,&g_951},{&g_954,&g_950,&g_969}},{{&g_955[0][2][2],&g_982,&g_984[0]},{&g_955[0][2][2],&g_967[7],&g_952},{&g_954,&g_949[2],&g_967[7]},{&g_952,&g_978,&g_979},{&g_949[2],(void*)0,&g_992},{&g_945,&g_988,(void*)0},{(void*)0,&g_970[7],&g_970[7]},{(void*)0,&g_947,&g_978}},{{(void*)0,&g_969,&g_983},{&g_968,&g_992,&g_991},{&g_961,&g_971[3],&g_953},{&g_952,&g_992,&g_961},{&g_989[0][2][1],&g_969,&g_967[7]},{&g_980,(void*)0,(void*)0},{&g_972,&g_963,&g_975[1][2]},{&g_960,&g_983,&g_980}},{{&g_946[3][2],&g_956[0],&g_984[0]},{&g_981,(void*)0,&g_986},{&g_969,&g_990,(void*)0},{&g_954,(void*)0,&g_988},{&g_985,&g_975[1][2],&g_988},{&g_971[3],&g_991,(void*)0},{&g_953,&g_960,&g_986},{&g_982,(void*)0,&g_984[0]}},{{&g_964[1],&g_985,&g_980},{&g_991,&g_950,&g_975[1][2]},{(void*)0,&g_962,(void*)0},{&g_951,(void*)0,&g_967[7]},{&g_975[1][2],&g_981,&g_961},{&g_955[0][2][2],&g_989[0][2][1],&g_953},{&g_977,&g_951,&g_991},{&g_955[0][2][2],&g_959[1],&g_983}}};
                int32_t *l_999 = &g_991.f3;
                int32_t l_1007 = 0x29D98873L;
                int i, j, k;
                ++l_936;
                if ((((((safe_add_func_int16_t_s_s(p_65, ((void*)0 != &l_864))) && (((safe_rshift_func_int16_t_s_s(((safe_unary_minus_func_int16_t_s(((l_765 = (l_775[0] = (((*l_514) = l_944[0][1][0]) != ((((safe_sub_func_uint8_t_u_u((safe_add_func_uint16_t_u_u((l_936 , (((void*)0 != &l_897) == ((*l_864) |= 0x83A836A7599BBC85LL))), 0x233EL)), 0x72L)) < 0xA4L) >= l_904) , g_997)))) != p_65))) && p_65), 0)) | 1UL) > l_936)) < 9UL) != p_65) || p_65))
                { /* block id: 377 */
                    int32_t **l_1000[9] = {&g_89,(void*)0,&g_89,&g_89,(void*)0,&g_89,&g_89,(void*)0,&g_89};
                    int i;
                    l_1001 = (l_999 = &l_805[1][0]);
                    (*l_999) &= (safe_lshift_func_uint64_t_u_s((safe_mod_func_uint16_t_u_u(((g_977.f0 , l_1006) > 0x8CL), 0xC366L)), l_1006));
                    if (p_65)
                        continue;
                }
                else
                { /* block id: 382 */
                    uint8_t l_1009 = 3UL;
                    if (p_65)
                    { /* block id: 383 */
                        if (l_892)
                            break;
                        if (p_65)
                            break;
                    }
                    else
                    { /* block id: 386 */
                        uint16_t l_1008 = 0x248FL;
                        int32_t l_1010 = (-8L);
                        (*l_1001) = (g_952.f0 , (l_1007 ^= p_65));
                        l_1007 &= (l_805[5][0] = (l_1008 ^= p_65));
                        l_775[0] ^= p_65;
                        l_1010 |= (l_1009 |= p_65);
                    }
                }
                ++l_1011;
            }
            else
            { /* block id: 398 */
                uint16_t *l_1024 = &g_244[2][4];
                const int32_t l_1029 = 0x895A595FL;
                int32_t l_1035[1];
                union U2 *l_1038 = &g_1039[6];
                int8_t *l_1040[1];
                int64_t ****l_1047 = &g_929;
                int i;
                for (i = 0; i < 1; i++)
                    l_1035[i] = 0xAF8F5EB6L;
                for (i = 0; i < 1; i++)
                    l_1040[i] = (void*)0;
                l_1030 |= ((((g_961.f3 = ((g_117 = 0x111F9DD6L) == (safe_mul_func_int64_t_s_s((p_65 , (p_65 , (safe_mod_func_int8_t_s_s((g_971[3].f0 <= (safe_lshift_func_int64_t_s_u((l_805[1][0] ^= ((safe_add_func_uint16_t_u_u(((*l_1024) = ((safe_mul_func_int64_t_s_s(((*l_1001) = (-8L)), p_65)) & 0x31L)), (g_607.f2 = g_946[3][2].f0))) < ((*l_571)++))), 1))), ((safe_mul_func_int32_t_s_s((l_773[1][3][3] <= 1UL), p_65)) || l_1029))))), p_65)))) , 0x73EA3B35BDD9A21ELL) & p_65) || p_65);
                (*l_1001) = p_65;
                l_1030 ^= (l_773[1][3][3] | ((safe_div_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((l_1029 || (l_1035[0] = l_904)) < (((g_1036 != ((((((*l_514) = l_1038) == ((g_51[4][2][2] = (l_805[5][0] = l_775[0])) , l_1041)) , (safe_mul_func_uint16_t_u_u(((((void*)0 == l_1045[0]) & g_961.f3) & 0L), 5UL))) && (-1L)) , (*l_781))) , l_1047) != (void*)0)), p_65)), p_65)) , p_65));
            }
        }
    }
    else
    { /* block id: 415 */
        const uint64_t **l_1058 = (void*)0;
        const uint64_t ***l_1057 = &l_1058;
        const uint64_t ****l_1059 = &l_1057;
        int32_t l_1060 = 0xC4566B63L;
        uint16_t *l_1061 = &g_901;
        int32_t **l_1071 = &l_584[0];
        uint32_t *l_1072 = &g_1039[6].f0;
        (**l_1071) ^= (safe_sub_func_int64_t_s_s((((*l_1072) = (((safe_div_func_uint8_t_u_u(((*l_571) ^= (((g_589.f2 = (((g_986.f0 != (g_1054 == ((*l_1059) = l_1057))) <= ((*l_1061) ^= (g_244[4][0] = l_1060))) > (((((((l_1060 <= ((((void*)0 != (*l_782)) || ((safe_mod_func_int16_t_s_s((!(safe_lshift_func_uint32_t_u_u((p_65 && ((((*g_768) = (safe_mod_func_int32_t_s_s((l_1069 , p_65), p_65))) | 1UL) == p_65)), 16))), p_65)) <= p_65)) ^ p_65)) == 0UL) == 65527UL) ^ 0x00CFEB64L) || g_1070) | p_65) && 1L))) && (-4L)) , g_964[1].f0)), l_1060)) , l_1071) != &g_633)) , p_65), p_65));
    }
    --l_1074;
    g_90 |= (l_1090 = ((((l_1089 = (g_901 = (safe_mod_func_int16_t_s_s((l_1079[1] = g_602.f0), (l_1088 = (0x0AL || (safe_lshift_func_int32_t_s_s((l_1085 ^= (0x94L ^ (p_65 != (~(safe_div_func_int16_t_s_s(g_974.f0, p_65)))))), l_1086)))))))) > (g_955[0][2][2].f0 || g_966.f0)) || (-1L)) < p_65));
    return p_65;
}


/* ------------------------------------------ */
/* 
 * reads : g_81 g_54 g_41 g_98 g_51 g_117 g_110 g_184 g_211 g_10 g_90 g_176 g_248 g_249 g_350 g_244 g_400 g_420 g_421 g_89 g_1342 g_2305
 * writes: g_81 g_89 g_110 g_117 g_176 g_98 g_184 g_90 g_211 g_244 g_248 g_336 g_400 g_421
 */
static int32_t * func_69(int32_t  p_70, uint32_t  p_71, int32_t * p_72, int32_t * p_73, int32_t * p_74)
{ /* block id: 12 */
    int32_t *l_88 = (void*)0;
    int32_t l_119[3][5][7] = {{{0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L,1L},{0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL},{0xF43875C6L,0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L},{2L,0xFE6C1E6BL,2L,0xFE6C1E6BL,2L,0xFE6C1E6BL,2L},{0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L,1L}},{{0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL},{0xF43875C6L,0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L},{2L,0xFE6C1E6BL,2L,0xFE6C1E6BL,2L,0xFE6C1E6BL,2L},{0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L,1L},{0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL}},{{0xF43875C6L,0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L},{2L,0xFE6C1E6BL,2L,0xFE6C1E6BL,2L,0xFE6C1E6BL,2L},{0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L,1L},{0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL,0xFE6C1E6BL,0x40D7AA6BL},{0xF43875C6L,0xF43875C6L,1L,1L,0xF43875C6L,0xF43875C6L,1L}}};
    uint32_t l_124 = 0UL;
    int8_t l_155 = 0x62L;
    uint64_t l_230[7] = {0xB93B745A2F1ED599LL,0x4FF0672DA4C94F83LL,0xB93B745A2F1ED599LL,0xB93B745A2F1ED599LL,0xB93B745A2F1ED599LL,0x29CE55DAC31F8A23LL,0x29CE55DAC31F8A23LL};
    int64_t *l_246 = &g_176;
    int64_t **l_245 = &l_246;
    int32_t l_268 = 0x3925E94DL;
    uint32_t *l_308[10][5][5] = {{{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117,&g_117,(void*)0}},{{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117}},{{&g_117,&g_117,&g_117,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117}},{{(void*)0,&g_117,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117}},{{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,&g_117,&g_117}},{{&g_117,&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117,&g_117}},{{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,(void*)0}},{{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117}},{{&g_117,&g_117,(void*)0,&g_117,&g_117},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117,&g_117,&g_117}},{{&g_117,&g_117,(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117,&g_117}}};
    uint32_t **l_307[1][5][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}}};
    int16_t *l_328[1];
    uint32_t ***l_358 = &l_307[0][2][1];
    const uint8_t *l_361[2][7][6] = {{{&g_110,&g_110,(void*)0,(void*)0,&g_110,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110,&g_110},{&g_110,(void*)0,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,(void*)0,&g_110,&g_110,(void*)0},{&g_110,&g_110,&g_110,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,(void*)0,&g_110}},{{(void*)0,&g_110,&g_110,(void*)0,&g_110,&g_110},{&g_110,(void*)0,&g_110,&g_110,(void*)0,(void*)0},{&g_110,(void*)0,(void*)0,&g_110,&g_110,&g_110},{&g_110,(void*)0,&g_110,&g_110,(void*)0,&g_110},{(void*)0,(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,(void*)0,&g_110},{&g_110,&g_110,(void*)0,&g_110,&g_110,&g_110}}};
    const uint8_t **l_360 = &l_361[1][3][0];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_328[i] = &g_10[4];
    for (g_81 = 7; (g_81 <= (-27)); --g_81)
    { /* block id: 15 */
        int16_t *l_97[10] = {&g_98,&g_98,&g_98,&g_98,&g_98,&g_98,&g_98,&g_98,&g_98,&g_98};
        int32_t l_99 = (-1L);
        int32_t l_100 = 0xB8438CF8L;
        uint8_t *l_109 = &g_110;
        int32_t l_113 = 1L;
        uint32_t *l_116[8][7][4] = {{{&g_117,&g_117,(void*)0,&g_117},{&g_117,(void*)0,&g_117,&g_117},{(void*)0,&g_117,(void*)0,&g_117},{&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,(void*)0,&g_117},{&g_117,&g_117,&g_117,&g_117},{&g_117,(void*)0,&g_117,&g_117}},{{(void*)0,(void*)0,&g_117,(void*)0},{&g_117,(void*)0,&g_117,(void*)0},{(void*)0,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,(void*)0},{&g_117,(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,(void*)0}},{{&g_117,&g_117,(void*)0,&g_117},{(void*)0,&g_117,&g_117,&g_117},{&g_117,&g_117,(void*)0,(void*)0},{&g_117,&g_117,&g_117,&g_117},{(void*)0,(void*)0,&g_117,&g_117},{&g_117,(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117}},{{&g_117,&g_117,&g_117,&g_117},{&g_117,(void*)0,&g_117,&g_117},{(void*)0,(void*)0,&g_117,&g_117},{(void*)0,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,(void*)0}},{{&g_117,&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117,&g_117},{&g_117,(void*)0,&g_117,(void*)0},{&g_117,&g_117,(void*)0,(void*)0},{&g_117,&g_117,&g_117,(void*)0},{&g_117,(void*)0,&g_117,(void*)0},{&g_117,(void*)0,&g_117,&g_117}},{{&g_117,(void*)0,(void*)0,&g_117},{&g_117,(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117},{&g_117,(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117}},{{&g_117,(void*)0,&g_117,&g_117},{(void*)0,&g_117,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117},{&g_117,(void*)0,&g_117,(void*)0},{&g_117,&g_117,&g_117,(void*)0},{&g_117,(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117,(void*)0}},{{(void*)0,&g_117,&g_117,&g_117},{&g_117,(void*)0,(void*)0,&g_117},{&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,(void*)0,&g_117},{&g_117,(void*)0,&g_117,&g_117},{&g_117,(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117,&g_117}}};
        int32_t l_118[10][8][3] = {{{0xF703B84DL,(-5L),0xC33ADB54L},{0xB5B2332FL,0x5F0F443CL,9L},{0xF703B84DL,0xA18A5C64L,0x8026BCB3L},{0x5D0160B5L,5L,5L},{(-9L),0xC33ADB54L,(-1L)},{0L,0xB5B2332FL,1L},{0L,0xEE040EEAL,0xED2767F9L},{0xCCF6B01AL,0x2C4F7295L,(-5L)}},{{0xF6FD0247L,0xEE040EEAL,0L},{0x46833E31L,0xB5B2332FL,0x5D0160B5L},{0xC33ADB54L,0xC33ADB54L,0xEE040EEAL},{(-5L),5L,0x1CB9B5B5L},{(-5L),0xA18A5C64L,2L},{0x1CB9B5B5L,0x5F0F443CL,0x46833E31L},{(-1L),(-5L),2L},{0xD27CF1A4L,0xDA46A136L,0x1CB9B5B5L}},{{0xEE040EEAL,0xF703B84DL,0xEE040EEAL},{0L,(-5L),0x5D0160B5L},{0x31594A51L,5L,0L},{(-5L),0x46833E31L,(-5L)},{(-7L),0L,0xED2767F9L},{(-5L),0xA7371980L,1L},{0x31594A51L,(-1L),(-1L)},{0L,(-5L),5L}},{{0xEE040EEAL,(-7L),0x8026BCB3L},{0xD27CF1A4L,0L,9L},{(-1L),0L,0xC33ADB54L},{0x1CB9B5B5L,0L,0x5F0F443CL},{(-5L),(-7L),0x31594A51L},{(-5L),(-5L),0L},{0xC33ADB54L,(-1L),0xF6FD0247L},{0x46833E31L,0xA7371980L,0x4458F597L}},{{0xF6FD0247L,0L,(-5L)},{0xCCF6B01AL,0x46833E31L,0x4458F597L},{0L,5L,0xF6FD0247L},{0L,(-5L),0L},{(-9L),0xF703B84DL,0x31594A51L},{0x5D0160B5L,0xDA46A136L,0x5F0F443CL},{0xF703B84DL,(-5L),0xC33ADB54L},{0xB5B2332FL,0x5F0F443CL,9L}},{{0xF703B84DL,0xA18A5C64L,0x8026BCB3L},{0x5D0160B5L,5L,5L},{(-9L),0xC33ADB54L,(-1L)},{0L,0xB5B2332FL,1L},{0L,0xEE040EEAL,0xED2767F9L},{0xCCF6B01AL,0x2C4F7295L,(-5L)},{0xF6FD0247L,0xEE040EEAL,0L},{0x46833E31L,0xB5B2332FL,0x5D0160B5L}},{{0xC33ADB54L,0xC33ADB54L,0xEE040EEAL},{(-5L),5L,0x1CB9B5B5L},{(-5L),0xA18A5C64L,2L},{0x1CB9B5B5L,0x5F0F443CL,0x46833E31L},{(-1L),(-5L),2L},{0xD27CF1A4L,0xDA46A136L,0x1CB9B5B5L},{0xEE040EEAL,0xF703B84DL,0xEE040EEAL},{0L,(-5L),0x5D0160B5L}},{{0x31594A51L,5L,0L},{(-5L),0x46833E31L,(-5L)},{(-7L),0L,0xED2767F9L},{(-5L),0xA7371980L,1L},{0x31594A51L,(-1L),0xC33ADB54L},{0xA7371980L,0xCCF6B01AL,(-5L)},{(-9L),(-1L),(-5L)},{9L,0L,0x1CB9B5B5L}},{{0x9E5C5CB2L,2L,(-1L)},{0x5D0160B5L,0L,0xD27CF1A4L},{(-7L),(-1L),0xEE040EEAL},{0xCCF6B01AL,0xCCF6B01AL,0L},{(-1L),0xC33ADB54L,0x31594A51L},{0xB5B2332FL,1L,(-5L)},{0x31594A51L,0L,(-7L)},{0x971DF810L,0xB5B2332FL,(-5L)}},{{0xED2767F9L,0L,0x31594A51L},{0L,0x5F0F443CL,0L},{0xA18A5C64L,0L,0xEE040EEAL},{0L,0x2C4F7295L,0xD27CF1A4L},{0L,(-7L),(-1L)},{5L,0xD27CF1A4L,0x1CB9B5B5L},{0L,0x8026BCB3L,(-5L)},{0L,(-5L),(-5L)}}};
        uint8_t l_197[2];
        uint32_t l_276 = 0x7B0658B6L;
        const uint8_t **l_362 = (void*)0;
        int32_t **l_391 = &g_89;
        int32_t ***l_390 = &l_391;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_197[i] = 250UL;
        for (p_70 = (-3); (p_70 >= (-20)); p_70--)
        { /* block id: 18 */
            int8_t l_87[3];
            int i;
            for (i = 0; i < 3; i++)
                l_87[i] = (-10L);
            l_87[1] |= (*p_72);
            g_89 = l_88;
        }
        if ((safe_div_func_uint32_t_u_u((l_119[1][2][1] ^= (((safe_mod_func_uint64_t_u_u((safe_mod_func_int16_t_s_s((l_99 = p_71), 0x2BEBL)), l_100)) <= (safe_div_func_int32_t_s_s((l_118[7][6][0] ^= (((safe_mod_func_uint32_t_u_u((safe_sub_func_uint8_t_u_u((p_70 < (safe_mod_func_uint16_t_u_u(((g_41 , (p_71 | ((*l_109) = p_70))) <= ((safe_div_func_int32_t_s_s((l_113 = (*p_72)), (g_117 = (((safe_mul_func_uint32_t_u_u(g_54, 0x75B4C718L)) & 0x3B64L) && p_71)))) | g_98)), 0x3E5BL))), 252UL)), l_100)) | g_51[2][1][0]) & g_51[1][1][1])), 0x6C9CC5FAL))) == g_54)), p_71)))
        { /* block id: 28 */
            int32_t *l_120 = &l_118[7][4][1];
            int32_t *l_121 = &g_90;
            int32_t *l_122 = &l_118[4][6][0];
            int32_t *l_123[6];
            int i;
            for (i = 0; i < 6; i++)
                l_123[i] = &l_119[1][2][1];
            l_124++;
        }
        else
        { /* block id: 30 */
            uint8_t *l_146[5][9][5] = {{{&g_110,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110}},{{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110}},{{&g_110,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,(void*)0,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110}},{{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110}},{{(void*)0,&g_110,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110,&g_110},{(void*)0,&g_110,&g_110,&g_110,&g_110}}};
            const int32_t l_154 = 0xE4956776L;
            const int16_t *l_156 = &g_10[3];
            uint32_t *l_270 = &g_117;
            uint32_t l_277 = 4294967295UL;
            uint16_t l_291 = 0x6971L;
            int32_t l_338 = (-1L);
            int i, j, k;
            if (((safe_lshift_func_uint32_t_u_u((~(l_118[6][5][0] == p_70)), (((safe_mul_func_int64_t_s_s((((((safe_rshift_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(((safe_div_func_int32_t_s_s(((0UL != (safe_div_func_int64_t_s_s((0xF1L || ((safe_sub_func_int64_t_s_s(((&g_10[3] == &g_10[3]) != (((safe_lshift_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(((void*)0 == l_146[4][5][1]), (safe_add_func_uint64_t_u_u(((~((safe_sub_func_uint8_t_u_u((safe_mod_func_int64_t_s_s(((-8L) != l_99), l_99)), p_70)) && g_41)) , p_71), g_98)))), 3)) && 0xA195L) <= g_51[2][3][0])), 0x728D9C3D7FAD0BDBLL)) == l_154)), p_71))) >= 0xD48F7C91L), p_70)) != p_70), l_100)), p_71)) && 0x67B20451B912C020LL) || 0x15L) && 0xFBL) != l_155), 18446744073709551615UL)) , &g_10[1]) == (void*)0))) , (-10L)))
            { /* block id: 31 */
                int32_t *l_157 = &l_118[7][3][0];
                int64_t *l_175 = &g_176;
                (*l_157) = (l_156 == (void*)0);
                (*l_157) = ((+((*l_175) = ((((safe_rshift_func_uint64_t_u_u(((safe_div_func_uint32_t_u_u((p_70 , (safe_add_func_uint16_t_u_u(65529UL, g_51[4][2][2]))), ((safe_mod_func_uint32_t_u_u((p_71 = (safe_mul_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(0UL, l_100)), p_71))), (g_117--))) ^ (safe_add_func_int64_t_s_s((l_118[7][6][0] , g_54), ((g_41 <= p_70) | p_70)))))) , l_100), 29)) , p_70) ^ g_81) & g_110))) , 1L);
                if ((*l_157))
                { /* block id: 37 */
                    uint32_t l_195 = 4294967292UL;
                    int32_t *l_202 = &l_119[1][2][1];
                    for (g_98 = (-16); (g_98 >= 15); g_98 = safe_add_func_uint64_t_u_u(g_98, 6))
                    { /* block id: 40 */
                        int64_t l_181 = 0xA6F6173B2678477ELL;
                        uint64_t *l_182 = (void*)0;
                        uint64_t *l_183[1][6][2];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 6; j++)
                            {
                                for (k = 0; k < 2; k++)
                                    l_183[i][j][k] = &g_184;
                            }
                        }
                        g_90 = (safe_mod_func_int64_t_s_s(l_181, (g_184--)));
                        (*l_157) = (*p_73);
                        (*l_157) ^= (safe_sub_func_int32_t_s_s(0x6C249806L, (*p_72)));
                    }
                    (*l_202) ^= (safe_lshift_func_uint64_t_u_u(((*l_157) , (((*p_73) & (((++g_117) , (*p_74)) == (safe_mod_func_uint64_t_u_u((((l_195 , ((l_118[3][3][1] >= (~(((void*)0 == &p_70) , (l_197[0] & (safe_lshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_u(0x5EF2L, 8)), 7)))))) || g_81)) && 0x386D8F9DL) >= 1UL), p_71)))) && l_195)), g_184));
                    for (l_113 = 5; (l_113 <= 22); ++l_113)
                    { /* block id: 50 */
                        (*l_202) = (safe_lshift_func_int8_t_s_s(p_71, 1));
                        if ((*p_72))
                            continue;
                    }
                }
                else
                { /* block id: 54 */
                    int32_t *l_207 = &l_118[8][1][2];
                    int32_t *l_208 = &l_119[1][2][1];
                    int32_t *l_209 = (void*)0;
                    int32_t *l_210[2][8] = {{&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1]},{&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1],&l_118[3][1][1]}};
                    int i, j;
                    g_211++;
                    if ((g_41 | (safe_rshift_func_uint64_t_u_s((safe_mod_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u(l_154, ((l_113 = (p_70 || (safe_lshift_func_uint8_t_u_s(p_70, (safe_unary_minus_func_uint64_t_u((1L < (safe_mod_func_int64_t_s_s(((safe_unary_minus_func_int64_t_s(((*l_207) = 0x2FEA0E9085B8020ALL))) >= (6L ^ ((((safe_rshift_func_uint16_t_u_u((g_110 < (l_154 > 0x3EE88BD6L)), 11)) > 0x91CA70F6C1F0966BLL) , (void*)0) != (void*)0))), g_211))))))))) , 65535UL))), p_71)), g_10[3]))))
                    { /* block id: 58 */
                        --l_230[6];
                    }
                    else
                    { /* block id: 60 */
                        uint32_t l_240[9][8] = {{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL},{0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL,0xD80A4BD0L,0xF737D9CEL}};
                        uint16_t *l_243 = &g_244[0][4];
                        int64_t ***l_247 = (void*)0;
                        int i, j;
                        (*l_207) = (((((safe_mul_func_uint64_t_u_u((safe_div_func_int16_t_s_s((safe_unary_minus_func_int8_t_s(0xF3L)), g_90)), p_71)) ^ (l_240[2][4] <= (p_70 || (((safe_rshift_func_int32_t_s_u((((*l_243) = 0x2B50L) || (g_10[3] | (g_51[3][2][1] , p_70))), 5)) != p_70) , 0x5DD0340F112F4C25LL)))) || p_71) & (*p_72)) | g_117);
                        g_248 = l_245;
                    }
                }
            }
            else
            { /* block id: 66 */
                const int32_t *l_251 = (void*)0;
                const int32_t **l_250 = &l_251;
                uint32_t **l_269 = (void*)0;
                uint32_t **l_271 = &l_116[0][6][3];
                int32_t l_278 = 0L;
                int32_t l_279[10];
                int i;
                for (i = 0; i < 10; i++)
                    l_279[i] = 0xC8B023FBL;
                (*l_250) = &l_154;
                l_279[4] ^= (l_278 = ((((((**l_250) ^ (safe_rshift_func_uint32_t_u_u((((safe_mod_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s((safe_sub_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u(p_71, 0)) || (safe_sub_func_int64_t_s_s((l_118[4][0][0] & ((((safe_rshift_func_int64_t_s_s(((safe_mul_func_uint32_t_u_u((l_268 < (*l_251)), ((l_270 = &g_117) != ((*l_271) = l_88)))) , ((safe_mul_func_uint8_t_u_u(g_176, (safe_sub_func_uint64_t_u_u(g_211, 1UL)))) || (**l_250))), (**g_248))) || (**l_250)) ^ 5UL) , l_154)), p_70))) >= 0x008311E2L), g_51[4][2][1])), (*l_251))), g_10[2])) , l_276) >= l_277), p_70))) > (*l_251)) && g_176) , 0x08477F48CB3587C0LL) > 0x1E7A8C1E0F0D1CF8LL));
            }
            for (g_211 = 0; (g_211 <= 3); g_211 += 1)
            { /* block id: 75 */
                int32_t l_290 = 0xD2D3AF8AL;
                int32_t l_298[1][1];
                int32_t *l_299 = &l_99;
                int32_t *l_300 = &l_118[7][6][0];
                int32_t l_337 = 1L;
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_298[i][j] = 0x77BA6C62L;
                }
                (*l_300) &= ((*l_299) = (safe_div_func_uint8_t_u_u((safe_div_func_int32_t_s_s((safe_lshift_func_uint8_t_u_u((0x42A0L ^ ((safe_mul_func_int8_t_s_s((safe_add_func_uint32_t_u_u(((l_291 ^= (g_41 , ((*l_109) = (l_290 = (p_71 > 1UL))))) ^ ((safe_lshift_func_int64_t_s_u((safe_mul_func_uint64_t_u_u(p_71, (safe_sub_func_int64_t_s_s(((((((g_211 < ((void*)0 == &g_249)) , ((void*)0 != &p_70)) < 0x32L) , l_113) >= p_71) == l_298[0][0]), 0L)))), 6)) , 0x3DL)), l_277)), 0UL)) != g_10[2])), l_277)), g_211)), 254UL)));
                if (l_277)
                    break;
                for (g_98 = 4; (g_98 >= 0); g_98 -= 1)
                { /* block id: 84 */
                    uint32_t **l_310 = &l_308[2][3][3];
                    uint32_t ***l_309 = &l_310;
                    int32_t l_327 = (-8L);
                    const int32_t l_329 = 0x51B85FDCL;
                    if (((((((safe_sub_func_int64_t_s_s(0x3B0460979C41AB53LL, 0x2DE809F092F5C2C1LL)) < (((*l_109) |= ((safe_mod_func_uint32_t_u_u((g_51[4][2][2] > 0x52E4B5579BDA6349LL), 1UL)) > (safe_sub_func_uint16_t_u_u(((((l_197[0] , l_307[0][4][1]) != ((*l_309) = &l_308[9][3][4])) >= ((*p_74) < (*l_300))) && 0x4BC64D5B5BBEE72DLL), p_70)))) >= p_70)) ^ g_184) , 0x1BEFL) && l_154) >= g_10[1]))
                    { /* block id: 87 */
                        int32_t **l_311 = &l_299;
                        (*l_311) = &l_118[7][6][0];
                        if ((**l_311))
                            break;
                    }
                    else
                    { /* block id: 90 */
                        g_90 = (safe_add_func_uint8_t_u_u((g_51[0][0][1] <= (g_10[3] <= (safe_mod_func_uint64_t_u_u((safe_div_func_uint64_t_u_u(1UL, ((safe_div_func_int64_t_s_s((safe_mul_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u((safe_mul_func_int8_t_s_s((safe_lshift_func_int32_t_s_u((l_327 = (*p_74)), g_51[4][2][2])), ((l_328[0] != &g_98) | l_100))))), ((((*l_300) ^= ((((0x5314A3952FBA135BLL >= g_98) || g_90) <= l_329) , 0L)) & 0xBE1FAAB5558DF00FLL) < (-1L)))), p_70)) & g_176))), 18446744073709551607UL)))), 0xA4L));
                        (*l_299) = 1L;
                    }
                    for (p_70 = 4; (p_70 >= 1); p_70 -= 1)
                    { /* block id: 98 */
                        const int8_t l_340 = 0xA5L;
                        int32_t *l_341 = &l_119[0][4][2];
                        uint32_t ** const l_352 = &l_116[4][5][1];
                        uint16_t *l_357 = &g_244[3][5];
                        uint16_t *l_359[2][2] = {{&l_291,&l_291},{&l_291,&l_291}};
                        int i, j;
                        (*l_341) ^= ((((((((safe_mul_func_uint64_t_u_u((l_100 && (safe_mod_func_int32_t_s_s(((((safe_mul_func_int64_t_s_s(((*l_246) &= ((g_336 = (g_110 = (((*l_300) = ((void*)0 != &g_184)) | p_71))) > (((&g_117 == ((l_338 = (l_337 ^ 1L)) , (void*)0)) < ((+(g_10[5] || 0x34D3L)) >= 0x73957DEBA7D9984ELL)) > 0x6EL))), p_70)) && 18446744073709551615UL) <= l_327) < p_70), l_340))), 0x23F752003131EDF9LL)) == g_81) || 0x4EL) >= (-1L)) == l_340) >= l_291) , 0xD4L) , (-1L));
                        l_338 &= (((((safe_lshift_func_int64_t_s_u(((safe_sub_func_int16_t_s_s((((safe_lshift_func_uint8_t_u_s(p_71, 2)) == ((safe_sub_func_uint16_t_u_u((p_70 != ((g_350 != l_352) , (*l_299))), (safe_mod_func_uint64_t_u_u(((void*)0 == &g_248), ((safe_add_func_uint16_t_u_u(((*l_341) &= (&g_350 == (((*l_357) |= (l_113 | 0x95L)) , l_358))), g_176)) || 4294967295UL))))) != 4294967290UL)) , g_244[0][4]), 0xF821L)) , p_70), g_10[5])) != g_51[4][2][2]) & g_117) == 0x40C0448FL) , 0x8E2427DBL);
                        l_362 = l_360;
                    }
                }
            }
        }
        for (g_98 = 0; (g_98 < 8); ++g_98)
        { /* block id: 115 */
            const int8_t l_373 = 0xD2L;
            int32_t *l_374 = &l_113;
            g_90 = ((*l_374) = ((*p_72) , (safe_lshift_func_uint8_t_u_s((safe_mul_func_int32_t_s_s((safe_mod_func_int8_t_s_s((0xA8L && (safe_add_func_uint16_t_u_u(l_197[0], l_373))), 5UL)), l_373)), 3))));
            for (l_113 = 0; (l_113 >= 23); l_113++)
            { /* block id: 120 */
                int32_t *l_377 = &g_81;
                return l_377;
            }
        }
        if ((((p_71 |= l_113) < (safe_mul_func_int8_t_s_s(p_70, 0xB0L))) > ((((65528UL == (((safe_mul_func_uint32_t_u_u(((safe_lshift_func_int32_t_s_u((safe_sub_func_int16_t_s_s(0x65D1L, g_51[2][0][0])), ((safe_add_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_u(g_81, (((*l_390) = &g_89) != &g_89))) <= 4294967290UL), (*p_72))) < 0x30L))) == p_70), (-8L))) | p_70) , 0UL)) == p_70) <= (*p_72)) || 0x1DB1BB6D1EDAE990LL)))
        { /* block id: 126 */
            int64_t ***l_393 = &g_248;
            int64_t ****l_392 = &l_393;
            (*l_392) = &g_248;
        }
        else
        { /* block id: 128 */
            int32_t l_394 = (-7L);
            int32_t *l_395 = &l_119[1][1][3];
            union U2 *l_405 = &g_406[4];
            (*l_395) = ((l_394 < 0x7F0D1D7AL) , (*p_74));
            for (l_268 = 0; (l_268 <= 7); l_268 += 1)
            { /* block id: 132 */
                const int32_t l_422[2] = {1L,1L};
                int32_t *l_423 = &l_119[1][3][3];
                int i;
                for (l_124 = 0; (l_124 <= 1); l_124 += 1)
                { /* block id: 135 */
                    union U2 **l_407 = &l_405;
                    int i, j;
                    if ((safe_mul_func_uint16_t_u_u(65527UL, g_244[l_268][(l_124 + 1)])))
                    { /* block id: 136 */
                        return &g_54;
                    }
                    else
                    { /* block id: 138 */
                        int64_t * const  volatile * const * const  volatile **l_403 = (void*)0;
                        int64_t * const  volatile * const * const  volatile **l_404 = &g_400[6];
                        int i;
                        (*l_395) ^= ((l_197[l_124]--) <= l_230[(l_124 + 4)]);
                        if (l_197[l_124])
                            continue;
                        (*l_404) = g_400[0];
                    }
                    (*l_407) = l_405;
                    (*l_395) = (1L >= ((((p_71 && ((*l_109) = (safe_unary_minus_func_uint16_t_u(((safe_add_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s(((((*g_249) = g_244[l_268][(l_124 + 1)]) || (((~((((*p_72) < (safe_sub_func_int16_t_s_s(g_98, ((safe_add_func_int16_t_s_s(p_70, (0xB7L != (g_420 != ((g_421 |= 0xFDC9L) , (void*)0))))) > g_10[3])))) >= l_124) , (*l_395))) <= l_422[0]) >= 0xBD43L)) < g_41), p_71)), p_70)) == l_422[1]))))) || p_70) & 3L) | 0L));
                    return (*l_391);
                }
                if ((*p_73))
                    break;
            }
        }
    }
    return &g_54;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_41, "g_41", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_51[i][j][k], "g_51[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_176, "g_176", print_hash_value);
    transparent_crc(g_184, "g_184", print_hash_value);
    transparent_crc(g_211, "g_211", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_244[i][j], "g_244[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_336, "g_336", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_406[i].f0, "g_406[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_421, "g_421", print_hash_value);
    transparent_crc(g_550, "g_550", print_hash_value);
    transparent_crc(g_573, "g_573", print_hash_value);
    transparent_crc(g_602.f0, "g_602.f0", print_hash_value);
    transparent_crc(g_679, "g_679", print_hash_value);
    transparent_crc(g_744, "g_744", print_hash_value);
    transparent_crc(g_748, "g_748", print_hash_value);
    transparent_crc(g_749, "g_749", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_750[i], "g_750[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_792.f0, "g_792.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_849[i][j], "g_849[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_900, "g_900", print_hash_value);
    transparent_crc(g_901, "g_901", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_946[i][j].f0, "g_946[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_948.f0, "g_948.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_949[i].f0, "g_949[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_950.f0, "g_950.f0", print_hash_value);
    transparent_crc(g_951.f0, "g_951.f0", print_hash_value);
    transparent_crc(g_953.f0, "g_953.f0", print_hash_value);
    transparent_crc(g_954.f0, "g_954.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_955[i][j][k].f0, "g_955[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_956[i].f0, "g_956[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_957[i][j].f0, "g_957[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_958[i][j][k].f0, "g_958[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_959[i].f0, "g_959[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_960.f0, "g_960.f0", print_hash_value);
    transparent_crc(g_961.f0, "g_961.f0", print_hash_value);
    transparent_crc(g_962.f0, "g_962.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_967[i].f0, "g_967[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_968.f0, "g_968.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_970[i].f0, "g_970[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_972.f0, "g_972.f0", print_hash_value);
    transparent_crc(g_974.f0, "g_974.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_975[i][j].f0, "g_975[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_978.f0, "g_978.f0", print_hash_value);
    transparent_crc(g_983.f0, "g_983.f0", print_hash_value);
    transparent_crc(g_986.f0, "g_986.f0", print_hash_value);
    transparent_crc(g_988.f0, "g_988.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_989[i][j][k].f0, "g_989[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_990.f0, "g_990.f0", print_hash_value);
    transparent_crc(g_991.f0, "g_991.f0", print_hash_value);
    transparent_crc(g_992.f0, "g_992.f0", print_hash_value);
    transparent_crc(g_998.f0, "g_998.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1039[i].f0, "g_1039[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1070, "g_1070", print_hash_value);
    transparent_crc(g_1282, "g_1282", print_hash_value);
    transparent_crc(g_1342, "g_1342", print_hash_value);
    transparent_crc(g_1361, "g_1361", print_hash_value);
    transparent_crc(g_1591.f0, "g_1591.f0", print_hash_value);
    transparent_crc(g_1639.f0, "g_1639.f0", print_hash_value);
    transparent_crc(g_1938, "g_1938", print_hash_value);
    transparent_crc(g_1939, "g_1939", print_hash_value);
    transparent_crc(g_1940, "g_1940", print_hash_value);
    transparent_crc(g_1941, "g_1941", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1942[i][j], "g_1942[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2017.f0, "g_2017.f0", print_hash_value);
    transparent_crc(g_2017.f1, "g_2017.f1", print_hash_value);
    transparent_crc(g_2017.f2, "g_2017.f2", print_hash_value);
    transparent_crc(g_2017.f3, "g_2017.f3", print_hash_value);
    transparent_crc(g_2017.f4, "g_2017.f4", print_hash_value);
    transparent_crc(g_2017.f5, "g_2017.f5", print_hash_value);
    transparent_crc(g_2017.f6, "g_2017.f6", print_hash_value);
    transparent_crc(g_2017.f7, "g_2017.f7", print_hash_value);
    transparent_crc(g_2017.f8, "g_2017.f8", print_hash_value);
    transparent_crc(g_2033.f0, "g_2033.f0", print_hash_value);
    transparent_crc(g_2120.f0, "g_2120.f0", print_hash_value);
    transparent_crc(g_2120.f1, "g_2120.f1", print_hash_value);
    transparent_crc(g_2120.f2, "g_2120.f2", print_hash_value);
    transparent_crc(g_2120.f3, "g_2120.f3", print_hash_value);
    transparent_crc(g_2120.f4, "g_2120.f4", print_hash_value);
    transparent_crc(g_2120.f5, "g_2120.f5", print_hash_value);
    transparent_crc(g_2120.f6, "g_2120.f6", print_hash_value);
    transparent_crc(g_2120.f7, "g_2120.f7", print_hash_value);
    transparent_crc(g_2120.f8, "g_2120.f8", print_hash_value);
    transparent_crc(g_2121.f0, "g_2121.f0", print_hash_value);
    transparent_crc(g_2121.f1, "g_2121.f1", print_hash_value);
    transparent_crc(g_2121.f2, "g_2121.f2", print_hash_value);
    transparent_crc(g_2121.f3, "g_2121.f3", print_hash_value);
    transparent_crc(g_2121.f4, "g_2121.f4", print_hash_value);
    transparent_crc(g_2121.f5, "g_2121.f5", print_hash_value);
    transparent_crc(g_2121.f6, "g_2121.f6", print_hash_value);
    transparent_crc(g_2121.f7, "g_2121.f7", print_hash_value);
    transparent_crc(g_2121.f8, "g_2121.f8", print_hash_value);
    transparent_crc(g_2132, "g_2132", print_hash_value);
    transparent_crc(g_2204.f0, "g_2204.f0", print_hash_value);
    transparent_crc(g_2305, "g_2305", print_hash_value);
    transparent_crc(g_2430, "g_2430", print_hash_value);
    transparent_crc(g_2434.f0, "g_2434.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2451[i][j][k], "g_2451[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2584, "g_2584", print_hash_value);
    transparent_crc(g_2606, "g_2606", print_hash_value);
    transparent_crc(g_2745, "g_2745", print_hash_value);
    transparent_crc(g_2851.f0, "g_2851.f0", print_hash_value);
    transparent_crc(g_2851.f1, "g_2851.f1", print_hash_value);
    transparent_crc(g_2851.f2, "g_2851.f2", print_hash_value);
    transparent_crc(g_2851.f3, "g_2851.f3", print_hash_value);
    transparent_crc(g_2851.f4, "g_2851.f4", print_hash_value);
    transparent_crc(g_2851.f5, "g_2851.f5", print_hash_value);
    transparent_crc(g_2851.f6, "g_2851.f6", print_hash_value);
    transparent_crc(g_2851.f7, "g_2851.f7", print_hash_value);
    transparent_crc(g_2851.f8, "g_2851.f8", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_2936[i][j][k], "g_2936[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3175[i], "g_3175[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3379, "g_3379", print_hash_value);
    transparent_crc(g_3480.f0, "g_3480.f0", print_hash_value);
    transparent_crc(g_3480.f1, "g_3480.f1", print_hash_value);
    transparent_crc(g_3480.f2, "g_3480.f2", print_hash_value);
    transparent_crc(g_3480.f3, "g_3480.f3", print_hash_value);
    transparent_crc(g_3480.f4, "g_3480.f4", print_hash_value);
    transparent_crc(g_3480.f5, "g_3480.f5", print_hash_value);
    transparent_crc(g_3480.f6, "g_3480.f6", print_hash_value);
    transparent_crc(g_3480.f7, "g_3480.f7", print_hash_value);
    transparent_crc(g_3480.f8, "g_3480.f8", print_hash_value);
    transparent_crc(g_3497, "g_3497", print_hash_value);
    transparent_crc(g_3499, "g_3499", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_3518[i][j], "g_3518[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3556, "g_3556", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_3586[i][j].f0, "g_3586[i][j].f0", print_hash_value);
            transparent_crc(g_3586[i][j].f1, "g_3586[i][j].f1", print_hash_value);
            transparent_crc(g_3586[i][j].f2, "g_3586[i][j].f2", print_hash_value);
            transparent_crc(g_3586[i][j].f3, "g_3586[i][j].f3", print_hash_value);
            transparent_crc(g_3586[i][j].f4, "g_3586[i][j].f4", print_hash_value);
            transparent_crc(g_3586[i][j].f5, "g_3586[i][j].f5", print_hash_value);
            transparent_crc(g_3586[i][j].f6, "g_3586[i][j].f6", print_hash_value);
            transparent_crc(g_3586[i][j].f7, "g_3586[i][j].f7", print_hash_value);
            transparent_crc(g_3586[i][j].f8, "g_3586[i][j].f8", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3588.f0, "g_3588.f0", print_hash_value);
    transparent_crc(g_3588.f1, "g_3588.f1", print_hash_value);
    transparent_crc(g_3588.f2, "g_3588.f2", print_hash_value);
    transparent_crc(g_3588.f3, "g_3588.f3", print_hash_value);
    transparent_crc(g_3588.f4, "g_3588.f4", print_hash_value);
    transparent_crc(g_3588.f5, "g_3588.f5", print_hash_value);
    transparent_crc(g_3588.f6, "g_3588.f6", print_hash_value);
    transparent_crc(g_3588.f7, "g_3588.f7", print_hash_value);
    transparent_crc(g_3588.f8, "g_3588.f8", print_hash_value);
    transparent_crc(g_3620.f0, "g_3620.f0", print_hash_value);
    transparent_crc(g_3620.f1, "g_3620.f1", print_hash_value);
    transparent_crc(g_3620.f2, "g_3620.f2", print_hash_value);
    transparent_crc(g_3620.f3, "g_3620.f3", print_hash_value);
    transparent_crc(g_3620.f4, "g_3620.f4", print_hash_value);
    transparent_crc(g_3620.f5, "g_3620.f5", print_hash_value);
    transparent_crc(g_3620.f6, "g_3620.f6", print_hash_value);
    transparent_crc(g_3620.f7, "g_3620.f7", print_hash_value);
    transparent_crc(g_3620.f8, "g_3620.f8", print_hash_value);
    transparent_crc(g_3781, "g_3781", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_3879[i][j], "g_3879[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3963, "g_3963", print_hash_value);
    transparent_crc(g_3994.f0, "g_3994.f0", print_hash_value);
    transparent_crc(g_3996.f0, "g_3996.f0", print_hash_value);
    transparent_crc(g_4104.f0, "g_4104.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_4161[i][j], "g_4161[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_4207[i], "g_4207[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_4305[i][j][k].f0, "g_4305[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4409.f0, "g_4409.f0", print_hash_value);
    transparent_crc(g_4415.f0, "g_4415.f0", print_hash_value);
    transparent_crc(g_4447, "g_4447", print_hash_value);
    transparent_crc(g_4522.f0, "g_4522.f0", print_hash_value);
    transparent_crc(g_4525.f2, "g_4525.f2", print_hash_value);
    transparent_crc(g_4677.f0, "g_4677.f0", print_hash_value);
    transparent_crc(g_4677.f1, "g_4677.f1", print_hash_value);
    transparent_crc(g_4677.f2, "g_4677.f2", print_hash_value);
    transparent_crc(g_4677.f3, "g_4677.f3", print_hash_value);
    transparent_crc(g_4677.f4, "g_4677.f4", print_hash_value);
    transparent_crc(g_4677.f5, "g_4677.f5", print_hash_value);
    transparent_crc(g_4677.f6, "g_4677.f6", print_hash_value);
    transparent_crc(g_4677.f7, "g_4677.f7", print_hash_value);
    transparent_crc(g_4677.f8, "g_4677.f8", print_hash_value);
    transparent_crc(g_4686, "g_4686", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_4795[i][j], "g_4795[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4906.f0, "g_4906.f0", print_hash_value);
    transparent_crc(g_4906.f1, "g_4906.f1", print_hash_value);
    transparent_crc(g_4906.f2, "g_4906.f2", print_hash_value);
    transparent_crc(g_4906.f3, "g_4906.f3", print_hash_value);
    transparent_crc(g_4906.f4, "g_4906.f4", print_hash_value);
    transparent_crc(g_4906.f5, "g_4906.f5", print_hash_value);
    transparent_crc(g_4906.f6, "g_4906.f6", print_hash_value);
    transparent_crc(g_4906.f7, "g_4906.f7", print_hash_value);
    transparent_crc(g_4906.f8, "g_4906.f8", print_hash_value);
    transparent_crc(g_4907.f0, "g_4907.f0", print_hash_value);
    transparent_crc(g_4907.f1, "g_4907.f1", print_hash_value);
    transparent_crc(g_4907.f2, "g_4907.f2", print_hash_value);
    transparent_crc(g_4907.f3, "g_4907.f3", print_hash_value);
    transparent_crc(g_4907.f4, "g_4907.f4", print_hash_value);
    transparent_crc(g_4907.f5, "g_4907.f5", print_hash_value);
    transparent_crc(g_4907.f6, "g_4907.f6", print_hash_value);
    transparent_crc(g_4907.f7, "g_4907.f7", print_hash_value);
    transparent_crc(g_4907.f8, "g_4907.f8", print_hash_value);
    transparent_crc(g_4908.f0, "g_4908.f0", print_hash_value);
    transparent_crc(g_4908.f1, "g_4908.f1", print_hash_value);
    transparent_crc(g_4908.f2, "g_4908.f2", print_hash_value);
    transparent_crc(g_4908.f3, "g_4908.f3", print_hash_value);
    transparent_crc(g_4908.f4, "g_4908.f4", print_hash_value);
    transparent_crc(g_4908.f5, "g_4908.f5", print_hash_value);
    transparent_crc(g_4908.f6, "g_4908.f6", print_hash_value);
    transparent_crc(g_4908.f7, "g_4908.f7", print_hash_value);
    transparent_crc(g_4908.f8, "g_4908.f8", print_hash_value);
    transparent_crc(g_4967.f0, "g_4967.f0", print_hash_value);
    transparent_crc(g_4967.f1, "g_4967.f1", print_hash_value);
    transparent_crc(g_4967.f2, "g_4967.f2", print_hash_value);
    transparent_crc(g_4967.f3, "g_4967.f3", print_hash_value);
    transparent_crc(g_4967.f4, "g_4967.f4", print_hash_value);
    transparent_crc(g_4967.f5, "g_4967.f5", print_hash_value);
    transparent_crc(g_4967.f6, "g_4967.f6", print_hash_value);
    transparent_crc(g_4967.f7, "g_4967.f7", print_hash_value);
    transparent_crc(g_4967.f8, "g_4967.f8", print_hash_value);
    transparent_crc(g_4968.f0, "g_4968.f0", print_hash_value);
    transparent_crc(g_4968.f1, "g_4968.f1", print_hash_value);
    transparent_crc(g_4968.f2, "g_4968.f2", print_hash_value);
    transparent_crc(g_4968.f3, "g_4968.f3", print_hash_value);
    transparent_crc(g_4968.f4, "g_4968.f4", print_hash_value);
    transparent_crc(g_4968.f5, "g_4968.f5", print_hash_value);
    transparent_crc(g_4968.f6, "g_4968.f6", print_hash_value);
    transparent_crc(g_4968.f7, "g_4968.f7", print_hash_value);
    transparent_crc(g_4968.f8, "g_4968.f8", print_hash_value);
    transparent_crc(g_4969.f0, "g_4969.f0", print_hash_value);
    transparent_crc(g_4969.f1, "g_4969.f1", print_hash_value);
    transparent_crc(g_4969.f2, "g_4969.f2", print_hash_value);
    transparent_crc(g_4969.f3, "g_4969.f3", print_hash_value);
    transparent_crc(g_4969.f4, "g_4969.f4", print_hash_value);
    transparent_crc(g_4969.f5, "g_4969.f5", print_hash_value);
    transparent_crc(g_4969.f6, "g_4969.f6", print_hash_value);
    transparent_crc(g_4969.f7, "g_4969.f7", print_hash_value);
    transparent_crc(g_4969.f8, "g_4969.f8", print_hash_value);
    transparent_crc(g_5003.f0, "g_5003.f0", print_hash_value);
    transparent_crc(g_5003.f1, "g_5003.f1", print_hash_value);
    transparent_crc(g_5003.f2, "g_5003.f2", print_hash_value);
    transparent_crc(g_5003.f3, "g_5003.f3", print_hash_value);
    transparent_crc(g_5003.f4, "g_5003.f4", print_hash_value);
    transparent_crc(g_5003.f5, "g_5003.f5", print_hash_value);
    transparent_crc(g_5003.f6, "g_5003.f6", print_hash_value);
    transparent_crc(g_5003.f7, "g_5003.f7", print_hash_value);
    transparent_crc(g_5003.f8, "g_5003.f8", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_5073[i][j].f0, "g_5073[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_5075[i].f0, "g_5075[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5122, "g_5122", print_hash_value);
    transparent_crc(g_5203.f0, "g_5203.f0", print_hash_value);
    transparent_crc(g_5265, "g_5265", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_5314[i][j], "g_5314[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_5334[i][j].f0, "g_5334[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_5351, "g_5351", print_hash_value);
    transparent_crc(g_5360, "g_5360", print_hash_value);
    transparent_crc(g_5395.f0, "g_5395.f0", print_hash_value);
    transparent_crc(g_5414.f0, "g_5414.f0", print_hash_value);
    transparent_crc(g_5437, "g_5437", print_hash_value);
    transparent_crc(g_5534, "g_5534", print_hash_value);
    transparent_crc(g_5616, "g_5616", print_hash_value);
    transparent_crc(g_5667, "g_5667", print_hash_value);
    transparent_crc(g_5873.f0, "g_5873.f0", print_hash_value);
    transparent_crc(g_5876.f0, "g_5876.f0", print_hash_value);
    transparent_crc(g_5977.f0, "g_5977.f0", print_hash_value);
    transparent_crc(g_5978.f0, "g_5978.f0", print_hash_value);
    transparent_crc(g_6046, "g_6046", print_hash_value);
    transparent_crc(g_6230.f0, "g_6230.f0", print_hash_value);
    transparent_crc(g_6316, "g_6316", print_hash_value);
    transparent_crc(g_6333.f0, "g_6333.f0", print_hash_value);
    transparent_crc(g_6335.f0, "g_6335.f0", print_hash_value);
    transparent_crc(g_6375.f0, "g_6375.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_6389[i][j][k], "g_6389[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_6468.f0, "g_6468.f0", print_hash_value);
    transparent_crc(g_6640, "g_6640", print_hash_value);
    transparent_crc(g_6683.f0, "g_6683.f0", print_hash_value);
    transparent_crc(g_6683.f1, "g_6683.f1", print_hash_value);
    transparent_crc(g_6683.f2, "g_6683.f2", print_hash_value);
    transparent_crc(g_6683.f3, "g_6683.f3", print_hash_value);
    transparent_crc(g_6683.f4, "g_6683.f4", print_hash_value);
    transparent_crc(g_6683.f5, "g_6683.f5", print_hash_value);
    transparent_crc(g_6683.f6, "g_6683.f6", print_hash_value);
    transparent_crc(g_6683.f7, "g_6683.f7", print_hash_value);
    transparent_crc(g_6683.f8, "g_6683.f8", print_hash_value);
    transparent_crc(g_6688.f0, "g_6688.f0", print_hash_value);
    transparent_crc(g_6688.f1, "g_6688.f1", print_hash_value);
    transparent_crc(g_6688.f2, "g_6688.f2", print_hash_value);
    transparent_crc(g_6688.f3, "g_6688.f3", print_hash_value);
    transparent_crc(g_6688.f4, "g_6688.f4", print_hash_value);
    transparent_crc(g_6688.f5, "g_6688.f5", print_hash_value);
    transparent_crc(g_6688.f6, "g_6688.f6", print_hash_value);
    transparent_crc(g_6688.f7, "g_6688.f7", print_hash_value);
    transparent_crc(g_6688.f8, "g_6688.f8", print_hash_value);
    transparent_crc(g_6714, "g_6714", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_6720[i][j].f0, "g_6720[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_6728.f0, "g_6728.f0", print_hash_value);
    transparent_crc(g_6752.f0, "g_6752.f0", print_hash_value);
    transparent_crc(g_6752.f1, "g_6752.f1", print_hash_value);
    transparent_crc(g_6752.f2, "g_6752.f2", print_hash_value);
    transparent_crc(g_6752.f3, "g_6752.f3", print_hash_value);
    transparent_crc(g_6752.f4, "g_6752.f4", print_hash_value);
    transparent_crc(g_6752.f5, "g_6752.f5", print_hash_value);
    transparent_crc(g_6752.f6, "g_6752.f6", print_hash_value);
    transparent_crc(g_6752.f7, "g_6752.f7", print_hash_value);
    transparent_crc(g_6752.f8, "g_6752.f8", print_hash_value);
    transparent_crc(g_6755, "g_6755", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_6757[i][j].f0, "g_6757[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_6772, "g_6772", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_6813[i].f0, "g_6813[i].f0", print_hash_value);
        transparent_crc(g_6813[i].f1, "g_6813[i].f1", print_hash_value);
        transparent_crc(g_6813[i].f2, "g_6813[i].f2", print_hash_value);
        transparent_crc(g_6813[i].f3, "g_6813[i].f3", print_hash_value);
        transparent_crc(g_6813[i].f4, "g_6813[i].f4", print_hash_value);
        transparent_crc(g_6813[i].f5, "g_6813[i].f5", print_hash_value);
        transparent_crc(g_6813[i].f6, "g_6813[i].f6", print_hash_value);
        transparent_crc(g_6813[i].f7, "g_6813[i].f7", print_hash_value);
        transparent_crc(g_6813[i].f8, "g_6813[i].f8", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6856.f0, "g_6856.f0", print_hash_value);
    transparent_crc(g_6970.f0, "g_6970.f0", print_hash_value);
    transparent_crc(g_6970.f1, "g_6970.f1", print_hash_value);
    transparent_crc(g_6970.f2, "g_6970.f2", print_hash_value);
    transparent_crc(g_6970.f3, "g_6970.f3", print_hash_value);
    transparent_crc(g_6970.f4, "g_6970.f4", print_hash_value);
    transparent_crc(g_6970.f5, "g_6970.f5", print_hash_value);
    transparent_crc(g_6970.f6, "g_6970.f6", print_hash_value);
    transparent_crc(g_6970.f7, "g_6970.f7", print_hash_value);
    transparent_crc(g_6970.f8, "g_6970.f8", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_7070[i].f0, "g_7070[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 1746
   depth: 1, occurrence: 3
XXX total union variables: 5

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 37
breakdown:
   indirect level: 0, occurrence: 3
   indirect level: 1, occurrence: 15
   indirect level: 2, occurrence: 6
   indirect level: 3, occurrence: 8
   indirect level: 4, occurrence: 4
   indirect level: 5, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 33
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 3
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 570
   depth: 2, occurrence: 151
   depth: 3, occurrence: 21
   depth: 4, occurrence: 8
   depth: 5, occurrence: 8
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 2
   depth: 12, occurrence: 2
   depth: 14, occurrence: 4
   depth: 15, occurrence: 2
   depth: 16, occurrence: 6
   depth: 17, occurrence: 3
   depth: 18, occurrence: 5
   depth: 19, occurrence: 7
   depth: 20, occurrence: 8
   depth: 21, occurrence: 11
   depth: 22, occurrence: 4
   depth: 23, occurrence: 6
   depth: 24, occurrence: 4
   depth: 25, occurrence: 8
   depth: 26, occurrence: 5
   depth: 27, occurrence: 8
   depth: 28, occurrence: 7
   depth: 29, occurrence: 5
   depth: 30, occurrence: 3
   depth: 31, occurrence: 4
   depth: 32, occurrence: 2
   depth: 33, occurrence: 2
   depth: 34, occurrence: 6
   depth: 37, occurrence: 2
   depth: 38, occurrence: 2
   depth: 39, occurrence: 3
   depth: 41, occurrence: 1
   depth: 43, occurrence: 1
   depth: 45, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 1313

XXX times a variable address is taken: 3555
XXX times a pointer is dereferenced on RHS: 768
breakdown:
   depth: 1, occurrence: 612
   depth: 2, occurrence: 120
   depth: 3, occurrence: 9
   depth: 4, occurrence: 18
   depth: 5, occurrence: 9
XXX times a pointer is dereferenced on LHS: 887
breakdown:
   depth: 1, occurrence: 778
   depth: 2, occurrence: 62
   depth: 3, occurrence: 19
   depth: 4, occurrence: 24
   depth: 5, occurrence: 4
XXX times a pointer is compared with null: 142
XXX times a pointer is compared with address of another variable: 37
XXX times a pointer is compared with another pointer: 46
XXX times a pointer is qualified to be dereferenced: 24675

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 4643
   level: 2, occurrence: 937
   level: 3, occurrence: 648
   level: 4, occurrence: 422
   level: 5, occurrence: 135
XXX number of pointers point to pointers: 718
XXX number of pointers point to scalars: 524
XXX number of pointers point to structs: 18
XXX percent of pointers has null in alias set: 30.2
XXX average alias set size: 1.62

XXX times a non-volatile is read: 5851
XXX times a non-volatile is write: 2881
XXX times a volatile is read: 17
XXX    times read thru a pointer: 8
XXX times a volatile is write: 15
XXX    times written thru a pointer: 15
XXX times a volatile is available for access: 1.04e+03
XXX percentage of non-volatile access: 99.6

XXX forward jumps: 1
XXX backward jumps: 13

XXX stmts: 587
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 34
   depth: 1, occurrence: 50
   depth: 2, occurrence: 79
   depth: 3, occurrence: 122
   depth: 4, occurrence: 131
   depth: 5, occurrence: 171

XXX percentage a fresh-made variable is used: 15.2
XXX percentage an existing variable is used: 84.8
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

