/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: deddca6
 * Options:   (none)
 * Seed:      313963748
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_5[6][1] = {{255UL},{255UL},{255UL},{255UL},{255UL},{255UL}};
static int64_t g_23 = 1L;
static int64_t g_48[5][4][2] = {{{0L,0L},{0L,0L},{0L,0L},{0L,0L}},{{0L,0L},{0L,0L},{0L,0L},{0L,0L}},{{0L,0L},{0L,0L},{0L,0L},{0L,0L}},{{0L,0L},{0L,0L},{0L,0L},{0L,0L}},{{0L,0L},{0L,0L},{0L,0L},{0L,0L}}};
static int64_t *g_47[6] = {&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0]};
static int32_t g_52 = 7L;
static int32_t *g_51 = &g_52;
static int32_t ** volatile g_50 = &g_51;/* VOLATILE GLOBAL g_50 */
static uint16_t g_74[2][7] = {{0xAF72L,0xAF72L,0xA878L,0xAF72L,0xAF72L,0xA878L,0xAF72L},{65534UL,0x4323L,0x4323L,65534UL,0x4323L,0x4323L,65534UL}};
static int16_t g_76[3][6] = {{0x786CL,(-4L),0x4EE8L,0x8C7BL,(-4L),0x8C7BL},{0x786CL,0x20E6L,0x786CL,0x8C7BL,0x20E6L,0x4EE8L},{0x786CL,(-1L),0x8C7BL,0x8C7BL,(-1L),0x786CL}};
static const int8_t g_77 = 0x69L;
static int32_t g_78 = (-5L);
static int32_t g_85 = 0L;
static int8_t g_94 = (-1L);
static uint8_t g_116 = 251UL;
static uint16_t g_123[10] = {65534UL,65534UL,65534UL,65534UL,65534UL,65534UL,65534UL,65534UL,65534UL,65534UL};
static uint64_t g_140 = 0UL;
static int64_t g_142 = 0xC2336C4584B38A77LL;
static int32_t g_156[8] = {0x5E2F7FA0L,0x5E2F7FA0L,7L,0x5E2F7FA0L,0x5E2F7FA0L,7L,0x5E2F7FA0L,0x5E2F7FA0L};
static int32_t * volatile g_155 = &g_156[5];/* VOLATILE GLOBAL g_155 */
static uint16_t *g_161 = &g_74[0][4];
static uint16_t **g_160 = &g_161;
static uint16_t *g_168 = &g_74[0][5];
static uint32_t g_174 = 0xAB1CF0A5L;
static int32_t g_179 = 4L;
static uint32_t g_193 = 0xDA17F8C6L;
static int32_t * volatile g_200 = (void*)0;/* VOLATILE GLOBAL g_200 */
static int32_t * volatile g_231 = (void*)0;/* VOLATILE GLOBAL g_231 */
static int32_t *g_242 = &g_179;
static int32_t **g_241[7][4] = {{&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242}};
static uint64_t g_260 = 0x4BBCF4FF70791D89LL;
static int32_t ** volatile g_289 = &g_51;/* VOLATILE GLOBAL g_289 */
static int32_t * volatile g_348[4] = {&g_52,&g_52,&g_52,&g_52};
static uint32_t g_582 = 0xFE74817AL;
static const uint8_t g_603[3] = {1UL,1UL,1UL};
static int8_t g_636 = (-5L);
static uint16_t ***g_652[10] = {&g_160,&g_160,&g_160,&g_160,&g_160,&g_160,&g_160,&g_160,&g_160,&g_160};
static int8_t g_667 = 0x5EL;
static int32_t * volatile g_669[8] = {&g_85,&g_52,&g_85,&g_52,&g_85,&g_52,&g_85,&g_52};
static int32_t * volatile g_670 = &g_156[7];/* VOLATILE GLOBAL g_670 */
static volatile uint16_t g_688 = 8UL;/* VOLATILE GLOBAL g_688 */
static int32_t * volatile * volatile g_696 = &g_242;/* VOLATILE GLOBAL g_696 */
static int32_t * volatile * volatile *g_695[4][5] = {{&g_696,&g_696,&g_696,&g_696,&g_696},{&g_696,&g_696,&g_696,&g_696,&g_696},{&g_696,&g_696,&g_696,&g_696,&g_696},{&g_696,&g_696,&g_696,&g_696,&g_696}};
static int32_t * volatile * volatile ** volatile g_694 = &g_695[1][1];/* VOLATILE GLOBAL g_694 */
static int8_t g_720 = 0xB2L;
static int16_t g_732 = (-4L);
static int16_t g_735 = (-1L);
static uint8_t g_737 = 0x62L;
static const uint64_t * volatile g_753[3][5] = {{(void*)0,(void*)0,&g_140,(void*)0,(void*)0},{&g_140,&g_140,&g_140,&g_140,&g_140},{(void*)0,&g_260,&g_260,(void*)0,&g_260}};
static const uint64_t * const  volatile *g_752 = &g_753[1][1];
static const uint64_t * const  volatile **g_751[7] = {&g_752,&g_752,&g_752,&g_752,&g_752,&g_752,&g_752};
static uint64_t *g_756 = &g_140;
static uint64_t **g_755 = &g_756;
static uint64_t ***g_754[1] = {&g_755};
static int32_t * volatile g_794 = &g_52;/* VOLATILE GLOBAL g_794 */
static volatile int16_t g_855 = 1L;/* VOLATILE GLOBAL g_855 */
static int32_t * volatile g_861 = &g_85;/* VOLATILE GLOBAL g_861 */
static volatile uint32_t ** volatile g_931 = (void*)0;/* VOLATILE GLOBAL g_931 */
static uint8_t g_981 = 246UL;
static volatile uint8_t *g_1031 = (void*)0;
static volatile uint8_t ** volatile g_1030 = &g_1031;/* VOLATILE GLOBAL g_1030 */
static const int32_t g_1038[3][8][2] = {{{0x6CAEC808L,1L},{0xB40C855AL,7L},{0xB40C855AL,1L},{0x6CAEC808L,6L},{1L,0L},{0x24967FD0L,0xD22DB764L},{0xE05535CDL,0x25354EA9L},{0x25354EA9L,0x587C1BCFL}},{{(-1L),0xE05535CDL},{7L,0xEDE54935L},{0xD22DB764L,0xEDE54935L},{7L,0xE05535CDL},{(-1L),0x587C1BCFL},{0x25354EA9L,0x25354EA9L},{0xE05535CDL,0xD22DB764L},{0x24967FD0L,0L}},{{1L,6L},{0x6CAEC808L,1L},{0xB40C855AL,7L},{0xB40C855AL,4L},{1L,0x25354EA9L},{4L,0xEDE54935L},{0x1C2C531DL,(-1L)},{0x587C1BCFL,0xB40C855AL}}};
static int32_t **g_1043 = &g_51;
static uint8_t *g_1078[2] = {&g_737,&g_737};
static uint8_t **g_1077 = &g_1078[1];
static volatile uint8_t g_1079 = 7UL;/* VOLATILE GLOBAL g_1079 */
static uint32_t **g_1096 = (void*)0;
static uint32_t ** const *g_1095 = &g_1096;
static uint32_t ** const *g_1098 = &g_1096;
static int32_t g_1121 = 0x243F50D6L;
static int32_t *g_1120 = &g_1121;
static int32_t * const *g_1119[8][10] = {{(void*)0,&g_1120,(void*)0,&g_1120,&g_1120,(void*)0,&g_1120,&g_1120,&g_1120,(void*)0},{(void*)0,&g_1120,&g_1120,&g_1120,(void*)0,&g_1120,(void*)0,&g_1120,&g_1120,&g_1120},{&g_1120,(void*)0,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120},{&g_1120,&g_1120,&g_1120,&g_1120,(void*)0,&g_1120,(void*)0,&g_1120,&g_1120,(void*)0},{&g_1120,(void*)0,(void*)0,&g_1120,&g_1120,(void*)0,&g_1120,(void*)0,&g_1120,&g_1120},{(void*)0,&g_1120,(void*)0,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120},{&g_1120,&g_1120,(void*)0,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120,&g_1120,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1120,&g_1120,&g_1120,&g_1120,(void*)0,&g_1120,&g_1120}};
static const uint16_t g_1178 = 5UL;
static volatile uint64_t g_1207 = 0x500D57E3CE0660BBLL;/* VOLATILE GLOBAL g_1207 */
static uint32_t *g_1327 = &g_582;
static uint32_t **g_1326[4] = {&g_1327,&g_1327,&g_1327,&g_1327};
static int16_t g_1350[6] = {0x788BL,0x788BL,0x788BL,0x788BL,0x788BL,0x788BL};
static volatile int32_t g_1394 = 0xBB603E52L;/* VOLATILE GLOBAL g_1394 */
static uint16_t g_1509[4] = {65532UL,65532UL,65532UL,65532UL};
static uint16_t ****g_1542 = &g_652[0];
static uint8_t g_1573 = 0xB8L;
static int32_t * volatile g_1621 = &g_156[7];/* VOLATILE GLOBAL g_1621 */
static int8_t g_1670 = (-2L);
static const uint16_t ***g_1687 = (void*)0;
static const uint16_t ****g_1686 = &g_1687;
static const uint16_t *****g_1685[5][4][1] = {{{&g_1686},{&g_1686},{&g_1686},{&g_1686}},{{&g_1686},{&g_1686},{&g_1686},{&g_1686}},{{&g_1686},{&g_1686},{&g_1686},{&g_1686}},{{&g_1686},{&g_1686},{&g_1686},{&g_1686}},{{&g_1686},{&g_1686},{&g_1686},{&g_1686}}};
static volatile uint16_t *g_1733 = &g_688;
static uint32_t ***g_1754[2][7] = {{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096},{(void*)0,(void*)0,&g_1096,&g_1096,&g_1096,(void*)0,(void*)0}};
static uint32_t ****g_1753 = &g_1754[1][0];
static uint32_t **** const *g_1752 = &g_1753;
static uint32_t g_1878 = 1UL;
static int8_t g_1949 = 0L;
static const int16_t g_1956 = 0xA8EDL;
static int8_t *g_1966 = &g_1670;
static int32_t g_2075 = 0xB4BF94EEL;
static volatile int16_t g_2168 = (-9L);/* VOLATILE GLOBAL g_2168 */
static uint32_t g_2173 = 4UL;
static int32_t ****g_2272 = (void*)0;
static const uint32_t g_2464 = 0xBDBA9F0DL;
static const uint32_t g_2466 = 4294967295UL;
static const uint32_t *g_2465 = &g_2466;
static const int64_t g_2472 = 0x8A62A9801335C4AELL;
static volatile uint16_t g_2591[9] = {0x21FAL,0x21FAL,0xC5D8L,0x21FAL,0x21FAL,0xC5D8L,0x21FAL,0x21FAL,0xC5D8L};
static uint32_t *** const *g_2895 = &g_1754[1][5];
static uint32_t *** const **g_2894 = &g_2895;
static int16_t g_2989 = 0x5ABAL;
static uint32_t ***g_3035 = &g_1326[3];
static uint32_t ****g_3034 = &g_3035;
static volatile int8_t g_3136 = 1L;/* VOLATILE GLOBAL g_3136 */
static volatile uint32_t g_3180 = 1UL;/* VOLATILE GLOBAL g_3180 */
static int32_t * volatile g_3203 = &g_156[5];/* VOLATILE GLOBAL g_3203 */
static uint32_t * const ****g_3211[2] = {(void*)0,(void*)0};
static uint32_t *g_3215 = &g_174;
static const int16_t *g_3271 = &g_1956;
static const int16_t **g_3270 = &g_3271;
static uint32_t *** const *g_3472[5][3][3] = {{{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0}},{{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0}},{{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0}},{{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0},{(void*)0,&g_3035,(void*)0}},{{(void*)0,&g_3035,(void*)0},{(void*)0,(void*)0,&g_3035},{&g_3035,(void*)0,&g_3035}}};
static uint32_t *** const **g_3471[7][1][1] = {{{&g_3472[4][1][2]}},{{&g_3472[4][1][2]}},{{&g_3472[4][1][2]}},{{&g_3472[4][1][2]}},{{&g_3472[4][1][2]}},{{&g_3472[4][1][2]}},{{&g_3472[4][1][2]}}};
static int32_t ***g_3479 = &g_1043;
static const int32_t *g_3489 = &g_156[5];
static const int32_t ** volatile g_3488[8] = {&g_3489,&g_3489,(void*)0,&g_3489,&g_3489,(void*)0,&g_3489,&g_3489};
static const int32_t ** volatile g_3490[7][6][6] = {{{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489}},{{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489}},{{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489}},{{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489}},{{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489}},{{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489}},{{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489},{&g_3489,&g_3489,&g_3489,&g_3489,&g_3489,&g_3489}}};
static uint8_t g_3506 = 0xB9L;
static const int32_t ** volatile ** volatile g_3658 = (void*)0;/* VOLATILE GLOBAL g_3658 */
static const int32_t ** volatile *g_3660 = &g_3490[1][1][2];
static const int32_t ** volatile ** volatile g_3659[4][10][6] = {{{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,(void*)0,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{(void*)0,&g_3660,(void*)0,&g_3660,&g_3660,&g_3660},{&g_3660,(void*)0,(void*)0,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660}},{{&g_3660,(void*)0,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{(void*)0,&g_3660,(void*)0,&g_3660,&g_3660,&g_3660},{&g_3660,(void*)0,(void*)0,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,(void*)0,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660}},{{(void*)0,&g_3660,&g_3660,(void*)0,&g_3660,&g_3660},{&g_3660,(void*)0,&g_3660,(void*)0,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,&g_3660,&g_3660,(void*)0},{&g_3660,(void*)0,&g_3660,&g_3660,&g_3660,(void*)0},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,(void*)0,&g_3660,&g_3660},{&g_3660,(void*)0,&g_3660,(void*)0,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,&g_3660,&g_3660,(void*)0}},{{&g_3660,(void*)0,&g_3660,&g_3660,&g_3660,(void*)0},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,(void*)0,&g_3660,&g_3660},{&g_3660,(void*)0,&g_3660,(void*)0,&g_3660,&g_3660},{(void*)0,&g_3660,&g_3660,&g_3660,&g_3660,(void*)0},{&g_3660,(void*)0,&g_3660,&g_3660,&g_3660,(void*)0},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660},{&g_3660,&g_3660,&g_3660,&g_3660,&g_3660,&g_3660}}};
static uint64_t * const **g_3709 = (void*)0;
static uint64_t * const ***g_3708 = &g_3709;
static int64_t **g_3729 = &g_47[5];
static uint32_t ** volatile *g_3760 = &g_1096;
static uint32_t ** volatile * volatile *g_3759 = &g_3760;
static uint32_t ** volatile * volatile * volatile * volatile g_3758 = &g_3759;/* VOLATILE GLOBAL g_3758 */
static uint8_t ****g_3859 = (void*)0;
static uint8_t *****g_3858 = &g_3859;
static int16_t ***g_3877 = (void*)0;
static volatile uint64_t g_3905[6][8] = {{18446744073709551615UL,0x0E0EC6D8B754AD21LL,0xEC282B42921FDAF4LL,0x87FFF029B59F5001LL,4UL,18446744073709551614UL,18446744073709551615UL,0xCDECE5773BBB6F79LL},{0x0E0EC6D8B754AD21LL,0x26B2B98F5973BCBCLL,0UL,0xEFC6A868A739C5B2LL,18446744073709551608UL,0xEFC6A868A739C5B2LL,0UL,0x26B2B98F5973BCBCLL},{0UL,1UL,18446744073709551608UL,6UL,8UL,0UL,0x26B2B98F5973BCBCLL,18446744073709551614UL},{18446744073709551615UL,0xEC282B42921FDAF4LL,0xCDECE5773BBB6F79LL,0UL,0UL,0UL,0x26B2B98F5973BCBCLL,1UL},{0xAB7C6FD23140E007LL,0UL,18446744073709551608UL,0UL,0UL,18446744073709551608UL,0UL,0xAB7C6FD23140E007LL},{0UL,18446744073709551608UL,0UL,0xAB7C6FD23140E007LL,0x78128959263E8D31LL,6UL,18446744073709551615UL,18446744073709551615UL}};
static volatile uint64_t g_3906 = 0xC05499BC080EA109LL;/* VOLATILE GLOBAL g_3906 */
static volatile uint64_t g_3907 = 18446744073709551613UL;/* VOLATILE GLOBAL g_3907 */
static volatile uint64_t g_3908[2] = {0xCC6C8596AA416376LL,0xCC6C8596AA416376LL};
static volatile uint64_t g_3909 = 0xA3D8BF6F41E566A3LL;/* VOLATILE GLOBAL g_3909 */
static volatile uint64_t g_3910 = 0x4DDCF7FC6E3F486CLL;/* VOLATILE GLOBAL g_3910 */
static volatile uint64_t g_3911 = 0x2FBF4C404F166B7FLL;/* VOLATILE GLOBAL g_3911 */
static volatile uint64_t g_3912 = 18446744073709551615UL;/* VOLATILE GLOBAL g_3912 */
static volatile uint64_t g_3913 = 18446744073709551613UL;/* VOLATILE GLOBAL g_3913 */
static volatile uint64_t * const g_3904[6][5] = {{&g_3911,&g_3913,&g_3908[1],&g_3906,&g_3906},{&g_3906,(void*)0,&g_3906,&g_3905[3][2],(void*)0},{&g_3908[1],&g_3910,(void*)0,&g_3909,&g_3913},{&g_3907,&g_3905[3][2],&g_3905[3][2],&g_3907,&g_3912},{&g_3908[1],&g_3907,(void*)0,&g_3913,&g_3910},{&g_3908[1],(void*)0,&g_3912,(void*)0,&g_3908[1]}};
static uint64_t **g_3998 = &g_756;
static uint64_t *** const g_3997 = &g_3998;
static uint64_t *** const *g_3996[4] = {&g_3997,&g_3997,&g_3997,&g_3997};
static uint64_t *** const **g_3995[3][9][3] = {{{&g_3996[2],&g_3996[2],&g_3996[2]},{&g_3996[2],&g_3996[2],&g_3996[2]},{&g_3996[2],&g_3996[2],&g_3996[2]},{&g_3996[1],&g_3996[2],&g_3996[0]},{&g_3996[2],&g_3996[2],&g_3996[1]},{&g_3996[2],(void*)0,(void*)0},{&g_3996[2],&g_3996[2],(void*)0},{(void*)0,&g_3996[1],&g_3996[1]},{&g_3996[3],(void*)0,&g_3996[0]}},{{&g_3996[2],&g_3996[0],&g_3996[2]},{&g_3996[1],(void*)0,&g_3996[2]},{&g_3996[2],&g_3996[1],&g_3996[2]},{&g_3996[2],&g_3996[2],(void*)0},{&g_3996[2],(void*)0,&g_3996[1]},{&g_3996[2],&g_3996[2],(void*)0},{&g_3996[1],&g_3996[2],&g_3996[2]},{&g_3996[2],&g_3996[2],(void*)0},{&g_3996[3],&g_3996[2],&g_3996[1]}},{{(void*)0,&g_3996[2],(void*)0},{&g_3996[2],&g_3996[2],&g_3996[2]},{&g_3996[2],&g_3996[2],&g_3996[2]},{&g_3996[2],&g_3996[2],&g_3996[2]},{&g_3996[1],&g_3996[2],&g_3996[0]},{&g_3996[2],&g_3996[2],&g_3996[1]},{&g_3996[2],(void*)0,(void*)0},{&g_3996[2],&g_3996[2],(void*)0},{(void*)0,&g_3996[1],&g_3996[1]}}};
static uint32_t ***g_4008[4] = {&g_1326[2],&g_1326[2],&g_1326[2],&g_1326[2]};
static uint32_t **** const g_4007 = &g_4008[3];
static uint32_t **** const *g_4006 = &g_4007;
static const int64_t *g_4095 = (void*)0;
static const int64_t **g_4094[1][5] = {{&g_4095,&g_4095,&g_4095,&g_4095,&g_4095}};
static volatile int64_t g_4122 = 1L;/* VOLATILE GLOBAL g_4122 */
static int16_t g_4174 = 1L;
static uint64_t g_4236[2][8] = {{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL}};
static uint16_t g_4371 = 5UL;
static uint64_t ** const *g_4385 = &g_755;
static uint64_t ** const **g_4384 = &g_4385;
static uint64_t ** const ***g_4383[9][4] = {{&g_4384,&g_4384,&g_4384,&g_4384},{&g_4384,&g_4384,&g_4384,&g_4384},{&g_4384,&g_4384,&g_4384,(void*)0},{&g_4384,&g_4384,&g_4384,&g_4384},{&g_4384,&g_4384,&g_4384,&g_4384},{&g_4384,&g_4384,(void*)0,(void*)0},{&g_4384,&g_4384,&g_4384,&g_4384},{&g_4384,&g_4384,(void*)0,&g_4384},{&g_4384,&g_4384,&g_4384,(void*)0}};
static uint32_t *****g_4414 = &g_1753;
static int64_t g_4521 = 7L;
static int32_t g_4553 = 0x5CEAD019L;
static int32_t g_4585 = (-4L);
static volatile int64_t * volatile g_4725[6] = {&g_4122,&g_4122,&g_4122,&g_4122,&g_4122,&g_4122};
static volatile int64_t * volatile *g_4724[2][1] = {{&g_4725[0]},{&g_4725[0]}};
static volatile int64_t * volatile **g_4723[10][6][1] = {{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}},{{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]},{&g_4724[1][0]},{&g_4724[0][0]}}};
static volatile int64_t * volatile ** volatile * volatile g_4722 = &g_4723[8][0][0];/* VOLATILE GLOBAL g_4722 */
static int16_t *g_4737 = &g_76[0][4];
static uint64_t ****g_4795 = &g_754[0];
static int32_t ****g_4937 = &g_3479;
static uint64_t g_5095 = 7UL;
static uint8_t g_5231 = 250UL;
static volatile uint32_t g_5236 = 4294967289UL;/* VOLATILE GLOBAL g_5236 */
static uint64_t ***g_5267 = (void*)0;
static const uint8_t *g_5454 = &g_5[3][0];
static const uint8_t **g_5453 = &g_5454;
static volatile uint16_t g_5540 = 0x60CCL;/* VOLATILE GLOBAL g_5540 */
static uint32_t *****g_5552 = &g_1753;
static volatile int32_t g_5629 = (-1L);/* VOLATILE GLOBAL g_5629 */
static uint64_t g_5809[1][1] = {{1UL}};
static int64_t g_5899[8][6][5] = {{{0xC568EEAFA514F3A6LL,0xC568EEAFA514F3A6LL,0x8D4AF490D7E1333BLL,(-10L),0x3ECF3ABEE2E594AALL},{0x0A75198268B62DF1LL,0x04E9D511FE648F1BLL,0x49957E84283497D2LL,(-5L),0xC7E0EC6EF6AE5B79LL},{0x050EFC4C8930B8DDLL,0x9CE29BF0CA3F4EA8LL,0L,0xF6625F761E8C2FC7LL,0x192A860B2EC793E4LL},{0xC568EEAFA514F3A6LL,0x04E9D511FE648F1BLL,0x1F63D60E8E4C8709LL,0x6EFC4F4135ECE93FLL,(-1L)},{(-7L),0xC568EEAFA514F3A6LL,0x49957E84283497D2LL,0xE3F75CFC93020801LL,(-1L)},{0L,0x0A75198268B62DF1LL,0L,0x1E1693EE0CD71D31LL,0x192A860B2EC793E4LL}},{{0x04E9D511FE648F1BLL,0x050EFC4C8930B8DDLL,0x3278459DA0511864LL,(-10L),0xC7E0EC6EF6AE5B79LL},{0xA0C31E3A23E4D5AFLL,0xC568EEAFA514F3A6LL,0L,1L,0x3ECF3ABEE2E594AALL},{0x050EFC4C8930B8DDLL,(-7L),0x49957E84283497D2LL,0x1E1693EE0CD71D31LL,0xC10D30AFD95C1FA2LL},{0x050EFC4C8930B8DDLL,0L,0x1F63D60E8E4C8709LL,0xF6625F761E8C2FC7LL,0x83CD4B828B7398EDLL},{0xA0C31E3A23E4D5AFLL,0x04E9D511FE648F1BLL,0L,0xBB511389AED40F0CLL,(-1L)},{0x04E9D511FE648F1BLL,0xA0C31E3A23E4D5AFLL,0x49957E84283497D2LL,0xF6625F761E8C2FC7LL,0L}},{{0L,0x050EFC4C8930B8DDLL,0x8D4AF490D7E1333BLL,0x1E1693EE0CD71D31LL,0x83CD4B828B7398EDLL},{(-7L),0x050EFC4C8930B8DDLL,0xC10D30AFD95C1FA2LL,1L,0xC7E0EC6EF6AE5B79LL},{0xC568EEAFA514F3A6LL,0xA0C31E3A23E4D5AFLL,0L,(-10L),0x4627761ED674BD96LL},{0x050EFC4C8930B8DDLL,0x04E9D511FE648F1BLL,0x5136AA2FCDB7B5C1LL,0x1E1693EE0CD71D31LL,0xC7E0EC6EF6AE5B79LL},{0x0A75198268B62DF1LL,0L,0L,0xE3F75CFC93020801LL,0x83CD4B828B7398EDLL},{0xC568EEAFA514F3A6LL,(-7L),0L,0x6EFC4F4135ECE93FLL,0L}},{{0x04E9D511FE648F1BLL,0xC568EEAFA514F3A6LL,0x5136AA2FCDB7B5C1LL,0xF6625F761E8C2FC7LL,(-1L)},{0x9CE29BF0CA3F4EA8LL,0x050EFC4C8930B8DDLL,0L,(-5L),0x83CD4B828B7398EDLL},{0x04E9D511FE648F1BLL,0x0A75198268B62DF1LL,0xC10D30AFD95C1FA2LL,(-10L),0xC10D30AFD95C1FA2LL},{0xC568EEAFA514F3A6LL,0xC568EEAFA514F3A6LL,0x8D4AF490D7E1333BLL,(-10L),0x3ECF3ABEE2E594AALL},{0x0A75198268B62DF1LL,0x04E9D511FE648F1BLL,0x49957E84283497D2LL,(-5L),0xC7E0EC6EF6AE5B79LL},{0x050EFC4C8930B8DDLL,0x9CE29BF0CA3F4EA8LL,0L,0xF6625F761E8C2FC7LL,0x192A860B2EC793E4LL}},{{0xC568EEAFA514F3A6LL,0x04E9D511FE648F1BLL,0x1F63D60E8E4C8709LL,0x6EFC4F4135ECE93FLL,(-1L)},{(-7L),0xC568EEAFA514F3A6LL,0x49957E84283497D2LL,0xE3F75CFC93020801LL,(-1L)},{0L,0x0A75198268B62DF1LL,0L,0x1E1693EE0CD71D31LL,0x192A860B2EC793E4LL},{0x04E9D511FE648F1BLL,0x050EFC4C8930B8DDLL,0x3278459DA0511864LL,(-10L),0xC7E0EC6EF6AE5B79LL},{0xA0C31E3A23E4D5AFLL,0xC568EEAFA514F3A6LL,0L,1L,0x3ECF3ABEE2E594AALL},{0x050EFC4C8930B8DDLL,(-7L),(-7L),0xBCDB114EB07F970ALL,(-9L)}},{{0x49957E84283497D2LL,0L,1L,5L,0x69E0967EAB785200LL},{(-1L),0x192A860B2EC793E4LL,0x63F93F0F2630B277LL,0x254323FB2E628F57LL,0L},{0x192A860B2EC793E4LL,(-1L),(-7L),5L,0L},{0L,0x49957E84283497D2LL,0xDAC399E51775B752LL,0xBCDB114EB07F970ALL,0x69E0967EAB785200LL},{0x7D7848591715CECALL,0x49957E84283497D2LL,(-9L),(-4L),0x093E5FFDFB0B133FLL},{0x4627761ED674BD96LL,(-1L),0L,0x10190E9BFC7E5801LL,0xA0A5C02F2C087FEBLL}},{{0x49957E84283497D2LL,0x192A860B2EC793E4LL,0x08ED3BFD7E9F2A5DLL,0xBCDB114EB07F970ALL,0x093E5FFDFB0B133FLL},{0x5136AA2FCDB7B5C1LL,0L,0x63F93F0F2630B277LL,2L,0x69E0967EAB785200LL},{0x4627761ED674BD96LL,0x7D7848591715CECALL,0x63F93F0F2630B277LL,1L,0L},{0x192A860B2EC793E4LL,0x4627761ED674BD96LL,0x08ED3BFD7E9F2A5DLL,5L,0L},{0x1F63D60E8E4C8709LL,0x49957E84283497D2LL,0L,(-6L),0x69E0967EAB785200LL},{0x192A860B2EC793E4LL,0x5136AA2FCDB7B5C1LL,(-9L),0x10190E9BFC7E5801LL,(-9L)}},{{0x4627761ED674BD96LL,0x4627761ED674BD96LL,0xDAC399E51775B752LL,0x10190E9BFC7E5801LL,(-1L)},{0x5136AA2FCDB7B5C1LL,0x192A860B2EC793E4LL,(-7L),(-6L),0x093E5FFDFB0B133FLL},{0x49957E84283497D2LL,0x1F63D60E8E4C8709LL,0x63F93F0F2630B277LL,5L,(-10L)},{0x4627761ED674BD96LL,0x192A860B2EC793E4LL,1L,1L,0L},{0x7D7848591715CECALL,0x4627761ED674BD96LL,(-7L),2L,0L},{0L,0x5136AA2FCDB7B5C1LL,0L,0xBCDB114EB07F970ALL,(-10L)}}};
static const uint32_t g_5928 = 3UL;
static int16_t ****g_6014 = (void*)0;
static const uint32_t g_6046 = 0xC8D72060L;


/* --- FORWARD DECLARATIONS --- */
static const int8_t  func_1(void);
static uint64_t  func_8(int32_t  p_9, uint32_t  p_10, int64_t  p_11);
static int32_t  func_12(int16_t  p_13, int32_t  p_14);
static int64_t * func_26(int32_t  p_27, int64_t * p_28, uint8_t  p_29, int64_t * p_30);
static int64_t  func_31(const int64_t * p_32, int32_t  p_33, uint8_t  p_34, int64_t * p_35, uint16_t  p_36);
static int64_t * func_37(int16_t  p_38, int32_t  p_39, int8_t  p_40, uint32_t  p_41, int64_t * p_42);
static int32_t * func_45(int64_t * p_46);
static int32_t  func_55(int64_t  p_56);
static int8_t  func_58(int32_t  p_59, int32_t  p_60, int32_t * const * p_61);
static uint8_t  func_63(uint32_t  p_64, const int8_t  p_65);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_142 g_1043 g_1966 g_1670 g_1077 g_1078 g_737 g_51 g_756 g_140 g_688 g_1120 g_123 g_3729 g_47 g_1542 g_652 g_160 g_161 g_3758 g_3270 g_3271 g_3035 g_1326 g_1327 g_582 g_3660 g_3490 g_52 g_1956 g_3759 g_755 g_1733 g_3489 g_156 g_1121 g_3858 g_3479 g_3877 g_289 g_3034 g_752 g_753 g_3904 g_670 g_3859 g_2894 g_2895 g_48 g_168 g_696 g_242 g_179 g_754 g_74 g_4006 g_4007 g_4008 g_794 g_735 g_694 g_695 g_3215 g_1621 g_4174 g_3997 g_3998 g_4236 g_3203 g_1509 g_116 g_732 g_981 g_4383 g_174 g_3911 g_667 g_636 g_78 g_4722 g_4385 g_3506 g_4795 g_94 g_23 g_1030 g_1031 g_2173 g_4723 g_5095 g_85 g_3913 g_4937 g_260 g_5453 g_5454 g_1573 g_50 g_76 g_77 g_155 g_241 g_193 g_603 g_751 g_861 g_931 g_1095 g_1119 g_1207 g_1038 g_720 g_1350 g_855 g_2168 g_2272 g_1949 g_5540 g_1878 g_3908 g_5629 g_1754 g_2075 g_4384 g_4724 g_4725 g_4122 g_4553 g_5899 g_5231 g_4521
 * writes: g_23 g_142 g_51 g_737 g_2465 g_735 g_1670 g_1121 g_47 g_74 g_48 g_140 g_52 g_2272 g_582 g_3858 g_1350 g_123 g_3489 g_2895 g_732 g_193 g_3995 g_4006 g_78 g_174 g_720 g_4094 g_1949 g_2075 g_179 g_156 g_1509 g_116 g_981 g_4383 g_4414 g_667 g_636 g_94 g_1043 g_160 g_2989 g_4737 g_4553 g_4795 g_3506 g_1327 g_260 g_4937 g_2173 g_1878 g_85 g_652 g_5231 g_5453 g_4008 g_1573 g_76 g_161 g_168 g_242 g_1095 g_1098 g_1207 g_241 g_1119 g_1542 g_1078 g_1120 g_5540 g_5552 g_4174 g_754 g_5809 g_4371 g_3877 g_6014 g_4521 g_348
 */
static const int8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_21 = 0x9864BA8BL;
    int64_t *l_22 = &g_23;
    const int64_t *l_2471[8] = {&g_2472,&g_2472,&g_2472,&g_2472,&g_2472,&g_2472,&g_2472,&g_2472};
    const int64_t **l_2470 = &l_2471[5];
    int64_t *l_3740 = (void*)0;
    int32_t l_5546 = 0x058127F0L;
    int32_t **l_5565 = &g_242;
    int32_t l_5592 = (-1L);
    int32_t l_5595[8][7][4] = {{{1L,0xCDDA61BFL,8L,(-1L)},{(-1L),0xCDDA61BFL,0xDCA343B9L,0x8E2DB724L},{0xCDDA61BFL,0xC18E9F43L,0L,0x2A7241B4L},{(-2L),0L,5L,(-5L)},{0x7501A841L,1L,5L,0xDC388306L},{(-2L),0xD8E097F0L,0L,0xDCA343B9L},{0xCDDA61BFL,0L,0xDCA343B9L,0x6E3DBBC3L}},{{(-1L),(-9L),8L,0x6E3DBBC3L},{1L,0L,(-1L),0xDCA343B9L},{0x6CC95689L,0xD8E097F0L,0x6E3DBBC3L,0xDC388306L},{0L,1L,(-5L),(-5L)},{0L,0L,0x6E3DBBC3L,0x2A7241B4L},{0x6CC95689L,0xC18E9F43L,(-1L),0x8E2DB724L},{1L,0xCDDA61BFL,8L,(-1L)}},{{(-1L),0xCDDA61BFL,0xDCA343B9L,0x8E2DB724L},{0xCDDA61BFL,0xC18E9F43L,0L,0x2A7241B4L},{(-2L),0L,5L,(-5L)},{0x7501A841L,1L,5L,0xDC388306L},{(-2L),0xD8E097F0L,0L,0xDCA343B9L},{0xCDDA61BFL,0L,0xDCA343B9L,0x6E3DBBC3L},{(-1L),(-9L),8L,0x6E3DBBC3L}},{{1L,0L,(-1L),0xDCA343B9L},{0x6CC95689L,0xD8E097F0L,0x224B4D50L,(-1L)},{(-9L),0x7501A841L,5L,5L},{(-9L),(-9L),0x224B4D50L,0x8E2DB724L},{(-1L),1L,0x6E3DBBC3L,9L},{0x7501A841L,(-2L),0xBEC9E834L,0x6E3DBBC3L},{0xC18E9F43L,(-2L),(-5L),9L}},{{(-2L),1L,8L,0x8E2DB724L},{0xD8E097F0L,(-9L),0xDC388306L,5L},{0L,0x7501A841L,0xDC388306L,(-1L)},{0xD8E097F0L,0L,8L,(-5L)},{(-2L),0L,(-5L),0x224B4D50L},{0xC18E9F43L,0xCDDA61BFL,0xBEC9E834L,0x224B4D50L},{0x7501A841L,0L,0x6E3DBBC3L,(-5L)}},{{(-1L),0L,0x224B4D50L,(-1L)},{(-9L),0x7501A841L,5L,5L},{(-9L),(-9L),0x224B4D50L,0x8E2DB724L},{(-1L),1L,0x6E3DBBC3L,9L},{0x7501A841L,(-2L),0xBEC9E834L,0x6E3DBBC3L},{0xC18E9F43L,(-2L),(-5L),9L},{(-2L),1L,8L,0x8E2DB724L}},{{0xD8E097F0L,(-9L),0xDC388306L,5L},{0L,0x7501A841L,0xDC388306L,(-1L)},{0xD8E097F0L,0L,8L,(-5L)},{(-2L),0L,(-5L),0x224B4D50L},{0xC18E9F43L,0xCDDA61BFL,0xBEC9E834L,0x224B4D50L},{0x7501A841L,0L,0x6E3DBBC3L,(-5L)},{(-1L),0L,0x224B4D50L,(-1L)}},{{(-9L),0x7501A841L,5L,5L},{(-9L),(-9L),0x224B4D50L,0x8E2DB724L},{(-1L),1L,0x6E3DBBC3L,9L},{0x7501A841L,(-2L),0xBEC9E834L,0x6E3DBBC3L},{0xC18E9F43L,(-2L),(-5L),9L},{(-2L),1L,8L,0x8E2DB724L},{0xD8E097F0L,(-9L),0xDC388306L,5L}}};
    uint64_t ** const * const l_5640 = &g_3998;
    int32_t l_5667 = 0xB7CB3294L;
    uint8_t * const l_5675[4][9] = {{&g_737,&g_5[3][0],&g_5[3][0],&g_737,&g_5[3][0],&g_5[3][0],&g_737,&g_5[3][0],&g_5[3][0]},{&g_981,&g_1573,(void*)0,(void*)0,(void*)0,&g_1573,&g_981,&g_1573,(void*)0},{&g_737,&g_5[3][0],&g_5[3][0],&g_737,&g_5[3][0],&g_5[3][0],&g_737,&g_5[3][0],&g_5[3][0]},{&g_981,&g_1573,(void*)0,(void*)0,(void*)0,&g_1573,&g_981,&g_1573,(void*)0}};
    uint8_t *l_5676 = &g_3506;
    int16_t l_5746[6][6][4] = {{{0xDC9DL,0xA8B4L,0xA8B4L,0xDC9DL},{0xA8B4L,0xDC9DL,0xA8B4L,0xA8B4L},{0xDC9DL,0xDC9DL,0x60B5L,0xDC9DL},{0xDC9DL,0xA8B4L,0xA8B4L,0xDC9DL},{0xA8B4L,0xDC9DL,0xA8B4L,0xA8B4L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L}},{{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L},{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L}},{{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L},{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L}},{{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L},{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L}},{{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L},{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L}},{{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L},{0xA8B4L,0x60B5L,0x60B5L,0xA8B4L},{0x60B5L,0xA8B4L,0x60B5L,0x60B5L},{0xA8B4L,0xA8B4L,0xDC9DL,0xA8B4L}}};
    int64_t l_5757[8][5][2] = {{{0L,0xBBF5340D6F2AEB9DLL},{0xF4DB3DC200569FF8LL,0x22C8A88107ACBBE5LL},{0x2A19CBAEC86ED446LL,2L},{0x32BE571CDB1E26AELL,0x18F4C85F7D8AEB6DLL},{0x053E1EEB0EFB684CLL,0L}},{{0x9D00E59C5AC689CFLL,0x512189B97B50B97BLL},{(-6L),(-1L)},{0x22C8A88107ACBBE5LL,0x3F84248B22C3A74BLL},{1L,0x3F84248B22C3A74BLL},{0x22C8A88107ACBBE5LL,(-1L)}},{{(-6L),0x512189B97B50B97BLL},{0x9D00E59C5AC689CFLL,0L},{0x053E1EEB0EFB684CLL,0x18F4C85F7D8AEB6DLL},{0x32BE571CDB1E26AELL,2L},{0x2A19CBAEC86ED446LL,0x22C8A88107ACBBE5LL}},{{0xF4DB3DC200569FF8LL,0xBBF5340D6F2AEB9DLL},{0L,1L},{0xCE7A4D5F50BFAF20LL,0xF4DB3DC200569FF8LL},{0xC3FFF9B534E68C32LL,0xC3FFF9B534E68C32LL},{(-4L),0x6D955482F46BF180LL}},{{2L,0x0A01535DB4776E14LL},{(-1L),0xE0F706484B660510LL},{0x18F4C85F7D8AEB6DLL,(-1L)},{5L,0x46754E106001D2FALL},{5L,(-1L)}},{{0x18F4C85F7D8AEB6DLL,0xE0F706484B660510LL},{(-1L),0x0A01535DB4776E14LL},{2L,0x6D955482F46BF180LL},{(-4L),0xC3FFF9B534E68C32LL},{0xC3FFF9B534E68C32LL,0xF4DB3DC200569FF8LL}},{{0xCE7A4D5F50BFAF20LL,1L},{0L,0xBBF5340D6F2AEB9DLL},{0xF4DB3DC200569FF8LL,0x22C8A88107ACBBE5LL},{0x2A19CBAEC86ED446LL,0xCE7A4D5F50BFAF20LL},{(-6L),0x9D00E59C5AC689CFLL}},{{0xBBF5340D6F2AEB9DLL,0x22C8A88107ACBBE5LL},{5L,0x8DF8335C1A2D1F89LL},{0x2149463AB7CF7C10LL,0x0A01535DB4776E14LL},{1L,2L},{3L,2L}}};
    int64_t ***l_5777 = &g_3729;
    int64_t ****l_5776[5][10][3] = {{{&l_5777,&l_5777,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,&l_5777,(void*)0},{(void*)0,&l_5777,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,(void*)0,(void*)0},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,&l_5777}},{{&l_5777,&l_5777,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,&l_5777,(void*)0},{(void*)0,&l_5777,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,(void*)0,(void*)0},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,&l_5777}},{{&l_5777,&l_5777,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,&l_5777,(void*)0},{(void*)0,&l_5777,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,(void*)0,(void*)0},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,&l_5777}},{{&l_5777,&l_5777,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,&l_5777,(void*)0},{(void*)0,&l_5777,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,(void*)0,(void*)0},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,&l_5777}},{{&l_5777,&l_5777,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,&l_5777,(void*)0},{(void*)0,&l_5777,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,(void*)0},{&l_5777,(void*)0,(void*)0},{&l_5777,(void*)0,&l_5777},{&l_5777,&l_5777,&l_5777}}};
    int64_t *****l_5775 = &l_5776[1][9][0];
    uint64_t ***l_5803[4][2] = {{(void*)0,(void*)0},{&g_3998,(void*)0},{(void*)0,&g_3998},{(void*)0,(void*)0}};
    int16_t **l_5888 = (void*)0;
    int16_t ***l_5887 = &l_5888;
    uint32_t *l_5890 = &g_174;
    int32_t ***l_5896 = &g_1043;
    uint32_t l_5897 = 18446744073709551610UL;
    uint32_t l_6002 = 1UL;
    uint32_t l_6006 = 0x538CD2F5L;
    uint16_t **l_6033 = &g_161;
    uint16_t l_6034 = 65528UL;
    uint32_t l_6040 = 4294967286UL;
    uint32_t *l_6044 = &g_1878;
    int i, j, k;
    if (((l_5546 = ((~(safe_sub_func_uint32_t_u_u(g_5[3][0], (safe_rshift_func_int64_t_s_u(g_5[3][0], func_8(((*g_242) = func_12((g_5[5][0] && (safe_rshift_func_uint8_t_u_s(8UL, (safe_lshift_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_u((((*l_22) = l_21) ^ 0x80DB959C45C1D102LL), ((****g_1542) = (g_5[3][0] , (safe_rshift_func_uint64_t_u_s((((*g_3729) = func_26((func_31(((*l_2470) = func_37(((g_5[3][0] >= l_21) & 7L), l_21, l_21, l_21, l_22)), l_21, l_21, l_22, l_21) > l_21), &g_48[4][0][0], l_21, &g_48[0][1][0])) == l_3740), l_21)))))) <= l_21), (*g_756)))))), l_21)), l_21, l_21)))))) , l_21)) == l_21))
    { /* block id: 2474 */
        uint64_t l_5559 = 0x98765A93BDB09507LL;
        int32_t *l_5560 = &g_1121;
        int32_t l_5578 = 0xE89FE7C4L;
        int32_t l_5587 = 9L;
        int32_t l_5591 = 1L;
        int32_t l_5593 = 0L;
        int32_t l_5598 = 0xB28903EDL;
        int32_t l_5601[5] = {0x0A1FDC56L,0x0A1FDC56L,0x0A1FDC56L,0x0A1FDC56L,0x0A1FDC56L};
        uint8_t l_5674 = 8UL;
        int16_t l_5719 = 0x0CCBL;
        int32_t l_5742 = 0xFA6DA760L;
        uint64_t l_5744 = 18446744073709551608UL;
        int64_t ***l_5774 = &g_3729;
        int64_t **** const l_5773 = &l_5774;
        int64_t **** const *l_5772 = &l_5773;
        const uint64_t *l_5792[3][5] = {{&g_260,&g_5095,&g_260,&l_5559,&l_5559},{&l_5744,&l_5744,&l_5559,&l_5744,&l_5744},{&g_260,&l_5744,&g_5095,&l_5744,&g_5095}};
        const uint64_t **l_5791 = &l_5792[2][1];
        const uint64_t *** const l_5790[1][9][2] = {{{&l_5791,&l_5791},{&l_5791,(void*)0},{&l_5791,&l_5791},{(void*)0,&l_5791},{&l_5791,(void*)0},{&l_5791,&l_5791},{&l_5791,(void*)0},{&l_5791,&l_5791},{(void*)0,&l_5791}}};
        const uint8_t l_5794[6][7] = {{1UL,0xE5L,0x9BL,0xE5L,1UL,0xABL,0xABL},{1UL,0xE5L,0x9BL,0xE5L,1UL,0xABL,0xABL},{1UL,0xE5L,0x9BL,0xE5L,1UL,0xABL,0xABL},{1UL,0xE5L,0x9BL,0xE5L,1UL,0xABL,0xABL},{1UL,0xE5L,0x9BL,0xE5L,1UL,0xABL,0xABL},{1UL,0xE5L,0x9BL,0xE5L,1UL,0xABL,0xABL}};
        int i, j, k;
        for (g_1878 = 0; (g_1878 <= 0); g_1878 += 1)
        { /* block id: 2477 */
            uint64_t l_5555 = 0UL;
            int32_t l_5586 = (-1L);
            int32_t l_5594[6][9] = {{0L,0x87C0B725L,0L,(-5L),0xC07A82D9L,5L,0x916BD042L,0x916BD042L,5L},{0x83451107L,0x20D11111L,(-6L),0x20D11111L,0x83451107L,0L,0L,0x796CC57BL,0x796CC57BL},{0x414D83E5L,0L,5L,(-5L),5L,0L,0x414D83E5L,0xC07A82D9L,(-5L)},{1L,0L,0x20D11111L,0L,9L,0L,0x20D11111L,0L,1L},{0L,0xFF9C9C6AL,0x916BD042L,0xC07A82D9L,1L,5L,1L,0xC07A82D9L,0x916BD042L},{0L,0L,0L,(-6L),0L,0x796CC57BL,1L,0x796CC57BL,0L}};
            int64_t *l_5639[7][7] = {{&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0],(void*)0,&g_142,&g_48[0][1][0]},{(void*)0,&g_142,&g_48[0][1][0],&g_48[0][1][0],&g_142,(void*)0,&g_4521},{&g_48[0][3][0],&g_48[0][1][0],(void*)0,&g_48[0][1][0],&g_48[0][1][0],(void*)0,&g_48[0][1][0]},{&g_142,&g_4521,(void*)0,&g_142,&g_48[0][1][0],&g_48[0][1][0],&g_142},{&g_142,&g_48[0][1][0],&g_142,(void*)0,&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0]},{&g_142,&g_142,&g_23,&g_142,&g_142,&g_23,&g_4521},{&g_48[0][1][0],&g_48[0][1][0],(void*)0,&g_48[0][1][0],(void*)0,&g_48[0][1][0],&g_48[0][1][0]}};
            uint32_t * const **l_5661 = (void*)0;
            uint16_t l_5668 = 3UL;
            uint8_t *****l_5669 = &g_3859;
            uint32_t *****l_5684 = &g_3034;
            int32_t ***l_5733 = &g_241[3][2];
            int32_t ****l_5732[2][6] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
            uint64_t l_5771 = 0x935438D2BBF06124LL;
            int32_t l_5778[3];
            int i, j;
            for (i = 0; i < 3; i++)
                l_5778[i] = (-1L);
            for (g_1949 = 0; (g_1949 <= 3); g_1949 += 1)
            { /* block id: 2480 */
                int32_t l_5588 = 5L;
                int32_t l_5590 = (-9L);
                int32_t l_5596 = 1L;
                int32_t l_5597 = 0x44243F46L;
                int32_t l_5599 = 1L;
                int32_t l_5603 = 0L;
                int64_t l_5604[9][6][4] = {{{0xC0282F9E794D1FF9LL,0L,0L,0x7882A1C594071CF8LL},{5L,0x8D4160EF0689EE38LL,(-6L),0L},{5L,(-8L),0L,0xC7B9622B534F4110LL},{0xC0282F9E794D1FF9LL,0L,0L,0x95C8CE8346B312CALL},{0x2B693CDC14154EA3LL,5L,5L,0x7D52AF865EE86B75LL},{2L,0L,(-5L),5L}},{{0x6D8B01AE57FA8BB4LL,(-1L),(-6L),(-1L)},{0x367FF0DFA0191EC1LL,0L,5L,0x7882A1C594071CF8LL},{0L,1L,(-9L),0x7882A1C594071CF8LL},{0x2AF88B2E7FA2648ALL,0L,0x5A8104E9CD04444ALL,(-1L)},{0L,(-1L),0x4CE1DC703790DBE9LL,5L},{0xE70D388BADC5672CLL,0L,0x14F549313815786BLL,0x7D52AF865EE86B75LL}},{{0x2AF88B2E7FA2648ALL,5L,0x2AF88B2E7FA2648ALL,0x95C8CE8346B312CALL},{9L,0x9F7BC571C8CBC3BCLL,5L,0x438651D8759E5220LL},{1L,0L,0L,0x9F7BC571C8CBC3BCLL},{0x6D8B01AE57FA8BB4LL,0x7D52AF865EE86B75LL,0L,(-1L)},{1L,0x7882A1C594071CF8LL,5L,0L},{9L,1L,0x2AF88B2E7FA2648ALL,1L}},{{0x2AF88B2E7FA2648ALL,1L,0x14F549313815786BLL,(-1L)},{0xE70D388BADC5672CLL,0x438651D8759E5220LL,0x4CE1DC703790DBE9LL,(-8L)},{0L,0L,0x5A8104E9CD04444ALL,(-1L)},{0x2AF88B2E7FA2648ALL,(-8L),(-9L),0x95C8CE8346B312CALL},{0L,(-8L),5L,(-1L)},{0x367FF0DFA0191EC1LL,0L,(-6L),(-8L)}},{{0x6D8B01AE57FA8BB4LL,0x438651D8759E5220LL,(-5L),(-1L)},{2L,1L,5L,1L},{0x2B693CDC14154EA3LL,1L,0x6D8B01AE57FA8BB4LL,0L},{0x2AF88B2E7FA2648ALL,0x7882A1C594071CF8LL,0x0212C96D7CDD6C8DLL,(-1L)},{0xC0282F9E794D1FF9LL,0x7D52AF865EE86B75LL,0x4CE1DC703790DBE9LL,0x9F7BC571C8CBC3BCLL},{0xC0282F9E794D1FF9LL,0L,0x0212C96D7CDD6C8DLL,0x438651D8759E5220LL}},{{0x2AF88B2E7FA2648ALL,0x9F7BC571C8CBC3BCLL,0x6D8B01AE57FA8BB4LL,0x95C8CE8346B312CALL},{0x2B693CDC14154EA3LL,5L,5L,0x7D52AF865EE86B75LL},{2L,0L,(-5L),5L},{0x6D8B01AE57FA8BB4LL,(-1L),(-6L),(-1L)},{0x367FF0DFA0191EC1LL,0L,5L,0x7882A1C594071CF8LL},{0L,1L,(-9L),0x7882A1C594071CF8LL}},{{0x2AF88B2E7FA2648ALL,0L,0x5A8104E9CD04444ALL,(-1L)},{0L,(-1L),0x4CE1DC703790DBE9LL,5L},{0xE70D388BADC5672CLL,0L,0x14F549313815786BLL,0x7D52AF865EE86B75LL},{0x2AF88B2E7FA2648ALL,5L,0x2AF88B2E7FA2648ALL,0x95C8CE8346B312CALL},{9L,0x9F7BC571C8CBC3BCLL,5L,0x438651D8759E5220LL},{1L,0L,0L,0x9F7BC571C8CBC3BCLL}},{{0x6D8B01AE57FA8BB4LL,0x7D52AF865EE86B75LL,0L,(-1L)},{1L,0x7882A1C594071CF8LL,5L,0L},{9L,1L,0x2AF88B2E7FA2648ALL,1L},{0x2AF88B2E7FA2648ALL,1L,0x14F549313815786BLL,(-1L)},{0xE70D388BADC5672CLL,0x438651D8759E5220LL,0x4CE1DC703790DBE9LL,(-8L)},{0L,0L,0x5A8104E9CD04444ALL,(-1L)}},{{0x2AF88B2E7FA2648ALL,(-8L),(-9L),0x95C8CE8346B312CALL},{0L,(-8L),5L,(-1L)},{0x367FF0DFA0191EC1LL,0L,(-6L),(-8L)},{0x6D8B01AE57FA8BB4LL,0x438651D8759E5220LL,0L,0x44700C27A7EB4BF7LL},{(-6L),0x2E84DEA862C63D0BLL,0xC0282F9E794D1FF9LL,0x2E84DEA862C63D0BLL},{0x14F549313815786BLL,0x84FBE3BCE2762A82LL,0xC063E2E2E723A84DLL,0x95C8CE8346B312CALL}}};
                uint32_t ***l_5618 = &g_1326[2];
                int i, j, k;
                if (g_123[g_1878])
                { /* block id: 2481 */
                    uint32_t *****l_5551 = &g_1753;
                    int16_t ****l_5554 = (void*)0;
                    int16_t *****l_5553 = &l_5554;
                    int i;
                    l_5555 &= (safe_mul_func_int16_t_s_s(g_3908[g_1878], ((((g_4414 = l_5551) == (g_5552 = (void*)0)) > (&g_3877 == ((*l_5553) = &g_3877))) <= ((void*)0 != (*g_3858)))));
                    if ((safe_div_func_int16_t_s_s(0x88EBL, (safe_unary_minus_func_int32_t_s(l_5559)))))
                    { /* block id: 2486 */
                        if (l_5559)
                            break;
                        return g_123[g_1878];
                    }
                    else
                    { /* block id: 2489 */
                        (***g_4937) = l_5560;
                    }
                }
                else
                { /* block id: 2492 */
                    int32_t ***l_5566 = &g_241[3][2];
                    uint64_t l_5569 = 18446744073709551610UL;
                    int32_t l_5589 = 0x6E1BE72EL;
                    int32_t l_5600 = 9L;
                    int32_t l_5602[6] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
                    uint32_t l_5605 = 0x30E45E7AL;
                    const uint8_t ***l_5638[10][2][7] = {{{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453},{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,(void*)0,&g_5453}},{{&g_5453,(void*)0,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453},{&g_5453,&g_5453,(void*)0,&g_5453,(void*)0,(void*)0,&g_5453}},{{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453},{&g_5453,&g_5453,&g_5453,&g_5453,(void*)0,&g_5453,&g_5453}},{{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453},{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453}},{{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,(void*)0,&g_5453},{&g_5453,(void*)0,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453}},{{&g_5453,&g_5453,(void*)0,&g_5453,(void*)0,(void*)0,&g_5453},{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453}},{{&g_5453,&g_5453,&g_5453,&g_5453,(void*)0,&g_5453,&g_5453},{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453}},{{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453},{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,(void*)0,&g_5453}},{{&g_5453,(void*)0,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453},{&g_5453,&g_5453,(void*)0,&g_5453,(void*)0,(void*)0,&g_5453}},{{&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453,&g_5453},{&g_5453,&g_5453,&g_5453,&g_5453,(void*)0,&g_5453,&g_5453}}};
                    const uint8_t ****l_5637 = &l_5638[1][1][4];
                    const uint8_t *****l_5636 = &l_5637;
                    int32_t *l_5641 = &l_5598;
                    int i, j, k;
                    if (((safe_mod_func_int16_t_s_s((safe_add_func_uint32_t_u_u((l_5565 != ((*l_5566) = &g_242)), (safe_mul_func_uint16_t_u_u((l_5569 , (((*l_22) = ((((safe_rshift_func_uint64_t_u_s(((((-9L) > (safe_add_func_uint32_t_u_u(0UL, (safe_lshift_func_int64_t_s_u(1L, 39))))) , (((safe_mod_func_int8_t_s_s(l_5546, 0x10L)) , (*l_5565)) != (***g_694))) < (*l_5560)), 4)) < 0x5FL) , (*g_1966)) , l_5555)) == 0x2FCB64A96A572BE7LL)), l_5555)))), l_5569)) , l_5569))
                    { /* block id: 2495 */
                        int32_t *l_5579 = &g_156[5];
                        int32_t *l_5580 = (void*)0;
                        int32_t *l_5581 = &g_156[5];
                        int32_t *l_5582 = &g_156[5];
                        int32_t *l_5583 = &g_156[6];
                        int32_t *l_5584 = &g_4553;
                        int32_t *l_5585[7][5] = {{&l_5578,&l_5578,&l_5578,&l_5578,&l_5578},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5578,&l_5578,&l_5578,&l_5578,&l_5578},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5578,&l_5578,&l_5578,&l_5578,&l_5578},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_5578,&l_5578,&l_5578,&l_5578,&l_5578}};
                        uint64_t l_5608 = 0UL;
                        int i, j;
                        l_5605--;
                        ++l_5608;
                    }
                    else
                    { /* block id: 2498 */
                        uint8_t l_5613 = 0x4EL;
                        (*l_5560) = ((*g_1966) , 0xE5C3C471L);
                        (*l_5560) = (l_5589 = ((*g_3203) = (l_5546 ^= (safe_sub_func_int32_t_s_s(l_21, (l_5613--))))));
                        return l_5594[3][4];
                    }
                    if ((*g_861))
                        break;
                    (*l_5641) ^= (safe_mod_func_uint16_t_u_u((&g_4722 != ((l_5600 = ((((((**g_3270) && (l_5618 == ((safe_mul_func_int64_t_s_s(0x79F658B4D1525906LL, (((safe_rshift_func_int32_t_s_u((safe_mod_func_int16_t_s_s(((safe_sub_func_int64_t_s_s((((*l_2470) != ((safe_rshift_func_uint16_t_u_s((g_123[(g_1949 + 4)] ^= (((**g_3270) && (g_5629 , (l_5594[4][8] , (((*g_3215) = (safe_div_func_int64_t_s_s((safe_mul_func_uint32_t_u_u((safe_sub_func_int64_t_s_s(((void*)0 != l_5636), l_5594[2][4])), (-1L))), 0x4436D8DCC2C8BBDALL))) , 0xA145L)))) , l_5546)), l_5589)) , l_5639[5][5])) ^ l_5602[3]), 1L)) & (*g_1966)), 8L)), (*l_5560))) >= 9L) && (*l_5560)))) , (void*)0))) , (-1L)) <= l_5597) , l_5640) != (void*)0)) , &g_4722)), 4UL));
                }
                for (l_5596 = 0; (l_5596 <= 0); l_5596 += 1)
                { /* block id: 2515 */
                    int i, j, k;
                    if (l_5604[6][3][2])
                        break;
                    for (g_4174 = 0; (g_4174 >= 0); g_4174 -= 1)
                    { /* block id: 2519 */
                        (**g_3660) = &l_5596;
                    }
                }
            }
            l_5586 = (safe_add_func_int16_t_s_s(0x01E1L, ((safe_add_func_int32_t_s_s(((safe_sub_func_uint32_t_u_u(l_21, (safe_mod_func_int8_t_s_s((!((safe_sub_func_int32_t_s_s((safe_div_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((safe_mul_func_int16_t_s_s((((safe_mul_func_uint16_t_u_u(((**g_2894) == l_5661), (safe_sub_func_int32_t_s_s((((safe_mod_func_uint8_t_u_u((247UL & (!0xA841851015DA799ELL)), (((**g_1077) = l_5592) , (((**g_160) = (*g_168)) && ((*l_5560) = (*g_3271)))))) & 1L) , l_5555), l_5594[2][4])))) | 0L) & l_5595[6][6][0]), l_5667)), 5)), 65529UL)), l_5594[2][4])) & l_5595[2][0][2])), l_5586)))) || (*l_5560)), l_5668)) > 0x4CL)));
            for (l_5587 = 0; (l_5587 <= 3); l_5587 += 1)
            { /* block id: 2530 */
                int8_t l_5677 = 0x09L;
                uint32_t * const *l_5688 = &g_1327;
                uint32_t * const **l_5687 = &l_5688;
                uint32_t * const *** const l_5686 = &l_5687;
                uint32_t * const *** const *l_5685 = &l_5686;
                uint64_t l_5697 = 18446744073709551610UL;
                int32_t l_5700 = 0xF2F081D8L;
                int64_t l_5718[9][8] = {{0xEA927A78268A9F44LL,(-1L),0xC50D19E1C6AA0644LL,(-1L),(-1L),0xC50D19E1C6AA0644LL,(-1L),0xEA927A78268A9F44LL},{0L,0xA1F35B88176E2E89LL,0xC50D19E1C6AA0644LL,0x948AD18FDE02560CLL,(-1L),0xC0B4F8A96134BB43LL,(-1L),0x948AD18FDE02560CLL},{(-1L),(-7L),(-1L),0x54D7B1C047AEB70FLL,0x948AD18FDE02560CLL,0xC0B4F8A96134BB43LL,0xC50D19E1C6AA0644LL,0xC50D19E1C6AA0644LL},{0xC50D19E1C6AA0644LL,0xA1F35B88176E2E89LL,0L,0L,0xA1F35B88176E2E89LL,0xC50D19E1C6AA0644LL,0x948AD18FDE02560CLL,(-1L)},{0xC50D19E1C6AA0644LL,(-1L),0xEA927A78268A9F44LL,0xA1F35B88176E2E89LL,0x948AD18FDE02560CLL,0xA1F35B88176E2E89LL,0xEA927A78268A9F44LL,(-1L)},{(-1L),0xEA927A78268A9F44LL,0xC0B4F8A96134BB43LL,0xA1F35B88176E2E89LL,(-1L),0x54D7B1C047AEB70FLL,0x54D7B1C047AEB70FLL,(-1L)},{0L,(-1L),(-1L),0L,(-1L),(-1L),0x54D7B1C047AEB70FLL,0xC50D19E1C6AA0644LL},{0xEA927A78268A9F44LL,0L,0xC0B4F8A96134BB43LL,0x54D7B1C047AEB70FLL,0xC0B4F8A96134BB43LL,0L,0xEA927A78268A9F44LL,0x948AD18FDE02560CLL},{0xC0B4F8A96134BB43LL,0L,0xEA927A78268A9F44LL,0x948AD18FDE02560CLL,(-1L),(-1L),0x948AD18FDE02560CLL,0xEA927A78268A9F44LL}};
                int32_t l_5741[6][1] = {{0L},{0xD000690BL},{0L},{0xD000690BL},{0L},{0xD000690BL}};
                uint16_t ****l_5754 = (void*)0;
                int8_t *l_5793 = &g_720;
                int i, j;
                (**g_3479) = &l_5578;
                if (((*l_5560) |= 0xD5D6F262L))
                { /* block id: 2533 */
                    int32_t l_5683 = 9L;
                    uint8_t l_5701 = 1UL;
                    int i, j;
                    if (((((((&g_3859 != l_5669) | ((safe_rshift_func_int64_t_s_u(l_5594[5][7], 7)) | ((safe_rshift_func_uint64_t_u_s((l_5674 = ((*g_756) = l_5668)), 45)) != l_5595[7][4][1]))) ^ (l_5675[0][8] == (l_5676 = l_5676))) ^ ((**g_3270) == (l_5594[2][4] > 0UL))) , l_5677) <= l_5555))
                    { /* block id: 2537 */
                        (*g_1621) = l_5546;
                    }
                    else
                    { /* block id: 2539 */
                        int16_t *l_5698 = &g_4174;
                        int32_t l_5699 = 0x31DD8746L;
                        const int32_t l_5702[10] = {0xDF620CC1L,0xDF620CC1L,0xDF620CC1L,0xDF620CC1L,0xDF620CC1L,0xDF620CC1L,0xDF620CC1L,0xDF620CC1L,0xDF620CC1L,0xDF620CC1L};
                        uint32_t *l_5705 = &g_193;
                        uint32_t *l_5706 = &g_582;
                        uint32_t *l_5707 = &g_2173;
                        uint32_t *l_5708 = &g_1878;
                        uint32_t *l_5709 = &g_2173;
                        uint32_t *l_5710 = (void*)0;
                        uint32_t *l_5711 = &g_1878;
                        uint32_t *l_5712 = (void*)0;
                        uint32_t *l_5713 = &g_193;
                        uint32_t *l_5714 = &g_2173;
                        uint32_t *l_5715 = &g_193;
                        uint32_t *l_5716 = (void*)0;
                        uint32_t *l_5717 = &g_1878;
                        uint32_t ** const l_5704[1][7][8] = {{{&l_5707,&l_5708,&l_5716,&l_5705,&l_5714,&l_5717,&l_5714,&l_5705},{&l_5714,&l_5717,&l_5714,&l_5705,&l_5716,&l_5708,&l_5707,&l_5713},{&l_5711,&l_5716,&l_5715,&l_5708,&l_5708,&l_5715,&l_5716,&l_5711},{&l_5711,&l_5705,&l_5706,&l_5714,&l_5716,&l_5712,&l_5715,&l_5712},{&l_5714,&l_5710,&l_5713,&l_5710,&l_5714,&l_5712,&l_5717,&l_5716},{&l_5707,&l_5705,&l_5710,&l_5709,&l_5715,&l_5715,&l_5709,&l_5710},{&l_5716,&l_5716,&l_5710,&l_5711,&l_5706,&l_5708,&l_5717,&l_5707}}};
                        uint32_t ** const *l_5703 = &l_5704[0][0][4];
                        int i, j, k;
                        (*g_51) ^= (1L || (safe_div_func_int64_t_s_s(((safe_lshift_func_int32_t_s_u(((-4L) | (((l_5703 = ((l_5586 || ((+((***g_4385) = (l_5683 & ((l_5700 = ((l_5586 , (((l_5684 != l_5685) && (((((*l_5698) = (safe_mul_func_uint16_t_u_u((safe_lshift_func_uint64_t_u_u(0xD3A8BD3BA7D7443FLL, (((safe_lshift_func_int64_t_s_s((((((safe_div_func_int32_t_s_s((l_5697 <= l_5546), 0x48206699L)) | l_5586) , 0xE804L) != l_5595[6][1][3]) , l_5683), l_5683)) || 0x643B2936768DC3C6LL) < (-1L)))), l_5683))) < l_5699) >= 4294967287UL) <= 0x168C882F0529DA89LL)) <= 0xADL)) , 0xFB53L)) , l_5701)))) || l_5702[8])) , (void*)0)) != (void*)0) ^ l_5718[3][5])), l_5586)) < l_5719), 0xABFFDA8B704799B2LL)));
                    }
                }
                else
                { /* block id: 2546 */
                    int32_t l_5745 = 0xAEDA9C37L;
                    int32_t l_5747 = 0x6646D31EL;
                    uint32_t l_5770[4][6][4] = {{{0xC54DD860L,0UL,0x1FC068E7L,0UL},{0x88875207L,0xE04DF00BL,0xF2D0F8D0L,0UL},{0x1145A4D2L,0UL,0x1145A4D2L,0xF2D0F8D0L},{4294967295UL,0xC54DD860L,0x496DA197L,4294967295UL},{0x88875207L,0xF2D0F8D0L,1UL,0xC54DD860L},{0xF2D0F8D0L,0UL,1UL,1UL}},{{0x88875207L,0x88875207L,0x496DA197L,0UL},{4294967295UL,4294967295UL,0x1145A4D2L,0xC54DD860L},{0x1145A4D2L,0xC54DD860L,0xF2D0F8D0L,0x1145A4D2L},{0x88875207L,0xC54DD860L,0x1FC068E7L,0xC54DD860L},{0xC54DD860L,4294967295UL,1UL,0UL},{0xE04DF00BL,0x88875207L,0xF2D0F8D0L,6UL}},{{1UL,0xE04DF00BL,0UL,0x1145A4D2L},{1UL,4294967288UL,4294967288UL,1UL},{0x496DA197L,0x1145A4D2L,6UL,4294967288UL},{0x1145A4D2L,0xE04DF00BL,0UL,4294967295UL},{0xF2D0F8D0L,0x496DA197L,4294967288UL,4294967295UL},{0x1FC068E7L,0xE04DF00BL,0x1FC068E7L,4294967288UL}},{{1UL,0x1145A4D2L,4294967295UL,1UL},{0xF2D0F8D0L,4294967288UL,6UL,0x1145A4D2L},{4294967288UL,0xE04DF00BL,6UL,6UL},{0xF2D0F8D0L,0xF2D0F8D0L,4294967295UL,4294967295UL},{1UL,0x534EF8E5L,0x1FC068E7L,0x1145A4D2L},{0x1FC068E7L,0x1145A4D2L,4294967288UL,0x1FC068E7L}}};
                    int i, j, k;
                    for (g_2075 = 3; (g_2075 >= 0); g_2075 -= 1)
                    { /* block id: 2549 */
                        int32_t l_5743 = 0x1E3B24EDL;
                        int i, j, k;
                        l_5747 = (safe_div_func_uint32_t_u_u(((l_5697 || (((((safe_mod_func_uint64_t_u_u(((****g_4795)++), l_5594[2][4])) , (l_5668 < ((*g_3203) = ((***g_3479) ^= ((**g_5453) == (((**g_755) = (safe_mul_func_int16_t_s_s((safe_div_func_int16_t_s_s((((*l_5560) = (safe_add_func_int64_t_s_s((l_5732[1][1] != &g_695[3][2]), ((safe_div_func_uint8_t_u_u((((*g_1966) = ((safe_sub_func_uint32_t_u_u((l_5595[6][6][0] , (safe_rshift_func_int8_t_s_s(((!l_5741[4][0]) , ((((void*)0 != (*g_4384)) | (*g_1966)) , l_5677)), 1))), l_5546)) != 0xD3L)) && (*g_1966)), l_5742)) & l_5555)))) & l_5743), 0xFFA9L)), (*g_168)))) > l_5741[1][0])))))) , l_5744) != 0xC83979E0L) != 0xA88499BFL)) <= l_5745), l_5746[1][3][0]));
                        if (l_5746[4][5][3])
                            break;
                    }
                    (*g_51) = ((safe_rshift_func_uint32_t_u_u((~(((((!(safe_mul_func_int64_t_s_s(((void*)0 == l_5754), ((*l_5560) , 18446744073709551609UL)))) && ((safe_rshift_func_int32_t_s_u(l_5757[7][2][1], 0)) >= (safe_lshift_func_int32_t_s_u((((*l_22) = l_5700) & ((safe_mod_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(0xF7L, 5)), ((l_5594[2][4] = ((safe_sub_func_int16_t_s_s(l_5747, ((**g_160) = (safe_rshift_func_int16_t_s_u(l_5770[0][5][3], 7))))) , l_5747)) != l_5771))), (*l_5560))) , l_5745)), l_5771)))) , l_5772) != l_5775) >= l_5771)), l_5778[1])) <= (**g_1077));
                    (*l_5560) |= (**g_50);
                    if (l_5700)
                        break;
                }
                if (l_5595[6][6][0])
                    break;
                (*l_5560) = ((l_5778[1] = (-1L)) && (((*l_5560) < (+(safe_add_func_uint32_t_u_u(0x578D7F20L, ((safe_mod_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_u((g_667 |= ((*l_5793) = ((safe_sub_func_int64_t_s_s(((*g_5454) < ((l_5595[5][6][0] || (*g_756)) != ((((*g_1966) = (((-2L) ^ (l_5790[0][2][0] == (void*)0)) || 0L)) > l_5595[5][0][0]) < l_5586))), (****g_4722))) >= (*l_5560)))), l_5595[6][6][0])) , l_5718[3][5]), l_5586)) || l_5794[1][6]))))) , 0xC5869EAAL));
            }
        }
        (*l_5560) = (*l_5560);
    }
    else
    { /* block id: 2575 */
        int8_t l_5810 = 1L;
        uint8_t *****l_5865 = &g_3859;
        int32_t l_5872[5];
        uint32_t * const l_5889 = &g_174;
        uint8_t l_5898 = 0x52L;
        uint32_t l_5900 = 4294967295UL;
        int32_t l_5956[4];
        const int64_t l_6025[1] = {0x588FFA8F304EADA3LL};
        uint64_t ****l_6041 = &l_5803[0][1];
        int i;
        for (i = 0; i < 5; i++)
            l_5872[i] = 0xDB0220D4L;
        for (i = 0; i < 4; i++)
            l_5956[i] = 0xCEEA7F35L;
        for (g_4553 = (-29); (g_4553 > 21); g_4553++)
        { /* block id: 2578 */
            uint64_t l_5811 = 0x79140DCBE521B95FLL;
            int32_t l_5812 = 0xC4A52E7AL;
            uint8_t l_5851 = 250UL;
            int32_t l_5959 = 0x6C46C107L;
            int64_t l_5974 = 0xA72C7035E3E28D36LL;
            if (((*g_1621) = (((((safe_mul_func_int16_t_s_s((safe_mul_func_uint64_t_u_u((safe_sub_func_int64_t_s_s(((((*g_4795) = l_5803[0][1]) != (*g_4384)) ^ (((safe_unary_minus_func_int32_t_s((((0x8D2CL <= l_5595[2][0][3]) , (*g_3858)) == (*g_3858)))) , (safe_div_func_uint16_t_u_u((safe_mod_func_int64_t_s_s(((l_5811 = (((**g_755) & (g_5809[0][0] = l_5746[3][5][3])) > ((**g_1077) && l_5810))) ^ l_5812), 0xF52F899DB643BE7BLL)), l_5810))) | 0x1BB5148BAB15DDE4LL)), l_5746[1][3][0])), l_5812)), 1L)) && (**g_5453)) != 0xBAL) && l_5811) > l_5812)))
            { /* block id: 2583 */
                int32_t *** const *l_5823 = &g_3479;
                for (l_5546 = 0; (l_5546 <= 0); l_5546 += 1)
                { /* block id: 2586 */
                    int32_t *l_5813 = &g_85;
                    uint32_t l_5848 = 0UL;
                    uint64_t l_5852[2][7][7] = {{{0x31FEC9BED8A8728ELL,0x09773A1DA85C4933LL,0UL,0UL,18446744073709551614UL,0UL,0UL},{0xBFE007EF442E0FE9LL,3UL,18446744073709551615UL,18446744073709551615UL,18446744073709551614UL,3UL,3UL},{0xEDB8A089F3F578DELL,0x09773A1DA85C4933LL,18446744073709551615UL,0x09773A1DA85C4933LL,0xEDB8A089F3F578DELL,0x97F181FA32EF8943LL,0x466D1640C6623499LL},{2UL,18446744073709551607UL,0x0B0C0F440CF735E7LL,18446744073709551615UL,18446744073709551614UL,2UL,0x38645DA6FEFCD04CLL},{0UL,0xDD9044169CDAE050LL,0x58D41CF8126C67F8LL,0x3100FF50C45308DALL,18446744073709551614UL,0x09773A1DA85C4933LL,18446744073709551614UL},{2UL,18446744073709551615UL,18446744073709551615UL,2UL,18446744073709551607UL,0x0B0C0F440CF735E7LL,18446744073709551615UL},{0xEDB8A089F3F578DELL,0x97F181FA32EF8943LL,0x466D1640C6623499LL,0x3100FF50C45308DALL,0x466D1640C6623499LL,0x97F181FA32EF8943LL,0xEDB8A089F3F578DELL}},{{0xBFE007EF442E0FE9LL,18446744073709551614UL,0x35C4BBA769E850CCLL,18446744073709551615UL,0xBFE007EF442E0FE9LL,0xBFE007EF442E0FE9LL,18446744073709551615UL},{0x31FEC9BED8A8728ELL,0xDD9044169CDAE050LL,0x31FEC9BED8A8728ELL,0x09773A1DA85C4933LL,0UL,0UL,18446744073709551614UL},{18446744073709551614UL,0x38645DA6FEFCD04CLL,0x35C4BBA769E850CCLL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL,0x38645DA6FEFCD04CLL},{18446744073709551615UL,0x09773A1DA85C4933LL,0x466D1640C6623499LL,0UL,0xE53AF0FAF1E04D0FLL,0UL,0x466D1640C6623499LL},{0xBFE007EF442E0FE9LL,0xBFE007EF442E0FE9LL,18446744073709551615UL,0x35C4BBA769E850CCLL,18446744073709551614UL,0xBFE007EF442E0FE9LL,3UL},{0x13FCAB6388050B8ALL,0x09773A1DA85C4933LL,0x58D41CF8126C67F8LL,0x09773A1DA85C4933LL,0x13FCAB6388050B8ALL,0x97F181FA32EF8943LL,0UL},{2UL,0x38645DA6FEFCD04CLL,0x0B0C0F440CF735E7LL,18446744073709551614UL,18446744073709551614UL,0x0B0C0F440CF735E7LL,0x38645DA6FEFCD04CLL}}};
                    uint32_t l_5870 = 4294967295UL;
                    uint16_t l_5879 = 0x7EA5L;
                    int i, j, k;
                    (*l_5813) = (l_5812 || 3UL);
                    if ((*g_155))
                        break;
                    if ((safe_unary_minus_func_int32_t_s((((((l_5810 , &g_3479) == &g_3660) >= (l_5812 | (safe_rshift_func_uint64_t_u_s((l_5812 | ((((**g_4937) != (void*)0) && ((safe_mod_func_int32_t_s_s((safe_div_func_uint16_t_u_u(((*l_5813) ^ (((((0xB0F8A8786DA59C12LL < l_5811) , &g_3660) != l_5823) | l_5757[4][1][1]) ^ (*g_3271))), (*l_5813))), 4UL)) , l_5812)) != 6L)), 62)))) | (*l_5813)) | l_5595[7][0][2]))))
                    { /* block id: 2589 */
                        int32_t *l_5824 = (void*)0;
                        int32_t *l_5825 = &g_85;
                        int32_t *l_5826 = (void*)0;
                        int32_t *l_5827 = (void*)0;
                        int32_t *l_5828 = &l_5592;
                        int32_t *l_5829 = &g_156[1];
                        int32_t *l_5830 = &g_156[5];
                        int32_t *l_5831 = &g_52;
                        int32_t *l_5832 = &g_85;
                        int32_t *l_5833 = &l_5595[1][1][1];
                        int32_t *l_5834 = &g_1121;
                        int32_t *l_5835 = &l_5812;
                        int32_t *l_5836 = (void*)0;
                        int32_t *l_5837 = &g_78;
                        int32_t *l_5838 = &g_156[2];
                        int32_t l_5839 = 1L;
                        int32_t l_5840 = 0xE1AD796BL;
                        int32_t *l_5841 = &l_5839;
                        int32_t *l_5842 = &g_156[4];
                        int32_t *l_5843 = (void*)0;
                        int32_t *l_5844 = (void*)0;
                        int32_t *l_5845 = (void*)0;
                        int32_t *l_5846 = &l_5839;
                        int32_t *l_5847 = &g_156[7];
                        l_5848--;
                        if (l_5851)
                            break;
                    }
                    else
                    { /* block id: 2592 */
                        uint8_t l_5868[5] = {255UL,255UL,255UL,255UL,255UL};
                        int32_t l_5869 = 0L;
                        uint16_t *l_5871 = &g_4371;
                        int i;
                        (***g_4937) = &l_5546;
                        l_5872[0] &= (l_5869 = (l_5852[1][2][5] || (((safe_mul_func_uint64_t_u_u(0xCB7FED13A0563410LL, ((--(**g_160)) <= ((*l_5871) = ((safe_lshift_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u((0x27BDD76AD167A1C0LL <= (((safe_rshift_func_uint8_t_u_s((((((l_5868[0] = ((safe_add_func_uint32_t_u_u(((****l_5823) & (((0x39L < ((*l_5813) == (l_5865 == (void*)0))) , (safe_rshift_func_int16_t_s_s(((0x67L <= l_5810) == 0x60A4735A7E17E6A2LL), 10))) != (****l_5823))), 0xD6092D09L)) | l_5810)) <= l_5869) & 4294967290UL) && (*l_5813)) < l_5870), (*g_1966))) > l_5592) , l_5868[2])), (****l_5823))) < (*l_5813)), (*g_1966))) , l_5868[3]))))) , 0xF138002158479077LL) >= (*l_5813))));
                        l_5869 &= (*l_5813);
                    }
                    (***g_4937) = &l_5812;
                    for (g_5231 = 0; (g_5231 <= 0); g_5231 += 1)
                    { /* block id: 2604 */
                        (****g_4937) |= 8L;
                        (*g_3203) |= (safe_mod_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((***g_3997), (****l_5823))), (safe_mul_func_uint32_t_u_u((--l_5879), (safe_mul_func_int32_t_s_s(l_5810, 4UL))))));
                        if ((*g_3203))
                            break;
                    }
                }
                return l_5811;
            }
            else
            { /* block id: 2612 */
                uint64_t l_5901 = 0x291FEA6DD0A23518LL;
                int32_t l_5905 = 0xE0216F82L;
                int8_t l_5909[7] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
                uint32_t ***l_5910 = &g_1326[1];
                int32_t l_5915[9][3] = {{0xFA3FF39AL,1L,0xFA3FF39AL},{(-3L),(-3L),(-3L)},{0xFA3FF39AL,1L,0xFA3FF39AL},{(-3L),(-3L),(-3L)},{0xFA3FF39AL,1L,0xFA3FF39AL},{(-3L),(-3L),(-3L)},{0xFA3FF39AL,1L,0xFA3FF39AL},{(-3L),(-3L),(-3L)},{0xFA3FF39AL,1L,0xFA3FF39AL}};
                int32_t l_5929 = 0L;
                int32_t **l_5946 = &g_1120;
                uint32_t l_5968 = 2UL;
                int32_t *l_6005[10][4] = {{&l_5595[6][6][0],&l_5595[6][6][0],&l_5905,&g_1121},{&g_1121,&l_5905,&l_5905,&g_1121},{&l_5905,&g_1121,&l_5905,&l_5905},{&g_1121,&g_1121,&l_5595[6][6][0],&g_1121},{&g_1121,&l_5905,&l_5905,&g_1121},{&l_5905,&g_1121,&l_5905,&l_5905},{&g_1121,&g_1121,&l_5595[6][6][0],&g_1121},{&g_1121,&l_5905,&l_5905,&g_1121},{&l_5905,&g_1121,&l_5905,&l_5905},{&g_1121,&g_1121,&l_5595[6][6][0],&g_1121}};
                int i, j;
                if (((safe_mul_func_int16_t_s_s((!(l_5901 |= ((((l_5810 , ((((g_3877 = l_5887) == &g_3270) != (l_5889 != l_5890)) ^ ((safe_unary_minus_func_uint32_t_u(((safe_add_func_int16_t_s_s(0xCA4BL, ((safe_mul_func_int8_t_s_s(((l_5896 != (*g_4937)) || (((l_5851 & l_5897) , l_5898) ^ g_5899[3][3][3])), 0xFDL)) && l_5810))) >= 0x87L))) | l_5900))) || 0x100FL) == l_5595[6][6][0]) == l_5872[4]))), (*g_3271))) , 0L))
                { /* block id: 2615 */
                    int32_t *l_5904 = (void*)0;
                    for (g_735 = 0; (g_735 <= (-22)); g_735 = safe_sub_func_int16_t_s_s(g_735, 1))
                    { /* block id: 2618 */
                        (**l_5896) = l_5904;
                    }
                    return l_5900;
                }
                else
                { /* block id: 2622 */
                    uint32_t l_5906 = 0x0545680AL;
                    const uint32_t *l_5927 = &g_5928;
                    const int16_t ***l_5938 = &g_3270;
                    const int16_t ****l_5937 = &l_5938;
                    const int16_t *****l_5936 = &l_5937;
                    int32_t *l_5960 = &l_5956[2];
                    int32_t *l_5961 = (void*)0;
                    int32_t *l_5962 = (void*)0;
                    int32_t *l_5963 = &l_5915[1][1];
                    int32_t *l_5964 = &l_5956[0];
                    int32_t *l_5965 = &l_5959;
                    int32_t *l_5966 = &l_5546;
                    int32_t *l_5967[2][7] = {{&l_5595[6][6][0],&l_5595[6][6][0],&l_5812,&l_5915[3][1],&l_5812,&l_5595[6][6][0],&l_5595[6][6][0]},{&l_5595[6][6][0],&l_5812,&l_5915[3][1],&l_5812,&l_5595[6][6][0],&l_5595[6][6][0],&l_5812}};
                    int i, j;
                    l_5906--;
                    for (g_174 = 0; (g_174 <= 3); g_174 += 1)
                    { /* block id: 2626 */
                        int64_t l_5921 = 0xD8AB6899E34FCDD5LL;
                        const uint32_t **l_5926 = &g_2465;
                        uint8_t l_5947[4][9] = {{247UL,247UL,0x06L,247UL,247UL,0x06L,247UL,247UL,0x06L},{255UL,255UL,0xECL,255UL,255UL,0xECL,255UL,255UL,0xECL},{247UL,247UL,0x06L,247UL,247UL,0x06L,247UL,247UL,0x06L},{255UL,255UL,0xECL,255UL,255UL,0xECL,255UL,255UL,0xECL}};
                        int16_t *l_5954 = (void*)0;
                        int16_t *l_5955[7];
                        int32_t l_5957[6][10][4] = {{{0x4964AF01L,0xB78C5EB4L,0xD11BC910L,0x969D9C92L},{0x9D8547D2L,0x6A6D9A4DL,0x4964AF01L,5L},{0x5C452D34L,0x9D8547D2L,0xE30D030BL,0x950A18C7L},{(-1L),0L,(-1L),0L},{0x0813D88AL,0x6442F3CFL,0xB097DDB0L,0x6F2FBA53L},{0x0339CFC8L,0xD7BFE813L,0x6F2FBA53L,0x9D8547D2L},{0x950A18C7L,(-1L),0x6442F3CFL,0x0C4EAE36L},{0x950A18C7L,0x7F80FE87L,0x6F2FBA53L,0x0339CFC8L},{0x0339CFC8L,0x0C4EAE36L,0xB097DDB0L,0x5C452D34L},{0x0813D88AL,0x5700B90BL,(-1L),0x611ACE67L}},{{(-1L),(-1L),0xE30D030BL,0xE30D030BL},{0x5C452D34L,0x5C452D34L,0x4964AF01L,0xD7BFE813L},{0x9D8547D2L,0x5667B278L,0xD11BC910L,0x6A6D9A4DL},{0x4964AF01L,0x8DB309B5L,0L,0xD11BC910L},{0x7F80FE87L,0x8DB309B5L,5L,0x6A6D9A4DL},{0x8DB309B5L,0x5667B278L,0x611ACE67L,0xD7BFE813L},{0x76F778AAL,0x5C452D34L,0x9D8547D2L,0xE30D030BL},{5L,(-1L),0xB78C5EB4L,0x611ACE67L},{0x5667B278L,0x5700B90BL,0x5667B278L,0x5C452D34L},{0x611ACE67L,0x0C4EAE36L,(-1L),0x0339CFC8L}},{{0L,0x7F80FE87L,0xEE540E2AL,0x0C4EAE36L},{0x2BB26804L,(-1L),0xEE540E2AL,0x9D8547D2L},{0L,0xD7BFE813L,(-1L),0x6F2FBA53L},{0x611ACE67L,0x6442F3CFL,0x5667B278L,0L},{0x5667B278L,0L,0xB78C5EB4L,0x950A18C7L},{5L,0x9D8547D2L,0x9D8547D2L,5L},{0x0339CFC8L,0xD11BC910L,0xEE540E2AL,0x6F2FBA53L},{0x4964AF01L,0xB097DDB0L,0xB78C5EB4L,0x5667B278L},{(-1L),0x5C452D34L,0x2BB26804L,0x5667B278L},{(-1L),0xB097DDB0L,5L,0x6F2FBA53L}},{{0x950A18C7L,0xD11BC910L,(-1L),0xB78C5EB4L},{0x969D9C92L,0x950A18C7L,0x76F778AAL,0xD7BFE813L},{0x611ACE67L,0x2BB26804L,0x6A6D9A4DL,0x2BB26804L},{0x5700B90BL,0x5667B278L,0x5C452D34L,0x6442F3CFL},{0x9D8547D2L,0x7F80FE87L,0x6442F3CFL,0x950A18C7L},{0xD7BFE813L,0x611ACE67L,0x5667B278L,0x8DB309B5L},{0xD7BFE813L,(-1L),0x6442F3CFL,0x9D8547D2L},{0x9D8547D2L,0x8DB309B5L,0x5C452D34L,0x969D9C92L},{0x5700B90BL,0xE30D030BL,0x6A6D9A4DL,0xEE540E2AL},{0x611ACE67L,0x6A6D9A4DL,0x76F778AAL,0x76F778AAL}},{{0x969D9C92L,0x969D9C92L,(-1L),0x7F80FE87L},{0x950A18C7L,0x0C4EAE36L,5L,0xD11BC910L},{(-1L),0x4964AF01L,0x2BB26804L,5L},{(-1L),0x4964AF01L,0xB78C5EB4L,0xD11BC910L},{0x4964AF01L,0x0C4EAE36L,0xEE540E2AL,0x7F80FE87L},{0x0339CFC8L,0x969D9C92L,0x950A18C7L,0x76F778AAL},{0xB78C5EB4L,0x6A6D9A4DL,0xB097DDB0L,0xEE540E2AL},{0x0C4EAE36L,0xE30D030BL,0x0C4EAE36L,0x969D9C92L},{0xEE540E2AL,0x8DB309B5L,0x611ACE67L,0x9D8547D2L},{0x2BB26804L,(-1L),0xF5481E47L,0x8DB309B5L}},{{0x0813D88AL,0x611ACE67L,0xF5481E47L,0x950A18C7L},{0x2BB26804L,0x7F80FE87L,0x611ACE67L,0x6442F3CFL},{0xEE540E2AL,0x5667B278L,0x0C4EAE36L,0x2BB26804L},{0x0C4EAE36L,0x2BB26804L,0xB097DDB0L,0xD7BFE813L},{0xB78C5EB4L,0x950A18C7L,0x950A18C7L,0xB78C5EB4L},{0x0339CFC8L,0xD11BC910L,0xEE540E2AL,0x6F2FBA53L},{0x4964AF01L,0xB097DDB0L,0xB78C5EB4L,0x5667B278L},{(-1L),0x5C452D34L,0x2BB26804L,0x5667B278L},{(-1L),0xB097DDB0L,5L,0x6F2FBA53L},{0x950A18C7L,0xD11BC910L,(-1L),0xB78C5EB4L}}};
                        int32_t l_5958 = 0L;
                        int i, j, k;
                        for (i = 0; i < 7; i++)
                            l_5955[i] = &g_76[0][4];
                        l_5812 = (((l_5905 > ((*g_4007) == (l_5909[5] , l_5910))) != 0x10D51D4CL) < (safe_mod_func_int64_t_s_s((safe_mod_func_int32_t_s_s(l_5872[4], (l_5915[5][1] |= 0x03A83EFCL))), ((**g_3998) ^= (0x95L && ((safe_unary_minus_func_int32_t_s(l_5909[4])) , 0UL))))));
                        (**g_3660) = ((safe_sub_func_int16_t_s_s(((l_5921 , l_5906) < ((safe_mod_func_int64_t_s_s((safe_div_func_uint32_t_u_u((((((l_5927 = ((*g_161) , &l_5900)) == (void*)0) < (l_5906 <= ((((****g_4384) = l_5901) & 9L) | l_5921))) , 0x30L) < l_5851), l_5851)), (****g_4722))) == l_5929)), 65528UL)) , l_5927);
                        l_5959 = (((safe_rshift_func_int64_t_s_u((safe_mul_func_uint64_t_u_u(((*g_756) = 0x16D0F831EE92CC22LL), ((safe_mod_func_int64_t_s_s(((l_5936 != (void*)0) == (safe_div_func_int64_t_s_s((l_5958 = (l_5957[3][7][1] = ((*l_22) = (+(safe_rshift_func_uint64_t_u_u(2UL, ((((((safe_div_func_int32_t_s_s((l_5946 != (**g_4937)), (l_5947[3][1] = l_5898))) > (l_5956[0] |= (safe_div_func_uint16_t_u_u((*g_168), ((safe_div_func_uint8_t_u_u(((l_5872[1] &= (((safe_div_func_uint64_t_u_u((l_5812 |= ((*l_5936) == &g_3877)), l_5811)) , (*g_3203)) , l_5921)) <= l_5811), 0x46L)) ^ l_5906))))) | l_5851) <= 0x5D884EF1L) > (*g_1966)) || 0x7B5B8E2A91254E3ELL))))))), l_5921))), l_5906)) & 0xEAL))), l_5900)) && l_5957[5][8][3]) ^ l_5906);
                    }
                    ++l_5968;
                }
                for (g_5231 = 0; (g_5231 != 34); g_5231++)
                { /* block id: 2647 */
                    uint32_t l_5977[9] = {0x01F5B82CL,0x01F5B82CL,0x01F5B82CL,0x01F5B82CL,0x01F5B82CL,0x01F5B82CL,0x01F5B82CL,0x01F5B82CL,0x01F5B82CL};
                    const int16_t l_5982 = (-4L);
                    int64_t *l_6003 = &g_5899[2][0][0];
                    int32_t *l_6004 = &g_156[5];
                    int i;
                    l_5959 = (((+(l_5974 | (safe_mod_func_uint32_t_u_u(0x16AFE441L, l_5977[1])))) || (safe_mul_func_int16_t_s_s(((safe_rshift_func_uint64_t_u_s(l_5900, (l_5982 & ((-1L) | (g_76[0][4] = (safe_mul_func_uint8_t_u_u((safe_sub_func_int32_t_s_s((0UL & (safe_mul_func_uint32_t_u_u((l_6002 = (((safe_div_func_uint32_t_u_u(((safe_rshift_func_int64_t_s_u((l_5812 &= ((safe_mod_func_int64_t_s_s(((((0xCDB0C80EE383FF49LL >= (safe_mod_func_uint64_t_u_u(((safe_unary_minus_func_uint64_t_u((safe_mul_func_uint64_t_u_u((safe_div_func_int64_t_s_s(l_5898, l_5905)), 0xF750CA5F894FF758LL)))) || 18446744073709551606UL), 0x10848E28E86E663BLL))) , l_5982) , l_5959) <= 4294967295UL), 0xEFF1FFA06610D34ALL)) == l_5900)), 61)) , 4294967292UL), 0x8E763DA2L)) & 0x52101CE5L) >= (*g_1966))), (-1L)))), l_5977[1])), 0xE4L))))))) , (**g_3270)), (-1L)))) | (**g_160));
                    (**g_3479) = l_6004;
                }
                (*l_5775) = (*l_5775);
                l_6006++;
            }
        }
        (**g_3660) = &l_5872[4];
        for (g_4174 = (-29); (g_4174 > (-23)); g_4174 = safe_add_func_int64_t_s_s(g_4174, 2))
        { /* block id: 2661 */
            uint16_t l_6011[8] = {0xA111L,0xA111L,8UL,0xA111L,0xA111L,8UL,0xA111L,0xA111L};
            int16_t ****l_6012 = &l_5887;
            int16_t *****l_6013[5][8] = {{&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012},{&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012},{&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012},{&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012},{&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012,&l_6012}};
            uint8_t l_6019[1][7] = {{0UL,0UL,1UL,0UL,0UL,1UL,0UL}};
            uint8_t l_6024[9] = {4UL,1UL,1UL,4UL,1UL,1UL,4UL,1UL,1UL};
            int32_t l_6026 = 0xB06D31A0L;
            uint16_t **l_6036 = &g_161;
            const uint32_t *l_6045 = &g_6046;
            int64_t l_6047 = 0x73227355D34156A4LL;
            int i, j;
            l_6026 &= ((l_6011[4] != ((g_6014 = l_6012) == ((safe_mul_func_int32_t_s_s((l_5872[0] >= (((((safe_add_func_int8_t_s_s((((*g_3271) , (((l_6019[0][3] <= l_6011[4]) | l_5757[7][2][1]) <= (safe_rshift_func_uint8_t_u_u(((*l_5676) = ((safe_add_func_int16_t_s_s(0x4F65L, (l_6024[3] && l_6025[0]))) ^ l_6011[4])), 2)))) , (*g_1966)), l_5872[0])) ^ l_6011[6]) || l_6019[0][3]) <= 0x51L) == l_6025[0])), l_6024[4])) , &g_3877))) , 1L);
            (**g_3660) = &l_5872[2];
            for (g_78 = 0; (g_78 <= 3); g_78 += 1)
            { /* block id: 2668 */
                int32_t *****l_6035 = (void*)0;
                int32_t l_6049[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_6049[i] = (-8L);
                l_5956[1] = l_5746[1][4][3];
                for (l_5592 = 0; l_5592 < 8; l_5592 += 1)
                {
                    l_6011[l_5592] = 0UL;
                }
                l_5956[2] = ((safe_sub_func_uint32_t_u_u((((*g_756) > ((**g_4722) == (void*)0)) && (safe_sub_func_int64_t_s_s((safe_sub_func_int16_t_s_s((l_6033 == ((l_6034 ^ (l_6035 != (void*)0)) , l_6036)), (0xEB02L | 0L))), (-8L)))), 0xAAD3E4ACL)) || (*g_1966));
                for (g_4521 = 0; (g_4521 >= 0); g_4521 -= 1)
                { /* block id: 2674 */
                    const int32_t l_6039 = 0xCDE1E5C9L;
                    int32_t *l_6042 = (void*)0;
                    int32_t *l_6043 = &l_5956[0];
                    uint32_t l_6048 = 4294967292UL;
                    int i, j;
                    if (((safe_mul_func_int64_t_s_s(l_6039, (l_6040 , (((****g_4722) >= (((*l_6043) |= ((void*)0 != l_6041)) > (((l_6044 = l_6043) == (l_6045 = l_6043)) != l_5746[1][3][0]))) , ((l_6048 = (l_6047 ^ l_5810)) , l_6011[7]))))) | l_6049[0]))
                    { /* block id: 2679 */
                        int i;
                        g_348[g_4521] = &l_6026;
                        (*l_6043) &= l_5898;
                        (*l_6043) = l_6011[4];
                    }
                    else
                    { /* block id: 2683 */
                        (*l_6043) = (*g_861);
                    }
                }
            }
        }
    }
    return (*g_1966);
}


/* ------------------------------------------ */
/* 
 * reads : g_1120 g_1121 g_160 g_161 g_74 g_3729 g_47 g_1077 g_1078 g_3270 g_3271 g_1956 g_1542 g_652 g_1509 g_3479 g_1043 g_1966 g_1670 g_48 g_755 g_756 g_140 g_1621 g_156 g_732 g_3203 g_4383 g_794 g_52 g_3215 g_174 g_4007 g_4008 g_1326 g_1327 g_582 g_3911 g_4174 g_51 g_737 g_116 g_670 g_168 g_636 g_78 g_3034 g_3035 g_289 g_3997 g_3998 g_4722 g_4385 g_3858 g_3859 g_694 g_695 g_696 g_242 g_179 g_3506 g_4795 g_754 g_1030 g_1031 g_1733 g_688 g_2173 g_4723 g_5095 g_23 g_3913 g_4937 g_260 g_5453 g_5454 g_5 g_1573 g_50 g_76 g_77 g_94 g_85 g_123 g_142 g_155 g_241 g_193 g_603 g_667 g_751 g_735 g_861 g_931 g_981 g_1095 g_1119 g_1207 g_1038 g_720 g_1350 g_855 g_2168 g_2272 g_1949 g_5540 g_3660 g_3490
 * writes: g_1121 g_74 g_48 g_737 g_1509 g_51 g_116 g_1670 g_732 g_981 g_720 g_156 g_193 g_4383 g_174 g_4414 g_142 g_667 g_582 g_636 g_94 g_23 g_78 g_52 g_1043 g_160 g_140 g_2989 g_4737 g_4553 g_179 g_735 g_4795 g_3506 g_1327 g_260 g_4937 g_47 g_3489 g_2173 g_1878 g_85 g_652 g_5231 g_5453 g_4008 g_1573 g_76 g_123 g_161 g_168 g_242 g_1095 g_1098 g_1207 g_241 g_1119 g_1542 g_1078 g_1120 g_1949 g_5540
 */
static uint64_t  func_8(int32_t  p_9, uint32_t  p_10, int64_t  p_11)
{ /* block id: 1933 */
    uint64_t ** const *l_4239 = &g_3998;
    int32_t l_4242 = 1L;
    uint64_t ****l_4244 = (void*)0;
    uint64_t *****l_4243 = &l_4244;
    int32_t l_4251 = 0x609F3871L;
    uint32_t l_4254[2];
    uint32_t l_4272 = 0xA8353C26L;
    int32_t ***l_4288 = &g_1043;
    int32_t l_4352[4][3][4] = {{{(-1L),0xA3D529EAL,(-1L),0xD40AC902L},{(-1L),0xD40AC902L,(-1L),0xA3D529EAL},{(-1L),0xA3D529EAL,(-1L),0xD40AC902L}},{{(-1L),0xD40AC902L,(-1L),0xA3D529EAL},{(-1L),0xA3D529EAL,(-1L),0xD40AC902L},{(-1L),0xD40AC902L,(-1L),0xA3D529EAL}},{{(-1L),0xA3D529EAL,(-1L),0xD40AC902L},{(-1L),0xD40AC902L,(-1L),0xA3D529EAL},{(-1L),0xA3D529EAL,(-1L),0xD40AC902L}},{{(-1L),0xD40AC902L,(-1L),0xA3D529EAL},{(-1L),0xA3D529EAL,(-1L),0xD40AC902L},{(-1L),0xD40AC902L,(-1L),0xA3D529EAL}}};
    uint16_t l_4357[4];
    uint16_t **l_4374 = &g_168;
    int16_t *l_4413 = &g_2989;
    int16_t **l_4412 = &l_4413;
    int16_t ***l_4411 = &l_4412;
    uint32_t *****l_4415 = (void*)0;
    const uint32_t *****l_4421 = (void*)0;
    uint32_t l_4554 = 0x8AB0F9F8L;
    uint16_t l_4629 = 1UL;
    uint8_t **l_4630 = &g_1078[1];
    uint16_t **l_4651 = &g_161;
    int32_t *l_4696 = &g_156[0];
    const int32_t **l_4715 = &g_3489;
    const int64_t ***l_4727 = &g_4094[0][4];
    const int64_t ****l_4726 = &l_4727;
    uint32_t *****l_4766 = (void*)0;
    uint8_t ** const ***l_4780 = (void*)0;
    uint32_t *l_4830 = (void*)0;
    int32_t l_4866 = (-6L);
    uint32_t l_4903[10][4][5] = {{{1UL,18446744073709551615UL,18446744073709551615UL,0UL,0x7D93D1BEL},{1UL,0x6DC629D4L,0x5F794976L,0x5F794976L,0x6DC629D4L},{0UL,18446744073709551615UL,0xADA17A87L,0UL,0x24565B4DL},{1UL,0UL,0x5F794976L,0x5698F180L,0x6DC629D4L}},{{1UL,18446744073709551615UL,18446744073709551615UL,0UL,0x7D93D1BEL},{1UL,0x6DC629D4L,0x5F794976L,0x5F794976L,0x6DC629D4L},{0UL,18446744073709551615UL,0xADA17A87L,0UL,0x24565B4DL},{1UL,0UL,0x5F794976L,0x5698F180L,0x6DC629D4L}},{{1UL,18446744073709551615UL,18446744073709551615UL,0UL,0x7D93D1BEL},{1UL,0x6DC629D4L,0x5F794976L,0x5F794976L,0x6DC629D4L},{0UL,18446744073709551615UL,0xADA17A87L,0UL,0x24565B4DL},{1UL,0UL,0x5F794976L,0x5698F180L,0x6DC629D4L}},{{1UL,18446744073709551615UL,18446744073709551615UL,0UL,0x7D93D1BEL},{1UL,0x6DC629D4L,0x5F794976L,0x5F794976L,0x6DC629D4L},{0UL,18446744073709551615UL,0xADA17A87L,0UL,0x24565B4DL},{1UL,0UL,0x5F794976L,0x5698F180L,0x6DC629D4L}},{{1UL,18446744073709551615UL,18446744073709551615UL,0UL,0x7D93D1BEL},{1UL,0x6DC629D4L,0x5F794976L,0x5F794976L,0x6DC629D4L},{0UL,18446744073709551615UL,0xADA17A87L,0UL,0x24565B4DL},{1UL,0UL,0x5F794976L,0x5698F180L,0x6DC629D4L}},{{1UL,18446744073709551615UL,18446744073709551615UL,0UL,0x7D93D1BEL},{1UL,0x6DC629D4L,0x5F794976L,0x5F794976L,0x6DC629D4L},{0UL,18446744073709551615UL,0xADA17A87L,0UL,0x24565B4DL},{1UL,0UL,0x5F794976L,0x5698F180L,0x6DC629D4L}},{{1UL,18446744073709551615UL,18446744073709551615UL,0UL,18446744073709551608UL},{0UL,0UL,0UL,0UL,0UL},{1UL,5UL,0x24565B4DL,18446744073709551615UL,1UL},{0UL,4UL,0UL,0x6DC629D4L,0UL}},{{1UL,5UL,0x7D93D1BEL,18446744073709551615UL,18446744073709551608UL},{0UL,0UL,0UL,0UL,0UL},{1UL,5UL,0x24565B4DL,18446744073709551615UL,1UL},{0UL,4UL,0UL,0x6DC629D4L,0UL}},{{1UL,5UL,0x7D93D1BEL,18446744073709551615UL,18446744073709551608UL},{0UL,0UL,0UL,0UL,0UL},{1UL,5UL,0x24565B4DL,18446744073709551615UL,1UL},{0UL,4UL,0UL,0x6DC629D4L,0UL}},{{1UL,5UL,0x7D93D1BEL,18446744073709551615UL,18446744073709551608UL},{0UL,0UL,0UL,0UL,0UL},{1UL,5UL,0x24565B4DL,18446744073709551615UL,1UL},{0UL,4UL,0UL,0x6DC629D4L,0UL}}};
    uint16_t ** const *l_4905 = &l_4651;
    uint16_t ** const **l_4904 = &l_4905;
    int8_t **l_5255[5][1];
    uint16_t l_5256 = 0UL;
    int32_t l_5363[7][3][3] = {{{0L,1L,1L},{0x58A8D3B1L,1L,(-5L)},{(-1L),0L,0x567BC307L}},{{0x58A8D3B1L,0x58A8D3B1L,0x567BC307L},{0L,(-1L),(-5L)},{1L,0x58A8D3B1L,1L}},{{1L,0L,0x58A8D3B1L},{0L,1L,1L},{0x58A8D3B1L,1L,(-5L)}},{{(-1L),0L,0x567BC307L},{0x58A8D3B1L,0x58A8D3B1L,0x567BC307L},{0L,(-1L),(-5L)}},{{1L,0x58A8D3B1L,1L},{1L,0L,0x58A8D3B1L},{0L,1L,1L}},{{0x58A8D3B1L,1L,(-5L)},{(-1L),0L,0x567BC307L},{0x58A8D3B1L,0x58A8D3B1L,0x567BC307L}},{{0L,(-1L),(-5L)},{1L,0x58A8D3B1L,1L},{1L,0L,0x58A8D3B1L}}};
    uint16_t l_5394 = 0x136DL;
    int32_t l_5403 = 0xDCCAEF88L;
    const int8_t l_5437 = 6L;
    uint16_t l_5533 = 0x8738L;
    int32_t *l_5536 = &g_52;
    int32_t *l_5537 = &g_156[1];
    int32_t *l_5538[3][5] = {{&l_4352[2][1][1],&l_4352[2][1][1],&g_1121,&l_4352[2][1][1],&l_4352[2][1][1]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_4352[2][1][1],(void*)0,(void*)0,&l_4352[2][1][1],(void*)0}};
    int32_t l_5539 = (-1L);
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_4254[i] = 4294967287UL;
    for (i = 0; i < 4; i++)
        l_4357[i] = 1UL;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
            l_5255[i][j] = (void*)0;
    }
    if ((safe_div_func_uint8_t_u_u(((**g_1077) = (((void*)0 != l_4239) >= ((**g_3729) = (((safe_mod_func_uint8_t_u_u(l_4242, 0x34L)) != ((*g_1120) |= ((void*)0 == l_4243))) < (safe_sub_func_int16_t_s_s(6L, ((l_4251 = ((**g_160) &= (safe_sub_func_uint32_t_u_u((((safe_mod_func_int32_t_s_s(l_4242, l_4242)) && p_9) , l_4242), 0L)))) ^ l_4242))))))), 5UL)))
    { /* block id: 1939 */
        uint8_t l_4269 = 0UL;
        uint16_t ***l_4283 = &g_160;
        int32_t l_4303[5][2] = {{0x1E40935AL,0x1E40935AL},{3L,0x1E40935AL},{0x1E40935AL,3L},{0x1E40935AL,0x1E40935AL},{3L,0x1E40935AL}};
        int16_t l_4335 = 0x1AA2L;
        int16_t *l_4339 = (void*)0;
        int16_t **l_4338 = &l_4339;
        int16_t ***l_4337 = &l_4338;
        const uint64_t l_4399 = 18446744073709551606UL;
        uint32_t **l_4461[9][5][4] = {{{(void*)0,&g_1327,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1327,&g_1327},{&g_1327,(void*)0,(void*)0,&g_1327},{&g_1327,&g_1327,&g_1327,&g_1327},{&g_1327,(void*)0,(void*)0,&g_1327}},{{(void*)0,(void*)0,&g_1327,(void*)0},{&g_1327,&g_1327,(void*)0,&g_1327},{&g_1327,(void*)0,&g_1327,(void*)0},{(void*)0,&g_1327,&g_1327,&g_1327},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_1327,&g_1327},{&g_1327,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,&g_1327,&g_1327},{(void*)0,&g_1327,&g_1327,&g_1327},{&g_1327,(void*)0,(void*)0,(void*)0}},{{&g_1327,(void*)0,&g_1327,&g_1327},{&g_1327,&g_1327,&g_1327,(void*)0},{&g_1327,(void*)0,(void*)0,&g_1327},{&g_1327,&g_1327,&g_1327,(void*)0},{&g_1327,&g_1327,&g_1327,&g_1327}},{{&g_1327,&g_1327,(void*)0,(void*)0},{(void*)0,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,&g_1327,(void*)0},{&g_1327,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,(void*)0,(void*)0}},{{&g_1327,&g_1327,&g_1327,&g_1327},{(void*)0,(void*)0,(void*)0,&g_1327},{(void*)0,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,(void*)0,&g_1327},{&g_1327,(void*)0,&g_1327,&g_1327}},{{&g_1327,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,&g_1327,&g_1327},{(void*)0,&g_1327,(void*)0,&g_1327},{&g_1327,(void*)0,&g_1327,(void*)0},{&g_1327,&g_1327,&g_1327,&g_1327}},{{&g_1327,&g_1327,(void*)0,&g_1327},{&g_1327,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,(void*)0,&g_1327},{&g_1327,&g_1327,&g_1327,(void*)0}},{{(void*)0,&g_1327,&g_1327,&g_1327},{&g_1327,&g_1327,&g_1327,(void*)0},{&g_1327,&g_1327,&g_1327,&g_1327},{(void*)0,&g_1327,(void*)0,&g_1327},{(void*)0,&g_1327,&g_1327,&g_1327}}};
        int64_t *l_4495 = &g_142;
        uint64_t ** const **l_4502 = &g_4385;
        uint8_t l_4593 = 0x23L;
        int i, j, k;
lbl_4598:
        if ((0x8878L <= (**g_3270)))
        { /* block id: 1940 */
            int16_t l_4270 = 0x6F29L;
            uint16_t *l_4271 = &g_1509[1];
            int32_t *l_4273[4][9] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_85,&g_85,&g_156[4],&g_156[4],&g_85,&g_85,&g_156[4],&g_156[4],&g_85},{&l_4251,(void*)0,&l_4251,(void*)0,&l_4251,(void*)0,&l_4251,(void*)0,&l_4251},{&g_85,&g_156[4],&g_156[4],&g_85,&g_85,&g_156[4],&g_156[4],&g_85,&g_85}};
            int i, j;
            (**g_3479) = (((l_4272 = ((*l_4271) |= ((safe_rshift_func_uint8_t_u_u(0UL, (p_10 , 0x6AL))) ^ (l_4254[1] ^ (safe_rshift_func_uint64_t_u_u((((**g_3729) = (safe_lshift_func_uint8_t_u_u(((**g_1077) = (safe_mod_func_int32_t_s_s((safe_sub_func_uint16_t_u_u((****g_1542), ((safe_mod_func_int32_t_s_s((safe_sub_func_int64_t_s_s((p_11 & (safe_add_func_uint64_t_u_u((l_4269 && l_4269), l_4270))), 0UL)), p_9)) , l_4269))), p_9))), p_11))) < p_11), 42)))))) > l_4251) , l_4273[3][0]);
            for (g_116 = 0; (g_116 == 22); ++g_116)
            { /* block id: 1948 */
                uint16_t ** const *l_4282 = &g_160;
                uint32_t l_4297[3][3] = {{18446744073709551615UL,0x0D0AC70DL,18446744073709551615UL},{0x0D0AC70DL,18446744073709551615UL,18446744073709551615UL},{0x0D0AC70DL,18446744073709551615UL,18446744073709551615UL}};
                int i, j;
                (*g_1120) &= (((*g_1966) = (safe_mod_func_uint8_t_u_u((((1L <= (safe_lshift_func_uint32_t_u_s(((((7L < (safe_lshift_func_int8_t_s_u(l_4269, 5))) , 0UL) , l_4282) != l_4283), (safe_mod_func_uint8_t_u_u((((+(~((void*)0 != l_4288))) == (safe_mod_func_uint32_t_u_u((((safe_mul_func_int16_t_s_s((((((safe_mul_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u(((l_4269 != 65534UL) != (*g_1966)), l_4297[2][2])), (-3L))) != (*g_1966)) , 0UL) > 0x0C3A6A623BA50F9DLL) ^ p_10), p_11)) & l_4269) , 1UL), p_9))) && p_10), p_11))))) , l_4269) ^ p_11), p_10))) < p_10);
            }
            for (l_4272 = 28; (l_4272 != 8); --l_4272)
            { /* block id: 1954 */
                for (g_732 = (-16); (g_732 > 15); ++g_732)
                { /* block id: 1957 */
                    int8_t l_4302 = 7L;
                    if (l_4302)
                        break;
                    return p_9;
                }
                l_4242 = (l_4303[1][1] && (**g_3729));
            }
        }
        else
        { /* block id: 1963 */
            uint32_t l_4321 = 0xCC3C3B67L;
            int16_t * const **l_4336 = (void*)0;
            int32_t l_4345 = 0x7AE41334L;
            int32_t l_4346 = 0xE8FE8261L;
            int32_t l_4350 = (-1L);
            int32_t l_4351 = 0x58689CBCL;
            int32_t l_4353 = 0xB86988B5L;
            int32_t l_4354 = (-10L);
            int32_t l_4356 = 0x85F2079DL;
            uint8_t *l_4429 = &g_116;
            int32_t *l_4450[4][3] = {{&g_2075,&g_2075,&g_2075},{&g_2075,(void*)0,(void*)0},{&g_2075,&g_2075,&g_2075},{&g_2075,(void*)0,(void*)0}};
            int32_t **l_4451 = &l_4450[2][2];
            uint32_t l_4471 = 18446744073709551615UL;
            int32_t l_4550 = 0x8602933DL;
            int32_t l_4551[7];
            uint32_t l_4560 = 0xD17818C0L;
            uint64_t *** const **l_4590 = &g_3996[2];
            int32_t l_4591 = (-9L);
            int i, j;
            for (i = 0; i < 7; i++)
                l_4551[i] = 0xD9D2A674L;
            for (g_981 = 0; (g_981 <= 1); g_981 += 1)
            { /* block id: 1966 */
                int16_t l_4306 = 1L;
                int32_t l_4341 = 0xF334C7E1L;
                int32_t l_4342 = 0xB54F9A59L;
                int32_t l_4347 = 1L;
                int32_t l_4348 = 2L;
                int32_t l_4349 = 0xA2596535L;
                int32_t l_4355 = 0xBAEB6A77L;
                uint32_t l_4439 = 0x8D9B3650L;
                for (l_4272 = 0; (l_4272 <= 2); l_4272 += 1)
                { /* block id: 1969 */
                    if (p_10)
                        break;
                }
                if (p_11)
                { /* block id: 1972 */
                    int i;
                    (*g_1120) = (((safe_mul_func_uint8_t_u_u(p_9, l_4306)) > ((**g_1077) = p_11)) != (safe_add_func_int16_t_s_s(((0x1218FFF3L || ((p_10 , ((safe_add_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_s((safe_add_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((safe_mod_func_uint32_t_u_u(l_4321, 0xB76B5FBEL)) >= ((**g_3729) = (l_4321 <= ((**g_755) , p_10)))), 0xA01013A1L)), 0UL)), 5)), l_4303[1][1])), 0x61L)) && p_11)) == p_9)) >= p_11), p_11)));
                }
                else
                { /* block id: 1976 */
                    int64_t *l_4322[4][5][10] = {{{&g_48[1][0][1],&g_142,(void*)0,(void*)0,&g_48[2][2][0],&g_23,(void*)0,&g_142,&g_23,&g_48[2][1][0]},{&g_48[0][1][0],&g_48[0][1][0],(void*)0,&g_23,&g_23,&g_23,(void*)0,&g_23,(void*)0,&g_48[2][0][1]},{&g_48[1][0][1],&g_23,&g_142,&g_23,(void*)0,(void*)0,&g_23,&g_142,&g_23,&g_48[1][0][1]},{&g_48[2][0][1],(void*)0,&g_23,(void*)0,&g_23,&g_23,&g_23,(void*)0,&g_48[0][1][0],&g_48[0][1][0]},{&g_48[2][1][0],&g_23,&g_142,(void*)0,&g_23,&g_48[2][2][0],(void*)0,(void*)0,&g_142,&g_48[1][0][1]}},{{&g_23,&g_23,&g_48[2][2][1],&g_23,(void*)0,&g_23,&g_48[2][2][1],&g_23,&g_23,&g_48[2][0][1]},{&g_23,&g_142,&g_48[0][1][0],(void*)0,&g_23,(void*)0,&g_142,&g_48[2][2][0],(void*)0,&g_48[2][1][0]},{&g_23,&g_48[2][1][0],(void*)0,(void*)0,&g_48[2][2][0],&g_48[0][1][0],&g_48[3][2][1],&g_48[0][1][0],&g_23,&g_23},{&g_23,&g_48[2][2][0],&g_48[1][2][0],&g_23,&g_23,&g_48[1][2][0],&g_48[2][2][0],&g_23,&g_142,&g_23},{&g_23,&g_23,&g_142,(void*)0,(void*)0,&g_48[1][0][1],&g_142,&g_142,&g_48[0][1][0],&g_23}},{{&g_48[0][1][0],&g_48[1][2][0],&g_142,(void*)0,&g_48[0][1][0],&g_142,&g_23,&g_23,&g_23,&g_23},{&g_142,&g_142,&g_48[1][2][0],&g_23,&g_48[1][2][0],&g_142,&g_142,&g_48[0][1][0],(void*)0,&g_23},{(void*)0,&g_48[3][2][1],(void*)0,&g_23,&g_48[1][0][1],&g_48[2][2][1],&g_142,&g_48[2][2][0],&g_23,&g_48[0][1][0]},{&g_48[2][2][0],&g_48[3][2][1],&g_48[0][1][0],(void*)0,&g_142,(void*)0,&g_142,&g_23,&g_23,&g_142},{&g_48[0][1][0],&g_142,&g_48[2][2][1],&g_48[2][2][1],&g_142,&g_48[0][1][0],&g_23,(void*)0,&g_142,(void*)0}},{{&g_23,&g_48[1][2][0],&g_142,&g_142,&g_48[2][2][1],&g_48[0][1][0],&g_142,(void*)0,&g_48[2][1][0],&g_48[2][2][0]},{&g_23,&g_23,&g_23,&g_48[3][2][1],(void*)0,&g_48[0][1][0],&g_48[2][2][0],&g_142,&g_48[2][2][0],&g_48[0][1][0]},{&g_48[0][1][0],&g_48[0][1][0],(void*)0,&g_48[0][1][0],&g_23,&g_48[2][2][0],&g_48[2][1][0],(void*)0,&g_142,&g_48[0][1][0]},{&g_48[0][1][0],&g_142,(void*)0,&g_23,&g_48[0][1][0],&g_48[2][0][1],&g_23,&g_48[1][2][0],(void*)0,&g_48[0][1][0]},{&g_23,&g_23,&g_23,(void*)0,&g_23,(void*)0,&g_48[2][0][1],&g_48[2][0][1],(void*)0,&g_23}}};
                    int8_t *l_4333 = &g_720;
                    int32_t l_4334 = 0x4B19561FL;
                    int16_t *l_4340 = &g_732;
                    int32_t *l_4343 = &g_156[4];
                    int32_t *l_4344[3][4] = {{&l_4341,(void*)0,(void*)0,(void*)0},{&l_4303[1][1],&l_4303[1][1],&l_4341,(void*)0},{(void*)0,(void*)0,(void*)0,&l_4341}};
                    int i, j, k;
                    (*g_3203) = ((*g_1966) ^ (((l_4322[0][1][9] = (*g_3729)) == (l_4303[1][1] , &p_11)) && ((*l_4340) ^= ((((((((**g_3729) = p_11) == (((((safe_sub_func_int8_t_s_s(((safe_rshift_func_int32_t_s_s(((safe_mod_func_uint64_t_u_u(((((safe_add_func_int8_t_s_s(p_11, ((*l_4333) = p_9))) <= (l_4321 < l_4334)) & l_4321) , (*g_756)), p_9)) >= (*g_1621)), l_4334)) , (-6L)), (*g_1966))) , l_4306) || 0xB1F785DFL) , l_4303[1][1]) != p_11)) > l_4334) , p_9) , l_4335) , l_4336) == l_4337))));
                    l_4357[2]++;
                }
                for (g_193 = 0; (g_193 <= 2); g_193 += 1)
                { /* block id: 1986 */
                    int32_t ***l_4364 = &g_241[3][2];
                    int32_t l_4404 = 8L;
                    const uint32_t *l_4420 = &g_174;
                    const uint32_t **l_4419 = &l_4420;
                    const uint32_t ***l_4418 = &l_4419;
                    const uint32_t ****l_4417 = &l_4418;
                    const uint32_t *****l_4416 = &l_4417;
                    for (l_4350 = 2; (l_4350 >= 0); l_4350 -= 1)
                    { /* block id: 1989 */
                        uint16_t * const **l_4367 = (void*)0;
                        uint16_t * const **l_4368 = (void*)0;
                        uint16_t * const l_4370 = &g_4371;
                        uint16_t * const *l_4369 = &l_4370;
                        uint16_t **l_4373[9] = {&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161};
                        uint16_t ***l_4372[7] = {&l_4373[4],&l_4373[4],&g_160,&l_4373[4],&l_4373[4],&g_160,&l_4373[4]};
                        int32_t l_4386 = 9L;
                        uint8_t *l_4387[5][9][5] = {{{&g_3506,&l_4269,&g_3506,&g_1573,(void*)0},{&g_5[3][0],&l_4269,&l_4269,&g_1573,&g_3506},{&g_5[3][0],(void*)0,&g_981,&g_116,&g_5[5][0]},{&l_4269,&g_1573,&l_4269,(void*)0,(void*)0},{&g_5[1][0],&g_116,&g_5[0][0],&g_981,&l_4269},{&g_3506,&g_1573,(void*)0,&g_3506,(void*)0},{&g_3506,(void*)0,(void*)0,(void*)0,&g_981},{&g_1573,(void*)0,&l_4269,&g_981,&g_3506},{&g_1573,&g_5[3][0],&g_5[5][0],&g_1573,&g_3506}},{{&g_116,&g_5[1][0],&g_981,&g_981,&g_3506},{(void*)0,&g_116,&g_5[3][0],&g_1573,&g_3506},{(void*)0,&g_1573,&g_5[3][0],&g_116,&g_981},{(void*)0,&g_5[3][0],(void*)0,&g_116,(void*)0},{(void*)0,&g_5[3][0],&l_4269,&g_5[3][0],&l_4269},{&g_5[4][0],&g_981,&g_981,&g_3506,(void*)0},{&g_981,&g_3506,&g_5[3][0],&l_4269,&g_5[5][0]},{&g_5[3][0],(void*)0,&g_1573,&g_5[3][0],&g_3506},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_981,&g_981,&l_4269,&g_1573,&l_4269},{&l_4269,&g_3506,&g_5[5][0],&l_4269,&g_981},{&g_1573,&g_1573,&g_116,&g_1573,&g_981},{&l_4269,&l_4269,&g_1573,(void*)0,&l_4269},{&g_3506,&g_116,&g_1573,&g_5[3][0],(void*)0},{(void*)0,&g_5[3][0],&g_5[3][0],&l_4269,&g_1573},{&g_981,&g_5[4][0],(void*)0,&g_3506,&g_5[3][0]},{(void*)0,&g_116,&g_1573,&g_5[3][0],&l_4269},{&g_981,&l_4269,&g_116,&g_116,&g_3506}},{{&g_981,&g_5[4][0],&g_116,&g_1573,(void*)0},{&g_5[3][0],&g_5[3][0],&g_5[4][0],(void*)0,&l_4269},{&g_3506,&g_5[4][0],&l_4269,&g_1573,(void*)0},{(void*)0,&l_4269,&l_4269,(void*)0,&g_116},{&g_5[3][0],&g_116,&g_5[4][0],(void*)0,(void*)0},{&g_5[3][0],&l_4269,&g_116,(void*)0,&g_5[4][0]},{&g_5[3][0],&g_1573,&g_1573,&l_4269,&l_4269},{(void*)0,&g_1573,&g_5[0][0],&l_4269,&g_3506},{(void*)0,&g_1573,&g_5[3][0],&g_5[3][0],(void*)0}},{{&l_4269,&l_4269,&g_116,&g_116,&l_4269},{&g_5[5][0],&l_4269,(void*)0,&g_981,(void*)0},{&g_116,&g_116,(void*)0,&g_981,&g_3506},{&g_3506,&g_3506,&g_5[3][0],&g_5[3][0],&g_5[3][0]},{&g_3506,&g_1573,&l_4269,&l_4269,&g_5[3][0]},{&g_5[3][0],&g_3506,&g_1573,&g_1573,&g_981},{&g_3506,&g_116,&g_981,&g_5[1][0],&g_5[4][0]},{&g_1573,&l_4269,&g_116,&l_4269,&g_981},{&g_3506,&l_4269,&l_4269,&l_4269,&g_5[1][0]}}};
                        int i, j, k;
                        l_4303[1][1] = (safe_add_func_uint64_t_u_u((((**g_3729) |= ((0xA7EDC650L || l_4347) < ((safe_mod_func_uint64_t_u_u((((l_4364 != (((safe_lshift_func_int8_t_s_s(((l_4369 = (**g_1542)) == (l_4374 = (*l_4283))), 4)) == (l_4349 = (safe_div_func_int16_t_s_s((safe_lshift_func_int64_t_s_u((((safe_mod_func_uint8_t_u_u(((**g_1077) = 0UL), (safe_mod_func_int64_t_s_s((&g_3996[2] == (g_4383[7][3] = g_4383[7][3])), p_10)))) <= l_4386) == (*g_794)), p_9)), p_11)))) , (void*)0)) <= p_11) , p_10), l_4335)) & (**g_160)))) >= p_11), p_10));
                        if (p_9)
                            continue;
                    }
                    (*g_1043) = ((safe_div_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((safe_rshift_func_int32_t_s_u((l_4348 , (((p_9 && ((!(((safe_lshift_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u((p_10 > l_4399), (safe_lshift_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u(l_4404, 14)), 0)))) > ((*g_1966) = 0x8DL)), (l_4269 < (l_4399 | ((safe_rshift_func_int8_t_s_u((safe_sub_func_int64_t_s_s((~(((*g_3215) ^= (+((((void*)0 == l_4411) > 0x05CE85E96B76304ALL) ^ 0x1BDFB768L))) , 0UL)), p_9)), 7)) | p_10))))) | p_9) , 0xCFCFL)) , p_10)) <= l_4356) >= l_4404)), (****g_4007))) | l_4351), g_3911)), g_4174)) , &l_4404);
                    if (((*g_51) |= ((l_4415 = (g_4414 = (void*)0)) != (l_4421 = l_4416))))
                    { /* block id: 2006 */
                        uint16_t l_4422 = 65535UL;
                        return l_4422;
                    }
                    else
                    { /* block id: 2008 */
                        uint8_t l_4423[6][7][3] = {{{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL},{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL}},{{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL},{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL}},{{250UL,0x57L,250UL},{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL},{3UL,0UL,0UL},{0x90L,0x57L,0x90L}},{{3UL,3UL,0UL},{250UL,0x57L,250UL},{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL},{3UL,0UL,0UL}},{{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL},{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL}},{{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL},{250UL,0x57L,250UL},{3UL,0UL,0UL},{0x90L,0x57L,0x90L},{3UL,3UL,0UL}}};
                        int32_t l_4432 = (-1L);
                        int32_t *l_4433 = (void*)0;
                        int32_t *l_4434 = (void*)0;
                        int32_t *l_4435 = &l_4356;
                        int32_t *l_4436 = &l_4345;
                        int32_t *l_4437 = &l_4352[2][0][1];
                        int32_t *l_4438[8] = {&l_4353,&l_4353,&l_4353,&l_4353,&l_4353,&l_4353,&l_4353,&l_4353};
                        int i, j, k;
                        (***l_4288) &= (8UL >= (l_4423[2][1][0] & (((safe_unary_minus_func_uint8_t_u(((**g_1077)--))) || ((void*)0 == l_4429)) , ((**g_160) && ((0L | 0xAC59L) < ((((safe_mul_func_int8_t_s_s(((((void*)0 == &g_695[1][1]) , l_4341) ^ l_4303[3][1]), (*g_1966))) , 0x43F4BD1F9A73D13ELL) <= p_10) , 0x4C255A27L))))));
                        l_4439++;
                    }
                }
            }
            if ((safe_add_func_uint32_t_u_u((safe_lshift_func_int64_t_s_u(((l_4351 = (safe_lshift_func_uint32_t_u_s(p_11, (*g_1120)))) , ((safe_div_func_int16_t_s_s((((*l_4451) = l_4450[3][2]) != &p_9), 65527UL)) , l_4399)), 20)), l_4269)))
            { /* block id: 2017 */
                (*g_1120) = p_10;
            }
            else
            { /* block id: 2019 */
                uint16_t l_4460 = 3UL;
                uint32_t l_4470 = 0xFBC30B34L;
                int32_t *l_4523 = &l_4354;
                int32_t l_4549[5] = {1L,1L,1L,1L,1L};
                int32_t l_4552[4] = {0xA80C12E5L,0xA80C12E5L,0xA80C12E5L,0xA80C12E5L};
                int i;
                for (l_4350 = 14; (l_4350 == 12); l_4350 = safe_sub_func_int8_t_s_s(l_4350, 4))
                { /* block id: 2022 */
                    uint32_t l_4472 = 0x0E8498A4L;
                    uint16_t **l_4490 = &g_168;
                    int32_t l_4503 = (-9L);
                    int32_t l_4522 = 0xB18B3BE7L;
                    int64_t *l_4536 = &g_48[0][3][0];
                }
                for (g_981 = 0; (g_981 <= 0); g_981 += 1)
                { /* block id: 2044 */
                    int32_t *l_4537 = &l_4354;
                    int32_t *l_4538 = (void*)0;
                    int32_t *l_4539 = &l_4303[2][1];
                    int32_t *l_4540 = &l_4356;
                    int32_t *l_4541 = (void*)0;
                    int32_t *l_4542 = &l_4356;
                    int32_t *l_4543 = &l_4352[2][0][1];
                    int32_t *l_4544 = &l_4242;
                    int32_t *l_4545 = &l_4303[1][1];
                    int32_t *l_4546 = &g_156[5];
                    int32_t l_4547[4][1][2] = {{{6L,6L}},{{(-1L),6L}},{{6L,(-1L)}},{{6L,6L}}};
                    int32_t *l_4548[9][5] = {{&l_4350,&g_78,&l_4350,&l_4350,&g_78},{&g_78,&l_4350,&l_4350,&g_78,&l_4350},{&g_78,&g_78,&l_4547[2][0][0],&g_78,&g_78},{&l_4350,&g_78,&l_4350,&l_4350,&g_78},{&g_78,&l_4350,&l_4350,&g_78,&l_4350},{&g_78,&g_78,&l_4547[2][0][0],&g_78,&g_78},{&l_4350,&g_78,&l_4350,&l_4350,&g_78},{&g_78,&l_4350,&l_4350,&g_78,&l_4350},{&g_78,&g_78,&l_4547[2][0][0],&g_78,&g_78}};
                    int i, j, k;
                    ++l_4554;
                    for (l_4356 = 0; (l_4356 >= 0); l_4356 -= 1)
                    { /* block id: 2048 */
                        return p_9;
                    }
                }
                for (g_142 = (-19); (g_142 <= (-2)); g_142 = safe_add_func_uint64_t_u_u(g_142, 7))
                { /* block id: 2054 */
                    int32_t *l_4559[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_4559[i] = &l_4350;
                    ++l_4560;
                }
                (**g_3479) = &l_4303[1][1];
            }
            for (g_667 = 29; (g_667 >= 13); g_667 = safe_sub_func_int8_t_s_s(g_667, 4))
            { /* block id: 2061 */
                uint32_t l_4588[6][3] = {{18446744073709551615UL,18446744073709551615UL,0xB64B5C6FL},{0x505B0BB8L,0xB64B5C6FL,0xB64B5C6FL},{0xB64B5C6FL,0xC7104272L,0xFFBEFA5FL},{0x505B0BB8L,0xC7104272L,0x505B0BB8L},{18446744073709551615UL,0xB64B5C6FL,0xFFBEFA5FL},{18446744073709551615UL,18446744073709551615UL,0xB64B5C6FL}};
                int32_t l_4589 = 0x46E74A6EL;
                int32_t *l_4592[5][1] = {{&l_4551[3]},{(void*)0},{&l_4551[3]},{(void*)0},{&l_4551[3]}};
                int i, j;
                l_4589 = ((0xD2A7B772F5B4C4DFLL != l_4335) == (p_9 == (((safe_sub_func_int16_t_s_s((((((*g_1966) |= ((5L == (*g_3271)) == p_10)) == (safe_sub_func_uint16_t_u_u(((*g_168) |= ((safe_add_func_uint8_t_u_u(p_10, (++(*l_4429)))) || (safe_lshift_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u(p_9, ((safe_sub_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s((safe_sub_func_uint32_t_u_u((((--(****g_4007)) < 8UL) ^ l_4354), (*g_670))), 18446744073709551612UL)), l_4588[5][0])), l_4551[3])) , p_11))) <= l_4345), 6)))), l_4356))) == (**g_3729)) > l_4588[5][0]), 0xBC1BL)) <= p_9) < 0x45L)));
                l_4590 = &g_3996[3];
                (*g_1120) ^= l_4591;
                ++l_4593;
            }
        }
        (*g_1120) &= 0x630971CFL;
        for (g_636 = 0; (g_636 != 0); g_636 = safe_add_func_uint16_t_u_u(g_636, 5))
        { /* block id: 2075 */
            if (l_4269)
                goto lbl_4598;
            l_4303[4][0] ^= p_9;
        }
    }
    else
    { /* block id: 2079 */
        uint64_t l_4621[5] = {0x77DDBA47A58E81D8LL,0x77DDBA47A58E81D8LL,0x77DDBA47A58E81D8LL,0x77DDBA47A58E81D8LL,0x77DDBA47A58E81D8LL};
        int32_t l_4689 = 9L;
        int32_t l_4690 = 8L;
        int32_t l_4691 = 0L;
        int32_t l_4692[2][4] = {{(-10L),(-10L),(-10L),(-10L)},{(-10L),(-10L),(-10L),(-10L)}};
        int64_t l_4746 = (-1L);
        uint16_t l_4747 = 65529UL;
        int16_t **l_4806 = &l_4413;
        int32_t l_4871 = 0x2450ACB2L;
        uint8_t l_4931 = 0xFAL;
        uint32_t l_4938 = 4294967290UL;
        uint32_t l_4953 = 4294967292UL;
        uint64_t l_4997 = 0xEB89E98831C46277LL;
        uint32_t l_5001 = 0xBF89C8AAL;
        int8_t l_5033 = 0xB4L;
        int64_t ** const l_5051 = &g_47[2];
        int32_t l_5054 = 0x27E7A8C1L;
        int32_t *l_5097 = &g_1121;
        int64_t l_5138 = 1L;
        uint32_t l_5150[6] = {0x588F8D0CL,0x588F8D0CL,0x588F8D0CL,0x588F8D0CL,0x588F8D0CL,0x588F8D0CL};
        uint64_t ***l_5266 = &g_755;
        const uint8_t l_5307[6][8][5] = {{{1UL,0x7BL,1UL,1UL,0x6CL},{9UL,255UL,255UL,251UL,1UL},{0x54L,251UL,0xCCL,0x8AL,0x24L},{0UL,0xF9L,255UL,9UL,0x11L},{0xA9L,255UL,1UL,7UL,247UL},{0xEFL,9UL,247UL,247UL,9UL},{0x24L,0xD3L,0xA0L,0xCFL,0xB3L},{4UL,0xF9L,0xCBL,4UL,0xECL}},{{0x46L,7UL,0x6CL,251UL,0x46L},{4UL,255UL,0x43L,249UL,0UL},{0x24L,1UL,0xCCL,1UL,248UL},{0UL,249UL,0x8CL,4UL,0x11L},{1UL,1UL,0x6CL,0xCFL,0xDCL},{0x18L,9UL,9UL,0xF9L,251UL},{0x4FL,0x00L,7UL,0xCFL,0x24L},{4UL,0xCBL,0xF9L,4UL,0x14L}},{{0x46L,0xD3L,253UL,1UL,253UL},{0x11L,0x11L,0x43L,247UL,0xEFL},{0x54L,0x8AL,7UL,255UL,0xA1L},{0UL,247UL,255UL,1UL,4UL},{253UL,0x8AL,0x6CL,0x7BL,247UL},{1UL,0x11L,249UL,9UL,251UL},{255UL,0xD3L,0xCCL,0xD3L,255UL},{9UL,0xCBL,1UL,4UL,0x18L}},{{253UL,0x00L,247UL,1UL,0xA9L},{4UL,9UL,0x8CL,0xCBL,0x18L},{0x54L,1UL,1UL,0x94L,255UL},{0x18L,249UL,255UL,251UL,251UL},{0x46L,6UL,0x46L,0xCFL,247UL},{0x14L,4UL,0xF9L,0xCBL,4UL},{0x4FL,0xD3L,0UL,0x5FL,0xA1L},{0x11L,1UL,0xF9L,4UL,0xEFL}},{{1UL,1UL,0x46L,255UL,253UL},{4UL,4UL,255UL,9UL,0x14L},{0xA1L,0x8AL,1UL,1UL,0x24L},{1UL,1UL,0x8CL,1UL,251UL},{0xDCL,255UL,247UL,0xD3L,0xDCL},{1UL,4UL,1UL,247UL,0x11L},{0xA1L,0x00L,0xCCL,0x5FL,248UL},{4UL,249UL,249UL,4UL,0x18L}},{{1UL,0x5FL,0x6CL,0x94L,0xDCL},{0x11L,9UL,255UL,0xF9L,0UL},{0x4FL,6UL,7UL,0x94L,0x24L},{0x14L,0xCBL,0x43L,4UL,4UL},{0x46L,255UL,253UL,0x5FL,253UL},{0x18L,0x11L,0xF9L,247UL,255UL},{0x54L,1UL,7UL,0xD3L,0xA1L},{4UL,247UL,9UL,1UL,0x14L}}};
        uint16_t l_5415 = 0xB208L;
        uint8_t **l_5418 = &g_1078[1];
        uint32_t ****l_5419 = &g_3035;
        uint64_t l_5442[10];
        int8_t l_5478 = 0xCFL;
        int32_t *l_5525 = &g_156[5];
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_5442[i] = 0x679EDACA945CCFD0LL;
lbl_4886:
        for (g_94 = (-8); (g_94 == 14); g_94 = safe_add_func_int32_t_s_s(g_94, 7))
        { /* block id: 2082 */
            const uint16_t l_4601 = 0UL;
            const uint8_t *l_4612 = &g_5[3][0];
            const uint8_t * const *l_4611 = &l_4612;
            int64_t l_4620 = 0x9E4C0C5DC7473870LL;
            uint16_t **l_4650[1][10][9] = {{{&g_168,&g_168,&g_168,(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0},{&g_168,&g_161,&g_168,&g_168,&g_161,&g_168,&g_168,&g_161,&g_168},{(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0},{&g_168,&g_161,&g_168,&g_168,&g_161,&g_168,&g_168,&g_161,&g_168},{(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0},{&g_168,&g_161,&g_168,&g_168,&g_161,&g_168,&g_168,&g_161,&g_168},{(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0},{&g_168,&g_161,&g_168,&g_168,&g_161,&g_168,&g_168,&g_161,&g_168},{(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0,(void*)0,&g_168,(void*)0},{&g_168,&g_161,&g_168,&g_168,&g_161,&g_168,&g_168,&g_161,&g_168}}};
            int64_t ***l_4653 = &g_3729;
            int64_t ****l_4652 = &l_4653;
            int32_t l_4683[6];
            uint64_t l_4728 = 0xC70B2367802F3114LL;
            int16_t *l_4734 = &g_732;
            uint32_t *****l_4767 = &g_3034;
            uint32_t l_4779[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
            uint32_t *l_4828 = &l_4254[1];
            uint32_t **l_4829[2][3][8] = {{{&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828},{&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828},{&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828}},{{&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828},{&l_4828,(void*)0,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828},{&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828,&l_4828}}};
            uint64_t *l_4885 = &g_260;
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_4683[i] = 0xAC61BAF8L;
            if (l_4601)
            { /* block id: 2083 */
                uint16_t l_4619[9][5][5] = {{{65535UL,0x0822L,65535UL,0x2FAFL,0xF56FL},{3UL,0x722BL,65535UL,0x722BL,3UL},{65535UL,0x09FAL,0x0822L,0x40B3L,0x0822L},{65532UL,0x5E8AL,65535UL,65528UL,0x0630L},{0x09FAL,65535UL,65535UL,0x09FAL,0x0822L}},{{65535UL,65528UL,1UL,65527UL,3UL},{0x0822L,65535UL,0x2FAFL,0xF56FL,0xF56FL},{0UL,0x5E8AL,0UL,65527UL,65535UL},{0x40B3L,0x09FAL,0xF56FL,0x09FAL,0x40B3L},{0UL,0x722BL,65532UL,65527UL,0x0630L}},{{8UL,8UL,0x0822L,0x2FAFL,0x09FAL},{0UL,65528UL,3UL,0x7E8DL,0x0630L},{65535UL,0x2FAFL,0xF56FL,0xF56FL,0x2FAFL},{0x0630L,65528UL,65535UL,0x5E8AL,65532UL},{0x40B3L,8UL,0x40B3L,0xF56FL,0x0822L}},{{1UL,0x7E8DL,65532UL,0x7E8DL,1UL},{0x40B3L,65535UL,8UL,0x2FAFL,8UL},{0x0630L,1UL,65532UL,65527UL,65535UL},{65535UL,0x40B3L,0x40B3L,65535UL,8UL},{0UL,65527UL,65535UL,0x3E50L,1UL}},{{8UL,0x40B3L,0xF56FL,0x0822L,0x0822L},{3UL,1UL,3UL,0x3E50L,65532UL},{0x2FAFL,65535UL,0x0822L,65535UL,0x2FAFL},{3UL,0x7E8DL,0x0630L,65527UL,0x0630L},{8UL,8UL,0x0822L,0x2FAFL,0x09FAL}},{{0UL,65528UL,3UL,0x7E8DL,0x0630L},{65535UL,0x2FAFL,0xF56FL,0xF56FL,0x2FAFL},{0x0630L,65528UL,65535UL,0x5E8AL,65532UL},{0x40B3L,8UL,0x40B3L,0xF56FL,0x0822L},{1UL,0x7E8DL,65532UL,0x7E8DL,1UL}},{{0x40B3L,65535UL,8UL,0x2FAFL,8UL},{0x0630L,1UL,65532UL,65527UL,65535UL},{65535UL,0x40B3L,0x40B3L,65535UL,8UL},{0UL,65527UL,65535UL,0x3E50L,1UL},{8UL,0x40B3L,0xF56FL,0x0822L,0x0822L}},{{3UL,1UL,3UL,0x3E50L,65532UL},{0x2FAFL,65535UL,0x0822L,65535UL,0x2FAFL},{3UL,0x7E8DL,0x0630L,65527UL,0x0630L},{8UL,8UL,0x0822L,0x2FAFL,0x09FAL},{0UL,65528UL,3UL,0x7E8DL,0x0630L}},{{65535UL,0x2FAFL,0xF56FL,0xF56FL,0x2FAFL},{0x0630L,65528UL,65535UL,0x5E8AL,65532UL},{0x40B3L,8UL,0x40B3L,0xF56FL,0x0822L},{1UL,0x7E8DL,65532UL,0x7E8DL,1UL},{0x40B3L,65535UL,8UL,0x2FAFL,8UL}}};
                int32_t l_4635 = (-2L);
                int64_t ****l_4654[8];
                int i, j, k;
                for (i = 0; i < 8; i++)
                    l_4654[i] = &l_4653;
                for (g_23 = 19; (g_23 == (-2)); --g_23)
                { /* block id: 2086 */
                    int32_t *l_4604 = &g_78;
                    uint16_t **l_4649 = &g_161;
                    (**g_3479) = l_4604;
                    (*g_51) |= p_11;
                    for (g_52 = 3; (g_52 >= 0); g_52 -= 1)
                    { /* block id: 2091 */
                        int32_t l_4628[7] = {8L,8L,8L,8L,8L,8L,8L};
                        int i;
                        (***l_4288) = ((p_10 && ((safe_rshift_func_int8_t_s_s(((*g_1966) = ((safe_mul_func_int64_t_s_s((((((safe_add_func_uint16_t_u_u((((void*)0 != l_4611) >= (safe_mod_func_uint8_t_u_u(((*g_161) > ((safe_rshift_func_int64_t_s_s(((0UL | p_9) , (0x288AL & (p_10 > ((((safe_sub_func_int16_t_s_s((*g_3271), 0x5A2EL)) > (*l_4604)) , (void*)0) != (void*)0)))), (*l_4604))) || (*g_3271))), 0xBFL))), l_4601)) , 3L) > p_10) == l_4619[6][4][3]) , 9L), 0xD26F361030FACFA7LL)) | l_4620)), 6)) , (*l_4604))) < l_4601);
                        l_4621[1]++;
                        l_4635 &= ((safe_add_func_uint8_t_u_u((((p_11 && l_4620) < l_4628[2]) | ((l_4629 , l_4630) != (void*)0)), (safe_div_func_uint64_t_u_u((((*g_3479) = (*g_3479)) != (void*)0), (safe_unary_minus_func_int32_t_s((+0x2AF4L))))))) >= 1L);
                    }
                    if ((safe_rshift_func_uint8_t_u_s((((safe_mod_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(p_10, (((****g_3034) <= ((***l_4288) > (((((**g_3729) = (((void*)0 == &p_10) | ((safe_sub_func_uint8_t_u_u(0x07L, (((*g_794) | (safe_mod_func_uint8_t_u_u(((+(p_9 , (safe_div_func_uint16_t_u_u(((l_4650[0][4][5] = ((**g_1542) = l_4649)) != l_4651), (-4L))))) == l_4619[6][4][3]), 1L))) & (**g_3729)))) ^ 1UL))) , l_4652) != l_4654[7]) == 0x3606L))) ^ l_4621[3]))), (*g_3271))) , (***l_4288)) & (*l_4604)), (***l_4288))))
                    { /* block id: 2101 */
                        (**g_3479) = (*g_289);
                        (*g_51) = p_11;
                    }
                    else
                    { /* block id: 2104 */
                        uint32_t l_4663 = 0x00029D10L;
                        (*g_51) = (safe_mul_func_int16_t_s_s(((((*l_4604) , 0x75ADL) , ((((l_4620 <= (0UL != (+9L))) > (safe_mul_func_int16_t_s_s(((p_10 ^ (~l_4601)) && (l_4663 <= ((safe_mod_func_uint32_t_u_u(((((safe_add_func_uint16_t_u_u((****g_1542), 0x3F78L)) | (*l_4604)) & 0L) | (**g_1077)), 0x23FB1128L)) ^ p_10))), (*g_168)))) , l_4601) , p_11)) | l_4601), l_4621[1]));
                        (*g_1120) ^= (((safe_mul_func_int8_t_s_s(((l_4663 || ((safe_add_func_int32_t_s_s(((*g_51) |= (safe_unary_minus_func_uint64_t_u((((*g_1966) = ((safe_lshift_func_int8_t_s_s((safe_lshift_func_uint64_t_u_u((((0x4BL && ((safe_div_func_int32_t_s_s((0xEA97F26D1EE2074ALL <= ((safe_sub_func_uint16_t_u_u(((0UL && (safe_lshift_func_int16_t_s_s(l_4663, (0x24022557L ^ (0x7268510EL != l_4620))))) || (*g_161)), (****g_1542))) <= p_10)), (-9L))) , l_4620)) || p_11) >= p_9), 9)), 3)) | l_4621[2])) <= p_9)))), l_4635)) < p_10)) ^ 4294967295UL), 0xDDL)) >= 4294967295UL) < (**g_3270));
                        (*g_51) &= (&g_3034 == &g_3472[1][1][2]);
                        return (*l_4604);
                    }
                }
                if (g_52)
                    goto lbl_5532;
            }
            else
            { /* block id: 2113 */
                int32_t l_4684[7][10] = {{8L,0xD8327704L,0xFB31ACB9L,8L,0xFB31ACB9L,0xD8327704L,8L,0x92539712L,0x92539712L,(-1L)},{0x92539712L,0xFB31ACB9L,1L,1L,0xFB31ACB9L,0x92539712L,0xDBDE630CL,0xFB31ACB9L,0xDBDE630CL,0x92539712L},{0xD8327704L,0xFB31ACB9L,8L,0xFB31ACB9L,0xD8327704L,8L,(-1L),(-1L),8L,0xD8327704L},{0xD8327704L,0xDBDE630CL,0xDBDE630CL,0xD8327704L,1L,0x92539712L,0xD8327704L,0x92539712L,1L,0xD8327704L},{0x92539712L,0xD8327704L,0x92539712L,1L,0xD8327704L,0xDBDE630CL,0xDBDE630CL,0xD8327704L,1L,0x92539712L},{(-1L),(-1L),8L,0xD8327704L,0xFB31ACB9L,8L,0xFB31ACB9L,0xD8327704L,8L,(-1L)},{0xFB31ACB9L,0xDBDE630CL,0x92539712L,0xFB31ACB9L,1L,1L,0xFB31ACB9L,0x92539712L,0xDBDE630CL,0xFB31ACB9L}};
                int32_t *l_4685 = &g_1121;
                int32_t *l_4686 = (void*)0;
                int32_t *l_4687 = (void*)0;
                int32_t *l_4688[3][10][7] = {{{(void*)0,(void*)0,&l_4352[3][2][1],(void*)0,&g_1121,&l_4251,&g_156[5]},{(void*)0,&g_1121,&l_4683[3],&l_4352[2][0][1],&l_4251,&g_85,&g_4553},{&g_85,&g_52,&l_4352[3][2][1],&l_4352[2][2][2],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_156[5],(void*)0,&l_4683[0],&l_4683[3]},{&g_52,&g_4553,&l_4683[3],&l_4251,&g_156[1],&g_85,&l_4352[2][2][2]},{(void*)0,&g_52,&g_1121,&l_4251,(void*)0,&l_4683[3],&g_4553},{&l_4251,&g_4553,&l_4352[0][0][3],(void*)0,&l_4352[2][0][1],&g_52,&g_52},{&g_85,&g_156[4],&l_4683[3],&g_156[6],&l_4352[2][0][1],&l_4683[3],(void*)0},{&g_1121,&g_52,(void*)0,&g_156[1],(void*)0,&l_4683[3],&g_4553},{(void*)0,&g_4553,&g_52,(void*)0,&g_156[1],(void*)0,&g_52}},{{(void*)0,&g_156[1],&l_4683[3],(void*)0,(void*)0,&l_4683[3],(void*)0},{&l_4352[2][0][1],&g_156[5],&g_156[5],&l_4352[2][0][1],(void*)0,&l_4683[3],&g_4553},{&l_4251,&g_4553,&l_4251,(void*)0,&l_4251,&l_4352[1][2][0],&l_4683[3]},{&g_156[4],&g_85,&g_85,(void*)0,&g_1121,&l_4683[3],&g_4553},{&g_156[0],&g_52,(void*)0,(void*)0,(void*)0,&g_156[5],(void*)0},{(void*)0,(void*)0,&l_4683[0],(void*)0,&l_4352[2][2][2],&g_156[3],&g_52},{(void*)0,&g_156[0],&g_85,&g_4553,&g_4553,&l_4683[3],&g_4553},{&l_4683[1],&g_52,&l_4683[3],&g_1121,&g_156[5],&g_156[1],(void*)0},{(void*)0,(void*)0,&g_156[4],&l_4242,&l_4683[3],&g_78,&g_4553},{&g_1121,&l_4352[1][2][0],(void*)0,&g_52,(void*)0,&l_4683[1],(void*)0}},{{&g_52,&g_156[4],&l_4683[3],&l_4683[3],&l_4683[2],&g_4553,&g_156[5]},{&l_4683[3],(void*)0,&g_78,&g_78,(void*)0,&l_4352[3][0][3],&l_4683[3]},{(void*)0,&g_156[1],&g_156[1],&l_4352[0][0][3],&l_4352[0][0][3],&g_156[1],&g_156[1]},{&g_156[5],&g_85,&g_52,(void*)0,&l_4242,&g_156[7],(void*)0},{&l_4683[3],&g_52,&g_85,&g_156[7],(void*)0,&l_4683[3],&l_4251},{(void*)0,(void*)0,&l_4683[1],(void*)0,&g_52,(void*)0,&l_4352[1][2][0]},{(void*)0,&l_4251,&l_4242,&l_4352[0][0][3],&g_156[1],&g_4553,(void*)0},{&l_4352[3][0][3],&l_4683[0],(void*)0,&g_78,&l_4352[1][2][0],&g_156[5],&l_4251},{&l_4683[0],(void*)0,(void*)0,&l_4683[3],(void*)0,(void*)0,(void*)0},{&g_156[5],&g_4553,&g_4553,&g_52,&l_4683[2],&l_4352[2][0][1],&l_4352[3][2][1]}}};
                uint32_t l_4693 = 9UL;
                int i, j, k;
                --l_4693;
                l_4696 = ((*g_1043) = (void*)0);
                (*g_1043) = &l_4683[3];
                if ((**g_1043))
                    break;
            }
            for (l_4629 = (-7); (l_4629 <= 27); l_4629++)
            { /* block id: 2122 */
                int32_t ***l_4699 = &g_1043;
                int32_t l_4720[6][8][5] = {{{0xE2C0B917L,(-1L),0x0C64B01CL,0L,0xCB0D4D54L},{0x72CAEA93L,0xC185641EL,0xC185641EL,0x72CAEA93L,0x42168D3EL},{0xC071142AL,0xDBC68AE5L,0xEC3D7BDDL,0x5BC2652CL,0xDBC68AE5L},{0x42168D3EL,0x58F86E45L,0x40E8074CL,0xEE0A1EFBL,0x789782C0L},{0xF774277AL,0xE2C0B917L,0x5DD1699BL,0x5BC2652CL,0x0C64B01CL},{0xDDCF2B0FL,0x72CAEA93L,6L,0x72CAEA93L,0xDDCF2B0FL},{0x5DD1699BL,0xC071142AL,0xE2C0B917L,0L,(-1L)},{(-5L),0x42168D3EL,0xEE0A1EFBL,0xDDCF2B0FL,1L}},{{0xC071142AL,0xF774277AL,0x9A31C922L,0xC071142AL,(-1L)},{0x8D2E864BL,0xDDCF2B0FL,0x40E8074CL,0x40E8074CL,0xDDCF2B0FL},{(-1L),0x5DD1699BL,(-1L),1L,0x0C64B01CL},{0x58F86E45L,(-5L),0x8610FE71L,0x2AA6F4F4L,0x789782C0L},{0L,0xC071142AL,0x0C64B01CL,0x2523ACF0L,0xDBC68AE5L},{0x58F86E45L,0x8D2E864BL,0x42168D3EL,0xDDCF2B0FL,0x42168D3EL},{(-1L),(-1L),0L,0xDBC68AE5L,0xCB0D4D54L},{0x8D2E864BL,0x58F86E45L,0xC185641EL,0x8D2E864BL,(-5L)}},{{0xC071142AL,0L,(-1L),0x5BC2652CL,0L},{(-5L),0x58F86E45L,0x282E3601L,0x789782C0L,0x789782C0L},{0x5DD1699BL,(-1L),0x5DD1699BL,(-1L),1L},{0xDDCF2B0FL,0x8D2E864BL,0xEE0A1EFBL,0x72CAEA93L,1L},{0xF774277AL,0xC071142AL,(-7L),0xDBC68AE5L,(-1L)},{0x42168D3EL,(-5L),0xEE0A1EFBL,0x282E3601L,0x8D2E864BL},{0x5DD1699BL,0L,0L,0x5DD1699BL,0x89B654BAL},{0xC185641EL,0x40E8074CL,0x789782C0L,0xEE0A1EFBL,0x40E8074CL}},{{0x89B654BAL,0L,0L,(-7L),0xE2C0B917L},{1L,0L,0L,0xEE0A1EFBL,(-2L)},{(-1L),0x5DD1699BL,(-1L),0x5DD1699BL,(-1L)},{0L,0xC185641EL,0L,0x282E3601L,1L},{0x168FF3D6L,0x89B654BAL,(-7L),(-1L),0x68F4A979L},{0xC185641EL,1L,0xDDCF2B0FL,0xC185641EL,1L},{0x9A31C922L,(-1L),0L,0L,(-1L)},{1L,0L,6L,0x42168D3EL,(-2L)}},{{0L,0x168FF3D6L,0xDBC68AE5L,0x0C64B01CL,0xE2C0B917L},{0x282E3601L,0xC185641EL,(-2L),0x8610FE71L,0x40E8074CL},{0L,0x9A31C922L,0x89B654BAL,(-1L),0x89B654BAL},{1L,1L,(-5L),0x40E8074CL,0x8D2E864BL},{0x9A31C922L,0L,0L,0x9A31C922L,0x168FF3D6L},{0xC185641EL,0x282E3601L,6L,0xEE0A1EFBL,0x282E3601L},{0x168FF3D6L,0L,1L,0xE2C0B917L,0xE2C0B917L},{0L,1L,0L,6L,0x42168D3EL}},{{(-1L),0x9A31C922L,(-7L),0x5DD1699BL,0xEC3D7BDDL},{1L,0xC185641EL,(-4L),0x40E8074CL,1L},{0x89B654BAL,0x168FF3D6L,(-7L),0xEC3D7BDDL,0x2523ACF0L},{0xC185641EL,0L,0L,0xC185641EL,0L},{0x5DD1699BL,(-1L),1L,0x0C64B01CL,(-1L)},{0L,1L,6L,(-2L),0x42168D3EL},{0L,0x89B654BAL,0L,0x0C64B01CL,(-7L)},{0x40E8074CL,0xC185641EL,(-5L),0xC185641EL,0x40E8074CL}}};
                int16_t *l_4736[2][8][3] = {{{&g_1350[1],&g_1350[2],&g_1350[1]},{&g_2989,&g_76[0][4],&g_732},{&g_2989,(void*)0,&g_76[0][4]},{&g_1350[1],&g_76[0][4],&g_76[0][4]},{&g_76[0][4],&g_1350[2],&g_732},{&g_1350[1],&g_1350[2],&g_1350[1]},{&g_2989,&g_76[0][4],&g_732},{&g_2989,(void*)0,&g_76[0][4]}},{{&g_1350[1],&g_76[0][4],&g_76[0][4]},{&g_76[0][4],&g_1350[2],&g_732},{&g_1350[1],&g_1350[2],&g_1350[1]},{&g_2989,&g_76[0][4],&g_732},{&g_2989,(void*)0,&g_76[0][4]},{&g_1350[1],&g_76[0][4],&g_76[0][4]},{&g_76[0][4],&g_1350[2],&g_732},{&g_1350[1],&g_1350[2],&g_1350[1]}}};
                uint8_t l_4782 = 1UL;
                int i, j, k;
                if (((void*)0 == l_4699))
                { /* block id: 2123 */
                    for (g_667 = 16; (g_667 > 16); g_667 = safe_add_func_uint8_t_u_u(g_667, 6))
                    { /* block id: 2126 */
                        (*g_1043) = &l_4691;
                    }
                    (**g_3479) = &l_4683[3];
                }
                else
                { /* block id: 2130 */
                    int8_t *l_4721 = &g_720;
                    int32_t l_4729 = 5L;
                    int16_t *l_4735 = &g_2989;
                    int32_t l_4745[8];
                    uint64_t l_4781 = 0x83052F40617E7064LL;
                    const int8_t *l_4810 = (void*)0;
                    int i;
                    for (i = 0; i < 8; i++)
                        l_4745[i] = 0x8F7C6402L;
                    if (((safe_lshift_func_int32_t_s_u((((safe_lshift_func_uint64_t_u_u((safe_rshift_func_int32_t_s_u((l_4691 |= (safe_add_func_int64_t_s_s(l_4692[1][3], ((+(((**l_4412) = (safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s((*g_1966), (((p_11 |= ((void*)0 == l_4715)) < (safe_rshift_func_int8_t_s_s(((*l_4721) = (((~l_4692[1][3]) != ((***g_3997) = (safe_unary_minus_func_uint32_t_u(l_4720[0][6][0])))) < (*g_1966))), ((l_4620 , g_4722) != l_4726)))) ^ 4294967287UL))), p_9))) && 0x8E86L)) ^ l_4690)))), l_4728)), 57)) > p_9) > p_10), p_10)) , l_4729))
                    { /* block id: 2136 */
                        (**l_4288) = &l_4683[3];
                        (***g_3479) &= p_10;
                        if (l_4728)
                            goto lbl_4886;
                        return p_9;
                    }
                    else
                    { /* block id: 2140 */
                        int32_t *l_4740 = &l_4690;
                        int32_t *l_4741 = &l_4692[0][1];
                        int32_t *l_4742 = &l_4242;
                        int32_t *l_4743 = &g_4553;
                        int32_t *l_4744[7] = {&g_156[5],&l_4692[0][2],&g_156[5],&g_156[5],&l_4692[0][2],&g_156[5],&g_156[5]};
                        int i;
                        l_4691 = ((((safe_lshift_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((((*l_4734) = (0x16L && ((l_4735 = ((*l_4412) = l_4734)) == (g_4737 = l_4736[1][6][0])))) > l_4690), (p_11 >= ((***g_4385) = (((p_10 , &g_4723[8][0][0]) == (((0x098A5062L && (safe_mod_func_int8_t_s_s((-5L), (-6L)))) , p_10) , (void*)0)) != p_9))))), 16)) || p_10) || 0xA8L) & (**g_3729));
                        l_4747--;
                        (*g_1120) = (((p_9 == ((((0x804DL <= l_4683[3]) ^ (p_11 || (((void*)0 == (*g_3858)) == ((*l_4743) = p_9)))) || (p_9 <= p_10)) | p_9)) & p_10) , p_9);
                    }
                    for (g_52 = 0; (g_52 == 24); g_52 = safe_add_func_uint64_t_u_u(g_52, 5))
                    { /* block id: 2153 */
                        int64_t l_4778 = 0xF4F7A1DF521F7151LL;
                        if (p_9)
                            break;
                        (*g_3203) = (safe_rshift_func_int32_t_s_u(((p_9 , ((((safe_div_func_uint64_t_u_u((safe_mul_func_uint64_t_u_u((((safe_lshift_func_int8_t_s_u((-1L), (safe_sub_func_int64_t_s_s(((0x1EL | (safe_div_func_int64_t_s_s((safe_mod_func_uint8_t_u_u((((&g_3472[2][2][0] == (l_4767 = l_4766)) ^ (safe_add_func_int8_t_s_s((0x46L && (((*g_242) = ((((((safe_lshift_func_int32_t_s_u(p_9, (+(~(((l_4729 >= ((safe_add_func_int64_t_s_s((safe_rshift_func_int16_t_s_u(l_4778, p_11)), 0UL)) , l_4778)) >= (-2L)) , p_9))))) , l_4621[1]) != l_4779[3]) , l_4780) == l_4780) , (****g_694))) , l_4745[0])), 4L))) && p_10), 0x03L)), p_10))) < 0x51C1L), (**g_3729))))) , p_11) > l_4781), 0x349722A27FE94AFALL)), p_11)) & l_4782) > p_11) == l_4729)) < p_9), 12));
                        if (l_4621[1])
                            continue;
                    }
                    for (g_735 = (-17); (g_735 < 17); g_735 = safe_add_func_int8_t_s_s(g_735, 7))
                    { /* block id: 2162 */
                        int64_t l_4801 = 0x0A5E3A977B04AA71LL;
                        int8_t **l_4809 = &l_4721;
                        l_4690 |= (((*g_1327)--) > ((*g_1966) & ((p_11 || (0xEAC62A07L >= 0x854735E3L)) , p_9)));
                        (*g_1120) &= (((safe_mul_func_uint8_t_u_u(0xAAL, (((****l_4652) ^= (((safe_rshift_func_int64_t_s_s(((safe_add_func_uint32_t_u_u(((((****g_3034) >= (l_4689 | (((((((*l_4243) = &g_754[0]) == (g_4795 = ((0x02L & 0UL) , &g_754[0]))) <= ((safe_rshift_func_int16_t_s_s(((safe_div_func_uint32_t_u_u((!l_4745[2]), 4294967295UL)) | p_11), l_4746)) > p_11)) >= p_11) , p_10) >= l_4729))) == l_4729) == 4294967290UL), (-5L))) > l_4620), 27)) , 0x46L) < l_4801)) | 0x2F114BED56425BDDLL))) , 65526UL) != 0L);
                        (*g_1120) &= ((((((((**g_1077) = 255UL) != ((((safe_div_func_int16_t_s_s((l_4806 != ((*l_4411) = (p_9 , (*l_4411)))), p_9)) ^ p_11) < (p_11 < (**g_3729))) , (safe_lshift_func_uint32_t_u_u((((*l_4809) = l_4721) != l_4810), p_11)))) , 0xE96F79EBL) || l_4683[3]) > l_4692[1][3]) == 0x12F06A94A030C4B6LL) <= p_11);
                        (*g_1120) = (safe_add_func_uint64_t_u_u((safe_sub_func_int32_t_s_s(((safe_add_func_uint16_t_u_u((safe_add_func_uint8_t_u_u(0xBBL, (safe_add_func_uint64_t_u_u(((***g_4385) = ((l_4779[5] & ((***l_4653) = p_10)) | (((p_10 < (safe_sub_func_int16_t_s_s(l_4745[0], ((*g_168) = ((((safe_unary_minus_func_int8_t_s((*g_1966))) > (l_4779[3] || l_4691)) != (((safe_div_func_uint16_t_u_u(l_4620, 0xB311L)) , (void*)0) == &g_1753)) == (-1L)))))) ^ 1UL) == (**g_3998)))), 0x7C809408FA521C4ELL)))), (*g_3271))) < p_11), (****g_3034))), p_10));
                    }
                    for (g_3506 = 0; (g_3506 < 19); g_3506 = safe_add_func_uint32_t_u_u(g_3506, 2))
                    { /* block id: 2180 */
                        return p_10;
                    }
                }
                if (g_981)
                    goto lbl_5532;
            }
            if ((&l_4254[0] != (l_4830 = ((***g_4007) = l_4828))))
            { /* block id: 2187 */
                int16_t l_4843[10] = {0xAB20L,0xAB20L,0xAB20L,0xAB20L,0xAB20L,0xAB20L,0xAB20L,0xAB20L,0xAB20L,0xAB20L};
                uint64_t *l_4844 = &g_260;
                int i;
                l_4690 &= (safe_mul_func_int32_t_s_s(((*g_1120) |= (*g_670)), (((safe_mul_func_int16_t_s_s(p_10, p_11)) <= p_11) > (((*l_4844) = ((**g_755) = ((safe_add_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((*g_1966), (++(**g_1077)))), ((((***l_4652) != ((safe_mul_func_uint16_t_u_u((**g_160), l_4843[0])) , (void*)0)) , p_10) || 0x9BC29E1D5F60365ELL))) & l_4843[0]))) || l_4691))));
                return l_4843[0];
            }
            else
            { /* block id: 2194 */
                uint8_t *l_4869 = &g_981;
                int32_t l_4870 = (-10L);
                l_4871 = (safe_sub_func_int32_t_s_s(((l_4352[3][0][3] = ((((!((*g_1120) = (*g_1621))) <= (safe_add_func_uint64_t_u_u((&p_11 == (((**g_1077) & (safe_add_func_int8_t_s_s((safe_add_func_uint64_t_u_u((safe_mod_func_int32_t_s_s((l_4683[3] ^= (((safe_unary_minus_func_int8_t_s((+(*g_1966)))) , ((*l_4413) = (safe_sub_func_uint16_t_u_u(((((safe_mod_func_uint16_t_u_u(((safe_mod_func_int16_t_s_s((((0x2EB8L > (0xDC44L < (safe_mod_func_int32_t_s_s(((l_4866 || (safe_add_func_int16_t_s_s((((*l_4869) = 7UL) ^ p_10), l_4870))) & l_4689), (****g_3034))))) ^ 0xB094975026D48073LL) < p_11), p_9)) < p_9), (*g_161))) != 0L) , (**g_160)) < l_4870), l_4870)))) == p_9)), p_10)), (**g_3729))), l_4690))) , &p_11)), (****g_4795)))) & 0UL) , p_9)) <= 0x31L), p_11));
                if (p_11)
                    break;
                (*g_1120) = ((-7L) <= (((1UL < ((safe_mod_func_uint16_t_u_u(((~(safe_sub_func_int16_t_s_s(((safe_lshift_func_int64_t_s_u((((-6L) < 0x6623546DA1C93ACCLL) == l_4620), ((((-5L) < (~((p_9 < (safe_mod_func_int32_t_s_s(((!(((((*g_1966) == (((l_4885 = &l_4621[1]) == (void*)0) | 9L)) > l_4621[1]) , 65535UL) && l_4747)) != p_11), (-1L)))) || l_4870))) & (***g_3035)) < p_9))) || p_9), 1UL))) | l_4746), l_4692[0][0])) > 18446744073709551609UL)) , p_11) | 0x0A03B9E8282D1670LL));
                return l_4621[2];
            }
        }
lbl_5529:
        if ((safe_rshift_func_int64_t_s_s(((safe_div_func_int8_t_s_s((l_4690 = (safe_mul_func_int32_t_s_s(0x3F0AD042L, (l_4691 = (((safe_sub_func_uint8_t_u_u((safe_add_func_uint8_t_u_u(0xC5L, ((-7L) & (safe_sub_func_int32_t_s_s((safe_add_func_uint32_t_u_u(((*g_1327) ^= p_11), (safe_rshift_func_int64_t_s_s(l_4903[2][1][2], 28)))), (l_4692[1][1] = (((**g_755) != ((l_4691 , l_4904) == (void*)0)) < 0xB6L))))))), l_4691)) == 254UL) , (*g_1327)))))), p_9)) <= l_4621[1]), p_9)))
        { /* block id: 2212 */
            uint8_t *l_4924 = &g_1573;
            int32_t l_4925 = (-1L);
            int32_t ***l_4960 = &g_241[3][2];
            uint16_t l_4966 = 0x33B3L;
            int32_t *l_4968 = &l_4925;
            uint32_t * const ** const l_4983 = (void*)0;
            uint32_t * const ** const *l_4982 = &l_4983;
            uint32_t * const ** const **l_4981 = &l_4982;
            int32_t l_5091 = 0xE2CA771BL;
            uint8_t l_5092[2][8][4] = {{{0UL,2UL,253UL,0UL},{0xD7L,255UL,0xD7L,253UL},{1UL,255UL,5UL,0UL},{255UL,2UL,2UL,255UL},{0xD7L,0UL,2UL,253UL},{255UL,1UL,5UL,1UL},{1UL,2UL,0xD7L,1UL},{0xD7L,1UL,253UL,253UL}},{{0UL,0UL,5UL,255UL},{0UL,2UL,253UL,0UL},{0xD7L,255UL,0xD7L,253UL},{1UL,255UL,5UL,0UL},{255UL,2UL,2UL,255UL},{0xD7L,0UL,2UL,253UL},{255UL,1UL,5UL,1UL},{1UL,2UL,0xD7L,1UL}}};
            int i, j, k;
            if ((safe_mod_func_uint16_t_u_u(p_10, (safe_mul_func_uint8_t_u_u((((safe_mod_func_uint8_t_u_u(((**g_1077) &= p_11), ((0x73L > ((safe_mul_func_int64_t_s_s((safe_mul_func_int64_t_s_s((safe_sub_func_uint32_t_u_u((p_9 == (l_4871 ^= ((*g_756) = ((safe_lshift_func_int16_t_s_s((+(+(((****g_4007) = 0x814FB9CDL) ^ ((*g_1120) = ((p_10 || (safe_lshift_func_uint16_t_u_s(p_10, 2))) != (*g_1966)))))), (l_4924 != (*g_1030)))) >= l_4925)))), 0xABED6D75L)), p_9)), 8UL)) != l_4925)) , 254UL))) > 0x0095L) < l_4689), 253UL)))))
            { /* block id: 2218 */
                int32_t *l_4926 = &l_4690;
                int32_t *l_4927 = &g_156[5];
                int32_t *l_4928 = &g_156[5];
                int32_t l_4929[10][7][3] = {{{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L}},{{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L}},{{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L}},{{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L}},{{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L}},{{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L}},{{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L}},{{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L}},{{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L}},{{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L},{1L,(-9L),1L},{0xC14D8FB2L,0xC14D8FB2L,0xC14D8FB2L}}};
                int32_t *l_4930[7][1][5];
                int32_t ****l_4936 = &g_3479;
                const int32_t **l_4959 = (void*)0;
                const int32_t *** const l_4958 = &l_4959;
                int32_t l_4999[8][9][3] = {{{(-1L),(-9L),(-5L)},{5L,0x945B35E7L,0x7AB925C6L},{(-1L),(-7L),(-1L)},{3L,5L,0x7AB925C6L},{0x7C62190CL,0xFABB8BA3L,(-5L)},{0L,5L,5L},{(-5L),(-7L),(-1L)},{0L,0x945B35E7L,0L},{0x7C62190CL,(-9L),(-1L)}},{{3L,3L,5L},{(-1L),(-9L),(-5L)},{5L,0x945B35E7L,0x7AB925C6L},{(-1L),(-7L),(-1L)},{3L,5L,0x7AB925C6L},{0x7C62190CL,0xFABB8BA3L,(-5L)},{0L,5L,5L},{(-5L),(-7L),(-1L)},{0L,0x945B35E7L,0L}},{{0x7C62190CL,(-9L),(-1L)},{3L,3L,5L},{(-1L),(-9L),(-5L)},{5L,0x945B35E7L,0x7AB925C6L},{(-1L),(-7L),(-1L)},{3L,5L,0x7AB925C6L},{0x7C62190CL,0xFABB8BA3L,(-5L)},{0L,5L,5L},{(-5L),(-7L),(-1L)}},{{0L,0x945B35E7L,0L},{0x7C62190CL,(-9L),(-1L)},{3L,3L,5L},{(-1L),(-9L),(-5L)},{5L,0x945B35E7L,0x7AB925C6L},{(-1L),(-7L),(-1L)},{3L,5L,0x945B35E7L},{(-5L),(-9L),(-1L)},{0x7AB925C6L,0L,0L}},{{(-1L),0xFABB8BA3L,(-1L)},{0x7AB925C6L,3L,0x7AB925C6L},{(-5L),(-9L),(-1L)},{5L,5L,0L},{(-1L),(-9L),(-1L)},{0L,3L,0x945B35E7L},{(-1L),0xFABB8BA3L,(-1L)},{5L,0L,0x945B35E7L},{(-5L),(-9L),(-1L)}},{{0x7AB925C6L,0L,0L},{(-1L),0xFABB8BA3L,(-1L)},{0x7AB925C6L,3L,0x7AB925C6L},{(-5L),(-9L),(-1L)},{5L,5L,0L},{(-1L),(-9L),(-1L)},{0L,3L,0x945B35E7L},{(-1L),0xFABB8BA3L,(-1L)},{5L,0L,0x945B35E7L}},{{(-5L),(-9L),(-1L)},{0x7AB925C6L,0L,0L},{(-1L),0xFABB8BA3L,(-1L)},{0x7AB925C6L,3L,0x7AB925C6L},{(-5L),(-9L),(-1L)},{5L,5L,0L},{(-1L),(-9L),(-1L)},{0L,3L,0x945B35E7L},{(-1L),0xFABB8BA3L,(-1L)}},{{5L,0L,0x945B35E7L},{(-5L),(-9L),(-1L)},{0x7AB925C6L,0L,0L},{(-1L),0xFABB8BA3L,(-1L)},{0x7AB925C6L,3L,0x7AB925C6L},{(-5L),(-9L),(-1L)},{5L,5L,0L},{(-1L),(-9L),(-1L)},{0L,3L,0x945B35E7L}}};
                uint32_t l_5029 = 0x05DFE3D3L;
                int64_t *l_5032 = &g_48[0][1][0];
                uint16_t *l_5090[4][2][3] = {{{&g_123[8],(void*)0,&g_123[8]},{&l_4357[2],&l_4357[2],&l_4357[2]}},{{&g_123[8],(void*)0,&g_123[8]},{&l_4357[2],&l_4357[2],&l_4357[2]}},{{&g_123[8],(void*)0,&g_123[8]},{&l_4357[2],&l_4357[2],&l_4357[2]}},{{&g_123[8],(void*)0,&g_123[8]},{&l_4357[2],&l_4357[2],&l_4357[2]}}};
                int i, j, k;
                for (i = 0; i < 7; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 5; k++)
                            l_4930[i][j][k] = (void*)0;
                    }
                }
                l_4931--;
                if ((((*g_756) = (safe_mul_func_uint8_t_u_u(p_9, 1L))) >= 0x6A15DF48449C6FEALL))
                { /* block id: 2221 */
                    uint32_t l_4943[10][6] = {{0x45E83C14L,0x45E83C14L,0xBFE30313L,0xCE709775L,8UL,0xCE709775L},{18446744073709551613UL,0x45E83C14L,18446744073709551613UL,0xCCC5579FL,0xBFE30313L,0xBFE30313L},{0x965B6BDCL,18446744073709551613UL,18446744073709551613UL,0x965B6BDCL,0x45E83C14L,0xCE709775L},{0xCE709775L,0x965B6BDCL,0xBFE30313L,0x965B6BDCL,0xCE709775L,0xCCC5579FL},{0x965B6BDCL,0xCE709775L,0xCCC5579FL,0xCCC5579FL,0xCE709775L,0x965B6BDCL},{18446744073709551613UL,0x965B6BDCL,0x45E83C14L,0xCE709775L,0x45E83C14L,0x965B6BDCL},{0x45E83C14L,18446744073709551613UL,0xCCC5579FL,0xBFE30313L,0xBFE30313L,0xCCC5579FL},{0x45E83C14L,0x45E83C14L,0xBFE30313L,0xCE709775L,8UL,0xCE709775L},{18446744073709551613UL,0x45E83C14L,18446744073709551613UL,0xCCC5579FL,0x45E83C14L,0x45E83C14L},{18446744073709551613UL,0xCE709775L,0xCE709775L,18446744073709551613UL,8UL,0xCCC5579FL}};
                    int32_t l_4965 = (-9L);
                    uint32_t * const *l_4980 = &g_3215;
                    uint32_t * const ** const l_4979 = &l_4980;
                    uint32_t * const ** const *l_4978 = &l_4979;
                    uint32_t * const ** const **l_4977 = &l_4978;
                    uint32_t *****l_4984 = &g_1753;
                    int8_t l_4998 = 0xCAL;
                    int i, j;
                    g_4937 = l_4936;
                    --l_4938;
                    if (l_4871)
                        goto lbl_4967;
                    if (p_11)
                    { /* block id: 2224 */
                        (*l_4926) &= ((*g_3203) = p_11);
                    }
                    else
                    { /* block id: 2227 */
lbl_4967:
                        (*l_4926) ^= (safe_sub_func_uint16_t_u_u((l_4943[5][5] || ((safe_sub_func_int8_t_s_s((((safe_add_func_int16_t_s_s((safe_add_func_int8_t_s_s((safe_unary_minus_func_int16_t_s(((l_4953 < (safe_mod_func_uint16_t_u_u(0UL, 0x6F65L))) , ((0x79L > (((*g_161) = (*g_1733)) <= (safe_mul_func_int16_t_s_s((l_4958 == l_4960), (safe_lshift_func_uint64_t_u_s((((safe_mul_func_uint32_t_u_u(l_4925, l_4965)) != (*g_1966)) || 0xA4BCFB077342F73DLL), p_10)))))) && (**g_3270))))), p_10)), l_4925)) != l_4925) != p_9), l_4966)) < l_4943[5][5])), (**g_3270)));
                        l_4968 = &l_4925;
                        (*l_4928) &= (safe_sub_func_uint64_t_u_u((safe_div_func_uint16_t_u_u((((p_11 > (safe_add_func_uint16_t_u_u((((safe_sub_func_uint64_t_u_u((((((l_4981 = l_4977) != (l_4984 = (g_4414 = l_4984))) || ((((**g_696) , ((~((safe_mod_func_uint64_t_u_u(((p_10 && ((safe_mod_func_int16_t_s_s((!p_11), p_11)) ^ (p_9 && (safe_mul_func_int8_t_s_s((((**l_4630) = (safe_add_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u(((*g_1327) = ((((((*g_3729) = &p_11) != (void*)0) ^ 0x013C8EFAAF13C814LL) , 0x8F5745F8L) || p_9)), p_9)) <= p_10), (****g_4795)))) < p_10), l_4997))))) || p_11), l_4965)) > p_11)) || p_10)) , (void*)0) == (void*)0)) != 0x8A40L) || (****g_1542)), p_11)) >= (*l_4968)) <= 0x60A4EF2F7283642ALL), l_4943[5][5]))) > l_4998) , p_9), 0x348BL)), l_4999[7][4][2]));
                    }
                    (*l_4715) = &l_4692[1][2];
                }
                else
                { /* block id: 2241 */
                    int32_t l_5000[10];
                    uint32_t * const l_5028 = &g_2173;
                    uint16_t l_5031 = 0UL;
                    uint32_t *l_5052 = &g_1878;
                    uint16_t *l_5053 = &l_4357[2];
                    int i;
                    for (i = 0; i < 10; i++)
                        l_5000[i] = 5L;
                    ++l_5001;
                    for (l_4871 = 0; (l_4871 > 21); l_4871 = safe_add_func_uint64_t_u_u(l_4871, 3))
                    { /* block id: 2245 */
                        uint64_t ** const l_5006 = &g_756;
                        const int32_t l_5030[5][5][8] = {{{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}},{{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}},{{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}},{{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}},{{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}}};
                        int i, j, k;
                    }
                    if ((&g_3472[4][1][2] == (((((!(--(****g_3034))) ^ p_11) && (-8L)) ^ (((p_10 >= ((*l_4968) = (safe_div_func_uint16_t_u_u(((*l_5053) = (p_10 & (((safe_mul_func_uint64_t_u_u((((*g_168) = ((p_10 < (((*l_5028)++) != ((*l_4927) = (((*l_5052) = ((p_10 , 4UL) , (safe_mul_func_uint32_t_u_u((safe_rshift_func_uint64_t_u_u((safe_rshift_func_uint64_t_u_s((((p_10 , l_5051) != &l_5032) , p_11), 36)), 35)), p_9)))) >= p_9)))) , 0x71CFL)) , (*l_4968)), p_9)) >= p_10) == p_10))), p_9)))) >= l_5054) != l_5000[1])) , (void*)0)))
                    { /* block id: 2260 */
                        (*l_4927) = ((!l_5000[5]) >= (*g_1966));
                    }
                    else
                    { /* block id: 2262 */
                        (**g_3479) = &l_4929[3][1][1];
                    }
                }
                for (g_179 = (-3); (g_179 < 27); g_179++)
                { /* block id: 2268 */
                    return (*g_756);
                }
                (*l_4927) = ((((**g_3270) != ((safe_lshift_func_uint32_t_u_s(((((safe_lshift_func_int8_t_s_s(p_10, 6)) , (safe_lshift_func_uint64_t_u_u((safe_mul_func_int32_t_s_s((safe_mod_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((safe_mod_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((*g_4722) == (void*)0), (l_4692[0][2] = ((safe_mul_func_uint16_t_u_u(((**l_4374) |= 0x21B5L), (safe_add_func_int32_t_s_s((((((*l_4927) >= (safe_rshift_func_uint8_t_u_s(((safe_mul_func_int16_t_s_s((l_4747 , ((safe_add_func_uint32_t_u_u((p_10 , ((safe_lshift_func_uint16_t_u_s((safe_sub_func_uint16_t_u_u(((l_5092[1][5][0]--) >= g_5095), p_10)), 2)) > p_11)), (*l_4968))) >= l_4621[1])), p_10)) ^ (*l_4968)), p_10))) >= 0x5B3F6D7396FE5B10LL) || l_4953) ^ (-5L)), p_10)))) , p_9)))), 0x89E46A2AC250F4EDLL)), (*g_1966))), 0UL)) | 0xA0L), (-2L))), l_4690)), 9))) ^ 0xF87E581DF5C20D1BLL) | l_4747), 15)) <= (*l_4968))) , &l_4924) != (void*)0);
            }
            else
            { /* block id: 2275 */
                int32_t *l_5096 = &l_4352[2][1][1];
                (**g_3479) = l_5096;
            }
        }
        else
        { /* block id: 2278 */
            uint8_t l_5110[5];
            int32_t l_5111 = 1L;
            int32_t l_5117 = 0x9F444DF5L;
            uint64_t l_5118 = 18446744073709551615UL;
            int32_t l_5168[9] = {0x5DA7DB11L,0L,0x5DA7DB11L,0L,0x5DA7DB11L,0L,0x5DA7DB11L,0L,0x5DA7DB11L};
            int64_t *l_5173 = &g_23;
            int32_t l_5213 = 0x95BF0497L;
            uint32_t *****l_5262 = &g_3034;
            uint32_t *****l_5263[10][9][2] = {{{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034}},{{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,(void*)0},{&g_3034,&g_3034}},{{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,(void*)0}},{{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,(void*)0},{(void*)0,&g_3034}},{{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,(void*)0}},{{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034}},{{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034}},{{&g_3034,(void*)0},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034}},{{&g_3034,&g_3034},{(void*)0,(void*)0},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034}},{{&g_3034,(void*)0},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,(void*)0},{&g_3034,&g_3034},{(void*)0,&g_3034},{&g_3034,&g_3034},{&g_3034,&g_3034},{&g_3034,(void*)0}}};
            uint32_t **l_5271 = &g_3215;
            int32_t ***l_5290 = &g_241[4][2];
            int32_t ****l_5289 = &l_5290;
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_5110[i] = 1UL;
            (**l_4288) = l_5097;
            for (l_4871 = (-15); (l_4871 > (-28)); l_4871 = safe_sub_func_int64_t_s_s(l_4871, 4))
            { /* block id: 2282 */
                int32_t l_5113 = 0x1BC7F549L;
                int32_t l_5114 = 0x793C9F7AL;
                int32_t l_5116 = 5L;
                if ((((((p_9 ^ (safe_mod_func_uint64_t_u_u(((*g_756) = ((safe_sub_func_uint32_t_u_u((safe_mod_func_int32_t_s_s(p_11, (((*l_5097) || p_9) , ((((**g_1077) = (((safe_rshift_func_uint16_t_u_s(((p_10 <= ((**g_1077) , (*l_5097))) , ((safe_mod_func_int16_t_s_s(p_9, (p_10 || 0x9DL))) & p_9)), 0)) >= 0xA19653A85B08666BLL) != l_5110[0])) , 255UL) & (*g_1966))))), (****g_4007))) ^ p_10)), 0xA29A350A8EB4A9CDLL))) , p_10) , &p_10) != &p_10) , (*l_5097)))
                { /* block id: 2285 */
                    int32_t *l_5112[6] = {&g_156[0],&l_4352[3][0][3],&l_4352[3][0][3],&g_156[0],&l_4352[3][0][3],&l_4352[3][0][3]};
                    int8_t l_5115 = (-1L);
                    int i;
                    ++l_5118;
                }
                else
                { /* block id: 2287 */
                    int32_t *l_5121 = &l_4691;
                    (**l_4288) = l_5121;
                    return p_10;
                }
            }
            for (l_4690 = 8; (l_4690 < 21); l_4690 = safe_add_func_int8_t_s_s(l_4690, 1))
            { /* block id: 2294 */
                int16_t ****l_5129[7] = {&g_3877,&g_3877,&g_3877,&g_3877,&g_3877,&g_3877,&g_3877};
                const int32_t l_5151 = 0x4B07DBA6L;
                int32_t l_5169 = 0x0F48F2BBL;
                int32_t *l_5174 = &g_156[7];
                int32_t ** const *l_5183[1][9][10] = {{{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,(void*)0,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{(void*)0,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,(void*)0,(void*)0,&g_1043},{&g_1043,(void*)0,&g_1043,&g_1043,(void*)0,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,(void*)0,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{(void*)0,&g_1043,&g_1043,(void*)0,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043}}};
                int32_t ** const ** const l_5182 = &l_5183[0][7][0];
                uint32_t l_5216 = 0x087212DFL;
                uint32_t **l_5270 = (void*)0;
                int i, j, k;
            }
        }
        for (g_85 = 0; (g_85 >= 9); g_85 = safe_add_func_uint8_t_u_u(g_85, 8))
        { /* block id: 2364 */
            const int8_t l_5328[4] = {(-3L),(-3L),(-3L),(-3L)};
            int32_t l_5360 = (-4L);
            int32_t l_5361 = (-1L);
            int32_t l_5362 = 1L;
            int32_t l_5364 = 0x0E308D9CL;
            int32_t l_5399 = 0xCC2974F0L;
            int32_t l_5401[9] = {(-1L),(-1L),0L,(-1L),(-1L),0L,(-1L),(-1L),0L};
            int i;
            l_4692[0][2] &= ((safe_div_func_int64_t_s_s(((**g_3729) = p_11), (((*l_5097) = p_10) || (0x5EC8461EL > (((&l_5266 != (void*)0) >= ((safe_div_func_uint8_t_u_u((p_9 == 0x31395687L), ((safe_sub_func_int8_t_s_s(((((safe_mod_func_uint16_t_u_u(((safe_lshift_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u(65530UL, p_10)) == 0x985597496A102EBFLL), l_5307[0][2][1])) & 0xCDE6L), (**g_3270))) <= (****g_4007)) | (*l_5097)) | (**g_3270)), (-2L))) , 0xC9L))) <= (*g_1966))) <= (**g_1077)))))) ^ p_10);
            for (p_9 = 4; (p_9 < 14); p_9 = safe_add_func_int32_t_s_s(p_9, 2))
            { /* block id: 2370 */
                int16_t l_5327[4];
                int32_t *l_5350 = (void*)0;
                int i;
                for (i = 0; i < 4; i++)
                    l_5327[i] = 1L;
                if (p_11)
                    break;
                for (l_5138 = 0; (l_5138 <= 3); l_5138 += 1)
                { /* block id: 2374 */
                    int32_t *l_5310 = (void*)0;
                    (**g_3479) = l_5310;
                    for (g_23 = 0; (g_23 <= 2); g_23 += 1)
                    { /* block id: 2378 */
                        uint32_t *l_5333 = &g_2173;
                        int16_t l_5336 = 0xF536L;
                        int64_t *l_5346 = (void*)0;
                        int64_t *l_5347 = &g_48[2][2][1];
                        int i, j, k;
                        if (l_4352[(g_23 + 1)][g_23][(g_23 + 1)])
                            break;
                        l_4691 = ((247UL ^ ((((safe_mul_func_uint32_t_u_u(1UL, ((*l_5097) = p_10))) >= 0x5175DC51L) >= (((safe_sub_func_uint16_t_u_u(((*g_1327) , (safe_add_func_int8_t_s_s((safe_sub_func_uint16_t_u_u(((((*g_1966) = 0L) != (safe_lshift_func_uint8_t_u_u((0xEAL >= ((safe_sub_func_int8_t_s_s(p_11, (((safe_add_func_int8_t_s_s((safe_sub_func_int8_t_s_s(((((3L | 0UL) != (-5L)) < l_5327[2]) < p_9), 0xE1L)), l_5328[2])) < 0L) & g_3913))) >= p_10)), 1))) || 1UL), 0xF811L)), 0x3DL))), 1L)) , p_10) < 0x5C7FBBBFL)) | p_9)) , p_10);
                        (*g_3203) |= (p_11 <= ((((p_10 ^ (((((safe_div_func_uint64_t_u_u((safe_div_func_uint32_t_u_u(((***g_4007) == l_5333), (safe_div_func_int64_t_s_s((((*g_1120) |= l_5336) & (safe_lshift_func_uint8_t_u_s((((safe_mul_func_uint8_t_u_u((((+((safe_lshift_func_int64_t_s_u(6L, 54)) < (safe_rshift_func_int64_t_s_s(((*l_5347) = p_11), 12)))) & 0xF6L) , (safe_lshift_func_int32_t_s_s(p_9, p_9))), (*g_1966))) != 255UL) & 0x41EDF5E26E7447EELL), l_5328[2]))), p_10)))), 9UL)) != 0xA04DE14B5EF07D93LL) > 0L) , l_5328[2]) | p_10)) , p_11) , l_5328[2]) <= (-1L)));
                        l_5350 = ((***g_4937) = &l_4352[(g_23 + 1)][g_23][(g_23 + 1)]);
                    }
                    if (p_10)
                        continue;
                }
            }
            for (l_4242 = 17; (l_4242 == 21); l_4242 = safe_add_func_uint32_t_u_u(l_4242, 3))
            { /* block id: 2394 */
                int32_t *l_5353 = &g_1121;
                int32_t *l_5354 = &l_4866;
                int32_t *l_5355 = &l_4692[1][3];
                int32_t *l_5356 = &g_52;
                int32_t *l_5357 = &l_4692[0][1];
                int32_t *l_5358 = &g_156[1];
                int32_t *l_5359[5] = {&l_4691,&l_4691,&l_4691,&l_4691,&l_4691};
                int8_t l_5365 = 0x40L;
                uint32_t l_5366 = 0xBA2708F7L;
                int64_t * const *l_5382 = &g_47[0];
                uint16_t ***l_5390 = &g_160;
                int64_t l_5392 = (-1L);
                const int8_t l_5393 = 0x06L;
                int i;
                ++l_5366;
                for (l_5256 = (-12); (l_5256 < 23); l_5256++)
                { /* block id: 2398 */
                    int16_t l_5375 = 1L;
                    uint16_t ***l_5389 = (void*)0;
                    int32_t l_5391 = 1L;
                    int32_t l_5395 = 9L;
                    int32_t l_5396 = 0L;
                    int32_t l_5397 = 0x4612D621L;
                    int32_t l_5398 = (-10L);
                    int32_t l_5400 = (-5L);
                    int32_t l_5402 = 0xBF0043E1L;
                    int32_t l_5404 = 0x2242CE0AL;
                    int32_t l_5405[3];
                    uint32_t l_5406 = 4294967295UL;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_5405[i] = (-1L);
                    (*l_5358) ^= ((safe_div_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(p_11, ((l_5375 ^ (l_5362 = (safe_lshift_func_uint64_t_u_s(p_9, (255UL & ((((((safe_rshift_func_uint32_t_u_s(0xCB06EA7AL, 31)) < (safe_rshift_func_uint32_t_u_u(l_5328[1], ((l_5382 != (((safe_div_func_uint32_t_u_u(((safe_add_func_int32_t_s_s(((safe_div_func_uint32_t_u_u(((*l_5353) |= ((((l_5389 == ((*g_1542) = l_5390)) , l_5391) && l_5392) && p_9)), (*g_1327))) ^ 0xD5DF6999L), (-1L))) < p_11), l_5360)) | l_5393) , (void*)0)) ^ l_5328[3])))) , p_11) >= 0x15CCL) || (*g_168)) != 0x4EL)))))) , 3L))), l_5394)) , l_5391);
                    --l_5406;
                    for (g_5231 = 0; (g_5231 < 7); g_5231 = safe_add_func_uint64_t_u_u(g_5231, 9))
                    { /* block id: 2406 */
                        l_5354 = &l_5401[1];
                    }
                }
            }
        }
        if (((*l_5097) = ((safe_add_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_u(((0x1C5EL > l_5415) , ((l_5418 == (void*)0) != (((void*)0 != l_5419) , ((&l_4904 != &l_4904) == (safe_mod_func_int32_t_s_s(((*l_5097) | (**g_160)), (***g_3035))))))), 13)) , p_10), p_11)) , 0xEBE9A0E4L)))
        { /* block id: 2413 */
            uint8_t l_5436 = 6UL;
            uint32_t l_5466 = 4294967295UL;
            int32_t l_5475 = 0x72A9A0AFL;
            int32_t l_5476 = (-3L);
            int32_t l_5477 = (-1L);
            int8_t l_5480 = 5L;
            int32_t l_5481 = (-5L);
            uint32_t l_5490 = 0x1E5CEC43L;
            uint64_t *l_5508 = &g_4236[0][2];
            const int64_t *****l_5531 = &l_4726;
lbl_5530:
            for (g_260 = (-30); (g_260 >= 59); g_260 = safe_add_func_uint16_t_u_u(g_260, 6))
            { /* block id: 2416 */
                uint32_t ** const *l_5472 = &g_1326[2];
                int32_t l_5473 = 0x127C2D54L;
                int32_t l_5479[10][4][4] = {{{(-1L),0x39F3755FL,(-1L),1L},{0L,0x2D5DFFB7L,9L,(-1L)},{(-9L),0x0192F275L,(-8L),1L},{9L,(-8L),0x692682FEL,0x86006994L}},{{(-1L),9L,0x9D92234EL,9L},{0xD49D89EBL,1L,0L,0xEE8E5166L},{4L,(-1L),0x0192F275L,(-1L)},{8L,2L,0L,(-1L)}},{{8L,0xB41CF74FL,0x0192F275L,(-7L)},{4L,(-1L),0L,1L},{0xD49D89EBL,1L,0x9D92234EL,0x39AB24D0L},{(-1L),0x3955337CL,0x692682FEL,0x5F95BBDEL}},{{9L,(-1L),(-8L),0L},{(-9L),0x33415B20L,0xEE8E5166L,0x39F3755FL},{0x75263E5DL,(-1L),0x39F3755FL,0L},{0x398F965FL,(-1L),0xB41CF74FL,0L}},{{0xEE8E5166L,8L,1L,0x96ABE62AL},{8L,1L,(-1L),(-8L)},{9L,1L,8L,0xEE8E5166L},{0L,0L,0x39AB24D0L,1L}},{{0L,0x2D5DFFB7L,1L,0x239D26E4L},{(-2L),0x96ABE62AL,0x96ABE62AL,(-2L)},{0x80ACE11DL,1L,0x0192F275L,0xFF82E84CL},{1L,8L,(-1L),0x75263E5DL}},{{1L,0L,0L,0x75263E5DL},{0x2D5DFFB7L,8L,4L,0xFF82E84CL},{1L,1L,1L,(-2L)},{(-9L),0x96ABE62AL,(-1L),0x239D26E4L}},{{0x39F3755FL,0x2D5DFFB7L,0x692682FEL,1L},{0x0192F275L,0L,0x86880ADEL,0xEE8E5166L},{(-7L),1L,0xD49D89EBL,(-8L)},{0x86006994L,1L,0x80ACE11DL,0x96ABE62AL}},{{0x8DC71AADL,8L,1L,0L},{0L,(-1L),0x75263E5DL,0L},{0x33415B20L,(-1L),9L,0x39F3755FL},{8L,0x80ACE11DL,0x86006994L,1L}},{{0x692682FEL,0x33415B20L,(-1L),0x8DC71AADL},{2L,0L,0L,8L},{0L,(-8L),0L,0x86880ADEL},{0x239D26E4L,0x39AB24D0L,(-1L),1L}}};
                uint32_t l_5482[5];
                const uint32_t l_5495 = 0x8F57A182L;
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_5482[i] = 8UL;
                if ((0xBAL ^ ((**g_1077) ^= (0x6C98L <= ((p_9 , (**g_3270)) , ((safe_add_func_uint16_t_u_u(((safe_add_func_int16_t_s_s(((((*g_161) &= (+(safe_add_func_int8_t_s_s((safe_mul_func_int64_t_s_s((safe_mod_func_uint8_t_u_u(4UL, (p_10 & ((!p_11) < 4294967295UL)))), p_11)), l_5436)))) && 0xC756L) && 3L), 0x0A83L)) <= (-4L)), l_5437)) == p_9))))))
                { /* block id: 2419 */
                    uint8_t **l_5456[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int32_t l_5469 = 0xEC8871D0L;
                    int32_t *l_5474[10][5][5] = {{{&l_4692[1][3],&g_156[5],&g_78,&l_4866,&g_1121},{&l_5469,&g_156[3],&l_4689,&l_4691,&l_4689},{&l_4692[1][3],&g_156[5],(void*)0,&l_4690,&l_4251},{(void*)0,&l_4691,&l_4251,&g_78,(void*)0},{&g_1121,&g_52,&l_4866,&l_4866,&l_4866}},{{&l_4690,&l_4691,&l_4690,&g_156[3],&l_5473},{&l_4251,&g_156[5],&l_4690,&g_52,&l_4692[0][2]},{&g_78,&g_156[3],&g_85,&l_4690,(void*)0},{&l_4866,&g_156[5],&l_4690,&l_4692[0][2],&l_4242},{&l_5469,(void*)0,&l_4690,&l_4692[1][3],&l_4689}},{{&l_4692[0][2],&l_4692[1][3],&l_4866,&l_4690,&l_4871},{&g_78,&l_4692[1][3],&l_4251,&l_4692[1][3],&g_78},{&l_4242,&g_52,(void*)0,&l_4692[0][2],&g_156[5]},{&l_4690,&l_4352[2][2][0],&l_4689,&l_4690,&l_5473},{&l_4871,&l_4692[1][3],&g_78,&g_52,&g_156[5]}},{{(void*)0,&l_4690,&g_85,&g_156[3],&g_78},{&g_156[5],&g_156[5],&g_52,&l_4866,&l_4871},{&l_5469,&g_156[7],&l_4689,&g_78,&l_4689},{&g_156[5],&g_156[5],&l_4251,&l_4690,&l_4242},{(void*)0,&g_78,&l_4251,&l_4691,(void*)0}},{{&l_4871,&g_52,(void*)0,&l_4866,&l_4692[0][2]},{&l_4690,&g_78,&l_4690,&g_156[7],&l_5473},{&l_4242,&g_156[5],&g_156[5],&g_52,&l_4866},{&g_78,&g_156[7],&g_85,(void*)0,(void*)0},{&l_4692[0][2],&g_156[5],&g_156[5],&l_4692[0][2],&l_4251}},{{&l_5469,&l_4690,&l_4690,&l_4352[2][2][0],&l_4689},{&l_4866,&l_4692[1][3],(void*)0,&l_4690,&g_1121},{&g_78,&l_4352[2][2][0],&l_4251,&l_4352[2][2][0],&g_78},{&l_4251,&g_52,&l_4251,&l_4692[0][2],&l_4692[1][3]},{&l_4690,&l_4692[1][3],&l_4689,(void*)0,&l_5473}},{{&g_1121,&l_4692[1][3],&g_52,&g_52,&l_4692[1][3]},{(void*)0,(void*)0,&g_85,&g_156[7],&g_78},{&l_4692[1][3],&g_156[5],&g_78,&l_4866,&g_1121},{&l_5469,&g_156[3],&l_4689,&l_4691,&l_4689},{&l_4692[1][3],&g_156[5],(void*)0,&l_4690,&l_4251}},{{(void*)0,&l_4691,&l_4251,&g_78,(void*)0},{&g_1121,&g_52,&l_4866,&l_4866,&l_4866},{&l_4690,&l_4691,&l_4690,&g_156[3],&l_5473},{&l_4251,&g_156[5],&l_4690,&g_52,&l_4692[0][2]},{&g_78,&g_156[3],&g_85,&l_4690,(void*)0}},{{&l_4866,&g_156[5],&l_4690,&l_4692[0][2],&l_4242},{&l_5469,(void*)0,&l_4690,&l_4692[1][3],&l_4689},{&l_4692[0][2],&l_4692[1][3],&l_4866,&l_4690,&l_4871},{&g_78,&l_4692[1][3],&l_4251,&l_4692[1][3],&g_78},{&l_4242,&g_52,(void*)0,&l_4692[0][2],&g_156[5]}},{{&l_4690,&l_4352[2][2][0],&l_4689,&l_4690,&l_5473},{&l_4871,&l_4692[1][3],&g_78,&g_52,&g_156[5]},{(void*)0,&l_4690,&g_85,&g_156[3],&g_78},{&g_156[5],&g_156[5],&g_52,&l_4866,&l_4871},{&l_5469,&g_156[7],&l_4689,&g_78,&l_4689}}};
                    const uint64_t *l_5509 = (void*)0;
                    int i, j, k;
                    for (g_3506 = 0; (g_3506 != 32); ++g_3506)
                    { /* block id: 2422 */
                        const uint8_t ***l_5455 = &g_5453;
                        uint16_t *l_5467 = (void*)0;
                        uint16_t *l_5468 = &l_5415;
                        int32_t l_5470 = 0x0A3C926CL;
                        uint8_t l_5471 = 0x48L;
                        (*l_5097) &= ((safe_mod_func_int8_t_s_s((l_5442[2] , (*g_1966)), (~((~((safe_lshift_func_uint8_t_u_s((((*g_4007) = ((safe_add_func_int64_t_s_s((((safe_mul_func_int32_t_s_s((((safe_mul_func_int64_t_s_s((((*l_5455) = g_5453) == l_5456[4]), (safe_mul_func_uint8_t_u_u(((safe_rshift_func_uint64_t_u_s((~(((((**g_160) &= ((safe_lshift_func_uint8_t_u_u(p_9, p_9)) >= 255UL)) & (safe_div_func_uint16_t_u_u(((*l_5468) = (l_5466 == 0L)), p_10))) && l_5469) && (-10L))), l_5470)) >= (*g_1966)), 0x90L)))) <= p_11) & p_11), 0L)) > 0xC5B7L) & l_5471), l_5469)) , (*g_4007))) == l_5472), 3)) != (****g_4795))) < l_5473)))) > l_5473);
                        if (l_4691)
                            goto lbl_5530;
                    }
                    l_5482[2]++;
                    for (l_4938 = 0; (l_4938 > 47); l_4938++)
                    { /* block id: 2432 */
                        uint8_t l_5487 = 0x4DL;
                        int32_t l_5511[6][5] = {{0xBA001FD5L,7L,(-7L),0xBA001FD5L,0x5E2BC3DBL},{0xDA131ED0L,7L,0x932FB6F9L,0xDA131ED0L,0x5E2BC3DBL},{0xBA001FD5L,0x932FB6F9L,0x932FB6F9L,0xBA001FD5L,0xBE3C269FL},{0xBA001FD5L,7L,(-7L),0xBA001FD5L,0x5E2BC3DBL},{1L,0xDA131ED0L,9L,1L,0xB7DE4169L},{0x81AA48EFL,9L,9L,0x81AA48EFL,1L}};
                        int i, j;
                        ++l_5487;
                        l_5490++;
                        l_5511[1][4] = (safe_rshift_func_int16_t_s_s((*g_3271), (0UL > (l_5495 , (p_11 != ((safe_lshift_func_uint32_t_u_s(((safe_sub_func_uint16_t_u_u((safe_unary_minus_func_uint16_t_u(((safe_lshift_func_int64_t_s_s((p_10 , (((safe_unary_minus_func_int16_t_s((safe_lshift_func_int8_t_s_u((((l_5508 != l_5509) , (p_9 > (+0x91L))) && p_11), (*g_5454))))) <= 0x77L) <= (*g_1966))), 3)) != (*l_5097)))), 1L)) <= p_10), p_11)) >= l_5487))))));
                    }
                }
                else
                { /* block id: 2437 */
                    uint16_t ** const *l_5521 = (void*)0;
                    int64_t l_5522 = (-5L);
                    (*g_1120) = (safe_mul_func_uint16_t_u_u(((safe_add_func_uint32_t_u_u(((***g_3035) = (*g_1327)), (1UL <= (safe_mod_func_uint64_t_u_u(((safe_rshift_func_int16_t_s_u(((((~1L) > (((*l_4904) == l_5521) == ((l_5522 & 0xDBL) <= p_11))) & (((*g_161) = ((void*)0 == (**g_694))) ^ p_11)) , l_5473), l_5475)) | 0x606F64E7028182EBLL), 0xE50F4C3F923D0E9CLL))))) != (**g_3729)), (*l_5097)));
                }
                for (g_1573 = 29; (g_1573 <= 54); ++g_1573)
                { /* block id: 2444 */
                    int32_t *l_5526 = &l_5475;
                    l_5526 = l_5525;
                    for (g_582 = (-14); (g_582 < 38); g_582++)
                    { /* block id: 2448 */
                        if (g_732)
                            goto lbl_5529;
                    }
                }
            }
            (*l_5531) = &l_4727;
        }
        else
        { /* block id: 2455 */
            if (l_4691)
                goto lbl_5529;
lbl_5532:
            (***g_4937) = func_45((*g_3729));
            l_5533++;
            return p_9;
        }
    }
    ++g_5540;
    for (l_4554 = 0; (l_4554 > 59); l_4554++)
    { /* block id: 2467 */
        uint16_t l_5545[3][3];
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 3; j++)
                l_5545[i][j] = 0x702FL;
        }
        l_5545[1][0] &= ((*g_1120) &= p_9);
        (**g_3660) = (void*)0;
    }
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_1966 g_1670 g_3729 g_47 g_756 g_1077 g_1078 g_737 g_3758 g_3270 g_3271 g_3035 g_1326 g_1327 g_582 g_140 g_3660 g_3490 g_52 g_1542 g_652 g_160 g_161 g_1956 g_1120 g_3759 g_755 g_1733 g_688 g_3489 g_156 g_1121 g_3858 g_3479 g_1043 g_3877 g_289 g_51 g_3034 g_752 g_753 g_3904 g_670 g_3859 g_123 g_2894 g_2895 g_48 g_168 g_696 g_242 g_179 g_754 g_74 g_4006 g_4007 g_4008 g_794 g_735 g_694 g_695 g_3215 g_1621 g_4174 g_3997 g_3998 g_4236 g_3203
 * writes: g_48 g_140 g_737 g_1670 g_52 g_74 g_2272 g_1121 g_582 g_3858 g_1350 g_51 g_123 g_3489 g_2895 g_732 g_193 g_3995 g_4006 g_735 g_47 g_78 g_174 g_720 g_4094 g_1949 g_2075 g_179 g_156
 */
static int32_t  func_12(int16_t  p_13, int32_t  p_14)
{ /* block id: 1698 */
    uint8_t ***l_3754 = &g_1077;
    uint8_t ****l_3753 = &l_3754;
    uint8_t *****l_3752 = &l_3753;
    int32_t l_3755 = (-5L);
    int16_t l_3756 = 4L;
    int16_t **l_3765 = (void*)0;
    int16_t ***l_3764[4] = {&l_3765,&l_3765,&l_3765,&l_3765};
    int32_t l_3767 = 0L;
    int32_t **l_3769[7][10][3] = {{{&g_51,&g_1120,&g_51},{&g_51,&g_51,&g_1120},{&g_1120,&g_1120,&g_1120},{(void*)0,(void*)0,&g_51},{&g_51,&g_1120,&g_51},{&g_51,(void*)0,(void*)0},{&g_1120,&g_1120,&g_51},{&g_51,&g_1120,&g_51},{&g_51,&g_1120,&g_1120},{&g_51,&g_51,&g_1120}},{{&g_1120,&g_51,&g_1120},{&g_1120,&g_51,&g_51},{&g_51,&g_1120,&g_51},{(void*)0,&g_51,(void*)0},{&g_51,&g_1120,&g_51},{(void*)0,(void*)0,&g_51},{(void*)0,&g_1120,&g_1120},{&g_51,(void*)0,&g_1120},{&g_51,&g_51,&g_51},{&g_51,&g_1120,&g_1120}},{{(void*)0,&g_1120,(void*)0},{(void*)0,&g_51,(void*)0},{&g_51,(void*)0,(void*)0},{(void*)0,&g_51,&g_1120},{&g_51,&g_1120,&g_51},{&g_1120,&g_51,&g_1120},{&g_1120,&g_1120,&g_1120},{&g_51,&g_51,(void*)0},{&g_51,&g_1120,&g_51},{&g_51,&g_51,&g_1120}},{{&g_1120,(void*)0,&g_1120},{&g_51,&g_51,(void*)0},{&g_51,&g_1120,&g_1120},{(void*)0,&g_1120,&g_1120},{&g_1120,&g_51,&g_51},{&g_51,(void*)0,&g_1120},{&g_51,&g_1120,&g_1120},{&g_51,(void*)0,(void*)0},{&g_51,&g_1120,&g_1120},{&g_1120,&g_51,&g_1120}},{{(void*)0,&g_1120,&g_51},{&g_1120,&g_51,(void*)0},{&g_1120,&g_51,&g_1120},{(void*)0,&g_51,&g_1120},{&g_1120,&g_1120,&g_51},{&g_1120,&g_1120,&g_1120},{(void*)0,&g_1120,(void*)0},{&g_1120,(void*)0,(void*)0},{&g_51,&g_1120,(void*)0},{&g_51,(void*)0,&g_1120}},{{&g_51,&g_1120,&g_51},{&g_51,&g_51,&g_1120},{&g_1120,&g_1120,&g_1120},{(void*)0,(void*)0,&g_51},{&g_51,&g_1120,&g_51},{&g_51,(void*)0,(void*)0},{&g_1120,&g_1120,&g_51},{&g_51,&g_1120,&g_51},{&g_51,&g_1120,&g_1120},{&g_1120,&g_51,&g_1120}},{{&g_1120,&g_1120,&g_1120},{&g_1120,(void*)0,&g_51},{&g_1120,&g_51,&g_1120},{&g_51,&g_51,&g_51},{&g_51,&g_1120,&g_51},{(void*)0,&g_51,&g_51},{(void*)0,&g_51,&g_51},{(void*)0,&g_51,&g_51},{&g_1120,&g_1120,&g_1120},{(void*)0,&g_1120,&g_1120}}};
    uint16_t l_3816[2];
    uint32_t *l_3842 = (void*)0;
    int8_t l_3852 = 0xB1L;
    uint32_t **l_3890 = &l_3842;
    const int32_t *l_3939 = &g_2075;
    const int32_t **l_3938 = &l_3939;
    const int32_t ***l_3937 = &l_3938;
    uint32_t *** const **l_4010 = &g_3472[4][1][2];
    uint32_t l_4042 = 0xA9620C62L;
    int32_t l_4043 = 1L;
    int32_t l_4045 = 1L;
    const int64_t *l_4093 = (void*)0;
    const int64_t **l_4092 = &l_4093;
    int32_t l_4125 = 0L;
    uint16_t ** const l_4188[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint32_t *** const l_4221 = &g_1096;
    int64_t ***l_4234 = &g_3729;
    int64_t ****l_4233 = &l_4234;
    int8_t l_4235[5];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_3816[i] = 2UL;
    for (i = 0; i < 5; i++)
        l_4235[i] = (-1L);
    if ((((((safe_div_func_int8_t_s_s((0xAAL > ((****l_3753) ^= ((safe_rshift_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(0xFCL, (((*g_756) = (safe_div_func_int16_t_s_s(0x42A0L, (safe_rshift_func_int64_t_s_s((!((**g_3729) = (((65535UL < ((*g_1966) ^ (l_3752 != &l_3753))) <= l_3755) <= p_13))), 4))))) ^ l_3755))), 11)) >= 0x2728L))), l_3755)) != l_3755) , l_3756) , p_14) == 0x5FD63948L))
    { /* block id: 1702 */
        int8_t l_3763 = 1L;
        uint8_t ***l_3766 = &g_1077;
        int32_t l_3773[1];
        uint32_t ***l_3796[3];
        int32_t l_3846 = 0x7207FBE2L;
        int16_t ***l_3879 = (void*)0;
        int32_t l_3885 = 0L;
        const int32_t ***l_3940 = (void*)0;
        uint32_t *l_3969 = &g_193;
        uint16_t *****l_3975[3][8] = {{&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542},{&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542},{&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542}};
        int64_t ** const l_3990 = &g_47[5];
        uint64_t **** const l_4000 = &g_754[0];
        uint64_t **** const *l_3999 = &l_4000;
        uint32_t l_4031 = 1UL;
        int32_t l_4046 = (-5L);
        int i, j;
        for (i = 0; i < 1; i++)
            l_3773[i] = 0xB7700E44L;
        for (i = 0; i < 3; i++)
            l_3796[i] = &g_1096;
        if ((p_14 <= ((*g_1966) = (+(l_3767 &= ((((void*)0 != g_3758) , (safe_add_func_uint16_t_u_u(l_3763, (0x2BL < (((((void*)0 == l_3764[3]) >= (l_3755 , ((((((((&p_13 != (*g_3270)) | (-7L)) , l_3766) != (**l_3752)) , (***g_3035)) & 4294967294UL) >= l_3755) == (-1L)))) && 1L) & (-2L)))))) >= l_3756))))))
        { /* block id: 1705 */
            uint64_t *l_3768[5][8] = {{&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260},{&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260},{&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260},{&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260},{&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260,&g_260}};
            uint8_t l_3778 = 4UL;
            int32_t l_3783 = (-1L);
            int32_t ****l_3787 = (void*)0;
            uint32_t * const *l_3790 = (void*)0;
            uint32_t * const **l_3789 = &l_3790;
            uint32_t * const ***l_3788 = &l_3789;
            uint16_t *l_3792 = &g_123[1];
            int32_t l_3795 = 5L;
            uint8_t l_3823 = 0xDCL;
            int32_t l_3844 = 0x5170D86AL;
            int32_t l_3845[4] = {0x4AA81236L,0x4AA81236L,0x4AA81236L,0x4AA81236L};
            uint8_t l_3847 = 0x46L;
            int16_t l_3881 = 0x223CL;
            uint64_t ****l_3884 = &g_754[0];
            uint64_t *****l_3883 = &l_3884;
            uint32_t l_3944 = 3UL;
            int i, j;
            if (((l_3756 > ((l_3755 |= ((*g_756) &= 4UL)) > ((l_3769[4][2][2] != (*g_3660)) | (p_14 ^ ((safe_lshift_func_uint8_t_u_u((~(l_3773[0] |= 0x46024D8AD9E3ADFFLL)), 2)) , (((safe_lshift_func_uint16_t_u_u((~(~p_14)), ((0xA0L == (((2UL || 0xCF74L) , 1L) <= l_3778)) & p_14))) , p_13) == p_13)))))) & l_3763))
            { /* block id: 1709 */
                uint16_t *l_3793 = &g_1509[2];
                int32_t l_3811 = 9L;
                uint16_t l_3812 = 3UL;
                uint32_t * const l_3843 = &g_582;
                int16_t ****l_3878[3][7];
                uint8_t l_3882 = 0x0BL;
                int i, j;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 7; j++)
                        l_3878[i][j] = (void*)0;
                }
                for (g_52 = 0; (g_52 > 8); g_52++)
                { /* block id: 1712 */
                    uint32_t * const ****l_3791 = &l_3788;
                    uint32_t l_3794 = 1UL;
                    l_3795 ^= ((((l_3783 = ((((****g_1542) = p_14) <= (p_14 | 0UL)) , (++(*g_756)))) <= ((!(((*****l_3752) = (((**g_3270) || (safe_div_func_int32_t_s_s((((g_2272 = l_3787) != (void*)0) != ((((*l_3791) = l_3788) == ((l_3792 == l_3793) , (void*)0)) || p_13)), l_3794))) , 1UL)) > l_3773[0])) == p_13)) , p_13) == 65529UL);
                    (*g_1120) = (l_3795 |= (((l_3763 , &g_3708) == ((((((l_3773[0] = p_14) , l_3796[2]) == (void*)0) > (***g_3035)) , ((((****l_3753) = 0xFBL) <= p_13) & (safe_div_func_uint32_t_u_u(p_14, 0x39F82D6AL)))) , &g_3708)) >= 0UL));
                    return p_13;
                }
                if ((safe_lshift_func_uint16_t_u_s((((((((((safe_mod_func_int16_t_s_s(((l_3778 , (safe_mod_func_uint8_t_u_u(((~(!(safe_mod_func_int32_t_s_s((l_3812 = (((safe_div_func_uint8_t_u_u(((p_13 , (*g_3758)) == &l_3796[2]), p_13)) || 1UL) , l_3811)), (+(safe_rshift_func_uint64_t_u_s(((*g_756) = ((l_3816[1] & (*g_1966)) < 0UL)), l_3783))))))) > l_3811), p_13))) != 0x87262558L), 0x24E4L)) , (*g_1966)) >= (**g_1077)) & l_3783) | 0x02L) || p_14) , 1L) <= l_3811) != 0xADL), l_3778)))
                { /* block id: 1728 */
                    int64_t l_3817 = 0xD7C2219551C68DA7LL;
                    int32_t l_3820 = 0xE88C2636L;
                    int32_t l_3822 = (-10L);
                    p_14 = (p_13 || ((*g_1120) = l_3817));
                    for (l_3756 = 0; (l_3756 <= 3); l_3756 += 1)
                    { /* block id: 1733 */
                        const int8_t l_3818[4][3][10] = {{{(-10L),(-10L),0x98L,0x0AL,(-1L),0x0AL,0x98L,(-10L),(-10L),0x98L},{0xECL,0x0AL,0xDAL,0xDAL,0x0AL,0xECL,0x98L,0xECL,0x0AL,0xDAL},{(-3L),(-10L),(-3L),0xDAL,0x98L,0x98L,0xDAL,(-3L),(-10L),(-3L)}},{{(-3L),0xECL,(-10L),0x0AL,(-10L),0xECL,(-3L),(-3L),0xECL,(-10L)},{0xECL,(-3L),(-3L),0xECL,(-10L),0x0AL,(-10L),0xECL,(-3L),(-3L)},{(-10L),(-3L),0xDAL,0x98L,0x98L,0xDAL,(-3L),(-10L),(-3L),0xDAL}},{{0x0AL,0xECL,0x98L,0xECL,0x0AL,0xDAL,0xDAL,0x0AL,0xECL,0x98L},{(-10L),(-10L),0x98L,0x0AL,(-1L),0x0AL,0x98L,(-10L),(-10L),0x98L},{0xECL,0x0AL,0xDAL,0xDAL,0xDAL,(-3L),(-10L),(-3L),0xDAL,0x98L}},{{0x0AL,(-1L),0x0AL,0x98L,(-10L),(-10L),0x98L,0x0AL,(-1L),0x0AL},{0x0AL,(-3L),(-1L),0xDAL,(-1L),(-3L),0x0AL,0x0AL,(-3L),(-1L)},{(-3L),0x0AL,0x0AL,(-3L),(-1L),0xDAL,(-1L),(-3L),0x0AL,0x0AL}}};
                        int32_t l_3819 = 6L;
                        int32_t l_3821[1];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_3821[i] = 0x395D1FB1L;
                        if (l_3818[2][1][4])
                            break;
                        if (p_13)
                            break;
                        l_3823--;
                    }
                    (*g_1120) &= ((safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_u((l_3811 |= ((**g_755)++)), ((safe_rshift_func_uint64_t_u_u((p_14 , (((safe_mul_func_int64_t_s_s(((**g_3729) = (((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((l_3773[0] = (*g_1733)), 15)), ((l_3842 != l_3843) <= (l_3847++)))) , &l_3788) != &l_3788)), ((0xA7A1L != (safe_lshift_func_int8_t_s_s(((*g_3489) == ((**g_3270) >= p_13)), 3))) && 0xEA7F105AL))) > 0x0CL) == l_3852)), p_13)) && p_14))), 19)), l_3820)) , p_14);
                    return l_3820;
                }
                else
                { /* block id: 1745 */
                    int32_t *l_3853 = &l_3773[0];
                    int32_t *****l_3855 = &g_2272;
                    l_3853 = &p_14;
                    (*g_1120) ^= (((*g_1327) = l_3763) ^ (((*l_3853) == (+p_13)) == ((((((((*l_3855) = (void*)0) == (void*)0) != (p_14 <= (safe_mod_func_uint16_t_u_u(0x52C2L, (l_3844 = (g_1350[5] = ((p_14 <= ((g_3858 = g_3858) == &g_3859)) ^ l_3811))))))) == p_13) , l_3795) == 0x5DL) != 0x6163L)));
                    (**g_3479) = &l_3811;
                }
                (*g_51) = (safe_add_func_int32_t_s_s((safe_rshift_func_uint64_t_u_s((safe_lshift_func_int16_t_s_u((((safe_mod_func_int16_t_s_s((**g_3270), (((l_3773[0] , (safe_mul_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s(p_14, 5)), l_3811))) != (!(((*****l_3752) = (safe_lshift_func_int32_t_s_s((l_3881 = (safe_mul_func_int16_t_s_s((&l_3765 != (l_3879 = g_3877)), (~(-7L))))), ((((((((*g_1327) = 4294967295UL) == (((((((**g_3729) = (p_14 >= (*g_1966))) , l_3811) == p_13) >= 0xE86B66FEL) , l_3773[0]) || 0x60L)) == l_3783) || l_3763) >= (**g_289)) != 1UL) , 0L)))) == l_3882))) , l_3882))) , (void*)0) == l_3883), p_14)), l_3845[2])), l_3885));
                (*g_1043) = &l_3844;
            }
            else
            { /* block id: 1762 */
                uint16_t *l_3898 = &g_1509[1];
                int32_t l_3903 = 0x61B31D31L;
                int8_t *l_3914 = &l_3852;
                int8_t l_3941 = (-1L);
                uint32_t *l_3942 = &g_174;
                if ((safe_mod_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u((l_3795 = ((l_3890 != (**g_3034)) && (((*l_3914) |= ((((safe_lshift_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((((((p_13 <= 0x85284FBE4270B97CLL) < (!(((((((**g_1077) < (l_3845[0] |= (safe_rshift_func_uint16_t_u_u(((void*)0 == l_3898), ((**g_160) = ((safe_div_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s(((((p_13 > ((*g_1120) = (&l_3845[1] == (**g_3660)))) == (*g_1966)) , l_3778) == (*g_3489)), p_14)), l_3885)) <= p_13)))))) , p_13) != 0x02DD1A35L) || p_13) , l_3903) & 0xEC5CL))) < (-1L)) , 0xFC1F860EAD221F34LL) , (*g_752)) != g_3904[0][0]) != p_14), p_14)), p_13)) ^ (*g_1966)) , p_13) | 1L)) >= l_3823))), 15)), p_13)))
                { /* block id: 1768 */
lbl_3915:
                    p_14 |= (*g_670);
                }
                else
                { /* block id: 1770 */
                    if (l_3756)
                        goto lbl_3915;
                    if (((safe_sub_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_s((((*g_756) , 0x515AED3FB5B8414BLL) | (-1L)), 4)) >= ((safe_mod_func_uint64_t_u_u((((*l_3792) &= ((safe_mul_func_uint32_t_u_u(((((((l_3903 = p_14) == (*g_1966)) , (*g_3858)) != (*g_3858)) <= p_14) == (*g_1966)), l_3885)) && (**g_1077))) != 1UL), (**g_755))) & 0xE60CL)), l_3845[3])) || 0x0BBAL))
                    { /* block id: 1774 */
                        int32_t l_3932 = 1L;
                        (**g_3660) = (void*)0;
                        (*g_1120) |= ((((0UL < ((safe_div_func_uint16_t_u_u((+(safe_mod_func_uint64_t_u_u(((*g_756) = (safe_div_func_int32_t_s_s(p_13, (safe_unary_minus_func_uint8_t_u(p_13))))), (p_14 | l_3932)))), 1L)) ^ 0x8B07L)) != ((((((*l_3914) = ((safe_sub_func_int16_t_s_s(((l_3932 , ((((((((safe_add_func_int16_t_s_s(((l_3940 = l_3937) == (void*)0), l_3932)) && l_3941) , 0x24L) && 0x95L) , (void*)0) == l_3942) & (***g_3035)) ^ (*g_1966))) , (**g_3270)), 8UL)) == 0xEA302DD5L)) , 0L) == (***g_3035)) <= p_14) | p_14)) ^ p_13) , (-1L));
                    }
                    else
                    { /* block id: 1780 */
                        int64_t l_3943 = 0x47C3E6A21A4553E9LL;
                        return l_3943;
                    }
                    l_3944--;
                }
                (*g_2894) = (*g_2894);
            }
        }
        else
        { /* block id: 1787 */
            uint8_t l_3968 = 5UL;
            uint16_t *****l_3974 = (void*)0;
            int16_t l_4044[3][1];
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 1; j++)
                    l_4044[i][j] = 0x8C42L;
            }
            (*g_1120) = (((safe_lshift_func_int8_t_s_s(((((safe_lshift_func_uint8_t_u_u(p_14, ((safe_lshift_func_int16_t_s_u((g_732 = (**g_3270)), 9)) >= (safe_div_func_int64_t_s_s(((safe_sub_func_uint16_t_u_u(((1UL || (safe_mul_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(0x14A3L, ((((((((0L > ((*g_168) = (((*g_1966) = (safe_div_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(((((**g_3729) = (((((safe_lshift_func_int8_t_s_u(p_14, ((!(l_3773[0] == (l_3968 & ((*l_3890) != l_3969)))) ^ 0xF01168C03738A05BLL))) > l_3885) , (void*)0) != (void*)0) , (**g_3729))) ^ 0xBB6DAA38F6CDDC74LL) , p_14), l_3763)), l_3846))) | p_13))) == (**g_755)) ^ p_14) & (*g_3271)) > l_3885) & (***g_3660)) | (**g_3270)) <= l_3968))), 0x60L))) && (-6L)), (-6L))) != 0xD4B2BDB42307C6ADLL), 0x2AF6EC988F0DCD8DLL))))) ^ p_14) , 0x2A82L) & 0x30B4L), 5)) | 0x69998B29F391676ELL) == l_3773[0]);
            for (l_3755 = (-6); (l_3755 > (-21)); l_3755 = safe_sub_func_int16_t_s_s(l_3755, 2))
            { /* block id: 1795 */
                uint16_t *****l_3976 = &g_1542;
                uint32_t l_3977 = 0UL;
                uint64_t *** const **l_3994 = (void*)0;
                int32_t * const l_4023 = &g_156[5];
                for (g_140 = 0; (g_140 <= 58); g_140 = safe_add_func_int16_t_s_s(g_140, 1))
                { /* block id: 1798 */
                    l_3976 = ((((void*)0 == l_3974) & p_13) , l_3975[1][1]);
                    for (g_193 = 0; (g_193 <= 3); g_193 += 1)
                    { /* block id: 1802 */
                        l_3977--;
                        (**g_3660) = &p_14;
                    }
                }
                if (p_14)
                { /* block id: 1807 */
                    return (**g_696);
                }
                else
                { /* block id: 1809 */
                    uint32_t **** const *l_4005[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int32_t l_4011 = 0x44A35E7EL;
                    int16_t l_4024 = 0xE56FL;
                    int i;
                    if ((safe_mul_func_uint64_t_u_u(l_3773[0], (((safe_rshift_func_int32_t_s_u((safe_lshift_func_uint32_t_u_s(0xA88006A3L, 11)), 2)) || (safe_lshift_func_int64_t_s_s(8L, 33))) && (((safe_lshift_func_uint64_t_u_s((&g_47[3] != l_3990), 21)) | (safe_unary_minus_func_int32_t_s((safe_add_func_int8_t_s_s(((g_3995[2][7][2] = l_3994) != l_3999), p_13))))) ^ ((safe_mul_func_int64_t_s_s((safe_mod_func_uint8_t_u_u(((void*)0 != &g_694), 0x2EL)), 0x4B39DDA8F0DFBEAELL)) != p_14))))))
                    { /* block id: 1811 */
                        uint16_t *** const * const l_4009 = &g_652[0];
                        (*g_1120) ^= (((((*g_168) = 0x9691L) , (g_4006 = l_4005[6])) == ((((void*)0 != l_4009) & 0xE20423C3E28757FCLL) , l_4010)) > l_4011);
                        return p_14;
                    }
                    else
                    { /* block id: 1816 */
                        int16_t l_4017 = 0x987FL;
                        uint64_t **l_4018 = &g_756;
                        if (l_3968)
                            break;
                        (*g_1120) |= (safe_sub_func_uint16_t_u_u(((****g_1542) |= (((safe_rshift_func_uint16_t_u_s(((!l_4017) > p_13), ((((l_4018 == ((*g_242) , (***l_3999))) | p_13) && (*g_3271)) , (safe_lshift_func_uint8_t_u_s(((***l_3754) = ((safe_mul_func_int32_t_s_s(((**g_3270) | l_4017), (*g_1327))) & 0xDD3DL)), (*g_1966)))))) , l_4023) == &p_14)), 0UL));
                        return l_4024;
                    }
                }
            }
            l_4046 &= (safe_mod_func_uint16_t_u_u(((**g_160) = ((safe_lshift_func_int64_t_s_s((safe_div_func_int64_t_s_s(l_3968, p_14)), 26)) == l_4031)), ((l_3846 = ((***g_3035) = ((((safe_mod_func_uint32_t_u_u((safe_add_func_int16_t_s_s(((l_3773[0] = 4294967295UL) == (*****g_4006)), ((safe_sub_func_uint32_t_u_u(p_13, (*g_794))) && (safe_div_func_int8_t_s_s((((safe_sub_func_uint64_t_u_u(l_4042, 0L)) , 0x6FCDL) >= l_4043), p_13))))), p_13)) && (*g_3271)) <= l_4044[2][0]) ^ p_13))) | l_4045)));
        }
    }
    else
    { /* block id: 1831 */
        uint8_t l_4050 = 0xB7L;
        uint32_t *l_4057 = (void*)0;
        uint64_t * const *l_4072 = &g_756;
        int64_t *l_4073[7];
        uint32_t * const ** const l_4076[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint32_t * const ** const *l_4075 = &l_4076[1];
        int32_t l_4104 = (-4L);
        int32_t l_4116 = (-10L);
        int32_t l_4118 = (-8L);
        int32_t l_4119 = 0x5DCDE81EL;
        int32_t l_4120 = 1L;
        int32_t l_4121[5][9][5] = {{{1L,0xF31DE749L,0xA2D45ACCL,(-5L),(-9L)},{0x8A8FC3B5L,0xFD568123L,0L,1L,(-6L)},{1L,(-6L),3L,0L,0L},{(-2L),0L,8L,(-4L),0x8E35FE31L},{7L,0xBF892C16L,(-9L),0xFD568123L,1L},{0x6181EC1EL,0xBF892C16L,(-4L),(-9L),0x44DCD496L},{0x45C2B232L,0L,0x8E35FE31L,0x8E35FE31L,0L},{(-9L),(-6L),0xF31DE749L,0x84708F9FL,0x0458B3DBL},{0L,0xFD568123L,0x45C2B232L,(-1L),8L}},{{0x76594713L,0xF31DE749L,0L,(-7L),0L},{0L,(-9L),0x8B3FE7A3L,1L,0L},{(-9L),0x6181EC1EL,(-6L),7L,0xFFA9CE0BL},{0x45C2B232L,1L,0x84708F9FL,0x06405A25L,(-5L)},{0x6181EC1EL,0x84708F9FL,(-1L),(-10L),(-5L)},{7L,0x8A8FC3B5L,9L,0x7FC9813EL,0xFFA9CE0BL},{(-2L),0x7FC9813EL,0x7FC9813EL,(-2L),0L},{1L,(-5L),0xFD568123L,0x44DCD496L,0L},{0x8A8FC3B5L,0L,0L,0L,8L}},{{1L,(-1L),0x06E919EEL,0x44DCD496L,0x0458B3DBL},{0x06405A25L,9L,(-10L),(-2L),0L},{3L,0L,0L,0x7FC9813EL,0x44DCD496L},{0xCA3273E4L,0xA2D45ACCL,0L,(-10L),1L},{8L,0xFFA9CE0BL,0L,0x06405A25L,0x8E35FE31L},{0x8E35FE31L,0xCA3273E4L,0L,7L,0L},{(-7L),(-7L),(-10L),1L,(-6L)},{0x7FC9813EL,0x0458B3DBL,0x06E919EEL,(-7L),(-9L)},{0xA2D45ACCL,1L,0L,(-1L),1L}},{{(-6L),0x0458B3DBL,0xFD568123L,0x84708F9FL,0xCA3273E4L},{0xBF892C16L,1L,0xA2C3144CL,0L,0xFFA9CE0BL},{0x44DCD496L,3L,0L,0x8E35FE31L,0x06E919EEL},{0xA2D45ACCL,0L,(-10L),1L,0x8B3FE7A3L},{0xA2D45ACCL,0L,(-6L),0x44DCD496L,1L},{0x44DCD496L,0L,0x76594713L,0L,0x44DCD496L},{0xF31DE749L,0L,0xFFA9CE0BL,0x0458B3DBL,1L},{0x76594713L,(-9L),0x84708F9FL,8L,0xFD568123L},{0L,0x8A8FC3B5L,0xFD568123L,0L,1L}},{{0xA2C3144CL,8L,0x06405A25L,0L,0x44DCD496L},{1L,0xA2C3144CL,0L,0xFFA9CE0BL,1L},{0L,0x7FC9813EL,0x44DCD496L,(-5L),0x8B3FE7A3L},{0xBF892C16L,(-6L),0x8E35FE31L,(-5L),0x06E919EEL},{3L,0x0458B3DBL,0xBF892C16L,0xFFA9CE0BL,0xFFA9CE0BL},{9L,(-2L),9L,0L,3L},{0xF661669BL,0x8E35FE31L,0x45C2B232L,0L,0x0458B3DBL},{0xCA3273E4L,0x06405A25L,0L,8L,0x8E35FE31L},{0x7FC9813EL,1L,0x45C2B232L,0x0458B3DBL,0x76594713L}}};
        int16_t l_4123[8] = {0x71A3L,4L,4L,0x71A3L,4L,4L,0x71A3L,4L};
        int32_t l_4124 = 5L;
        uint32_t l_4172 = 0xF6BFFFE3L;
        uint8_t ***l_4173 = &g_1077;
        uint16_t **l_4201 = (void*)0;
        uint32_t ****l_4222 = &g_1754[1][0];
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_4073[i] = &g_48[0][1][0];
        for (g_735 = 0; (g_735 <= 2); g_735 += 1)
        { /* block id: 1834 */
            uint8_t l_4049[10][3][8] = {{{255UL,0xE5L,0UL,0x4CL,255UL,0xB5L,0x95L,0xCCL},{255UL,0xFEL,3UL,1UL,254UL,254UL,1UL,3UL},{0UL,0UL,0x16L,1UL,251UL,0x95L,4UL,0xC4L}},{{6UL,0UL,247UL,0xEAL,255UL,249UL,1UL,0xC4L},{0UL,1UL,0UL,1UL,0xA0L,0UL,255UL,3UL},{255UL,0xF1L,0UL,1UL,0x84L,248UL,0x1DL,0xCCL}},{{1UL,0xEAL,0x42L,0x4CL,1UL,0x08L,248UL,0xA6L},{251UL,0x93L,1UL,255UL,0x14L,0x20L,0UL,0xA0L},{1UL,246UL,6UL,255UL,8UL,251UL,0xE5L,2UL}},{{0xF7L,255UL,0UL,0x86L,0x4DL,6UL,249UL,255UL},{0x86L,254UL,255UL,0xCCL,255UL,0x06L,254UL,0UL},{0UL,255UL,0xB7L,7UL,0x01L,0UL,1UL,255UL}},{{0x31L,0x16L,4UL,253UL,6UL,0UL,0x08L,247UL},{0x9AL,252UL,0x50L,4UL,0x2BL,0x16L,254UL,0xC6L},{0x17L,6UL,255UL,0xF1L,0xFFL,0x86L,251UL,0UL}},{{4UL,253UL,1UL,2UL,1UL,253UL,4UL,1UL},{0xF9L,255UL,1UL,0UL,0x60L,255UL,0xC6L,3UL},{255UL,1UL,0x20L,255UL,0x60L,255UL,1UL,2UL}},{{0xF9L,253UL,0xEAL,3UL,1UL,0x06L,255UL,0UL},{4UL,255UL,255UL,0x42L,0xFFL,253UL,249UL,0xF9L},{0x17L,0UL,0x4CL,0xEAL,0x2BL,0UL,255UL,0xFFL}},{{0x9AL,2UL,252UL,249UL,6UL,0x7AL,0xF1L,255UL},{0xF1L,0xA6L,0xF9L,0x4DL,255UL,247UL,255UL,255UL},{0x93L,0x84L,0x36L,0x43L,255UL,0UL,2UL,0x8EL}},{{6UL,255UL,0xF7L,0xC4L,1UL,0x17L,0x06L,255UL},{255UL,0x3FL,0x31L,255UL,1UL,0UL,0UL,249UL},{0x14L,0xE5L,255UL,255UL,249UL,0UL,1UL,8UL}},{{255UL,0UL,0xCCL,0x16L,0xA6L,0x1DL,0x17L,0x06L},{6UL,0UL,255UL,0x4CL,0UL,0x43L,0x43L,0UL},{0xFFL,1UL,1UL,0xFFL,0UL,1UL,249UL,255UL}}};
            uint32_t ****l_4074 = (void*)0;
            int32_t l_4110 = 1L;
            int32_t l_4112[10][2][4] = {{{0x0CC03D31L,0x184B1FA7L,(-3L),(-3L)},{0x184B1FA7L,0x184B1FA7L,4L,(-1L)}},{{0xDA58BA06L,0x184B1FA7L,(-1L),(-3L)},{1L,0x184B1FA7L,(-1L),(-1L)}},{{0x0CC03D31L,0x184B1FA7L,(-3L),(-3L)},{0x184B1FA7L,0x184B1FA7L,4L,(-1L)}},{{0xDA58BA06L,0x184B1FA7L,(-1L),(-3L)},{1L,0x184B1FA7L,(-1L),(-1L)}},{{0x0CC03D31L,0x184B1FA7L,(-3L),(-3L)},{0x184B1FA7L,0x184B1FA7L,4L,(-1L)}},{{0xDA58BA06L,0x184B1FA7L,(-1L),(-3L)},{1L,0x184B1FA7L,(-1L),(-1L)}},{{0x0CC03D31L,0x184B1FA7L,(-3L),(-3L)},{0x184B1FA7L,0x184B1FA7L,4L,(-1L)}},{{0xDA58BA06L,0x184B1FA7L,(-1L),(-3L)},{1L,0x184B1FA7L,(-1L),(-1L)}},{{0x0CC03D31L,0x184B1FA7L,(-3L),(-3L)},{0x184B1FA7L,0x184B1FA7L,4L,(-1L)}},{{0xDA58BA06L,0x184B1FA7L,(-1L),(-3L)},{1L,0x184B1FA7L,(-1L),(-1L)}}};
            int i, j, k;
            if (((safe_div_func_int64_t_s_s(((l_4049[7][1][7] , (((**g_3729) = l_4050) , (safe_mul_func_int8_t_s_s(((safe_rshift_func_int64_t_s_u((safe_sub_func_uint64_t_u_u((((***g_4007) != l_4057) > (safe_rshift_func_uint32_t_u_s((safe_sub_func_int8_t_s_s((safe_mul_func_int32_t_s_s(5L, (safe_mod_func_int16_t_s_s((safe_add_func_int16_t_s_s((((**g_3270) >= (**g_3270)) && (((safe_sub_func_uint64_t_u_u(((((*****l_3752) |= (safe_add_func_uint32_t_u_u((l_4072 == ((((*g_3729) = (*g_3729)) == l_4073[5]) , l_4072)), p_13))) , l_4074) == l_4075), 1UL)) == l_4049[2][1][3]) ^ 0L)), l_4050)), l_4049[7][1][7])))), 1UL)), p_14))), l_4050)), 17)) | l_4050), l_4049[7][1][7])))) , p_14), p_14)) >= 18446744073709551615UL))
            { /* block id: 1838 */
                uint32_t *****l_4088 = &g_1753;
                int32_t l_4109[9];
                int32_t l_4115 = 0xBDC8432BL;
                int64_t l_4117 = 0x3E0E0F522C2C308ELL;
                int64_t l_4126 = 0x6CD1CDBBC35A6E2ELL;
                uint16_t l_4130 = 0x9E36L;
                int i;
                for (i = 0; i < 9; i++)
                    l_4109[i] = 0x903C9B6FL;
                for (g_78 = 1; (g_78 >= 0); g_78 -= 1)
                { /* block id: 1841 */
                    uint16_t l_4077[7] = {4UL,4UL,4UL,4UL,4UL,4UL,4UL};
                    int i;
                    (*g_1120) |= l_4077[3];
                    for (g_52 = 0; (g_52 <= 1); g_52 += 1)
                    { /* block id: 1845 */
                        int32_t l_4089[10][4] = {{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)},{(-9L),(-9L),(-9L),(-9L)}};
                        int i, j, k;
                        (*g_1120) = ((l_4089[6][0] = ((((void*)0 != (*g_694)) | (*g_1966)) <= (((*g_3215) = p_13) , (safe_div_func_uint32_t_u_u(((p_14 = ((**g_3729) ^ (((l_4049[7][1][7] ^ (safe_div_func_uint64_t_u_u((p_13 ^ ((0L || (l_4088 == &g_3759)) == 1L)), l_4050))) , 4294967295UL) != (-8L)))) , 4294967286UL), p_13))))) & (***g_3035));
                        (*g_1120) = l_4049[2][0][2];
                    }
                }
                if (p_13)
                    continue;
                for (g_78 = 0; (g_78 <= 1); g_78 += 1)
                { /* block id: 1856 */
                    const int8_t l_4098 = 0L;
                    int32_t l_4108 = 0xE09FA3BBL;
                    int32_t l_4114[1];
                    uint64_t l_4127 = 7UL;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_4114[i] = 0x77D7CF1CL;
                    if ((*g_1621))
                        break;
                    if (p_14)
                        break;
                    for (g_720 = 0; (g_720 <= 2); g_720 += 1)
                    { /* block id: 1861 */
                        uint16_t *l_4107[9] = {&g_123[8],&g_123[6],&g_123[8],&g_123[6],&g_123[8],&g_123[6],&g_123[8],&g_123[6],&g_123[8]};
                        int32_t l_4111 = 0xD078245CL;
                        int32_t l_4113[4];
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_4113[i] = 0x097604E2L;
                        (*g_1120) = ((safe_mod_func_int8_t_s_s(((1L >= p_14) & ((g_4094[0][4] = l_4092) == &l_4073[4])), (safe_rshift_func_uint32_t_u_s(l_4098, 24)))) , ((+((*g_1966) = (safe_add_func_int16_t_s_s((safe_sub_func_int16_t_s_s((*g_3271), (p_13 , (((((((((****g_1542)--) == (l_4108 |= l_4098)) , ((**g_3729) != 0L)) & p_13) == 1UL) , l_4109[4]) & p_13) > p_13)))), 7L)))) , 0xE8E9ADEEL));
                        l_4127++;
                    }
                }
                ++l_4130;
            }
            else
            { /* block id: 1871 */
                uint32_t l_4171 = 0x8CB8B5E5L;
                int32_t l_4176 = 1L;
                for (g_1949 = 0; (g_1949 <= 1); g_1949 += 1)
                { /* block id: 1874 */
                    int16_t l_4177 = (-4L);
                    int32_t l_4183[6] = {1L,1L,1L,1L,1L,1L};
                    int i, j;
                    if ((safe_sub_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((((**g_1077) |= (~(((((safe_sub_func_uint64_t_u_u(l_4123[g_735], (safe_unary_minus_func_int64_t_s(((safe_add_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u((!(safe_lshift_func_uint64_t_u_s(((p_14 , (((((252UL & (((**g_755) = (((**g_160) = ((safe_mul_func_uint64_t_u_u((safe_rshift_func_int32_t_s_s(p_14, (((((*g_1966) = l_4123[g_735]) , (safe_lshift_func_int32_t_s_s(((safe_add_func_int64_t_s_s((safe_mul_func_int64_t_s_s((safe_sub_func_uint32_t_u_u(((****g_3034) = 4294967294UL), ((((((safe_rshift_func_uint32_t_u_u(p_14, (safe_add_func_int64_t_s_s((((((safe_rshift_func_uint8_t_u_u((safe_unary_minus_func_uint32_t_u(p_14)), ((safe_div_func_int16_t_s_s(((((void*)0 == (*l_4072)) >= (*g_1966)) | 0L), l_4123[g_735])) >= 0xF837E3E4L))) , p_14) , 0xCD55EB224AFEFE86LL) , l_4121[1][2][2]) ^ (*g_1621)), p_13)))) > l_4171) , l_4171) , l_4171) , l_4119) , l_4123[g_735]))), 0x9D50C1F7F638B267LL)), 0x8BCFF3DA8FE22C55LL)) != p_14), l_4123[6]))) , p_13) , (*g_3489)))), p_14)) , p_14)) >= p_13)) < l_4123[g_735])) && (*g_1120)) , l_4172) , l_4049[7][1][7]) , &g_1077)) != l_4173), (**g_3729)))), (-1L))), g_4174)) >= 0x2051L))))) >= p_13) && 1UL) , 0x286D542DL) , l_4123[g_735]))) != l_4112[5][1][0]) ^ p_14), 0x3EL)), 6L)))
                    { /* block id: 1880 */
                        const uint32_t l_4175 = 4294967289UL;
                        if (l_4175)
                            break;
                        return (*g_242);
                    }
                    else
                    { /* block id: 1883 */
                        uint64_t l_4178 = 0UL;
                        l_4178++;
                        l_4183[1] &= (safe_lshift_func_uint8_t_u_u(0x33L, (l_4177 && ((*g_1120) |= p_14))));
                        (*g_1043) = &p_14;
                        return l_4104;
                    }
                }
            }
            for (p_14 = 7; (p_14 >= 0); p_14 -= 1)
            { /* block id: 1894 */
                const uint8_t l_4193 = 1UL;
                int8_t l_4202[7][1][5] = {{{7L,7L,7L,7L,7L}},{{1L,0xEBL,1L,0xEBL,1L}},{{7L,7L,7L,7L,7L}},{{1L,0xEBL,1L,0xEBL,1L}},{{7L,7L,7L,7L,7L}},{{1L,0xEBL,1L,0xEBL,1L}},{{7L,7L,7L,7L,7L}}};
                int i, j, k;
                for (g_1121 = 0; (g_1121 <= 1); g_1121 += 1)
                { /* block id: 1897 */
                    for (l_3852 = 1; (l_3852 >= 0); l_3852 -= 1)
                    { /* block id: 1900 */
                        int8_t l_4184 = 0xA6L;
                        return l_4184;
                    }
                    l_4118 = 9L;
                }
                for (g_2075 = 2; (g_2075 <= 7); g_2075 += 1)
                { /* block id: 1907 */
                    int8_t l_4185 = (-8L);
                    uint32_t ****l_4203 = &g_1754[1][0];
                    if ((((((((0x22759BB5F9E5A632LL == ((*g_756) = l_4185)) || (safe_lshift_func_int64_t_s_s((((l_4188[0] != (((((safe_rshift_func_uint32_t_u_s(0x13FC51DBL, 6)) , (safe_mod_func_int32_t_s_s(l_4193, (safe_lshift_func_uint16_t_u_u((+(p_14 >= (((***g_3997) , l_4193) ^ (!(safe_rshift_func_uint64_t_u_s((((safe_unary_minus_func_uint64_t_u((l_4193 < (*g_168)))) & l_4124) | p_13), l_4120)))))), 15))))) , l_4050) || 0x063FBC88L) , l_4201)) | (-8L)) , l_4202[6][0][0]), l_4185))) , p_14) , (void*)0) != &l_4072) , l_4203) != (*g_3758)))
                    { /* block id: 1909 */
                        if (p_14)
                            break;
                    }
                    else
                    { /* block id: 1911 */
                        uint64_t l_4212 = 18446744073709551615UL;
                        (*g_1120) ^= (safe_mod_func_uint8_t_u_u((safe_div_func_uint8_t_u_u((safe_lshift_func_int64_t_s_s(p_13, p_13)), ((safe_sub_func_uint64_t_u_u(((-1L) && ((l_4212 ^ ((p_14 && (safe_div_func_int16_t_s_s((safe_div_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((p_13 | ((****g_4007) = ((void*)0 != l_4221))), 5)), ((0xB07144F3FD349848LL ^ p_13) , (*g_3271)))), l_4104)), p_13))) , 18446744073709551608UL)) ^ 7UL)), l_4112[8][0][2])) & 1UL))), l_4212));
                        (**g_3660) = &p_14;
                    }
                    (**g_3479) = &p_14;
                    (*g_1120) = p_14;
                }
            }
        }
        (*g_1120) = ((((*g_242) = 0xB7D8D676L) , ((void*)0 == l_4222)) , p_13);
    }
    (*g_1120) = (*g_1621);
    (*g_3203) = ((safe_add_func_int16_t_s_s((l_4188[0] != l_4188[0]), ((p_14 >= (!(!(*g_1966)))) & (safe_mod_func_int32_t_s_s((l_4235[2] = (0x686DE9ABL != ((*g_794) = ((((safe_sub_func_uint32_t_u_u(((*****g_4006) = 0x54706E34L), 1UL)) <= (((*g_1120) &= (((((*l_4233) = ((p_13 == (safe_lshift_func_int8_t_s_s(p_13, 1))) , (void*)0)) == &g_3729) != 8L) > p_14)) & p_14)) != p_13) >= (-1L))))), g_4236[0][2]))))) && (****g_1542));
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_3729 g_47
 * writes:
 */
static int64_t * func_26(int32_t  p_27, int64_t * p_28, uint8_t  p_29, int64_t * p_30)
{ /* block id: 1087 */
    int64_t l_2481[10] = {0L,0L,2L,0L,0L,2L,0L,0L,2L,0L};
    uint16_t *l_2485[6][8][3] = {{{&g_74[0][4],&g_1509[2],(void*)0},{(void*)0,(void*)0,&g_1509[3]},{(void*)0,&g_123[8],&g_1509[3]},{&g_74[0][4],(void*)0,&g_123[8]},{&g_123[3],&g_1509[2],&g_1509[3]},{&g_74[0][4],&g_1509[2],&g_1509[3]},{&g_1509[2],(void*)0,&g_1509[2]},{(void*)0,&g_123[8],(void*)0}},{{&g_74[0][4],(void*)0,&g_1509[3]},{&g_74[1][3],&g_1509[2],&g_1509[2]},{&g_123[8],&g_1509[2],&g_123[8]},{(void*)0,(void*)0,&g_74[1][1]},{&g_1509[2],&g_123[8],&g_123[8]},{&g_123[8],(void*)0,(void*)0},{&g_74[0][4],&g_1509[2],&g_74[1][1]},{&g_74[0][4],&g_1509[2],(void*)0}},{{(void*)0,(void*)0,&g_1509[3]},{(void*)0,&g_74[0][4],&g_1509[2]},{&g_74[1][1],&g_74[0][3],&g_74[0][5]},{&g_123[8],(void*)0,(void*)0},{&g_1509[2],(void*)0,&g_123[3]},{&g_1509[3],&g_74[0][3],&g_74[0][4]},{(void*)0,&g_74[0][4],&g_74[0][3]},{&g_1509[2],&g_74[0][3],&g_1509[2]}},{{&g_1509[3],(void*)0,&g_74[0][4]},{&g_1509[3],(void*)0,&g_74[0][0]},{&g_123[8],&g_74[0][3],&g_123[3]},{&g_1509[3],&g_74[0][4],&g_74[0][5]},{&g_1509[3],&g_74[0][3],&g_74[0][3]},{(void*)0,(void*)0,&g_123[3]},{&g_74[1][1],(void*)0,&g_74[0][4]},{(void*)0,&g_74[0][3],(void*)0}},{{&g_123[8],&g_74[0][4],&g_1509[2]},{&g_74[1][1],&g_74[0][3],&g_74[0][5]},{&g_123[8],(void*)0,(void*)0},{&g_1509[2],(void*)0,&g_123[3]},{&g_1509[3],&g_74[0][3],&g_74[0][4]},{(void*)0,&g_74[0][4],&g_74[0][3]},{&g_1509[2],&g_74[0][3],&g_1509[2]},{&g_1509[3],(void*)0,&g_74[0][4]}},{{&g_1509[3],(void*)0,&g_74[0][0]},{&g_123[8],&g_74[0][3],&g_123[3]},{&g_1509[3],&g_74[0][4],&g_74[0][5]},{&g_1509[3],&g_74[0][3],&g_74[0][3]},{(void*)0,(void*)0,&g_123[3]},{&g_74[1][1],(void*)0,&g_74[0][4]},{(void*)0,&g_74[0][3],(void*)0},{&g_123[8],&g_74[0][4],&g_1509[2]}}};
    const uint64_t l_2491 = 0xD77ED616DD76C8E4LL;
    int32_t l_2492 = 0x948E2C0BL;
    int32_t ***l_2504 = (void*)0;
    uint8_t l_2505 = 0x3BL;
    uint16_t l_2508 = 65528UL;
    int32_t *l_2509 = &g_156[2];
    uint32_t *l_2547 = &g_174;
    uint32_t * const *l_2546[6][9] = {{&l_2547,&l_2547,(void*)0,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547},{&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,(void*)0,&l_2547,(void*)0},{&l_2547,&l_2547,(void*)0,(void*)0,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547},{&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547},{&l_2547,(void*)0,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,(void*)0},{&l_2547,&l_2547,&l_2547,&l_2547,&l_2547,(void*)0,(void*)0,&l_2547,&l_2547}};
    uint32_t * const **l_2545 = &l_2546[4][8];
    uint32_t * const ***l_2544 = &l_2545;
    int32_t l_2573 = 9L;
    int32_t l_2581[9] = {0x9C3BED82L,(-1L),0x9C3BED82L,(-1L),0x9C3BED82L,(-1L),0x9C3BED82L,(-1L),0x9C3BED82L};
    int16_t l_2586 = (-5L);
    int32_t l_2587 = (-1L);
    int32_t l_2588 = 1L;
    int32_t *****l_2627[6][10] = {{&g_2272,(void*)0,&g_2272,&g_2272,&g_2272,(void*)0,&g_2272,(void*)0,(void*)0,&g_2272},{(void*)0,&g_2272,&g_2272,&g_2272,&g_2272,(void*)0,(void*)0,&g_2272,(void*)0,(void*)0},{&g_2272,&g_2272,&g_2272,&g_2272,&g_2272,&g_2272,&g_2272,&g_2272,&g_2272,&g_2272},{&g_2272,(void*)0,(void*)0,&g_2272,&g_2272,(void*)0,(void*)0,&g_2272,&g_2272,(void*)0},{&g_2272,(void*)0,&g_2272,&g_2272,(void*)0,&g_2272,&g_2272,(void*)0,&g_2272,&g_2272},{(void*)0,(void*)0,&g_2272,(void*)0,&g_2272,&g_2272,&g_2272,(void*)0,&g_2272,(void*)0}};
    uint32_t l_2650 = 18446744073709551614UL;
    const uint32_t *l_2682 = (void*)0;
    int8_t l_2715[3];
    uint64_t l_2723[2][6][2] = {{{0UL,0xE363BEB944CFA460LL},{0UL,0UL},{0xE363BEB944CFA460LL,0UL},{0UL,0xE363BEB944CFA460LL},{0UL,0UL},{0xE363BEB944CFA460LL,0UL}},{{0UL,0xE363BEB944CFA460LL},{0UL,0UL},{0xE363BEB944CFA460LL,0UL},{0UL,0xE363BEB944CFA460LL},{0UL,0UL},{0xE363BEB944CFA460LL,0UL}}};
    int32_t ***l_2797 = (void*)0;
    uint32_t *** const l_2836 = &g_1326[2];
    uint32_t l_2913 = 0UL;
    uint32_t l_2932[9];
    uint32_t ****l_3037 = &g_3035;
    int64_t l_3075 = 0x459FCB552B45F9CBLL;
    uint64_t **l_3085 = (void*)0;
    uint32_t * const **l_3210 = (void*)0;
    uint32_t * const ***l_3209 = &l_3210;
    uint32_t * const ****l_3208 = &l_3209;
    int32_t l_3223 = 0L;
    int64_t l_3258 = 0xAC814CC12CC6F149LL;
    const int16_t *l_3268[2];
    const int16_t **l_3267 = &l_3268[1];
    uint16_t l_3312 = 0x9E83L;
    uint32_t l_3349 = 1UL;
    uint32_t l_3360 = 0UL;
    uint8_t **l_3569 = &g_1078[1];
    uint8_t l_3572[4];
    uint32_t ***l_3601[10] = {&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096};
    uint64_t *** const *l_3707 = &g_754[0];
    uint32_t l_3731 = 0xFE9C5551L;
    int16_t l_3737 = 0x97D5L;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_2715[i] = 0xEEL;
    for (i = 0; i < 9; i++)
        l_2932[i] = 18446744073709551612UL;
    for (i = 0; i < 2; i++)
        l_3268[i] = &g_732;
    for (i = 0; i < 4; i++)
        l_3572[i] = 1UL;
    return (*g_3729);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int64_t  func_31(const int64_t * p_32, int32_t  p_33, uint8_t  p_34, int64_t * p_35, uint16_t  p_36)
{ /* block id: 1085 */
    uint16_t l_2473 = 65535UL;
    return l_2473;
}


/* ------------------------------------------ */
/* 
 * reads : g_142 g_1043 g_1966 g_1670 g_1077 g_1078 g_737 g_51 g_756 g_140 g_688 g_1120 g_123
 * writes: g_142 g_51 g_737 g_2465 g_735 g_1670 g_1121
 */
static int64_t * func_37(int16_t  p_38, int32_t  p_39, int8_t  p_40, uint32_t  p_41, int64_t * p_42)
{ /* block id: 2 */
    uint32_t l_2345 = 4294967295UL;
    int64_t l_2352 = 0x651FC72BC93B27B0LL;
    uint16_t *****l_2369 = &g_1542;
    int8_t l_2372 = 0xADL;
    int32_t l_2380[6] = {0xC59934C8L,0xC59934C8L,0xC59934C8L,0xC59934C8L,0xC59934C8L,0xC59934C8L};
    uint32_t *l_2396[8][10] = {{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174},{&g_174,&g_174,(void*)0,&g_174,&g_174,(void*)0,&g_174,&g_174,(void*)0,&g_174},{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174},{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174},{&g_174,&g_174,(void*)0,&g_174,&g_174,(void*)0,&g_174,&g_174,(void*)0,&g_174},{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174},{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174},{&g_174,&g_174,(void*)0,&g_174,&g_174,(void*)0,&g_174,&g_174,(void*)0,&g_174}};
    uint32_t **l_2395 = &l_2396[6][0];
    uint8_t ** const l_2453[4] = {&g_1078[1],&g_1078[1],&g_1078[1],&g_1078[1]};
    int32_t l_2455[5];
    int i, j;
    for (i = 0; i < 5; i++)
        l_2455[i] = 0x311AD497L;
    for (p_41 = 0; (p_41 >= 17); p_41++)
    { /* block id: 5 */
        const int32_t l_2341 = 1L;
        int16_t l_2365 = (-1L);
        int16_t *l_2381 = (void*)0;
        const uint16_t *****l_2382 = &g_1686;
        int64_t *l_2385 = &g_142;
        uint8_t *** const l_2392 = (void*)0;
        uint32_t * const ***l_2409 = (void*)0;
    }
    for (g_142 = 15; (g_142 <= (-5)); g_142 = safe_sub_func_int8_t_s_s(g_142, 9))
    { /* block id: 1071 */
        int32_t *l_2435[2];
        uint32_t **l_2436 = (void*)0;
        uint32_t l_2454 = 1UL;
        const uint32_t *l_2463 = &g_2464;
        const uint32_t **l_2462[2];
        int16_t *l_2467[2][10][1];
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_2435[i] = &g_1121;
        for (i = 0; i < 2; i++)
            l_2462[i] = &l_2463;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 10; j++)
            {
                for (k = 0; k < 1; k++)
                    l_2467[i][j][k] = (void*)0;
            }
        }
        l_2435[1] = ((*g_1043) = &l_2380[4]);
        p_39 = (l_2436 != ((l_2455[4] ^= ((((safe_mod_func_uint64_t_u_u((safe_mod_func_int8_t_s_s((safe_rshift_func_int32_t_s_s((p_41 , (((((((safe_rshift_func_int8_t_s_s((safe_lshift_func_int32_t_s_s((safe_lshift_func_int32_t_s_u((((*g_1966) < (((safe_lshift_func_uint32_t_u_u(0UL, 18)) < ((safe_rshift_func_int16_t_s_s(((p_40 , l_2453[1]) == (void*)0), 1)) , 5UL)) , ((**g_1077) &= p_39))) >= 0x97L), 11)), p_38)), 0)) && (**g_1043)) | l_2345) & 65535UL) <= (*g_51)) | p_39) & l_2454)), l_2380[4])), l_2345)), 3UL)) | 4UL) || (*g_756)) , 0xDEL)) , &l_2396[7][7]));
        (*g_1120) = ((0x38L ^ (safe_lshift_func_uint32_t_u_u((safe_lshift_func_int8_t_s_s(((*g_1966) = (safe_rshift_func_int16_t_s_s(((g_2465 = &l_2454) != &p_41), (g_735 = g_688)))), 0)), 16))) < (safe_mul_func_int16_t_s_s((&l_2435[1] == (void*)0), (p_38 || p_41))));
        (*g_1043) = (g_123[2] , &p_39);
    }
    return &g_142;
}


/* ------------------------------------------ */
/* 
 * reads : g_50 g_48 g_52 g_5 g_76 g_77 g_51 g_78 g_94 g_85 g_123 g_140 g_142 g_116 g_155 g_156 g_160 g_174 g_179 g_168 g_241 g_242 g_289 g_161 g_260 g_193 g_74 g_582 g_603 g_670 g_688 g_636 g_694 g_667 g_732 g_737 g_695 g_696 g_751 g_754 g_794 g_755 g_756 g_735 g_861 g_931 g_981 g_1043 g_1095 g_1077 g_1078 g_1119 g_1120 g_1121 g_1207 g_1038 g_720 g_1327 g_1350 g_855 g_1573 g_1621 g_1966 g_1670 g_2168 g_2173 g_2272 g_1949
 * writes: g_51 g_74 g_76 g_52 g_78 g_94 g_85 g_116 g_123 g_140 g_142 g_156 g_160 g_161 g_168 g_174 g_179 g_47 g_260 g_48 g_193 g_582 g_242 g_652 g_636 g_667 g_720 g_732 g_735 g_981 g_1095 g_1098 g_737 g_1121 g_1207 g_241 g_1119 g_1542 g_1078 g_1573 g_2173 g_1670 g_1120 g_1949 g_1878
 */
static int32_t * func_45(int64_t * p_46)
{ /* block id: 6 */
    int32_t *l_49 = (void*)0;
    uint64_t l_1664 = 0xFCD50CE7771FE029LL;
    uint32_t ***l_1714 = (void*)0;
    int32_t l_1761 = 0x3C90C651L;
    int32_t l_1764 = 4L;
    int32_t l_1766 = 4L;
    uint8_t l_1768 = 0x2AL;
    uint32_t ***l_1774 = &g_1096;
    int64_t l_1834[2][4] = {{0x3A3E0CB062DA633ALL,0x3A3E0CB062DA633ALL,0x3A3E0CB062DA633ALL,0x3A3E0CB062DA633ALL},{0x3A3E0CB062DA633ALL,0x3A3E0CB062DA633ALL,0x3A3E0CB062DA633ALL,0x3A3E0CB062DA633ALL}};
    int32_t l_1838 = 0L;
    int32_t l_1844[2][7] = {{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)},{0L,0L,0L,0L,0L,0L,0L}};
    int32_t l_1955 = 0x5C09E89EL;
    int32_t ****l_1988 = (void*)0;
    uint64_t **l_2029 = &g_756;
    const int32_t *l_2052 = &l_1764;
    uint32_t *l_2063 = &g_174;
    uint32_t **l_2062 = &l_2063;
    uint16_t **l_2110 = (void*)0;
    int16_t l_2129[2];
    uint32_t l_2158 = 0x4BA80816L;
    uint32_t l_2178 = 0xD1D62711L;
    int32_t **l_2185 = &g_51;
    uint32_t *l_2207[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    const int32_t l_2299 = 0x587786BCL;
    uint8_t l_2332 = 0UL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_2129[i] = 0x547BL;
    (*g_50) = l_49;
    if ((safe_div_func_uint8_t_u_u((func_55((*p_46)) , 0x59L), g_603[0])))
    { /* block id: 690 */
        int16_t l_1655 = 0xAF92L;
        uint32_t l_1674 = 4294967289UL;
        const int32_t *l_1675 = &g_85;
        int32_t l_1700 = 0x977D33C0L;
        uint16_t ***** const l_1701 = &g_1542;
        uint16_t **l_1717 = &g_161;
        int32_t *** const l_1736[8] = {&g_241[4][2],&g_241[4][2],&g_241[4][2],&g_241[4][2],&g_241[4][2],&g_241[4][2],&g_241[4][2],&g_241[4][2]};
        int32_t *** const *l_1735[7] = {&l_1736[0],&l_1736[0],&l_1736[0],&l_1736[0],&l_1736[0],&l_1736[0],&l_1736[0]};
        int32_t *** const **l_1734[4];
        int32_t l_1762 = 7L;
        int32_t l_1763[1];
        uint32_t ***l_1775[10] = {&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096};
        uint16_t l_1917 = 0xC753L;
        int8_t *l_1967[7] = {&g_94,&g_94,&g_94,&g_94,&g_94,&g_94,&g_94};
        int32_t *l_2005 = (void*)0;
        uint32_t *l_2045 = (void*)0;
        uint32_t **l_2044 = &l_2045;
        int32_t * const l_2074 = &g_2075;
        int32_t * const *l_2073 = &l_2074;
        int32_t * const **l_2072 = &l_2073;
        int32_t * const ***l_2071 = &l_2072;
        int32_t * const ****l_2070 = &l_2071;
        uint8_t l_2118 = 0xB7L;
        int i;
        for (i = 0; i < 4; i++)
            l_1734[i] = &l_1735[5];
        for (i = 0; i < 1; i++)
            l_1763[i] = (-9L);
        for (g_116 = 0; (g_116 > 43); g_116++)
        { /* block id: 693 */
            uint16_t l_1654 = 0x6F9BL;
            int32_t ***l_1660[4][4][2] = {{{&g_241[5][3],&g_241[1][3]},{&g_241[3][2],&g_241[6][0]},{&g_241[3][2],&g_241[1][3]},{&g_241[5][3],&g_241[3][2]}},{{&g_241[1][3],&g_241[6][0]},{&g_241[3][2],&g_241[3][2]},{&g_241[5][3],&g_241[3][2]},{&g_241[3][2],&g_241[6][0]}},{{&g_241[1][3],&g_241[3][2]},{&g_241[5][3],&g_241[1][3]},{&g_241[3][2],&g_241[6][0]},{&g_241[3][2],&g_241[1][3]}},{{&g_241[5][3],&g_241[3][2]},{&g_241[1][3],&g_241[6][0]},{&g_241[3][2],&g_241[3][2]},{&g_241[5][3],&g_241[3][2]}}};
            int32_t l_1663 = 0x3C93C2EEL;
            const uint16_t **l_1730 = (void*)0;
            const uint16_t *l_1732[5];
            const uint16_t **l_1731 = &l_1732[2];
            uint32_t *****l_1875 = &g_1753;
            uint32_t *l_1877 = &g_174;
            uint64_t l_1950 = 3UL;
            int8_t *l_1965 = (void*)0;
            int8_t **l_1968 = (void*)0;
            const int32_t **l_1986[8][6][5] = {{{(void*)0,(void*)0,&l_1675,&l_1675,&l_1675},{(void*)0,&l_1675,&l_1675,(void*)0,&l_1675},{&l_1675,&l_1675,&l_1675,(void*)0,&l_1675},{(void*)0,&l_1675,(void*)0,&l_1675,&l_1675},{(void*)0,&l_1675,(void*)0,&l_1675,&l_1675},{(void*)0,&l_1675,(void*)0,&l_1675,&l_1675}},{{&l_1675,&l_1675,&l_1675,&l_1675,(void*)0},{&l_1675,&l_1675,(void*)0,&l_1675,&l_1675},{&l_1675,(void*)0,(void*)0,(void*)0,&l_1675},{&l_1675,&l_1675,(void*)0,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{&l_1675,(void*)0,&l_1675,&l_1675,&l_1675}},{{(void*)0,&l_1675,&l_1675,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{(void*)0,&l_1675,&l_1675,(void*)0,(void*)0},{&l_1675,(void*)0,&l_1675,(void*)0,&l_1675},{&l_1675,&l_1675,(void*)0,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675}},{{&l_1675,&l_1675,(void*)0,&l_1675,&l_1675},{&l_1675,(void*)0,&l_1675,(void*)0,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{(void*)0,&l_1675,&l_1675,&l_1675,&l_1675},{(void*)0,(void*)0,&l_1675,&l_1675,&l_1675},{(void*)0,&l_1675,&l_1675,(void*)0,&l_1675}},{{&l_1675,&l_1675,&l_1675,(void*)0,&l_1675},{(void*)0,&l_1675,(void*)0,&l_1675,&l_1675},{(void*)0,&l_1675,(void*)0,&l_1675,&l_1675},{(void*)0,&l_1675,(void*)0,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{(void*)0,&l_1675,(void*)0,&l_1675,&l_1675}},{{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,(void*)0},{(void*)0,&l_1675,&l_1675,&l_1675,&l_1675},{&l_1675,(void*)0,(void*)0,&l_1675,(void*)0},{&l_1675,&l_1675,&l_1675,(void*)0,&l_1675},{(void*)0,(void*)0,&l_1675,&l_1675,&l_1675}},{{&l_1675,&l_1675,(void*)0,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,(void*)0,&l_1675},{(void*)0,&l_1675,&l_1675,&l_1675,&l_1675},{&l_1675,(void*)0,(void*)0,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{(void*)0,(void*)0,&l_1675,(void*)0,(void*)0}},{{&l_1675,&l_1675,(void*)0,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{(void*)0,&l_1675,(void*)0,(void*)0,(void*)0},{&l_1675,&l_1675,&l_1675,&l_1675,&l_1675},{(void*)0,&l_1675,&l_1675,&l_1675,&l_1675}}};
            uint64_t **l_2028[3];
            int32_t *l_2031 = &g_85;
            uint64_t l_2058[8][10][3] = {{{8UL,0x11DD2371256E9FECLL,1UL},{0xBC29D3301F14FCB7LL,0xAFA5B509AC7E2260LL,0x9F0FE59950011876LL},{0UL,1UL,0UL},{0x5E0BEE9A8774F262LL,0x5E0BEE9A8774F262LL,0UL},{0xAFA5B509AC7E2260LL,0UL,6UL},{0UL,18446744073709551615UL,0x532C824A81866794LL},{0UL,0xFF994EEDD60BDDB9LL,0UL},{0UL,0UL,0x532C824A81866794LL},{1UL,0UL,6UL},{0x09E124788AA34B9ELL,18446744073709551609UL,0UL}},{{7UL,18446744073709551609UL,0UL},{0x11DD2371256E9FECLL,0UL,0x9F0FE59950011876LL},{18446744073709551608UL,18446744073709551615UL,1UL},{0x3AF64B8289187FCCLL,1UL,1UL},{18446744073709551607UL,0x532C824A81866794LL,0x78D139F4CC2CCED8LL},{0UL,18446744073709551607UL,0x2453E3E6209C7E2ELL},{5UL,0x81AB890E949B0315LL,1UL},{18446744073709551610UL,7UL,0xE7B927FC6537A66DLL},{0UL,0UL,18446744073709551607UL},{0UL,8UL,5UL}},{{18446744073709551610UL,18446744073709551615UL,1UL},{5UL,0x07A2D213FA1488B9LL,0x81AB890E949B0315LL},{0UL,7UL,0xBC29D3301F14FCB7LL},{18446744073709551607UL,3UL,0UL},{0x3AF64B8289187FCCLL,0x3F689F933589CB6BLL,0x09E124788AA34B9ELL},{18446744073709551608UL,1UL,0x11DD2371256E9FECLL},{0x11DD2371256E9FECLL,0UL,0UL},{7UL,18446744073709551612UL,18446744073709551615UL},{0x09E124788AA34B9ELL,0UL,18446744073709551615UL},{1UL,0x5120FC0F43E338D5LL,0UL}},{{0x2453E3E6209C7E2ELL,18446744073709551611UL,3UL},{1UL,1UL,7UL},{1UL,1UL,1UL},{3UL,0xFF994EEDD60BDDB9LL,0xAFA5B509AC7E2260LL},{0x22730323051AC360LL,18446744073709551609UL,18446744073709551607UL},{8UL,0x6F0547E66C3780FELL,1UL},{0xEEC969F5E87415B5LL,0x78D139F4CC2CCED8LL,0x22730323051AC360LL},{3UL,0x11DD2371256E9FECLL,0xFF994EEDD60BDDB9LL},{0UL,0UL,1UL},{0xDE35C58CD72EA4DFLL,18446744073709551612UL,18446744073709551610UL}},{{7UL,18446744073709551613UL,0x63FA30A74C72A074LL},{1UL,3UL,3UL},{6UL,0x5120FC0F43E338D5LL,3UL},{0xE06E8B0C88CA6482LL,18446744073709551614UL,0x63FA30A74C72A074LL},{0UL,0UL,18446744073709551610UL},{0x81AB890E949B0315LL,0x09E124788AA34B9ELL,1UL},{0UL,0UL,0xFF994EEDD60BDDB9LL},{0x3AF64B8289187FCCLL,0UL,0x22730323051AC360LL},{18446744073709551612UL,7UL,1UL},{5UL,1UL,18446744073709551607UL}},{{0xAFA5B509AC7E2260LL,18446744073709551607UL,0xAFA5B509AC7E2260LL},{0UL,0xBC29D3301F14FCB7LL,1UL},{0x11DD2371256E9FECLL,18446744073709551615UL,7UL},{18446744073709551609UL,1UL,3UL},{18446744073709551607UL,1UL,0UL},{18446744073709551609UL,0xDE35C58CD72EA4DFLL,18446744073709551613UL},{0x11DD2371256E9FECLL,0x3F689F933589CB6BLL,0xDE35C58CD72EA4DFLL},{0UL,0x22730323051AC360LL,18446744073709551609UL},{0xAFA5B509AC7E2260LL,0UL,0UL},{5UL,3UL,0x07A2D213FA1488B9LL}},{{18446744073709551612UL,0UL,6UL},{0x3AF64B8289187FCCLL,0UL,0xEEC969F5E87415B5LL},{0UL,18446744073709551615UL,0UL},{0x81AB890E949B0315LL,0xE06E8B0C88CA6482LL,0x6F0547E66C3780FELL},{0UL,0x5E0BEE9A8774F262LL,0xB284F57D3CBA7106LL},{0xE06E8B0C88CA6482LL,0x5FA2E49C400B3245LL,0x532C824A81866794LL},{6UL,0x5FA2E49C400B3245LL,1UL},{1UL,0x5E0BEE9A8774F262LL,18446744073709551611UL},{7UL,0xE06E8B0C88CA6482LL,0UL},{0xDE35C58CD72EA4DFLL,18446744073709551615UL,18446744073709551608UL}},{{0UL,0UL,0x5E0BEE9A8774F262LL},{3UL,0UL,0UL},{0xEEC969F5E87415B5LL,3UL,0x778EBEB2B4D74F8ELL},{8UL,0UL,18446744073709551615UL},{0x22730323051AC360LL,0x22730323051AC360LL,8UL},{3UL,0x3F689F933589CB6BLL,18446744073709551609UL},{1UL,0xDE35C58CD72EA4DFLL,0UL},{1UL,1UL,0xF7C38FABBC9A8288LL},{0x2453E3E6209C7E2ELL,1UL,0UL},{1UL,18446744073709551615UL,18446744073709551609UL}}};
            uint8_t l_2076 = 0x5BL;
            int32_t *l_2077 = &g_78;
            int32_t *l_2080 = &g_156[4];
            int64_t l_2108 = (-3L);
            uint16_t *****l_2121[1][8] = {{&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542,&g_1542}};
            uint16_t l_2130[3][2] = {{65528UL,65528UL},{0xFB2AL,65528UL},{65528UL,0xFB2AL}};
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_1732[i] = &g_1178;
            for (i = 0; i < 3; i++)
                l_2028[i] = &g_756;
        }
        (*g_1120) ^= (*l_2052);
    }
    else
    { /* block id: 943 */
        int8_t l_2167 = 0xD1L;
        int32_t **l_2183 = &l_49;
        int32_t **l_2184 = &g_51;
        uint32_t *l_2208 = &g_1878;
        int32_t ***l_2271 = &g_241[3][2];
        int32_t ****l_2270 = &l_2271;
        uint64_t ****l_2327 = (void*)0;
        int32_t l_2330 = 4L;
        for (g_140 = 0; (g_140 <= 19); g_140++)
        { /* block id: 946 */
            int32_t l_2156 = 5L;
            int32_t l_2157[3][5][3] = {{{9L,(-1L),9L},{0xE75D034EL,0xC5A82F23L,0x3F14C07EL},{0xE75D034EL,0xE75D034EL,0xC5A82F23L},{9L,0xC5A82F23L,0xC5A82F23L},{0xC5A82F23L,(-1L),0x3F14C07EL}},{{9L,(-1L),9L},{0xE75D034EL,0xC5A82F23L,0x3F14C07EL},{0xE75D034EL,0xE75D034EL,0xC5A82F23L},{9L,9L,9L},{9L,0xE75D034EL,(-1L)}},{{0x3F14C07EL,0xE75D034EL,0x3F14C07EL},{0xC5A82F23L,9L,(-1L)},{0xC5A82F23L,0xC5A82F23L,9L},{0x3F14C07EL,9L,9L},{9L,0xE75D034EL,(-1L)}}};
            int32_t **l_2181 = &g_1120;
            uint32_t l_2187 = 0x3DA6F81DL;
            uint16_t ****l_2232 = &g_652[0];
            int i, j, k;
            for (g_1573 = 0; (g_1573 >= 43); ++g_1573)
            { /* block id: 949 */
                int32_t *l_2154 = &g_85;
                int32_t *l_2155[10] = {&g_1121,&g_1121,&l_1761,&g_1121,&g_1121,&l_1761,&g_1121,&g_1121,&l_1761,&g_1121};
                int i;
                l_2158--;
                for (g_737 = 0; g_737 < 10; g_737 += 1)
                {
                    l_2155[g_737] = (void*)0;
                }
            }
            if ((((*g_1966) , (safe_mul_func_uint8_t_u_u(((**g_1077) = (safe_add_func_uint16_t_u_u(((((safe_lshift_func_uint16_t_u_s(l_2167, 15)) == ((g_2168 ^ (safe_mul_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(((((g_2173 , 1UL) ^ (3L | 0x7ACA688F9F6B1065LL)) , (safe_mul_func_uint32_t_u_u((((((*g_1966) , (((safe_lshift_func_uint32_t_u_u(((l_2167 <= l_2167) == 0xC1050A3E8012F9C1LL), (*g_1327))) & l_2157[1][2][1]) ^ 0UL)) ^ 2UL) > (*g_1966)) || l_2157[2][2][0]), (*g_1120)))) > 0x3F5C9ABAL), l_2167)), 7L))) > l_2167)) || l_2167) , (*g_168)), (-1L)))), (*l_2052)))) != 0x3692387D44FCCA63LL))
            { /* block id: 954 */
                int32_t *l_2186 = &g_52;
                int8_t l_2209 = 0xB7L;
                if (l_2178)
                    break;
                for (g_2173 = 0; (g_2173 != 48); g_2173++)
                { /* block id: 958 */
                    int32_t ***l_2182[6] = {&g_1043,&g_1043,&g_1043,&g_1043,&g_1043,&g_1043};
                    uint32_t *l_2203 = &g_1878;
                    uint32_t *l_2205 = &g_582;
                    int16_t l_2213 = 1L;
                    int i;
                    (*g_1043) = &l_1838;
                    if (((l_2183 = (l_2181 = l_2181)) == (l_2185 = l_2184)))
                    { /* block id: 963 */
                        return l_2186;
                    }
                    else
                    { /* block id: 965 */
                        int8_t *l_2200 = &l_2167;
                        int16_t *l_2201 = (void*)0;
                        int16_t *l_2202 = &g_732;
                        uint32_t **l_2204 = &l_2203;
                        uint32_t **l_2206[7][7][5] = {{{&l_2205,&l_2205,&g_1327,(void*)0,&l_2205},{(void*)0,&l_2205,&g_1327,(void*)0,(void*)0},{&l_2205,&l_2205,&l_2205,(void*)0,&l_2205},{&g_1327,(void*)0,&l_2205,(void*)0,(void*)0},{&l_2205,(void*)0,&l_2205,&g_1327,&g_1327},{&l_2205,(void*)0,&l_2205,(void*)0,&l_2205},{&g_1327,&l_2205,&l_2205,&l_2205,&g_1327}},{{&l_2205,&l_2205,&g_1327,&l_2205,&l_2205},{&l_2205,&l_2205,&g_1327,&l_2205,&g_1327},{&l_2205,&l_2205,(void*)0,&g_1327,&l_2205},{&g_1327,&l_2205,&g_1327,&l_2205,&g_1327},{&l_2205,(void*)0,&l_2205,&l_2205,(void*)0},{&g_1327,&l_2205,&l_2205,&g_1327,&l_2205},{&l_2205,&l_2205,&g_1327,&l_2205,(void*)0}},{{&g_1327,&l_2205,&g_1327,&l_2205,&l_2205},{(void*)0,&l_2205,&l_2205,&l_2205,&l_2205},{&g_1327,&l_2205,&l_2205,&g_1327,&g_1327},{&g_1327,(void*)0,&l_2205,&l_2205,&g_1327},{&l_2205,(void*)0,(void*)0,&l_2205,&l_2205},{&g_1327,(void*)0,&g_1327,&g_1327,&l_2205},{&g_1327,&l_2205,&l_2205,&l_2205,&l_2205}},{{(void*)0,&l_2205,(void*)0,&l_2205,&g_1327},{&g_1327,&l_2205,&l_2205,&l_2205,&g_1327},{&l_2205,(void*)0,&g_1327,(void*)0,&l_2205},{&g_1327,&g_1327,(void*)0,&g_1327,&g_1327},{&l_2205,&g_1327,&l_2205,(void*)0,&l_2205},{&g_1327,&g_1327,&l_2205,(void*)0,&g_1327},{&l_2205,&g_1327,&l_2205,(void*)0,&g_1327}},{{&l_2205,&l_2205,&g_1327,(void*)0,&l_2205},{&l_2205,&g_1327,&g_1327,&l_2205,&l_2205},{&g_1327,&g_1327,&l_2205,&g_1327,&l_2205},{&g_1327,&l_2205,(void*)0,(void*)0,&l_2205},{&l_2205,&l_2205,&l_2205,&l_2205,&l_2205},{&g_1327,&l_2205,&l_2205,&g_1327,&g_1327},{&l_2205,&g_1327,&l_2205,&l_2205,&g_1327}},{{&l_2205,(void*)0,&l_2205,&l_2205,&l_2205},{&l_2205,(void*)0,&l_2205,&g_1327,&l_2205},{&g_1327,&l_2205,(void*)0,&l_2205,&l_2205},{&l_2205,&l_2205,&g_1327,&l_2205,(void*)0},{&g_1327,&l_2205,(void*)0,&l_2205,&g_1327},{&l_2205,&g_1327,&l_2205,&g_1327,&l_2205},{&g_1327,&g_1327,&l_2205,&l_2205,(void*)0}},{{&l_2205,&l_2205,&l_2205,&g_1327,&l_2205},{&l_2205,&l_2205,&l_2205,&l_2205,&g_1327},{&l_2205,&g_1327,&l_2205,&g_1327,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_2205},{&g_1327,&g_1327,&g_1327,&g_1327,&l_2205},{&g_1327,&l_2205,&l_2205,&g_1327,&l_2205},{&l_2205,&l_2205,&l_2205,&l_2205,&g_1327}}};
                        int16_t *l_2210 = &g_76[0][4];
                        uint64_t *l_2211 = &l_1664;
                        const int32_t l_2212 = 1L;
                        int32_t *l_2214 = &l_1764;
                        int32_t *l_2215[7][5][4] = {{{&g_1121,(void*)0,&l_2157[1][1][1],&l_1838},{&l_2157[1][1][1],&l_1838,&l_1761,&l_1955},{&g_78,&l_2157[2][3][1],&l_2157[2][3][1],&g_78},{&g_156[7],&l_2157[1][2][1],&g_1121,&g_52},{(void*)0,&l_1761,&g_78,(void*)0}},{{&l_1955,&l_1838,&l_1838,(void*)0},{&l_1766,&l_1761,&l_1838,&g_52},{&l_2157[2][3][1],&l_2157[1][2][1],&l_1766,&g_78},{&l_2157[1][2][1],&l_2157[2][3][1],&l_1955,&l_1955},{&g_156[0],&l_1838,&g_156[5],&l_1838}},{{&l_2157[0][4][0],(void*)0,&l_1838,&g_78},{(void*)0,(void*)0,&g_78,&l_2157[2][3][1]},{&l_1955,&g_156[0],(void*)0,&g_78},{&l_1955,&l_1955,&g_78,(void*)0},{(void*)0,&g_78,&l_1838,&l_2157[1][2][1]}},{{&l_2157[0][4][0],&g_1121,&g_156[5],&g_1121},{&g_156[0],&g_156[5],&l_1955,&l_1955},{&l_2157[1][2][1],&l_2157[1][2][1],&l_1766,(void*)0},{&l_2157[2][3][1],&l_2157[1][1][1],&l_1838,&l_2157[1][2][1]},{&l_1766,(void*)0,&l_1838,&l_1838}},{{&l_1955,(void*)0,&g_78,&l_2157[1][2][1]},{(void*)0,&l_2157[1][1][1],&g_1121,(void*)0},{&g_156[7],&l_2157[1][2][1],&l_2157[2][3][1],&l_1955},{&g_78,&g_156[5],&l_1761,&g_1121},{&l_2157[1][1][1],&g_1121,&l_2157[1][1][1],&l_2157[1][2][1]}},{{&g_156[3],(void*)0,&g_1121,&l_2157[2][3][1]},{(void*)0,&g_156[5],&g_78,(void*)0},{&l_2157[0][4][0],&g_1121,&g_78,&l_1955},{(void*)0,&l_1955,&g_1121,(void*)0},{&g_156[3],&l_2157[1][1][1],&g_78,(void*)0}},{{&g_78,(void*)0,&l_1838,(void*)0},{&l_1761,&l_1955,&l_1955,&l_1761},{(void*)0,&l_1838,&g_156[3],&g_78},{&l_1766,&l_1838,&l_1761,&l_2157[1][1][1]},{&g_156[5],&l_2157[1][2][1],(void*)0,&l_2157[1][1][1]}}};
                        int i, j, k;
                        l_2213 |= (((*l_2211) = (l_2187 & ((*l_2186) == (safe_mul_func_uint64_t_u_u((((*l_2210) = (safe_mod_func_int8_t_s_s((*l_2186), ((safe_unary_minus_func_int16_t_s(((+(safe_add_func_uint64_t_u_u((safe_rshift_func_int8_t_s_s(((((safe_mul_func_uint8_t_u_u((**g_1077), 0x0EL)) , (((((*l_2200) = ((*g_1966) = (*l_2186))) , ((((*l_2202) = 0x3FF5L) && (((*l_2204) = l_2203) == (l_2208 = (l_2207[5] = l_2205)))) == (*g_1327))) < (*l_2052)) | (*p_46))) > g_603[1]) && l_2209), 3)), 9UL))) | (*p_46)))) , (*l_2186))))) < (**l_2181)), (**l_2185)))))) | l_2212);
                        (*l_2183) = (*g_1043);
                        return l_2186;
                    }
                }
                (*l_2183) = ((*g_1043) = (*l_2183));
            }
            else
            { /* block id: 981 */
                int16_t *l_2227 = &g_76[0][4];
                int32_t l_2233 = (-8L);
                uint64_t ** const *l_2243 = (void*)0;
                int32_t *****l_2245[3][1][10] = {{{&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988}},{{&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988}},{{&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988,&l_1988}}};
                uint32_t ***l_2249 = &g_1096;
                uint32_t ***l_2278 = &g_1326[2];
                uint16_t **l_2289[5][9] = {{(void*)0,&g_161,(void*)0,&g_161,(void*)0,&g_161,(void*)0,&g_161,(void*)0},{&g_168,&g_168,&g_168,&g_168,&g_168,&g_168,&g_168,&g_168,&g_168},{&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161},{&g_168,&g_168,&g_168,&g_168,&g_168,&g_168,&g_168,&g_168,&g_168},{(void*)0,&g_161,(void*)0,&g_161,(void*)0,&g_161,(void*)0,&g_161,(void*)0}};
                int i, j, k;
                if ((safe_add_func_uint64_t_u_u((((safe_mul_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((safe_mod_func_int32_t_s_s((~((((*l_2227) = g_52) ^ 0L) | ((*g_1966) == (**l_2181)))), (safe_add_func_int8_t_s_s((-9L), (-1L))))), (safe_div_func_int16_t_s_s((((*g_1966) && (*l_2052)) || ((void*)0 == l_2232)), (**l_2181))))) , 0x36L), l_2233)) < l_2233) != 0x4B24L), 0UL)))
                { /* block id: 983 */
                    uint16_t *****l_2244 = &g_1542;
                    int32_t l_2275 = (-6L);
                    uint32_t *l_2276 = &g_193;
                    uint32_t ***l_2281 = (void*)0;
                    uint8_t *l_2298 = (void*)0;
                    int32_t *l_2300 = &l_2157[0][3][1];
                    uint64_t *l_2315 = &l_1664;
                    int8_t *l_2322 = &g_1949;
                    int8_t *l_2331 = &g_720;
                    for (l_1664 = 1; (l_1664 <= 7); l_1664 += 1)
                    { /* block id: 986 */
                        int i;
                        g_156[l_1664] = ((safe_rshift_func_uint64_t_u_s((safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s((!g_156[l_1664]), (safe_rshift_func_int8_t_s_s(((((**g_755) == ((l_2244 = ((l_2243 != &g_752) , l_2244)) == (void*)0)) , l_2245[1][0][5]) == (void*)0), (+(safe_lshift_func_uint64_t_u_u(((l_2233 || (*g_1966)) ^ l_2233), l_2233))))))), 0xB928C500L)), (*l_2052))) != (*g_756));
                        (*g_1120) ^= ((l_2249 == (void*)0) , (safe_lshift_func_uint16_t_u_s(l_2233, 0)));
                    }
                    for (l_2178 = 5; (l_2178 <= 32); ++l_2178)
                    { /* block id: 993 */
                        int32_t ***l_2269 = &g_241[3][3];
                        int32_t ****l_2268 = &l_2269;
                        uint16_t l_2277 = 6UL;
                        uint32_t ****l_2279 = &l_1714;
                        uint32_t ****l_2280[3][9][8] = {{{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0,&l_2278},{(void*)0,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{(void*)0,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,(void*)0,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0,(void*)0},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,(void*)0,&l_2278,(void*)0,(void*)0,&l_2278,&l_2278,&l_2278},{(void*)0,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0,&l_2278,&l_2278}},{{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0},{&l_2278,&l_2278,&l_2278,(void*)0,&l_2278,&l_2278,&l_2278,&l_2278},{(void*)0,&l_2278,&l_2278,(void*)0,&l_2278,&l_2278,&l_2278,(void*)0},{(void*)0,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0},{(void*)0,&l_2278,&l_2278,(void*)0,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{(void*)0,&l_2278,(void*)0,&l_2278,(void*)0,&l_2278,&l_2278,&l_2278},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0,&l_2278,&l_2278}},{{&l_2278,&l_2278,&l_2278,&l_2278,(void*)0,&l_2278,&l_2278,&l_2278},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0},{(void*)0,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,(void*)0,&l_2278,&l_2278,(void*)0,&l_2278,&l_2278,(void*)0},{&l_2278,&l_2278,(void*)0,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0,&l_2278,(void*)0},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,&l_2278},{&l_2278,&l_2278,&l_2278,&l_2278,&l_2278,(void*)0,&l_2278,(void*)0},{(void*)0,&l_2278,(void*)0,&l_2278,(void*)0,&l_2278,&l_2278,&l_2278}}};
                        int32_t *l_2282 = &l_1766;
                        int i, j, k;
                        l_2281 = ((*l_2279) = (((safe_mul_func_int32_t_s_s((safe_div_func_uint16_t_u_u(((((**l_2181) , (safe_lshift_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(((((**l_2181) = 0L) , g_48[0][3][1]) , ((*l_2227) = (safe_add_func_int8_t_s_s(((((safe_mul_func_int16_t_s_s((((l_2233 < (((l_2270 = l_2268) == (l_1988 = g_2272)) ^ (safe_sub_func_int32_t_s_s((((p_46 != &g_48[0][1][0]) ^ (l_2275 , 65529UL)) & 0x66DDEAB896D7255ELL), 0x67236F84L)))) , l_2276) != l_2208), 65535UL)) , (void*)0) == &g_1326[2]) && g_720), l_2233)))), g_1038[2][7][1])), l_2187)), 8))) , (void*)0) != (void*)0), l_2233)), (*g_1327))) <= l_2277) , l_2278));
                        (*l_2282) |= (**l_2181);
                        (*l_2282) ^= (*g_670);
                    }
                    (*l_2300) &= ((*g_1120) = ((safe_rshift_func_int64_t_s_s(((((safe_sub_func_int64_t_s_s((**l_2181), (safe_sub_func_uint8_t_u_u(((l_2289[1][0] = (void*)0) != (void*)0), ((*g_861) <= (safe_mul_func_uint16_t_u_u((((safe_rshift_func_uint8_t_u_s(0x32L, (safe_div_func_int8_t_s_s((*l_2052), (safe_mul_func_uint64_t_u_u(((*g_1077) != l_2298), (((((*l_2227) = g_1121) >= 0xA466L) >= (*g_1327)) , l_2275))))))) == 0x4987A3BA835CCA0FLL) == g_1573), l_2233))))))) <= l_2299) >= (-1L)) , (*p_46)), 57)) == (**l_2181)));
                    (*l_2300) = (((safe_rshift_func_int8_t_s_s((((*g_1120) = ((((**l_2181) && (safe_lshift_func_uint8_t_u_u(((((safe_add_func_uint8_t_u_u(((**g_1077)++), (*l_2300))) && (safe_sub_func_int32_t_s_s((safe_rshift_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_s((--(*l_2315)), 45)), 39)), l_2233))) , ((safe_mod_func_int64_t_s_s((((safe_add_func_int8_t_s_s((((*l_2322) |= (*g_1966)) <= ((((*l_2331) = (safe_add_func_int32_t_s_s((safe_sub_func_int8_t_s_s(((void*)0 == l_2327), (safe_rshift_func_int64_t_s_s(l_2330, (*p_46))))), ((*l_2208) = (((((**l_2181) >= l_2233) >= l_2233) , (**l_2181)) , (*l_2300)))))) , (*p_46)) || (-1L))), (*g_1966))) < (**l_2181)) && (*l_2052)), l_2233)) < (**l_2181))) & 0xD382L), 4))) >= (**l_2181)) == l_2332)) | 0UL), 4)) , l_2300) != (void*)0);
                }
                else
                { /* block id: 1014 */
                    return (*l_2181);
                }
                if ((*g_670))
                    continue;
            }
        }
    }
    return &g_1121;
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_5 g_76 g_77 g_50 g_51 g_78 g_94 g_85 g_123 g_140 g_142 g_116 g_155 g_156 g_160 g_174 g_179 g_168 g_241 g_242 g_289 g_161 g_260 g_193 g_48 g_74 g_582 g_603 g_670 g_688 g_636 g_694 g_667 g_732 g_737 g_695 g_696 g_751 g_754 g_794 g_755 g_756 g_735 g_861 g_931 g_981 g_1043 g_1095 g_1077 g_1078 g_1119 g_1120 g_1121 g_1207 g_1038 g_720 g_1327 g_1350 g_855 g_1573 g_1621 l_4254
 * writes: g_74 g_76 g_52 g_78 g_94 g_85 g_116 g_123 g_140 g_142 g_156 g_160 g_161 g_168 g_174 g_179 g_47 g_51 g_260 g_48 g_193 g_582 g_242 g_652 g_636 g_667 g_720 g_732 g_735 g_981 g_1095 g_1098 g_737 g_1121 g_1207 g_241 g_1119 g_1542 g_1078
 */
static int32_t  func_55(int64_t  p_56)
{ /* block id: 8 */
    uint32_t l_57 = 18446744073709551615UL;
    uint16_t *l_73 = &g_74[0][4];
    int16_t *l_75 = &g_76[0][4];
    int8_t *l_1125 = &g_720;
    int8_t **l_1124 = &l_1125;
    int32_t l_1127 = 0x3E723EA6L;
    int32_t l_1157 = (-1L);
    int32_t *l_1183 = (void*)0;
    int32_t *l_1185[9] = {&g_179,&g_179,&g_179,&g_179,&g_179,&g_179,&g_179,&g_179,&g_179};
    int32_t l_1204 = 0x1EB2658CL;
    uint32_t ***l_1230 = &g_1096;
    int32_t l_1348 = 0xFFAB5432L;
    int32_t l_1349 = 1L;
    int32_t l_1351[2][7] = {{8L,8L,(-1L),(-1L),0L,(-1L),(-1L)},{8L,8L,(-1L),(-1L),0L,(-1L),(-1L)}};
    int32_t **l_1436[3][5][10] = {{{&l_1185[8],&l_1185[4],&l_1185[8],&l_1185[4],&l_1185[5],&l_1185[0],&l_1185[4],&g_242,(void*)0,&l_1185[4]},{&l_1183,(void*)0,&l_1185[8],&l_1185[4],&l_1185[4],&g_242,(void*)0,&g_242,&l_1185[5],&l_1185[5]},{&g_242,&l_1183,&l_1185[8],(void*)0,(void*)0,&l_1185[8],&l_1183,&g_242,&g_242,&l_1183},{&l_1183,&g_242,&l_1185[3],&g_242,&g_242,&l_1185[4],&g_242,&l_1183,&l_1183,&l_1185[8]},{(void*)0,(void*)0,&l_1185[3],&g_242,&l_1185[0],&l_1183,(void*)0,&l_1183,&l_1185[0],&g_242}},{{&l_1185[3],&l_1183,&l_1185[3],&l_1183,&g_242,&l_1183,&l_1183,&l_1183,&l_1185[8],&l_1185[0]},{&l_1185[4],&l_1183,&l_1185[3],&l_1185[0],&l_1183,(void*)0,&l_1183,&l_1183,&g_242,&g_242},{&l_1183,&l_1185[4],&l_1185[3],&l_1185[8],&l_1185[8],&l_1185[3],&l_1185[4],&l_1183,&g_242,&l_1183},{&l_1183,&g_242,&l_1185[3],&g_242,&g_242,&l_1185[4],&g_242,&l_1183,&l_1183,&l_1185[8]},{(void*)0,(void*)0,&l_1185[3],&g_242,&l_1185[0],&l_1183,(void*)0,&l_1183,&l_1185[0],&g_242}},{{&l_1185[3],&l_1183,&l_1185[3],&l_1183,&g_242,&l_1183,&l_1183,&l_1183,&l_1185[8],&l_1185[0]},{&l_1185[4],&l_1183,&l_1185[3],&l_1185[0],&l_1183,(void*)0,&l_1183,&l_1183,&g_242,&g_242},{&l_1183,&l_1185[4],&l_1185[3],&l_1185[8],&l_1185[8],&l_1185[3],&l_1185[4],&l_1183,&g_242,&l_1183},{&l_1183,&g_242,&l_1185[3],&g_242,&g_242,&l_1185[4],&g_242,&l_1183,&l_1183,&l_1185[8]},{(void*)0,(void*)0,&l_1185[3],&g_242,&l_1185[0],&l_1183,(void*)0,&l_1183,&l_1185[0],&g_242}}};
    const uint16_t ***l_1437 = (void*)0;
    uint64_t l_1570 = 0xC0FF7AFFE94E2C32LL;
    int16_t l_1585[1][5];
    int16_t l_1589 = 0x29B1L;
    int8_t l_1617 = (-1L);
    uint8_t l_1618[8][1][2];
    uint16_t ****l_1633[2][9] = {{&g_652[0],&g_652[6],&g_652[0],&g_652[6],&g_652[0],&g_652[6],&g_652[0],&g_652[6],&g_652[0]},{(void*)0,&g_652[0],&g_652[0],(void*)0,(void*)0,&g_652[0],&g_652[0],(void*)0,(void*)0}};
    int64_t l_1634 = (-5L);
    int64_t *l_1635 = &g_48[1][1][0];
    uint32_t l_1636 = 0x871A41FFL;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
            l_1585[i][j] = 0x4949L;
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 2; k++)
                l_1618[i][j][k] = 255UL;
        }
    }
    (*g_1120) &= (l_57 ^ func_58(((safe_unary_minus_func_int8_t_s(((5UL | (func_63((+(g_52 == ((safe_lshift_func_uint8_t_u_u((l_57 >= (0xA3CE724D257E7E5FLL != ((((*l_75) |= ((g_5[3][0] > (((-10L) ^ (safe_mul_func_uint32_t_u_u((p_56 >= (((*l_73) = (safe_lshift_func_uint32_t_u_s((g_5[3][0] & 0x97L), l_57))) & 0x0698L)), l_57))) && p_56)) != p_56)) == 0x0DD7L) , g_77))), 5)) & p_56))), l_57) & l_57)) || p_56))) || 0x1446E785F5D03DF8LL), p_56, g_1119[6][5]));
    if (g_174)
        goto lbl_1123;
lbl_1123:
    (*g_1120) = 0x24D8AFA1L;
    if ((l_1124 != &l_1125))
    { /* block id: 451 */
        uint64_t l_1126 = 0x4C60F120F11C1522LL;
        l_1127 ^= l_1126;
        (*g_1043) = &l_1127;
        return p_56;
    }
    else
    { /* block id: 455 */
        uint32_t l_1132[1][9][3] = {{{5UL,0xD3E62EE5L,0UL},{5UL,0xC24FEDE4L,0xC24FEDE4L},{5UL,0xD3E62EE5L,0UL},{5UL,0xC24FEDE4L,0xC24FEDE4L},{5UL,0xD3E62EE5L,0UL},{5UL,0xC24FEDE4L,0xC24FEDE4L},{5UL,0xD3E62EE5L,0UL},{5UL,0xC24FEDE4L,0xC24FEDE4L},{5UL,0xD3E62EE5L,0UL}}};
        uint32_t l_1159 = 6UL;
        int32_t * const *l_1162 = &g_242;
        int32_t * const * const *l_1161 = &l_1162;
        int32_t *l_1168 = &g_78;
        int32_t l_1199 = 4L;
        uint32_t **l_1284 = (void*)0;
        uint64_t l_1328 = 1UL;
        int32_t l_1343[2][5] = {{1L,1L,1L,1L,1L},{0xFCC8A1B8L,0xFCC8A1B8L,0xFCC8A1B8L,0xFCC8A1B8L,0xFCC8A1B8L}};
        int32_t l_1347 = 6L;
        uint64_t ****l_1358[9][8] = {{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]},{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]},{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]},{&g_754[0],(void*)0,&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]},{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]},{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],(void*)0,&g_754[0],&g_754[0]},{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]},{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]},{&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]}};
        int8_t l_1370 = 0x2BL;
        uint32_t l_1413 = 18446744073709551613UL;
        int32_t **l_1435 = &g_242;
        int8_t l_1439 = 0x8DL;
        int64_t l_1467 = 0xC4E81BBE7F89EA6BLL;
        uint16_t ****l_1540 = &g_652[3];
        uint32_t l_1544 = 0UL;
        uint32_t l_1546 = 0UL;
        int16_t *l_1555 = &g_76[0][3];
        uint8_t *l_1616 = (void*)0;
        int i, j, k;
lbl_1595:
        for (g_636 = (-10); (g_636 == (-7)); g_636 = safe_add_func_int64_t_s_s(g_636, 7))
        { /* block id: 458 */
            int8_t l_1141[10] = {0x3BL,0x61L,0xF2L,0xF2L,0x61L,0x3BL,0x61L,0xF2L,0xF2L,0x61L};
            int32_t ***l_1163[5];
            int32_t *l_1167[7][3][5];
            uint8_t l_1172 = 0xE0L;
            int16_t l_1175 = 0x2536L;
            int8_t l_1202 = 0xF2L;
            int8_t l_1283 = (-3L);
            uint64_t ** const l_1408 = &g_756;
            int64_t l_1488 = (-1L);
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_1163[i] = (void*)0;
            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    for (k = 0; k < 5; k++)
                        l_1167[i][j][k] = (void*)0;
                }
            }
            (*g_1120) = (safe_mod_func_int16_t_s_s((l_1132[0][0][1] && 0xD296L), ((safe_lshift_func_uint8_t_u_u(((((((safe_rshift_func_int16_t_s_s(((safe_mod_func_uint64_t_u_u((&g_160 != &g_160), 0x054DC46D3BCB606DLL)) , ((safe_div_func_uint8_t_u_u(((0UL & ((**g_1077) &= l_1127)) > (((*g_861) , l_1132[0][0][1]) <= p_56)), l_57)) | p_56)), l_1132[0][2][2])) & l_1141[3]) == 0xAF28EEA6E0AA21AALL) , l_57) ^ l_1132[0][0][1]) < l_1132[0][0][1]), p_56)) && l_57)));
            for (l_1127 = 0; (l_1127 <= (-24)); l_1127 = safe_sub_func_int64_t_s_s(l_1127, 9))
            { /* block id: 463 */
                uint32_t *l_1156 = &g_193;
                int32_t l_1158 = 6L;
                uint32_t *l_1160 = &g_582;
                (*g_1043) = (((p_56 <= ((*l_1160) &= (safe_add_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((*g_794) , g_76[0][4]), ((((((**g_1077) = l_1141[3]) & p_56) || (safe_mod_func_int16_t_s_s(((safe_rshift_func_int32_t_s_u(((safe_sub_func_uint32_t_u_u(((*l_1156) = ((p_56 && l_1127) , l_1132[0][0][1])), ((l_1157 ^= 0xFFD7L) , g_78))) , l_1141[3]), l_1158)) & p_56), 65528UL))) , l_1159) , l_1132[0][0][1]))), 65533UL)) != l_1127), p_56)))) , 0x0AL) , (void*)0);
                for (g_720 = 2; (g_720 >= 0); g_720 -= 1)
                { /* block id: 471 */
                    for (g_981 = 0; (g_981 <= 2); g_981 += 1)
                    { /* block id: 474 */
                        uint16_t l_1164 = 0x971EL;
                        int i, j;
                        l_1164 = (l_1161 != l_1163[2]);
                        return g_76[g_981][(g_981 + 2)];
                    }
                }
                for (g_179 = 17; (g_179 <= (-17)); g_179 = safe_sub_func_int32_t_s_s(g_179, 6))
                { /* block id: 481 */
                    l_1158 = (&p_56 != &p_56);
                    (*g_1043) = l_1167[3][1][4];
                    if ((*g_861))
                        break;
                    (*g_1043) = l_1168;
                }
            }
            if ((*l_1168))
            { /* block id: 488 */
                int16_t l_1169 = 0L;
                int32_t *l_1170 = &g_78;
                int32_t l_1171 = (-2L);
                int32_t *l_1184 = &g_179;
                const int32_t *l_1191 = &g_179;
                const int32_t ** const l_1190 = &l_1191;
                const int32_t ** const *l_1189[4][9][2] = {{{(void*)0,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{(void*)0,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{&l_1190,(void*)0}},{{&l_1190,&l_1190},{(void*)0,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{(void*)0,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190}},{{&l_1190,(void*)0},{&l_1190,&l_1190},{(void*)0,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{(void*)0,&l_1190},{&l_1190,(void*)0}},{{&l_1190,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{(void*)0,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{&l_1190,(void*)0},{&l_1190,&l_1190},{(void*)0,&l_1190}}};
                const int32_t ** const **l_1188 = &l_1189[1][3][1];
                int32_t l_1196 = 0x0A743DD9L;
                int32_t l_1201 = 5L;
                int32_t l_1205[5] = {0x0447D739L,0x0447D739L,0x0447D739L,0x0447D739L,0x0447D739L};
                uint32_t *l_1226[6][4][8] = {{{&g_582,&g_193,&g_193,&g_582,&g_193,&g_582,&g_193,&g_193},{&g_193,&g_193,&g_582,&g_582,&g_193,&g_193,&g_193,&g_582},{&g_193,&g_193,&g_582,&g_193,&g_193,&g_582,&g_193,&g_193},{&g_582,&g_193,&g_582,&g_193,&g_193,&g_582,&g_193,&g_582}},{{&g_193,&g_582,&g_193,&g_582,&g_193,&g_582,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193,&g_582,&g_582,&g_582},{&g_582,&g_582,(void*)0,(void*)0,&g_582,&g_582,(void*)0,&g_193},{&g_582,(void*)0,&g_193,&g_582,&g_582,&g_193,&g_582,&g_193}},{{&g_193,&g_582,&g_193,&g_582,&g_193,&g_193,&g_582,&g_193},{&g_193,&g_193,&g_582,(void*)0,&g_582,&g_193,&g_193,&g_582},{&g_582,&g_582,&g_582,&g_582,(void*)0,&g_193,&g_582,&g_582},{&g_582,&g_582,&g_193,&g_193,&g_582,&g_193,&g_582,&g_193}},{{&g_193,&g_582,&g_193,&g_582,&g_582,&g_193,(void*)0,&g_582},{&g_193,&g_582,(void*)0,&g_582,&g_193,&g_193,&g_582,(void*)0},{&g_193,&g_193,&g_193,&g_193,&g_582,&g_193,&g_193,&g_582},{&g_193,&g_582,&g_582,&g_193,&g_582,&g_193,&g_582,&g_582}},{{&g_582,(void*)0,(void*)0,&g_193,(void*)0,&g_582,&g_582,(void*)0},{&g_582,&g_582,&g_582,&g_582,&g_582,&g_582,&g_582,&g_582},{&g_193,&g_582,(void*)0,&g_582,&g_193,&g_193,&g_582,&g_193},{&g_193,&g_193,&g_582,&g_193,&g_582,&g_193,&g_193,&g_582}},{{&g_582,&g_582,&g_193,&g_582,&g_582,&g_582,&g_582,&g_582},{&g_582,&g_582,(void*)0,(void*)0,&g_582,&g_582,(void*)0,&g_193},{&g_582,(void*)0,&g_193,&g_582,&g_582,&g_193,&g_582,&g_193},{&g_193,&g_582,&g_193,&g_582,&g_193,&g_193,&g_582,&g_193}}};
                uint32_t **l_1225[8][7][4] = {{{&l_1226[5][3][5],&l_1226[2][2][6],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[0][0][0],&l_1226[0][0][0],&l_1226[2][2][5],&l_1226[5][3][5]},{&l_1226[2][0][3],&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[4][2][2]},{&l_1226[5][3][5],(void*)0,&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[5][3][5],(void*)0,&l_1226[5][3][2],&l_1226[4][2][2]},{(void*)0,&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[5][3][5],&l_1226[0][0][0],&l_1226[5][3][5],&l_1226[5][3][5]}},{{&l_1226[5][3][5],&l_1226[2][2][6],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[5][3][5],&l_1226[0][3][0],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[2][1][7],&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[4][0][0]},{&l_1226[5][3][5],(void*)0,&l_1226[5][3][5],&l_1226[2][1][7]},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[2][2][5],&l_1226[5][3][5]},{&l_1226[5][3][2],(void*)0,(void*)0,&l_1226[0][1][1]},{&l_1226[4][0][0],&l_1226[5][3][5],&l_1226[2][2][6],&l_1226[5][3][5]}},{{&l_1226[4][0][0],&l_1226[2][2][5],(void*)0,&l_1226[0][3][0]},{&l_1226[5][3][2],&l_1226[5][3][5],&l_1226[2][2][5],(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[2][0][3],&l_1226[4][0][0]},{&l_1226[5][3][5],&l_1226[5][3][5],(void*)0,(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5],(void*)0},{&l_1226[0][3][0],&l_1226[4][0][0],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[5][3][5],&l_1226[3][1][0],&l_1226[3][1][0],&l_1226[5][3][5]}},{{(void*)0,(void*)0,&l_1226[5][3][5],(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[2][1][7]},{&l_1226[5][3][5],(void*)0,&l_1226[0][0][7],&l_1226[2][1][7]},{&l_1226[3][1][0],&l_1226[5][3][5],&l_1226[2][2][5],(void*)0},{&l_1226[5][3][5],(void*)0,(void*)0,&l_1226[5][3][5]},{&l_1226[4][0][0],&l_1226[3][1][0],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[2][2][5],&l_1226[4][0][0],(void*)0,(void*)0}},{{&l_1226[5][3][5],&l_1226[5][3][5],(void*)0,(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[0][0][7],&l_1226[4][0][0]},{(void*)0,&l_1226[5][3][5],(void*)0,(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],(void*)0,&l_1226[0][3][0]},{&l_1226[0][3][0],&l_1226[2][2][5],&l_1226[3][1][0],&l_1226[5][3][5]},{&l_1226[0][1][1],&l_1226[5][3][5],&l_1226[3][1][0],&l_1226[0][1][1]},{&l_1226[0][3][0],(void*)0,(void*)0,&l_1226[5][3][5]}},{{&l_1226[5][3][5],&l_1226[5][3][5],(void*)0,&l_1226[2][1][7]},{(void*)0,&l_1226[2][1][7],&l_1226[0][0][7],(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],(void*)0,&l_1226[5][3][5]},{&l_1226[5][3][5],(void*)0,(void*)0,&l_1226[5][3][5]},{&l_1226[2][2][5],&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[4][0][0],&l_1226[4][0][0],(void*)0,&l_1226[0][3][0]},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[2][2][5],(void*)0}},{{&l_1226[3][1][0],&l_1226[5][3][5],&l_1226[0][0][7],&l_1226[2][2][5]},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5],(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[0][3][0]},{(void*)0,&l_1226[4][0][0],&l_1226[3][1][0],&l_1226[5][3][5]},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[0][3][0],(void*)0,&l_1226[5][3][5],&l_1226[5][3][5]},{&l_1226[5][3][5],&l_1226[5][3][5],(void*)0,(void*)0}},{{&l_1226[5][3][5],&l_1226[2][1][7],&l_1226[2][0][3],&l_1226[2][1][7]},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[2][2][5],&l_1226[5][3][5]},{&l_1226[5][3][2],(void*)0,(void*)0,&l_1226[0][1][1]},{&l_1226[4][0][0],&l_1226[5][3][5],&l_1226[2][2][6],&l_1226[5][3][5]},{&l_1226[4][0][0],&l_1226[2][2][5],(void*)0,&l_1226[0][3][0]},{&l_1226[5][3][2],&l_1226[5][3][5],&l_1226[2][2][5],(void*)0},{&l_1226[5][3][5],&l_1226[5][3][5],&l_1226[2][0][3],&l_1226[4][0][0]}}};
                uint32_t *** const l_1224[5] = {&l_1225[4][2][3],&l_1225[4][2][3],&l_1225[4][2][3],&l_1225[4][2][3],&l_1225[4][2][3]};
                uint16_t ****l_1275 = &g_652[3];
                uint32_t l_1369 = 7UL;
                int i, j, k;
                if (l_1169)
                { /* block id: 489 */
                    (*g_1043) = l_1170;
                }
                else
                { /* block id: 491 */
                    const uint16_t *l_1177[9][10][2] = {{{&g_1178,(void*)0},{&g_1178,&g_1178},{(void*)0,&g_1178},{(void*)0,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_1178,&g_1178},{(void*)0,&g_1178}},{{(void*)0,&g_1178},{&g_1178,(void*)0},{&g_1178,&g_1178},{&g_1178,(void*)0},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0},{(void*)0,&g_1178},{&g_1178,(void*)0},{&g_1178,(void*)0}},{{&g_1178,&g_1178},{(void*)0,(void*)0},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0},{&g_1178,&g_1178},{&g_1178,(void*)0},{&g_1178,&g_1178},{(void*)0,&g_1178},{(void*)0,&g_1178}},{{&g_1178,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_1178,&g_1178},{&g_1178,&g_1178},{(void*)0,&g_1178},{(void*)0,(void*)0},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178}},{{&g_1178,&g_1178},{(void*)0,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0},{(void*)0,(void*)0},{&g_1178,&g_1178},{(void*)0,&g_1178}},{{&g_1178,&g_1178},{&g_1178,&g_1178},{(void*)0,&g_1178},{&g_1178,(void*)0},{(void*)0,(void*)0},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178}},{{(void*)0,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0},{(void*)0,&g_1178},{(void*)0,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{&g_1178,&g_1178},{(void*)0,&g_1178},{(void*)0,&g_1178},{&g_1178,(void*)0},{&g_1178,&g_1178},{&g_1178,(void*)0},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0}},{{(void*)0,&g_1178},{&g_1178,(void*)0},{&g_1178,(void*)0},{&g_1178,&g_1178},{(void*)0,(void*)0},{&g_1178,&g_1178},{&g_1178,&g_1178},{&g_1178,(void*)0},{&g_1178,&g_1178},{&g_1178,(void*)0}}};
                    const uint16_t **l_1176 = &l_1177[1][5][1];
                    const int32_t ** const ***l_1192 = &l_1188;
                    uint32_t *l_1193 = &g_193;
                    int32_t l_1194 = 9L;
                    int32_t l_1197[9];
                    uint32_t ***l_1227 = (void*)0;
                    uint32_t ***l_1228[9][2][7] = {{{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,(void*)0,(void*)0,&g_1096,&g_1096,(void*)0,&g_1096}},{{&g_1096,(void*)0,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,(void*)0,&g_1096,(void*)0,&g_1096}},{{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,(void*)0},{&g_1096,&g_1096,&g_1096,(void*)0,(void*)0,&g_1096,&g_1096}},{{(void*)0,&g_1096,&g_1096,(void*)0,&g_1096,&g_1096,(void*)0},{&g_1096,&g_1096,(void*)0,(void*)0,&g_1096,(void*)0,&g_1096}},{{&g_1096,&g_1096,(void*)0,&g_1096,(void*)0,(void*)0,&g_1096},{&g_1096,(void*)0,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096}},{{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096}},{{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096},{(void*)0,&g_1096,&g_1096,&g_1096,&g_1096,(void*)0,&g_1096}},{{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,(void*)0,&g_1096},{&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096,&g_1096}},{{&g_1096,&g_1096,&g_1096,(void*)0,&g_1096,&g_1096,&g_1096},{(void*)0,(void*)0,&g_1096,&g_1096,(void*)0,(void*)0,&g_1096}}};
                    int i, j, k;
                    for (i = 0; i < 9; i++)
                        l_1197[i] = (-10L);
                    l_1172--;
                    l_1127 = ((p_56 || (l_1175 , (*l_1168))) , ((*g_168) ^ (((*l_1176) = (void*)0) == (void*)0)));
                    (*l_1170) ^= (safe_sub_func_int32_t_s_s(l_1127, g_667));
                    if ((safe_mod_func_int32_t_s_s(p_56, (((*l_1193) = (((l_1185[4] = (l_1184 = (l_1183 = (void*)0))) != ((safe_sub_func_uint8_t_u_u((((*l_1192) = l_1188) == &l_1161), (6UL >= p_56))) , (**l_1161))) <= ((((l_57 , 0xE4169705L) , 0x72EC06A6L) ^ 9UL) , 0L))) , p_56))))
                    { /* block id: 501 */
                        int16_t l_1195 = 0xE427L;
                        int32_t l_1198 = 4L;
                        int32_t l_1200 = 0xE08D81D4L;
                        int32_t l_1203 = 0x7DE79E86L;
                        int32_t l_1206 = 0xA05C9903L;
                        ++g_1207;
                        return (*g_794);
                    }
                    else
                    { /* block id: 504 */
                        uint32_t ****l_1229 = &l_1228[1][0][5];
                        (*g_1120) |= (safe_mul_func_uint8_t_u_u(((((((*l_75) = ((safe_mul_func_uint64_t_u_u(l_57, (((*l_1190) != (*l_1162)) == (p_56 && ((safe_rshift_func_int8_t_s_u((safe_mul_func_int64_t_s_s((safe_div_func_int32_t_s_s((0xB98873B5C81A07F1LL | (((safe_sub_func_uint64_t_u_u(((3UL | (safe_rshift_func_uint32_t_u_u(((((l_1224[3] == l_1227) == (((*l_1229) = l_1228[1][0][5]) == l_1230)) , (*l_1168)) ^ p_56), 23))) && (*l_1168)), p_56)) , p_56) < 0x60F9L)), p_56)), 0x446D82D8203E7BABLL)), p_56)) > 3UL))))) , g_77)) | (-1L)) > (*l_1168)) & 1L) != p_56), 0xC8L));
                    }
                }
                l_1127 &= (safe_rshift_func_int64_t_s_u((safe_lshift_func_int32_t_s_s((safe_mod_func_uint8_t_u_u(0UL, g_1038[2][5][0])), (l_1201 = ((*l_1170) = ((*g_1120) ^= 1L))))), 2));
                for (l_1196 = 0; (l_1196 < 13); ++l_1196)
                { /* block id: 516 */
                    uint8_t *l_1305 = &g_737;
                    int32_t l_1308[7][6][6] = {{{(-1L),0x14312258L,(-7L),(-6L),0x646E965CL,0x30742223L},{0xF5D43D45L,0x177C3968L,0xEE0C6FF3L,0x5DD55216L,0x89BE32F8L,0L},{0xED8C27D7L,0x97A1DAE6L,0x451A79C9L,9L,0x330CFFAEL,(-1L)},{(-1L),8L,0x392E0535L,0xF485FF81L,0xE558DA68L,0xE54AEF6EL},{(-8L),1L,(-1L),(-1L),1L,(-8L)},{0x4A9F8146L,0x740A6E30L,0x2F0A37E1L,(-2L),(-1L),0xEEA30047L}},{{0xDDF143B3L,0xA4D70CB8L,0xA2C55C89L,0x5DBF6377L,(-2L),(-1L)},{0xDDF143B3L,(-1L),0x5DBF6377L,(-2L),0x80CC37A8L,(-8L)},{0x4A9F8146L,(-1L),9L,(-1L),0L,0xCC14E4B2L},{(-8L),7L,6L,0xF485FF81L,0x5DBF6377L,0xB8D21F36L},{(-1L),0x30742223L,0xD0DD4A90L,9L,6L,0xA4D70CB8L},{0xED8C27D7L,(-1L),0x52963415L,0x5DD55216L,0x451A79C9L,(-8L)}},{{0xF5D43D45L,0x012B66EDL,(-2L),(-6L),0x14312258L,0x392E0535L},{(-1L),0x5DBF6377L,1L,0xAD3983B5L,0x534B3A28L,(-2L)},{0xED8C27D7L,(-2L),1L,0x14312258L,(-1L),9L},{0xEEA30047L,0L,0xF485FF81L,0xB8D21F36L,0x9384013CL,0xA4D70CB8L},{0x012B66EDL,0xAD3983B5L,0x2A1E0B36L,0xA2C55C89L,0x5DD55216L,4L},{4L,(-2L),9L,0xA4D70CB8L,0xD0DD4A90L,0xF58DBCD8L}},{{(-1L),0L,1L,0x9A1937DCL,(-7L),(-1L)},{0xDC02DAB2L,0x81B8C151L,(-5L),(-6L),0xE558DA68L,0xD0DD4A90L},{(-1L),0x392E0535L,0x68A79293L,0xDDF143B3L,0x68A79293L,0x392E0535L},{(-2L),0x534B3A28L,0x9A6202CBL,7L,(-2L),0x97A1DAE6L},{0xCFA1B79FL,(-8L),0x012B66EDL,0xEE0C6FF3L,0xDC02DAB2L,0xAD041D78L},{(-1L),(-8L),0xA4D70CB8L,(-1L),(-2L),6L}},{{(-1L),0x534B3A28L,0x52963415L,0xF58DBCD8L,0x68A79293L,(-2L)},{0x89BE32F8L,0x392E0535L,0L,(-1L),0xE558DA68L,9L},{0xCC31BD78L,0x81B8C151L,(-2L),0xCFA1B79FL,(-7L),0L},{(-1L),0L,0x392E0535L,0x66587055L,0xD0DD4A90L,0x4A9F8146L},{(-1L),(-2L),(-1L),0x2A1E0B36L,0x5DD55216L,0xE02A4B65L},{0x8F08B996L,0xAD3983B5L,0xB569BF1CL,(-1L),0x9384013CL,0x5DD55216L}},{{0xF58DBCD8L,0L,0xD0DD4A90L,0x52963415L,(-1L),(-1L)},{0xB8D21F36L,(-2L),0xE558DA68L,0xCC14E4B2L,0x534B3A28L,0x68A79293L},{0xE558DA68L,0xBD668FD9L,0x177C3968L,1L,0xDE11A19EL,6L},{(-1L),0x177C3968L,(-8L),0xD0DD4A90L,0xAD3983B5L,0x30742223L},{0xCC14E4B2L,0xAD041D78L,(-1L),(-8L),(-6L),1L},{0xDDF143B3L,(-8L),0xE75354DFL,0xEC1F2309L,0xBD668FD9L,(-1L)}},{{0x646E965CL,0x80CC37A8L,0xB8D21F36L,0L,0L,0xB8D21F36L},{(-2L),(-2L),0xE54AEF6EL,(-1L),0x012B66EDL,(-1L)},{0x451A79C9L,0x66587055L,0x97A1DAE6L,1L,0xE75354DFL,0xE54AEF6EL},{9L,0x451A79C9L,0x97A1DAE6L,0xED8C27D7L,(-2L),(-1L)},{(-1L),0xED8C27D7L,0xE54AEF6EL,(-1L),0x740A6E30L,0xB8D21F36L},{(-1L),0x740A6E30L,0xB8D21F36L,0x5DD55216L,(-1L),(-1L)}}};
                    int32_t *l_1316 = (void*)0;
                    uint64_t ****l_1357[6] = {&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0],&g_754[0]};
                    int i, j, k;
                }
            }
            else
            { /* block id: 577 */
                const int32_t *l_1398 = (void*)0;
                const int32_t **l_1399 = &l_1398;
                int32_t l_1409 = (-6L);
                int32_t l_1411 = 1L;
                uint64_t l_1469 = 0x2BBCD9C978E09CA3LL;
                int32_t **l_1486 = &g_242;
                int32_t **l_1487 = (void*)0;
                (*l_1399) = l_1398;
                if ((safe_add_func_uint8_t_u_u((&l_1172 != (void*)0), (((*l_1168) = (safe_div_func_int32_t_s_s(0x25BC9353L, (safe_mod_func_uint64_t_u_u(((**g_755) |= p_56), ((safe_lshift_func_int32_t_s_s(((p_56 , ((l_1409 &= ((((l_1408 == l_1408) ^ g_603[1]) && ((*l_1168) ^ l_1351[0][3])) <= p_56)) , p_56)) != g_735), 13)) , p_56)))))) , p_56))))
                { /* block id: 582 */
                    int32_t l_1410 = 0xF50C2A62L;
                    int32_t l_1412 = 0x6B51BB68L;
                    int32_t *** const *l_1468[7] = {&l_1163[2],&l_1163[2],&l_1163[2],&l_1163[2],&l_1163[2],&l_1163[2],&l_1163[2]};
                    int i;
                    l_1413++;
                    if (p_56)
                    { /* block id: 584 */
                        uint32_t l_1416 = 1UL;
                        l_1416++;
                    }
                    else
                    { /* block id: 586 */
                        int8_t l_1438 = 0x90L;
                        int32_t **l_1474 = &g_51;
                        int32_t * const **l_1475 = &g_1119[7][1];
                        int64_t *l_1484 = &g_48[0][1][0];
                        int64_t *l_1485[5];
                        int i;
                        for (i = 0; i < 5; i++)
                            l_1485[i] = &l_1467;
                        (*l_1168) = (((safe_mod_func_uint16_t_u_u(((((((safe_mul_func_int8_t_s_s((safe_mul_func_int64_t_s_s((l_1412 , ((((((**l_1408)--) < (((**l_1124) &= 0L) ^ (safe_mod_func_int8_t_s_s(p_56, (safe_lshift_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u((**g_1077), 2)) , (*l_1168)) , ((((safe_mul_func_uint16_t_u_u(((((l_1204 || ((*g_1120) = ((g_241[1][2] = &g_242) == (l_1436[2][2][0] = l_1435)))) >= ((void*)0 == l_1437)) <= 1UL) , 65535UL), 0UL)) || 1L) | l_1438) , p_56)), g_48[0][1][1])))))) && 0xA4L) || 0x5797L) <= g_193)), p_56)), g_76[0][4])) , p_56) ^ p_56) | g_1207) || (*g_168)) >= l_1439), 6L)) & p_56) < l_1438);
                        l_1409 ^= (l_1412 |= (safe_rshift_func_int64_t_s_u(((*g_155) | (safe_sub_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((safe_rshift_func_int32_t_s_u((p_56 || ((~(safe_sub_func_uint64_t_u_u(((g_78 ^ (((((*g_756) &= (safe_sub_func_int16_t_s_s(((*l_75) = (*l_1168)), ((((safe_lshift_func_uint16_t_u_s(p_56, 3)) ^ (((((((void*)0 != &g_735) , (safe_lshift_func_int32_t_s_u(((*g_1327) ^ (safe_mod_func_uint16_t_u_u((((*g_161)++) , (safe_lshift_func_uint32_t_u_u(((safe_lshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u(1UL, l_1467)), l_1438)) == p_56), 24))), 0xB4A7L))), 16))) , &g_695[1][1]) != l_1468[3]) | (*g_1120)) , 0UL)) > p_56) ^ (*g_1120))))) <= (*l_1168)) == p_56) ^ 4L)) != 0x14L), l_1469))) < l_1348)), 0)), p_56)), l_1351[1][4]))), 43)));
                        (*g_1120) &= ((safe_sub_func_int16_t_s_s(g_1350[2], p_56)) & (((safe_add_func_uint64_t_u_u((l_1474 != ((*l_1475) = &l_1167[3][1][4])), (safe_mul_func_uint16_t_u_u((l_1204 | (safe_mod_func_uint64_t_u_u(((p_56 == (((((safe_lshift_func_uint32_t_u_u((safe_mul_func_int64_t_s_s((l_1412 = ((*l_1484) ^= l_1349)), ((l_1487 = l_1486) != (**g_694)))), 25)) && p_56) >= 1UL) || (*l_1168)) != g_123[8])) & p_56), (-5L)))), (*l_1168))))) , l_1488) && p_56));
                    }
                    return l_1410;
                }
                else
                { /* block id: 605 */
                    int8_t l_1489[7][4][7] = {{{0xD8L,0xB2L,0xC2L,(-3L),0x3BL,0xD9L,0xC2L},{(-4L),0x3BL,(-9L),(-9L),0x3BL,(-4L),0xE1L},{0x15L,0xC2L,0L,0x6BL,(-1L),0xC5L,0x3BL},{(-9L),0xE3L,0L,1L,0L,1L,0x0DL}},{{0xA7L,0xC2L,(-8L),0xA7L,0x03L,0xDDL,0xD9L},{(-1L),0x3BL,0x49L,1L,0x62L,0L,0x92L},{(-9L),0x88L,0xD9L,0x22L,0L,0xE1L,4L},{0L,0x15L,0xD3L,0xE4L,0xB2L,0xE1L,0L}},{{1L,(-1L),0x0BL,0xC2L,(-9L),0L,0x3BL},{0x22L,0xDDL,0xE0L,0x0DL,0xE0L,0xDDL,0x22L},{0x2AL,0x22L,0xA7L,0L,0x15L,1L,(-8L)},{0x92L,0L,0L,0xC2L,0x62L,0xC5L,(-9L)}},{{0x03L,0xE4L,0xA7L,0x73L,0x88L,(-4L),(-1L)},{0xD3L,0x73L,0xE0L,0xE1L,0x0DL,0xD9L,0x2AL},{0x73L,0L,0x0BL,1L,(-1L),0x4CL,1L},{(-1L),0xE1L,0xD3L,(-1L),1L,(-1L),1L}},{{0x88L,0x6BL,0xD9L,(-4L),1L,0xD3L,0x2AL},{0x92L,(-1L),0x49L,0x6BL,0x6BL,0x49L,(-1L)},{0x62L,0L,(-8L),0x92L,0xDDL,0xA7L,(-9L)},{0xE1L,0x03L,0L,0xE0L,1L,0xD9L,(-8L)}},{{1L,0x3BL,0L,0x92L,0x3BL,0L,0x22L},{0x15L,(-8L),(-9L),0x6BL,0xA7L,(-1L),0x3BL},{(-1L),1L,0L,(-4L),0x0DL,1L,0L},{(-1L),0xC2L,1L,(-1L),0x03L,(-3L),4L}},{{(-1L),1L,(-1L),1L,0x2AL,0xE0L,0x92L},{(-1L),0x03L,0xD9L,0xE1L,0x15L,0xE1L,0xD9L},{0x15L,0x15L,0x33L,0x73L,0xB2L,(-8L),0x0DL},{1L,0xD3L,0L,0xC2L,(-1L),0xE0L,0x3BL}}};
                    uint32_t *l_1497 = &l_1132[0][4][2];
                    int i, j, k;
                    (*g_155) ^= ((g_140 < (4294967290UL | l_1489[2][3][3])) , (((*l_1497) = (((safe_rshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_u((*l_1168), 5)), (p_56 & (safe_mul_func_uint32_t_u_u(((*g_1327) < (~(g_123[8] != (1UL | 0xDCL)))), (*g_1327)))))) || 1UL) != 0x80L)) , l_1204));
                }
            }
        }
        for (g_52 = (-29); (g_52 != (-1)); g_52 = safe_add_func_int32_t_s_s(g_52, 7))
        { /* block id: 613 */
            int32_t **l_1505 = &g_1120;
            uint8_t *l_1527 = (void*)0;
            uint8_t *l_1528 = &g_116;
            uint16_t ****l_1543 = &g_652[9];
            int32_t l_1562[7];
            int8_t l_1601[7];
            uint32_t l_1619 = 0x539BCAE2L;
            int i;
            for (i = 0; i < 7; i++)
                l_1562[i] = 0L;
            for (i = 0; i < 7; i++)
                l_1601[i] = 1L;
            for (g_732 = 0; (g_732 > 26); g_732 = safe_add_func_int64_t_s_s(g_732, 3))
            { /* block id: 616 */
                int32_t *l_1502 = (void*)0;
                uint16_t *l_1508[4][3] = {{&g_74[1][3],&g_74[0][3],&g_74[1][3]},{&g_1509[2],&g_1509[2],&g_1509[2]},{&g_74[1][3],&g_74[0][3],&g_74[1][3]},{&g_1509[2],&g_1509[2],&g_1509[2]}};
                int i, j;
                l_1502 = &l_1157;
                (*l_1168) |= ((p_56 | (safe_add_func_uint16_t_u_u((*g_161), (l_1505 == &l_1168)))) ^ ((*l_1502) = (safe_mul_func_uint8_t_u_u(0x31L, 0UL))));
            }
            if ((p_56 , ((((safe_add_func_uint64_t_u_u((((safe_rshift_func_int64_t_s_s(((((((((~0xC8B25916L) >= (**l_1505)) & ((*l_1528) = (((safe_rshift_func_uint16_t_u_u(1UL, 4)) & ((*g_168) = (safe_mul_func_uint16_t_u_u((((**g_1077) = (((**g_696) , 6UL) != ((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((**l_1505), (-9L))), 1UL)), 0)) <= l_1351[1][1]))) == 0UL), p_56)))) ^ l_1349))) >= p_56) , &g_695[1][1]) == &g_695[1][1]) < p_56) || p_56), 50)) & l_1349) & 0x0F0BABC0D462B78BLL), 0xD8628D7945FF87D1LL)) , l_1348) , (**l_1505)) != (*l_1168))))
            { /* block id: 624 */
                int8_t l_1533 = 0x6BL;
                uint16_t *****l_1541[2][8][10] = {{{&l_1540,&l_1540,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540},{&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,(void*)0,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,(void*)0,(void*)0,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540}},{{&l_1540,&l_1540,(void*)0,&l_1540,(void*)0,(void*)0,&l_1540,(void*)0,&l_1540,&l_1540},{&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540},{&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,(void*)0,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,&l_1540,&l_1540,(void*)0,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,&l_1540,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,(void*)0,&l_1540,&l_1540},{&l_1540,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540},{&l_1540,(void*)0,&l_1540,(void*)0,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540,&l_1540}}};
                int32_t *l_1545[2];
                int64_t l_1556 = (-3L);
                int32_t **l_1557 = &g_51;
                int32_t *l_1558 = &l_1349;
                uint8_t l_1559[3][3][3] = {{{0UL,6UL,0UL},{6UL,0UL,0UL},{0UL,0UL,0UL}},{{255UL,6UL,0UL},{0UL,0UL,0UL},{6UL,255UL,0UL}},{{255UL,0xDCL,255UL},{255UL,0UL,0xDCL},{0UL,255UL,255UL}}};
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_1545[i] = &g_85;
                (**l_1505) = (safe_sub_func_int16_t_s_s(((((++(*l_1528)) ^ ((void*)0 != &g_861)) <= ((((safe_rshift_func_uint8_t_u_u(((safe_sub_func_int16_t_s_s(((*l_75) |= (((g_1542 = l_1540) != l_1543) , ((((*g_756) = ((((void*)0 != &g_76[0][4]) == g_78) >= 0x4DL)) ^ (((*g_1077) = (*g_1077)) == (void*)0)) , l_1544))), g_855)) || 0UL), g_77)) & 0UL) , (void*)0) == (void*)0)) < 0x2B02L), l_1351[1][5]));
                l_1546++;
                (**l_1505) = (safe_sub_func_int64_t_s_s((**l_1505), (l_1351[1][4] & ((safe_mod_func_int64_t_s_s((((safe_mul_func_int32_t_s_s((l_1555 == l_75), (l_1556 = ((**l_1505) > (p_56 = p_56))))) < 255UL) & (&l_1348 == (l_1558 = (*l_1505)))), l_1559[0][2][2])) >= (*l_1168)))));
                for (l_1370 = (-25); (l_1370 == 20); ++l_1370)
                { /* block id: 638 */
                    if (g_94)
                        goto lbl_1123;
                }
            }
            else
            { /* block id: 641 */
                int32_t *l_1563 = &l_1351[1][5];
                int32_t *l_1564 = &l_1562[3];
                int32_t *l_1565 = &g_85;
                int32_t *l_1566 = (void*)0;
                int32_t *l_1567 = &l_1348;
                int32_t *l_1568 = (void*)0;
                int32_t *l_1569[2][9][6] = {{{(void*)0,&g_78,(void*)0,&l_1562[3],&l_1343[1][4],(void*)0},{&l_1348,&l_1351[1][1],&l_1343[1][4],&g_156[5],&l_1343[1][4],&g_156[5]},{&g_156[5],&g_78,(void*)0,&g_78,&g_156[5],&g_156[5]},{&l_1343[1][4],&g_78,&l_1204,&l_1127,(void*)0,&l_1348},{&l_1204,&l_1199,&g_156[5],&g_78,&l_1127,&l_1348},{&g_156[5],&g_156[5],&l_1204,&l_1204,&g_156[5],&g_156[5]},{&l_1127,&l_1562[3],(void*)0,&l_1343[1][4],&l_1343[1][4],&g_156[5]},{&l_1562[3],&g_156[5],&l_1343[1][4],(void*)0,&l_1351[1][1],(void*)0},{&l_1562[3],&l_1127,(void*)0,&l_1343[1][4],(void*)0,&l_1127}},{{&l_1127,&l_1343[1][4],&g_78,&l_1204,&l_1127,(void*)0},{&g_156[5],(void*)0,&l_1343[1][4],&g_78,&l_1348,(void*)0},{&l_1204,(void*)0,&l_1199,&l_1127,&l_1127,&l_1199},{&l_1343[1][4],&l_1343[1][4],(void*)0,&g_78,(void*)0,&l_1562[3]},{&g_156[5],&l_1127,(void*)0,&g_156[5],&l_1351[1][1],(void*)0},{&l_1348,&g_156[5],(void*)0,&l_1562[3],&l_1343[1][4],&l_1562[3]},{(void*)0,&l_1562[3],(void*)0,(void*)0,&g_156[5],&l_1199},{(void*)0,&g_156[5],&l_1199,&l_1351[1][1],&l_1127,(void*)0},{&g_78,&l_1199,&l_1343[1][4],&l_1351[1][1],(void*)0,(void*)0}}};
                int i, j, k;
                l_1570--;
                return g_1573;
            }
            for (l_1204 = 0; (l_1204 == 23); l_1204++)
            { /* block id: 647 */
                uint16_t l_1578 = 1UL;
                l_1589 = ((*l_1168) = ((safe_mod_func_uint32_t_u_u((l_1157 &= ((**l_1505) = l_1578)), l_1127)) && (safe_sub_func_uint64_t_u_u(((l_1157 != ((18446744073709551615UL || ((*l_1168) | (safe_sub_func_int8_t_s_s(((((safe_mod_func_int32_t_s_s(0x717A6810L, (p_56 , (((**l_1505) = (((*g_756) = (l_1585[0][2] | (safe_div_func_uint8_t_u_u((!(**l_1505)), 0x8DL)))) | p_56)) , p_56)))) & l_1578) == p_56) & l_1127), 4L)))) , 0x7BL)) != 0x7DCFL), (*l_1168)))));
            }
            for (g_116 = 0; (g_116 > 1); g_116 = safe_add_func_uint32_t_u_u(g_116, 8))
            { /* block id: 657 */
                int64_t *l_1592[8] = {&l_1467,&l_1467,&g_48[0][1][0],&l_1467,&l_1467,&g_48[0][1][0],&l_1467,&l_1467};
                int32_t l_1596 = 0xD4319CC9L;
                int32_t l_1620 = 0x92372C8EL;
                int i;
                (*l_1168) = ((p_56 = 0x9228C827805DBFEBLL) | (safe_sub_func_uint16_t_u_u(0x2EC2L, 0xA847L)));
                if (l_1546)
                    goto lbl_1595;
                (*l_1168) ^= (l_1596 = (*g_155));
                (*g_1621) ^= ((*l_1168) = (safe_rshift_func_uint16_t_u_u((l_1620 |= (((((((safe_sub_func_uint32_t_u_u((l_1127 = ((l_1596 |= (*l_1168)) , ((((l_1601[1] &= (**l_1505)) | ((1L > (((safe_add_func_int32_t_s_s(0x266B4030L, (safe_add_func_int8_t_s_s((((safe_mod_func_int32_t_s_s(8L, (safe_sub_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u(((((safe_add_func_int16_t_s_s((safe_sub_func_int16_t_s_s((((9L < (l_1616 != (void*)0)) && l_1617) <= g_85), 0x1773L)), g_603[0])) <= 251UL) < g_52) >= l_1618[4][0][1]), 1UL)), 7L)))) | g_582) || (-1L)), 8L)))) & (*g_161)) , 0UL)) , (*l_1168))) <= l_1618[4][0][1]) , 1UL))), l_1618[4][0][1])) , l_1619) >= (**l_1505)) , &g_652[0]) == (void*)0) || p_56) , p_56)), 8)));
            }
        }
        (*l_1168) |= (~(*g_168));
    }
    if (((safe_mul_func_uint64_t_u_u(((g_636 = (+((**g_1077) = ((0UL > (safe_rshift_func_int32_t_s_u((safe_mod_func_uint16_t_u_u(0UL, 0xE715L)), 16))) > ((*l_1635) ^= (((~p_56) >= p_56) & (safe_div_func_int16_t_s_s((((l_1633[1][8] = l_1633[0][8]) != &l_1437) | (l_1634 | (((*l_1125) = ((p_56 < 0xD2L) , l_1204)) == l_1204))), p_56)))))))) != p_56), l_1636)) , p_56))
    { /* block id: 678 */
        uint32_t l_1637 = 0x02C34E00L;
        l_1637 ^= (-6L);
        return p_56;
    }
    else
    { /* block id: 681 */
        for (g_732 = 0; (g_732 != (-3)); g_732 = safe_sub_func_int16_t_s_s(g_732, 1))
        { /* block id: 684 */
            (*g_1120) ^= 0xED6E6F05L;
            (*g_1120) ^= p_56;
        }
    }
    return p_56;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_58(int32_t  p_59, int32_t  p_60, int32_t * const * p_61)
{ /* block id: 446 */
    int8_t l_1122[9][9][3] = {{{0xE9L,0xF7L,1L},{0xE9L,0x2EL,0x03L},{0xE9L,(-9L),0xE9L},{0xE9L,0xF7L,1L},{0xE9L,0x2EL,0x03L},{0xE9L,(-9L),0xE9L},{0xE9L,0xF7L,1L},{0xE9L,0x2EL,0x03L},{0xE9L,(-9L),0xE9L}},{{0xE9L,0xF7L,1L},{0xE9L,0x2EL,0x03L},{0xE9L,(-9L),0xE9L},{0xE9L,0xF7L,1L},{0xE9L,0x2EL,0x03L},{0xE9L,(-9L),0xE9L},{0xE9L,0xF7L,1L},{0xE9L,0x2EL,0x03L},{0xE9L,(-9L),0xE9L}},{{0xE9L,0xF7L,1L},{0xE9L,0x2EL,0x03L},{0xE9L,(-9L),0xE9L},{0xE9L,0xF7L,1L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL}},{{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL}},{{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL}},{{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL}},{{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL}},{{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL}},{{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL},{0x1BL,0xE9L,0L},{0x1BL,0x03L,0xE5L},{0x1BL,1L,0x1BL}}};
    int i, j, k;
    return l_1122[5][6][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_50 g_51 g_78 g_76 g_94 g_85 g_123 g_5 g_140 g_142 g_116 g_155 g_156 g_160 g_174 g_179 g_168 g_77 g_241 g_242 g_289 g_161 g_260 g_193 g_48 g_74 g_582 g_603 g_670 g_688 g_636 g_694 g_667 g_732 g_737 g_695 g_696 g_751 g_754 g_794 g_755 g_756 g_735 g_861 g_931 g_981 g_1043 g_1095 g_1077 g_1078
 * writes: g_52 g_78 g_94 g_85 g_116 g_123 g_140 g_76 g_142 g_156 g_160 g_161 g_168 g_174 g_179 g_47 g_51 g_260 g_48 g_74 g_193 g_582 g_242 g_652 g_636 g_667 g_720 g_732 g_735 g_981 g_1095 g_1098 g_737
 */
static uint8_t  func_63(uint32_t  p_64, const int8_t  p_65)
{ /* block id: 11 */
    uint16_t *l_79 = &g_74[1][6];
    int32_t *l_84 = &g_85;
    uint16_t **l_90 = (void*)0;
    uint16_t **l_91 = &l_79;
    uint16_t l_172 = 0x73F2L;
    uint32_t l_177 = 0x7A79C0B2L;
    uint8_t *l_207 = &g_5[0][0];
    int32_t l_356 = 0xEF89A33DL;
    int32_t l_357 = 0L;
    int32_t l_358 = 9L;
    uint32_t l_361 = 2UL;
    int32_t ***l_377 = &g_241[3][2];
    const uint16_t *l_390 = &g_123[2];
    const uint16_t **l_389 = &l_390;
    const uint16_t ***l_388 = &l_389;
    const uint16_t ****l_387 = &l_388;
    uint64_t * const l_422 = &g_140;
    int32_t l_488 = 1L;
    uint64_t * const *l_517[2][10][6] = {{{&l_422,&l_422,&l_422,&l_422,(void*)0,&l_422},{&l_422,&l_422,&l_422,&l_422,&l_422,&l_422},{&l_422,&l_422,&l_422,(void*)0,&l_422,&l_422},{&l_422,(void*)0,&l_422,&l_422,&l_422,&l_422},{&l_422,&l_422,(void*)0,&l_422,&l_422,&l_422},{&l_422,&l_422,&l_422,(void*)0,(void*)0,&l_422},{&l_422,&l_422,&l_422,&l_422,&l_422,&l_422},{(void*)0,&l_422,(void*)0,&l_422,&l_422,(void*)0},{&l_422,(void*)0,&l_422,&l_422,(void*)0,(void*)0},{&l_422,&l_422,&l_422,&l_422,&l_422,(void*)0}},{{&l_422,&l_422,(void*)0,(void*)0,&l_422,&l_422},{&l_422,(void*)0,&l_422,&l_422,&l_422,&l_422},{&l_422,&l_422,&l_422,(void*)0,&l_422,&l_422},{&l_422,&l_422,&l_422,&l_422,(void*)0,&l_422},{(void*)0,(void*)0,(void*)0,&l_422,&l_422,&l_422},{&l_422,&l_422,&l_422,(void*)0,&l_422,&l_422},{&l_422,&l_422,(void*)0,&l_422,(void*)0,&l_422},{(void*)0,&l_422,&l_422,&l_422,&l_422,(void*)0},{&l_422,&l_422,(void*)0,&l_422,&l_422,&l_422},{&l_422,(void*)0,&l_422,&l_422,&l_422,(void*)0}}};
    uint64_t * const **l_516[10] = {&l_517[0][5][2],&l_517[0][6][2],&l_517[0][5][2],(void*)0,(void*)0,&l_517[0][5][2],&l_517[0][6][2],&l_517[0][5][2],(void*)0,(void*)0};
    uint32_t l_541 = 0x863A165CL;
    uint32_t l_610 = 0xD8912CC2L;
    uint8_t l_611 = 1UL;
    int32_t l_630 = 0xDA6895BFL;
    int32_t l_632 = 1L;
    int32_t l_634 = 3L;
    int32_t l_635[4][9] = {{0xBBFD7ABEL,0x70C8B207L,7L,0L,(-5L),0x5F535460L,0x5F535460L,(-5L),0L},{4L,0xBBFD7ABEL,4L,0xED9496CBL,0x5F535460L,0x70C8B207L,0x3D07C3D5L,0xB11CB596L,0xB11CB596L},{(-7L),0xBBFD7ABEL,0xB11CB596L,0x5F535460L,0xB11CB596L,0xBBFD7ABEL,(-7L),0x3D07C3D5L,7L},{0x3D07C3D5L,0x70C8B207L,0x5F535460L,0xED9496CBL,4L,0xBBFD7ABEL,4L,0xED9496CBL,0x5F535460L}};
    uint16_t l_638 = 65534UL;
    uint32_t *l_679 = (void*)0;
    uint64_t ***l_758 = &g_755;
    uint16_t l_851 = 0x8A77L;
    const uint8_t *l_892 = (void*)0;
    int8_t *l_902 = (void*)0;
    uint32_t **l_930 = (void*)0;
    int32_t * const l_1008 = &l_357;
    int16_t l_1080 = 0x5A46L;
    int32_t l_1118 = (-1L);
    int i, j, k;
    for (g_52 = 1; (g_52 >= 0); g_52 -= 1)
    { /* block id: 14 */
        uint16_t **l_88 = (void*)0;
        int32_t l_114 = 0x9EA4C7FAL;
        int8_t l_157 = (-1L);
        for (p_64 = 0; (p_64 <= 5); p_64 += 1)
        { /* block id: 17 */
            int16_t l_122 = 0x3C28L;
            int32_t l_134 = 0L;
            uint16_t l_136[10] = {0x3B4FL,0x3B4FL,0UL,0x55B8L,0UL,0x3B4FL,0x3B4FL,0UL,0x55B8L,0UL};
            int i;
            for (g_78 = 0; (g_78 <= 1); g_78 += 1)
            { /* block id: 20 */
                uint16_t **l_80 = &l_79;
                int32_t * const l_83 = &g_78;
                uint16_t ***l_89[2];
                int8_t *l_92 = (void*)0;
                int8_t *l_93[2][9] = {{&g_94,&g_94,&g_94,&g_94,&g_94,&g_94,&g_94,&g_94,&g_94},{(void*)0,&g_94,(void*)0,&g_94,&g_94,&g_94,&g_94,(void*)0,&g_94}};
                int32_t *l_95 = &g_85;
                int32_t l_120[6] = {0x423D3ABBL,0x8ACF152CL,0x8ACF152CL,0x423D3ABBL,0x8ACF152CL,0x8ACF152CL};
                int i, j;
                for (i = 0; i < 2; i++)
                    l_89[i] = &l_80;
                (*l_95) |= ((&g_74[g_52][(g_52 + 2)] != ((*l_80) = l_79)) && ((safe_add_func_int64_t_s_s((((l_83 == (l_84 = (*g_50))) < ((safe_mul_func_uint8_t_u_u(((l_91 = (l_90 = l_88)) != (void*)0), (g_94 ^= g_76[g_78][(g_78 + 4)]))) > 0xDB64L)) , p_64), 0x044A2B86846FFD3CLL)) <= (*l_83)));
                for (g_85 = 5; (g_85 >= 1); g_85 -= 1)
                { /* block id: 29 */
                    int32_t l_96 = (-9L);
                    uint16_t *l_111 = (void*)0;
                    int32_t *l_112 = (void*)0;
                    if (l_96)
                        break;
                    for (g_94 = 5; (g_94 >= 1); g_94 -= 1)
                    { /* block id: 33 */
                        uint8_t l_110 = 248UL;
                        int32_t **l_113 = &l_95;
                        uint8_t *l_115 = &g_116;
                        int64_t l_117 = 7L;
                        uint8_t *l_118 = &l_110;
                        int32_t *l_119 = (void*)0;
                        int32_t *l_121[8];
                        uint64_t *l_139 = &g_140;
                        int16_t *l_141[3];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_121[i] = &l_120[0];
                        for (i = 0; i < 3; i++)
                            l_141[i] = (void*)0;
                        l_114 = (((*l_118) = ((((safe_div_func_int64_t_s_s((safe_div_func_int8_t_s_s((safe_add_func_int16_t_s_s((safe_div_func_int8_t_s_s((safe_lshift_func_int64_t_s_u((safe_mul_func_uint8_t_u_u((~0UL), ((l_110 != 1UL) != ((void*)0 != l_111)))), (((*l_113) = l_112) == (*g_50)))), 5L)), (((*l_115) = (l_114 & 0x816D4D43A62FBF91LL)) < 254UL))), l_114)), l_117)) ^ p_65) , 0x92391BE15C8DD589LL) <= 18446744073709551606UL)) == (-1L));
                        --g_123[8];
                        if (l_122)
                            break;
                        g_142 ^= ((safe_add_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s(1L, (g_5[4][0] < 0x5362L))) != (g_76[0][5] = (safe_lshift_func_uint8_t_u_s((safe_add_func_uint16_t_u_u((((*l_113) != (void*)0) == ((l_134 && ((*l_139) |= ((+l_122) == (((l_136[3] <= (safe_rshift_func_int64_t_s_u(p_65, 20))) | g_5[5][0]) < 0x643A2F0F6D1638B9LL)))) || 0UL)), 0x0F4AL)), p_65)))), (-1L))) ^ 18446744073709551608UL);
                    }
                    for (g_116 = 0; (g_116 <= 5); g_116 += 1)
                    { /* block id: 46 */
                        int32_t *l_154 = &l_96;
                        (*g_155) &= (((safe_rshift_func_int8_t_s_s((safe_div_func_int64_t_s_s(((!(safe_div_func_uint16_t_u_u(p_64, 0xCEB6L))) <= (safe_sub_func_uint64_t_u_u((p_65 | (safe_div_func_int64_t_s_s(1L, (((g_94 ^= (&p_65 == &g_94)) <= (4294967295UL >= (((((*l_154) &= (l_114 = ((*l_83) <= g_123[0]))) , &l_80) != &l_91) & p_64))) && 0x5EL)))), 0x594DF62E77A0DE80LL))), p_64)), g_76[0][4])) < g_123[8]) == 0L);
                    }
                }
            }
        }
        if (l_157)
            continue;
    }
    if ((*g_155))
    { /* block id: 57 */
        const int8_t l_162 = 0L;
        int32_t l_163 = 0L;
        uint16_t *l_166 = &g_123[8];
        uint16_t **l_167 = &g_161;
        int8_t *l_171 = &g_94;
        uint32_t *l_173 = &g_174;
        int64_t *l_175[5][10][5] = {{{&g_48[0][1][0],&g_48[2][0][1],&g_48[4][2][1],&g_48[0][1][0],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],(void*)0,(void*)0,&g_48[0][1][0]},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][2][1],&g_142},{(void*)0,&g_142,&g_142,&g_142,&g_48[0][1][0]},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][2][1],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],&g_142,(void*)0,(void*)0},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][1][0],&g_142},{(void*)0,&g_142,(void*)0,&g_142,(void*)0},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][1][0],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],(void*)0,(void*)0,&g_48[0][1][0]}},{{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][2][1],&g_142},{(void*)0,&g_142,&g_142,&g_142,&g_48[0][1][0]},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][2][1],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],&g_142,(void*)0,(void*)0},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][1][0],&g_142},{(void*)0,&g_142,(void*)0,&g_142,(void*)0},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][1][0],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],(void*)0,(void*)0,&g_48[0][1][0]},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][2][1],&g_142},{(void*)0,&g_142,&g_142,&g_142,&g_48[0][1][0]}},{{&g_142,&g_48[0][1][0],&g_142,&g_48[0][2][1],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],&g_142,(void*)0,(void*)0},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][1][0],&g_142},{(void*)0,&g_142,(void*)0,&g_142,(void*)0},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][1][0],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],(void*)0,(void*)0,&g_48[0][1][0]},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][2][1],&g_142},{(void*)0,&g_142,&g_142,&g_142,&g_48[0][1][0]},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][2][1],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],&g_142,(void*)0,(void*)0}},{{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][1][0],&g_142},{(void*)0,&g_142,(void*)0,&g_142,(void*)0},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][1][0],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],(void*)0,(void*)0,&g_48[0][1][0]},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][2][1],&g_142},{(void*)0,&g_142,&g_142,&g_142,&g_48[0][1][0]},{&g_142,&g_48[0][1][0],&g_142,&g_48[0][2][1],&g_48[0][1][0]},{(void*)0,&g_48[0][0][0],&g_142,(void*)0,(void*)0},{&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1],&g_48[0][1][0],&g_48[0][0][1]},{&g_142,&g_48[0][1][0],&g_142,(void*)0,(void*)0}},{{&g_142,&g_48[0][1][0],&g_48[0][2][0],&g_48[0][1][0],&g_142},{(void*)0,&g_142,&g_142,(void*)0,(void*)0},{&g_48[0][1][0],&g_48[0][1][0],&g_48[0][1][0],&g_142,&g_48[0][0][1]},{(void*)0,&g_48[0][1][0],&g_48[2][0][1],(void*)0,(void*)0},{&g_142,&g_48[1][1][0],&g_48[0][2][0],&g_142,&g_142},{&g_142,&g_142,&g_48[2][0][1],(void*)0,(void*)0},{&g_48[0][1][0],&g_48[1][1][0],&g_48[0][1][0],&g_48[0][1][0],&g_48[0][0][1]},{&g_142,&g_48[0][1][0],&g_142,(void*)0,(void*)0},{&g_142,&g_48[0][1][0],&g_48[0][2][0],&g_48[0][1][0],&g_142},{(void*)0,&g_142,&g_142,(void*)0,(void*)0}}};
        int32_t l_176 = 0x3390C0CCL;
        int8_t *l_178[3][2][9];
        int32_t **l_243[6][7][5] = {{{&g_242,(void*)0,&g_242,&g_242,(void*)0},{&g_242,&g_242,(void*)0,&g_242,&g_242},{&g_242,(void*)0,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,(void*)0,&g_242,&g_242,&g_242}},{{&g_242,(void*)0,&g_242,(void*)0,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,(void*)0,&g_242,&g_242},{(void*)0,&g_242,&g_242,&g_242,(void*)0},{&g_242,(void*)0,(void*)0,&g_242,(void*)0},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,(void*)0,&g_242,(void*)0,(void*)0}},{{(void*)0,&g_242,&g_242,(void*)0,(void*)0},{(void*)0,&g_242,&g_242,&g_242,&g_242},{(void*)0,&g_242,(void*)0,&g_242,&g_242},{&g_242,&g_242,(void*)0,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,(void*)0,&g_242,&g_242}},{{&g_242,&g_242,(void*)0,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{(void*)0,&g_242,&g_242,(void*)0,(void*)0},{&g_242,&g_242,&g_242,&g_242,&g_242},{(void*)0,&g_242,(void*)0,&g_242,&g_242},{&g_242,(void*)0,&g_242,(void*)0,&g_242}},{{&g_242,&g_242,(void*)0,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{(void*)0,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,(void*)0},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,(void*)0,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,(void*)0,&g_242}},{{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{&g_242,(void*)0,&g_242,&g_242,&g_242},{&g_242,&g_242,&g_242,&g_242,&g_242},{(void*)0,&g_242,&g_242,&g_242,(void*)0},{&g_242,&g_242,(void*)0,&g_242,&g_242},{(void*)0,(void*)0,&g_242,&g_242,(void*)0}}};
        int32_t l_359 = 0x8622F22AL;
        int32_t l_360 = 0x654F5CE1L;
        int32_t ***l_378 = &l_243[0][5][0];
        const int64_t l_382 = 2L;
        const int8_t l_383[1] = {0L};
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 2; j++)
            {
                for (k = 0; k < 9; k++)
                    l_178[i][j][k] = (void*)0;
            }
        }
        if ((safe_add_func_uint16_t_u_u(((g_179 |= (((((g_160 = g_160) == &g_161) || (l_163 = (l_162 ^ 0UL))) | (((safe_lshift_func_int64_t_s_s((((18446744073709551615UL == (l_176 &= ((((*l_173) |= ((l_166 == (g_168 = ((*l_167) = l_166))) , ((p_65 && (safe_mod_func_uint32_t_u_u((((((*l_171) = ((&g_123[0] != &g_123[8]) , g_76[0][3])) <= l_172) <= p_65) , g_5[4][0]), g_156[7]))) >= l_162))) , (void*)0) != l_175[4][7][4]))) , l_177) || l_162), 3)) | (-1L)) == p_64)) , (-1L))) && p_64), l_162)))
        { /* block id: 66 */
            int64_t * const l_189 = &g_48[1][2][0];
            uint32_t *l_192[9][10][2] = {{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{(void*)0,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{(void*)0,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{(void*)0,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{(void*)0,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{(void*)0,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193}},{{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193},{&g_193,&g_193}}};
            uint8_t *l_196 = &g_116;
            uint64_t *l_199 = &g_140;
            int32_t *l_201 = &l_176;
            int64_t l_212 = 9L;
            uint32_t l_297 = 4294967286UL;
            int32_t l_303 = 0x1BF46D65L;
            int32_t **l_329 = &g_242;
            int i, j, k;
lbl_307:
            (*l_201) = (safe_sub_func_uint64_t_u_u((((safe_rshift_func_int64_t_s_s((safe_sub_func_uint64_t_u_u(((((void*)0 != l_175[4][7][4]) & (safe_div_func_int32_t_s_s((~((((*l_199) = ((0x8B7DADB20BFAB2E0LL <= (((((l_189 != (g_47[5] = (void*)0)) == (((safe_div_func_uint32_t_u_u((p_64 = g_116), 0xE04F8DB9L)) , (safe_mul_func_uint8_t_u_u(((*l_196) = 0x61L), ((safe_mod_func_uint16_t_u_u((*g_168), (-7L))) >= 0xC0L)))) || 0xBEDFL)) || 0x81E5L) || (*g_155)) , l_163)) == g_85)) , l_162) > l_163)), 4294967295UL))) | 0xAC62L), (-9L))), 22)) , 0UL) > (-9L)), 0x68A6C423DE851E6ALL));
            for (g_142 = 12; (g_142 <= (-8)); g_142 = safe_sub_func_uint8_t_u_u(g_142, 1))
            { /* block id: 74 */
                int8_t l_227 = (-1L);
                int32_t l_230[6][10] = {{(-2L),0x2E5F2695L,0x863BCAABL,0L,0x0199EC3FL,0L,(-1L),(-1L),0L,0x0199EC3FL},{0xA774E767L,0L,0L,0xA774E767L,3L,(-5L),0x433A3D88L,(-2L),6L,0x2E5F2695L},{0xACBB44B8L,3L,0x90424AEAL,0L,6L,0x433A3D88L,0L,0x433A3D88L,6L,0L},{0x2E5F2695L,0xACBB44B8L,0x2E5F2695L,0xA774E767L,(-1L),(-1L),6L,(-4L),0L,6L},{6L,(-1L),3L,0L,(-4L),0x0199EC3FL,0x0199EC3FL,(-4L),0L,3L},{0x90424AEAL,0x90424AEAL,0x2E5F2695L,0xF5AA1C89L,0L,0xACBB44B8L,0x863BCAABL,0x433A3D88L,(-4L),(-5L)}};
                const uint16_t *l_249[1][5][4] = {{{&l_172,&l_172,&l_172,&l_172},{&l_172,&g_123[5],&g_123[5],&l_172},{&g_123[5],&l_172,&g_123[5],&g_123[5]},{&l_172,&l_172,&l_172,&l_172},{&l_172,&g_123[5],&g_123[5],&l_172}}};
                const uint16_t **l_248 = &l_249[0][4][2];
                const uint16_t ***l_247 = &l_248;
                int32_t **l_271 = (void*)0;
                int32_t *l_272 = (void*)0;
                uint16_t *l_323 = &g_123[8];
                int i, j, k;
                for (g_78 = (-20); (g_78 > (-30)); --g_78)
                { /* block id: 77 */
                    int32_t **l_219 = &g_51;
                    int32_t l_246 = 0x1B0F9FA3L;
                    if ((~(((void*)0 == l_207) != (*l_201))))
                    { /* block id: 78 */
                        int32_t *l_216 = &g_179;
                        int32_t **l_215 = &l_216;
                        int32_t **l_224 = (void*)0;
                        int32_t *l_226[10] = {(void*)0,(void*)0,(void*)0,&g_179,(void*)0,(void*)0,(void*)0,(void*)0,&g_179,(void*)0};
                        int32_t **l_225 = &l_226[2];
                        int16_t *l_228 = &g_76[0][4];
                        int32_t l_229 = 0xB37FBF51L;
                        int32_t *l_232 = &g_85;
                        int32_t ***l_244 = &l_243[4][3][1];
                        int32_t ***l_245 = &l_215;
                        uint16_t ***l_251[1];
                        uint16_t ****l_250 = &l_251[0];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_251[i] = &l_167;
                        (*l_232) &= (l_230[0][1] = (safe_div_func_int16_t_s_s((safe_div_func_int32_t_s_s(((((l_212 ^= (*g_168)) <= ((l_229 = (safe_lshift_func_uint16_t_u_u((((((*l_215) = l_84) == l_192[7][7][1]) || (((*l_228) |= ((safe_sub_func_uint32_t_u_u((l_219 != &l_201), (p_64 = 0x146DD524L))) && ((safe_sub_func_uint16_t_u_u((safe_mul_func_uint64_t_u_u(((*l_215) != ((*l_225) = (*l_215))), p_64)), l_227)) | 0xBEL))) || 0xB065L)) == 0x0AC72209DD69673ELL), 14))) != p_65)) && (*l_201)) != g_77), g_140)), p_65)));
                        l_246 ^= (!(((*g_242) = ((safe_rshift_func_uint64_t_u_s((((+((((*l_232) = (((((((safe_mul_func_int8_t_s_s((((void*)0 != l_171) != ((l_227 , ((g_241[3][2] != ((*l_245) = ((*l_244) = l_243[2][4][0]))) , l_230[0][1])) == p_65)), p_64)) , 0x321204FD572D6567LL) , 18446744073709551606UL) && 0UL) != 0x68F17BB5D6DC47B3LL) | 0x52B1CF9FL) > (*g_155))) < p_65) < 65535UL)) || p_65) >= 1L), l_162)) , (*l_201))) , p_65));
                        (*l_232) = ((l_176 || (l_247 != ((*l_250) = &g_160))) , p_65);
                    }
                    else
                    { /* block id: 94 */
                        return l_162;
                    }
                    for (g_140 = (-21); (g_140 != 11); g_140++)
                    { /* block id: 99 */
                        uint64_t *l_259 = &g_260;
                        (*l_219) = (*g_50);
                        (*l_219) = l_201;
                        l_246 ^= (safe_mul_func_uint16_t_u_u((+(0UL >= (((**l_219) == (0x021F96459FD89EE9LL == (((*l_259) = p_65) >= (safe_lshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_s(0x59L, (((p_64 = (((g_76[2][3] == g_140) == ((safe_rshift_func_int8_t_s_u((safe_mod_func_int32_t_s_s(((safe_sub_func_int32_t_s_s((**g_50), 3L)) | g_142), 4294967295UL)), 3)) >= p_65)) <= (**l_219))) != 0xFD2365CFL) ^ p_65))), 6))))) ^ p_65))), g_142));
                    }
                }
                l_84 = ((*g_50) = (l_272 = l_192[7][7][1]));
                for (l_227 = (-18); (l_227 < 24); l_227++)
                { /* block id: 112 */
                    int16_t l_288 = (-5L);
                    for (g_52 = 3; (g_52 >= 0); g_52 -= 1)
                    { /* block id: 115 */
                        int32_t **l_290 = (void*)0;
                        int32_t **l_291 = &l_201;
                        int i, j;
                        (*l_201) = (safe_mod_func_int16_t_s_s(g_116, ((((safe_mod_func_int32_t_s_s(((+(safe_mul_func_uint64_t_u_u((!((void*)0 == g_241[(g_52 + 3)][g_52])), (((g_123[8] < ((*l_201) ^ (0L == p_64))) && (+((((g_156[(g_52 + 3)] = ((safe_lshift_func_uint16_t_u_s((*g_168), 7)) == (((0xA8741E03DBD97F58LL & g_123[8]) & p_65) & p_65))) & g_174) > g_5[3][0]) != 0x2CEEL))) <= p_65)))) , l_162), 0x3CA587E9L)) == 1L) , p_65) & (-9L))));
                        if ((*g_155))
                            break;
                        (*g_289) = (l_288 , (*g_50));
                        (*l_291) = &l_176;
                    }
                }
                for (l_212 = 0; (l_212 == 1); l_212 = safe_add_func_int32_t_s_s(l_212, 1))
                { /* block id: 125 */
                    int64_t l_300[5] = {0xC31099B1E4FE6702LL,0xC31099B1E4FE6702LL,0xC31099B1E4FE6702LL,0xC31099B1E4FE6702LL,0xC31099B1E4FE6702LL};
                    int32_t l_301 = (-1L);
                    uint8_t l_304 = 0xC8L;
                    uint16_t *l_324 = &g_74[1][5];
                    int8_t *l_334 = &g_94;
                    int16_t *l_347 = &g_76[0][4];
                    int32_t *l_349 = &l_303;
                    int i;
                    if (p_65)
                    { /* block id: 126 */
                        int32_t *l_302 = &g_156[5];
                        (*l_302) = (safe_unary_minus_func_uint16_t_u((safe_add_func_uint8_t_u_u(((*l_201) = l_297), (safe_div_func_int16_t_s_s(l_297, (l_301 = ((*l_166) ^= l_300[3]))))))));
                        --l_304;
                        if (l_176)
                            goto lbl_307;
                        if (p_64)
                            break;
                    }
                    else
                    { /* block id: 134 */
                        int32_t ** const l_308[7] = {&l_272,&l_84,&l_272,&l_272,&l_84,&l_272,&l_272};
                        uint8_t *l_313 = &l_304;
                        int i;
                        (*l_201) = (l_308[2] != &g_155);
                        (*l_201) = (safe_mod_func_uint8_t_u_u((p_64 || ((p_65 , ((((((*l_313) = ((*l_196) &= p_65)) == g_156[1]) , (((l_301 = (((((0xA9CEL | (safe_div_func_uint16_t_u_u(((*l_166) = ((safe_div_func_uint16_t_u_u((*g_161), 0xF8A7L)) > ((*l_189) = (((safe_sub_func_int32_t_s_s((((safe_unary_minus_func_int32_t_s(p_65)) , (*l_201)) <= g_76[0][4]), 0UL)) , l_304) | p_64)))), g_78))) || p_64) , (*l_201)) >= p_64) <= p_64)) >= (-2L)) >= g_260)) , 0x8E23L) != l_162)) <= l_163)), 0xF0L));
                        (*l_201) = (p_64 <= (safe_lshift_func_int64_t_s_u(0x9B39C02D81B6AF7DLL, ((((*l_167) = (*g_160)) != (l_324 = l_323)) || ((*l_189) = (safe_sub_func_int16_t_s_s((p_64 , ((0xD2L < ((safe_rshift_func_int64_t_s_s(((-1L) != 1L), ((((void*)0 != l_329) ^ g_179) || (*g_168)))) == 4294967295UL)) == 0x876B6C0DL)), 65526UL)))))));
                        (*g_50) = (*g_289);
                    }
                    (*l_349) ^= (safe_rshift_func_uint64_t_u_s((((p_64 != ((void*)0 != l_84)) == ((*l_347) = (safe_mul_func_uint16_t_u_u(((&l_162 != l_334) , (((safe_mul_func_int64_t_s_s((((safe_lshift_func_uint8_t_u_u(p_65, (safe_div_func_uint16_t_u_u((((((safe_rshift_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((0x68BDD1987B85D46DLL <= (-1L)) < (safe_div_func_uint16_t_u_u((((l_176 = ((((((g_116 = (&p_64 != l_173)) , g_116) == g_85) == 1UL) <= (*l_201)) || g_123[4])) && p_64) || 5UL), l_301))), l_163)), 0)) | p_65) | 0x1C1DF3BDAC993534LL) , 0xE1A1BED7L) && 0L), g_85)))) >= p_65) != p_65), 0xBA162BEFE8F5AF06LL)) , p_65) , (*g_161))), p_64)))) | p_64), 58));
                }
            }
        }
        else
        { /* block id: 154 */
            int32_t *l_355[4];
            int32_t ***l_375 = &g_241[3][2];
            int32_t ****l_374[7] = {&l_375,&l_375,(void*)0,&l_375,&l_375,(void*)0,&l_375};
            int32_t ***l_376 = &g_241[3][2];
            uint64_t *l_379 = &g_140;
            int32_t l_384[7];
            int i;
            for (i = 0; i < 4; i++)
                l_355[i] = (void*)0;
            for (i = 0; i < 7; i++)
                l_384[i] = 8L;
            for (g_116 = (-25); (g_116 < 47); g_116 = safe_add_func_int64_t_s_s(g_116, 1))
            { /* block id: 157 */
                int32_t *l_354 = &g_156[5];
                l_163 = (safe_add_func_int8_t_s_s((-6L), ((g_193 , p_65) , 0x84L)));
                if (l_176)
                    continue;
                (*l_354) = 0L;
                if (p_64)
                    continue;
            }
            l_361--;
            l_359 &= (((safe_mul_func_uint64_t_u_u(((((0x669CBBF9B92B1560LL < ((g_76[2][0] >= g_5[3][0]) ^ 0xC8L)) >= ((safe_lshift_func_uint16_t_u_s((((safe_mul_func_int8_t_s_s((safe_add_func_uint8_t_u_u(0x18L, (safe_unary_minus_func_int16_t_s((+(-1L)))))), (((((*l_379) = ((l_376 = &l_243[2][2][2]) == (l_378 = l_377))) ^ (((safe_rshift_func_int64_t_s_s(l_382, p_65)) && 1L) , 0UL)) > l_360) < l_383[0]))) | p_64) | l_384[1]), 3)) , 0x9DBFL)) , (*g_168)) == 0x475FL), p_65)) && g_48[0][2][0]) > p_64);
        }
    }
    else
    { /* block id: 169 */
        uint32_t l_391 = 18446744073709551615UL;
        int32_t l_411 = 0xD29A96D1L;
        uint32_t l_435 = 0x05BAE596L;
        int32_t l_475 = 0xF3FECB31L;
        int64_t l_477 = 1L;
        int32_t l_478 = (-9L);
        int32_t l_479 = 0xC8BF5B44L;
        int32_t l_481 = (-6L);
        int32_t l_483 = 4L;
        int32_t l_484 = 0x36BD2E50L;
        int32_t l_486[9][10][2] = {{{0xBD78593CL,0xFD04F174L},{1L,1L},{0x4CC1448BL,1L},{1L,0xFD04F174L},{0xBD78593CL,(-1L)},{0x4CC1448BL,0xBD78593CL},{(-1L),0xFD04F174L},{(-1L),0xBD78593CL},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL}},{{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL}},{{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL}},{{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL}},{{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)}},{{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L}},{{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL}},{{(-1L),0xFD04F174L},{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L}},{{(-8L),(-1L)},{0xFD04F174L,0x3A098A3AL},{0x4CC1448BL,0x4CC1448BL},{(-8L),0x4CC1448BL},{0x4CC1448BL,0x3A098A3AL},{0xFD04F174L,(-1L)},{(-8L),0xFD04F174L},{(-1L),0x3A098A3AL},{(-1L),0xFD04F174L},{(-8L),(-1L)}}};
        uint16_t l_521 = 0x0AF1L;
        int16_t *l_533 = &g_76[0][4];
        int32_t *l_585 = &g_179;
        uint32_t l_724 = 0x22C780D6L;
        uint8_t l_816 = 0xA8L;
        uint16_t l_836 = 65535UL;
        int64_t l_911 = 0xCA52D2C28C999715LL;
        uint64_t l_933[6];
        uint64_t l_1091 = 18446744073709551615UL;
        uint64_t l_1115 = 0xA15EAA4F52A3645BLL;
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_933[i] = 0x973B108E367A9579LL;
        if (((safe_mod_func_uint64_t_u_u((l_387 != &l_388), g_85)) , (l_358 != (l_391 | 0x149AF9143D7EFFB6LL))))
        { /* block id: 170 */
            int32_t *l_392 = &g_179;
            uint8_t l_406 = 2UL;
            int32_t l_452 = 0x088B2600L;
            int32_t l_467[7];
            int32_t l_469 = (-8L);
            int32_t l_476[9][2] = {{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L}};
            uint16_t l_492 = 0xC952L;
            int16_t *l_532[7] = {&g_76[0][4],&g_76[0][4],&g_76[0][4],&g_76[0][4],&g_76[0][4],&g_76[0][4],&g_76[0][4]};
            uint16_t ***l_556 = &l_91;
            uint16_t ****l_555[6][2] = {{&l_556,&l_556},{&l_556,&l_556},{&l_556,&l_556},{&l_556,&l_556},{&l_556,&l_556},{&l_556,&l_556}};
            int32_t *l_562 = &l_469;
            int i, j;
            for (i = 0; i < 7; i++)
                l_467[i] = 0L;
            if (((void*)0 != l_392))
            { /* block id: 171 */
                uint16_t l_405[9] = {65527UL,65527UL,65527UL,65527UL,65527UL,65527UL,65527UL,65527UL,65527UL};
                int32_t *l_415 = &l_356;
                int32_t l_433 = 8L;
                int32_t l_434 = 0xEE8E4BB4L;
                int32_t l_480 = 0L;
                int32_t l_485[2][10] = {{0xDF9B1FE8L,0x5BF27620L,0xDF9B1FE8L,0xDF9B1FE8L,0x5BF27620L,0xDF9B1FE8L,0xDF9B1FE8L,0x5BF27620L,0xDF9B1FE8L,0xDF9B1FE8L},{0x5BF27620L,0x5BF27620L,0L,0x5BF27620L,0x5BF27620L,0L,0x5BF27620L,0x5BF27620L,0L,0x5BF27620L}};
                int i, j;
                if ((safe_lshift_func_uint16_t_u_s((((&p_64 == (((safe_div_func_uint64_t_u_u(((l_358 = ((safe_add_func_int8_t_s_s((1L || 6L), p_65)) , (p_65 > 65533UL))) <= ((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint32_t_u_s(p_64, 15)), (safe_lshift_func_uint32_t_u_u((0xDB41L == l_405[6]), 7)))) < 1L)), l_406)) ^ (**g_160)) , &g_193)) != p_64) & g_85), l_405[6])))
                { /* block id: 173 */
                    l_411 &= (safe_mul_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_u((((g_140 = (g_260 = g_5[0][0])) && g_260) && (*g_155)), 47)), 0UL));
                    for (l_172 = 15; (l_172 > 60); l_172++)
                    { /* block id: 179 */
                        int32_t **l_414 = &l_84;
                        (*l_414) = l_392;
                        (**l_414) ^= (p_65 && p_65);
                        (*l_414) = l_415;
                    }
                }
                else
                { /* block id: 184 */
                    uint64_t *l_424 = &g_140;
                    uint64_t **l_423 = &l_424;
                    uint32_t *l_425 = (void*)0;
                    uint32_t *l_426 = &l_177;
                    int32_t l_428 = 1L;
                    int32_t l_432 = 6L;
                    int32_t *l_463 = &g_156[1];
                    int32_t ****l_466[10][5] = {{(void*)0,&l_377,(void*)0,&l_377,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_377,(void*)0,&l_377,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_377,(void*)0,&l_377,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_377,(void*)0,&l_377,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_377,(void*)0,&l_377,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                    uint16_t *l_468 = &l_172;
                    uint8_t l_470[5][7] = {{0x52L,255UL,0x7AL,255UL,0x52L,0x4AL,0x52L},{0xA2L,6UL,6UL,0xA2L,6UL,6UL,0xA2L},{0x7DL,255UL,0x7DL,247UL,0x52L,247UL,0x7DL},{0xA2L,0xA2L,247UL,0xA2L,0xA2L,247UL,0xA2L},{0x52L,247UL,0x7DL,255UL,0x7DL,247UL,0x52L}};
                    int32_t *l_471 = &g_85;
                    int32_t l_482 = 3L;
                    int32_t l_487 = 0x78F2025EL;
                    int32_t l_489 = (-1L);
                    int32_t l_490 = 0L;
                    int32_t l_491 = 4L;
                    int i, j;
                    (*l_415) = ((safe_mod_func_int8_t_s_s(((*l_415) ^ ((safe_rshift_func_int8_t_s_u((p_65 , (safe_mod_func_uint8_t_u_u(((*l_415) > ((((*l_426) |= ((l_422 == ((*l_423) = (void*)0)) | 9UL)) , (+1UL)) <= (l_428 = 0xE339245AE2BB5F5BLL))), 3UL))), 2)) < (**g_160))), l_391)) && 0x5419L);
                    for (l_177 = 0; (l_177 <= 40); l_177 = safe_add_func_uint8_t_u_u(l_177, 5))
                    { /* block id: 191 */
                        int32_t *l_431[7];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_431[i] = (void*)0;
                        l_435--;
                        (*l_415) = p_64;
                        (*l_415) = p_65;
                    }
                    (*l_471) |= (safe_mod_func_uint64_t_u_u((&p_64 != &p_64), (safe_add_func_int16_t_s_s((safe_rshift_func_int64_t_s_s(((safe_mul_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((((**g_160) < (((l_452 = (safe_mul_func_int32_t_s_s(p_65, p_65))) >= (((safe_lshift_func_uint32_t_u_s((*l_415), (safe_rshift_func_int16_t_s_u(((safe_div_func_int8_t_s_s((((l_469 = (safe_rshift_func_int16_t_s_u((((l_433 = (((*l_463) = (safe_lshift_func_int16_t_s_s(l_432, 9))) == (((*l_468) = (l_467[2] = ((safe_div_func_uint32_t_u_u((l_466[3][0] == (void*)0), 0x7F7E0717L)) , (*g_161)))) < p_64))) != (-6L)) , (-1L)), 6))) <= 5L) , (*l_463)), 0xE0L)) || (*g_155)), 2)))) > p_64) , g_5[3][0])) | 4UL)) && p_65), (**g_160))), (*l_415))), l_470[0][1])) > 0x91L), 1)), (*l_415)))));
                    for (l_177 = 0; (l_177 == 58); l_177 = safe_add_func_uint32_t_u_u(l_177, 9))
                    { /* block id: 205 */
                        int32_t *l_474[9] = {&g_52,&g_52,&g_52,&g_52,&g_52,&g_52,&g_52,&g_52,&g_52};
                        int8_t *l_515 = &g_94;
                        int i;
                        --l_492;
                        (*g_155) |= (((safe_rshift_func_uint16_t_u_s((safe_add_func_int32_t_s_s((((*l_471) = (0x7BL <= l_467[3])) , ((7UL >= (safe_mod_func_int16_t_s_s((safe_mul_func_int64_t_s_s(((((safe_rshift_func_int8_t_s_s(((**g_160) == ((((*l_515) = (((*l_415) = (*l_471)) & ((((((safe_rshift_func_uint16_t_u_s((safe_sub_func_int32_t_s_s(p_64, (g_174 & ((safe_mod_func_int64_t_s_s(p_65, (*l_471))) != 0x304A0AEFL)))), g_52)) == 0x3A2CD0A928B4CB26LL) == p_64) <= p_65) != g_116) , 0UL))) > g_174) && (*l_415))), p_64)) > p_65) ^ 0L) ^ p_65), l_452)), (**g_160)))) <= 1UL)), p_65)), p_64)) , 0xAFL) && 0L);
                        l_452 &= (g_123[1] || p_65);
                    }
                }
                l_516[8] = l_516[0];
            }
            else
            { /* block id: 215 */
                int32_t *l_520 = &l_486[4][9][1];
                int8_t *l_565 = &g_94;
                const int32_t *l_574 = (void*)0;
                const int32_t **l_573[5][7] = {{(void*)0,&l_574,&l_574,&l_574,&l_574,&l_574,&l_574},{(void*)0,&l_574,&l_574,(void*)0,&l_574,&l_574,&l_574},{&l_574,&l_574,(void*)0,&l_574,&l_574,&l_574,(void*)0},{&l_574,&l_574,&l_574,&l_574,&l_574,&l_574,&l_574},{(void*)0,&l_574,&l_574,(void*)0,&l_574,&l_574,&l_574}};
                const int32_t ***l_572 = &l_573[0][5];
                const uint8_t *l_602 = &g_603[1];
                int32_t l_624 = 0xB6DAF5F7L;
                int32_t l_626 = 0x277713E2L;
                int32_t l_627 = 0xF15CBCF6L;
                int32_t l_629 = 1L;
                int32_t l_631[7][10][3] = {{{(-5L),5L,0xF5894C06L},{0x830D21C6L,0L,0x830D21C6L},{0x9C5DEE8BL,0x60E52490L,0x80E20B79L},{0L,0x23ECC9A0L,0x50A47287L},{7L,0xF5894C06L,1L},{(-1L),0x5523A76DL,0L},{7L,(-5L),0x0C6B1197L},{0L,5L,(-1L)},{0xF8A528CBL,(-4L),5L},{0x21C1B7F8L,0x78C4A2A8L,0xBF33BBEAL}},{{0x81A40B03L,(-1L),7L},{(-1L),(-1L),0xFE14C3ECL},{(-1L),0x214613B6L,0x96827612L},{5L,0xF5DD9733L,0xCF7E96C8L},{5L,0x37E1A23FL,0xA83B296BL},{(-1L),(-1L),0xE8390C89L},{(-3L),0x66CDA521L,1L},{(-8L),(-8L),0L},{0x0C6B1197L,1L,0x60E52490L},{0xA2F15E8CL,0x8A1C189AL,(-1L)}},{{7L,0x5F2979F3L,(-2L)},{0x899021FAL,0xA2F15E8CL,(-1L)},{4L,0xE182A96AL,0x60E52490L},{0x78C4A2A8L,9L,0L},{0x37E1A23FL,9L,1L},{0x881330DCL,(-1L),0xE8390C89L},{0L,0L,0xA83B296BL},{0x97917CFCL,0x830D21C6L,0xCF7E96C8L},{0x7AC22D6BL,0x60E52490L,0x96827612L},{(-1L),(-7L),0xFE14C3ECL}},{{(-5L),4L,7L},{0xFE14C3ECL,0x576B4228L,0xBF33BBEAL},{0L,5L,5L},{(-1L),0x50A47287L,(-1L)},{0x66CDA521L,4L,0x5F2979F3L},{1L,0xB26B5243L,0x899021FAL},{9L,0L,0L},{0xED1DC6CDL,0xB26B5243L,(-10L)},{(-5L),4L,0xE182A96AL},{0x5523A76DL,0x50A47287L,0x21C1B7F8L}},{{(-4L),5L,(-5L)},{0x50A47287L,0x576B4228L,0x6361C300L},{(-5L),4L,0x9C5DEE8BL},{0x7B547737L,(-7L),0x576B4228L},{0x981E0A66L,0x60E52490L,3L},{0x6361C300L,0x830D21C6L,(-1L)},{(-1L),0L,(-1L)},{0x8A1C189AL,(-1L),0xA2F15E8CL},{(-1L),9L,(-1L)},{0xE8390C89L,9L,0xDD676129L}},{{0x0D8364CFL,0xE182A96AL,0xC2EC2227L},{1L,0xA2F15E8CL,0x830D21C6L},{1L,0x5F2979F3L,9L},{1L,0x8A1C189AL,(-5L)},{0x0D8364CFL,1L,0x7AC22D6BL},{0xE8390C89L,(-8L),0x7B547737L},{(-1L),0x66CDA521L,0x9E4A20BBL},{0x8A1C189AL,(-1L),0xED1DC6CDL},{(-1L),0x37E1A23FL,0L},{0x6361C300L,0xF5DD9733L,1L}},{{0x981E0A66L,0x214613B6L,0L},{0x7B547737L,(-1L),(-7L)},{(-5L),(-1L),0xF8A528CBL},{0x50A47287L,0x78C4A2A8L,0x5F5D95B5L},{(-4L),(-4L),1L},{0x5523A76DL,5L,(-1L)},{(-5L),0x81A40B03L,0x37E1A23FL},{0xED1DC6CDL,(-5L),0x86C4120BL},{9L,(-5L),0x37E1A23FL},{1L,0xDD676129L,(-1L)}}};
                uint16_t ***l_651 = &l_91;
                int i, j, k;
                (*l_520) = ((--(*g_168)) | 0xC1A4L);
                if (p_64)
                { /* block id: 218 */
                    uint16_t l_529 = 0xC1CAL;
                    int64_t *l_530 = (void*)0;
                    int32_t **l_531 = (void*)0;
                    int32_t l_534 = 0x0AFD0AD5L;
                    int8_t *l_535 = &g_94;
                    int32_t *l_536 = &l_358;
                    (*l_536) &= (l_521 < ((((*l_535) = (((safe_mul_func_uint8_t_u_u(p_65, g_156[5])) , ((safe_mul_func_int32_t_s_s((l_484 = (l_534 = (l_452 || (1L & ((safe_rshift_func_uint32_t_u_s(0x347D0AC7L, 11)) & ((((((safe_unary_minus_func_uint32_t_u((l_391 > ((*l_520) = l_529)))) & ((void*)0 != l_531)) , p_64) , l_532[2]) == l_533) , g_52)))))), 7L)) > p_64)) ^ g_74[0][1])) <= l_467[4]) ^ 0xEE1C72FAL));
                }
                else
                { /* block id: 224 */
                    uint32_t *l_550 = &g_193;
                    int32_t l_551 = (-1L);
                    int32_t *l_552 = &g_78;
                    (*l_520) &= (((&l_357 == (void*)0) <= ((*g_161) = (safe_lshift_func_uint64_t_u_s(((g_48[0][1][0] <= (1L ^ (((safe_mul_func_int64_t_s_s((l_541 >= p_64), 0x4CC96B6824F0F7B1LL)) && ((safe_lshift_func_int32_t_s_u((safe_rshift_func_uint32_t_u_u(((*l_550) = (safe_add_func_int64_t_s_s(p_64, (safe_mul_func_uint32_t_u_u((0x5CD937E0L > g_76[0][4]), 9UL))))), 31)), g_179)) | p_64)) == l_467[2]))) >= p_64), l_476[5][1])))) , l_551);
                    l_552 = &l_551;
                }
                if ((1L || (g_140 = l_492)))
                { /* block id: 231 */
                    int8_t *l_559 = &g_94;
                    int32_t **l_560 = (void*)0;
                    int32_t **l_561 = (void*)0;
                    int32_t *l_571 = &l_484;
                    const int32_t ****l_575 = (void*)0;
                    const int32_t ****l_576 = &l_572;
                    uint32_t *l_579 = &g_193;
                    uint32_t *l_580 = (void*)0;
                    uint32_t *l_581 = &g_582;
                    int32_t l_609[9][3][9] = {{{0xBF649907L,0x17993B2FL,0xB2D503AAL,0xB2D503AAL,0xB2D503AAL,0x66392DA1L,(-9L),0x8C1F87F8L,0L},{0x98C8228AL,0xBE68D1D2L,2L,0xAB4AA508L,0xAAF3694CL,0x643AB79CL,(-1L),0x01D9D264L,1L},{1L,0x9B671F2BL,0x2E0B57D5L,0xBF649907L,(-8L),(-10L),0L,0x2E0B57D5L,0L}},{{0x7DF0C69CL,0x19106502L,0L,0x1F8B3B59L,0x6CDAE7ECL,0xF75D52A0L,0xAAF3694CL,4L,0x25F36B8CL},{(-10L),(-8L),0xBF649907L,0x2E0B57D5L,0x9B671F2BL,1L,1L,0xB2D503AAL,0x2E0B57D5L},{0x28BC0172L,(-4L),0L,(-1L),0xAA82C227L,0xB923446AL,0xAAF3694CL,0xB923446AL,0xAA82C227L}},{{0x66392DA1L,0xB2D503AAL,0xB2D503AAL,0x66392DA1L,(-9L),0x8C1F87F8L,0L,0x9B671F2BL,1L},{2L,(-1L),0x25F36B8CL,0xBE68D1D2L,2L,3L,(-1L),0xB4F2097EL,0x691FD541L},{0x9B671F2BL,8L,0xB8D37320L,0xDF871930L,(-9L),0x9B671F2BL,(-9L),0xDF871930L,0xB8D37320L}},{{2L,0x31F89280L,0x7DF0C69CL,0L,0xAA82C227L,0xEEF42B54L,0x95D4FAB6L,(-1L),1L},{1L,(-7L),0x66392DA1L,(-3L),0x9B671F2BL,0L,(-7L),0x8C1F87F8L,0xBF649907L},{1L,0x9B0E5F16L,0x7DF0C69CL,0xAB4AA508L,0x6CDAE7ECL,0xAB4AA508L,0x7DF0C69CL,0x9B0E5F16L,1L}},{{1L,0xBF649907L,0xB8D37320L,0L,(-8L),(-5L),0xB2D503AAL,0xB8D37320L,0x9B671F2BL},{0x7DF0C69CL,0xE7433D29L,0x25F36B8CL,4L,0xAAF3694CL,0xF75D52A0L,0x6CDAE7ECL,0x1F8B3B59L,0L},{1L,(-8L),0xB2D503AAL,0xB80C2341L,0xB2D503AAL,(-8L),1L,(-3L),0xB80C2341L}},{{1L,0xED16524CL,0L,0x9B0E5F16L,2L,0x0E6E7EA0L,(-1L),0xB923446AL,0x7DF0C69CL},{1L,0L,0xBF649907L,0x66392DA1L,8L,1L,(-3L),(-3L),1L},{2L,0x01D9D264L,0L,0x01D9D264L,2L,1L,0xAA82C227L,0x1F8B3B59L,(-1L)}},{{0x9B671F2BL,0x5272A57AL,0x2E0B57D5L,0x17993B2FL,(-7L),0x9B671F2BL,8L,0xB8D37320L,0xDF871930L},{2L,0x31F89280L,2L,0xA9105C73L,(-1L),1L,0x95D4FAB6L,0x9B0E5F16L,0x666C8A14L},{0x66392DA1L,(-4L),0x66392DA1L,0x9B671F2BL,0xBF649907L,1L,(-4L),0x8C1F87F8L,0xB2D503AAL}},{{0x28BC0172L,0xF75D52A0L,0xAA82C227L,0xAB4AA508L,0xC86AD2A4L,0L,0L,0x643AB79CL,0L},{0xB2D503AAL,1L,0x5272A57AL,1L,0x9B671F2BL,0x9B671F2BL,1L,0x5272A57AL,1L},{0xE0123DBBL,1L,0xAAF3694CL,0xE7433D29L,0x85319E86L,0x0E6E7EA0L,0xC86AD2A4L,0x98496C20L,(-1L)}},{{0L,0x9B671F2BL,1L,(-9L),0L,(-3L),0xBF649907L,1L,(-9L)},{0x666C8A14L,1L,0x25F36B8CL,0xAB4AA508L,0L,0xB4F2097EL,0x95D4FAB6L,0xA9105C73L,0x28BC0172L},{0xB8D37320L,1L,0L,0x17993B2FL,(-5L),0xB80C2341L,0x8C1F87F8L,0x66392DA1L,0x2E0B57D5L}}};
                    int32_t l_625 = 0xF0E02443L;
                    int32_t l_628 = (-9L);
                    int32_t l_633 = 0L;
                    int32_t l_637[6][6];
                    int i, j, k;
                    for (i = 0; i < 6; i++)
                    {
                        for (j = 0; j < 6; j++)
                            l_637[i][j] = 0xD06D4FADL;
                    }
                    (*l_520) |= (((g_260 |= ((*l_422) = ((safe_sub_func_uint16_t_u_u((((((((*l_559) |= (((p_64 != ((**g_160) , g_48[0][1][0])) != (*g_168)) == (((void*)0 == l_555[3][0]) , (safe_rshift_func_uint64_t_u_u((l_478 | ((void*)0 != &l_476[5][0])), 36))))) , 0x64L) , l_492) < 0x12L) >= p_64) && 0x8465AB4BCA64F29FLL), 4L)) == l_406))) >= g_77) , 0x549AED16L);
                    l_562 = &l_486[4][1][1];
                    (*l_571) |= (safe_rshift_func_uint32_t_u_s((((void*)0 == l_565) == (((void*)0 != &g_241[2][3]) && (((safe_add_func_uint64_t_u_u(((l_207 != &g_94) || (~(safe_mod_func_uint16_t_u_u((((l_520 != (void*)0) <= ((((1UL >= p_65) & l_477) || p_65) && 1UL)) && 0x2C3F630CD0A85428LL), (*l_562))))), (-1L))) | g_179) > 0x1542C0F520941F19LL))), p_64));
                    if (((((*l_576) = l_572) != &g_241[4][0]) || (safe_div_func_uint32_t_u_u(((*l_579) = g_142), ((*l_581) &= p_65)))))
                    { /* block id: 241 */
                        int32_t **l_586 = &l_392;
                        int32_t *l_601 = &g_78;
                        const uint8_t **l_604 = (void*)0;
                        const uint8_t *l_606 = (void*)0;
                        const uint8_t **l_605 = &l_606;
                        const uint8_t *l_608 = &g_603[1];
                        const uint8_t **l_607 = &l_608;
                        l_611 = (safe_mul_func_int32_t_s_s(((*l_562) = (p_65 || (p_65 != (l_585 != ((*l_586) = ((**l_377) = l_585)))))), (((safe_rshift_func_uint8_t_u_u((((safe_rshift_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((((*l_579) ^= 0xB19AF3AFL) , (safe_sub_func_int64_t_s_s((safe_sub_func_int8_t_s_s(((((safe_sub_func_uint16_t_u_u(((safe_mul_func_int32_t_s_s(((*g_155) = ((((*l_601) = (l_484 = p_65)) || (((*l_607) = ((*l_605) = (l_602 = l_565))) != (void*)0)) != (0x4EL & 1UL))), 0x0C4AFB48L)) || (*l_601)), (*g_168))) & 255UL) , l_609[6][0][2]) || p_64), l_610)), 0UL))), l_411)), p_65)) >= 0xE33CL) > p_65), p_64)) && 0xFB40L) && (*l_601))));
                        (*l_601) = (safe_lshift_func_uint32_t_u_u(((0x72L ^ (*l_601)) ^ (l_483 , ((*l_571) <= ((safe_mod_func_uint32_t_u_u(p_65, (safe_mod_func_int32_t_s_s(p_65, 0xFC34CE3BL)))) , (p_65 , g_123[8]))))), 14));
                    }
                    else
                    { /* block id: 254 */
                        int32_t *l_620 = &l_467[5];
                        int32_t *l_621 = (void*)0;
                        int32_t *l_622 = &l_467[0];
                        int32_t *l_623[10];
                        int32_t ****l_641 = &l_377;
                        int32_t ***l_642[4] = {&g_241[3][2],&g_241[3][2],&g_241[3][2],&g_241[3][2]};
                        int i;
                        for (i = 0; i < 10; i++)
                            l_623[i] = &l_484;
                        l_638++;
                        (*l_520) = ((((void*)0 != (**l_387)) , &g_241[3][2]) == (l_642[1] = ((*l_641) = l_377)));
                    }
                }
                else
                { /* block id: 260 */
                    int8_t *l_655 = &g_636;
                    uint32_t *l_662[5][4][4] = {{{&l_610,(void*)0,&l_610,&l_610},{(void*)0,(void*)0,&l_610,(void*)0},{(void*)0,&l_610,&l_610,(void*)0},{&l_610,(void*)0,&l_610,&l_610}},{{(void*)0,(void*)0,&l_610,(void*)0},{(void*)0,&l_610,&l_610,(void*)0},{&l_610,(void*)0,&l_610,&l_610},{(void*)0,(void*)0,&l_610,(void*)0}},{{(void*)0,&l_610,&l_610,(void*)0},{&l_610,(void*)0,&l_610,&l_610},{(void*)0,(void*)0,&l_610,(void*)0},{(void*)0,&l_610,&l_610,(void*)0}},{{&l_610,(void*)0,&l_610,&l_610},{(void*)0,(void*)0,&l_610,(void*)0},{(void*)0,&l_610,&l_610,(void*)0},{&l_610,(void*)0,&l_610,&l_610}},{{(void*)0,(void*)0,&l_610,(void*)0},{(void*)0,&l_610,&l_610,(void*)0},{&l_610,(void*)0,&l_610,&l_610},{(void*)0,(void*)0,&l_610,(void*)0}}};
                    uint64_t *l_665 = (void*)0;
                    int8_t *l_666 = &g_667;
                    uint8_t *l_668 = &g_116;
                    int i, j, k;
                    for (l_624 = (-3); (l_624 > (-10)); l_624--)
                    { /* block id: 263 */
                        (*l_520) = (safe_rshift_func_uint8_t_u_s(((((*l_565) ^= p_64) >= (0x8B4D766E8257F892LL & ((*g_160) == (void*)0))) , (((safe_sub_func_uint8_t_u_u((0x0E3004D31ABF37FELL <= (*l_562)), (l_391 <= ((p_64 >= ((safe_mod_func_int32_t_s_s(p_64, p_65)) , 0xA66E7BBBL)) , (*l_562))))) ^ p_65) >= 0x0FL)), 1));
                        if (p_65)
                            continue;
                        g_652[0] = l_651;
                    }
                    l_452 ^= ((*l_562) = (*l_520));
                    (*g_670) |= ((safe_div_func_uint8_t_u_u((((*l_655) = (p_65 & (g_77 | ((*l_565) = 0x40L)))) ^ p_64), (safe_sub_func_int32_t_s_s(p_64, (safe_add_func_int64_t_s_s((((((((*l_668) = (((*l_666) = ((safe_sub_func_int32_t_s_s(1L, 0x2F2F4A4AL)) != (((g_582--) <= ((((*l_520) < ((void*)0 != l_665)) || 0x79E3832B3C4D1DA1LL) > p_64)) <= p_65))) > 247UL)) , p_65) , (*l_562)) > p_64) <= g_603[1]) & g_5[3][0]), p_65)))))) != p_65);
                }
            }
            for (g_116 = 0; (g_116 <= 3); g_116 = safe_add_func_int8_t_s_s(g_116, 1))
            { /* block id: 281 */
                uint32_t **l_682 = &l_679;
                int32_t l_689 = 0L;
                (*l_562) = ((((g_5[4][0] >= (safe_add_func_int64_t_s_s((safe_sub_func_int16_t_s_s(((safe_add_func_uint64_t_u_u(0UL, ((l_679 != &p_64) , (l_475 = ((((safe_div_func_int64_t_s_s((((*l_422) = (((*l_682) = &p_64) == (p_64 , ((safe_unary_minus_func_uint64_t_u((((((((*l_562) < (safe_mul_func_int32_t_s_s((*l_562), (safe_sub_func_int16_t_s_s(0x9D6DL, (**g_160)))))) == g_193) >= p_65) >= 0x28C2L) , &g_603[1]) == &g_5[3][0]))) , (void*)0)))) || l_177), g_688)) , (void*)0) == &l_562) && l_689))))) | l_411), g_636)), 0x689FB88CF2C44258LL))) , 0xBE2F741D52377BA8LL) >= p_64) , 0x3207B724L);
                for (l_391 = 0; (l_391 <= 52); ++l_391)
                { /* block id: 288 */
                    (*l_562) = l_689;
                    (*l_562) |= ((safe_rshift_func_int8_t_s_u(p_64, 6)) ^ (-3L));
                    (*l_562) &= (g_694 != (void*)0);
                }
            }
        }
        else
        { /* block id: 294 */
            uint32_t l_701[6];
            int32_t l_702 = 0x6526992FL;
            uint64_t *l_793 = &g_140;
            uint16_t * const *l_827 = &g_168;
            uint16_t * const **l_826 = &l_827;
            uint16_t * const ***l_825[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            uint32_t *l_890 = &l_541;
            int32_t l_913[8] = {6L,6L,0x3A1A53E5L,6L,6L,0x3A1A53E5L,6L,6L};
            uint32_t l_991[10][3][8] = {{{18446744073709551615UL,18446744073709551615UL,0x14D33D6AL,0x8003E2A8L,0UL,0x0BC3CD5DL,0x4036BD7CL,0x7420F967L},{1UL,0x7FC90FF1L,18446744073709551607UL,0x4036BD7CL,18446744073709551615UL,0UL,0xDDA0C03DL,18446744073709551612UL},{0x8DDEB511L,0x1DED6D82L,0x7988E45FL,0x139FB73CL,0x8003E2A8L,0UL,0xF55AE7F3L,0UL}},{{0UL,18446744073709551612UL,18446744073709551615UL,18446744073709551607UL,0UL,0x1DED6D82L,0x4D0E3095L,0x4D0E3095L},{0x28148849L,18446744073709551609UL,0x1DED6D82L,0x1DED6D82L,18446744073709551609UL,0x28148849L,0x0BC3CD5DL,0x8DDEB511L},{0x7FC90FF1L,0UL,18446744073709551606UL,0UL,0x6B1A7504L,0x7420F967L,1UL,18446744073709551613UL}},{{0x316E78A8L,18446744073709551612UL,7UL,0UL,0x7B6EDA1CL,0x0E9F0A07L,0x1DED6D82L,0xFD9300F5L},{0x0C1B29F3L,0x7B6EDA1CL,0x4CD194E0L,0UL,0xB2A63378L,0UL,0xFA82CDFCL,18446744073709551609UL},{7UL,0x8003E2A8L,0x7988E45FL,0x507B3A80L,0xF55AE7F3L,0x139FB73CL,0UL,0xDDA0C03DL}},{{18446744073709551607UL,18446744073709551607UL,0xF55AE7F3L,0xFA82CDFCL,0x0BC3CD5DL,0x0C1B29F3L,0x14D33D6AL,0x5C84CFFCL},{0xFA82CDFCL,0x507B3A80L,6UL,0xAA982241L,0UL,18446744073709551607UL,18446744073709551612UL,0x139FB73CL},{0xB2A63378L,18446744073709551615UL,18446744073709551615UL,0UL,0x507B3A80L,0UL,18446744073709551615UL,18446744073709551615UL}},{{0x7FC90FF1L,0x0E9F0A07L,0UL,0x4036BD7CL,1UL,18446744073709551609UL,18446744073709551607UL,0x18E71899L},{0xA67ABC97L,0x0C1B29F3L,2UL,0x7420F967L,0x7FC90FF1L,18446744073709551614UL,18446744073709551607UL,18446744073709551615UL},{0UL,0x7420F967L,0UL,18446744073709551609UL,0x139FB73CL,3UL,18446744073709551615UL,0xA67ABC97L}},{{0x139FB73CL,3UL,18446744073709551615UL,0xA67ABC97L,1UL,1UL,18446744073709551612UL,0x28148849L},{18446744073709551613UL,0x139FB73CL,6UL,0xDD537588L,18446744073709551615UL,0x1DED6D82L,0x14D33D6AL,0xFA82CDFCL},{18446744073709551615UL,1UL,0xF55AE7F3L,18446744073709551615UL,18446744073709551615UL,0x0BC3CD5DL,0UL,0x4D0E3095L}},{{0x1DED6D82L,0xAA982241L,0x7988E45FL,1UL,0xDD8BB153L,0xFA82CDFCL,0xFA82CDFCL,0xDD8BB153L},{0x7988E45FL,0x4CD194E0L,0x4CD194E0L,0x7988E45FL,0x4036BD7CL,18446744073709551613UL,0x1DED6D82L,18446744073709551607UL},{18446744073709551612UL,18446744073709551615UL,7UL,1UL,1UL,1UL,1UL,18446744073709551614UL}},{{0x8DDEB511L,18446744073709551615UL,3UL,0x6B1A7504L,0xFA82CDFCL,18446744073709551613UL,0x316E78A8L,7UL},{0x7B6EDA1CL,0x4CD194E0L,0UL,0xB2A63378L,0UL,0xFA82CDFCL,18446744073709551609UL,0x7FC90FF1L},{1UL,0xAA982241L,18446744073709551615UL,0x0C1B29F3L,18446744073709551607UL,0x0BC3CD5DL,1UL,1UL}},{{0x18E71899L,1UL,0x4036BD7CL,18446744073709551612UL,18446744073709551607UL,0x1DED6D82L,0xF55AE7F3L,0x4CD194E0L},{0xDD537588L,0x139FB73CL,0x507B3A80L,1UL,0x4D0E3095L,1UL,0xAA982241L,0xF55AE7F3L},{18446744073709551615UL,3UL,0xA67ABC97L,18446744073709551606UL,0xA67ABC97L,3UL,18446744073709551615UL,0UL}},{{18446744073709551615UL,0x7420F967L,0x18E71899L,18446744073709551607UL,7UL,18446744073709551614UL,18446744073709551615UL,18446744073709551615UL},{0x4036BD7CL,0x0C1B29F3L,18446744073709551607UL,0x139FB73CL,7UL,18446744073709551609UL,18446744073709551615UL,18446744073709551606UL},{18446744073709551615UL,0x0E9F0A07L,0UL,0x18E71899L,18446744073709551613UL,1UL,0xF55AE7F3L,0x8DDEB511L}}};
            int32_t *l_1007 = &l_913[3];
            int64_t l_1018[1][6];
            int64_t *l_1027 = &l_477;
            int32_t *l_1110 = &l_481;
            int32_t *l_1111 = (void*)0;
            int32_t *l_1112 = &l_913[1];
            int32_t *l_1113[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t l_1114 = 0L;
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_701[i] = 0x9281DF6EL;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 6; j++)
                    l_1018[i][j] = 0xF91AE58D4D92239FLL;
            }
            if (((l_702 ^= (safe_mul_func_uint32_t_u_u(0x60BFD6BDL, (l_701[2] = (safe_add_func_uint32_t_u_u(l_610, (g_667 > g_142))))))) & p_64))
            { /* block id: 297 */
                int8_t *l_713 = (void*)0;
                int8_t *l_714 = &g_636;
                int8_t *l_715 = &g_667;
                int16_t *l_731 = &g_732;
                int32_t l_733 = 0L;
                int16_t *l_734 = &g_735;
                int8_t *l_736 = (void*)0;
                uint64_t l_738 = 0xDAD5B0D86ED1A44ELL;
                uint32_t *l_739 = &g_193;
                uint16_t ***l_771 = &l_90;
                int64_t l_786 = 0xEF534720BB50FBDELL;
                int32_t l_854[3][7][10] = {{{(-1L),4L,0x44A6746DL,0xF7896253L,0xF7896253L,0x44A6746DL,4L,(-1L),0xC6B28B1BL,3L},{0xF7896253L,0x657C99B6L,(-5L),0x50A9C425L,1L,0x657C99B6L,0x50A9C425L,0x1F3A88EEL,0L,0xF7896253L},{0L,3L,(-5L),1L,(-1L),0x1F3A88EEL,0x470F17A3L,(-1L),0x657C99B6L,0x1F3A88EEL},{1L,(-1L),0x44A6746DL,3L,1L,0xC6B28B1BL,0x50A9C425L,0x50A9C425L,0xC6B28B1BL,1L},{1L,0x470F17A3L,0x470F17A3L,1L,1L,0x1F3A88EEL,4L,0L,1L,4L},{0L,1L,0x1F3A88EEL,(-5L),1L,0x657C99B6L,0x470F17A3L,4L,1L,0L},{0xF7896253L,0x50A9C425L,0x44A6746DL,1L,(-1L),0x44A6746DL,3L,1L,0xC6B28B1BL,0x50A9C425L}},{{(-1L),0x657C99B6L,0x1F3A88EEL,3L,1L,1L,3L,0x1F3A88EEL,0x657C99B6L,(-1L)},{0L,0x50A9C425L,0x470F17A3L,1L,0xF7896253L,(-5L),0x470F17A3L,0xF7896253L,0L,0x1F3A88EEL},{(-1L),1L,0x44A6746DL,0x50A9C425L,0xF7896253L,0xC6B28B1BL,4L,3L,0xC6B28B1BL,(-1L)},{0xF7896253L,0x470F17A3L,(-5L),0xF7896253L,1L,0x470F17A3L,0x50A9C425L,0L,0L,0x50A9C425L},{0L,(-1L),(-5L),(-5L),(-1L),0L,0x470F17A3L,3L,0x657C99B6L,0L},{1L,3L,0x44A6746DL,(-1L),1L,0x44A6746DL,0x50A9C425L,0xF7896253L,0xC6B28B1BL,4L},{1L,0x657C99B6L,0x470F17A3L,4L,1L,0L,4L,0x1F3A88EEL,1L,1L}},{{0L,4L,0x1F3A88EEL,1L,1L,0x470F17A3L,0x470F17A3L,1L,1L,0x1F3A88EEL},{0xF7896253L,0xF7896253L,0x44A6746DL,4L,(-1L),0xC6B28B1BL,3L,4L,0xC6B28B1BL,0xF7896253L},{(-1L),0x470F17A3L,0x1F3A88EEL,(-1L),1L,(-5L),3L,0L,0x657C99B6L,3L},{0L,0xF7896253L,0x470F17A3L,(-5L),0L,8L,0x44A6746DL,0x1F3A88EEL,1L,1L},{1L,0x470F17A3L,0x50A9C425L,0L,0L,0x50A9C425L,0x470F17A3L,1L,0xF7896253L,(-5L)},{0L,0xC6B28B1BL,(-2L),0x1F3A88EEL,8L,0xC6B28B1BL,0x1F3A88EEL,(-8L),1L,0L},{1L,(-5L),(-2L),8L,1L,(-8L),0x44A6746DL,1L,0xC6B28B1BL,(-8L)}}};
                uint32_t l_858[6];
                uint32_t *l_889 = &g_174;
                uint32_t **l_888 = &l_889;
                uint32_t **l_891 = &l_890;
                int64_t *l_893[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int64_t l_910 = 0x8F570A606C16E3EFLL;
                int i, j, k;
                for (i = 0; i < 6; i++)
                    l_858[i] = 1UL;
                if ((((*l_739) = (((((*l_533) = p_64) > (safe_lshift_func_uint16_t_u_u(((safe_add_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_s((((l_483 = (((safe_add_func_int64_t_s_s(p_65, ((*l_422) = (((safe_div_func_int8_t_s_s(((*l_715) = ((*l_714) = 0x0FL)), (l_478 = (safe_mul_func_uint8_t_u_u(((g_720 = g_78) <= ((safe_div_func_uint32_t_u_u(0xFF13C1D9L, 0x416364FFL)) > ((l_701[3] > (~l_724)) != (((*l_734) = (!(((*l_731) ^= (safe_mul_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s((~(7L >= p_64)), p_64)) , p_64), 5UL))) & l_733))) , 0x2E3599C5L)))), 0x5EL))))) ^ 0x63FB013FL) != (*g_161))))) , p_65) > 0x5FL)) == g_737) , l_738), g_48[0][1][0])) , l_486[1][7][1]), l_701[2])) >= p_64), 6))) <= p_65) , g_179)) && p_65))
                { /* block id: 308 */
                    int8_t l_744[3];
                    int32_t l_807 = 0x40E8B08BL;
                    int32_t l_814 = 0x77C61FD4L;
                    int32_t l_856 = 4L;
                    int32_t l_857 = 0xA57BE4EAL;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_744[i] = (-5L);
                    for (l_358 = (-23); (l_358 == (-28)); l_358 = safe_sub_func_uint64_t_u_u(l_358, 9))
                    { /* block id: 311 */
                        int32_t *l_742 = (void*)0;
                        int32_t *l_743[4];
                        uint64_t ****l_757[9];
                        int8_t l_772 = 1L;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_743[i] = &l_478;
                        for (i = 0; i < 9; i++)
                            l_757[i] = &g_754[0];
                        l_744[2] |= (l_479 = (p_64 == (*g_161)));
                        l_733 = (-4L);
                        g_85 &= (safe_rshift_func_int16_t_s_s(p_64, ((2L != (((**g_694) != (void*)0) > (safe_add_func_int8_t_s_s(((safe_add_func_uint16_t_u_u((g_751[0] == (l_758 = g_754[0])), (safe_add_func_int64_t_s_s(((safe_sub_func_uint16_t_u_u(((safe_lshift_func_int32_t_s_s((g_156[5] = l_744[2]), (p_65 & (safe_div_func_uint8_t_u_u((((safe_lshift_func_uint64_t_u_u(((safe_add_func_uint8_t_u_u((((*l_739) ^= ((((*g_161) = (&g_160 != l_771)) , &g_5[5][0]) == (void*)0)) < g_737), p_64)) , 0xFBA2AA5D575C45D5LL), p_65)) | g_142) | l_772), 2UL))))) && (*g_168)), p_65)) <= p_65), 0x85C732DEDE17B797LL)))) > 0x86F55BEA57D849ADLL), 9L)))) , (-1L))));
                        l_702 |= (safe_add_func_int64_t_s_s((safe_mul_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u(p_65, (((&l_738 == ((safe_unary_minus_func_uint8_t_u((((safe_sub_func_int64_t_s_s((safe_mul_func_int64_t_s_s(0x2A35B657DEF8277FLL, (safe_lshift_func_uint64_t_u_u(l_786, (safe_lshift_func_int16_t_s_u(g_74[0][4], 1)))))), (++(*l_422)))) >= (safe_rshift_func_int8_t_s_s(((((p_64 != p_64) >= (-1L)) , p_64) , 0xFDL), 5))) , l_486[8][0][0]))) , l_793)) ^ p_64) && g_48[0][1][0]))), 1L)), p_64));
                    }
                    for (g_116 = 0; (g_116 <= 5); g_116 += 1)
                    { /* block id: 325 */
                        uint32_t l_808 = 0x488D58C6L;
                        uint64_t l_815 = 4UL;
                        int32_t *l_817 = (void*)0;
                        int32_t *l_818 = &l_478;
                        int i;
                        (*g_794) = p_64;
                        (*l_818) = (safe_rshift_func_int8_t_s_s(((*l_715) = (safe_rshift_func_uint64_t_u_u(((((safe_sub_func_int16_t_s_s(((((((((safe_mul_func_int32_t_s_s((g_5[3][0] , (-1L)), l_744[1])) , (safe_lshift_func_uint8_t_u_s(g_5[3][0], 7))) & ((safe_add_func_int32_t_s_s((l_808 = (l_807 = 0x9D92CE86L)), ((0x5A77E8FC85D59947LL == ((-1L) != (safe_lshift_func_uint64_t_u_u(1UL, (l_814 = (safe_add_func_uint16_t_u_u((~l_786), p_64))))))) & g_603[1]))) , p_65)) , l_815) , p_65) , 0xC8L) > 8L) > l_816), l_701[2])) == l_815) || p_64) , 0UL), 61))), 0));
                        (*l_818) = (safe_sub_func_uint32_t_u_u(p_64, (((p_64 != (safe_sub_func_uint64_t_u_u((safe_add_func_int8_t_s_s(((void*)0 == &g_48[0][0][0]), 3L)), (((void*)0 != l_825[1]) < ((void*)0 != &g_193))))) && (-9L)) ^ g_156[5])));
                        (*l_818) = ((safe_lshift_func_uint8_t_u_u((safe_add_func_int64_t_s_s(p_64, (((safe_rshift_func_int32_t_s_s((safe_rshift_func_int64_t_s_s(l_836, (((((**g_755) = (*l_818)) | (safe_div_func_uint8_t_u_u((((((safe_mul_func_uint8_t_u_u(((p_64 || (l_702 = l_807)) >= (((((2UL != (~((((*l_714) = ((safe_rshift_func_int32_t_s_u(((safe_rshift_func_uint16_t_u_u((!0x1940139EA90A5877LL), 1)) != (p_64 & ((g_123[2] & g_142) > (-1L)))), g_174)) , p_64)) , 0x5D35L) > p_64))) & p_64) && g_74[0][4]) != p_64) , g_735)), g_582)) != 18446744073709551609UL) | p_65) == 6UL) & 0x50L), 0x87L))) < (*l_818)) >= p_65))), p_64)) || 7L) > 0x7612L))), g_123[0])) | 0L);
                    }
                    for (g_174 = 0; (g_174 <= 5); g_174 += 1)
                    { /* block id: 340 */
                        int16_t l_847 = 0xD2BFL;
                        int32_t *l_848 = &l_634;
                        int32_t *l_849 = &g_156[5];
                        int32_t *l_850[2][4];
                        int i, j;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 4; j++)
                                l_850[i][j] = (void*)0;
                        }
                        l_851++;
                        (*l_849) = l_702;
                        l_858[0]--;
                        (*l_848) = l_836;
                    }
                    (*g_861) = p_65;
                }
                else
                { /* block id: 347 */
                    int32_t *l_862[9] = {(void*)0,&l_635[2][5],&l_635[2][5],(void*)0,&l_635[2][5],&l_635[2][5],(void*)0,&l_635[2][5],&l_635[2][5]};
                    uint64_t l_863 = 18446744073709551607UL;
                    int i;
                    l_863--;
                }
                if ((safe_rshift_func_uint32_t_u_s((((safe_add_func_int32_t_s_s(((safe_unary_minus_func_int32_t_s(((((safe_mod_func_uint64_t_u_u(((p_65 > (**g_755)) , (+(((safe_mod_func_uint64_t_u_u((g_142 >= (safe_sub_func_int64_t_s_s(0xF7C74FBCECD644C6LL, ((safe_div_func_int64_t_s_s(((safe_unary_minus_func_int16_t_s(l_854[2][0][7])) && ((safe_mod_func_int64_t_s_s((l_486[1][7][1] = (safe_unary_minus_func_int8_t_s(((safe_sub_func_uint32_t_u_u((g_582 = (safe_lshift_func_uint32_t_u_s((l_478 , (((*l_888) = &g_174) != ((*l_891) = l_890))), ((&g_5[3][0] != l_892) == 4294967292UL)))), p_64)) || 0x42C2E2BC568A71F5LL)))), l_702)) != 0xA0L)), 0x9963B78F66B6E36DLL)) , (**g_755))))), p_65)) != g_74[0][4]) && p_64))), l_391)) >= p_64) >= 6UL) && p_65))) != 0xE1CC5981L), p_65)) < g_78) && 0x953BL), p_64)))
                { /* block id: 354 */
                    const int64_t l_909[1] = {0xDD2EA06C18213CA4LL};
                    uint8_t *l_912 = &l_611;
                    int32_t l_914[4][4] = {{(-3L),0x2271EA22L,(-3L),(-3L)},{0x2271EA22L,0x2271EA22L,(-1L),0x2271EA22L},{0x2271EA22L,(-3L),(-3L),0x2271EA22L},{(-3L),0x2271EA22L,(-3L),(-3L)}};
                    uint32_t **l_945[4][5][7] = {{{(void*)0,(void*)0,&l_679,(void*)0,&l_679,&l_739,&l_679},{(void*)0,&l_739,&l_679,(void*)0,&l_739,(void*)0,(void*)0},{&l_739,(void*)0,&l_679,(void*)0,(void*)0,(void*)0,(void*)0},{&l_679,&l_739,&l_739,&l_679,&l_739,&l_739,(void*)0},{&l_739,(void*)0,&l_739,&l_679,&l_739,(void*)0,&l_679}},{{&l_679,&l_679,&l_679,(void*)0,&l_739,(void*)0,&l_739},{&l_679,&l_739,(void*)0,&l_739,&l_679,&l_739,&l_679},{(void*)0,&l_739,&l_739,&l_739,&l_739,(void*)0,(void*)0},{&l_679,(void*)0,&l_739,(void*)0,(void*)0,(void*)0,(void*)0},{&l_739,(void*)0,&l_739,&l_739,(void*)0,&l_739,&l_679}},{{(void*)0,(void*)0,&l_739,(void*)0,&l_739,(void*)0,&l_739},{(void*)0,&l_739,&l_739,(void*)0,&l_679,&l_679,&l_739},{(void*)0,&l_739,&l_739,&l_739,(void*)0,&l_679,(void*)0},{&l_679,&l_679,(void*)0,&l_679,(void*)0,&l_739,&l_679},{&l_739,(void*)0,&l_739,&l_739,&l_679,&l_739,&l_739}},{{&l_739,&l_739,(void*)0,&l_739,&l_739,(void*)0,&l_679},{&l_739,(void*)0,&l_679,(void*)0,(void*)0,&l_679,(void*)0},{&l_679,&l_739,&l_739,&l_739,&l_739,&l_679,&l_739},{(void*)0,(void*)0,&l_679,&l_739,(void*)0,(void*)0,(void*)0},{(void*)0,&l_679,&l_679,(void*)0,&l_679,&l_739,&l_679}}};
                    int i, j, k;
                    l_357 = (g_193 , (safe_mod_func_int16_t_s_s(4L, (safe_div_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u(l_854[2][0][7], 0)), (l_914[0][0] = (l_913[6] ^= (safe_lshift_func_uint64_t_u_s(((((((((p_64 | ((l_902 = (void*)0) != (((*l_912) = (((((p_65 != ((**g_160) >= (0x08B87F5BL < ((safe_lshift_func_uint32_t_u_s((safe_mod_func_int64_t_s_s((safe_div_func_uint64_t_u_u(p_64, l_909[0])), 0x02DB5EC3093EF40ALL)), 23)) , l_702)))) < l_910) , (void*)0) != &g_754[0]) , l_911)) , &p_65))) != l_909[0]) ^ p_64) & p_64) > g_156[5]) > p_64) | g_737) > 4294967291UL), p_64)))))))));
                    for (g_78 = 0; (g_78 <= 0); g_78 += 1)
                    { /* block id: 362 */
                        uint32_t l_919 = 0UL;
                        uint32_t **l_929 = &l_889;
                        int32_t *l_932 = &l_914[1][2];
                        int i;
                        (*l_932) &= ((safe_rshift_func_int32_t_s_u((safe_add_func_int8_t_s_s(((&l_909[0] != &l_909[0]) != (**g_160)), (l_919 != (((safe_mul_func_uint8_t_u_u((0L & (p_64 & l_909[0])), (+(safe_mul_func_uint8_t_u_u((((g_179 & (safe_add_func_uint32_t_u_u(((safe_lshift_func_int8_t_s_u((((*l_715) &= ((l_930 = l_929) == g_931)) & g_735), p_64)) | p_65), 0xD62B6E27L))) , (void*)0) != (void*)0), p_65))))) && 7UL) , g_260)))), p_65)) < p_64);
                    }
                    if ((p_64 != ((**g_755) = (g_94 , l_933[1]))))
                    { /* block id: 368 */
                        int32_t *l_934[1][3][10] = {{{&l_630,&l_913[6],&l_913[6],&l_630,&l_483,&l_854[2][0][7],&l_483,&l_630,&l_913[6],&l_913[6]},{&l_483,&l_913[6],&l_479,(void*)0,(void*)0,&l_479,&l_913[6],&l_483,&l_913[6],&l_479},{&l_854[2][0][7],&l_630,(void*)0,&l_630,&l_854[2][0][7],&l_479,&l_479,&l_854[2][0][7],&l_630,(void*)0}}};
                        uint32_t **l_946 = &l_739;
                        uint32_t ***l_947 = (void*)0;
                        uint32_t ***l_948 = &l_946;
                        int32_t **l_952 = &l_934[0][2][5];
                        int i, j, k;
                        l_914[0][3] = (l_854[2][0][7] &= (*g_794));
                        if (l_478)
                            goto lbl_1009;
                        l_914[0][0] = ((((safe_mod_func_uint64_t_u_u((safe_div_func_uint64_t_u_u((safe_div_func_uint64_t_u_u(l_914[0][0], l_909[0])), (safe_sub_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((g_123[0] && ((l_945[2][2][6] != ((*l_948) = l_946)) != (safe_sub_func_uint64_t_u_u((((p_65 <= (((**g_160) <= p_65) >= ((l_913[6] = (!((g_85 != 255UL) , p_65))) | 2UL))) | g_179) > 0x1AB1789AL), p_64)))), 0x5ACEC5E39BA67448LL)), 2UL)))), p_65)) , l_521) || p_65) || p_64);
                        (*l_952) = &l_634;
                    }
                    else
                    { /* block id: 375 */
                        int8_t **l_963 = &l_713;
                        uint16_t *** const l_968 = &l_91;
                        int32_t l_974 = 4L;
                        int32_t *l_980[9] = {&g_85,&l_733,&g_85,&l_733,&g_85,&l_733,&g_85,&l_733,&g_85};
                        int i;
                        l_475 = (safe_mul_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_u(g_737, 2)) > ((safe_add_func_int16_t_s_s((l_854[2][0][7] = (safe_div_func_uint64_t_u_u((++(**g_755)), 1UL))), 0x3E4CL)) , (((*l_963) = (g_123[3] , &g_94)) == (void*)0))), (safe_add_func_uint32_t_u_u(((safe_add_func_int64_t_s_s(((l_968 == (void*)0) != ((+(p_64 = (safe_div_func_int32_t_s_s((safe_mod_func_uint32_t_u_u((--(*l_739)), (safe_mul_func_int16_t_s_s((+p_64), p_65)))), (*g_155))))) & 7UL)), l_913[0])) , p_65), l_909[0]))));
                        ++g_981;
                    }
                }
                else
                { /* block id: 384 */
                    int32_t *l_984 = &l_486[5][5][0];
                    int32_t l_985 = 0xD5871D8EL;
                    int32_t *l_986 = &l_488;
                    int32_t *l_987 = &g_156[3];
                    int32_t *l_988 = &l_486[1][7][1];
                    int32_t *l_989 = (void*)0;
                    int32_t *l_990[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int i;
                    l_991[5][1][3]--;
                    (*l_987) = p_64;
                    return g_603[1];
                }
                l_913[6] = (p_65 > (safe_sub_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(g_193, (safe_add_func_uint64_t_u_u((safe_lshift_func_int32_t_s_s(1L, 31)), (safe_mul_func_uint32_t_u_u((++p_64), p_65)))))), 0L)));
            }
            else
            { /* block id: 391 */
                int32_t **l_1006[7][5][7] = {{{&g_51,(void*)0,&g_51,(void*)0,&g_51,&g_51,(void*)0},{&l_84,(void*)0,&l_84,(void*)0,(void*)0,&l_84,(void*)0},{(void*)0,&l_84,&g_51,&g_51,&l_84,(void*)0,&l_84},{&l_84,(void*)0,(void*)0,&l_84,(void*)0,&l_84,(void*)0},{&g_51,&g_51,(void*)0,&g_51,(void*)0,&g_51,&g_51}},{{&l_84,(void*)0,&g_51,(void*)0,&l_84,&l_84,(void*)0},{(void*)0,&l_84,(void*)0,(void*)0,(void*)0,(void*)0,&l_84},{(void*)0,(void*)0,&g_51,&g_51,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_84,(void*)0,(void*)0},{&l_84,&l_84,(void*)0,&g_51,(void*)0,&l_84,&l_84}},{{&g_51,(void*)0,&g_51,(void*)0,&g_51,&g_51,(void*)0},{&l_84,(void*)0,&l_84,(void*)0,(void*)0,&l_84,(void*)0},{(void*)0,&l_84,&g_51,&g_51,&l_84,(void*)0,&l_84},{&l_84,(void*)0,(void*)0,&l_84,(void*)0,&l_84,(void*)0},{&g_51,&g_51,(void*)0,&g_51,(void*)0,&g_51,&g_51}},{{&l_84,(void*)0,&g_51,(void*)0,&l_84,&l_84,(void*)0},{(void*)0,&l_84,(void*)0,(void*)0,(void*)0,(void*)0,&l_84},{(void*)0,(void*)0,&g_51,&g_51,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_51,&g_51,&g_51,(void*)0},{(void*)0,(void*)0,&l_84,(void*)0,&l_84,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_84,(void*)0,(void*)0,(void*)0,(void*)0},{&g_51,&l_84,&g_51,&l_84,&l_84,&g_51,&l_84},{(void*)0,&g_51,&l_84,&l_84,&g_51,(void*)0,&g_51},{&g_51,&l_84,&l_84,&g_51,&l_84,&g_51,&l_84},{(void*)0,(void*)0,(void*)0,&l_84,(void*)0,(void*)0,(void*)0}},{{(void*)0,&l_84,(void*)0,&l_84,(void*)0,(void*)0,&l_84},{&g_51,&g_51,&g_51,(void*)0,(void*)0,&g_51,&g_51},{&l_84,&l_84,(void*)0,(void*)0,&l_84,&l_84,&l_84},{&g_51,(void*)0,(void*)0,&g_51,&g_51,&g_51,(void*)0},{(void*)0,(void*)0,&l_84,(void*)0,&l_84,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_84,(void*)0,(void*)0,(void*)0,(void*)0},{&g_51,&l_84,&g_51,&l_84,&l_84,&g_51,&l_84},{(void*)0,&g_51,&l_84,&l_84,&g_51,(void*)0,&g_51},{&g_51,&l_84,&l_84,&g_51,&l_84,&g_51,&l_84},{(void*)0,(void*)0,(void*)0,&l_84,(void*)0,(void*)0,(void*)0}}};
                int i, j, k;
                l_1007 = (*g_50);
            }
lbl_1009:
            l_1007 = l_1008;
            if ((0x9672L < ((p_64 , ((safe_rshift_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(((*l_1027) = (((((void*)0 != &g_193) < ((((safe_add_func_int64_t_s_s(((p_64 , ((***l_377) = (safe_mul_func_int8_t_s_s(l_1018[0][5], 0x9EL)))) , 0x916B538310846AD1LL), ((safe_div_func_uint64_t_u_u(((*l_793) ^= (((safe_rshift_func_int64_t_s_s((((*l_1007) = (safe_div_func_int32_t_s_s((safe_sub_func_uint16_t_u_u(0x8899L, (*l_1008))), p_64))) <= p_64), p_65)) , 0xFC6C99C8L) || p_64)), 1UL)) < 1L))) || (*l_1007)) & l_411) | (**g_160))) >= 0xEBB44CFABE894260LL) == p_65)), 0x811B4270185ADF9CLL)), 9)) & p_65)) || (*l_1008))))
            { /* block id: 400 */
                return g_737;
            }
            else
            { /* block id: 402 */
                int32_t l_1081 = 0x5418435DL;
                int32_t l_1085 = (-10L);
                int32_t l_1086 = 1L;
                int32_t l_1087 = 0x77954722L;
                int32_t l_1088 = (-10L);
                int32_t l_1089 = 0x311C9F15L;
                int32_t l_1090[2];
                uint32_t *l_1094 = (void*)0;
                int i;
                for (i = 0; i < 2; i++)
                    l_1090[i] = (-1L);
                for (l_724 = 0; (l_724 < 13); l_724 = safe_add_func_int32_t_s_s(l_724, 8))
                { /* block id: 405 */
                    uint8_t **l_1033 = (void*)0;
                    uint8_t ***l_1032 = &l_1033;
                    const int32_t l_1057 = 3L;
                    int32_t l_1058 = 0x97037E9FL;
                }
                (*g_1043) = &l_635[2][1];
                if ((*g_670))
                { /* block id: 430 */
                    int32_t *l_1082 = &g_85;
                    int32_t *l_1083 = &l_635[2][2];
                    int32_t *l_1084[3][3];
                    int i, j;
                    for (i = 0; i < 3; i++)
                    {
                        for (j = 0; j < 3; j++)
                            l_1084[i][j] = &l_475;
                    }
                    ++l_1091;
                }
                else
                { /* block id: 432 */
                    uint32_t ** const **l_1097 = &g_1095;
                    int32_t l_1107 = (-9L);
                    const uint64_t *l_1108[6] = {&g_260,&g_260,&g_260,&g_260,&g_260,&g_260};
                    const uint64_t **l_1109 = &l_1108[5];
                    int i;
                    (*l_1008) = ((void*)0 != l_1094);
                    g_1098 = ((*l_1097) = g_1095);
                    (*l_1007) = (safe_sub_func_int64_t_s_s((((safe_mul_func_int32_t_s_s(p_65, (l_724 > ((void*)0 == (*l_377))))) & ((safe_add_func_uint8_t_u_u((((((((*l_1109) = ((safe_add_func_int8_t_s_s((*l_1007), ((**g_755) , ((**g_1077) |= l_1107)))) , l_1108[5])) != l_793) ^ 0x209EF1F2608DBF2BLL) , 4294967292UL) & 3L) >= p_65), 0x44L)) <= 0xC289D7EAL)) >= (-8L)), 1UL));
                    (*g_51) = 0L;
                }
            }
            --l_1115;
        }
    }
    return l_1118;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_5[i][j], "g_5[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_23, "g_23", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_48[i][j][k], "g_48[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_52, "g_52", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_74[i][j], "g_74[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_76[i][j], "g_76[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_123[i], "g_123[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_156[i], "g_156[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_174, "g_174", print_hash_value);
    transparent_crc(g_179, "g_179", print_hash_value);
    transparent_crc(g_193, "g_193", print_hash_value);
    transparent_crc(g_260, "g_260", print_hash_value);
    transparent_crc(g_582, "g_582", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_603[i], "g_603[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_636, "g_636", print_hash_value);
    transparent_crc(g_667, "g_667", print_hash_value);
    transparent_crc(g_688, "g_688", print_hash_value);
    transparent_crc(g_720, "g_720", print_hash_value);
    transparent_crc(g_732, "g_732", print_hash_value);
    transparent_crc(g_735, "g_735", print_hash_value);
    transparent_crc(g_737, "g_737", print_hash_value);
    transparent_crc(g_855, "g_855", print_hash_value);
    transparent_crc(g_981, "g_981", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_1038[i][j][k], "g_1038[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1079, "g_1079", print_hash_value);
    transparent_crc(g_1121, "g_1121", print_hash_value);
    transparent_crc(g_1178, "g_1178", print_hash_value);
    transparent_crc(g_1207, "g_1207", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1350[i], "g_1350[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1394, "g_1394", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1509[i], "g_1509[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1573, "g_1573", print_hash_value);
    transparent_crc(g_1670, "g_1670", print_hash_value);
    transparent_crc(g_1878, "g_1878", print_hash_value);
    transparent_crc(g_1949, "g_1949", print_hash_value);
    transparent_crc(g_1956, "g_1956", print_hash_value);
    transparent_crc(g_2075, "g_2075", print_hash_value);
    transparent_crc(g_2168, "g_2168", print_hash_value);
    transparent_crc(g_2173, "g_2173", print_hash_value);
    transparent_crc(g_2464, "g_2464", print_hash_value);
    transparent_crc(g_2466, "g_2466", print_hash_value);
    transparent_crc(g_2472, "g_2472", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2591[i], "g_2591[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2989, "g_2989", print_hash_value);
    transparent_crc(g_3136, "g_3136", print_hash_value);
    transparent_crc(g_3180, "g_3180", print_hash_value);
    transparent_crc(g_3506, "g_3506", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_3905[i][j], "g_3905[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3906, "g_3906", print_hash_value);
    transparent_crc(g_3907, "g_3907", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_3908[i], "g_3908[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3909, "g_3909", print_hash_value);
    transparent_crc(g_3910, "g_3910", print_hash_value);
    transparent_crc(g_3911, "g_3911", print_hash_value);
    transparent_crc(g_3912, "g_3912", print_hash_value);
    transparent_crc(g_3913, "g_3913", print_hash_value);
    transparent_crc(g_4122, "g_4122", print_hash_value);
    transparent_crc(g_4174, "g_4174", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_4236[i][j], "g_4236[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4371, "g_4371", print_hash_value);
    transparent_crc(g_4521, "g_4521", print_hash_value);
    transparent_crc(g_4553, "g_4553", print_hash_value);
    transparent_crc(g_4585, "g_4585", print_hash_value);
    transparent_crc(g_5095, "g_5095", print_hash_value);
    transparent_crc(g_5231, "g_5231", print_hash_value);
    transparent_crc(g_5236, "g_5236", print_hash_value);
    transparent_crc(g_5540, "g_5540", print_hash_value);
    transparent_crc(g_5629, "g_5629", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_5809[i][j], "g_5809[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_5899[i][j][k], "g_5899[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_5928, "g_5928", print_hash_value);
    transparent_crc(g_6046, "g_6046", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1443
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 56
breakdown:
   depth: 1, occurrence: 585
   depth: 2, occurrence: 144
   depth: 3, occurrence: 7
   depth: 4, occurrence: 9
   depth: 5, occurrence: 3
   depth: 6, occurrence: 6
   depth: 7, occurrence: 7
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 3
   depth: 11, occurrence: 2
   depth: 12, occurrence: 1
   depth: 13, occurrence: 3
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 6
   depth: 17, occurrence: 4
   depth: 18, occurrence: 6
   depth: 19, occurrence: 10
   depth: 20, occurrence: 8
   depth: 21, occurrence: 7
   depth: 22, occurrence: 8
   depth: 23, occurrence: 12
   depth: 24, occurrence: 4
   depth: 25, occurrence: 8
   depth: 26, occurrence: 5
   depth: 27, occurrence: 8
   depth: 28, occurrence: 2
   depth: 29, occurrence: 10
   depth: 30, occurrence: 7
   depth: 31, occurrence: 4
   depth: 32, occurrence: 2
   depth: 33, occurrence: 4
   depth: 34, occurrence: 5
   depth: 35, occurrence: 1
   depth: 36, occurrence: 4
   depth: 37, occurrence: 4
   depth: 38, occurrence: 2
   depth: 39, occurrence: 1
   depth: 40, occurrence: 3
   depth: 42, occurrence: 1
   depth: 43, occurrence: 1
   depth: 56, occurrence: 1

XXX total number of pointers: 1157

XXX times a variable address is taken: 3082
XXX times a pointer is dereferenced on RHS: 966
breakdown:
   depth: 1, occurrence: 708
   depth: 2, occurrence: 191
   depth: 3, occurrence: 34
   depth: 4, occurrence: 32
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 899
breakdown:
   depth: 1, occurrence: 681
   depth: 2, occurrence: 159
   depth: 3, occurrence: 35
   depth: 4, occurrence: 18
   depth: 5, occurrence: 6
XXX times a pointer is compared with null: 140
XXX times a pointer is compared with address of another variable: 45
XXX times a pointer is compared with another pointer: 34
XXX times a pointer is qualified to be dereferenced: 18858

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 6539
   level: 2, occurrence: 1552
   level: 3, occurrence: 373
   level: 4, occurrence: 265
   level: 5, occurrence: 53
XXX number of pointers point to pointers: 588
XXX number of pointers point to scalars: 569
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.9
XXX average alias set size: 1.46

XXX times a non-volatile is read: 5396
XXX times a non-volatile is write: 2762
XXX times a volatile is read: 184
XXX    times read thru a pointer: 48
XXX times a volatile is write: 56
XXX    times written thru a pointer: 13
XXX times a volatile is available for access: 3.37e+03
XXX percentage of non-volatile access: 97.1

XXX forward jumps: 7
XXX backward jumps: 15

XXX stmts: 596
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 37
   depth: 2, occurrence: 60
   depth: 3, occurrence: 125
   depth: 4, occurrence: 165
   depth: 5, occurrence: 181

XXX percentage a fresh-made variable is used: 15.4
XXX percentage an existing variable is used: 84.6
XXX total OOB instances added: 0
********************* end of statistics **********************/

